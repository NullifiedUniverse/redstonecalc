tellraw @s {"text":"[rscalc] no mark yet — /function rscalc_move:mark where you want to come back to.","color":"red"}
