execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] run return fail
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.0] run return fail
scoreboard players set @s rscalc_move_fall 60
execute facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^0.85 if block ~ ~ ~ #rscalc_move:passable run tp @s ~ ~ ~
