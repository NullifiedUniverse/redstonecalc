tellraw @a {"text":"rscalc traversal","color":"white"}
tellraw @a {"text":"  /function rscalc_move:gear  — get the hook and the dash charm, and switch it on","color":"gray"}
tellraw @a {"text":"  /function rscalc_move:on  — enable the hook and dash for yourself","color":"gray"}
tellraw @a {"text":"  /function rscalc_move:off  — disable them","color":"gray"}
tellraw @a {"text":"  /function rscalc_move:mark  — remember where you are standing","color":"gray"}
tellraw @a {"text":"  /function rscalc_move:recall  — go back to the mark","color":"gray"}
tellraw @a {"text":"  Cast the rod to grapple; hold it out to keep pulling, reel in to let go. Right-click the charm to dash 4 blocks the way you are looking. Both leave you with slow falling, so the landing is survivable.","color":"gray"}
