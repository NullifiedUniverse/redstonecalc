give @s minecraft:fishing_rod[custom_name={text:"Grappling Hook",color:"aqua",italic:false},custom_data={rscalc_move:1b}]
give @s minecraft:carrot_on_a_stick[custom_name={text:"Dash Charm",color:"gold",italic:false},custom_data={rscalc_move:1b}]
function rscalc_move:on
