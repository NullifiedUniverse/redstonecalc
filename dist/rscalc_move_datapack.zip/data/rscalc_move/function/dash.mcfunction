scoreboard players set @s rscalc_move_dash 0
scoreboard players set @s rscalc_move_fall 60
execute positioned ^ ^ ^1 if block ~ ~ ~ #rscalc_move:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^2 if block ~ ~ ~ #rscalc_move:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^3 if block ~ ~ ~ #rscalc_move:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^4 if block ~ ~ ~ #rscalc_move:passable run tp @s ~ ~ ~
playsound minecraft:entity.arrow.shoot player @s ~ ~ ~ 0.6 1.6
