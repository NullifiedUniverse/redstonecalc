$tp @s $(x) $(y) $(z)
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.5 1.2
