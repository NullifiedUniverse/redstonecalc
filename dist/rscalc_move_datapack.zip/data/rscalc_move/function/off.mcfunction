tag @s remove rscalc_move_on
tellraw @s {"text":"[rscalc] hook and dash off.","color":"gray"}
