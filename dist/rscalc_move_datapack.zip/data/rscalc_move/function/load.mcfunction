scoreboard objectives add rscalc_move_dash minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rscalc_move_use minecraft.used:minecraft.fishing_rod
scoreboard objectives add rscalc_move_fall dummy
tellraw @a {"text":"[rscalc] traversal loaded — /function rscalc_move:help","color":"dark_gray"}
