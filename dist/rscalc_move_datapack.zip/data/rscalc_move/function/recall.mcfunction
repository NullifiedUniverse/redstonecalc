execute unless data storage rscalc_move:wp x run function rscalc_move:no_mark
execute unless data storage rscalc_move:wp x run return fail
scoreboard players set @s rscalc_move_fall 60
function rscalc_move:recall_at with storage rscalc_move:wp
