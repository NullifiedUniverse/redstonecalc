execute as @a[tag=rscalc_move_on] at @s run function rscalc_move:grapple
execute as @a[tag=rscalc_move_on,scores={rscalc_move_dash=1..}] at @s run function rscalc_move:dash
execute as @a[scores={rscalc_move_fall=1..}] run effect give @s minecraft:slow_falling 1 0 true
scoreboard players remove @a[scores={rscalc_move_fall=1..}] rscalc_move_fall 1
