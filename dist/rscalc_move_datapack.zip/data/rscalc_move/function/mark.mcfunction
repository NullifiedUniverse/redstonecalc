execute store result storage rscalc_move:wp x double 0.01 run data get entity @s Pos[0] 100
execute store result storage rscalc_move:wp y double 0.01 run data get entity @s Pos[1] 100
execute store result storage rscalc_move:wp z double 0.01 run data get entity @s Pos[2] 100
tellraw @s {"text":"[rscalc] mark set — /function rscalc_move:recall to come back.","color":"gray"}
