tag @s add rscalc_move_on
scoreboard players set @s rscalc_move_dash 0
tellraw @s {"text":"[rscalc] hook and dash on. Cast the rod to grapple.","color":"aqua"}
