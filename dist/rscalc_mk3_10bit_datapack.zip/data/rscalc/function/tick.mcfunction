execute as @e[type=marker,tag=rscalc_anchor,limit=1] at @s run function rscalc:sys/dispatch
scoreboard players add #build rscalc_v 1
execute store result storage rscalc:ui part int 1 run scoreboard players get #build rscalc_v
scoreboard players operation #pitch rscalc_v = #build rscalc_v
scoreboard players operation #pitch rscalc_v *= #c90 rscalc_v
scoreboard players operation #pitch rscalc_v /= #cparts rscalc_v
scoreboard players add #pitch rscalc_v 90
execute store result storage rscalc:ui pitch double 0.01 run scoreboard players get #pitch rscalc_v
function rscalc:sys/bar with storage rscalc:ui
execute store result storage rscalc:ui pace int 1 run scoreboard players get #pace rscalc_v
execute if score #build rscalc_v matches ..119 run function rscalc:sys/next with storage rscalc:ui
execute if score #build rscalc_v matches 120.. run function rscalc:sys/done
