execute as @e[type=marker,tag=rscalc_anchor,limit=1] at @s run function rscalc:sys/dispatch
scoreboard players add #build rscalc_v 1
execute store result storage rscalc:ui part int 1 run scoreboard players get #build rscalc_v
function rscalc:sys/bar with storage rscalc:ui
execute if score #build rscalc_v matches ..35 run schedule function rscalc:tick 1t replace
execute if score #build rscalc_v matches 36.. run function rscalc:sys/done
