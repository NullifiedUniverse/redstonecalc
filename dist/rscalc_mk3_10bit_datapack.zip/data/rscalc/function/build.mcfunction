# 71,768 commands in 120 parts, one part per tick, after the
# chunks are actually loaded. Stand at the -X -Y -Z corner.
scoreboard objectives add rscalc_v dummy
execute if score #run rscalc_v matches 1 run function rscalc:sys/busy
execute if score #run rscalc_v matches 1 run return fail
scoreboard players set #run rscalc_v 1
scoreboard players set #build rscalc_v 0
scoreboard players set #wait rscalc_v 0
data remove storage rscalc:ui layer
kill @e[type=marker,tag=rscalc_anchor]
execute at @s align xyz run summon marker ~ ~ ~ {Tags:["rscalc_anchor"]}
execute store result storage rscalc:origin x int 1 run data get entity @e[type=marker,tag=rscalc_anchor,limit=1] Pos[0]
execute store result storage rscalc:origin y int 1 run data get entity @e[type=marker,tag=rscalc_anchor,limit=1] Pos[1]
execute store result storage rscalc:origin z int 1 run data get entity @e[type=marker,tag=rscalc_anchor,limit=1] Pos[2]
execute unless score #pace rscalc_v matches 1.. run scoreboard players set #pace rscalc_v 1
scoreboard players set #c90 rscalc_v 90
scoreboard players set #cparts rscalc_v 120
bossbar add rscalc:progress "rscalc_mk3_10bit"
bossbar set rscalc:progress players @a
bossbar set rscalc:progress color blue
bossbar set rscalc:progress name "rscalc_mk3_10bit: loading chunks"
bossbar set rscalc:progress max 2135
bossbar set rscalc:progress value 0
tellraw @a {"text":"rscalc_mk3_10bit: 71,768 commands over 120 batches, once 2135 chunks are loaded. You are standing inside the footprint — use spectator, or /function rscalc:go/above.","color":"gray"}
function rscalc:load
function rscalc:sys/wait
