execute unless data storage rscalc:origin x run function rscalc:sys/no_origin
execute unless data storage rscalc:origin x run return fail
function rscalc:sys/unload_at with storage rscalc:origin
