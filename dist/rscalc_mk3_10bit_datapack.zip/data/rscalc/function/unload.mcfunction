execute unless data storage rscalc:origin x run function rscalc:sys/no_origin
execute unless data storage rscalc:origin x run return fail
scoreboard players set #keep rscalc_v 0
function rscalc:sys/unload_at with storage rscalc:origin
