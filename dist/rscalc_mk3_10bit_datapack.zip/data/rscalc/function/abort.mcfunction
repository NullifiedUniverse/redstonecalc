scoreboard objectives add rscalc_v dummy
schedule clear rscalc:tick
schedule clear rscalc:sys/wait
schedule clear rscalc:sys/clear_tick
scoreboard players set #run rscalc_v 0
tellraw @a {"text":"rscalc_mk3_10bit: stopped. Anything half-placed is still there; run build again or clear it.","color":"yellow"}
