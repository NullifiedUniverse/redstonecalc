setblock ~448 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~550 ~440 ~169 ~560 minecraft:redstone_wire replace
fill ~444 ~169 ~550 ~444 ~169 ~560 minecraft:redstone_wire replace
fill ~448 ~169 ~550 ~448 ~169 ~560 minecraft:redstone_wire replace
fill ~458 ~169 ~550 ~458 ~169 ~560 minecraft:redstone_wire replace
fill ~460 ~169 ~550 ~460 ~169 ~560 minecraft:redstone_wire replace
fill ~472 ~169 ~550 ~472 ~169 ~560 minecraft:redstone_wire replace
fill ~474 ~169 ~550 ~474 ~169 ~560 minecraft:redstone_wire replace
setblock ~442 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~554 ~442 ~169 ~564 minecraft:redstone_wire replace
fill ~450 ~169 ~554 ~450 ~169 ~564 minecraft:redstone_wire replace
fill ~456 ~169 ~554 ~456 ~169 ~564 minecraft:redstone_wire replace
fill ~462 ~169 ~554 ~462 ~169 ~564 minecraft:redstone_wire replace
fill ~470 ~169 ~554 ~470 ~169 ~564 minecraft:redstone_wire replace
fill ~476 ~169 ~554 ~476 ~169 ~564 minecraft:redstone_wire replace
fill ~502 ~169 ~554 ~502 ~169 ~564 minecraft:redstone_wire replace
setblock ~446 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~558 ~446 ~169 ~568 minecraft:redstone_wire replace
fill ~452 ~169 ~558 ~452 ~169 ~568 minecraft:redstone_wire replace
fill ~454 ~169 ~558 ~454 ~169 ~568 minecraft:redstone_wire replace
fill ~464 ~169 ~558 ~464 ~169 ~568 minecraft:redstone_wire replace
fill ~466 ~169 ~558 ~466 ~169 ~568 minecraft:redstone_wire replace
fill ~478 ~169 ~558 ~478 ~169 ~568 minecraft:redstone_wire replace
fill ~480 ~169 ~558 ~480 ~169 ~568 minecraft:redstone_wire replace
setblock ~440 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~562 ~440 ~169 ~572 minecraft:redstone_wire replace
fill ~444 ~169 ~562 ~444 ~169 ~572 minecraft:redstone_wire replace
fill ~448 ~169 ~562 ~448 ~169 ~572 minecraft:redstone_wire replace
fill ~458 ~169 ~562 ~458 ~169 ~572 minecraft:redstone_wire replace
fill ~460 ~169 ~562 ~460 ~169 ~572 minecraft:redstone_wire replace
fill ~472 ~169 ~562 ~472 ~169 ~572 minecraft:redstone_wire replace
fill ~474 ~169 ~562 ~474 ~169 ~572 minecraft:redstone_wire replace
setblock ~442 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~566 ~442 ~169 ~576 minecraft:redstone_wire replace
fill ~450 ~169 ~566 ~450 ~169 ~576 minecraft:redstone_wire replace
fill ~456 ~169 ~566 ~456 ~169 ~576 minecraft:redstone_wire replace
fill ~462 ~169 ~566 ~462 ~169 ~576 minecraft:redstone_wire replace
fill ~476 ~169 ~566 ~476 ~169 ~576 minecraft:redstone_wire replace
fill ~502 ~169 ~566 ~502 ~169 ~576 minecraft:redstone_wire replace
setblock ~446 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~570 ~446 ~169 ~580 minecraft:redstone_wire replace
fill ~452 ~169 ~570 ~452 ~169 ~580 minecraft:redstone_wire replace
fill ~454 ~169 ~570 ~454 ~169 ~580 minecraft:redstone_wire replace
fill ~464 ~169 ~570 ~464 ~169 ~580 minecraft:redstone_wire replace
fill ~466 ~169 ~570 ~466 ~169 ~580 minecraft:redstone_wire replace
fill ~478 ~169 ~570 ~478 ~169 ~580 minecraft:redstone_wire replace
fill ~480 ~169 ~570 ~480 ~169 ~580 minecraft:redstone_wire replace
setblock ~440 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~574 ~440 ~169 ~584 minecraft:redstone_wire replace
fill ~444 ~169 ~574 ~444 ~169 ~584 minecraft:redstone_wire replace
fill ~448 ~169 ~574 ~448 ~169 ~584 minecraft:redstone_wire replace
fill ~458 ~169 ~574 ~458 ~169 ~584 minecraft:redstone_wire replace
fill ~460 ~169 ~574 ~460 ~169 ~584 minecraft:redstone_wire replace
fill ~472 ~169 ~574 ~472 ~169 ~584 minecraft:redstone_wire replace
fill ~474 ~169 ~574 ~474 ~169 ~584 minecraft:redstone_wire replace
setblock ~442 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~578 ~442 ~169 ~588 minecraft:redstone_wire replace
fill ~450 ~169 ~578 ~450 ~169 ~588 minecraft:redstone_wire replace
fill ~456 ~169 ~578 ~456 ~169 ~588 minecraft:redstone_wire replace
fill ~462 ~169 ~578 ~462 ~169 ~588 minecraft:redstone_wire replace
fill ~476 ~169 ~578 ~476 ~169 ~588 minecraft:redstone_wire replace
fill ~502 ~169 ~578 ~502 ~169 ~588 minecraft:redstone_wire replace
setblock ~446 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~582 ~446 ~169 ~592 minecraft:redstone_wire replace
fill ~452 ~169 ~582 ~452 ~169 ~592 minecraft:redstone_wire replace
fill ~454 ~169 ~582 ~454 ~169 ~592 minecraft:redstone_wire replace
fill ~464 ~169 ~582 ~464 ~169 ~592 minecraft:redstone_wire replace
fill ~466 ~169 ~582 ~466 ~169 ~592 minecraft:redstone_wire replace
fill ~478 ~169 ~582 ~478 ~169 ~592 minecraft:redstone_wire replace
fill ~480 ~169 ~582 ~480 ~169 ~592 minecraft:redstone_wire replace
setblock ~440 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~586 ~440 ~169 ~596 minecraft:redstone_wire replace
fill ~444 ~169 ~586 ~444 ~169 ~596 minecraft:redstone_wire replace
fill ~448 ~169 ~586 ~448 ~169 ~596 minecraft:redstone_wire replace
fill ~458 ~169 ~586 ~458 ~169 ~596 minecraft:redstone_wire replace
fill ~460 ~169 ~586 ~460 ~169 ~596 minecraft:redstone_wire replace
fill ~472 ~169 ~586 ~472 ~169 ~596 minecraft:redstone_wire replace
fill ~474 ~169 ~586 ~474 ~169 ~596 minecraft:redstone_wire replace
setblock ~442 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~590 ~442 ~169 ~600 minecraft:redstone_wire replace
fill ~450 ~169 ~590 ~450 ~169 ~600 minecraft:redstone_wire replace
fill ~456 ~169 ~590 ~456 ~169 ~600 minecraft:redstone_wire replace
fill ~462 ~169 ~590 ~462 ~169 ~600 minecraft:redstone_wire replace
fill ~476 ~169 ~590 ~476 ~169 ~600 minecraft:redstone_wire replace
fill ~502 ~169 ~590 ~502 ~169 ~600 minecraft:redstone_wire replace
setblock ~446 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~594 ~446 ~169 ~604 minecraft:redstone_wire replace
fill ~452 ~169 ~594 ~452 ~169 ~604 minecraft:redstone_wire replace
fill ~454 ~169 ~594 ~454 ~169 ~604 minecraft:redstone_wire replace
fill ~464 ~169 ~594 ~464 ~169 ~604 minecraft:redstone_wire replace
fill ~466 ~169 ~594 ~466 ~169 ~604 minecraft:redstone_wire replace
fill ~478 ~169 ~594 ~478 ~169 ~604 minecraft:redstone_wire replace
fill ~480 ~169 ~594 ~480 ~169 ~604 minecraft:redstone_wire replace
setblock ~440 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~598 ~440 ~169 ~608 minecraft:redstone_wire replace
fill ~444 ~169 ~598 ~444 ~169 ~608 minecraft:redstone_wire replace
fill ~448 ~169 ~598 ~448 ~169 ~608 minecraft:redstone_wire replace
fill ~458 ~169 ~598 ~458 ~169 ~608 minecraft:redstone_wire replace
fill ~460 ~169 ~598 ~460 ~169 ~608 minecraft:redstone_wire replace
fill ~474 ~169 ~598 ~474 ~169 ~608 minecraft:redstone_wire replace
setblock ~442 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~602 ~442 ~169 ~612 minecraft:redstone_wire replace
fill ~450 ~169 ~602 ~450 ~169 ~612 minecraft:redstone_wire replace
fill ~456 ~169 ~602 ~456 ~169 ~612 minecraft:redstone_wire replace
fill ~462 ~169 ~602 ~462 ~169 ~612 minecraft:redstone_wire replace
fill ~476 ~169 ~602 ~476 ~169 ~612 minecraft:redstone_wire replace
fill ~502 ~169 ~602 ~502 ~169 ~612 minecraft:redstone_wire replace
setblock ~446 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~606 ~446 ~169 ~616 minecraft:redstone_wire replace
fill ~452 ~169 ~606 ~452 ~169 ~616 minecraft:redstone_wire replace
fill ~454 ~169 ~606 ~454 ~169 ~616 minecraft:redstone_wire replace
fill ~464 ~169 ~606 ~464 ~169 ~616 minecraft:redstone_wire replace
fill ~466 ~169 ~606 ~466 ~169 ~616 minecraft:redstone_wire replace
fill ~478 ~169 ~606 ~478 ~169 ~616 minecraft:redstone_wire replace
fill ~480 ~169 ~606 ~480 ~169 ~616 minecraft:redstone_wire replace
setblock ~440 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~610 ~440 ~169 ~620 minecraft:redstone_wire replace
fill ~444 ~169 ~610 ~444 ~169 ~620 minecraft:redstone_wire replace
fill ~448 ~169 ~610 ~448 ~169 ~620 minecraft:redstone_wire replace
fill ~458 ~169 ~610 ~458 ~169 ~620 minecraft:redstone_wire replace
fill ~460 ~169 ~610 ~460 ~169 ~620 minecraft:redstone_wire replace
fill ~474 ~169 ~610 ~474 ~169 ~620 minecraft:redstone_wire replace
setblock ~442 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~614 ~442 ~169 ~624 minecraft:redstone_wire replace
fill ~450 ~169 ~614 ~450 ~169 ~624 minecraft:redstone_wire replace
fill ~456 ~169 ~614 ~456 ~169 ~624 minecraft:redstone_wire replace
fill ~462 ~169 ~614 ~462 ~169 ~624 minecraft:redstone_wire replace
fill ~476 ~169 ~614 ~476 ~169 ~624 minecraft:redstone_wire replace
fill ~502 ~169 ~614 ~502 ~169 ~624 minecraft:redstone_wire replace
setblock ~446 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~618 ~446 ~169 ~628 minecraft:redstone_wire replace
fill ~452 ~169 ~618 ~452 ~169 ~628 minecraft:redstone_wire replace
fill ~454 ~169 ~618 ~454 ~169 ~628 minecraft:redstone_wire replace
fill ~464 ~169 ~618 ~464 ~169 ~628 minecraft:redstone_wire replace
fill ~466 ~169 ~618 ~466 ~169 ~628 minecraft:redstone_wire replace
fill ~478 ~169 ~618 ~478 ~169 ~628 minecraft:redstone_wire replace
fill ~480 ~169 ~618 ~480 ~169 ~628 minecraft:redstone_wire replace
setblock ~440 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~622 ~440 ~169 ~632 minecraft:redstone_wire replace
fill ~444 ~169 ~622 ~444 ~169 ~632 minecraft:redstone_wire replace
fill ~448 ~169 ~622 ~448 ~169 ~632 minecraft:redstone_wire replace
fill ~458 ~169 ~622 ~458 ~169 ~632 minecraft:redstone_wire replace
fill ~460 ~169 ~622 ~460 ~169 ~632 minecraft:redstone_wire replace
fill ~474 ~169 ~622 ~474 ~169 ~632 minecraft:redstone_wire replace
setblock ~442 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~626 ~442 ~169 ~636 minecraft:redstone_wire replace
fill ~450 ~169 ~626 ~450 ~169 ~636 minecraft:redstone_wire replace
fill ~456 ~169 ~626 ~456 ~169 ~636 minecraft:redstone_wire replace
fill ~462 ~169 ~626 ~462 ~169 ~636 minecraft:redstone_wire replace
fill ~476 ~169 ~626 ~476 ~169 ~636 minecraft:redstone_wire replace
fill ~502 ~169 ~626 ~502 ~169 ~636 minecraft:redstone_wire replace
setblock ~446 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~630 ~446 ~169 ~640 minecraft:redstone_wire replace
fill ~452 ~169 ~630 ~452 ~169 ~640 minecraft:redstone_wire replace
fill ~454 ~169 ~630 ~454 ~169 ~640 minecraft:redstone_wire replace
fill ~464 ~169 ~630 ~464 ~169 ~640 minecraft:redstone_wire replace
fill ~466 ~169 ~630 ~466 ~169 ~640 minecraft:redstone_wire replace
fill ~478 ~169 ~630 ~478 ~169 ~640 minecraft:redstone_wire replace
fill ~480 ~169 ~630 ~480 ~169 ~640 minecraft:redstone_wire replace
setblock ~440 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~634 ~440 ~169 ~644 minecraft:redstone_wire replace
fill ~444 ~169 ~634 ~444 ~169 ~644 minecraft:redstone_wire replace
fill ~448 ~169 ~634 ~448 ~169 ~644 minecraft:redstone_wire replace
fill ~458 ~169 ~634 ~458 ~169 ~644 minecraft:redstone_wire replace
fill ~460 ~169 ~634 ~460 ~169 ~644 minecraft:redstone_wire replace
setblock ~442 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~638 ~442 ~169 ~648 minecraft:redstone_wire replace
fill ~450 ~169 ~638 ~450 ~169 ~648 minecraft:redstone_wire replace
fill ~456 ~169 ~638 ~456 ~169 ~648 minecraft:redstone_wire replace
fill ~462 ~169 ~638 ~462 ~169 ~648 minecraft:redstone_wire replace
fill ~476 ~169 ~638 ~476 ~169 ~648 minecraft:redstone_wire replace
fill ~502 ~169 ~638 ~502 ~169 ~648 minecraft:redstone_wire replace
setblock ~446 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~642 ~446 ~169 ~652 minecraft:redstone_wire replace
fill ~452 ~169 ~642 ~452 ~169 ~652 minecraft:redstone_wire replace
fill ~454 ~169 ~642 ~454 ~169 ~652 minecraft:redstone_wire replace
fill ~464 ~169 ~642 ~464 ~169 ~652 minecraft:redstone_wire replace
fill ~466 ~169 ~642 ~466 ~169 ~652 minecraft:redstone_wire replace
fill ~478 ~169 ~642 ~478 ~169 ~652 minecraft:redstone_wire replace
fill ~480 ~169 ~642 ~480 ~169 ~652 minecraft:redstone_wire replace
setblock ~440 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~646 ~440 ~169 ~656 minecraft:redstone_wire replace
fill ~444 ~169 ~646 ~444 ~169 ~656 minecraft:redstone_wire replace
fill ~448 ~169 ~646 ~448 ~169 ~656 minecraft:redstone_wire replace
fill ~458 ~169 ~646 ~458 ~169 ~656 minecraft:redstone_wire replace
fill ~460 ~169 ~646 ~460 ~169 ~656 minecraft:redstone_wire replace
setblock ~442 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~650 ~442 ~169 ~660 minecraft:redstone_wire replace
fill ~450 ~169 ~650 ~450 ~169 ~660 minecraft:redstone_wire replace
fill ~456 ~169 ~650 ~456 ~169 ~660 minecraft:redstone_wire replace
fill ~462 ~169 ~650 ~462 ~169 ~660 minecraft:redstone_wire replace
fill ~476 ~169 ~650 ~476 ~169 ~660 minecraft:redstone_wire replace
fill ~502 ~169 ~650 ~502 ~169 ~660 minecraft:redstone_wire replace
setblock ~446 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~654 ~446 ~169 ~664 minecraft:redstone_wire replace
fill ~452 ~169 ~654 ~452 ~169 ~664 minecraft:redstone_wire replace
fill ~454 ~169 ~654 ~454 ~169 ~664 minecraft:redstone_wire replace
fill ~464 ~169 ~654 ~464 ~169 ~664 minecraft:redstone_wire replace
fill ~466 ~169 ~654 ~466 ~169 ~664 minecraft:redstone_wire replace
fill ~478 ~169 ~654 ~478 ~169 ~664 minecraft:redstone_wire replace
fill ~480 ~169 ~654 ~480 ~169 ~664 minecraft:redstone_wire replace
setblock ~440 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~658 ~440 ~169 ~668 minecraft:redstone_wire replace
fill ~444 ~169 ~658 ~444 ~169 ~668 minecraft:redstone_wire replace
fill ~448 ~169 ~658 ~448 ~169 ~668 minecraft:redstone_wire replace
fill ~458 ~169 ~658 ~458 ~169 ~668 minecraft:redstone_wire replace
fill ~460 ~169 ~658 ~460 ~169 ~668 minecraft:redstone_wire replace
setblock ~442 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~662 ~442 ~169 ~672 minecraft:redstone_wire replace
fill ~450 ~169 ~662 ~450 ~169 ~672 minecraft:redstone_wire replace
fill ~456 ~169 ~662 ~456 ~169 ~672 minecraft:redstone_wire replace
fill ~462 ~169 ~662 ~462 ~169 ~672 minecraft:redstone_wire replace
fill ~502 ~169 ~662 ~502 ~169 ~672 minecraft:redstone_wire replace
setblock ~446 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~666 ~446 ~169 ~676 minecraft:redstone_wire replace
fill ~452 ~169 ~666 ~452 ~169 ~676 minecraft:redstone_wire replace
fill ~454 ~169 ~666 ~454 ~169 ~676 minecraft:redstone_wire replace
fill ~464 ~169 ~666 ~464 ~169 ~676 minecraft:redstone_wire replace
fill ~466 ~169 ~666 ~466 ~169 ~676 minecraft:redstone_wire replace
fill ~478 ~169 ~666 ~478 ~169 ~676 minecraft:redstone_wire replace
fill ~480 ~169 ~666 ~480 ~169 ~676 minecraft:redstone_wire replace
setblock ~440 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~670 ~440 ~169 ~680 minecraft:redstone_wire replace
fill ~444 ~169 ~670 ~444 ~169 ~680 minecraft:redstone_wire replace
fill ~448 ~169 ~670 ~448 ~169 ~680 minecraft:redstone_wire replace
fill ~458 ~169 ~670 ~458 ~169 ~680 minecraft:redstone_wire replace
fill ~460 ~169 ~670 ~460 ~169 ~680 minecraft:redstone_wire replace
setblock ~442 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~674 ~442 ~169 ~684 minecraft:redstone_wire replace
fill ~450 ~169 ~674 ~450 ~169 ~684 minecraft:redstone_wire replace
fill ~456 ~169 ~674 ~456 ~169 ~684 minecraft:redstone_wire replace
fill ~462 ~169 ~674 ~462 ~169 ~684 minecraft:redstone_wire replace
fill ~502 ~169 ~674 ~502 ~169 ~684 minecraft:redstone_wire replace
setblock ~446 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~678 ~446 ~169 ~688 minecraft:redstone_wire replace
fill ~452 ~169 ~678 ~452 ~169 ~688 minecraft:redstone_wire replace
fill ~454 ~169 ~678 ~454 ~169 ~688 minecraft:redstone_wire replace
fill ~464 ~169 ~678 ~464 ~169 ~688 minecraft:redstone_wire replace
fill ~466 ~169 ~678 ~466 ~169 ~688 minecraft:redstone_wire replace
fill ~480 ~169 ~678 ~480 ~169 ~688 minecraft:redstone_wire replace
setblock ~440 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~682 ~440 ~169 ~692 minecraft:redstone_wire replace
fill ~444 ~169 ~682 ~444 ~169 ~692 minecraft:redstone_wire replace
fill ~448 ~169 ~682 ~448 ~169 ~692 minecraft:redstone_wire replace
fill ~458 ~169 ~682 ~458 ~169 ~692 minecraft:redstone_wire replace
fill ~460 ~169 ~682 ~460 ~169 ~692 minecraft:redstone_wire replace
setblock ~442 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~686 ~442 ~169 ~696 minecraft:redstone_wire replace
fill ~450 ~169 ~686 ~450 ~169 ~696 minecraft:redstone_wire replace
fill ~456 ~169 ~686 ~456 ~169 ~696 minecraft:redstone_wire replace
fill ~462 ~169 ~686 ~462 ~169 ~696 minecraft:redstone_wire replace
fill ~502 ~169 ~686 ~502 ~169 ~696 minecraft:redstone_wire replace
setblock ~446 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~690 ~446 ~169 ~700 minecraft:redstone_wire replace
fill ~452 ~169 ~690 ~452 ~169 ~700 minecraft:redstone_wire replace
fill ~454 ~169 ~690 ~454 ~169 ~700 minecraft:redstone_wire replace
fill ~464 ~169 ~690 ~464 ~169 ~700 minecraft:redstone_wire replace
fill ~466 ~169 ~690 ~466 ~169 ~700 minecraft:redstone_wire replace
fill ~480 ~169 ~690 ~480 ~169 ~700 minecraft:redstone_wire replace
setblock ~440 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~694 ~440 ~169 ~704 minecraft:redstone_wire replace
fill ~444 ~169 ~694 ~444 ~169 ~704 minecraft:redstone_wire replace
fill ~448 ~169 ~694 ~448 ~169 ~704 minecraft:redstone_wire replace
fill ~458 ~169 ~694 ~458 ~169 ~704 minecraft:redstone_wire replace
fill ~460 ~169 ~694 ~460 ~169 ~704 minecraft:redstone_wire replace
setblock ~442 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~698 ~442 ~169 ~708 minecraft:redstone_wire replace
fill ~450 ~169 ~698 ~450 ~169 ~708 minecraft:redstone_wire replace
fill ~456 ~169 ~698 ~456 ~169 ~708 minecraft:redstone_wire replace
fill ~462 ~169 ~698 ~462 ~169 ~708 minecraft:redstone_wire replace
fill ~502 ~169 ~698 ~502 ~169 ~708 minecraft:redstone_wire replace
setblock ~446 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~702 ~446 ~169 ~712 minecraft:redstone_wire replace
fill ~452 ~169 ~702 ~452 ~169 ~712 minecraft:redstone_wire replace
fill ~454 ~169 ~702 ~454 ~169 ~712 minecraft:redstone_wire replace
fill ~464 ~169 ~702 ~464 ~169 ~712 minecraft:redstone_wire replace
fill ~466 ~169 ~702 ~466 ~169 ~712 minecraft:redstone_wire replace
setblock ~440 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~706 ~440 ~169 ~716 minecraft:redstone_wire replace
fill ~444 ~169 ~706 ~444 ~169 ~716 minecraft:redstone_wire replace
fill ~448 ~169 ~706 ~448 ~169 ~716 minecraft:redstone_wire replace
fill ~458 ~169 ~706 ~458 ~169 ~716 minecraft:redstone_wire replace
fill ~460 ~169 ~706 ~460 ~169 ~716 minecraft:redstone_wire replace
setblock ~442 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~710 ~442 ~169 ~720 minecraft:redstone_wire replace
fill ~450 ~169 ~710 ~450 ~169 ~720 minecraft:redstone_wire replace
fill ~456 ~169 ~710 ~456 ~169 ~720 minecraft:redstone_wire replace
fill ~462 ~169 ~710 ~462 ~169 ~720 minecraft:redstone_wire replace
fill ~502 ~169 ~710 ~502 ~169 ~720 minecraft:redstone_wire replace
setblock ~446 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~714 ~446 ~169 ~724 minecraft:redstone_wire replace
fill ~452 ~169 ~714 ~452 ~169 ~724 minecraft:redstone_wire replace
fill ~454 ~169 ~714 ~454 ~169 ~724 minecraft:redstone_wire replace
fill ~464 ~169 ~714 ~464 ~169 ~724 minecraft:redstone_wire replace
fill ~466 ~169 ~714 ~466 ~169 ~724 minecraft:redstone_wire replace
setblock ~440 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~718 ~440 ~169 ~728 minecraft:redstone_wire replace
fill ~444 ~169 ~718 ~444 ~169 ~728 minecraft:redstone_wire replace
fill ~448 ~169 ~718 ~448 ~169 ~728 minecraft:redstone_wire replace
fill ~458 ~169 ~718 ~458 ~169 ~728 minecraft:redstone_wire replace
fill ~460 ~169 ~718 ~460 ~169 ~728 minecraft:redstone_wire replace
setblock ~442 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~722 ~442 ~169 ~732 minecraft:redstone_wire replace
fill ~450 ~169 ~722 ~450 ~169 ~732 minecraft:redstone_wire replace
fill ~456 ~169 ~722 ~456 ~169 ~732 minecraft:redstone_wire replace
fill ~462 ~169 ~722 ~462 ~169 ~732 minecraft:redstone_wire replace
fill ~502 ~169 ~722 ~502 ~169 ~732 minecraft:redstone_wire replace
setblock ~446 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~726 ~446 ~169 ~736 minecraft:redstone_wire replace
fill ~452 ~169 ~726 ~452 ~169 ~736 minecraft:redstone_wire replace
fill ~454 ~169 ~726 ~454 ~169 ~736 minecraft:redstone_wire replace
fill ~464 ~169 ~726 ~464 ~169 ~736 minecraft:redstone_wire replace
fill ~466 ~169 ~726 ~466 ~169 ~736 minecraft:redstone_wire replace
setblock ~440 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~444 ~169 ~730 ~444 ~169 ~740 minecraft:redstone_wire replace
fill ~448 ~169 ~730 ~448 ~169 ~740 minecraft:redstone_wire replace
fill ~458 ~169 ~730 ~458 ~169 ~740 minecraft:redstone_wire replace
fill ~460 ~169 ~730 ~460 ~169 ~740 minecraft:redstone_wire replace
setblock ~442 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~450 ~169 ~734 ~450 ~169 ~744 minecraft:redstone_wire replace
fill ~456 ~169 ~734 ~456 ~169 ~744 minecraft:redstone_wire replace
fill ~462 ~169 ~734 ~462 ~169 ~744 minecraft:redstone_wire replace
fill ~502 ~169 ~734 ~502 ~169 ~744 minecraft:redstone_wire replace
setblock ~446 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~738 ~446 ~169 ~748 minecraft:redstone_wire replace
fill ~452 ~169 ~738 ~452 ~169 ~748 minecraft:redstone_wire replace
fill ~454 ~169 ~738 ~454 ~169 ~748 minecraft:redstone_wire replace
fill ~464 ~169 ~738 ~464 ~169 ~748 minecraft:redstone_wire replace
fill ~466 ~169 ~738 ~466 ~169 ~748 minecraft:redstone_wire replace
setblock ~444 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~448 ~169 ~742 ~448 ~169 ~752 minecraft:redstone_wire replace
fill ~458 ~169 ~742 ~458 ~169 ~752 minecraft:redstone_wire replace
fill ~460 ~169 ~742 ~460 ~169 ~752 minecraft:redstone_wire replace
setblock ~450 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~450 ~169 ~746 ~450 ~169 ~756 minecraft:redstone_wire replace
fill ~456 ~169 ~746 ~456 ~169 ~756 minecraft:redstone_wire replace
fill ~462 ~169 ~746 ~462 ~169 ~756 minecraft:redstone_wire replace
fill ~502 ~169 ~746 ~502 ~169 ~756 minecraft:redstone_wire replace
setblock ~446 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~750 ~452 ~169 ~760 minecraft:redstone_wire replace
fill ~454 ~169 ~750 ~454 ~169 ~760 minecraft:redstone_wire replace
fill ~464 ~169 ~750 ~464 ~169 ~760 minecraft:redstone_wire replace
fill ~466 ~169 ~750 ~466 ~169 ~760 minecraft:redstone_wire replace
setblock ~448 ~169 ~753 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~753 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~753 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~754 ~458 ~169 ~764 minecraft:redstone_wire replace
fill ~460 ~169 ~754 ~460 ~169 ~764 minecraft:redstone_wire replace
setblock ~450 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
