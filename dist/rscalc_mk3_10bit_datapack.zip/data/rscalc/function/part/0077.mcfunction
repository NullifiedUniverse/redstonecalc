setblock ~184 ~45 ~327 minecraft:redstone_wire replace
setblock ~187 ~45 ~327 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~45 ~330 ~209 ~45 ~330 minecraft:redstone_wire replace
setblock ~210 ~45 ~330 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~45 ~330 ~212 ~45 ~330 minecraft:redstone_wire replace
setblock ~211 ~45 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~45 ~334 ~208 ~45 ~334 minecraft:redstone_wire replace
setblock ~210 ~45 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~45 ~334 ~224 ~45 ~334 minecraft:redstone_wire replace
setblock ~226 ~45 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~45 ~334 ~240 ~45 ~334 minecraft:redstone_wire replace
setblock ~242 ~45 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~45 ~334 ~255 ~45 ~334 minecraft:redstone_wire replace
setblock ~257 ~45 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~45 ~334 ~272 ~45 ~334 minecraft:redstone_wire replace
setblock ~274 ~45 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~45 ~334 ~289 ~45 ~334 minecraft:redstone_wire replace
setblock ~291 ~45 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~293 ~45 ~334 ~299 ~45 ~334 minecraft:redstone_wire replace
setblock ~208 ~45 ~335 minecraft:redstone_wire replace
setblock ~232 ~45 ~335 minecraft:redstone_wire replace
setblock ~283 ~45 ~335 minecraft:redstone_wire replace
setblock ~298 ~45 ~335 minecraft:redstone_wire replace
fill ~207 ~45 ~342 ~212 ~45 ~342 minecraft:redstone_wire replace
setblock ~213 ~45 ~342 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~214 ~45 ~342 ~215 ~45 ~342 minecraft:redstone_wire replace
setblock ~214 ~45 ~343 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~45 ~346 ~236 ~45 ~346 minecraft:redstone_wire replace
setblock ~237 ~45 ~346 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~45 ~346 ~239 ~45 ~346 minecraft:redstone_wire replace
setblock ~238 ~45 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~45 ~350 ~240 ~45 ~350 minecraft:redstone_wire replace
setblock ~242 ~45 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~45 ~350 ~257 ~45 ~350 minecraft:redstone_wire replace
setblock ~259 ~45 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~45 ~350 ~273 ~45 ~350 minecraft:redstone_wire replace
setblock ~275 ~45 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~277 ~45 ~350 ~290 ~45 ~350 minecraft:redstone_wire replace
setblock ~292 ~45 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~294 ~45 ~350 ~299 ~45 ~350 minecraft:redstone_wire replace
setblock ~232 ~45 ~351 minecraft:redstone_wire replace
setblock ~283 ~45 ~351 minecraft:redstone_wire replace
setblock ~298 ~45 ~351 minecraft:redstone_wire replace
fill ~234 ~45 ~358 ~239 ~45 ~358 minecraft:redstone_wire replace
setblock ~240 ~45 ~358 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~45 ~358 ~242 ~45 ~358 minecraft:redstone_wire replace
setblock ~241 ~45 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~45 ~362 ~283 ~45 ~362 minecraft:redstone_wire replace
setblock ~284 ~45 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~45 ~362 ~296 ~45 ~362 minecraft:redstone_wire replace
setblock ~297 ~45 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~45 ~362 ~299 ~45 ~362 minecraft:redstone_wire replace
setblock ~283 ~45 ~363 minecraft:redstone_wire replace
setblock ~298 ~45 ~363 minecraft:redstone_wire replace
fill ~306 ~45 ~366 ~308 ~45 ~366 minecraft:redstone_wire replace
setblock ~307 ~45 ~367 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~309 ~45 ~370 ~311 ~45 ~370 minecraft:redstone_wire replace
setblock ~310 ~45 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~45 ~374 ~284 ~45 ~374 minecraft:redstone_wire replace
setblock ~283 ~45 ~375 minecraft:redstone_wire replace
fill ~294 ~45 ~378 ~297 ~45 ~378 minecraft:redstone_wire replace
setblock ~295 ~45 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~45 ~386 ~260 ~45 ~386 minecraft:redstone_wire replace
setblock ~259 ~45 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~45 ~390 ~335 ~45 ~390 minecraft:redstone_wire replace
setblock ~334 ~45 ~391 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~45 ~394 ~356 ~45 ~394 minecraft:redstone_wire replace
setblock ~355 ~45 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~45 ~398 ~323 ~45 ~398 minecraft:redstone_wire replace
setblock ~322 ~45 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~45 ~402 ~347 ~45 ~402 minecraft:redstone_wire replace
setblock ~346 ~45 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~45 ~406 ~317 ~45 ~406 minecraft:redstone_wire replace
setblock ~316 ~45 ~407 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~45 ~414 ~92 ~45 ~414 minecraft:redstone_wire replace
setblock ~91 ~45 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~45 ~418 ~119 ~45 ~418 minecraft:redstone_wire replace
setblock ~118 ~45 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~45 ~422 ~143 ~45 ~422 minecraft:redstone_wire replace
setblock ~142 ~45 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~45 ~426 ~176 ~45 ~426 minecraft:redstone_wire replace
setblock ~175 ~45 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~45 ~430 ~200 ~45 ~430 minecraft:redstone_wire replace
setblock ~199 ~45 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~45 ~434 ~224 ~45 ~434 minecraft:redstone_wire replace
setblock ~225 ~45 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~45 ~434 ~227 ~45 ~434 minecraft:redstone_wire replace
setblock ~226 ~45 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~252 ~45 ~438 ~257 ~45 ~438 minecraft:redstone_wire replace
setblock ~256 ~45 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~45 ~442 ~278 ~45 ~442 minecraft:redstone_wire replace
setblock ~277 ~45 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~45 ~446 ~314 ~45 ~446 minecraft:redstone_wire replace
setblock ~313 ~45 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~45 ~450 ~89 ~45 ~450 minecraft:redstone_wire replace
setblock ~88 ~45 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~45 ~454 ~116 ~45 ~454 minecraft:redstone_wire replace
setblock ~115 ~45 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~45 ~458 ~140 ~45 ~458 minecraft:redstone_wire replace
setblock ~139 ~45 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~45 ~462 ~173 ~45 ~462 minecraft:redstone_wire replace
setblock ~172 ~45 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~45 ~466 ~197 ~45 ~466 minecraft:redstone_wire replace
setblock ~196 ~45 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~216 ~45 ~470 ~221 ~45 ~470 minecraft:redstone_wire replace
setblock ~222 ~45 ~470 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~45 ~470 ~224 ~45 ~470 minecraft:redstone_wire replace
setblock ~223 ~45 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~45 ~474 ~251 ~45 ~474 minecraft:redstone_wire replace
setblock ~252 ~45 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~45 ~474 ~254 ~45 ~474 minecraft:redstone_wire replace
setblock ~253 ~45 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~45 ~478 ~275 ~45 ~478 minecraft:redstone_wire replace
setblock ~274 ~45 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~45 ~482 ~338 ~45 ~482 minecraft:redstone_wire replace
setblock ~337 ~45 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~360 ~45 ~486 ~362 ~45 ~486 minecraft:redstone_wire replace
setblock ~361 ~45 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~45 ~490 ~86 ~45 ~490 minecraft:redstone_wire replace
setblock ~85 ~45 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~45 ~494 ~113 ~45 ~494 minecraft:redstone_wire replace
setblock ~112 ~45 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~45 ~498 ~137 ~45 ~498 minecraft:redstone_wire replace
setblock ~136 ~45 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~45 ~502 ~164 ~45 ~502 minecraft:redstone_wire replace
setblock ~163 ~45 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~45 ~506 ~194 ~45 ~506 minecraft:redstone_wire replace
setblock ~193 ~45 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~45 ~510 ~218 ~45 ~510 minecraft:redstone_wire replace
setblock ~219 ~45 ~510 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~45 ~510 ~221 ~45 ~510 minecraft:redstone_wire replace
setblock ~220 ~45 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~243 ~45 ~514 ~248 ~45 ~514 minecraft:redstone_wire replace
setblock ~249 ~45 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~45 ~514 ~251 ~45 ~514 minecraft:redstone_wire replace
setblock ~250 ~45 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~45 ~518 ~272 ~45 ~518 minecraft:redstone_wire replace
setblock ~271 ~45 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~330 ~45 ~522 ~332 ~45 ~522 minecraft:redstone_wire replace
setblock ~331 ~45 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~45 ~526 ~359 ~45 ~526 minecraft:redstone_wire replace
setblock ~358 ~45 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~45 ~530 ~83 ~45 ~530 minecraft:redstone_wire replace
setblock ~82 ~45 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~45 ~534 ~110 ~45 ~534 minecraft:redstone_wire replace
setblock ~109 ~45 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~45 ~538 ~134 ~45 ~538 minecraft:redstone_wire replace
setblock ~133 ~45 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~45 ~542 ~158 ~45 ~542 minecraft:redstone_wire replace
setblock ~157 ~45 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~45 ~546 ~191 ~45 ~546 minecraft:redstone_wire replace
setblock ~190 ~45 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~45 ~550 ~215 ~45 ~550 minecraft:redstone_wire replace
setblock ~216 ~45 ~550 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~45 ~550 ~218 ~45 ~550 minecraft:redstone_wire replace
setblock ~217 ~45 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~45 ~554 ~245 ~45 ~554 minecraft:redstone_wire replace
setblock ~246 ~45 ~554 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~45 ~554 ~248 ~45 ~554 minecraft:redstone_wire replace
setblock ~247 ~45 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~45 ~558 ~266 ~45 ~558 minecraft:redstone_wire replace
setblock ~265 ~45 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~327 ~45 ~562 ~329 ~45 ~562 minecraft:redstone_wire replace
setblock ~328 ~45 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~351 ~45 ~566 ~353 ~45 ~566 minecraft:redstone_wire replace
setblock ~352 ~45 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~45 ~570 ~80 ~45 ~570 minecraft:redstone_wire replace
setblock ~79 ~45 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~45 ~574 ~107 ~45 ~574 minecraft:redstone_wire replace
setblock ~106 ~45 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~45 ~578 ~131 ~45 ~578 minecraft:redstone_wire replace
setblock ~130 ~45 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~45 ~582 ~155 ~45 ~582 minecraft:redstone_wire replace
setblock ~154 ~45 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~45 ~586 ~182 ~45 ~586 minecraft:redstone_wire replace
setblock ~181 ~45 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~45 ~590 ~206 ~45 ~590 minecraft:redstone_wire replace
setblock ~205 ~45 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~45 ~594 ~242 ~45 ~594 minecraft:redstone_wire replace
setblock ~243 ~45 ~594 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~45 ~594 ~245 ~45 ~594 minecraft:redstone_wire replace
setblock ~244 ~45 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~45 ~598 ~263 ~45 ~598 minecraft:redstone_wire replace
setblock ~262 ~45 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~45 ~602 ~326 ~45 ~602 minecraft:redstone_wire replace
setblock ~325 ~45 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~45 ~606 ~350 ~45 ~606 minecraft:redstone_wire replace
setblock ~349 ~45 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~45 ~610 ~104 ~45 ~610 minecraft:redstone_wire replace
setblock ~103 ~45 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~45 ~614 ~128 ~45 ~614 minecraft:redstone_wire replace
setblock ~127 ~45 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~45 ~618 ~152 ~45 ~618 minecraft:redstone_wire replace
setblock ~151 ~45 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~45 ~622 ~179 ~45 ~622 minecraft:redstone_wire replace
setblock ~178 ~45 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~45 ~626 ~203 ~45 ~626 minecraft:redstone_wire replace
setblock ~202 ~45 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~45 ~630 ~227 ~45 ~630 minecraft:redstone_wire replace
setblock ~228 ~45 ~630 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~45 ~630 ~230 ~45 ~630 minecraft:redstone_wire replace
setblock ~229 ~45 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~45 ~634 ~269 ~45 ~634 minecraft:redstone_wire replace
setblock ~268 ~45 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~279 ~45 ~638 ~281 ~45 ~638 minecraft:redstone_wire replace
setblock ~280 ~45 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~45 ~642 ~341 ~45 ~642 minecraft:redstone_wire replace
setblock ~340 ~45 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~45 ~646 ~161 ~45 ~646 minecraft:redstone_wire replace
setblock ~160 ~45 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~366 ~45 ~650 ~368 ~45 ~650 minecraft:redstone_wire replace
setblock ~367 ~45 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~45 ~654 ~101 ~45 ~654 minecraft:redstone_wire replace
setblock ~100 ~45 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~45 ~658 ~344 ~45 ~658 minecraft:redstone_wire replace
setblock ~343 ~45 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~363 ~45 ~662 ~365 ~45 ~662 minecraft:redstone_wire replace
setblock ~364 ~45 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~46 ~40 minecraft:redstone_wire replace
setblock ~286 ~46 ~44 minecraft:redstone_wire replace
setblock ~235 ~46 ~48 minecraft:redstone_wire replace
setblock ~304 ~46 ~52 minecraft:redstone_wire replace
setblock ~289 ~46 ~56 minecraft:redstone_wire replace
setblock ~292 ~46 ~64 minecraft:redstone_wire replace
setblock ~319 ~46 ~80 minecraft:redstone_wire replace
setblock ~94 ~46 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~46 ~252 minecraft:redstone_wire replace
setblock ~121 ~46 ~272 minecraft:redstone_wire replace
setblock ~124 ~46 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~46 ~280 minecraft:redstone_wire replace
setblock ~97 ~46 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~46 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~46 ~284 minecraft:redstone_wire replace
setblock ~145 ~46 ~288 minecraft:redstone_wire replace
setblock ~148 ~46 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~46 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~46 ~300 minecraft:redstone_wire replace
setblock ~166 ~46 ~304 minecraft:redstone_wire replace
setblock ~169 ~46 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~46 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~46 ~316 minecraft:redstone_wire replace
setblock ~184 ~46 ~324 minecraft:redstone_wire replace
setblock ~187 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~46 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~46 ~328 minecraft:redstone_wire replace
setblock ~211 ~46 ~332 minecraft:redstone_wire replace
setblock ~208 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~46 ~344 minecraft:redstone_wire replace
setblock ~238 ~46 ~348 minecraft:redstone_wire replace
setblock ~232 ~46 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~46 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~46 ~360 minecraft:redstone_wire replace
setblock ~283 ~46 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~46 ~368 minecraft:redstone_wire replace
setblock ~310 ~46 ~372 minecraft:redstone_wire replace
setblock ~283 ~46 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~46 ~380 minecraft:redstone_wire replace
setblock ~259 ~46 ~388 minecraft:redstone_wire replace
setblock ~334 ~46 ~392 minecraft:redstone_wire replace
setblock ~355 ~46 ~396 minecraft:redstone_wire replace
setblock ~322 ~46 ~400 minecraft:redstone_wire replace
setblock ~346 ~46 ~404 minecraft:redstone_wire replace
setblock ~316 ~46 ~408 minecraft:redstone_wire replace
setblock ~91 ~46 ~416 minecraft:redstone_wire replace
setblock ~118 ~46 ~420 minecraft:redstone_wire replace
setblock ~142 ~46 ~424 minecraft:redstone_wire replace
setblock ~175 ~46 ~428 minecraft:redstone_wire replace
setblock ~199 ~46 ~432 minecraft:redstone_wire replace
setblock ~226 ~46 ~436 minecraft:redstone_wire replace
setblock ~256 ~46 ~440 minecraft:redstone_wire replace
setblock ~277 ~46 ~444 minecraft:redstone_wire replace
setblock ~313 ~46 ~448 minecraft:redstone_wire replace
setblock ~88 ~46 ~452 minecraft:redstone_wire replace
setblock ~115 ~46 ~456 minecraft:redstone_wire replace
setblock ~139 ~46 ~460 minecraft:redstone_wire replace
setblock ~172 ~46 ~464 minecraft:redstone_wire replace
setblock ~196 ~46 ~468 minecraft:redstone_wire replace
setblock ~223 ~46 ~472 minecraft:redstone_wire replace
setblock ~253 ~46 ~476 minecraft:redstone_wire replace
setblock ~274 ~46 ~480 minecraft:redstone_wire replace
setblock ~337 ~46 ~484 minecraft:redstone_wire replace
setblock ~361 ~46 ~488 minecraft:redstone_wire replace
setblock ~85 ~46 ~492 minecraft:redstone_wire replace
setblock ~112 ~46 ~496 minecraft:redstone_wire replace
setblock ~136 ~46 ~500 minecraft:redstone_wire replace
setblock ~163 ~46 ~504 minecraft:redstone_wire replace
setblock ~193 ~46 ~508 minecraft:redstone_wire replace
setblock ~220 ~46 ~512 minecraft:redstone_wire replace
setblock ~250 ~46 ~516 minecraft:redstone_wire replace
setblock ~271 ~46 ~520 minecraft:redstone_wire replace
setblock ~331 ~46 ~524 minecraft:redstone_wire replace
setblock ~358 ~46 ~528 minecraft:redstone_wire replace
setblock ~82 ~46 ~532 minecraft:redstone_wire replace
setblock ~109 ~46 ~536 minecraft:redstone_wire replace
setblock ~133 ~46 ~540 minecraft:redstone_wire replace
setblock ~157 ~46 ~544 minecraft:redstone_wire replace
setblock ~190 ~46 ~548 minecraft:redstone_wire replace
setblock ~217 ~46 ~552 minecraft:redstone_wire replace
setblock ~247 ~46 ~556 minecraft:redstone_wire replace
setblock ~265 ~46 ~560 minecraft:redstone_wire replace
setblock ~328 ~46 ~564 minecraft:redstone_wire replace
setblock ~352 ~46 ~568 minecraft:redstone_wire replace
setblock ~79 ~46 ~572 minecraft:redstone_wire replace
setblock ~106 ~46 ~576 minecraft:redstone_wire replace
setblock ~130 ~46 ~580 minecraft:redstone_wire replace
setblock ~154 ~46 ~584 minecraft:redstone_wire replace
setblock ~181 ~46 ~588 minecraft:redstone_wire replace
setblock ~205 ~46 ~592 minecraft:redstone_wire replace
setblock ~244 ~46 ~596 minecraft:redstone_wire replace
setblock ~262 ~46 ~600 minecraft:redstone_wire replace
setblock ~325 ~46 ~604 minecraft:redstone_wire replace
setblock ~349 ~46 ~608 minecraft:redstone_wire replace
setblock ~103 ~46 ~612 minecraft:redstone_wire replace
setblock ~127 ~46 ~616 minecraft:redstone_wire replace
setblock ~151 ~46 ~620 minecraft:redstone_wire replace
setblock ~178 ~46 ~624 minecraft:redstone_wire replace
setblock ~202 ~46 ~628 minecraft:redstone_wire replace
setblock ~229 ~46 ~632 minecraft:redstone_wire replace
setblock ~268 ~46 ~636 minecraft:redstone_wire replace
setblock ~280 ~46 ~640 minecraft:redstone_wire replace
setblock ~340 ~46 ~644 minecraft:redstone_wire replace
setblock ~160 ~46 ~648 minecraft:redstone_wire replace
setblock ~367 ~46 ~652 minecraft:redstone_wire replace
setblock ~100 ~46 ~656 minecraft:redstone_wire replace
setblock ~343 ~46 ~660 minecraft:redstone_wire replace
setblock ~364 ~46 ~664 minecraft:redstone_wire replace
fill ~300 ~47 ~36 ~300 ~47 ~40 minecraft:redstone_wire replace
fill ~285 ~47 ~40 ~285 ~47 ~44 minecraft:redstone_wire replace
fill ~234 ~47 ~44 ~234 ~47 ~48 minecraft:redstone_wire replace
fill ~303 ~47 ~48 ~303 ~47 ~52 minecraft:redstone_wire replace
fill ~288 ~47 ~52 ~288 ~47 ~56 minecraft:redstone_wire replace
fill ~291 ~47 ~60 ~291 ~47 ~64 minecraft:redstone_wire replace
fill ~318 ~47 ~76 ~318 ~47 ~80 minecraft:redstone_wire replace
fill ~96 ~47 ~244 ~96 ~47 ~250 minecraft:redstone_wire replace
fill ~93 ~47 ~248 ~93 ~47 ~250 minecraft:redstone_wire replace
setblock ~93 ~47 ~251 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~47 ~251 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~47 ~252 ~93 ~47 ~264 minecraft:redstone_wire replace
fill ~96 ~47 ~252 ~96 ~47 ~264 minecraft:redstone_wire replace
fill ~123 ~47 ~264 ~123 ~47 ~270 minecraft:redstone_wire replace
setblock ~93 ~47 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~47 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~47 ~268 ~93 ~47 ~280 minecraft:redstone_wire replace
fill ~96 ~47 ~268 ~96 ~47 ~280 minecraft:redstone_wire replace
fill ~120 ~47 ~268 ~120 ~47 ~270 minecraft:redstone_wire replace
setblock ~120 ~47 ~271 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~47 ~271 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~47 ~272 ~120 ~47 ~284 minecraft:redstone_wire replace
fill ~123 ~47 ~272 ~123 ~47 ~284 minecraft:redstone_wire replace
fill ~147 ~47 ~280 ~147 ~47 ~286 minecraft:redstone_wire replace
fill ~144 ~47 ~284 ~144 ~47 ~286 minecraft:redstone_wire replace
setblock ~144 ~47 ~287 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~47 ~287 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~47 ~288 ~144 ~47 ~300 minecraft:redstone_wire replace
fill ~147 ~47 ~288 ~147 ~47 ~300 minecraft:redstone_wire replace
setblock ~168 ~47 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~47 ~294 ~168 ~47 ~302 minecraft:redstone_wire replace
fill ~165 ~47 ~296 ~165 ~47 ~302 minecraft:redstone_wire replace
fill ~297 ~47 ~300 ~297 ~47 ~306 minecraft:redstone_wire replace
setblock ~165 ~47 ~303 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~47 ~303 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~47 ~304 ~165 ~47 ~316 minecraft:redstone_wire replace
fill ~168 ~47 ~304 ~168 ~47 ~316 minecraft:redstone_wire replace
setblock ~282 ~47 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~306 ~282 ~47 ~314 minecraft:redstone_wire replace
setblock ~231 ~47 ~308 minecraft:redstone_wire replace
setblock ~297 ~47 ~308 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~47 ~309 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~47 ~310 ~231 ~47 ~322 minecraft:redstone_wire replace
fill ~297 ~47 ~310 ~297 ~47 ~322 minecraft:redstone_wire replace
setblock ~207 ~47 ~312 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~47 ~314 ~207 ~47 ~322 minecraft:redstone_wire replace
setblock ~186 ~47 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~282 ~47 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~47 ~318 ~186 ~47 ~328 minecraft:redstone_wire replace
fill ~282 ~47 ~318 ~282 ~47 ~330 minecraft:redstone_wire replace
setblock ~183 ~47 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~47 ~322 ~183 ~47 ~328 minecraft:redstone_wire replace
setblock ~207 ~47 ~323 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~47 ~323 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~297 ~47 ~323 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~47 ~324 ~207 ~47 ~336 minecraft:redstone_wire replace
fill ~231 ~47 ~324 ~231 ~47 ~336 minecraft:redstone_wire replace
fill ~297 ~47 ~324 ~297 ~47 ~336 minecraft:redstone_wire replace
fill ~210 ~47 ~328 ~210 ~47 ~332 minecraft:redstone_wire replace
setblock ~282 ~47 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~334 ~282 ~47 ~346 minecraft:redstone_wire replace
setblock ~297 ~47 ~337 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~47 ~338 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~47 ~338 ~297 ~47 ~350 minecraft:redstone_wire replace
fill ~213 ~47 ~340 ~213 ~47 ~344 minecraft:redstone_wire replace
fill ~231 ~47 ~340 ~231 ~47 ~352 minecraft:redstone_wire replace
fill ~237 ~47 ~344 ~237 ~47 ~348 minecraft:redstone_wire replace
setblock ~282 ~47 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~350 ~282 ~47 ~362 minecraft:redstone_wire replace
setblock ~297 ~47 ~351 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~47 ~352 ~297 ~47 ~364 minecraft:redstone_wire replace
fill ~240 ~47 ~356 ~240 ~47 ~360 minecraft:redstone_wire replace
setblock ~282 ~47 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~364 ~282 ~47 ~376 minecraft:redstone_wire replace
fill ~306 ~47 ~364 ~306 ~47 ~368 minecraft:redstone_wire replace
fill ~309 ~47 ~368 ~309 ~47 ~372 minecraft:redstone_wire replace
fill ~294 ~47 ~376 ~294 ~47 ~380 minecraft:redstone_wire replace
fill ~258 ~47 ~384 ~258 ~47 ~388 minecraft:redstone_wire replace
fill ~333 ~47 ~388 ~333 ~47 ~392 minecraft:redstone_wire replace
fill ~354 ~47 ~392 ~354 ~47 ~396 minecraft:redstone_wire replace
fill ~321 ~47 ~396 ~321 ~47 ~400 minecraft:redstone_wire replace
fill ~345 ~47 ~400 ~345 ~47 ~404 minecraft:redstone_wire replace
fill ~315 ~47 ~404 ~315 ~47 ~408 minecraft:redstone_wire replace
fill ~90 ~47 ~412 ~90 ~47 ~416 minecraft:redstone_wire replace
fill ~117 ~47 ~416 ~117 ~47 ~420 minecraft:redstone_wire replace
fill ~141 ~47 ~420 ~141 ~47 ~424 minecraft:redstone_wire replace
fill ~174 ~47 ~424 ~174 ~47 ~428 minecraft:redstone_wire replace
fill ~198 ~47 ~428 ~198 ~47 ~432 minecraft:redstone_wire replace
fill ~225 ~47 ~432 ~225 ~47 ~436 minecraft:redstone_wire replace
fill ~255 ~47 ~436 ~255 ~47 ~440 minecraft:redstone_wire replace
fill ~276 ~47 ~440 ~276 ~47 ~444 minecraft:redstone_wire replace
fill ~312 ~47 ~444 ~312 ~47 ~448 minecraft:redstone_wire replace
fill ~87 ~47 ~448 ~87 ~47 ~452 minecraft:redstone_wire replace
fill ~114 ~47 ~452 ~114 ~47 ~456 minecraft:redstone_wire replace
fill ~138 ~47 ~456 ~138 ~47 ~460 minecraft:redstone_wire replace
fill ~171 ~47 ~460 ~171 ~47 ~464 minecraft:redstone_wire replace
fill ~195 ~47 ~464 ~195 ~47 ~468 minecraft:redstone_wire replace
fill ~222 ~47 ~468 ~222 ~47 ~472 minecraft:redstone_wire replace
fill ~252 ~47 ~472 ~252 ~47 ~476 minecraft:redstone_wire replace
fill ~273 ~47 ~476 ~273 ~47 ~480 minecraft:redstone_wire replace
fill ~336 ~47 ~480 ~336 ~47 ~484 minecraft:redstone_wire replace
fill ~360 ~47 ~484 ~360 ~47 ~488 minecraft:redstone_wire replace
fill ~84 ~47 ~488 ~84 ~47 ~492 minecraft:redstone_wire replace
fill ~111 ~47 ~492 ~111 ~47 ~496 minecraft:redstone_wire replace
fill ~135 ~47 ~496 ~135 ~47 ~500 minecraft:redstone_wire replace
fill ~162 ~47 ~500 ~162 ~47 ~504 minecraft:redstone_wire replace
fill ~192 ~47 ~504 ~192 ~47 ~508 minecraft:redstone_wire replace
fill ~219 ~47 ~508 ~219 ~47 ~512 minecraft:redstone_wire replace
fill ~249 ~47 ~512 ~249 ~47 ~516 minecraft:redstone_wire replace
fill ~270 ~47 ~516 ~270 ~47 ~520 minecraft:redstone_wire replace
fill ~330 ~47 ~520 ~330 ~47 ~524 minecraft:redstone_wire replace
fill ~357 ~47 ~524 ~357 ~47 ~528 minecraft:redstone_wire replace
fill ~81 ~47 ~528 ~81 ~47 ~532 minecraft:redstone_wire replace
fill ~108 ~47 ~532 ~108 ~47 ~536 minecraft:redstone_wire replace
fill ~132 ~47 ~536 ~132 ~47 ~540 minecraft:redstone_wire replace
fill ~156 ~47 ~540 ~156 ~47 ~544 minecraft:redstone_wire replace
fill ~189 ~47 ~544 ~189 ~47 ~548 minecraft:redstone_wire replace
fill ~216 ~47 ~548 ~216 ~47 ~552 minecraft:redstone_wire replace
fill ~246 ~47 ~552 ~246 ~47 ~556 minecraft:redstone_wire replace
fill ~264 ~47 ~556 ~264 ~47 ~560 minecraft:redstone_wire replace
fill ~327 ~47 ~560 ~327 ~47 ~564 minecraft:redstone_wire replace
fill ~351 ~47 ~564 ~351 ~47 ~568 minecraft:redstone_wire replace
fill ~78 ~47 ~568 ~78 ~47 ~572 minecraft:redstone_wire replace
fill ~105 ~47 ~572 ~105 ~47 ~576 minecraft:redstone_wire replace
fill ~129 ~47 ~576 ~129 ~47 ~580 minecraft:redstone_wire replace
fill ~153 ~47 ~580 ~153 ~47 ~584 minecraft:redstone_wire replace
fill ~180 ~47 ~584 ~180 ~47 ~588 minecraft:redstone_wire replace
fill ~204 ~47 ~588 ~204 ~47 ~592 minecraft:redstone_wire replace
fill ~243 ~47 ~592 ~243 ~47 ~596 minecraft:redstone_wire replace
fill ~261 ~47 ~596 ~261 ~47 ~600 minecraft:redstone_wire replace
fill ~324 ~47 ~600 ~324 ~47 ~604 minecraft:redstone_wire replace
fill ~348 ~47 ~604 ~348 ~47 ~608 minecraft:redstone_wire replace
fill ~102 ~47 ~608 ~102 ~47 ~612 minecraft:redstone_wire replace
fill ~126 ~47 ~612 ~126 ~47 ~616 minecraft:redstone_wire replace
fill ~150 ~47 ~616 ~150 ~47 ~620 minecraft:redstone_wire replace
fill ~177 ~47 ~620 ~177 ~47 ~624 minecraft:redstone_wire replace
fill ~201 ~47 ~624 ~201 ~47 ~628 minecraft:redstone_wire replace
fill ~228 ~47 ~628 ~228 ~47 ~632 minecraft:redstone_wire replace
fill ~267 ~47 ~632 ~267 ~47 ~636 minecraft:redstone_wire replace
fill ~279 ~47 ~636 ~279 ~47 ~640 minecraft:redstone_wire replace
fill ~339 ~47 ~640 ~339 ~47 ~644 minecraft:redstone_wire replace
fill ~159 ~47 ~644 ~159 ~47 ~648 minecraft:redstone_wire replace
fill ~366 ~47 ~648 ~366 ~47 ~652 minecraft:redstone_wire replace
fill ~99 ~47 ~652 ~99 ~47 ~656 minecraft:redstone_wire replace
fill ~342 ~47 ~656 ~342 ~47 ~660 minecraft:redstone_wire replace
fill ~363 ~47 ~660 ~363 ~47 ~664 minecraft:redstone_wire replace
setblock ~300 ~48 ~35 minecraft:redstone_wire replace
setblock ~285 ~48 ~39 minecraft:redstone_wire replace
setblock ~234 ~48 ~43 minecraft:redstone_wire replace
setblock ~303 ~48 ~47 minecraft:redstone_wire replace
setblock ~288 ~48 ~51 minecraft:redstone_wire replace
setblock ~291 ~48 ~59 minecraft:redstone_wire replace
setblock ~318 ~48 ~75 minecraft:redstone_wire replace
setblock ~96 ~48 ~243 minecraft:redstone_wire replace
setblock ~93 ~48 ~247 minecraft:redstone_wire replace
setblock ~123 ~48 ~263 minecraft:redstone_wire replace
setblock ~120 ~48 ~267 minecraft:redstone_wire replace
setblock ~147 ~48 ~279 minecraft:redstone_wire replace
setblock ~144 ~48 ~283 minecraft:redstone_wire replace
setblock ~168 ~48 ~291 minecraft:redstone_wire replace
setblock ~165 ~48 ~295 minecraft:redstone_wire replace
setblock ~297 ~48 ~299 minecraft:redstone_wire replace
setblock ~282 ~48 ~303 minecraft:redstone_wire replace
setblock ~231 ~48 ~307 minecraft:redstone_wire replace
setblock ~207 ~48 ~311 minecraft:redstone_wire replace
setblock ~186 ~48 ~315 minecraft:redstone_wire replace
setblock ~183 ~48 ~319 minecraft:redstone_wire replace
setblock ~210 ~48 ~327 minecraft:redstone_wire replace
setblock ~213 ~48 ~339 minecraft:redstone_wire replace
setblock ~237 ~48 ~343 minecraft:redstone_wire replace
setblock ~240 ~48 ~355 minecraft:redstone_wire replace
setblock ~306 ~48 ~363 minecraft:redstone_wire replace
setblock ~309 ~48 ~367 minecraft:redstone_wire replace
setblock ~294 ~48 ~375 minecraft:redstone_wire replace
setblock ~258 ~48 ~383 minecraft:redstone_wire replace
setblock ~333 ~48 ~387 minecraft:redstone_wire replace
setblock ~354 ~48 ~391 minecraft:redstone_wire replace
setblock ~321 ~48 ~395 minecraft:redstone_wire replace
setblock ~345 ~48 ~399 minecraft:redstone_wire replace
setblock ~315 ~48 ~403 minecraft:redstone_wire replace
setblock ~90 ~48 ~411 minecraft:redstone_wire replace
setblock ~117 ~48 ~415 minecraft:redstone_wire replace
setblock ~141 ~48 ~419 minecraft:redstone_wire replace
setblock ~174 ~48 ~423 minecraft:redstone_wire replace
setblock ~198 ~48 ~427 minecraft:redstone_wire replace
setblock ~225 ~48 ~431 minecraft:redstone_wire replace
setblock ~255 ~48 ~435 minecraft:redstone_wire replace
setblock ~276 ~48 ~439 minecraft:redstone_wire replace
setblock ~312 ~48 ~443 minecraft:redstone_wire replace
setblock ~87 ~48 ~447 minecraft:redstone_wire replace
setblock ~114 ~48 ~451 minecraft:redstone_wire replace
setblock ~138 ~48 ~455 minecraft:redstone_wire replace
setblock ~171 ~48 ~459 minecraft:redstone_wire replace
setblock ~195 ~48 ~463 minecraft:redstone_wire replace
setblock ~222 ~48 ~467 minecraft:redstone_wire replace
setblock ~252 ~48 ~471 minecraft:redstone_wire replace
setblock ~273 ~48 ~475 minecraft:redstone_wire replace
setblock ~336 ~48 ~479 minecraft:redstone_wire replace
setblock ~360 ~48 ~483 minecraft:redstone_wire replace
setblock ~84 ~48 ~487 minecraft:redstone_wire replace
setblock ~111 ~48 ~491 minecraft:redstone_wire replace
setblock ~135 ~48 ~495 minecraft:redstone_wire replace
setblock ~162 ~48 ~499 minecraft:redstone_wire replace
setblock ~192 ~48 ~503 minecraft:redstone_wire replace
setblock ~219 ~48 ~507 minecraft:redstone_wire replace
setblock ~249 ~48 ~511 minecraft:redstone_wire replace
setblock ~270 ~48 ~515 minecraft:redstone_wire replace
setblock ~330 ~48 ~519 minecraft:redstone_wire replace
setblock ~357 ~48 ~523 minecraft:redstone_wire replace
setblock ~81 ~48 ~527 minecraft:redstone_wire replace
setblock ~108 ~48 ~531 minecraft:redstone_wire replace
setblock ~132 ~48 ~535 minecraft:redstone_wire replace
setblock ~156 ~48 ~539 minecraft:redstone_wire replace
setblock ~189 ~48 ~543 minecraft:redstone_wire replace
setblock ~216 ~48 ~547 minecraft:redstone_wire replace
setblock ~246 ~48 ~551 minecraft:redstone_wire replace
setblock ~264 ~48 ~555 minecraft:redstone_wire replace
setblock ~327 ~48 ~559 minecraft:redstone_wire replace
setblock ~351 ~48 ~563 minecraft:redstone_wire replace
setblock ~78 ~48 ~567 minecraft:redstone_wire replace
setblock ~105 ~48 ~571 minecraft:redstone_wire replace
setblock ~129 ~48 ~575 minecraft:redstone_wire replace
setblock ~153 ~48 ~579 minecraft:redstone_wire replace
setblock ~180 ~48 ~583 minecraft:redstone_wire replace
setblock ~204 ~48 ~587 minecraft:redstone_wire replace
setblock ~243 ~48 ~591 minecraft:redstone_wire replace
setblock ~261 ~48 ~595 minecraft:redstone_wire replace
setblock ~324 ~48 ~599 minecraft:redstone_wire replace
setblock ~348 ~48 ~603 minecraft:redstone_wire replace
setblock ~102 ~48 ~607 minecraft:redstone_wire replace
setblock ~126 ~48 ~611 minecraft:redstone_wire replace
setblock ~150 ~48 ~615 minecraft:redstone_wire replace
setblock ~177 ~48 ~619 minecraft:redstone_wire replace
setblock ~201 ~48 ~623 minecraft:redstone_wire replace
setblock ~228 ~48 ~627 minecraft:redstone_wire replace
setblock ~267 ~48 ~631 minecraft:redstone_wire replace
setblock ~279 ~48 ~635 minecraft:redstone_wire replace
setblock ~339 ~48 ~639 minecraft:redstone_wire replace
setblock ~159 ~48 ~643 minecraft:redstone_wire replace
setblock ~366 ~48 ~647 minecraft:redstone_wire replace
setblock ~99 ~48 ~651 minecraft:redstone_wire replace
setblock ~342 ~48 ~655 minecraft:redstone_wire replace
setblock ~363 ~48 ~659 minecraft:redstone_wire replace
setblock ~262 ~49 ~33 minecraft:redstone_wire replace
fill ~261 ~49 ~34 ~273 ~49 ~34 minecraft:redstone_wire replace
setblock ~275 ~49 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~49 ~34 ~290 ~49 ~34 minecraft:redstone_wire replace
setblock ~292 ~49 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~49 ~34 ~300 ~49 ~34 minecraft:redstone_wire replace
setblock ~259 ~49 ~37 minecraft:redstone_wire replace
fill ~258 ~49 ~38 ~260 ~49 ~38 minecraft:redstone_wire replace
setblock ~261 ~49 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~49 ~38 ~275 ~49 ~38 minecraft:redstone_wire replace
setblock ~277 ~49 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~49 ~38 ~285 ~49 ~38 minecraft:redstone_wire replace
setblock ~214 ~49 ~41 minecraft:redstone_wire replace
fill ~213 ~49 ~42 ~224 ~49 ~42 minecraft:redstone_wire replace
setblock ~226 ~49 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~49 ~42 ~234 ~49 ~42 minecraft:redstone_wire replace
setblock ~262 ~49 ~45 minecraft:redstone_wire replace
fill ~261 ~49 ~46 ~262 ~49 ~46 minecraft:redstone_wire replace
setblock ~264 ~49 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~49 ~46 ~278 ~49 ~46 minecraft:redstone_wire replace
setblock ~280 ~49 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~49 ~46 ~294 ~49 ~46 minecraft:redstone_wire replace
