fill ~150 ~135 ~548 ~150 ~135 ~560 minecraft:redstone_wire replace
setblock ~129 ~135 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~135 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~550 ~129 ~135 ~562 minecraft:redstone_wire replace
fill ~135 ~135 ~550 ~135 ~135 ~562 minecraft:redstone_wire replace
fill ~144 ~135 ~550 ~144 ~135 ~562 minecraft:redstone_wire replace
setblock ~126 ~135 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~135 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~135 ~554 ~126 ~135 ~566 minecraft:redstone_wire replace
fill ~132 ~135 ~554 ~132 ~135 ~566 minecraft:redstone_wire replace
setblock ~141 ~135 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~135 ~556 ~141 ~135 ~568 minecraft:redstone_wire replace
setblock ~153 ~135 ~560 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~135 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~135 ~562 ~153 ~135 ~568 minecraft:redstone_wire replace
setblock ~129 ~135 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~135 ~564 ~138 ~135 ~576 minecraft:redstone_wire replace
setblock ~144 ~135 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~135 ~564 minecraft:redstone_wire replace
fill ~150 ~135 ~564 ~150 ~135 ~576 minecraft:redstone_wire replace
setblock ~147 ~135 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~566 ~129 ~135 ~578 minecraft:redstone_wire replace
fill ~135 ~135 ~566 ~135 ~135 ~578 minecraft:redstone_wire replace
fill ~144 ~135 ~566 ~144 ~135 ~578 minecraft:redstone_wire replace
fill ~147 ~135 ~566 ~147 ~135 ~578 minecraft:redstone_wire replace
setblock ~126 ~135 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~135 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~135 ~568 ~126 ~135 ~580 minecraft:redstone_wire replace
fill ~132 ~135 ~568 ~132 ~135 ~580 minecraft:redstone_wire replace
fill ~156 ~135 ~576 ~156 ~135 ~578 minecraft:redstone_wire replace
setblock ~138 ~135 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~580 ~129 ~135 ~592 minecraft:redstone_wire replace
fill ~135 ~135 ~580 ~135 ~135 ~592 minecraft:redstone_wire replace
fill ~138 ~135 ~580 ~138 ~135 ~592 minecraft:redstone_wire replace
fill ~144 ~135 ~580 ~144 ~135 ~592 minecraft:redstone_wire replace
fill ~147 ~135 ~580 ~147 ~135 ~592 minecraft:redstone_wire replace
fill ~150 ~135 ~580 ~150 ~135 ~592 minecraft:redstone_wire replace
fill ~156 ~135 ~580 ~156 ~135 ~592 minecraft:redstone_wire replace
setblock ~129 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~596 ~129 ~135 ~608 minecraft:redstone_wire replace
fill ~135 ~135 ~596 ~135 ~135 ~608 minecraft:redstone_wire replace
fill ~138 ~135 ~596 ~138 ~135 ~608 minecraft:redstone_wire replace
fill ~144 ~135 ~596 ~144 ~135 ~608 minecraft:redstone_wire replace
fill ~147 ~135 ~596 ~147 ~135 ~608 minecraft:redstone_wire replace
fill ~150 ~135 ~596 ~150 ~135 ~608 minecraft:redstone_wire replace
fill ~156 ~135 ~596 ~156 ~135 ~608 minecraft:redstone_wire replace
fill ~162 ~135 ~608 ~162 ~135 ~612 minecraft:redstone_wire replace
fill ~159 ~135 ~620 ~159 ~135 ~624 minecraft:redstone_wire replace
fill ~171 ~135 ~644 ~171 ~135 ~648 minecraft:redstone_wire replace
fill ~84 ~135 ~648 ~84 ~135 ~652 minecraft:redstone_wire replace
fill ~165 ~135 ~652 ~165 ~135 ~656 minecraft:redstone_wire replace
fill ~168 ~135 ~660 ~168 ~135 ~664 minecraft:redstone_wire replace
setblock ~114 ~136 ~383 minecraft:redstone_wire replace
setblock ~81 ~136 ~395 minecraft:redstone_wire replace
setblock ~87 ~136 ~443 minecraft:redstone_wire replace
setblock ~78 ~136 ~447 minecraft:redstone_wire replace
setblock ~117 ~136 ~451 minecraft:redstone_wire replace
setblock ~108 ~136 ~455 minecraft:redstone_wire replace
setblock ~105 ~136 ~459 minecraft:redstone_wire replace
setblock ~102 ~136 ~463 minecraft:redstone_wire replace
setblock ~99 ~136 ~467 minecraft:redstone_wire replace
setblock ~96 ~136 ~471 minecraft:redstone_wire replace
setblock ~93 ~136 ~475 minecraft:redstone_wire replace
setblock ~90 ~136 ~479 minecraft:redstone_wire replace
setblock ~123 ~136 ~495 minecraft:redstone_wire replace
setblock ~111 ~136 ~499 minecraft:redstone_wire replace
setblock ~120 ~136 ~511 minecraft:redstone_wire replace
setblock ~150 ~136 ~515 minecraft:redstone_wire replace
setblock ~144 ~136 ~519 minecraft:redstone_wire replace
setblock ~141 ~136 ~523 minecraft:redstone_wire replace
setblock ~138 ~136 ~527 minecraft:redstone_wire replace
setblock ~135 ~136 ~531 minecraft:redstone_wire replace
setblock ~132 ~136 ~535 minecraft:redstone_wire replace
setblock ~129 ~136 ~539 minecraft:redstone_wire replace
setblock ~126 ~136 ~543 minecraft:redstone_wire replace
setblock ~153 ~136 ~559 minecraft:redstone_wire replace
setblock ~147 ~136 ~563 minecraft:redstone_wire replace
setblock ~156 ~136 ~575 minecraft:redstone_wire replace
setblock ~162 ~136 ~607 minecraft:redstone_wire replace
setblock ~159 ~136 ~619 minecraft:redstone_wire replace
setblock ~171 ~136 ~643 minecraft:redstone_wire replace
setblock ~84 ~136 ~647 minecraft:redstone_wire replace
setblock ~165 ~136 ~651 minecraft:redstone_wire replace
setblock ~168 ~136 ~659 minecraft:redstone_wire replace
setblock ~100 ~137 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~137 ~382 ~104 ~137 ~382 minecraft:redstone_wire replace
setblock ~106 ~137 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~137 ~382 ~114 ~137 ~382 minecraft:redstone_wire replace
setblock ~82 ~137 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~137 ~394 ~83 ~137 ~394 minecraft:redstone_wire replace
setblock ~88 ~137 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~137 ~442 ~89 ~137 ~442 minecraft:redstone_wire replace
setblock ~79 ~137 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~137 ~446 ~80 ~137 ~446 minecraft:redstone_wire replace
setblock ~103 ~137 ~449 minecraft:redstone_wire replace
fill ~102 ~137 ~450 ~103 ~137 ~450 minecraft:redstone_wire replace
setblock ~104 ~137 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~137 ~450 ~117 ~137 ~450 minecraft:redstone_wire replace
setblock ~97 ~137 ~453 minecraft:redstone_wire replace
fill ~96 ~137 ~454 ~97 ~137 ~454 minecraft:redstone_wire replace
setblock ~99 ~137 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~137 ~454 ~108 ~137 ~454 minecraft:redstone_wire replace
setblock ~97 ~137 ~457 minecraft:redstone_wire replace
fill ~96 ~137 ~458 ~105 ~137 ~458 minecraft:redstone_wire replace
setblock ~94 ~137 ~461 minecraft:redstone_wire replace
fill ~93 ~137 ~462 ~102 ~137 ~462 minecraft:redstone_wire replace
setblock ~94 ~137 ~465 minecraft:redstone_wire replace
fill ~93 ~137 ~466 ~99 ~137 ~466 minecraft:redstone_wire replace
setblock ~94 ~137 ~469 minecraft:redstone_wire replace
fill ~93 ~137 ~470 ~96 ~137 ~470 minecraft:redstone_wire replace
setblock ~91 ~137 ~473 minecraft:redstone_wire replace
fill ~90 ~137 ~474 ~93 ~137 ~474 minecraft:redstone_wire replace
setblock ~91 ~137 ~477 minecraft:redstone_wire replace
fill ~90 ~137 ~478 ~92 ~137 ~478 minecraft:redstone_wire replace
setblock ~103 ~137 ~493 minecraft:redstone_wire replace
fill ~102 ~137 ~494 ~107 ~137 ~494 minecraft:redstone_wire replace
setblock ~109 ~137 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~137 ~494 ~123 ~137 ~494 minecraft:redstone_wire replace
setblock ~97 ~137 ~497 minecraft:redstone_wire replace
fill ~96 ~137 ~498 ~97 ~137 ~498 minecraft:redstone_wire replace
setblock ~98 ~137 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~137 ~498 ~111 ~137 ~498 minecraft:redstone_wire replace
setblock ~103 ~137 ~509 minecraft:redstone_wire replace
fill ~102 ~137 ~510 ~104 ~137 ~510 minecraft:redstone_wire replace
setblock ~106 ~137 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~137 ~510 ~120 ~137 ~510 minecraft:redstone_wire replace
setblock ~115 ~137 ~513 minecraft:redstone_wire replace
fill ~114 ~137 ~514 ~118 ~137 ~514 minecraft:redstone_wire replace
setblock ~120 ~137 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~137 ~514 ~135 ~137 ~514 minecraft:redstone_wire replace
setblock ~137 ~137 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~137 ~514 ~150 ~137 ~514 minecraft:redstone_wire replace
setblock ~112 ~137 ~517 minecraft:redstone_wire replace
fill ~111 ~137 ~518 ~113 ~137 ~518 minecraft:redstone_wire replace
setblock ~114 ~137 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~137 ~518 ~128 ~137 ~518 minecraft:redstone_wire replace
setblock ~130 ~137 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~137 ~518 ~144 ~137 ~518 minecraft:redstone_wire replace
setblock ~112 ~137 ~521 minecraft:redstone_wire replace
setblock ~111 ~137 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~137 ~522 ~125 ~137 ~522 minecraft:redstone_wire replace
setblock ~127 ~137 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~137 ~522 ~141 ~137 ~522 minecraft:redstone_wire replace
setblock ~109 ~137 ~525 minecraft:redstone_wire replace
fill ~108 ~137 ~526 ~110 ~137 ~526 minecraft:redstone_wire replace
setblock ~111 ~137 ~526 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~137 ~526 ~125 ~137 ~526 minecraft:redstone_wire replace
setblock ~127 ~137 ~526 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~137 ~526 ~138 ~137 ~526 minecraft:redstone_wire replace
setblock ~109 ~137 ~529 minecraft:redstone_wire replace
fill ~108 ~137 ~530 ~120 ~137 ~530 minecraft:redstone_wire replace
setblock ~122 ~137 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~137 ~530 ~135 ~137 ~530 minecraft:redstone_wire replace
setblock ~109 ~137 ~533 minecraft:redstone_wire replace
fill ~108 ~137 ~534 ~117 ~137 ~534 minecraft:redstone_wire replace
setblock ~119 ~137 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~137 ~534 ~132 ~137 ~534 minecraft:redstone_wire replace
setblock ~106 ~137 ~537 minecraft:redstone_wire replace
fill ~105 ~137 ~538 ~113 ~137 ~538 minecraft:redstone_wire replace
setblock ~115 ~137 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~137 ~538 ~129 ~137 ~538 minecraft:redstone_wire replace
setblock ~106 ~137 ~541 minecraft:redstone_wire replace
fill ~105 ~137 ~542 ~117 ~137 ~542 minecraft:redstone_wire replace
setblock ~119 ~137 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~137 ~542 ~126 ~137 ~542 minecraft:redstone_wire replace
setblock ~115 ~137 ~557 minecraft:redstone_wire replace
fill ~114 ~137 ~558 ~120 ~137 ~558 minecraft:redstone_wire replace
setblock ~122 ~137 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~137 ~558 ~137 ~137 ~558 minecraft:redstone_wire replace
setblock ~139 ~137 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~137 ~558 ~153 ~137 ~558 minecraft:redstone_wire replace
setblock ~112 ~137 ~561 minecraft:redstone_wire replace
fill ~111 ~137 ~562 ~115 ~137 ~562 minecraft:redstone_wire replace
setblock ~117 ~137 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~137 ~562 ~132 ~137 ~562 minecraft:redstone_wire replace
setblock ~134 ~137 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~137 ~562 ~147 ~137 ~562 minecraft:redstone_wire replace
setblock ~115 ~137 ~573 minecraft:redstone_wire replace
fill ~114 ~137 ~574 ~126 ~137 ~574 minecraft:redstone_wire replace
setblock ~128 ~137 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~137 ~574 ~143 ~137 ~574 minecraft:redstone_wire replace
setblock ~145 ~137 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~137 ~574 ~156 ~137 ~574 minecraft:redstone_wire replace
setblock ~121 ~137 ~605 minecraft:redstone_wire replace
fill ~120 ~137 ~606 ~121 ~137 ~606 minecraft:redstone_wire replace
setblock ~123 ~137 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~137 ~606 ~137 ~137 ~606 minecraft:redstone_wire replace
setblock ~139 ~137 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~137 ~606 ~153 ~137 ~606 minecraft:redstone_wire replace
setblock ~155 ~137 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~137 ~606 ~162 ~137 ~606 minecraft:redstone_wire replace
setblock ~118 ~137 ~617 minecraft:redstone_wire replace
fill ~117 ~137 ~618 ~118 ~137 ~618 minecraft:redstone_wire replace
setblock ~120 ~137 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~137 ~618 ~134 ~137 ~618 minecraft:redstone_wire replace
setblock ~136 ~137 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~137 ~618 ~150 ~137 ~618 minecraft:redstone_wire replace
setblock ~152 ~137 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~137 ~618 ~159 ~137 ~618 minecraft:redstone_wire replace
setblock ~130 ~137 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~137 ~642 ~130 ~137 ~642 minecraft:redstone_wire replace
setblock ~132 ~137 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~137 ~642 ~146 ~137 ~642 minecraft:redstone_wire replace
setblock ~148 ~137 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~137 ~642 ~162 ~137 ~642 minecraft:redstone_wire replace
setblock ~164 ~137 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~137 ~642 ~171 ~137 ~642 minecraft:redstone_wire replace
setblock ~85 ~137 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~137 ~646 ~86 ~137 ~646 minecraft:redstone_wire replace
setblock ~124 ~137 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~137 ~650 ~124 ~137 ~650 minecraft:redstone_wire replace
setblock ~126 ~137 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~137 ~650 ~140 ~137 ~650 minecraft:redstone_wire replace
setblock ~142 ~137 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~137 ~650 ~156 ~137 ~650 minecraft:redstone_wire replace
setblock ~158 ~137 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~137 ~650 ~165 ~137 ~650 minecraft:redstone_wire replace
setblock ~127 ~137 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~137 ~658 ~127 ~137 ~658 minecraft:redstone_wire replace
setblock ~129 ~137 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~137 ~658 ~143 ~137 ~658 minecraft:redstone_wire replace
setblock ~145 ~137 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~137 ~658 ~159 ~137 ~658 minecraft:redstone_wire replace
setblock ~161 ~137 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~137 ~658 ~168 ~137 ~658 minecraft:redstone_wire replace
setblock ~100 ~138 ~380 minecraft:redstone_wire replace
setblock ~82 ~138 ~392 minecraft:redstone_wire replace
setblock ~88 ~138 ~440 minecraft:redstone_wire replace
setblock ~79 ~138 ~444 minecraft:redstone_wire replace
setblock ~103 ~138 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~138 ~452 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~138 ~456 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~138 ~460 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~138 ~464 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~138 ~468 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~138 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~138 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~138 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~138 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~138 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~138 ~512 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~138 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~138 ~520 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~138 ~524 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~138 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~138 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~138 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~138 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~138 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~138 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~138 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~138 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~138 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~138 ~640 minecraft:redstone_wire replace
setblock ~85 ~138 ~644 minecraft:redstone_wire replace
setblock ~124 ~138 ~648 minecraft:redstone_wire replace
setblock ~127 ~138 ~656 minecraft:redstone_wire replace
fill ~99 ~139 ~380 ~99 ~139 ~384 minecraft:redstone_wire replace
fill ~81 ~139 ~392 ~81 ~139 ~396 minecraft:redstone_wire replace
fill ~87 ~139 ~440 ~87 ~139 ~444 minecraft:redstone_wire replace
fill ~78 ~139 ~444 ~78 ~139 ~448 minecraft:redstone_wire replace
fill ~102 ~139 ~448 ~102 ~139 ~460 minecraft:redstone_wire replace
fill ~96 ~139 ~452 ~96 ~139 ~464 minecraft:redstone_wire replace
fill ~93 ~139 ~460 ~93 ~139 ~470 minecraft:redstone_wire replace
setblock ~102 ~139 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~464 ~102 ~139 ~476 minecraft:redstone_wire replace
setblock ~96 ~139 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~139 ~468 ~96 ~139 ~480 minecraft:redstone_wire replace
fill ~90 ~139 ~472 ~90 ~139 ~478 minecraft:redstone_wire replace
setblock ~93 ~139 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~139 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~139 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~480 ~102 ~139 ~492 minecraft:redstone_wire replace
setblock ~96 ~139 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~139 ~484 ~96 ~139 ~496 minecraft:redstone_wire replace
setblock ~102 ~139 ~493 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~494 ~102 ~139 ~506 minecraft:redstone_wire replace
setblock ~96 ~139 ~497 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~139 ~498 ~96 ~139 ~500 minecraft:redstone_wire replace
setblock ~102 ~139 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~508 ~102 ~139 ~512 minecraft:redstone_wire replace
fill ~114 ~139 ~512 ~114 ~139 ~524 minecraft:redstone_wire replace
fill ~111 ~139 ~516 ~111 ~139 ~528 minecraft:redstone_wire replace
fill ~108 ~139 ~524 ~108 ~139 ~534 minecraft:redstone_wire replace
setblock ~114 ~139 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~528 ~114 ~139 ~540 minecraft:redstone_wire replace
setblock ~111 ~139 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~139 ~532 ~111 ~139 ~544 minecraft:redstone_wire replace
fill ~105 ~139 ~536 ~105 ~139 ~542 minecraft:redstone_wire replace
setblock ~108 ~139 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~139 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~139 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~544 ~114 ~139 ~556 minecraft:redstone_wire replace
setblock ~111 ~139 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~139 ~548 ~111 ~139 ~560 minecraft:redstone_wire replace
setblock ~114 ~139 ~557 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~558 ~114 ~139 ~570 minecraft:redstone_wire replace
setblock ~111 ~139 ~561 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~139 ~562 ~111 ~139 ~564 minecraft:redstone_wire replace
setblock ~114 ~139 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~572 ~114 ~139 ~576 minecraft:redstone_wire replace
fill ~120 ~139 ~604 ~120 ~139 ~608 minecraft:redstone_wire replace
fill ~117 ~139 ~616 ~117 ~139 ~620 minecraft:redstone_wire replace
fill ~129 ~139 ~640 ~129 ~139 ~644 minecraft:redstone_wire replace
fill ~84 ~139 ~644 ~84 ~139 ~648 minecraft:redstone_wire replace
fill ~123 ~139 ~648 ~123 ~139 ~652 minecraft:redstone_wire replace
fill ~126 ~139 ~656 ~126 ~139 ~660 minecraft:redstone_wire replace
setblock ~99 ~140 ~385 minecraft:redstone_wire replace
setblock ~81 ~140 ~397 minecraft:redstone_wire replace
setblock ~87 ~140 ~445 minecraft:redstone_wire replace
setblock ~78 ~140 ~449 minecraft:redstone_wire replace
setblock ~93 ~140 ~473 minecraft:redstone_wire replace
setblock ~90 ~140 ~481 minecraft:redstone_wire replace
setblock ~96 ~140 ~501 minecraft:redstone_wire replace
setblock ~102 ~140 ~513 minecraft:redstone_wire replace
setblock ~108 ~140 ~537 minecraft:redstone_wire replace
setblock ~105 ~140 ~545 minecraft:redstone_wire replace
setblock ~111 ~140 ~565 minecraft:redstone_wire replace
setblock ~114 ~140 ~577 minecraft:redstone_wire replace
setblock ~120 ~140 ~609 minecraft:redstone_wire replace
setblock ~117 ~140 ~621 minecraft:redstone_wire replace
setblock ~129 ~140 ~645 minecraft:redstone_wire replace
setblock ~84 ~140 ~649 minecraft:redstone_wire replace
setblock ~123 ~140 ~653 minecraft:redstone_wire replace
setblock ~126 ~140 ~661 minecraft:redstone_wire replace
fill ~99 ~141 ~386 ~105 ~141 ~386 minecraft:redstone_wire replace
setblock ~107 ~141 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~141 ~386 ~113 ~141 ~386 minecraft:redstone_wire replace
setblock ~112 ~141 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~141 ~398 ~83 ~141 ~398 minecraft:redstone_wire replace
setblock ~82 ~141 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~141 ~446 ~92 ~141 ~446 minecraft:redstone_wire replace
setblock ~93 ~141 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~141 ~446 ~106 ~141 ~446 minecraft:redstone_wire replace
setblock ~107 ~141 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~108 ~141 ~446 ~116 ~141 ~446 minecraft:redstone_wire replace
setblock ~88 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~141 ~447 minecraft:redstone_wire replace
setblock ~94 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~141 ~447 minecraft:redstone_wire replace
setblock ~100 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~141 ~447 minecraft:redstone_wire replace
setblock ~115 ~141 ~447 minecraft:redstone_wire replace
fill ~78 ~141 ~450 ~80 ~141 ~450 minecraft:redstone_wire replace
setblock ~79 ~141 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~141 ~474 ~104 ~141 ~474 minecraft:redstone_wire replace
setblock ~105 ~141 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~141 ~474 ~118 ~141 ~474 minecraft:redstone_wire replace
setblock ~119 ~141 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~141 ~474 ~122 ~141 ~474 minecraft:redstone_wire replace
setblock ~88 ~141 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~141 ~475 minecraft:redstone_wire replace
setblock ~97 ~141 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~141 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~141 ~475 minecraft:redstone_wire replace
setblock ~109 ~141 ~475 minecraft:redstone_wire replace
setblock ~121 ~141 ~475 minecraft:redstone_wire replace
fill ~87 ~141 ~482 ~101 ~141 ~482 minecraft:redstone_wire replace
setblock ~102 ~141 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~141 ~482 ~115 ~141 ~482 minecraft:redstone_wire replace
setblock ~116 ~141 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~117 ~141 ~482 ~119 ~141 ~482 minecraft:redstone_wire replace
setblock ~88 ~141 ~483 minecraft:redstone_wire replace
setblock ~91 ~141 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~141 ~483 minecraft:redstone_wire replace
setblock ~103 ~141 ~483 minecraft:redstone_wire replace
setblock ~109 ~141 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~141 ~483 minecraft:redstone_wire replace
fill ~90 ~141 ~502 ~104 ~141 ~502 minecraft:redstone_wire replace
setblock ~105 ~141 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~141 ~502 ~118 ~141 ~502 minecraft:redstone_wire replace
setblock ~119 ~141 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~141 ~502 ~122 ~141 ~502 minecraft:redstone_wire replace
setblock ~91 ~141 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~141 ~503 minecraft:redstone_wire replace
setblock ~100 ~141 ~503 minecraft:redstone_wire replace
setblock ~106 ~141 ~503 minecraft:redstone_wire replace
setblock ~109 ~141 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~141 ~503 minecraft:redstone_wire replace
setblock ~121 ~141 ~503 minecraft:redstone_wire replace
fill ~102 ~141 ~514 ~108 ~141 ~514 minecraft:redstone_wire replace
setblock ~110 ~141 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~141 ~514 ~125 ~141 ~514 minecraft:redstone_wire replace
setblock ~126 ~141 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~141 ~514 ~140 ~141 ~514 minecraft:redstone_wire replace
setblock ~141 ~141 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~141 ~514 ~149 ~141 ~514 minecraft:redstone_wire replace
setblock ~124 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~141 ~515 minecraft:redstone_wire replace
setblock ~130 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~141 ~515 minecraft:redstone_wire replace
setblock ~136 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~141 ~515 minecraft:redstone_wire replace
setblock ~148 ~141 ~515 minecraft:redstone_wire replace
fill ~108 ~141 ~538 ~120 ~141 ~538 minecraft:redstone_wire replace
setblock ~122 ~141 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~141 ~538 ~137 ~141 ~538 minecraft:redstone_wire replace
setblock ~139 ~141 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~141 ~538 ~154 ~141 ~538 minecraft:redstone_wire replace
setblock ~155 ~141 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~124 ~141 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~141 ~539 minecraft:redstone_wire replace
setblock ~133 ~141 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~141 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~141 ~539 minecraft:redstone_wire replace
setblock ~145 ~141 ~539 minecraft:redstone_wire replace
setblock ~154 ~141 ~539 minecraft:redstone_wire replace
fill ~105 ~141 ~546 ~117 ~141 ~546 minecraft:redstone_wire replace
setblock ~119 ~141 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~141 ~546 ~134 ~141 ~546 minecraft:redstone_wire replace
setblock ~136 ~141 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~138 ~141 ~546 ~151 ~141 ~546 minecraft:redstone_wire replace
setblock ~152 ~141 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~124 ~141 ~547 minecraft:redstone_wire replace
setblock ~127 ~141 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~141 ~547 minecraft:redstone_wire replace
setblock ~139 ~141 ~547 minecraft:redstone_wire replace
setblock ~145 ~141 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~141 ~547 minecraft:redstone_wire replace
fill ~111 ~141 ~566 ~120 ~141 ~566 minecraft:redstone_wire replace
setblock ~122 ~141 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~141 ~566 ~137 ~141 ~566 minecraft:redstone_wire replace
setblock ~139 ~141 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~141 ~566 ~154 ~141 ~566 minecraft:redstone_wire replace
setblock ~155 ~141 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~127 ~141 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~141 ~567 minecraft:redstone_wire replace
setblock ~136 ~141 ~567 minecraft:redstone_wire replace
setblock ~142 ~141 ~567 minecraft:redstone_wire replace
setblock ~145 ~141 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~141 ~567 minecraft:redstone_wire replace
setblock ~154 ~141 ~567 minecraft:redstone_wire replace
fill ~114 ~141 ~578 ~120 ~141 ~578 minecraft:redstone_wire replace
setblock ~122 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~141 ~578 ~137 ~141 ~578 minecraft:redstone_wire replace
setblock ~139 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~141 ~578 ~154 ~141 ~578 minecraft:redstone_wire replace
setblock ~155 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~141 ~578 ~169 ~141 ~578 minecraft:redstone_wire replace
setblock ~170 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~141 ~578 ~173 ~141 ~578 minecraft:redstone_wire replace
setblock ~157 ~141 ~579 minecraft:redstone_wire replace
setblock ~160 ~141 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~141 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~141 ~579 minecraft:redstone_wire replace
setblock ~172 ~141 ~579 minecraft:redstone_wire replace
fill ~120 ~141 ~610 ~126 ~141 ~610 minecraft:redstone_wire replace
setblock ~128 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~141 ~610 ~143 ~141 ~610 minecraft:redstone_wire replace
setblock ~145 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~141 ~610 ~160 ~141 ~610 minecraft:redstone_wire replace
setblock ~161 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~141 ~610 ~175 ~141 ~610 minecraft:redstone_wire replace
setblock ~176 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~160 ~141 ~611 minecraft:redstone_wire replace
setblock ~163 ~141 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~141 ~611 minecraft:redstone_wire replace
setblock ~169 ~141 ~611 minecraft:redstone_wire replace
setblock ~175 ~141 ~611 minecraft:redstone_wire replace
fill ~117 ~141 ~622 ~123 ~141 ~622 minecraft:redstone_wire replace
setblock ~125 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~141 ~622 ~140 ~141 ~622 minecraft:redstone_wire replace
setblock ~142 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~141 ~622 ~157 ~141 ~622 minecraft:redstone_wire replace
setblock ~158 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~141 ~622 ~172 ~141 ~622 minecraft:redstone_wire replace
setblock ~173 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~141 ~622 ~176 ~141 ~622 minecraft:redstone_wire replace
setblock ~157 ~141 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~141 ~623 minecraft:redstone_wire replace
setblock ~163 ~141 ~623 minecraft:redstone_wire replace
setblock ~166 ~141 ~623 minecraft:redstone_wire replace
setblock ~169 ~141 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~141 ~623 minecraft:redstone_wire replace
setblock ~175 ~141 ~623 minecraft:redstone_wire replace
fill ~129 ~141 ~646 ~135 ~141 ~646 minecraft:redstone_wire replace
setblock ~137 ~141 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~141 ~646 ~152 ~141 ~646 minecraft:redstone_wire replace
setblock ~154 ~141 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~141 ~646 ~169 ~141 ~646 minecraft:redstone_wire replace
setblock ~171 ~141 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~141 ~646 ~185 ~141 ~646 minecraft:redstone_wire replace
setblock ~184 ~141 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~141 ~650 ~86 ~141 ~650 minecraft:redstone_wire replace
setblock ~85 ~141 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~141 ~654 ~129 ~141 ~654 minecraft:redstone_wire replace
setblock ~131 ~141 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~141 ~654 ~146 ~141 ~654 minecraft:redstone_wire replace
setblock ~148 ~141 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~141 ~654 ~163 ~141 ~654 minecraft:redstone_wire replace
setblock ~165 ~141 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~167 ~141 ~654 ~179 ~141 ~654 minecraft:redstone_wire replace
setblock ~178 ~141 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~141 ~662 ~132 ~141 ~662 minecraft:redstone_wire replace
setblock ~134 ~141 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~141 ~662 ~149 ~141 ~662 minecraft:redstone_wire replace
setblock ~151 ~141 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~141 ~662 ~166 ~141 ~662 minecraft:redstone_wire replace
setblock ~168 ~141 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~170 ~141 ~662 ~182 ~141 ~662 minecraft:redstone_wire replace
setblock ~181 ~141 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~142 ~388 minecraft:redstone_wire replace
setblock ~82 ~142 ~400 minecraft:redstone_wire replace
setblock ~88 ~142 ~448 minecraft:redstone_wire replace
setblock ~91 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~142 ~448 minecraft:redstone_wire replace
setblock ~97 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~142 ~448 minecraft:redstone_wire replace
setblock ~103 ~142 ~448 minecraft:redstone_wire replace
setblock ~106 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~142 ~452 minecraft:redstone_wire replace
setblock ~88 ~142 ~476 minecraft:redstone_wire replace
setblock ~94 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~142 ~476 minecraft:redstone_wire replace
setblock ~100 ~142 ~476 minecraft:redstone_wire replace
setblock ~106 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~142 ~484 minecraft:redstone_wire replace
setblock ~97 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~142 ~484 minecraft:redstone_wire replace
setblock ~118 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~142 ~504 minecraft:redstone_wire replace
setblock ~94 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~142 ~504 minecraft:redstone_wire replace
setblock ~115 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~142 ~516 minecraft:redstone_wire replace
setblock ~127 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~142 ~516 minecraft:redstone_wire replace
setblock ~133 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~142 ~516 minecraft:redstone_wire replace
setblock ~139 ~142 ~516 minecraft:redstone_wire replace
setblock ~142 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~142 ~540 minecraft:redstone_wire replace
setblock ~130 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~142 ~540 minecraft:redstone_wire replace
setblock ~136 ~142 ~540 minecraft:redstone_wire replace
setblock ~142 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~142 ~548 minecraft:redstone_wire replace
setblock ~133 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~142 ~548 minecraft:redstone_wire replace
setblock ~151 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~142 ~568 minecraft:redstone_wire replace
setblock ~130 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~142 ~568 minecraft:redstone_wire replace
setblock ~148 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~142 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~142 ~580 minecraft:redstone_wire replace
setblock ~163 ~142 ~580 minecraft:redstone_wire replace
setblock ~166 ~142 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~142 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~142 ~612 minecraft:redstone_wire replace
setblock ~166 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~142 ~624 minecraft:redstone_wire replace
setblock ~160 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~142 ~624 minecraft:redstone_wire replace
setblock ~172 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~142 ~648 minecraft:redstone_wire replace
setblock ~85 ~142 ~652 minecraft:redstone_wire replace
setblock ~178 ~142 ~656 minecraft:redstone_wire replace
setblock ~181 ~142 ~664 minecraft:redstone_wire replace
fill ~111 ~143 ~384 ~111 ~143 ~388 minecraft:redstone_wire replace
fill ~81 ~143 ~396 ~81 ~143 ~400 minecraft:redstone_wire replace
