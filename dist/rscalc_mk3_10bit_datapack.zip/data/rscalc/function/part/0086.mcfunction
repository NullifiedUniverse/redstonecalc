setblock ~123 ~96 ~611 minecraft:redstone_wire replace
setblock ~117 ~96 ~615 minecraft:redstone_wire replace
setblock ~114 ~96 ~619 minecraft:redstone_wire replace
setblock ~111 ~96 ~623 minecraft:redstone_wire replace
setblock ~105 ~96 ~627 minecraft:redstone_wire replace
setblock ~126 ~96 ~631 minecraft:redstone_wire replace
setblock ~108 ~96 ~635 minecraft:redstone_wire replace
setblock ~135 ~96 ~643 minecraft:redstone_wire replace
setblock ~84 ~96 ~647 minecraft:redstone_wire replace
setblock ~129 ~96 ~651 minecraft:redstone_wire replace
setblock ~132 ~96 ~659 minecraft:redstone_wire replace
setblock ~115 ~97 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~97 ~382 ~120 ~97 ~382 minecraft:redstone_wire replace
setblock ~82 ~97 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~97 ~394 ~83 ~97 ~394 minecraft:redstone_wire replace
setblock ~88 ~97 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~97 ~582 ~89 ~97 ~582 minecraft:redstone_wire replace
setblock ~79 ~97 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~97 ~586 ~80 ~97 ~586 minecraft:redstone_wire replace
setblock ~91 ~97 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~97 ~590 ~92 ~97 ~590 minecraft:redstone_wire replace
setblock ~94 ~97 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~97 ~594 ~95 ~97 ~594 minecraft:redstone_wire replace
setblock ~97 ~97 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~97 ~598 ~98 ~97 ~598 minecraft:redstone_wire replace
setblock ~100 ~97 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~97 ~602 ~101 ~97 ~602 minecraft:redstone_wire replace
setblock ~103 ~97 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~97 ~606 ~104 ~97 ~606 minecraft:redstone_wire replace
setblock ~118 ~97 ~609 minecraft:redstone_wire replace
fill ~117 ~97 ~610 ~123 ~97 ~610 minecraft:redstone_wire replace
setblock ~112 ~97 ~613 minecraft:redstone_wire replace
fill ~111 ~97 ~614 ~117 ~97 ~614 minecraft:redstone_wire replace
setblock ~112 ~97 ~617 minecraft:redstone_wire replace
fill ~111 ~97 ~618 ~114 ~97 ~618 minecraft:redstone_wire replace
setblock ~109 ~97 ~621 minecraft:redstone_wire replace
fill ~108 ~97 ~622 ~111 ~97 ~622 minecraft:redstone_wire replace
setblock ~106 ~97 ~625 minecraft:redstone_wire replace
fill ~105 ~97 ~626 ~107 ~97 ~626 minecraft:redstone_wire replace
setblock ~118 ~97 ~629 minecraft:redstone_wire replace
fill ~117 ~97 ~630 ~126 ~97 ~630 minecraft:redstone_wire replace
setblock ~106 ~97 ~633 minecraft:redstone_wire replace
fill ~105 ~97 ~634 ~108 ~97 ~634 minecraft:redstone_wire replace
setblock ~127 ~97 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~97 ~642 ~127 ~97 ~642 minecraft:redstone_wire replace
setblock ~128 ~97 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~97 ~642 ~135 ~97 ~642 minecraft:redstone_wire replace
setblock ~85 ~97 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~97 ~646 ~86 ~97 ~646 minecraft:redstone_wire replace
setblock ~121 ~97 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~97 ~650 ~121 ~97 ~650 minecraft:redstone_wire replace
setblock ~122 ~97 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~97 ~650 ~129 ~97 ~650 minecraft:redstone_wire replace
setblock ~124 ~97 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~97 ~658 ~124 ~97 ~658 minecraft:redstone_wire replace
setblock ~125 ~97 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~97 ~658 ~132 ~97 ~658 minecraft:redstone_wire replace
setblock ~115 ~98 ~380 minecraft:redstone_wire replace
setblock ~82 ~98 ~392 minecraft:redstone_wire replace
setblock ~88 ~98 ~580 minecraft:redstone_wire replace
setblock ~79 ~98 ~584 minecraft:redstone_wire replace
setblock ~91 ~98 ~588 minecraft:redstone_wire replace
setblock ~94 ~98 ~592 minecraft:redstone_wire replace
setblock ~97 ~98 ~596 minecraft:redstone_wire replace
setblock ~100 ~98 ~600 minecraft:redstone_wire replace
setblock ~103 ~98 ~604 minecraft:redstone_wire replace
setblock ~118 ~98 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~98 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~98 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~98 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~98 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~98 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~98 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~98 ~640 minecraft:redstone_wire replace
setblock ~85 ~98 ~644 minecraft:redstone_wire replace
setblock ~121 ~98 ~648 minecraft:redstone_wire replace
setblock ~124 ~98 ~656 minecraft:redstone_wire replace
fill ~114 ~99 ~380 ~114 ~99 ~384 minecraft:redstone_wire replace
fill ~81 ~99 ~392 ~81 ~99 ~396 minecraft:redstone_wire replace
fill ~87 ~99 ~580 ~87 ~99 ~584 minecraft:redstone_wire replace
fill ~78 ~99 ~584 ~78 ~99 ~588 minecraft:redstone_wire replace
fill ~90 ~99 ~588 ~90 ~99 ~592 minecraft:redstone_wire replace
fill ~93 ~99 ~592 ~93 ~99 ~596 minecraft:redstone_wire replace
fill ~96 ~99 ~596 ~96 ~99 ~600 minecraft:redstone_wire replace
fill ~99 ~99 ~600 ~99 ~99 ~604 minecraft:redstone_wire replace
fill ~102 ~99 ~604 ~102 ~99 ~608 minecraft:redstone_wire replace
fill ~117 ~99 ~608 ~117 ~99 ~620 minecraft:redstone_wire replace
fill ~111 ~99 ~612 ~111 ~99 ~618 minecraft:redstone_wire replace
fill ~108 ~99 ~620 ~108 ~99 ~624 minecraft:redstone_wire replace
setblock ~111 ~99 ~620 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~99 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~99 ~624 ~105 ~99 ~634 minecraft:redstone_wire replace
fill ~117 ~99 ~624 ~117 ~99 ~630 minecraft:redstone_wire replace
setblock ~117 ~99 ~632 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~99 ~636 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~99 ~640 ~126 ~99 ~644 minecraft:redstone_wire replace
fill ~84 ~99 ~644 ~84 ~99 ~648 minecraft:redstone_wire replace
fill ~120 ~99 ~648 ~120 ~99 ~652 minecraft:redstone_wire replace
fill ~123 ~99 ~656 ~123 ~99 ~660 minecraft:redstone_wire replace
setblock ~114 ~100 ~385 minecraft:redstone_wire replace
setblock ~81 ~100 ~397 minecraft:redstone_wire replace
setblock ~87 ~100 ~585 minecraft:redstone_wire replace
setblock ~78 ~100 ~589 minecraft:redstone_wire replace
setblock ~90 ~100 ~593 minecraft:redstone_wire replace
setblock ~93 ~100 ~597 minecraft:redstone_wire replace
setblock ~96 ~100 ~601 minecraft:redstone_wire replace
setblock ~99 ~100 ~605 minecraft:redstone_wire replace
setblock ~102 ~100 ~609 minecraft:redstone_wire replace
setblock ~111 ~100 ~621 minecraft:redstone_wire replace
setblock ~108 ~100 ~625 minecraft:redstone_wire replace
setblock ~117 ~100 ~633 minecraft:redstone_wire replace
setblock ~105 ~100 ~637 minecraft:redstone_wire replace
setblock ~126 ~100 ~645 minecraft:redstone_wire replace
setblock ~84 ~100 ~649 minecraft:redstone_wire replace
setblock ~120 ~100 ~653 minecraft:redstone_wire replace
setblock ~123 ~100 ~661 minecraft:redstone_wire replace
fill ~114 ~101 ~386 ~120 ~101 ~386 minecraft:redstone_wire replace
setblock ~122 ~101 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~101 ~386 ~128 ~101 ~386 minecraft:redstone_wire replace
setblock ~127 ~101 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~101 ~398 ~83 ~101 ~398 minecraft:redstone_wire replace
setblock ~82 ~101 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~101 ~586 ~89 ~101 ~586 minecraft:redstone_wire replace
setblock ~88 ~101 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~101 ~590 ~80 ~101 ~590 minecraft:redstone_wire replace
setblock ~79 ~101 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~101 ~594 ~92 ~101 ~594 minecraft:redstone_wire replace
setblock ~91 ~101 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~101 ~598 ~95 ~101 ~598 minecraft:redstone_wire replace
setblock ~94 ~101 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~101 ~602 ~98 ~101 ~602 minecraft:redstone_wire replace
setblock ~97 ~101 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~101 ~606 ~101 ~101 ~606 minecraft:redstone_wire replace
setblock ~100 ~101 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~101 ~610 ~107 ~101 ~610 minecraft:redstone_wire replace
setblock ~108 ~101 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~101 ~610 ~121 ~101 ~610 minecraft:redstone_wire replace
setblock ~122 ~101 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~101 ~610 ~131 ~101 ~610 minecraft:redstone_wire replace
setblock ~103 ~101 ~611 minecraft:redstone_wire replace
setblock ~106 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~101 ~611 minecraft:redstone_wire replace
setblock ~115 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~101 ~611 minecraft:redstone_wire replace
setblock ~130 ~101 ~611 minecraft:redstone_wire replace
fill ~105 ~101 ~622 ~122 ~101 ~622 minecraft:redstone_wire replace
setblock ~123 ~101 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~101 ~622 ~136 ~101 ~622 minecraft:redstone_wire replace
setblock ~137 ~101 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~106 ~101 ~623 minecraft:redstone_wire replace
setblock ~112 ~101 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~101 ~623 minecraft:redstone_wire replace
setblock ~121 ~101 ~623 minecraft:redstone_wire replace
setblock ~124 ~101 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~101 ~623 minecraft:redstone_wire replace
setblock ~136 ~101 ~623 minecraft:redstone_wire replace
fill ~102 ~101 ~626 ~114 ~101 ~626 minecraft:redstone_wire replace
setblock ~116 ~101 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~101 ~626 ~131 ~101 ~626 minecraft:redstone_wire replace
setblock ~132 ~101 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~101 ~626 ~134 ~101 ~626 minecraft:redstone_wire replace
setblock ~103 ~101 ~627 minecraft:redstone_wire replace
setblock ~109 ~101 ~627 minecraft:redstone_wire replace
setblock ~112 ~101 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~101 ~627 minecraft:redstone_wire replace
setblock ~124 ~101 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~101 ~627 minecraft:redstone_wire replace
fill ~117 ~101 ~634 ~129 ~101 ~634 minecraft:redstone_wire replace
setblock ~131 ~101 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~101 ~634 ~140 ~101 ~634 minecraft:redstone_wire replace
setblock ~139 ~101 ~635 minecraft:redstone_wire replace
fill ~102 ~101 ~638 ~117 ~101 ~638 minecraft:redstone_wire replace
setblock ~119 ~101 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~101 ~638 ~134 ~101 ~638 minecraft:redstone_wire replace
setblock ~135 ~101 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~101 ~638 ~137 ~101 ~638 minecraft:redstone_wire replace
setblock ~103 ~101 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~101 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~101 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~101 ~639 minecraft:redstone_wire replace
setblock ~121 ~101 ~639 minecraft:redstone_wire replace
setblock ~124 ~101 ~639 minecraft:redstone_wire replace
setblock ~136 ~101 ~639 minecraft:redstone_wire replace
fill ~126 ~101 ~646 ~132 ~101 ~646 minecraft:redstone_wire replace
setblock ~134 ~101 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~101 ~646 ~149 ~101 ~646 minecraft:redstone_wire replace
setblock ~148 ~101 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~101 ~650 ~86 ~101 ~650 minecraft:redstone_wire replace
setblock ~85 ~101 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~101 ~654 ~126 ~101 ~654 minecraft:redstone_wire replace
setblock ~128 ~101 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~101 ~654 ~143 ~101 ~654 minecraft:redstone_wire replace
setblock ~142 ~101 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~101 ~662 ~129 ~101 ~662 minecraft:redstone_wire replace
setblock ~131 ~101 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~101 ~662 ~146 ~101 ~662 minecraft:redstone_wire replace
setblock ~145 ~101 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~102 ~388 minecraft:redstone_wire replace
setblock ~82 ~102 ~400 minecraft:redstone_wire replace
setblock ~88 ~102 ~588 minecraft:redstone_wire replace
setblock ~79 ~102 ~592 minecraft:redstone_wire replace
setblock ~91 ~102 ~596 minecraft:redstone_wire replace
setblock ~94 ~102 ~600 minecraft:redstone_wire replace
setblock ~97 ~102 ~604 minecraft:redstone_wire replace
setblock ~100 ~102 ~608 minecraft:redstone_wire replace
setblock ~103 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~102 ~612 minecraft:redstone_wire replace
setblock ~109 ~102 ~612 minecraft:redstone_wire replace
setblock ~112 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~102 ~612 minecraft:redstone_wire replace
setblock ~118 ~102 ~612 minecraft:redstone_wire replace
setblock ~121 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~102 ~624 minecraft:redstone_wire replace
setblock ~115 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~102 ~624 minecraft:redstone_wire replace
setblock ~130 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~102 ~628 minecraft:redstone_wire replace
setblock ~118 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~102 ~628 minecraft:redstone_wire replace
setblock ~133 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~102 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~102 ~640 minecraft:redstone_wire replace
setblock ~106 ~102 ~640 minecraft:redstone_wire replace
setblock ~109 ~102 ~640 minecraft:redstone_wire replace
setblock ~115 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~102 ~648 minecraft:redstone_wire replace
setblock ~85 ~102 ~652 minecraft:redstone_wire replace
setblock ~142 ~102 ~656 minecraft:redstone_wire replace
setblock ~145 ~102 ~664 minecraft:redstone_wire replace
fill ~126 ~103 ~384 ~126 ~103 ~388 minecraft:redstone_wire replace
fill ~81 ~103 ~396 ~81 ~103 ~400 minecraft:redstone_wire replace
setblock ~87 ~103 ~556 minecraft:redstone_wire replace
setblock ~87 ~103 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~103 ~560 minecraft:redstone_wire replace
fill ~87 ~103 ~560 ~87 ~103 ~572 minecraft:redstone_wire replace
setblock ~78 ~103 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~103 ~564 ~78 ~103 ~576 minecraft:redstone_wire replace
setblock ~90 ~103 ~564 minecraft:redstone_wire replace
setblock ~90 ~103 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~103 ~568 ~90 ~103 ~580 minecraft:redstone_wire replace
setblock ~93 ~103 ~568 minecraft:redstone_wire replace
setblock ~93 ~103 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~103 ~572 ~93 ~103 ~584 minecraft:redstone_wire replace
setblock ~96 ~103 ~572 minecraft:redstone_wire replace
setblock ~87 ~103 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~103 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~103 ~576 ~87 ~103 ~588 minecraft:redstone_wire replace
fill ~96 ~103 ~576 ~96 ~103 ~588 minecraft:redstone_wire replace
setblock ~99 ~103 ~576 minecraft:redstone_wire replace
setblock ~78 ~103 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~103 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~103 ~580 ~78 ~103 ~592 minecraft:redstone_wire replace
fill ~99 ~103 ~580 ~99 ~103 ~592 minecraft:redstone_wire replace
setblock ~129 ~103 ~580 minecraft:redstone_wire replace
setblock ~129 ~103 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~103 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~103 ~582 ~129 ~103 ~594 minecraft:redstone_wire replace
fill ~90 ~103 ~584 ~90 ~103 ~596 minecraft:redstone_wire replace
setblock ~120 ~103 ~584 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~103 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~103 ~586 ~120 ~103 ~594 minecraft:redstone_wire replace
fill ~93 ~103 ~588 ~93 ~103 ~600 minecraft:redstone_wire replace
setblock ~117 ~103 ~588 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~103 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~103 ~590 ~117 ~103 ~596 minecraft:redstone_wire replace
fill ~96 ~103 ~592 ~96 ~103 ~604 minecraft:redstone_wire replace
fill ~114 ~103 ~592 ~114 ~103 ~594 minecraft:redstone_wire replace
setblock ~99 ~103 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~103 ~596 ~99 ~103 ~608 minecraft:redstone_wire replace
setblock ~111 ~103 ~596 minecraft:redstone_wire replace
setblock ~114 ~103 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~103 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~103 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~103 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~103 ~598 ~114 ~103 ~610 minecraft:redstone_wire replace
setblock ~117 ~103 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~103 ~598 ~120 ~103 ~610 minecraft:redstone_wire replace
fill ~129 ~103 ~598 ~129 ~103 ~610 minecraft:redstone_wire replace
setblock ~108 ~103 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~103 ~600 ~111 ~103 ~612 minecraft:redstone_wire replace
fill ~117 ~103 ~600 ~117 ~103 ~612 minecraft:redstone_wire replace
fill ~108 ~103 ~602 ~108 ~103 ~612 minecraft:redstone_wire replace
fill ~105 ~103 ~604 ~105 ~103 ~610 minecraft:redstone_wire replace
fill ~102 ~103 ~608 ~102 ~103 ~612 minecraft:redstone_wire replace
setblock ~105 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~103 ~612 ~105 ~103 ~624 minecraft:redstone_wire replace
fill ~114 ~103 ~612 ~114 ~103 ~624 minecraft:redstone_wire replace
fill ~120 ~103 ~612 ~120 ~103 ~624 minecraft:redstone_wire replace
fill ~129 ~103 ~612 ~129 ~103 ~624 minecraft:redstone_wire replace
setblock ~102 ~103 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~103 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~103 ~614 ~102 ~103 ~626 minecraft:redstone_wire replace
fill ~108 ~103 ~614 ~108 ~103 ~626 minecraft:redstone_wire replace
setblock ~111 ~103 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~103 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~103 ~616 ~111 ~103 ~628 minecraft:redstone_wire replace
fill ~117 ~103 ~616 ~117 ~103 ~628 minecraft:redstone_wire replace
setblock ~135 ~103 ~616 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~103 ~618 ~135 ~103 ~624 minecraft:redstone_wire replace
fill ~123 ~103 ~620 ~123 ~103 ~626 minecraft:redstone_wire replace
fill ~132 ~103 ~624 ~132 ~103 ~628 minecraft:redstone_wire replace
setblock ~105 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~103 ~627 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~103 ~627 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~103 ~627 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~103 ~628 ~102 ~103 ~640 minecraft:redstone_wire replace
fill ~105 ~103 ~628 ~105 ~103 ~640 minecraft:redstone_wire replace
fill ~108 ~103 ~628 ~108 ~103 ~640 minecraft:redstone_wire replace
fill ~114 ~103 ~628 ~114 ~103 ~640 minecraft:redstone_wire replace
fill ~120 ~103 ~628 ~120 ~103 ~640 minecraft:redstone_wire replace
fill ~123 ~103 ~628 ~123 ~103 ~640 minecraft:redstone_wire replace
fill ~135 ~103 ~628 ~135 ~103 ~640 minecraft:redstone_wire replace
fill ~138 ~103 ~632 ~138 ~103 ~636 minecraft:redstone_wire replace
fill ~147 ~103 ~644 ~147 ~103 ~648 minecraft:redstone_wire replace
fill ~84 ~103 ~648 ~84 ~103 ~652 minecraft:redstone_wire replace
fill ~141 ~103 ~652 ~141 ~103 ~656 minecraft:redstone_wire replace
fill ~144 ~103 ~660 ~144 ~103 ~664 minecraft:redstone_wire replace
setblock ~126 ~104 ~383 minecraft:redstone_wire replace
setblock ~81 ~104 ~395 minecraft:redstone_wire replace
setblock ~87 ~104 ~555 minecraft:redstone_wire replace
setblock ~78 ~104 ~559 minecraft:redstone_wire replace
setblock ~90 ~104 ~563 minecraft:redstone_wire replace
setblock ~93 ~104 ~567 minecraft:redstone_wire replace
setblock ~96 ~104 ~571 minecraft:redstone_wire replace
setblock ~99 ~104 ~575 minecraft:redstone_wire replace
setblock ~129 ~104 ~579 minecraft:redstone_wire replace
setblock ~120 ~104 ~583 minecraft:redstone_wire replace
setblock ~117 ~104 ~587 minecraft:redstone_wire replace
setblock ~114 ~104 ~591 minecraft:redstone_wire replace
setblock ~111 ~104 ~595 minecraft:redstone_wire replace
setblock ~108 ~104 ~599 minecraft:redstone_wire replace
setblock ~105 ~104 ~603 minecraft:redstone_wire replace
setblock ~102 ~104 ~607 minecraft:redstone_wire replace
setblock ~135 ~104 ~615 minecraft:redstone_wire replace
setblock ~123 ~104 ~619 minecraft:redstone_wire replace
setblock ~132 ~104 ~623 minecraft:redstone_wire replace
setblock ~138 ~104 ~631 minecraft:redstone_wire replace
setblock ~147 ~104 ~643 minecraft:redstone_wire replace
setblock ~84 ~104 ~647 minecraft:redstone_wire replace
setblock ~141 ~104 ~651 minecraft:redstone_wire replace
setblock ~144 ~104 ~659 minecraft:redstone_wire replace
setblock ~112 ~105 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~105 ~382 ~116 ~105 ~382 minecraft:redstone_wire replace
setblock ~118 ~105 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~105 ~382 ~126 ~105 ~382 minecraft:redstone_wire replace
setblock ~82 ~105 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~105 ~394 ~83 ~105 ~394 minecraft:redstone_wire replace
setblock ~88 ~105 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~105 ~554 ~89 ~105 ~554 minecraft:redstone_wire replace
setblock ~79 ~105 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~105 ~558 ~80 ~105 ~558 minecraft:redstone_wire replace
setblock ~91 ~105 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~105 ~562 ~92 ~105 ~562 minecraft:redstone_wire replace
setblock ~94 ~105 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~105 ~566 ~95 ~105 ~566 minecraft:redstone_wire replace
setblock ~97 ~105 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~105 ~570 ~98 ~105 ~570 minecraft:redstone_wire replace
setblock ~100 ~105 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~105 ~574 ~101 ~105 ~574 minecraft:redstone_wire replace
setblock ~115 ~105 ~577 minecraft:redstone_wire replace
fill ~114 ~105 ~578 ~116 ~105 ~578 minecraft:redstone_wire replace
setblock ~117 ~105 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~105 ~578 ~129 ~105 ~578 minecraft:redstone_wire replace
setblock ~109 ~105 ~581 minecraft:redstone_wire replace
fill ~108 ~105 ~582 ~120 ~105 ~582 minecraft:redstone_wire replace
setblock ~109 ~105 ~585 minecraft:redstone_wire replace
fill ~108 ~105 ~586 ~117 ~105 ~586 minecraft:redstone_wire replace
setblock ~106 ~105 ~589 minecraft:redstone_wire replace
fill ~105 ~105 ~590 ~114 ~105 ~590 minecraft:redstone_wire replace
setblock ~106 ~105 ~593 minecraft:redstone_wire replace
fill ~105 ~105 ~594 ~111 ~105 ~594 minecraft:redstone_wire replace
setblock ~106 ~105 ~597 minecraft:redstone_wire replace
fill ~105 ~105 ~598 ~108 ~105 ~598 minecraft:redstone_wire replace
setblock ~103 ~105 ~601 minecraft:redstone_wire replace
fill ~102 ~105 ~602 ~105 ~105 ~602 minecraft:redstone_wire replace
setblock ~103 ~105 ~605 minecraft:redstone_wire replace
fill ~102 ~105 ~606 ~104 ~105 ~606 minecraft:redstone_wire replace
setblock ~115 ~105 ~613 minecraft:redstone_wire replace
fill ~114 ~105 ~614 ~119 ~105 ~614 minecraft:redstone_wire replace
setblock ~121 ~105 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~105 ~614 ~135 ~105 ~614 minecraft:redstone_wire replace
setblock ~109 ~105 ~617 minecraft:redstone_wire replace
fill ~108 ~105 ~618 ~114 ~105 ~618 minecraft:redstone_wire replace
setblock ~116 ~105 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~105 ~618 ~123 ~105 ~618 minecraft:redstone_wire replace
setblock ~115 ~105 ~621 minecraft:redstone_wire replace
fill ~114 ~105 ~622 ~122 ~105 ~622 minecraft:redstone_wire replace
setblock ~124 ~105 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~105 ~622 ~132 ~105 ~622 minecraft:redstone_wire replace
setblock ~118 ~105 ~629 minecraft:redstone_wire replace
fill ~117 ~105 ~630 ~128 ~105 ~630 minecraft:redstone_wire replace
setblock ~130 ~105 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~105 ~630 ~138 ~105 ~630 minecraft:redstone_wire replace
setblock ~127 ~105 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~105 ~642 ~137 ~105 ~642 minecraft:redstone_wire replace
setblock ~139 ~105 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~105 ~642 ~147 ~105 ~642 minecraft:redstone_wire replace
setblock ~85 ~105 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~105 ~646 ~86 ~105 ~646 minecraft:redstone_wire replace
setblock ~121 ~105 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~105 ~650 ~131 ~105 ~650 minecraft:redstone_wire replace
setblock ~133 ~105 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~105 ~650 ~141 ~105 ~650 minecraft:redstone_wire replace
setblock ~124 ~105 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~105 ~658 ~134 ~105 ~658 minecraft:redstone_wire replace
setblock ~136 ~105 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~105 ~658 ~144 ~105 ~658 minecraft:redstone_wire replace
setblock ~112 ~106 ~380 minecraft:redstone_wire replace
setblock ~82 ~106 ~392 minecraft:redstone_wire replace
setblock ~88 ~106 ~552 minecraft:redstone_wire replace
setblock ~79 ~106 ~556 minecraft:redstone_wire replace
setblock ~91 ~106 ~560 minecraft:redstone_wire replace
setblock ~94 ~106 ~564 minecraft:redstone_wire replace
setblock ~97 ~106 ~568 minecraft:redstone_wire replace
setblock ~100 ~106 ~572 minecraft:redstone_wire replace
setblock ~115 ~106 ~576 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~106 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~106 ~584 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~106 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~106 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~106 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~106 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~106 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~106 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~106 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~106 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~106 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~106 ~640 minecraft:redstone_wire replace
setblock ~85 ~106 ~644 minecraft:redstone_wire replace
setblock ~121 ~106 ~648 minecraft:redstone_wire replace
setblock ~124 ~106 ~656 minecraft:redstone_wire replace
fill ~111 ~107 ~380 ~111 ~107 ~384 minecraft:redstone_wire replace
fill ~81 ~107 ~392 ~81 ~107 ~396 minecraft:redstone_wire replace
fill ~87 ~107 ~552 ~87 ~107 ~556 minecraft:redstone_wire replace
fill ~78 ~107 ~556 ~78 ~107 ~560 minecraft:redstone_wire replace
fill ~90 ~107 ~560 ~90 ~107 ~564 minecraft:redstone_wire replace
fill ~93 ~107 ~564 ~93 ~107 ~568 minecraft:redstone_wire replace
fill ~96 ~107 ~568 ~96 ~107 ~572 minecraft:redstone_wire replace
fill ~99 ~107 ~572 ~99 ~107 ~576 minecraft:redstone_wire replace
fill ~114 ~107 ~576 ~114 ~107 ~588 minecraft:redstone_wire replace
fill ~108 ~107 ~580 ~108 ~107 ~592 minecraft:redstone_wire replace
fill ~105 ~107 ~588 ~105 ~107 ~598 minecraft:redstone_wire replace
setblock ~114 ~107 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~107 ~592 ~114 ~107 ~604 minecraft:redstone_wire replace
setblock ~108 ~107 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~107 ~596 ~108 ~107 ~608 minecraft:redstone_wire replace
fill ~102 ~107 ~600 ~102 ~107 ~606 minecraft:redstone_wire replace
setblock ~105 ~107 ~600 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~107 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~107 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~107 ~608 ~114 ~107 ~620 minecraft:redstone_wire replace
setblock ~108 ~107 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~107 ~612 ~108 ~107 ~618 minecraft:redstone_wire replace
setblock ~108 ~107 ~620 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~107 ~621 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~107 ~622 ~114 ~107 ~624 minecraft:redstone_wire replace
fill ~117 ~107 ~628 ~117 ~107 ~632 minecraft:redstone_wire replace
fill ~126 ~107 ~640 ~126 ~107 ~644 minecraft:redstone_wire replace
fill ~84 ~107 ~644 ~84 ~107 ~648 minecraft:redstone_wire replace
fill ~120 ~107 ~648 ~120 ~107 ~652 minecraft:redstone_wire replace
fill ~123 ~107 ~656 ~123 ~107 ~660 minecraft:redstone_wire replace
setblock ~111 ~108 ~385 minecraft:redstone_wire replace
setblock ~81 ~108 ~397 minecraft:redstone_wire replace
setblock ~87 ~108 ~557 minecraft:redstone_wire replace
setblock ~78 ~108 ~561 minecraft:redstone_wire replace
setblock ~90 ~108 ~565 minecraft:redstone_wire replace
setblock ~93 ~108 ~569 minecraft:redstone_wire replace
setblock ~96 ~108 ~573 minecraft:redstone_wire replace
setblock ~99 ~108 ~577 minecraft:redstone_wire replace
setblock ~105 ~108 ~601 minecraft:redstone_wire replace
setblock ~102 ~108 ~609 minecraft:redstone_wire replace
setblock ~108 ~108 ~621 minecraft:redstone_wire replace
setblock ~114 ~108 ~625 minecraft:redstone_wire replace
setblock ~117 ~108 ~633 minecraft:redstone_wire replace
setblock ~126 ~108 ~645 minecraft:redstone_wire replace
setblock ~84 ~108 ~649 minecraft:redstone_wire replace
setblock ~120 ~108 ~653 minecraft:redstone_wire replace
setblock ~123 ~108 ~661 minecraft:redstone_wire replace
fill ~111 ~109 ~386 ~117 ~109 ~386 minecraft:redstone_wire replace
setblock ~119 ~109 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~109 ~386 ~125 ~109 ~386 minecraft:redstone_wire replace
setblock ~124 ~109 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~109 ~398 ~83 ~109 ~398 minecraft:redstone_wire replace
setblock ~82 ~109 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~109 ~558 ~89 ~109 ~558 minecraft:redstone_wire replace
setblock ~88 ~109 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~109 ~562 ~80 ~109 ~562 minecraft:redstone_wire replace
setblock ~79 ~109 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~109 ~566 ~92 ~109 ~566 minecraft:redstone_wire replace
setblock ~91 ~109 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~109 ~570 ~95 ~109 ~570 minecraft:redstone_wire replace
setblock ~94 ~109 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~109 ~574 ~98 ~109 ~574 minecraft:redstone_wire replace
setblock ~97 ~109 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~109 ~578 ~104 ~109 ~578 minecraft:redstone_wire replace
setblock ~105 ~109 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~109 ~578 ~118 ~109 ~578 minecraft:redstone_wire replace
setblock ~119 ~109 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~109 ~578 ~128 ~109 ~578 minecraft:redstone_wire replace
setblock ~100 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~109 ~579 minecraft:redstone_wire replace
setblock ~106 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~109 ~579 minecraft:redstone_wire replace
setblock ~112 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~109 ~579 minecraft:redstone_wire replace
setblock ~127 ~109 ~579 minecraft:redstone_wire replace
fill ~99 ~109 ~602 ~116 ~109 ~602 minecraft:redstone_wire replace
setblock ~117 ~109 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~109 ~602 ~130 ~109 ~602 minecraft:redstone_wire replace
setblock ~131 ~109 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~132 ~109 ~602 ~134 ~109 ~602 minecraft:redstone_wire replace
setblock ~100 ~109 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~109 ~603 minecraft:redstone_wire replace
setblock ~109 ~109 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~109 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~109 ~603 minecraft:redstone_wire replace
setblock ~121 ~109 ~603 minecraft:redstone_wire replace
setblock ~133 ~109 ~603 minecraft:redstone_wire replace
fill ~99 ~109 ~610 ~113 ~109 ~610 minecraft:redstone_wire replace
setblock ~114 ~109 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~109 ~610 ~127 ~109 ~610 minecraft:redstone_wire replace
setblock ~128 ~109 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~129 ~109 ~610 ~131 ~109 ~610 minecraft:redstone_wire replace
setblock ~100 ~109 ~611 minecraft:redstone_wire replace
setblock ~103 ~109 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~109 ~611 minecraft:redstone_wire replace
setblock ~115 ~109 ~611 minecraft:redstone_wire replace
setblock ~121 ~109 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~109 ~611 minecraft:redstone_wire replace
fill ~102 ~109 ~622 ~119 ~109 ~622 minecraft:redstone_wire replace
setblock ~120 ~109 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~109 ~622 ~133 ~109 ~622 minecraft:redstone_wire replace
setblock ~134 ~109 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~103 ~109 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~109 ~623 minecraft:redstone_wire replace
setblock ~112 ~109 ~623 minecraft:redstone_wire replace
setblock ~118 ~109 ~623 minecraft:redstone_wire replace
setblock ~121 ~109 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~109 ~623 minecraft:redstone_wire replace
setblock ~133 ~109 ~623 minecraft:redstone_wire replace
fill ~114 ~109 ~626 ~123 ~109 ~626 minecraft:redstone_wire replace
setblock ~125 ~109 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~109 ~626 ~137 ~109 ~626 minecraft:redstone_wire replace
setblock ~136 ~109 ~627 minecraft:redstone_wire replace
fill ~117 ~109 ~634 ~123 ~109 ~634 minecraft:redstone_wire replace
setblock ~125 ~109 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~109 ~634 ~140 ~109 ~634 minecraft:redstone_wire replace
setblock ~139 ~109 ~635 minecraft:redstone_wire replace
fill ~126 ~109 ~646 ~132 ~109 ~646 minecraft:redstone_wire replace
setblock ~134 ~109 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~109 ~646 ~149 ~109 ~646 minecraft:redstone_wire replace
setblock ~148 ~109 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~109 ~650 ~86 ~109 ~650 minecraft:redstone_wire replace
setblock ~85 ~109 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~109 ~654 ~126 ~109 ~654 minecraft:redstone_wire replace
setblock ~128 ~109 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~109 ~654 ~143 ~109 ~654 minecraft:redstone_wire replace
setblock ~142 ~109 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~109 ~662 ~129 ~109 ~662 minecraft:redstone_wire replace
setblock ~131 ~109 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~109 ~662 ~146 ~109 ~662 minecraft:redstone_wire replace
setblock ~145 ~109 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~110 ~388 minecraft:redstone_wire replace
setblock ~82 ~110 ~400 minecraft:redstone_wire replace
setblock ~88 ~110 ~560 minecraft:redstone_wire replace
setblock ~79 ~110 ~564 minecraft:redstone_wire replace
setblock ~91 ~110 ~568 minecraft:redstone_wire replace
setblock ~94 ~110 ~572 minecraft:redstone_wire replace
setblock ~97 ~110 ~576 minecraft:redstone_wire replace
setblock ~100 ~110 ~580 minecraft:redstone_wire replace
setblock ~103 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~110 ~580 minecraft:redstone_wire replace
setblock ~109 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~110 ~580 minecraft:redstone_wire replace
setblock ~115 ~110 ~580 minecraft:redstone_wire replace
setblock ~118 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~110 ~604 minecraft:redstone_wire replace
setblock ~106 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~110 ~604 minecraft:redstone_wire replace
setblock ~112 ~110 ~604 minecraft:redstone_wire replace
setblock ~118 ~110 ~604 minecraft:redstone_torch[lit=true] replace
