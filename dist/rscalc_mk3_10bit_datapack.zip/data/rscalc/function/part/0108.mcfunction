setblock ~252 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~157 ~890 ~267 ~157 ~890 minecraft:redstone_wire replace
setblock ~269 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~890 ~284 ~157 ~890 minecraft:redstone_wire replace
setblock ~286 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~157 ~890 ~301 ~157 ~890 minecraft:redstone_wire replace
setblock ~303 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~157 ~890 ~318 ~157 ~890 minecraft:redstone_wire replace
setblock ~320 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~157 ~890 ~335 ~157 ~890 minecraft:redstone_wire replace
setblock ~337 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~157 ~890 ~348 ~157 ~890 minecraft:redstone_wire replace
setblock ~139 ~157 ~891 minecraft:redstone_wire replace
setblock ~141 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~894 ~155 ~157 ~894 minecraft:redstone_wire replace
setblock ~157 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~894 ~172 ~157 ~894 minecraft:redstone_wire replace
setblock ~174 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~894 ~189 ~157 ~894 minecraft:redstone_wire replace
setblock ~191 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~894 ~206 ~157 ~894 minecraft:redstone_wire replace
setblock ~208 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~894 ~223 ~157 ~894 minecraft:redstone_wire replace
setblock ~225 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~894 ~240 ~157 ~894 minecraft:redstone_wire replace
setblock ~242 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~894 ~257 ~157 ~894 minecraft:redstone_wire replace
setblock ~259 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~894 ~274 ~157 ~894 minecraft:redstone_wire replace
setblock ~276 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~894 ~291 ~157 ~894 minecraft:redstone_wire replace
setblock ~293 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~894 ~308 ~157 ~894 minecraft:redstone_wire replace
setblock ~310 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~894 ~325 ~157 ~894 minecraft:redstone_wire replace
setblock ~327 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~894 ~342 ~157 ~894 minecraft:redstone_wire replace
setblock ~344 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~894 ~351 ~157 ~894 minecraft:redstone_wire replace
setblock ~142 ~157 ~895 minecraft:redstone_wire replace
fill ~141 ~157 ~898 ~151 ~157 ~898 minecraft:redstone_wire replace
setblock ~153 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~898 ~168 ~157 ~898 minecraft:redstone_wire replace
setblock ~170 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~898 ~185 ~157 ~898 minecraft:redstone_wire replace
setblock ~187 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~898 ~202 ~157 ~898 minecraft:redstone_wire replace
setblock ~204 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~898 ~219 ~157 ~898 minecraft:redstone_wire replace
setblock ~221 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~898 ~236 ~157 ~898 minecraft:redstone_wire replace
setblock ~238 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~898 ~253 ~157 ~898 minecraft:redstone_wire replace
setblock ~255 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~898 ~270 ~157 ~898 minecraft:redstone_wire replace
setblock ~272 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~898 ~287 ~157 ~898 minecraft:redstone_wire replace
setblock ~289 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~157 ~898 ~304 ~157 ~898 minecraft:redstone_wire replace
setblock ~306 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~157 ~898 ~321 ~157 ~898 minecraft:redstone_wire replace
setblock ~323 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~325 ~157 ~898 ~338 ~157 ~898 minecraft:redstone_wire replace
setblock ~340 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~342 ~157 ~898 ~354 ~157 ~898 minecraft:redstone_wire replace
setblock ~142 ~157 ~899 minecraft:redstone_wire replace
setblock ~141 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~902 ~155 ~157 ~902 minecraft:redstone_wire replace
setblock ~157 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~902 ~172 ~157 ~902 minecraft:redstone_wire replace
setblock ~174 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~902 ~189 ~157 ~902 minecraft:redstone_wire replace
setblock ~191 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~902 ~206 ~157 ~902 minecraft:redstone_wire replace
setblock ~208 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~902 ~223 ~157 ~902 minecraft:redstone_wire replace
setblock ~225 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~902 ~240 ~157 ~902 minecraft:redstone_wire replace
setblock ~242 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~902 ~257 ~157 ~902 minecraft:redstone_wire replace
setblock ~259 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~902 ~274 ~157 ~902 minecraft:redstone_wire replace
setblock ~276 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~902 ~291 ~157 ~902 minecraft:redstone_wire replace
setblock ~293 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~902 ~308 ~157 ~902 minecraft:redstone_wire replace
setblock ~310 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~902 ~325 ~157 ~902 minecraft:redstone_wire replace
setblock ~327 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~902 ~342 ~157 ~902 minecraft:redstone_wire replace
setblock ~344 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~902 ~357 ~157 ~902 minecraft:redstone_wire replace
setblock ~142 ~157 ~903 minecraft:redstone_wire replace
fill ~141 ~157 ~906 ~143 ~157 ~906 minecraft:redstone_wire replace
setblock ~145 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~906 ~160 ~157 ~906 minecraft:redstone_wire replace
setblock ~162 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~906 ~177 ~157 ~906 minecraft:redstone_wire replace
setblock ~179 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~906 ~194 ~157 ~906 minecraft:redstone_wire replace
setblock ~196 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~906 ~211 ~157 ~906 minecraft:redstone_wire replace
setblock ~213 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~906 ~228 ~157 ~906 minecraft:redstone_wire replace
setblock ~230 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~906 ~245 ~157 ~906 minecraft:redstone_wire replace
setblock ~247 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~906 ~262 ~157 ~906 minecraft:redstone_wire replace
setblock ~264 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~906 ~279 ~157 ~906 minecraft:redstone_wire replace
setblock ~281 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~906 ~296 ~157 ~906 minecraft:redstone_wire replace
setblock ~298 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~906 ~313 ~157 ~906 minecraft:redstone_wire replace
setblock ~315 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~906 ~330 ~157 ~906 minecraft:redstone_wire replace
setblock ~332 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~906 ~347 ~157 ~906 minecraft:redstone_wire replace
setblock ~349 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~157 ~906 ~360 ~157 ~906 minecraft:redstone_wire replace
setblock ~142 ~157 ~907 minecraft:redstone_wire replace
fill ~144 ~157 ~910 ~150 ~157 ~910 minecraft:redstone_wire replace
setblock ~152 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~910 ~167 ~157 ~910 minecraft:redstone_wire replace
setblock ~169 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~910 ~184 ~157 ~910 minecraft:redstone_wire replace
setblock ~186 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~910 ~201 ~157 ~910 minecraft:redstone_wire replace
setblock ~203 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~910 ~218 ~157 ~910 minecraft:redstone_wire replace
setblock ~220 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~910 ~235 ~157 ~910 minecraft:redstone_wire replace
setblock ~237 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~910 ~252 ~157 ~910 minecraft:redstone_wire replace
setblock ~254 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~910 ~269 ~157 ~910 minecraft:redstone_wire replace
setblock ~271 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~910 ~286 ~157 ~910 minecraft:redstone_wire replace
setblock ~288 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~910 ~303 ~157 ~910 minecraft:redstone_wire replace
setblock ~305 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~910 ~320 ~157 ~910 minecraft:redstone_wire replace
setblock ~322 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~910 ~337 ~157 ~910 minecraft:redstone_wire replace
setblock ~339 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~910 ~354 ~157 ~910 minecraft:redstone_wire replace
setblock ~356 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~910 ~363 ~157 ~910 minecraft:redstone_wire replace
setblock ~145 ~157 ~911 minecraft:redstone_wire replace
fill ~144 ~157 ~914 ~146 ~157 ~914 minecraft:redstone_wire replace
setblock ~148 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~914 ~163 ~157 ~914 minecraft:redstone_wire replace
setblock ~165 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~914 ~180 ~157 ~914 minecraft:redstone_wire replace
setblock ~182 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~914 ~197 ~157 ~914 minecraft:redstone_wire replace
setblock ~199 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~914 ~214 ~157 ~914 minecraft:redstone_wire replace
setblock ~216 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~914 ~231 ~157 ~914 minecraft:redstone_wire replace
setblock ~233 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~914 ~248 ~157 ~914 minecraft:redstone_wire replace
setblock ~250 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~914 ~265 ~157 ~914 minecraft:redstone_wire replace
setblock ~267 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~914 ~282 ~157 ~914 minecraft:redstone_wire replace
setblock ~284 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~914 ~299 ~157 ~914 minecraft:redstone_wire replace
setblock ~301 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~157 ~914 ~316 ~157 ~914 minecraft:redstone_wire replace
setblock ~318 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~320 ~157 ~914 ~333 ~157 ~914 minecraft:redstone_wire replace
setblock ~335 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~157 ~914 ~350 ~157 ~914 minecraft:redstone_wire replace
setblock ~352 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~157 ~914 ~366 ~157 ~914 minecraft:redstone_wire replace
setblock ~145 ~157 ~915 minecraft:redstone_wire replace
fill ~144 ~157 ~918 ~150 ~157 ~918 minecraft:redstone_wire replace
setblock ~152 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~918 ~167 ~157 ~918 minecraft:redstone_wire replace
setblock ~169 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~918 ~184 ~157 ~918 minecraft:redstone_wire replace
setblock ~186 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~918 ~201 ~157 ~918 minecraft:redstone_wire replace
setblock ~203 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~918 ~218 ~157 ~918 minecraft:redstone_wire replace
setblock ~220 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~918 ~235 ~157 ~918 minecraft:redstone_wire replace
setblock ~237 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~918 ~252 ~157 ~918 minecraft:redstone_wire replace
setblock ~254 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~918 ~269 ~157 ~918 minecraft:redstone_wire replace
setblock ~271 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~918 ~286 ~157 ~918 minecraft:redstone_wire replace
setblock ~288 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~918 ~303 ~157 ~918 minecraft:redstone_wire replace
setblock ~305 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~918 ~320 ~157 ~918 minecraft:redstone_wire replace
setblock ~322 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~918 ~337 ~157 ~918 minecraft:redstone_wire replace
setblock ~339 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~918 ~354 ~157 ~918 minecraft:redstone_wire replace
setblock ~356 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~918 ~369 ~157 ~918 minecraft:redstone_wire replace
setblock ~145 ~157 ~919 minecraft:redstone_wire replace
fill ~144 ~157 ~922 ~155 ~157 ~922 minecraft:redstone_wire replace
setblock ~157 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~922 ~172 ~157 ~922 minecraft:redstone_wire replace
setblock ~174 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~922 ~189 ~157 ~922 minecraft:redstone_wire replace
setblock ~191 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~922 ~206 ~157 ~922 minecraft:redstone_wire replace
setblock ~208 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~922 ~223 ~157 ~922 minecraft:redstone_wire replace
setblock ~225 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~922 ~240 ~157 ~922 minecraft:redstone_wire replace
setblock ~242 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~922 ~257 ~157 ~922 minecraft:redstone_wire replace
setblock ~259 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~922 ~274 ~157 ~922 minecraft:redstone_wire replace
setblock ~276 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~922 ~291 ~157 ~922 minecraft:redstone_wire replace
setblock ~293 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~922 ~308 ~157 ~922 minecraft:redstone_wire replace
setblock ~310 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~922 ~325 ~157 ~922 minecraft:redstone_wire replace
setblock ~327 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~922 ~342 ~157 ~922 minecraft:redstone_wire replace
setblock ~344 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~922 ~359 ~157 ~922 minecraft:redstone_wire replace
setblock ~361 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~157 ~922 ~372 ~157 ~922 minecraft:redstone_wire replace
setblock ~145 ~157 ~923 minecraft:redstone_wire replace
fill ~144 ~157 ~926 ~145 ~157 ~926 minecraft:redstone_wire replace
setblock ~147 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~926 ~162 ~157 ~926 minecraft:redstone_wire replace
setblock ~164 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~926 ~179 ~157 ~926 minecraft:redstone_wire replace
setblock ~181 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~926 ~196 ~157 ~926 minecraft:redstone_wire replace
setblock ~198 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~926 ~213 ~157 ~926 minecraft:redstone_wire replace
setblock ~215 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~926 ~230 ~157 ~926 minecraft:redstone_wire replace
setblock ~232 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~926 ~247 ~157 ~926 minecraft:redstone_wire replace
setblock ~249 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~926 ~264 ~157 ~926 minecraft:redstone_wire replace
setblock ~266 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~926 ~281 ~157 ~926 minecraft:redstone_wire replace
setblock ~283 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~157 ~926 ~298 ~157 ~926 minecraft:redstone_wire replace
setblock ~300 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~157 ~926 ~315 ~157 ~926 minecraft:redstone_wire replace
setblock ~317 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~157 ~926 ~332 ~157 ~926 minecraft:redstone_wire replace
setblock ~334 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~157 ~926 ~349 ~157 ~926 minecraft:redstone_wire replace
setblock ~351 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~353 ~157 ~926 ~366 ~157 ~926 minecraft:redstone_wire replace
setblock ~368 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~157 ~926 ~375 ~157 ~926 minecraft:redstone_wire replace
setblock ~145 ~157 ~927 minecraft:redstone_wire replace
setblock ~144 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~930 ~158 ~157 ~930 minecraft:redstone_wire replace
setblock ~160 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~930 ~175 ~157 ~930 minecraft:redstone_wire replace
setblock ~177 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~930 ~192 ~157 ~930 minecraft:redstone_wire replace
setblock ~194 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~930 ~209 ~157 ~930 minecraft:redstone_wire replace
setblock ~211 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~930 ~226 ~157 ~930 minecraft:redstone_wire replace
setblock ~228 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~930 ~243 ~157 ~930 minecraft:redstone_wire replace
setblock ~245 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~930 ~260 ~157 ~930 minecraft:redstone_wire replace
setblock ~262 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~930 ~277 ~157 ~930 minecraft:redstone_wire replace
setblock ~279 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~930 ~294 ~157 ~930 minecraft:redstone_wire replace
setblock ~296 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~930 ~311 ~157 ~930 minecraft:redstone_wire replace
setblock ~313 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~157 ~930 ~328 ~157 ~930 minecraft:redstone_wire replace
setblock ~330 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~332 ~157 ~930 ~345 ~157 ~930 minecraft:redstone_wire replace
setblock ~347 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~349 ~157 ~930 ~362 ~157 ~930 minecraft:redstone_wire replace
setblock ~364 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~366 ~157 ~930 ~378 ~157 ~930 minecraft:redstone_wire replace
setblock ~145 ~157 ~931 minecraft:redstone_wire replace
fill ~147 ~157 ~934 ~159 ~157 ~934 minecraft:redstone_wire replace
setblock ~161 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~934 ~175 ~157 ~934 minecraft:redstone_wire replace
setblock ~177 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~934 ~191 ~157 ~934 minecraft:redstone_wire replace
setblock ~193 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~934 ~207 ~157 ~934 minecraft:redstone_wire replace
setblock ~209 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~934 ~223 ~157 ~934 minecraft:redstone_wire replace
setblock ~225 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~934 ~239 ~157 ~934 minecraft:redstone_wire replace
setblock ~241 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~157 ~934 ~255 ~157 ~934 minecraft:redstone_wire replace
setblock ~257 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~934 ~271 ~157 ~934 minecraft:redstone_wire replace
setblock ~273 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~157 ~934 ~287 ~157 ~934 minecraft:redstone_wire replace
setblock ~289 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~157 ~934 ~303 ~157 ~934 minecraft:redstone_wire replace
setblock ~305 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~934 ~319 ~157 ~934 minecraft:redstone_wire replace
setblock ~321 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~323 ~157 ~934 ~335 ~157 ~934 minecraft:redstone_wire replace
setblock ~337 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~157 ~934 ~351 ~157 ~934 minecraft:redstone_wire replace
setblock ~353 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~355 ~157 ~934 ~367 ~157 ~934 minecraft:redstone_wire replace
setblock ~369 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~371 ~157 ~934 ~381 ~157 ~934 minecraft:redstone_wire replace
setblock ~148 ~157 ~935 minecraft:redstone_wire replace
fill ~147 ~157 ~938 ~150 ~157 ~938 minecraft:redstone_wire replace
setblock ~152 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~938 ~167 ~157 ~938 minecraft:redstone_wire replace
setblock ~169 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~938 ~184 ~157 ~938 minecraft:redstone_wire replace
setblock ~186 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~938 ~201 ~157 ~938 minecraft:redstone_wire replace
setblock ~203 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~938 ~218 ~157 ~938 minecraft:redstone_wire replace
setblock ~220 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~938 ~235 ~157 ~938 minecraft:redstone_wire replace
setblock ~237 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~938 ~252 ~157 ~938 minecraft:redstone_wire replace
setblock ~254 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~938 ~269 ~157 ~938 minecraft:redstone_wire replace
setblock ~271 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~938 ~286 ~157 ~938 minecraft:redstone_wire replace
setblock ~288 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~938 ~303 ~157 ~938 minecraft:redstone_wire replace
setblock ~305 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~938 ~320 ~157 ~938 minecraft:redstone_wire replace
setblock ~322 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~938 ~337 ~157 ~938 minecraft:redstone_wire replace
setblock ~339 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~938 ~354 ~157 ~938 minecraft:redstone_wire replace
setblock ~356 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~938 ~371 ~157 ~938 minecraft:redstone_wire replace
setblock ~373 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~157 ~938 ~384 ~157 ~938 minecraft:redstone_wire replace
setblock ~148 ~157 ~939 minecraft:redstone_wire replace
fill ~147 ~157 ~942 ~157 ~157 ~942 minecraft:redstone_wire replace
setblock ~159 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~942 ~174 ~157 ~942 minecraft:redstone_wire replace
setblock ~176 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~942 ~191 ~157 ~942 minecraft:redstone_wire replace
setblock ~193 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~942 ~208 ~157 ~942 minecraft:redstone_wire replace
setblock ~210 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~942 ~225 ~157 ~942 minecraft:redstone_wire replace
setblock ~227 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~942 ~242 ~157 ~942 minecraft:redstone_wire replace
setblock ~244 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~942 ~259 ~157 ~942 minecraft:redstone_wire replace
setblock ~261 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~942 ~276 ~157 ~942 minecraft:redstone_wire replace
setblock ~278 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~942 ~293 ~157 ~942 minecraft:redstone_wire replace
setblock ~295 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~157 ~942 ~310 ~157 ~942 minecraft:redstone_wire replace
setblock ~312 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~942 ~327 ~157 ~942 minecraft:redstone_wire replace
setblock ~329 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~157 ~942 ~344 ~157 ~942 minecraft:redstone_wire replace
setblock ~346 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~157 ~942 ~361 ~157 ~942 minecraft:redstone_wire replace
setblock ~363 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~365 ~157 ~942 ~378 ~157 ~942 minecraft:redstone_wire replace
setblock ~380 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~382 ~157 ~942 ~387 ~157 ~942 minecraft:redstone_wire replace
setblock ~148 ~157 ~943 minecraft:redstone_wire replace
fill ~147 ~157 ~946 ~153 ~157 ~946 minecraft:redstone_wire replace
setblock ~155 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~946 ~170 ~157 ~946 minecraft:redstone_wire replace
setblock ~172 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~946 ~187 ~157 ~946 minecraft:redstone_wire replace
setblock ~189 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~946 ~204 ~157 ~946 minecraft:redstone_wire replace
setblock ~206 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~157 ~946 ~221 ~157 ~946 minecraft:redstone_wire replace
setblock ~223 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~157 ~946 ~238 ~157 ~946 minecraft:redstone_wire replace
setblock ~240 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~157 ~946 ~255 ~157 ~946 minecraft:redstone_wire replace
setblock ~257 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~946 ~272 ~157 ~946 minecraft:redstone_wire replace
setblock ~274 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~946 ~289 ~157 ~946 minecraft:redstone_wire replace
setblock ~291 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~157 ~946 ~306 ~157 ~946 minecraft:redstone_wire replace
setblock ~308 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~157 ~946 ~323 ~157 ~946 minecraft:redstone_wire replace
setblock ~325 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~157 ~946 ~340 ~157 ~946 minecraft:redstone_wire replace
setblock ~342 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~344 ~157 ~946 ~357 ~157 ~946 minecraft:redstone_wire replace
setblock ~359 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~361 ~157 ~946 ~374 ~157 ~946 minecraft:redstone_wire replace
setblock ~376 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~378 ~157 ~946 ~390 ~157 ~946 minecraft:redstone_wire replace
setblock ~148 ~157 ~947 minecraft:redstone_wire replace
fill ~147 ~157 ~950 ~157 ~157 ~950 minecraft:redstone_wire replace
setblock ~159 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~950 ~174 ~157 ~950 minecraft:redstone_wire replace
setblock ~176 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~950 ~191 ~157 ~950 minecraft:redstone_wire replace
setblock ~193 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~950 ~208 ~157 ~950 minecraft:redstone_wire replace
setblock ~210 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~950 ~225 ~157 ~950 minecraft:redstone_wire replace
setblock ~227 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~950 ~242 ~157 ~950 minecraft:redstone_wire replace
setblock ~244 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~950 ~259 ~157 ~950 minecraft:redstone_wire replace
setblock ~261 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~950 ~276 ~157 ~950 minecraft:redstone_wire replace
setblock ~278 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~950 ~293 ~157 ~950 minecraft:redstone_wire replace
setblock ~295 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~157 ~950 ~310 ~157 ~950 minecraft:redstone_wire replace
setblock ~312 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~950 ~327 ~157 ~950 minecraft:redstone_wire replace
setblock ~329 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~157 ~950 ~344 ~157 ~950 minecraft:redstone_wire replace
setblock ~346 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~157 ~950 ~361 ~157 ~950 minecraft:redstone_wire replace
setblock ~363 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~365 ~157 ~950 ~378 ~157 ~950 minecraft:redstone_wire replace
setblock ~380 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~382 ~157 ~950 ~393 ~157 ~950 minecraft:redstone_wire replace
setblock ~148 ~157 ~951 minecraft:redstone_wire replace
setblock ~147 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~157 ~954 ~160 ~157 ~954 minecraft:redstone_wire replace
setblock ~162 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~954 ~176 ~157 ~954 minecraft:redstone_wire replace
setblock ~178 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~954 ~192 ~157 ~954 minecraft:redstone_wire replace
setblock ~194 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~954 ~208 ~157 ~954 minecraft:redstone_wire replace
setblock ~210 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~954 ~224 ~157 ~954 minecraft:redstone_wire replace
setblock ~226 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~954 ~240 ~157 ~954 minecraft:redstone_wire replace
setblock ~242 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~954 ~256 ~157 ~954 minecraft:redstone_wire replace
setblock ~258 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~260 ~157 ~954 ~272 ~157 ~954 minecraft:redstone_wire replace
setblock ~274 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~954 ~288 ~157 ~954 minecraft:redstone_wire replace
setblock ~290 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~157 ~954 ~304 ~157 ~954 minecraft:redstone_wire replace
setblock ~306 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~157 ~954 ~320 ~157 ~954 minecraft:redstone_wire replace
setblock ~322 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~954 ~336 ~157 ~954 minecraft:redstone_wire replace
setblock ~338 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~340 ~157 ~954 ~352 ~157 ~954 minecraft:redstone_wire replace
setblock ~354 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~356 ~157 ~954 ~368 ~157 ~954 minecraft:redstone_wire replace
setblock ~370 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~372 ~157 ~954 ~384 ~157 ~954 minecraft:redstone_wire replace
setblock ~386 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~388 ~157 ~954 ~396 ~157 ~954 minecraft:redstone_wire replace
setblock ~148 ~157 ~955 minecraft:redstone_wire replace
fill ~147 ~157 ~958 ~152 ~157 ~958 minecraft:redstone_wire replace
setblock ~154 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~958 ~169 ~157 ~958 minecraft:redstone_wire replace
setblock ~171 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~958 ~186 ~157 ~958 minecraft:redstone_wire replace
setblock ~188 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~958 ~203 ~157 ~958 minecraft:redstone_wire replace
setblock ~205 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~958 ~220 ~157 ~958 minecraft:redstone_wire replace
setblock ~222 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~157 ~958 ~237 ~157 ~958 minecraft:redstone_wire replace
setblock ~239 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~157 ~958 ~254 ~157 ~958 minecraft:redstone_wire replace
setblock ~256 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~157 ~958 ~271 ~157 ~958 minecraft:redstone_wire replace
setblock ~273 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~157 ~958 ~288 ~157 ~958 minecraft:redstone_wire replace
setblock ~290 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~157 ~958 ~305 ~157 ~958 minecraft:redstone_wire replace
setblock ~307 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~309 ~157 ~958 ~322 ~157 ~958 minecraft:redstone_wire replace
setblock ~324 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~326 ~157 ~958 ~339 ~157 ~958 minecraft:redstone_wire replace
setblock ~341 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~157 ~958 ~356 ~157 ~958 minecraft:redstone_wire replace
setblock ~358 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~360 ~157 ~958 ~373 ~157 ~958 minecraft:redstone_wire replace
setblock ~375 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~377 ~157 ~958 ~390 ~157 ~958 minecraft:redstone_wire replace
setblock ~392 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~394 ~157 ~958 ~399 ~157 ~958 minecraft:redstone_wire replace
setblock ~148 ~157 ~959 minecraft:redstone_wire replace
fill ~174 ~157 ~962 ~179 ~157 ~962 minecraft:redstone_wire replace
setblock ~181 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~962 ~196 ~157 ~962 minecraft:redstone_wire replace
setblock ~198 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~962 ~213 ~157 ~962 minecraft:redstone_wire replace
setblock ~215 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~962 ~230 ~157 ~962 minecraft:redstone_wire replace
setblock ~232 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~962 ~247 ~157 ~962 minecraft:redstone_wire replace
setblock ~249 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~962 ~264 ~157 ~962 minecraft:redstone_wire replace
setblock ~266 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~962 ~281 ~157 ~962 minecraft:redstone_wire replace
setblock ~283 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~157 ~962 ~298 ~157 ~962 minecraft:redstone_wire replace
setblock ~300 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~157 ~962 ~315 ~157 ~962 minecraft:redstone_wire replace
setblock ~317 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~157 ~962 ~332 ~157 ~962 minecraft:redstone_wire replace
setblock ~334 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~157 ~962 ~349 ~157 ~962 minecraft:redstone_wire replace
setblock ~351 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~353 ~157 ~962 ~366 ~157 ~962 minecraft:redstone_wire replace
setblock ~368 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~157 ~962 ~383 ~157 ~962 minecraft:redstone_wire replace
setblock ~385 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~387 ~157 ~962 ~400 ~157 ~962 minecraft:redstone_wire replace
setblock ~402 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~404 ~157 ~962 ~417 ~157 ~962 minecraft:redstone_wire replace
setblock ~419 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~421 ~157 ~962 ~432 ~157 ~962 minecraft:redstone_wire replace
setblock ~175 ~157 ~963 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~157 ~966 ~172 ~157 ~966 minecraft:redstone_wire replace
setblock ~174 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~966 ~189 ~157 ~966 minecraft:redstone_wire replace
setblock ~191 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~966 ~206 ~157 ~966 minecraft:redstone_wire replace
setblock ~208 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~966 ~223 ~157 ~966 minecraft:redstone_wire replace
setblock ~225 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~966 ~240 ~157 ~966 minecraft:redstone_wire replace
setblock ~242 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~966 ~257 ~157 ~966 minecraft:redstone_wire replace
setblock ~259 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~966 ~274 ~157 ~966 minecraft:redstone_wire replace
setblock ~276 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~966 ~291 ~157 ~966 minecraft:redstone_wire replace
setblock ~293 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~966 ~308 ~157 ~966 minecraft:redstone_wire replace
setblock ~310 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~966 ~325 ~157 ~966 minecraft:redstone_wire replace
setblock ~327 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~966 ~342 ~157 ~966 minecraft:redstone_wire replace
setblock ~344 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~966 ~359 ~157 ~966 minecraft:redstone_wire replace
setblock ~361 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~157 ~966 ~376 ~157 ~966 minecraft:redstone_wire replace
setblock ~378 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~380 ~157 ~966 ~393 ~157 ~966 minecraft:redstone_wire replace
setblock ~395 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~397 ~157 ~966 ~410 ~157 ~966 minecraft:redstone_wire replace
setblock ~412 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~414 ~157 ~966 ~426 ~157 ~966 minecraft:redstone_wire replace
setblock ~169 ~157 ~967 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~157 ~970 ~175 ~157 ~970 minecraft:redstone_wire replace
setblock ~177 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~970 ~192 ~157 ~970 minecraft:redstone_wire replace
setblock ~194 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~970 ~209 ~157 ~970 minecraft:redstone_wire replace
setblock ~211 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~970 ~226 ~157 ~970 minecraft:redstone_wire replace
setblock ~228 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~970 ~243 ~157 ~970 minecraft:redstone_wire replace
setblock ~245 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~970 ~260 ~157 ~970 minecraft:redstone_wire replace
setblock ~262 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~970 ~277 ~157 ~970 minecraft:redstone_wire replace
setblock ~279 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~970 ~294 ~157 ~970 minecraft:redstone_wire replace
setblock ~296 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~970 ~311 ~157 ~970 minecraft:redstone_wire replace
setblock ~313 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~157 ~970 ~328 ~157 ~970 minecraft:redstone_wire replace
setblock ~330 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~332 ~157 ~970 ~345 ~157 ~970 minecraft:redstone_wire replace
setblock ~347 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~349 ~157 ~970 ~362 ~157 ~970 minecraft:redstone_wire replace
setblock ~364 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~366 ~157 ~970 ~379 ~157 ~970 minecraft:redstone_wire replace
setblock ~381 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~383 ~157 ~970 ~396 ~157 ~970 minecraft:redstone_wire replace
setblock ~398 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~400 ~157 ~970 ~413 ~157 ~970 minecraft:redstone_wire replace
