fill ~317 ~165 ~794 ~327 ~165 ~794 minecraft:redstone_wire replace
setblock ~328 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~794 ~339 ~165 ~794 minecraft:redstone_wire replace
setblock ~340 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~794 ~351 ~165 ~794 minecraft:redstone_wire replace
setblock ~352 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~794 ~363 ~165 ~794 minecraft:redstone_wire replace
setblock ~364 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~794 ~375 ~165 ~794 minecraft:redstone_wire replace
setblock ~376 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~794 ~387 ~165 ~794 minecraft:redstone_wire replace
setblock ~388 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~794 ~399 ~165 ~794 minecraft:redstone_wire replace
setblock ~400 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~794 ~411 ~165 ~794 minecraft:redstone_wire replace
setblock ~412 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~794 ~423 ~165 ~794 minecraft:redstone_wire replace
setblock ~424 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~794 ~435 ~165 ~794 minecraft:redstone_wire replace
setblock ~436 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~794 ~447 ~165 ~794 minecraft:redstone_wire replace
setblock ~448 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~794 ~455 ~165 ~794 minecraft:redstone_wire replace
setblock ~139 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~826 ~150 ~165 ~826 minecraft:redstone_wire replace
setblock ~151 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~826 ~162 ~165 ~826 minecraft:redstone_wire replace
setblock ~163 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~826 ~174 ~165 ~826 minecraft:redstone_wire replace
setblock ~175 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~826 ~186 ~165 ~826 minecraft:redstone_wire replace
setblock ~187 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~826 ~198 ~165 ~826 minecraft:redstone_wire replace
setblock ~199 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~826 ~210 ~165 ~826 minecraft:redstone_wire replace
setblock ~211 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~826 ~222 ~165 ~826 minecraft:redstone_wire replace
setblock ~223 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~826 ~234 ~165 ~826 minecraft:redstone_wire replace
setblock ~235 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~826 ~246 ~165 ~826 minecraft:redstone_wire replace
setblock ~247 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~826 ~258 ~165 ~826 minecraft:redstone_wire replace
setblock ~259 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~826 ~270 ~165 ~826 minecraft:redstone_wire replace
setblock ~271 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~826 ~282 ~165 ~826 minecraft:redstone_wire replace
setblock ~283 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~826 ~294 ~165 ~826 minecraft:redstone_wire replace
setblock ~295 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~826 ~306 ~165 ~826 minecraft:redstone_wire replace
setblock ~307 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~826 ~318 ~165 ~826 minecraft:redstone_wire replace
setblock ~319 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~826 ~330 ~165 ~826 minecraft:redstone_wire replace
setblock ~331 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~826 ~342 ~165 ~826 minecraft:redstone_wire replace
setblock ~343 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~826 ~354 ~165 ~826 minecraft:redstone_wire replace
setblock ~355 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~826 ~366 ~165 ~826 minecraft:redstone_wire replace
setblock ~367 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~826 ~378 ~165 ~826 minecraft:redstone_wire replace
setblock ~379 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~826 ~390 ~165 ~826 minecraft:redstone_wire replace
setblock ~391 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~826 ~402 ~165 ~826 minecraft:redstone_wire replace
setblock ~403 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~826 ~414 ~165 ~826 minecraft:redstone_wire replace
setblock ~415 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~826 ~426 ~165 ~826 minecraft:redstone_wire replace
setblock ~427 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~826 ~438 ~165 ~826 minecraft:redstone_wire replace
setblock ~439 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~826 ~450 ~165 ~826 minecraft:redstone_wire replace
setblock ~451 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~826 ~457 ~165 ~826 minecraft:redstone_wire replace
setblock ~142 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~862 ~153 ~165 ~862 minecraft:redstone_wire replace
setblock ~154 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~862 ~165 ~165 ~862 minecraft:redstone_wire replace
setblock ~166 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~862 ~177 ~165 ~862 minecraft:redstone_wire replace
setblock ~178 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~862 ~189 ~165 ~862 minecraft:redstone_wire replace
setblock ~190 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~862 ~201 ~165 ~862 minecraft:redstone_wire replace
setblock ~202 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~862 ~213 ~165 ~862 minecraft:redstone_wire replace
setblock ~214 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~862 ~225 ~165 ~862 minecraft:redstone_wire replace
setblock ~226 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~862 ~237 ~165 ~862 minecraft:redstone_wire replace
setblock ~238 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~862 ~249 ~165 ~862 minecraft:redstone_wire replace
setblock ~250 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~862 ~261 ~165 ~862 minecraft:redstone_wire replace
setblock ~262 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~862 ~273 ~165 ~862 minecraft:redstone_wire replace
setblock ~274 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~862 ~285 ~165 ~862 minecraft:redstone_wire replace
setblock ~286 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~862 ~297 ~165 ~862 minecraft:redstone_wire replace
setblock ~298 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~862 ~309 ~165 ~862 minecraft:redstone_wire replace
setblock ~310 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~862 ~321 ~165 ~862 minecraft:redstone_wire replace
setblock ~322 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~862 ~333 ~165 ~862 minecraft:redstone_wire replace
setblock ~334 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~862 ~345 ~165 ~862 minecraft:redstone_wire replace
setblock ~346 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~862 ~357 ~165 ~862 minecraft:redstone_wire replace
setblock ~358 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~862 ~369 ~165 ~862 minecraft:redstone_wire replace
setblock ~370 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~862 ~381 ~165 ~862 minecraft:redstone_wire replace
setblock ~382 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~862 ~393 ~165 ~862 minecraft:redstone_wire replace
setblock ~394 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~862 ~405 ~165 ~862 minecraft:redstone_wire replace
setblock ~406 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~862 ~417 ~165 ~862 minecraft:redstone_wire replace
setblock ~418 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~862 ~429 ~165 ~862 minecraft:redstone_wire replace
setblock ~430 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~862 ~441 ~165 ~862 minecraft:redstone_wire replace
setblock ~442 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~862 ~453 ~165 ~862 minecraft:redstone_wire replace
setblock ~454 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~862 ~459 ~165 ~862 minecraft:redstone_wire replace
setblock ~145 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~890 ~156 ~165 ~890 minecraft:redstone_wire replace
setblock ~157 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~890 ~168 ~165 ~890 minecraft:redstone_wire replace
setblock ~169 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~890 ~180 ~165 ~890 minecraft:redstone_wire replace
setblock ~181 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~890 ~192 ~165 ~890 minecraft:redstone_wire replace
setblock ~193 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~890 ~204 ~165 ~890 minecraft:redstone_wire replace
setblock ~205 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~890 ~216 ~165 ~890 minecraft:redstone_wire replace
setblock ~217 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~890 ~228 ~165 ~890 minecraft:redstone_wire replace
setblock ~229 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~890 ~240 ~165 ~890 minecraft:redstone_wire replace
setblock ~241 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~890 ~252 ~165 ~890 minecraft:redstone_wire replace
setblock ~253 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~890 ~264 ~165 ~890 minecraft:redstone_wire replace
setblock ~265 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~890 ~276 ~165 ~890 minecraft:redstone_wire replace
setblock ~277 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~890 ~288 ~165 ~890 minecraft:redstone_wire replace
setblock ~289 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~890 ~300 ~165 ~890 minecraft:redstone_wire replace
setblock ~301 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~890 ~312 ~165 ~890 minecraft:redstone_wire replace
setblock ~313 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~890 ~324 ~165 ~890 minecraft:redstone_wire replace
setblock ~325 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~890 ~336 ~165 ~890 minecraft:redstone_wire replace
setblock ~337 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~890 ~348 ~165 ~890 minecraft:redstone_wire replace
setblock ~349 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~890 ~360 ~165 ~890 minecraft:redstone_wire replace
setblock ~361 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~890 ~372 ~165 ~890 minecraft:redstone_wire replace
setblock ~373 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~890 ~384 ~165 ~890 minecraft:redstone_wire replace
setblock ~385 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~890 ~396 ~165 ~890 minecraft:redstone_wire replace
setblock ~397 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~890 ~408 ~165 ~890 minecraft:redstone_wire replace
setblock ~409 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~890 ~420 ~165 ~890 minecraft:redstone_wire replace
setblock ~421 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~890 ~432 ~165 ~890 minecraft:redstone_wire replace
setblock ~433 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~890 ~444 ~165 ~890 minecraft:redstone_wire replace
setblock ~445 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~890 ~456 ~165 ~890 minecraft:redstone_wire replace
setblock ~457 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~890 ~461 ~165 ~890 minecraft:redstone_wire replace
setblock ~148 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~906 ~159 ~165 ~906 minecraft:redstone_wire replace
setblock ~160 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~906 ~171 ~165 ~906 minecraft:redstone_wire replace
setblock ~172 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~906 ~183 ~165 ~906 minecraft:redstone_wire replace
setblock ~184 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~906 ~195 ~165 ~906 minecraft:redstone_wire replace
setblock ~196 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~906 ~207 ~165 ~906 minecraft:redstone_wire replace
setblock ~208 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~906 ~219 ~165 ~906 minecraft:redstone_wire replace
setblock ~220 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~906 ~231 ~165 ~906 minecraft:redstone_wire replace
setblock ~232 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~906 ~243 ~165 ~906 minecraft:redstone_wire replace
setblock ~244 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~906 ~255 ~165 ~906 minecraft:redstone_wire replace
setblock ~256 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~906 ~267 ~165 ~906 minecraft:redstone_wire replace
setblock ~268 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~906 ~279 ~165 ~906 minecraft:redstone_wire replace
setblock ~280 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~906 ~291 ~165 ~906 minecraft:redstone_wire replace
setblock ~292 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~906 ~303 ~165 ~906 minecraft:redstone_wire replace
setblock ~304 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~906 ~315 ~165 ~906 minecraft:redstone_wire replace
setblock ~316 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~906 ~327 ~165 ~906 minecraft:redstone_wire replace
setblock ~328 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~906 ~339 ~165 ~906 minecraft:redstone_wire replace
setblock ~340 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~906 ~351 ~165 ~906 minecraft:redstone_wire replace
setblock ~352 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~906 ~363 ~165 ~906 minecraft:redstone_wire replace
setblock ~364 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~906 ~375 ~165 ~906 minecraft:redstone_wire replace
setblock ~376 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~906 ~387 ~165 ~906 minecraft:redstone_wire replace
setblock ~388 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~906 ~399 ~165 ~906 minecraft:redstone_wire replace
setblock ~400 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~906 ~411 ~165 ~906 minecraft:redstone_wire replace
setblock ~412 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~906 ~423 ~165 ~906 minecraft:redstone_wire replace
setblock ~424 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~906 ~435 ~165 ~906 minecraft:redstone_wire replace
setblock ~436 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~906 ~447 ~165 ~906 minecraft:redstone_wire replace
setblock ~448 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~906 ~459 ~165 ~906 minecraft:redstone_wire replace
setblock ~460 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~906 ~463 ~165 ~906 minecraft:redstone_wire replace
setblock ~151 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~930 ~162 ~165 ~930 minecraft:redstone_wire replace
setblock ~163 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~930 ~174 ~165 ~930 minecraft:redstone_wire replace
setblock ~175 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~930 ~186 ~165 ~930 minecraft:redstone_wire replace
setblock ~187 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~930 ~198 ~165 ~930 minecraft:redstone_wire replace
setblock ~199 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~930 ~210 ~165 ~930 minecraft:redstone_wire replace
setblock ~211 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~930 ~222 ~165 ~930 minecraft:redstone_wire replace
setblock ~223 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~930 ~234 ~165 ~930 minecraft:redstone_wire replace
setblock ~235 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~930 ~246 ~165 ~930 minecraft:redstone_wire replace
setblock ~247 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~930 ~258 ~165 ~930 minecraft:redstone_wire replace
setblock ~259 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~930 ~270 ~165 ~930 minecraft:redstone_wire replace
setblock ~271 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~930 ~282 ~165 ~930 minecraft:redstone_wire replace
setblock ~283 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~930 ~294 ~165 ~930 minecraft:redstone_wire replace
setblock ~295 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~930 ~306 ~165 ~930 minecraft:redstone_wire replace
setblock ~307 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~930 ~318 ~165 ~930 minecraft:redstone_wire replace
setblock ~319 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~930 ~330 ~165 ~930 minecraft:redstone_wire replace
setblock ~331 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~930 ~342 ~165 ~930 minecraft:redstone_wire replace
setblock ~343 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~930 ~354 ~165 ~930 minecraft:redstone_wire replace
setblock ~355 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~930 ~366 ~165 ~930 minecraft:redstone_wire replace
setblock ~367 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~930 ~378 ~165 ~930 minecraft:redstone_wire replace
setblock ~379 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~930 ~390 ~165 ~930 minecraft:redstone_wire replace
setblock ~391 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~930 ~402 ~165 ~930 minecraft:redstone_wire replace
setblock ~403 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~930 ~414 ~165 ~930 minecraft:redstone_wire replace
setblock ~415 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~930 ~426 ~165 ~930 minecraft:redstone_wire replace
setblock ~427 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~930 ~438 ~165 ~930 minecraft:redstone_wire replace
setblock ~439 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~930 ~450 ~165 ~930 minecraft:redstone_wire replace
setblock ~451 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~930 ~462 ~165 ~930 minecraft:redstone_wire replace
setblock ~463 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~930 ~465 ~165 ~930 minecraft:redstone_wire replace
setblock ~172 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~962 ~183 ~165 ~962 minecraft:redstone_wire replace
setblock ~184 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~962 ~195 ~165 ~962 minecraft:redstone_wire replace
setblock ~196 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~962 ~207 ~165 ~962 minecraft:redstone_wire replace
setblock ~208 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~962 ~219 ~165 ~962 minecraft:redstone_wire replace
setblock ~220 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~962 ~231 ~165 ~962 minecraft:redstone_wire replace
setblock ~232 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~962 ~243 ~165 ~962 minecraft:redstone_wire replace
setblock ~244 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~962 ~255 ~165 ~962 minecraft:redstone_wire replace
setblock ~256 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~962 ~267 ~165 ~962 minecraft:redstone_wire replace
setblock ~268 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~962 ~279 ~165 ~962 minecraft:redstone_wire replace
setblock ~280 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~962 ~291 ~165 ~962 minecraft:redstone_wire replace
setblock ~292 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~962 ~303 ~165 ~962 minecraft:redstone_wire replace
setblock ~304 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~962 ~315 ~165 ~962 minecraft:redstone_wire replace
setblock ~316 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~962 ~327 ~165 ~962 minecraft:redstone_wire replace
setblock ~328 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~962 ~339 ~165 ~962 minecraft:redstone_wire replace
setblock ~340 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~962 ~351 ~165 ~962 minecraft:redstone_wire replace
setblock ~352 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~962 ~363 ~165 ~962 minecraft:redstone_wire replace
setblock ~364 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~962 ~375 ~165 ~962 minecraft:redstone_wire replace
setblock ~376 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~962 ~387 ~165 ~962 minecraft:redstone_wire replace
setblock ~388 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~962 ~399 ~165 ~962 minecraft:redstone_wire replace
setblock ~400 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~962 ~411 ~165 ~962 minecraft:redstone_wire replace
setblock ~412 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~962 ~423 ~165 ~962 minecraft:redstone_wire replace
setblock ~424 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~962 ~435 ~165 ~962 minecraft:redstone_wire replace
setblock ~436 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~962 ~447 ~165 ~962 minecraft:redstone_wire replace
setblock ~448 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~962 ~459 ~165 ~962 minecraft:redstone_wire replace
setblock ~460 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~962 ~471 ~165 ~962 minecraft:redstone_wire replace
setblock ~472 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~962 ~483 ~165 ~962 minecraft:redstone_wire replace
setblock ~484 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~485 ~165 ~962 ~495 ~165 ~962 minecraft:redstone_wire replace
setblock ~496 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~497 ~165 ~962 ~501 ~165 ~962 minecraft:redstone_wire replace
setblock ~175 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~966 ~186 ~165 ~966 minecraft:redstone_wire replace
setblock ~187 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~966 ~198 ~165 ~966 minecraft:redstone_wire replace
setblock ~199 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~966 ~210 ~165 ~966 minecraft:redstone_wire replace
setblock ~211 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~966 ~222 ~165 ~966 minecraft:redstone_wire replace
setblock ~223 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~966 ~234 ~165 ~966 minecraft:redstone_wire replace
setblock ~235 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~966 ~246 ~165 ~966 minecraft:redstone_wire replace
setblock ~247 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~966 ~258 ~165 ~966 minecraft:redstone_wire replace
setblock ~259 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~966 ~270 ~165 ~966 minecraft:redstone_wire replace
setblock ~271 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~966 ~282 ~165 ~966 minecraft:redstone_wire replace
setblock ~283 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~966 ~294 ~165 ~966 minecraft:redstone_wire replace
setblock ~295 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~966 ~306 ~165 ~966 minecraft:redstone_wire replace
setblock ~307 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~966 ~318 ~165 ~966 minecraft:redstone_wire replace
setblock ~319 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~966 ~330 ~165 ~966 minecraft:redstone_wire replace
setblock ~331 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~966 ~342 ~165 ~966 minecraft:redstone_wire replace
setblock ~343 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~966 ~354 ~165 ~966 minecraft:redstone_wire replace
setblock ~355 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~966 ~366 ~165 ~966 minecraft:redstone_wire replace
setblock ~367 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~966 ~378 ~165 ~966 minecraft:redstone_wire replace
setblock ~379 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~966 ~390 ~165 ~966 minecraft:redstone_wire replace
setblock ~391 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~966 ~402 ~165 ~966 minecraft:redstone_wire replace
setblock ~403 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~966 ~414 ~165 ~966 minecraft:redstone_wire replace
setblock ~415 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~966 ~426 ~165 ~966 minecraft:redstone_wire replace
setblock ~427 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~966 ~438 ~165 ~966 minecraft:redstone_wire replace
setblock ~439 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~966 ~450 ~165 ~966 minecraft:redstone_wire replace
setblock ~451 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~496 ~166 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~166 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~166 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~166 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~166 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~166 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~166 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~166 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~166 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~166 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~166 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~166 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~166 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~166 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~166 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~166 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~166 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~166 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~166 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~166 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~166 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~166 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~166 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~166 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~166 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~166 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~166 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~166 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~166 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~166 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~166 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~166 ~966 minecraft:redstone_torch[lit=true] replace
setblock ~496 ~168 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~168 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~168 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~168 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~168 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~168 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~168 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~168 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~168 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~168 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~168 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~168 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~168 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~168 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~168 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~168 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~168 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~168 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~168 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~168 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~168 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~168 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~168 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~168 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~168 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~168 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~168 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~168 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~168 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~168 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~168 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~168 ~966 minecraft:redstone_torch[lit=true] replace
fill ~440 ~169 ~3 ~440 ~169 ~8 minecraft:redstone_wire replace
fill ~454 ~169 ~3 ~454 ~169 ~4 minecraft:redstone_wire replace
fill ~468 ~169 ~3 ~468 ~169 ~4 minecraft:redstone_wire replace
fill ~494 ~169 ~3 ~494 ~169 ~8 minecraft:redstone_wire replace
fill ~498 ~169 ~3 ~498 ~169 ~4 minecraft:redstone_wire replace
fill ~450 ~169 ~5 ~450 ~169 ~12 minecraft:redstone_wire replace
setblock ~454 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~484 ~169 ~5 ~484 ~169 ~8 minecraft:redstone_wire replace
setblock ~498 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~500 ~169 ~5 ~500 ~169 ~12 minecraft:redstone_wire replace
fill ~454 ~169 ~6 ~454 ~169 ~16 minecraft:redstone_wire replace
fill ~464 ~169 ~6 ~464 ~169 ~16 minecraft:redstone_wire replace
fill ~468 ~169 ~6 ~468 ~169 ~16 minecraft:redstone_wire replace
fill ~478 ~169 ~6 ~478 ~169 ~16 minecraft:redstone_wire replace
fill ~498 ~169 ~6 ~498 ~169 ~16 minecraft:redstone_wire replace
fill ~442 ~169 ~7 ~442 ~169 ~12 minecraft:redstone_wire replace
fill ~456 ~169 ~7 ~456 ~169 ~12 minecraft:redstone_wire replace
fill ~470 ~169 ~7 ~470 ~169 ~12 minecraft:redstone_wire replace
fill ~492 ~169 ~7 ~492 ~169 ~12 minecraft:redstone_wire replace
fill ~502 ~169 ~7 ~502 ~169 ~12 minecraft:redstone_wire replace
setblock ~440 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~9 ~452 ~169 ~16 minecraft:redstone_wire replace
fill ~466 ~169 ~9 ~466 ~169 ~16 minecraft:redstone_wire replace
fill ~480 ~169 ~9 ~480 ~169 ~16 minecraft:redstone_wire replace
setblock ~482 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~496 ~169 ~9 ~496 ~169 ~12 minecraft:redstone_wire replace
fill ~440 ~169 ~10 ~440 ~169 ~20 minecraft:redstone_wire replace
fill ~482 ~169 ~10 ~482 ~169 ~20 minecraft:redstone_wire replace
fill ~484 ~169 ~10 ~484 ~169 ~20 minecraft:redstone_wire replace
fill ~494 ~169 ~10 ~494 ~169 ~20 minecraft:redstone_wire replace
fill ~448 ~169 ~11 ~448 ~169 ~20 minecraft:redstone_wire replace
fill ~462 ~169 ~11 ~462 ~169 ~12 minecraft:redstone_wire replace
fill ~476 ~169 ~11 ~476 ~169 ~12 minecraft:redstone_wire replace
fill ~486 ~169 ~11 ~486 ~169 ~12 minecraft:redstone_wire replace
setblock ~442 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~444 ~169 ~13 ~444 ~169 ~20 minecraft:redstone_wire replace
setblock ~450 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~13 ~458 ~169 ~20 minecraft:redstone_wire replace
setblock ~462 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~472 ~169 ~13 ~472 ~169 ~20 minecraft:redstone_wire replace
setblock ~476 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~490 ~169 ~13 ~490 ~169 ~16 minecraft:redstone_wire replace
setblock ~492 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~14 ~442 ~169 ~24 minecraft:redstone_wire replace
fill ~450 ~169 ~14 ~450 ~169 ~24 minecraft:redstone_wire replace
fill ~456 ~169 ~14 ~456 ~169 ~24 minecraft:redstone_wire replace
fill ~462 ~169 ~14 ~462 ~169 ~24 minecraft:redstone_wire replace
fill ~470 ~169 ~14 ~470 ~169 ~24 minecraft:redstone_wire replace
fill ~476 ~169 ~14 ~476 ~169 ~24 minecraft:redstone_wire replace
fill ~486 ~169 ~14 ~486 ~169 ~24 minecraft:redstone_wire replace
fill ~492 ~169 ~14 ~492 ~169 ~24 minecraft:redstone_wire replace
fill ~496 ~169 ~14 ~496 ~169 ~24 minecraft:redstone_wire replace
fill ~500 ~169 ~14 ~500 ~169 ~24 minecraft:redstone_wire replace
fill ~502 ~169 ~14 ~502 ~169 ~24 minecraft:redstone_wire replace
fill ~446 ~169 ~15 ~446 ~169 ~16 minecraft:redstone_wire replace
fill ~460 ~169 ~15 ~460 ~169 ~20 minecraft:redstone_wire replace
fill ~474 ~169 ~15 ~474 ~169 ~20 minecraft:redstone_wire replace
fill ~488 ~169 ~15 ~488 ~169 ~16 minecraft:redstone_wire replace
setblock ~446 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~18 ~446 ~169 ~28 minecraft:redstone_wire replace
fill ~452 ~169 ~18 ~452 ~169 ~28 minecraft:redstone_wire replace
fill ~454 ~169 ~18 ~454 ~169 ~28 minecraft:redstone_wire replace
fill ~464 ~169 ~18 ~464 ~169 ~28 minecraft:redstone_wire replace
fill ~466 ~169 ~18 ~466 ~169 ~28 minecraft:redstone_wire replace
fill ~468 ~169 ~18 ~468 ~169 ~28 minecraft:redstone_wire replace
fill ~478 ~169 ~18 ~478 ~169 ~28 minecraft:redstone_wire replace
fill ~480 ~169 ~18 ~480 ~169 ~28 minecraft:redstone_wire replace
fill ~488 ~169 ~18 ~488 ~169 ~28 minecraft:redstone_wire replace
fill ~490 ~169 ~18 ~490 ~169 ~28 minecraft:redstone_wire replace
fill ~498 ~169 ~18 ~498 ~169 ~28 minecraft:redstone_wire replace
setblock ~440 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~22 ~440 ~169 ~32 minecraft:redstone_wire replace
fill ~444 ~169 ~22 ~444 ~169 ~32 minecraft:redstone_wire replace
fill ~448 ~169 ~22 ~448 ~169 ~32 minecraft:redstone_wire replace
fill ~458 ~169 ~22 ~458 ~169 ~32 minecraft:redstone_wire replace
fill ~460 ~169 ~22 ~460 ~169 ~32 minecraft:redstone_wire replace
fill ~472 ~169 ~22 ~472 ~169 ~32 minecraft:redstone_wire replace
fill ~474 ~169 ~22 ~474 ~169 ~32 minecraft:redstone_wire replace
fill ~482 ~169 ~22 ~482 ~169 ~32 minecraft:redstone_wire replace
fill ~484 ~169 ~22 ~484 ~169 ~32 minecraft:redstone_wire replace
fill ~494 ~169 ~22 ~494 ~169 ~32 minecraft:redstone_wire replace
setblock ~442 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~26 ~442 ~169 ~36 minecraft:redstone_wire replace
fill ~450 ~169 ~26 ~450 ~169 ~36 minecraft:redstone_wire replace
fill ~456 ~169 ~26 ~456 ~169 ~36 minecraft:redstone_wire replace
fill ~462 ~169 ~26 ~462 ~169 ~36 minecraft:redstone_wire replace
fill ~470 ~169 ~26 ~470 ~169 ~36 minecraft:redstone_wire replace
fill ~476 ~169 ~26 ~476 ~169 ~36 minecraft:redstone_wire replace
fill ~486 ~169 ~26 ~486 ~169 ~36 minecraft:redstone_wire replace
fill ~492 ~169 ~26 ~492 ~169 ~36 minecraft:redstone_wire replace
fill ~496 ~169 ~26 ~496 ~169 ~36 minecraft:redstone_wire replace
fill ~500 ~169 ~26 ~500 ~169 ~36 minecraft:redstone_wire replace
fill ~502 ~169 ~26 ~502 ~169 ~36 minecraft:redstone_wire replace
setblock ~446 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
