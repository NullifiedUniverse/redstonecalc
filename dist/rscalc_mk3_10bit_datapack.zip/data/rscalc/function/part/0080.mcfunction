setblock ~117 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~261 ~55 ~362 ~261 ~55 ~372 minecraft:redstone_wire replace
fill ~93 ~55 ~364 ~93 ~55 ~376 minecraft:redstone_wire replace
fill ~117 ~55 ~364 ~117 ~55 ~376 minecraft:redstone_wire replace
fill ~138 ~55 ~364 ~138 ~55 ~376 minecraft:redstone_wire replace
fill ~153 ~55 ~364 ~153 ~55 ~376 minecraft:redstone_wire replace
fill ~168 ~55 ~364 ~168 ~55 ~376 minecraft:redstone_wire replace
setblock ~306 ~55 ~364 minecraft:redstone_wire replace
setblock ~306 ~55 ~365 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~306 ~55 ~366 ~306 ~55 ~378 minecraft:redstone_wire replace
setblock ~270 ~55 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~55 ~370 ~270 ~55 ~378 minecraft:redstone_wire replace
setblock ~237 ~55 ~372 minecraft:redstone_wire replace
setblock ~237 ~55 ~374 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~234 ~55 ~376 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~55 ~376 ~237 ~55 ~388 minecraft:redstone_wire replace
setblock ~93 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~234 ~55 ~378 ~234 ~55 ~388 minecraft:redstone_wire replace
setblock ~270 ~55 ~379 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~306 ~55 ~379 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~380 ~93 ~55 ~392 minecraft:redstone_wire replace
fill ~117 ~55 ~380 ~117 ~55 ~392 minecraft:redstone_wire replace
fill ~138 ~55 ~380 ~138 ~55 ~392 minecraft:redstone_wire replace
fill ~153 ~55 ~380 ~153 ~55 ~392 minecraft:redstone_wire replace
fill ~168 ~55 ~380 ~168 ~55 ~392 minecraft:redstone_wire replace
fill ~270 ~55 ~380 ~270 ~55 ~392 minecraft:redstone_wire replace
fill ~306 ~55 ~380 ~306 ~55 ~392 minecraft:redstone_wire replace
fill ~309 ~55 ~392 ~309 ~55 ~396 minecraft:redstone_wire replace
setblock ~93 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~270 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~396 ~93 ~55 ~408 minecraft:redstone_wire replace
fill ~117 ~55 ~396 ~117 ~55 ~408 minecraft:redstone_wire replace
fill ~138 ~55 ~396 ~138 ~55 ~408 minecraft:redstone_wire replace
fill ~153 ~55 ~396 ~153 ~55 ~408 minecraft:redstone_wire replace
fill ~168 ~55 ~396 ~168 ~55 ~408 minecraft:redstone_wire replace
fill ~270 ~55 ~396 ~270 ~55 ~408 minecraft:redstone_wire replace
fill ~276 ~55 ~396 ~276 ~55 ~400 minecraft:redstone_wire replace
fill ~297 ~55 ~400 ~297 ~55 ~404 minecraft:redstone_wire replace
setblock ~93 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~55 ~412 ~90 ~55 ~416 minecraft:redstone_wire replace
fill ~93 ~55 ~412 ~93 ~55 ~424 minecraft:redstone_wire replace
fill ~117 ~55 ~412 ~117 ~55 ~424 minecraft:redstone_wire replace
fill ~138 ~55 ~412 ~138 ~55 ~424 minecraft:redstone_wire replace
fill ~153 ~55 ~412 ~153 ~55 ~424 minecraft:redstone_wire replace
fill ~168 ~55 ~412 ~168 ~55 ~424 minecraft:redstone_wire replace
fill ~114 ~55 ~416 ~114 ~55 ~420 minecraft:redstone_wire replace
fill ~135 ~55 ~420 ~135 ~55 ~424 minecraft:redstone_wire replace
fill ~159 ~55 ~424 ~159 ~55 ~428 minecraft:redstone_wire replace
setblock ~93 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~428 ~93 ~55 ~440 minecraft:redstone_wire replace
fill ~117 ~55 ~428 ~117 ~55 ~440 minecraft:redstone_wire replace
fill ~138 ~55 ~428 ~138 ~55 ~440 minecraft:redstone_wire replace
fill ~153 ~55 ~428 ~153 ~55 ~440 minecraft:redstone_wire replace
fill ~168 ~55 ~428 ~168 ~55 ~440 minecraft:redstone_wire replace
fill ~180 ~55 ~428 ~180 ~55 ~432 minecraft:redstone_wire replace
fill ~204 ~55 ~432 ~204 ~55 ~436 minecraft:redstone_wire replace
fill ~231 ~55 ~436 ~231 ~55 ~440 minecraft:redstone_wire replace
fill ~255 ~55 ~440 ~255 ~55 ~444 minecraft:redstone_wire replace
setblock ~93 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~444 ~93 ~55 ~456 minecraft:redstone_wire replace
fill ~117 ~55 ~444 ~117 ~55 ~456 minecraft:redstone_wire replace
fill ~138 ~55 ~444 ~138 ~55 ~456 minecraft:redstone_wire replace
fill ~153 ~55 ~444 ~153 ~55 ~456 minecraft:redstone_wire replace
fill ~168 ~55 ~444 ~168 ~55 ~456 minecraft:redstone_wire replace
fill ~267 ~55 ~444 ~267 ~55 ~448 minecraft:redstone_wire replace
fill ~87 ~55 ~448 ~87 ~55 ~452 minecraft:redstone_wire replace
fill ~111 ~55 ~452 ~111 ~55 ~456 minecraft:redstone_wire replace
fill ~132 ~55 ~456 ~132 ~55 ~460 minecraft:redstone_wire replace
setblock ~93 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~460 ~93 ~55 ~472 minecraft:redstone_wire replace
fill ~117 ~55 ~460 ~117 ~55 ~472 minecraft:redstone_wire replace
fill ~138 ~55 ~460 ~138 ~55 ~472 minecraft:redstone_wire replace
fill ~153 ~55 ~460 ~153 ~55 ~472 minecraft:redstone_wire replace
fill ~156 ~55 ~460 ~156 ~55 ~464 minecraft:redstone_wire replace
fill ~168 ~55 ~460 ~168 ~55 ~472 minecraft:redstone_wire replace
fill ~177 ~55 ~464 ~177 ~55 ~468 minecraft:redstone_wire replace
fill ~201 ~55 ~468 ~201 ~55 ~472 minecraft:redstone_wire replace
fill ~225 ~55 ~472 ~225 ~55 ~476 minecraft:redstone_wire replace
setblock ~93 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~476 ~93 ~55 ~488 minecraft:redstone_wire replace
fill ~117 ~55 ~476 ~117 ~55 ~488 minecraft:redstone_wire replace
fill ~138 ~55 ~476 ~138 ~55 ~488 minecraft:redstone_wire replace
fill ~153 ~55 ~476 ~153 ~55 ~488 minecraft:redstone_wire replace
fill ~168 ~55 ~476 ~168 ~55 ~488 minecraft:redstone_wire replace
fill ~252 ~55 ~476 ~252 ~55 ~480 minecraft:redstone_wire replace
fill ~288 ~55 ~480 ~288 ~55 ~484 minecraft:redstone_wire replace
fill ~315 ~55 ~484 ~315 ~55 ~488 minecraft:redstone_wire replace
fill ~84 ~55 ~488 ~84 ~55 ~492 minecraft:redstone_wire replace
setblock ~93 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~492 ~93 ~55 ~504 minecraft:redstone_wire replace
fill ~108 ~55 ~492 ~108 ~55 ~496 minecraft:redstone_wire replace
fill ~117 ~55 ~492 ~117 ~55 ~504 minecraft:redstone_wire replace
fill ~138 ~55 ~492 ~138 ~55 ~504 minecraft:redstone_wire replace
fill ~153 ~55 ~492 ~153 ~55 ~504 minecraft:redstone_wire replace
fill ~168 ~55 ~492 ~168 ~55 ~504 minecraft:redstone_wire replace
fill ~129 ~55 ~496 ~129 ~55 ~500 minecraft:redstone_wire replace
fill ~150 ~55 ~500 ~150 ~55 ~504 minecraft:redstone_wire replace
fill ~174 ~55 ~504 ~174 ~55 ~508 minecraft:redstone_wire replace
setblock ~93 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~508 ~93 ~55 ~520 minecraft:redstone_wire replace
fill ~117 ~55 ~508 ~117 ~55 ~520 minecraft:redstone_wire replace
fill ~138 ~55 ~508 ~138 ~55 ~520 minecraft:redstone_wire replace
fill ~153 ~55 ~508 ~153 ~55 ~520 minecraft:redstone_wire replace
fill ~168 ~55 ~508 ~168 ~55 ~520 minecraft:redstone_wire replace
fill ~198 ~55 ~508 ~198 ~55 ~512 minecraft:redstone_wire replace
fill ~222 ~55 ~512 ~222 ~55 ~516 minecraft:redstone_wire replace
fill ~249 ~55 ~516 ~249 ~55 ~520 minecraft:redstone_wire replace
fill ~285 ~55 ~520 ~285 ~55 ~524 minecraft:redstone_wire replace
setblock ~93 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~524 ~93 ~55 ~536 minecraft:redstone_wire replace
fill ~117 ~55 ~524 ~117 ~55 ~536 minecraft:redstone_wire replace
fill ~138 ~55 ~524 ~138 ~55 ~536 minecraft:redstone_wire replace
fill ~153 ~55 ~524 ~153 ~55 ~536 minecraft:redstone_wire replace
fill ~168 ~55 ~524 ~168 ~55 ~536 minecraft:redstone_wire replace
fill ~312 ~55 ~524 ~312 ~55 ~528 minecraft:redstone_wire replace
fill ~81 ~55 ~528 ~81 ~55 ~532 minecraft:redstone_wire replace
fill ~105 ~55 ~532 ~105 ~55 ~536 minecraft:redstone_wire replace
fill ~126 ~55 ~536 ~126 ~55 ~540 minecraft:redstone_wire replace
setblock ~93 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~540 ~93 ~55 ~552 minecraft:redstone_wire replace
fill ~117 ~55 ~540 ~117 ~55 ~552 minecraft:redstone_wire replace
fill ~138 ~55 ~540 ~138 ~55 ~552 minecraft:redstone_wire replace
fill ~147 ~55 ~540 ~147 ~55 ~544 minecraft:redstone_wire replace
fill ~153 ~55 ~540 ~153 ~55 ~552 minecraft:redstone_wire replace
fill ~168 ~55 ~540 ~168 ~55 ~552 minecraft:redstone_wire replace
fill ~171 ~55 ~544 ~171 ~55 ~548 minecraft:redstone_wire replace
fill ~195 ~55 ~548 ~195 ~55 ~552 minecraft:redstone_wire replace
fill ~219 ~55 ~552 ~219 ~55 ~556 minecraft:redstone_wire replace
setblock ~93 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~556 ~93 ~55 ~568 minecraft:redstone_wire replace
fill ~117 ~55 ~556 ~117 ~55 ~568 minecraft:redstone_wire replace
fill ~138 ~55 ~556 ~138 ~55 ~568 minecraft:redstone_wire replace
fill ~153 ~55 ~556 ~153 ~55 ~568 minecraft:redstone_wire replace
fill ~168 ~55 ~556 ~168 ~55 ~568 minecraft:redstone_wire replace
fill ~243 ~55 ~556 ~243 ~55 ~560 minecraft:redstone_wire replace
fill ~282 ~55 ~560 ~282 ~55 ~564 minecraft:redstone_wire replace
fill ~303 ~55 ~564 ~303 ~55 ~568 minecraft:redstone_wire replace
fill ~78 ~55 ~568 ~78 ~55 ~572 minecraft:redstone_wire replace
setblock ~93 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~572 ~93 ~55 ~584 minecraft:redstone_wire replace
fill ~102 ~55 ~572 ~102 ~55 ~576 minecraft:redstone_wire replace
fill ~117 ~55 ~572 ~117 ~55 ~584 minecraft:redstone_wire replace
fill ~138 ~55 ~572 ~138 ~55 ~584 minecraft:redstone_wire replace
fill ~153 ~55 ~572 ~153 ~55 ~584 minecraft:redstone_wire replace
fill ~168 ~55 ~572 ~168 ~55 ~584 minecraft:redstone_wire replace
fill ~123 ~55 ~576 ~123 ~55 ~580 minecraft:redstone_wire replace
fill ~144 ~55 ~580 ~144 ~55 ~584 minecraft:redstone_wire replace
fill ~165 ~55 ~584 ~165 ~55 ~588 minecraft:redstone_wire replace
setblock ~93 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~588 ~93 ~55 ~600 minecraft:redstone_wire replace
fill ~117 ~55 ~588 ~117 ~55 ~600 minecraft:redstone_wire replace
fill ~138 ~55 ~588 ~138 ~55 ~600 minecraft:redstone_wire replace
fill ~153 ~55 ~588 ~153 ~55 ~600 minecraft:redstone_wire replace
fill ~168 ~55 ~588 ~168 ~55 ~600 minecraft:redstone_wire replace
fill ~186 ~55 ~588 ~186 ~55 ~592 minecraft:redstone_wire replace
fill ~216 ~55 ~592 ~216 ~55 ~596 minecraft:redstone_wire replace
fill ~240 ~55 ~596 ~240 ~55 ~600 minecraft:redstone_wire replace
fill ~279 ~55 ~600 ~279 ~55 ~604 minecraft:redstone_wire replace
setblock ~93 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~604 ~93 ~55 ~616 minecraft:redstone_wire replace
fill ~117 ~55 ~604 ~117 ~55 ~616 minecraft:redstone_wire replace
fill ~138 ~55 ~604 ~138 ~55 ~616 minecraft:redstone_wire replace
fill ~153 ~55 ~604 ~153 ~55 ~616 minecraft:redstone_wire replace
fill ~168 ~55 ~604 ~168 ~55 ~616 minecraft:redstone_wire replace
fill ~300 ~55 ~604 ~300 ~55 ~608 minecraft:redstone_wire replace
fill ~99 ~55 ~608 ~99 ~55 ~612 minecraft:redstone_wire replace
fill ~120 ~55 ~612 ~120 ~55 ~616 minecraft:redstone_wire replace
fill ~141 ~55 ~616 ~141 ~55 ~620 minecraft:redstone_wire replace
setblock ~93 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~620 ~93 ~55 ~632 minecraft:redstone_wire replace
fill ~117 ~55 ~620 ~117 ~55 ~632 minecraft:redstone_wire replace
fill ~138 ~55 ~620 ~138 ~55 ~632 minecraft:redstone_wire replace
fill ~153 ~55 ~620 ~153 ~55 ~632 minecraft:redstone_wire replace
fill ~162 ~55 ~620 ~162 ~55 ~624 minecraft:redstone_wire replace
fill ~168 ~55 ~620 ~168 ~55 ~632 minecraft:redstone_wire replace
fill ~183 ~55 ~624 ~183 ~55 ~628 minecraft:redstone_wire replace
fill ~207 ~55 ~628 ~207 ~55 ~632 minecraft:redstone_wire replace
fill ~246 ~55 ~632 ~246 ~55 ~636 minecraft:redstone_wire replace
setblock ~93 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~636 ~93 ~55 ~648 minecraft:redstone_wire replace
fill ~117 ~55 ~636 ~117 ~55 ~648 minecraft:redstone_wire replace
fill ~138 ~55 ~636 ~138 ~55 ~648 minecraft:redstone_wire replace
fill ~153 ~55 ~636 ~153 ~55 ~648 minecraft:redstone_wire replace
fill ~168 ~55 ~636 ~168 ~55 ~648 minecraft:redstone_wire replace
fill ~258 ~55 ~636 ~258 ~55 ~640 minecraft:redstone_wire replace
fill ~291 ~55 ~640 ~291 ~55 ~644 minecraft:redstone_wire replace
fill ~228 ~55 ~644 ~228 ~55 ~648 minecraft:redstone_wire replace
fill ~321 ~55 ~648 ~321 ~55 ~652 minecraft:redstone_wire replace
fill ~96 ~55 ~652 ~96 ~55 ~656 minecraft:redstone_wire replace
fill ~294 ~55 ~656 ~294 ~55 ~660 minecraft:redstone_wire replace
fill ~318 ~55 ~660 ~318 ~55 ~664 minecraft:redstone_wire replace
setblock ~273 ~56 ~75 minecraft:redstone_wire replace
setblock ~93 ~56 ~247 minecraft:redstone_wire replace
setblock ~117 ~56 ~267 minecraft:redstone_wire replace
setblock ~138 ~56 ~283 minecraft:redstone_wire replace
setblock ~153 ~56 ~295 minecraft:redstone_wire replace
setblock ~168 ~56 ~319 minecraft:redstone_wire replace
setblock ~192 ~56 ~323 minecraft:redstone_wire replace
setblock ~189 ~56 ~327 minecraft:redstone_wire replace
setblock ~213 ~56 ~339 minecraft:redstone_wire replace
setblock ~210 ~56 ~343 minecraft:redstone_wire replace
setblock ~264 ~56 ~355 minecraft:redstone_wire replace
setblock ~261 ~56 ~359 minecraft:redstone_wire replace
setblock ~306 ~56 ~363 minecraft:redstone_wire replace
setblock ~270 ~56 ~367 minecraft:redstone_wire replace
setblock ~237 ~56 ~371 minecraft:redstone_wire replace
setblock ~234 ~56 ~375 minecraft:redstone_wire replace
setblock ~309 ~56 ~391 minecraft:redstone_wire replace
setblock ~276 ~56 ~395 minecraft:redstone_wire replace
setblock ~297 ~56 ~399 minecraft:redstone_wire replace
setblock ~90 ~56 ~411 minecraft:redstone_wire replace
setblock ~114 ~56 ~415 minecraft:redstone_wire replace
setblock ~135 ~56 ~419 minecraft:redstone_wire replace
setblock ~159 ~56 ~423 minecraft:redstone_wire replace
setblock ~180 ~56 ~427 minecraft:redstone_wire replace
setblock ~204 ~56 ~431 minecraft:redstone_wire replace
setblock ~231 ~56 ~435 minecraft:redstone_wire replace
setblock ~255 ~56 ~439 minecraft:redstone_wire replace
setblock ~267 ~56 ~443 minecraft:redstone_wire replace
setblock ~87 ~56 ~447 minecraft:redstone_wire replace
setblock ~111 ~56 ~451 minecraft:redstone_wire replace
setblock ~132 ~56 ~455 minecraft:redstone_wire replace
setblock ~156 ~56 ~459 minecraft:redstone_wire replace
setblock ~177 ~56 ~463 minecraft:redstone_wire replace
setblock ~201 ~56 ~467 minecraft:redstone_wire replace
setblock ~225 ~56 ~471 minecraft:redstone_wire replace
setblock ~252 ~56 ~475 minecraft:redstone_wire replace
setblock ~288 ~56 ~479 minecraft:redstone_wire replace
setblock ~315 ~56 ~483 minecraft:redstone_wire replace
setblock ~84 ~56 ~487 minecraft:redstone_wire replace
setblock ~108 ~56 ~491 minecraft:redstone_wire replace
setblock ~129 ~56 ~495 minecraft:redstone_wire replace
setblock ~150 ~56 ~499 minecraft:redstone_wire replace
setblock ~174 ~56 ~503 minecraft:redstone_wire replace
setblock ~198 ~56 ~507 minecraft:redstone_wire replace
setblock ~222 ~56 ~511 minecraft:redstone_wire replace
setblock ~249 ~56 ~515 minecraft:redstone_wire replace
setblock ~285 ~56 ~519 minecraft:redstone_wire replace
setblock ~312 ~56 ~523 minecraft:redstone_wire replace
setblock ~81 ~56 ~527 minecraft:redstone_wire replace
setblock ~105 ~56 ~531 minecraft:redstone_wire replace
setblock ~126 ~56 ~535 minecraft:redstone_wire replace
setblock ~147 ~56 ~539 minecraft:redstone_wire replace
setblock ~171 ~56 ~543 minecraft:redstone_wire replace
setblock ~195 ~56 ~547 minecraft:redstone_wire replace
setblock ~219 ~56 ~551 minecraft:redstone_wire replace
setblock ~243 ~56 ~555 minecraft:redstone_wire replace
setblock ~282 ~56 ~559 minecraft:redstone_wire replace
setblock ~303 ~56 ~563 minecraft:redstone_wire replace
setblock ~78 ~56 ~567 minecraft:redstone_wire replace
setblock ~102 ~56 ~571 minecraft:redstone_wire replace
setblock ~123 ~56 ~575 minecraft:redstone_wire replace
setblock ~144 ~56 ~579 minecraft:redstone_wire replace
setblock ~165 ~56 ~583 minecraft:redstone_wire replace
setblock ~186 ~56 ~587 minecraft:redstone_wire replace
setblock ~216 ~56 ~591 minecraft:redstone_wire replace
setblock ~240 ~56 ~595 minecraft:redstone_wire replace
setblock ~279 ~56 ~599 minecraft:redstone_wire replace
setblock ~300 ~56 ~603 minecraft:redstone_wire replace
setblock ~99 ~56 ~607 minecraft:redstone_wire replace
setblock ~120 ~56 ~611 minecraft:redstone_wire replace
setblock ~141 ~56 ~615 minecraft:redstone_wire replace
setblock ~162 ~56 ~619 minecraft:redstone_wire replace
setblock ~183 ~56 ~623 minecraft:redstone_wire replace
setblock ~207 ~56 ~627 minecraft:redstone_wire replace
setblock ~246 ~56 ~631 minecraft:redstone_wire replace
setblock ~258 ~56 ~635 minecraft:redstone_wire replace
setblock ~291 ~56 ~639 minecraft:redstone_wire replace
setblock ~228 ~56 ~643 minecraft:redstone_wire replace
setblock ~321 ~56 ~647 minecraft:redstone_wire replace
setblock ~96 ~56 ~651 minecraft:redstone_wire replace
setblock ~294 ~56 ~655 minecraft:redstone_wire replace
setblock ~318 ~56 ~659 minecraft:redstone_wire replace
setblock ~169 ~57 ~73 minecraft:redstone_wire replace
fill ~168 ~57 ~74 ~178 ~57 ~74 minecraft:redstone_wire replace
setblock ~180 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~57 ~74 ~195 ~57 ~74 minecraft:redstone_wire replace
setblock ~197 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~57 ~74 ~212 ~57 ~74 minecraft:redstone_wire replace
setblock ~214 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~57 ~74 ~229 ~57 ~74 minecraft:redstone_wire replace
setblock ~231 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~233 ~57 ~74 ~246 ~57 ~74 minecraft:redstone_wire replace
setblock ~248 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~57 ~74 ~263 ~57 ~74 minecraft:redstone_wire replace
setblock ~265 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~57 ~74 ~273 ~57 ~74 minecraft:redstone_wire replace
setblock ~79 ~57 ~245 minecraft:redstone_wire replace
fill ~78 ~57 ~246 ~80 ~57 ~246 minecraft:redstone_wire replace
setblock ~82 ~57 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~84 ~57 ~246 ~93 ~57 ~246 minecraft:redstone_wire replace
setblock ~82 ~57 ~265 minecraft:redstone_wire replace
fill ~81 ~57 ~266 ~84 ~57 ~266 minecraft:redstone_wire replace
setblock ~86 ~57 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~57 ~266 ~101 ~57 ~266 minecraft:redstone_wire replace
setblock ~103 ~57 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~266 ~117 ~57 ~266 minecraft:redstone_wire replace
setblock ~85 ~57 ~281 minecraft:redstone_wire replace
fill ~84 ~57 ~282 ~88 ~57 ~282 minecraft:redstone_wire replace
setblock ~90 ~57 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~57 ~282 ~105 ~57 ~282 minecraft:redstone_wire replace
setblock ~107 ~57 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~57 ~282 ~122 ~57 ~282 minecraft:redstone_wire replace
setblock ~124 ~57 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~282 ~138 ~57 ~282 minecraft:redstone_wire replace
setblock ~88 ~57 ~293 minecraft:redstone_wire replace
fill ~87 ~57 ~294 ~89 ~57 ~294 minecraft:redstone_wire replace
setblock ~91 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~57 ~294 ~106 ~57 ~294 minecraft:redstone_wire replace
setblock ~108 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~57 ~294 ~123 ~57 ~294 minecraft:redstone_wire replace
setblock ~125 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~57 ~294 ~140 ~57 ~294 minecraft:redstone_wire replace
setblock ~142 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~57 ~294 ~153 ~57 ~294 minecraft:redstone_wire replace
setblock ~91 ~57 ~317 minecraft:redstone_wire replace
fill ~90 ~57 ~318 ~101 ~57 ~318 minecraft:redstone_wire replace
setblock ~103 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~318 ~118 ~57 ~318 minecraft:redstone_wire replace
setblock ~120 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~57 ~318 ~135 ~57 ~318 minecraft:redstone_wire replace
setblock ~137 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~57 ~318 ~152 ~57 ~318 minecraft:redstone_wire replace
setblock ~154 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~57 ~318 ~168 ~57 ~318 minecraft:redstone_wire replace
setblock ~100 ~57 ~321 minecraft:redstone_wire replace
fill ~99 ~57 ~322 ~100 ~57 ~322 minecraft:redstone_wire replace
setblock ~101 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~57 ~322 ~115 ~57 ~322 minecraft:redstone_wire replace
setblock ~117 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~57 ~322 ~132 ~57 ~322 minecraft:redstone_wire replace
setblock ~134 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~57 ~322 ~149 ~57 ~322 minecraft:redstone_wire replace
setblock ~151 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~57 ~322 ~166 ~57 ~322 minecraft:redstone_wire replace
setblock ~168 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~57 ~322 ~183 ~57 ~322 minecraft:redstone_wire replace
setblock ~185 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~57 ~322 ~192 ~57 ~322 minecraft:redstone_wire replace
setblock ~100 ~57 ~325 minecraft:redstone_wire replace
fill ~99 ~57 ~326 ~108 ~57 ~326 minecraft:redstone_wire replace
setblock ~110 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~57 ~326 ~125 ~57 ~326 minecraft:redstone_wire replace
setblock ~127 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~326 ~142 ~57 ~326 minecraft:redstone_wire replace
setblock ~144 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~57 ~326 ~159 ~57 ~326 minecraft:redstone_wire replace
setblock ~161 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~57 ~326 ~176 ~57 ~326 minecraft:redstone_wire replace
setblock ~178 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~57 ~326 ~189 ~57 ~326 minecraft:redstone_wire replace
setblock ~118 ~57 ~337 minecraft:redstone_wire replace
fill ~117 ~57 ~338 ~119 ~57 ~338 minecraft:redstone_wire replace
setblock ~121 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~57 ~338 ~136 ~57 ~338 minecraft:redstone_wire replace
setblock ~138 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~57 ~338 ~153 ~57 ~338 minecraft:redstone_wire replace
setblock ~155 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~57 ~338 ~170 ~57 ~338 minecraft:redstone_wire replace
setblock ~172 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~338 ~187 ~57 ~338 minecraft:redstone_wire replace
setblock ~189 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~57 ~338 ~204 ~57 ~338 minecraft:redstone_wire replace
setblock ~206 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~57 ~338 ~213 ~57 ~338 minecraft:redstone_wire replace
setblock ~118 ~57 ~341 minecraft:redstone_wire replace
fill ~117 ~57 ~342 ~129 ~57 ~342 minecraft:redstone_wire replace
setblock ~131 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~57 ~342 ~146 ~57 ~342 minecraft:redstone_wire replace
setblock ~148 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~57 ~342 ~163 ~57 ~342 minecraft:redstone_wire replace
setblock ~165 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~57 ~342 ~180 ~57 ~342 minecraft:redstone_wire replace
setblock ~182 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~57 ~342 ~197 ~57 ~342 minecraft:redstone_wire replace
setblock ~199 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~57 ~342 ~210 ~57 ~342 minecraft:redstone_wire replace
setblock ~163 ~57 ~353 minecraft:redstone_wire replace
fill ~162 ~57 ~354 ~164 ~57 ~354 minecraft:redstone_wire replace
setblock ~166 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~57 ~354 ~181 ~57 ~354 minecraft:redstone_wire replace
setblock ~183 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~57 ~354 ~198 ~57 ~354 minecraft:redstone_wire replace
setblock ~200 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~354 ~215 ~57 ~354 minecraft:redstone_wire replace
setblock ~217 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~57 ~354 ~232 ~57 ~354 minecraft:redstone_wire replace
setblock ~234 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~57 ~354 ~249 ~57 ~354 minecraft:redstone_wire replace
setblock ~251 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~57 ~354 ~264 ~57 ~354 minecraft:redstone_wire replace
setblock ~163 ~57 ~357 minecraft:redstone_wire replace
fill ~162 ~57 ~358 ~166 ~57 ~358 minecraft:redstone_wire replace
setblock ~168 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~57 ~358 ~182 ~57 ~358 minecraft:redstone_wire replace
setblock ~184 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~57 ~358 ~198 ~57 ~358 minecraft:redstone_wire replace
setblock ~200 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~358 ~214 ~57 ~358 minecraft:redstone_wire replace
setblock ~216 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~57 ~358 ~230 ~57 ~358 minecraft:redstone_wire replace
setblock ~232 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~57 ~358 ~246 ~57 ~358 minecraft:redstone_wire replace
setblock ~248 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~57 ~358 ~261 ~57 ~358 minecraft:redstone_wire replace
setblock ~199 ~57 ~361 minecraft:redstone_wire replace
fill ~198 ~57 ~362 ~206 ~57 ~362 minecraft:redstone_wire replace
setblock ~208 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~362 ~223 ~57 ~362 minecraft:redstone_wire replace
setblock ~225 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~57 ~362 ~240 ~57 ~362 minecraft:redstone_wire replace
setblock ~242 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~57 ~362 ~257 ~57 ~362 minecraft:redstone_wire replace
setblock ~259 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~57 ~362 ~274 ~57 ~362 minecraft:redstone_wire replace
setblock ~276 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~57 ~362 ~291 ~57 ~362 minecraft:redstone_wire replace
setblock ~293 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~57 ~362 ~306 ~57 ~362 minecraft:redstone_wire replace
setblock ~169 ~57 ~365 minecraft:redstone_wire replace
fill ~168 ~57 ~366 ~169 ~57 ~366 minecraft:redstone_wire replace
setblock ~171 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~57 ~366 ~186 ~57 ~366 minecraft:redstone_wire replace
setblock ~188 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~57 ~366 ~203 ~57 ~366 minecraft:redstone_wire replace
setblock ~205 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~57 ~366 ~220 ~57 ~366 minecraft:redstone_wire replace
setblock ~222 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~57 ~366 ~237 ~57 ~366 minecraft:redstone_wire replace
setblock ~239 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~57 ~366 ~254 ~57 ~366 minecraft:redstone_wire replace
setblock ~256 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~57 ~366 ~270 ~57 ~366 minecraft:redstone_wire replace
setblock ~139 ~57 ~369 minecraft:redstone_wire replace
fill ~138 ~57 ~370 ~139 ~57 ~370 minecraft:redstone_wire replace
setblock ~140 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~57 ~370 ~154 ~57 ~370 minecraft:redstone_wire replace
setblock ~156 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~57 ~370 ~171 ~57 ~370 minecraft:redstone_wire replace
setblock ~173 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~57 ~370 ~188 ~57 ~370 minecraft:redstone_wire replace
setblock ~190 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~57 ~370 ~205 ~57 ~370 minecraft:redstone_wire replace
setblock ~207 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~57 ~370 ~222 ~57 ~370 minecraft:redstone_wire replace
setblock ~224 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~57 ~370 ~237 ~57 ~370 minecraft:redstone_wire replace
setblock ~139 ~57 ~373 minecraft:redstone_wire replace
fill ~138 ~57 ~374 ~150 ~57 ~374 minecraft:redstone_wire replace
setblock ~152 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~374 ~167 ~57 ~374 minecraft:redstone_wire replace
setblock ~169 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~57 ~374 ~184 ~57 ~374 minecraft:redstone_wire replace
setblock ~186 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~57 ~374 ~201 ~57 ~374 minecraft:redstone_wire replace
setblock ~203 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~57 ~374 ~218 ~57 ~374 minecraft:redstone_wire replace
setblock ~220 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~57 ~374 ~234 ~57 ~374 minecraft:redstone_wire replace
setblock ~199 ~57 ~389 minecraft:redstone_wire replace
fill ~198 ~57 ~390 ~199 ~57 ~390 minecraft:redstone_wire replace
setblock ~200 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~57 ~390 ~214 ~57 ~390 minecraft:redstone_wire replace
setblock ~216 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~57 ~390 ~231 ~57 ~390 minecraft:redstone_wire replace
setblock ~233 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~57 ~390 ~248 ~57 ~390 minecraft:redstone_wire replace
setblock ~250 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~57 ~390 ~265 ~57 ~390 minecraft:redstone_wire replace
setblock ~267 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~57 ~390 ~282 ~57 ~390 minecraft:redstone_wire replace
setblock ~284 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~57 ~390 ~299 ~57 ~390 minecraft:redstone_wire replace
setblock ~301 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~57 ~390 ~309 ~57 ~390 minecraft:redstone_wire replace
setblock ~169 ~57 ~393 minecraft:redstone_wire replace
fill ~168 ~57 ~394 ~181 ~57 ~394 minecraft:redstone_wire replace
setblock ~183 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~57 ~394 ~198 ~57 ~394 minecraft:redstone_wire replace
setblock ~200 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~394 ~215 ~57 ~394 minecraft:redstone_wire replace
setblock ~217 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~57 ~394 ~232 ~57 ~394 minecraft:redstone_wire replace
setblock ~234 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~57 ~394 ~249 ~57 ~394 minecraft:redstone_wire replace
setblock ~251 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~57 ~394 ~266 ~57 ~394 minecraft:redstone_wire replace
setblock ~268 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~57 ~394 ~276 ~57 ~394 minecraft:redstone_wire replace
setblock ~190 ~57 ~397 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~57 ~398 ~202 ~57 ~398 minecraft:redstone_wire replace
setblock ~204 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~57 ~398 ~219 ~57 ~398 minecraft:redstone_wire replace
setblock ~221 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~57 ~398 ~236 ~57 ~398 minecraft:redstone_wire replace
setblock ~238 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~57 ~398 ~253 ~57 ~398 minecraft:redstone_wire replace
setblock ~255 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~57 ~398 ~270 ~57 ~398 minecraft:redstone_wire replace
setblock ~272 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~57 ~398 ~287 ~57 ~398 minecraft:redstone_wire replace
setblock ~289 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~57 ~398 ~297 ~57 ~398 minecraft:redstone_wire replace
setblock ~79 ~57 ~409 minecraft:redstone_wire replace
fill ~78 ~57 ~410 ~80 ~57 ~410 minecraft:redstone_wire replace
setblock ~82 ~57 ~410 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~84 ~57 ~410 ~90 ~57 ~410 minecraft:redstone_wire replace
setblock ~82 ~57 ~413 minecraft:redstone_wire replace
fill ~81 ~57 ~414 ~87 ~57 ~414 minecraft:redstone_wire replace
setblock ~89 ~57 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~91 ~57 ~414 ~104 ~57 ~414 minecraft:redstone_wire replace
setblock ~106 ~57 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~57 ~414 ~114 ~57 ~414 minecraft:redstone_wire replace
setblock ~85 ~57 ~417 minecraft:redstone_wire replace
fill ~84 ~57 ~418 ~91 ~57 ~418 minecraft:redstone_wire replace
setblock ~93 ~57 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~57 ~418 ~108 ~57 ~418 minecraft:redstone_wire replace
setblock ~110 ~57 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~57 ~418 ~125 ~57 ~418 minecraft:redstone_wire replace
setblock ~127 ~57 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~418 ~135 ~57 ~418 minecraft:redstone_wire replace
setblock ~88 ~57 ~421 minecraft:redstone_wire replace
fill ~87 ~57 ~422 ~98 ~57 ~422 minecraft:redstone_wire replace
setblock ~100 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~57 ~422 ~115 ~57 ~422 minecraft:redstone_wire replace
setblock ~117 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~57 ~422 ~132 ~57 ~422 minecraft:redstone_wire replace
setblock ~134 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~57 ~422 ~149 ~57 ~422 minecraft:redstone_wire replace
