setblock ~426 ~155 ~838 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~840 ~426 ~155 ~852 minecraft:redstone_wire replace
setblock ~429 ~155 ~846 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~846 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~848 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~848 ~429 ~155 ~860 minecraft:redstone_wire replace
fill ~432 ~155 ~848 ~432 ~155 ~860 minecraft:redstone_wire replace
setblock ~321 ~155 ~851 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~852 minecraft:redstone_wire replace
setblock ~324 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~155 ~854 ~324 ~155 ~856 minecraft:redstone_wire replace
fill ~327 ~155 ~854 ~327 ~155 ~860 minecraft:redstone_wire replace
fill ~330 ~155 ~854 ~330 ~155 ~862 minecraft:redstone_wire replace
fill ~333 ~155 ~854 ~333 ~155 ~866 minecraft:redstone_wire replace
fill ~336 ~155 ~854 ~336 ~155 ~866 minecraft:redstone_wire replace
fill ~339 ~155 ~854 ~339 ~155 ~866 minecraft:redstone_wire replace
fill ~342 ~155 ~854 ~342 ~155 ~866 minecraft:redstone_wire replace
fill ~345 ~155 ~854 ~345 ~155 ~866 minecraft:redstone_wire replace
fill ~348 ~155 ~854 ~348 ~155 ~866 minecraft:redstone_wire replace
fill ~351 ~155 ~854 ~351 ~155 ~866 minecraft:redstone_wire replace
fill ~354 ~155 ~854 ~354 ~155 ~866 minecraft:redstone_wire replace
fill ~357 ~155 ~854 ~357 ~155 ~866 minecraft:redstone_wire replace
fill ~360 ~155 ~854 ~360 ~155 ~866 minecraft:redstone_wire replace
fill ~363 ~155 ~854 ~363 ~155 ~866 minecraft:redstone_wire replace
fill ~366 ~155 ~854 ~366 ~155 ~866 minecraft:redstone_wire replace
fill ~369 ~155 ~854 ~369 ~155 ~866 minecraft:redstone_wire replace
fill ~372 ~155 ~854 ~372 ~155 ~866 minecraft:redstone_wire replace
fill ~375 ~155 ~854 ~375 ~155 ~866 minecraft:redstone_wire replace
fill ~378 ~155 ~854 ~378 ~155 ~866 minecraft:redstone_wire replace
fill ~381 ~155 ~854 ~381 ~155 ~866 minecraft:redstone_wire replace
fill ~384 ~155 ~854 ~384 ~155 ~866 minecraft:redstone_wire replace
fill ~387 ~155 ~854 ~387 ~155 ~866 minecraft:redstone_wire replace
fill ~390 ~155 ~854 ~390 ~155 ~866 minecraft:redstone_wire replace
fill ~393 ~155 ~854 ~393 ~155 ~866 minecraft:redstone_wire replace
fill ~396 ~155 ~854 ~396 ~155 ~866 minecraft:redstone_wire replace
fill ~399 ~155 ~854 ~399 ~155 ~866 minecraft:redstone_wire replace
setblock ~426 ~155 ~854 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~856 ~426 ~155 ~868 minecraft:redstone_wire replace
setblock ~429 ~155 ~862 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~862 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~864 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~864 ~429 ~155 ~876 minecraft:redstone_wire replace
fill ~432 ~155 ~864 ~432 ~155 ~876 minecraft:redstone_wire replace
setblock ~333 ~155 ~867 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~868 minecraft:redstone_wire replace
setblock ~336 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~155 ~870 ~336 ~155 ~872 minecraft:redstone_wire replace
fill ~339 ~155 ~870 ~339 ~155 ~876 minecraft:redstone_wire replace
fill ~342 ~155 ~870 ~342 ~155 ~878 minecraft:redstone_wire replace
fill ~345 ~155 ~870 ~345 ~155 ~882 minecraft:redstone_wire replace
fill ~348 ~155 ~870 ~348 ~155 ~882 minecraft:redstone_wire replace
fill ~351 ~155 ~870 ~351 ~155 ~882 minecraft:redstone_wire replace
fill ~354 ~155 ~870 ~354 ~155 ~882 minecraft:redstone_wire replace
fill ~357 ~155 ~870 ~357 ~155 ~882 minecraft:redstone_wire replace
fill ~360 ~155 ~870 ~360 ~155 ~882 minecraft:redstone_wire replace
fill ~363 ~155 ~870 ~363 ~155 ~882 minecraft:redstone_wire replace
fill ~366 ~155 ~870 ~366 ~155 ~882 minecraft:redstone_wire replace
fill ~369 ~155 ~870 ~369 ~155 ~882 minecraft:redstone_wire replace
fill ~372 ~155 ~870 ~372 ~155 ~882 minecraft:redstone_wire replace
fill ~375 ~155 ~870 ~375 ~155 ~882 minecraft:redstone_wire replace
fill ~378 ~155 ~870 ~378 ~155 ~882 minecraft:redstone_wire replace
fill ~381 ~155 ~870 ~381 ~155 ~882 minecraft:redstone_wire replace
fill ~384 ~155 ~870 ~384 ~155 ~882 minecraft:redstone_wire replace
fill ~387 ~155 ~870 ~387 ~155 ~882 minecraft:redstone_wire replace
fill ~390 ~155 ~870 ~390 ~155 ~882 minecraft:redstone_wire replace
fill ~393 ~155 ~870 ~393 ~155 ~882 minecraft:redstone_wire replace
fill ~396 ~155 ~870 ~396 ~155 ~882 minecraft:redstone_wire replace
fill ~399 ~155 ~870 ~399 ~155 ~882 minecraft:redstone_wire replace
setblock ~426 ~155 ~870 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~872 ~426 ~155 ~884 minecraft:redstone_wire replace
setblock ~429 ~155 ~878 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~878 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~880 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~880 ~429 ~155 ~892 minecraft:redstone_wire replace
fill ~432 ~155 ~880 ~432 ~155 ~892 minecraft:redstone_wire replace
setblock ~345 ~155 ~883 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~884 minecraft:redstone_wire replace
setblock ~348 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~155 ~886 ~348 ~155 ~888 minecraft:redstone_wire replace
fill ~351 ~155 ~886 ~351 ~155 ~892 minecraft:redstone_wire replace
fill ~354 ~155 ~886 ~354 ~155 ~894 minecraft:redstone_wire replace
fill ~357 ~155 ~886 ~357 ~155 ~898 minecraft:redstone_wire replace
fill ~360 ~155 ~886 ~360 ~155 ~898 minecraft:redstone_wire replace
fill ~363 ~155 ~886 ~363 ~155 ~898 minecraft:redstone_wire replace
fill ~366 ~155 ~886 ~366 ~155 ~898 minecraft:redstone_wire replace
fill ~369 ~155 ~886 ~369 ~155 ~898 minecraft:redstone_wire replace
fill ~372 ~155 ~886 ~372 ~155 ~898 minecraft:redstone_wire replace
fill ~375 ~155 ~886 ~375 ~155 ~898 minecraft:redstone_wire replace
fill ~378 ~155 ~886 ~378 ~155 ~898 minecraft:redstone_wire replace
fill ~381 ~155 ~886 ~381 ~155 ~898 minecraft:redstone_wire replace
fill ~384 ~155 ~886 ~384 ~155 ~898 minecraft:redstone_wire replace
fill ~387 ~155 ~886 ~387 ~155 ~898 minecraft:redstone_wire replace
fill ~390 ~155 ~886 ~390 ~155 ~898 minecraft:redstone_wire replace
fill ~393 ~155 ~886 ~393 ~155 ~898 minecraft:redstone_wire replace
fill ~396 ~155 ~886 ~396 ~155 ~898 minecraft:redstone_wire replace
fill ~399 ~155 ~886 ~399 ~155 ~898 minecraft:redstone_wire replace
setblock ~426 ~155 ~886 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~888 ~426 ~155 ~900 minecraft:redstone_wire replace
setblock ~429 ~155 ~894 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~894 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~896 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~896 ~429 ~155 ~908 minecraft:redstone_wire replace
fill ~432 ~155 ~896 ~432 ~155 ~908 minecraft:redstone_wire replace
setblock ~357 ~155 ~899 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~900 minecraft:redstone_wire replace
setblock ~360 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~360 ~155 ~902 ~360 ~155 ~904 minecraft:redstone_wire replace
fill ~363 ~155 ~902 ~363 ~155 ~908 minecraft:redstone_wire replace
fill ~366 ~155 ~902 ~366 ~155 ~910 minecraft:redstone_wire replace
fill ~369 ~155 ~902 ~369 ~155 ~914 minecraft:redstone_wire replace
fill ~372 ~155 ~902 ~372 ~155 ~914 minecraft:redstone_wire replace
fill ~375 ~155 ~902 ~375 ~155 ~914 minecraft:redstone_wire replace
fill ~378 ~155 ~902 ~378 ~155 ~914 minecraft:redstone_wire replace
fill ~381 ~155 ~902 ~381 ~155 ~914 minecraft:redstone_wire replace
fill ~384 ~155 ~902 ~384 ~155 ~914 minecraft:redstone_wire replace
fill ~387 ~155 ~902 ~387 ~155 ~914 minecraft:redstone_wire replace
fill ~390 ~155 ~902 ~390 ~155 ~914 minecraft:redstone_wire replace
fill ~393 ~155 ~902 ~393 ~155 ~914 minecraft:redstone_wire replace
fill ~396 ~155 ~902 ~396 ~155 ~914 minecraft:redstone_wire replace
fill ~399 ~155 ~902 ~399 ~155 ~914 minecraft:redstone_wire replace
setblock ~426 ~155 ~902 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~904 ~426 ~155 ~916 minecraft:redstone_wire replace
setblock ~429 ~155 ~910 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~910 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~912 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~912 ~429 ~155 ~924 minecraft:redstone_wire replace
fill ~432 ~155 ~912 ~432 ~155 ~924 minecraft:redstone_wire replace
setblock ~369 ~155 ~915 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~916 minecraft:redstone_wire replace
setblock ~372 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~155 ~918 ~372 ~155 ~920 minecraft:redstone_wire replace
fill ~375 ~155 ~918 ~375 ~155 ~924 minecraft:redstone_wire replace
fill ~378 ~155 ~918 ~378 ~155 ~926 minecraft:redstone_wire replace
fill ~381 ~155 ~918 ~381 ~155 ~930 minecraft:redstone_wire replace
fill ~384 ~155 ~918 ~384 ~155 ~930 minecraft:redstone_wire replace
fill ~387 ~155 ~918 ~387 ~155 ~930 minecraft:redstone_wire replace
fill ~390 ~155 ~918 ~390 ~155 ~930 minecraft:redstone_wire replace
fill ~393 ~155 ~918 ~393 ~155 ~930 minecraft:redstone_wire replace
fill ~396 ~155 ~918 ~396 ~155 ~930 minecraft:redstone_wire replace
fill ~399 ~155 ~918 ~399 ~155 ~930 minecraft:redstone_wire replace
setblock ~426 ~155 ~918 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~920 ~426 ~155 ~932 minecraft:redstone_wire replace
setblock ~429 ~155 ~926 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~926 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~928 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~928 ~429 ~155 ~940 minecraft:redstone_wire replace
fill ~432 ~155 ~928 ~432 ~155 ~940 minecraft:redstone_wire replace
setblock ~381 ~155 ~931 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~932 minecraft:redstone_wire replace
setblock ~384 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~384 ~155 ~934 ~384 ~155 ~936 minecraft:redstone_wire replace
fill ~387 ~155 ~934 ~387 ~155 ~940 minecraft:redstone_wire replace
fill ~390 ~155 ~934 ~390 ~155 ~942 minecraft:redstone_wire replace
fill ~393 ~155 ~934 ~393 ~155 ~946 minecraft:redstone_wire replace
fill ~396 ~155 ~934 ~396 ~155 ~946 minecraft:redstone_wire replace
fill ~399 ~155 ~934 ~399 ~155 ~946 minecraft:redstone_wire replace
setblock ~426 ~155 ~934 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~936 ~426 ~155 ~948 minecraft:redstone_wire replace
setblock ~429 ~155 ~942 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~942 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~944 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~944 ~429 ~155 ~956 minecraft:redstone_wire replace
fill ~432 ~155 ~944 ~432 ~155 ~956 minecraft:redstone_wire replace
setblock ~393 ~155 ~947 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~948 minecraft:redstone_wire replace
setblock ~396 ~155 ~948 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~948 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~155 ~950 ~396 ~155 ~952 minecraft:redstone_wire replace
fill ~399 ~155 ~950 ~399 ~155 ~956 minecraft:redstone_wire replace
setblock ~426 ~155 ~950 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~952 ~426 ~155 ~962 minecraft:redstone_wire replace
setblock ~429 ~155 ~958 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~958 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~960 ~429 ~155 ~966 minecraft:redstone_wire replace
setblock ~432 ~155 ~960 minecraft:redstone_wire replace
setblock ~426 ~155 ~964 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~429 ~155 ~968 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~156 ~233 minecraft:redstone_wire replace
setblock ~81 ~156 ~237 minecraft:redstone_wire replace
setblock ~102 ~156 ~265 minecraft:redstone_wire replace
setblock ~99 ~156 ~289 minecraft:redstone_wire replace
setblock ~96 ~156 ~305 minecraft:redstone_wire replace
setblock ~93 ~156 ~333 minecraft:redstone_wire replace
setblock ~90 ~156 ~369 minecraft:redstone_wire replace
setblock ~87 ~156 ~401 minecraft:redstone_wire replace
setblock ~84 ~156 ~433 minecraft:redstone_wire replace
setblock ~78 ~156 ~449 minecraft:redstone_wire replace
setblock ~108 ~156 ~537 minecraft:redstone_wire replace
setblock ~111 ~156 ~541 minecraft:redstone_wire replace
setblock ~114 ~156 ~545 minecraft:redstone_wire replace
setblock ~117 ~156 ~549 minecraft:redstone_wire replace
setblock ~120 ~156 ~553 minecraft:redstone_wire replace
setblock ~123 ~156 ~557 minecraft:redstone_wire replace
setblock ~126 ~156 ~561 minecraft:redstone_wire replace
setblock ~129 ~156 ~565 minecraft:redstone_wire replace
setblock ~132 ~156 ~569 minecraft:redstone_wire replace
setblock ~135 ~156 ~573 minecraft:redstone_wire replace
setblock ~138 ~156 ~577 minecraft:redstone_wire replace
setblock ~141 ~156 ~581 minecraft:redstone_wire replace
setblock ~144 ~156 ~585 minecraft:redstone_wire replace
setblock ~147 ~156 ~589 minecraft:redstone_wire replace
setblock ~150 ~156 ~593 minecraft:redstone_wire replace
setblock ~153 ~156 ~597 minecraft:redstone_wire replace
setblock ~156 ~156 ~601 minecraft:redstone_wire replace
setblock ~159 ~156 ~605 minecraft:redstone_wire replace
setblock ~162 ~156 ~609 minecraft:redstone_wire replace
setblock ~165 ~156 ~613 minecraft:redstone_wire replace
setblock ~168 ~156 ~617 minecraft:redstone_wire replace
setblock ~171 ~156 ~621 minecraft:redstone_wire replace
setblock ~174 ~156 ~625 minecraft:redstone_wire replace
setblock ~177 ~156 ~629 minecraft:redstone_wire replace
setblock ~180 ~156 ~633 minecraft:redstone_wire replace
setblock ~183 ~156 ~637 minecraft:redstone_wire replace
setblock ~186 ~156 ~641 minecraft:redstone_wire replace
setblock ~189 ~156 ~645 minecraft:redstone_wire replace
setblock ~192 ~156 ~649 minecraft:redstone_wire replace
setblock ~195 ~156 ~653 minecraft:redstone_wire replace
setblock ~198 ~156 ~657 minecraft:redstone_wire replace
setblock ~201 ~156 ~661 minecraft:redstone_wire replace
setblock ~204 ~156 ~665 minecraft:redstone_wire replace
setblock ~207 ~156 ~669 minecraft:redstone_wire replace
setblock ~210 ~156 ~673 minecraft:redstone_wire replace
setblock ~213 ~156 ~677 minecraft:redstone_wire replace
setblock ~216 ~156 ~681 minecraft:redstone_wire replace
setblock ~219 ~156 ~685 minecraft:redstone_wire replace
setblock ~222 ~156 ~689 minecraft:redstone_wire replace
setblock ~225 ~156 ~693 minecraft:redstone_wire replace
setblock ~228 ~156 ~697 minecraft:redstone_wire replace
setblock ~231 ~156 ~701 minecraft:redstone_wire replace
setblock ~234 ~156 ~705 minecraft:redstone_wire replace
setblock ~237 ~156 ~709 minecraft:redstone_wire replace
setblock ~240 ~156 ~713 minecraft:redstone_wire replace
setblock ~243 ~156 ~717 minecraft:redstone_wire replace
setblock ~246 ~156 ~721 minecraft:redstone_wire replace
setblock ~249 ~156 ~725 minecraft:redstone_wire replace
setblock ~252 ~156 ~729 minecraft:redstone_wire replace
setblock ~402 ~156 ~733 minecraft:redstone_wire replace
setblock ~405 ~156 ~737 minecraft:redstone_wire replace
setblock ~408 ~156 ~741 minecraft:redstone_wire replace
setblock ~411 ~156 ~745 minecraft:redstone_wire replace
setblock ~414 ~156 ~749 minecraft:redstone_wire replace
setblock ~417 ~156 ~753 minecraft:redstone_wire replace
setblock ~420 ~156 ~757 minecraft:redstone_wire replace
setblock ~423 ~156 ~761 minecraft:redstone_wire replace
setblock ~255 ~156 ~765 minecraft:redstone_wire replace
setblock ~258 ~156 ~769 minecraft:redstone_wire replace
setblock ~261 ~156 ~773 minecraft:redstone_wire replace
setblock ~264 ~156 ~777 minecraft:redstone_wire replace
setblock ~267 ~156 ~781 minecraft:redstone_wire replace
setblock ~270 ~156 ~785 minecraft:redstone_wire replace
setblock ~273 ~156 ~789 minecraft:redstone_wire replace
setblock ~276 ~156 ~793 minecraft:redstone_wire replace
setblock ~279 ~156 ~797 minecraft:redstone_wire replace
setblock ~282 ~156 ~801 minecraft:redstone_wire replace
setblock ~285 ~156 ~805 minecraft:redstone_wire replace
setblock ~288 ~156 ~809 minecraft:redstone_wire replace
setblock ~291 ~156 ~813 minecraft:redstone_wire replace
setblock ~294 ~156 ~817 minecraft:redstone_wire replace
setblock ~297 ~156 ~821 minecraft:redstone_wire replace
setblock ~300 ~156 ~825 minecraft:redstone_wire replace
setblock ~303 ~156 ~829 minecraft:redstone_wire replace
setblock ~306 ~156 ~833 minecraft:redstone_wire replace
setblock ~309 ~156 ~837 minecraft:redstone_wire replace
setblock ~312 ~156 ~841 minecraft:redstone_wire replace
setblock ~315 ~156 ~845 minecraft:redstone_wire replace
setblock ~318 ~156 ~849 minecraft:redstone_wire replace
setblock ~321 ~156 ~853 minecraft:redstone_wire replace
setblock ~324 ~156 ~857 minecraft:redstone_wire replace
setblock ~327 ~156 ~861 minecraft:redstone_wire replace
setblock ~330 ~156 ~865 minecraft:redstone_wire replace
setblock ~333 ~156 ~869 minecraft:redstone_wire replace
setblock ~336 ~156 ~873 minecraft:redstone_wire replace
setblock ~339 ~156 ~877 minecraft:redstone_wire replace
setblock ~342 ~156 ~881 minecraft:redstone_wire replace
setblock ~345 ~156 ~885 minecraft:redstone_wire replace
setblock ~348 ~156 ~889 minecraft:redstone_wire replace
setblock ~351 ~156 ~893 minecraft:redstone_wire replace
setblock ~354 ~156 ~897 minecraft:redstone_wire replace
setblock ~357 ~156 ~901 minecraft:redstone_wire replace
setblock ~360 ~156 ~905 minecraft:redstone_wire replace
setblock ~363 ~156 ~909 minecraft:redstone_wire replace
setblock ~366 ~156 ~913 minecraft:redstone_wire replace
setblock ~369 ~156 ~917 minecraft:redstone_wire replace
setblock ~372 ~156 ~921 minecraft:redstone_wire replace
setblock ~375 ~156 ~925 minecraft:redstone_wire replace
setblock ~378 ~156 ~929 minecraft:redstone_wire replace
setblock ~381 ~156 ~933 minecraft:redstone_wire replace
setblock ~384 ~156 ~937 minecraft:redstone_wire replace
setblock ~387 ~156 ~941 minecraft:redstone_wire replace
setblock ~390 ~156 ~945 minecraft:redstone_wire replace
setblock ~393 ~156 ~949 minecraft:redstone_wire replace
setblock ~396 ~156 ~953 minecraft:redstone_wire replace
setblock ~399 ~156 ~957 minecraft:redstone_wire replace
setblock ~432 ~156 ~961 minecraft:redstone_wire replace
setblock ~426 ~156 ~965 minecraft:redstone_wire replace
setblock ~429 ~156 ~969 minecraft:redstone_wire replace
fill ~105 ~157 ~234 ~107 ~157 ~234 minecraft:redstone_wire replace
setblock ~106 ~157 ~235 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~157 ~238 ~83 ~157 ~238 minecraft:redstone_wire replace
setblock ~82 ~157 ~239 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~157 ~266 ~104 ~157 ~266 minecraft:redstone_wire replace
setblock ~103 ~157 ~267 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~157 ~290 ~101 ~157 ~290 minecraft:redstone_wire replace
setblock ~100 ~157 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~157 ~306 ~98 ~157 ~306 minecraft:redstone_wire replace
setblock ~97 ~157 ~307 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~157 ~334 ~95 ~157 ~334 minecraft:redstone_wire replace
setblock ~94 ~157 ~335 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~157 ~370 ~92 ~157 ~370 minecraft:redstone_wire replace
setblock ~91 ~157 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~157 ~402 ~89 ~157 ~402 minecraft:redstone_wire replace
setblock ~88 ~157 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~157 ~434 ~86 ~157 ~434 minecraft:redstone_wire replace
setblock ~85 ~157 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~157 ~450 ~80 ~157 ~450 minecraft:redstone_wire replace
setblock ~79 ~157 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~157 ~538 ~110 ~157 ~538 minecraft:redstone_wire replace
setblock ~109 ~157 ~539 minecraft:redstone_wire replace
fill ~108 ~157 ~542 ~111 ~157 ~542 minecraft:redstone_wire replace
setblock ~109 ~157 ~543 minecraft:redstone_wire replace
fill ~108 ~157 ~546 ~114 ~157 ~546 minecraft:redstone_wire replace
setblock ~109 ~157 ~547 minecraft:redstone_wire replace
fill ~108 ~157 ~550 ~117 ~157 ~550 minecraft:redstone_wire replace
setblock ~109 ~157 ~551 minecraft:redstone_wire replace
fill ~108 ~157 ~554 ~109 ~157 ~554 minecraft:redstone_wire replace
setblock ~110 ~157 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~157 ~554 ~120 ~157 ~554 minecraft:redstone_wire replace
setblock ~109 ~157 ~555 minecraft:redstone_wire replace
fill ~108 ~157 ~558 ~114 ~157 ~558 minecraft:redstone_wire replace
setblock ~116 ~157 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~558 ~123 ~157 ~558 minecraft:redstone_wire replace
setblock ~109 ~157 ~559 minecraft:redstone_wire replace
fill ~108 ~157 ~562 ~110 ~157 ~562 minecraft:redstone_wire replace
setblock ~112 ~157 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~157 ~562 ~126 ~157 ~562 minecraft:redstone_wire replace
setblock ~109 ~157 ~563 minecraft:redstone_wire replace
fill ~108 ~157 ~566 ~114 ~157 ~566 minecraft:redstone_wire replace
setblock ~116 ~157 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~566 ~129 ~157 ~566 minecraft:redstone_wire replace
setblock ~109 ~157 ~567 minecraft:redstone_wire replace
fill ~111 ~157 ~570 ~119 ~157 ~570 minecraft:redstone_wire replace
setblock ~121 ~157 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~157 ~570 ~132 ~157 ~570 minecraft:redstone_wire replace
setblock ~112 ~157 ~571 minecraft:redstone_wire replace
fill ~111 ~157 ~574 ~113 ~157 ~574 minecraft:redstone_wire replace
setblock ~114 ~157 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~574 ~127 ~157 ~574 minecraft:redstone_wire replace
setblock ~129 ~157 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~157 ~574 ~135 ~157 ~574 minecraft:redstone_wire replace
setblock ~112 ~157 ~575 minecraft:redstone_wire replace
fill ~111 ~157 ~578 ~122 ~157 ~578 minecraft:redstone_wire replace
setblock ~124 ~157 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~157 ~578 ~138 ~157 ~578 minecraft:redstone_wire replace
setblock ~112 ~157 ~579 minecraft:redstone_wire replace
fill ~111 ~157 ~582 ~113 ~157 ~582 minecraft:redstone_wire replace
setblock ~114 ~157 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~582 ~127 ~157 ~582 minecraft:redstone_wire replace
setblock ~129 ~157 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~157 ~582 ~141 ~157 ~582 minecraft:redstone_wire replace
setblock ~112 ~157 ~583 minecraft:redstone_wire replace
fill ~111 ~157 ~586 ~114 ~157 ~586 minecraft:redstone_wire replace
setblock ~116 ~157 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~586 ~131 ~157 ~586 minecraft:redstone_wire replace
setblock ~133 ~157 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~157 ~586 ~144 ~157 ~586 minecraft:redstone_wire replace
setblock ~112 ~157 ~587 minecraft:redstone_wire replace
fill ~111 ~157 ~590 ~121 ~157 ~590 minecraft:redstone_wire replace
setblock ~123 ~157 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~157 ~590 ~138 ~157 ~590 minecraft:redstone_wire replace
setblock ~140 ~157 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~590 ~147 ~157 ~590 minecraft:redstone_wire replace
setblock ~112 ~157 ~591 minecraft:redstone_wire replace
fill ~111 ~157 ~594 ~117 ~157 ~594 minecraft:redstone_wire replace
setblock ~119 ~157 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~157 ~594 ~134 ~157 ~594 minecraft:redstone_wire replace
setblock ~136 ~157 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~594 ~150 ~157 ~594 minecraft:redstone_wire replace
setblock ~112 ~157 ~595 minecraft:redstone_wire replace
fill ~111 ~157 ~598 ~121 ~157 ~598 minecraft:redstone_wire replace
setblock ~123 ~157 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~157 ~598 ~138 ~157 ~598 minecraft:redstone_wire replace
setblock ~140 ~157 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~598 ~153 ~157 ~598 minecraft:redstone_wire replace
setblock ~112 ~157 ~599 minecraft:redstone_wire replace
fill ~114 ~157 ~602 ~126 ~157 ~602 minecraft:redstone_wire replace
setblock ~128 ~157 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~157 ~602 ~143 ~157 ~602 minecraft:redstone_wire replace
setblock ~145 ~157 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~602 ~156 ~157 ~602 minecraft:redstone_wire replace
setblock ~115 ~157 ~603 minecraft:redstone_wire replace
fill ~114 ~157 ~606 ~116 ~157 ~606 minecraft:redstone_wire replace
setblock ~118 ~157 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~157 ~606 ~133 ~157 ~606 minecraft:redstone_wire replace
setblock ~135 ~157 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~606 ~150 ~157 ~606 minecraft:redstone_wire replace
setblock ~152 ~157 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~606 ~159 ~157 ~606 minecraft:redstone_wire replace
setblock ~115 ~157 ~607 minecraft:redstone_wire replace
fill ~114 ~157 ~610 ~115 ~157 ~610 minecraft:redstone_wire replace
setblock ~117 ~157 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~157 ~610 ~131 ~157 ~610 minecraft:redstone_wire replace
setblock ~133 ~157 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~157 ~610 ~147 ~157 ~610 minecraft:redstone_wire replace
setblock ~149 ~157 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~610 ~162 ~157 ~610 minecraft:redstone_wire replace
setblock ~115 ~157 ~611 minecraft:redstone_wire replace
fill ~114 ~157 ~614 ~116 ~157 ~614 minecraft:redstone_wire replace
setblock ~118 ~157 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~157 ~614 ~133 ~157 ~614 minecraft:redstone_wire replace
setblock ~135 ~157 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~614 ~150 ~157 ~614 minecraft:redstone_wire replace
setblock ~152 ~157 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~614 ~165 ~157 ~614 minecraft:redstone_wire replace
setblock ~115 ~157 ~615 minecraft:redstone_wire replace
fill ~114 ~157 ~618 ~121 ~157 ~618 minecraft:redstone_wire replace
setblock ~123 ~157 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~157 ~618 ~138 ~157 ~618 minecraft:redstone_wire replace
setblock ~140 ~157 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~618 ~155 ~157 ~618 minecraft:redstone_wire replace
setblock ~157 ~157 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~618 ~168 ~157 ~618 minecraft:redstone_wire replace
setblock ~115 ~157 ~619 minecraft:redstone_wire replace
setblock ~114 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~622 ~128 ~157 ~622 minecraft:redstone_wire replace
setblock ~130 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~622 ~145 ~157 ~622 minecraft:redstone_wire replace
setblock ~147 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~622 ~162 ~157 ~622 minecraft:redstone_wire replace
setblock ~164 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~622 ~171 ~157 ~622 minecraft:redstone_wire replace
setblock ~115 ~157 ~623 minecraft:redstone_wire replace
fill ~114 ~157 ~626 ~124 ~157 ~626 minecraft:redstone_wire replace
setblock ~126 ~157 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~157 ~626 ~141 ~157 ~626 minecraft:redstone_wire replace
setblock ~143 ~157 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~626 ~158 ~157 ~626 minecraft:redstone_wire replace
setblock ~160 ~157 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~626 ~174 ~157 ~626 minecraft:redstone_wire replace
setblock ~115 ~157 ~627 minecraft:redstone_wire replace
setblock ~114 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~630 ~128 ~157 ~630 minecraft:redstone_wire replace
setblock ~130 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~630 ~145 ~157 ~630 minecraft:redstone_wire replace
setblock ~147 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~630 ~162 ~157 ~630 minecraft:redstone_wire replace
setblock ~164 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~630 ~177 ~157 ~630 minecraft:redstone_wire replace
setblock ~115 ~157 ~631 minecraft:redstone_wire replace
fill ~114 ~157 ~634 ~116 ~157 ~634 minecraft:redstone_wire replace
setblock ~118 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~157 ~634 ~133 ~157 ~634 minecraft:redstone_wire replace
setblock ~135 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~634 ~150 ~157 ~634 minecraft:redstone_wire replace
setblock ~152 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~634 ~167 ~157 ~634 minecraft:redstone_wire replace
setblock ~169 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~634 ~180 ~157 ~634 minecraft:redstone_wire replace
setblock ~115 ~157 ~635 minecraft:redstone_wire replace
fill ~117 ~157 ~638 ~123 ~157 ~638 minecraft:redstone_wire replace
setblock ~125 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~157 ~638 ~140 ~157 ~638 minecraft:redstone_wire replace
setblock ~142 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~638 ~157 ~157 ~638 minecraft:redstone_wire replace
setblock ~159 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~638 ~174 ~157 ~638 minecraft:redstone_wire replace
setblock ~176 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~638 ~183 ~157 ~638 minecraft:redstone_wire replace
setblock ~118 ~157 ~639 minecraft:redstone_wire replace
fill ~117 ~157 ~642 ~119 ~157 ~642 minecraft:redstone_wire replace
setblock ~121 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~157 ~642 ~136 ~157 ~642 minecraft:redstone_wire replace
setblock ~138 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~642 ~153 ~157 ~642 minecraft:redstone_wire replace
setblock ~155 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~642 ~170 ~157 ~642 minecraft:redstone_wire replace
setblock ~172 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~642 ~186 ~157 ~642 minecraft:redstone_wire replace
setblock ~118 ~157 ~643 minecraft:redstone_wire replace
fill ~117 ~157 ~646 ~123 ~157 ~646 minecraft:redstone_wire replace
setblock ~125 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~157 ~646 ~140 ~157 ~646 minecraft:redstone_wire replace
setblock ~142 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~646 ~157 ~157 ~646 minecraft:redstone_wire replace
setblock ~159 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~646 ~174 ~157 ~646 minecraft:redstone_wire replace
setblock ~176 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~646 ~189 ~157 ~646 minecraft:redstone_wire replace
setblock ~118 ~157 ~647 minecraft:redstone_wire replace
fill ~117 ~157 ~650 ~128 ~157 ~650 minecraft:redstone_wire replace
setblock ~130 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~650 ~145 ~157 ~650 minecraft:redstone_wire replace
setblock ~147 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~650 ~162 ~157 ~650 minecraft:redstone_wire replace
setblock ~164 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~650 ~179 ~157 ~650 minecraft:redstone_wire replace
setblock ~181 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~650 ~192 ~157 ~650 minecraft:redstone_wire replace
setblock ~118 ~157 ~651 minecraft:redstone_wire replace
fill ~117 ~157 ~654 ~118 ~157 ~654 minecraft:redstone_wire replace
setblock ~120 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~157 ~654 ~135 ~157 ~654 minecraft:redstone_wire replace
setblock ~137 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~654 ~152 ~157 ~654 minecraft:redstone_wire replace
setblock ~154 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~654 ~169 ~157 ~654 minecraft:redstone_wire replace
setblock ~171 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~654 ~186 ~157 ~654 minecraft:redstone_wire replace
setblock ~188 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~654 ~195 ~157 ~654 minecraft:redstone_wire replace
setblock ~118 ~157 ~655 minecraft:redstone_wire replace
