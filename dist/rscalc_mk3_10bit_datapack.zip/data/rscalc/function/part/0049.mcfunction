setblock ~390 ~155 ~853 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~853 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~853 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~853 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~853 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~855 minecraft:light_gray_concrete replace
setblock ~324 ~155 ~857 minecraft:light_gray_concrete replace
setblock ~327 ~155 ~861 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~861 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~861 minecraft:light_gray_concrete replace
setblock ~330 ~155 ~863 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~863 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~863 minecraft:light_gray_concrete replace
setblock ~330 ~155 ~865 minecraft:light_gray_concrete replace
setblock ~336 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~339 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~342 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~345 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~348 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~351 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~354 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~357 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~867 minecraft:light_gray_concrete replace
setblock ~333 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~336 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~339 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~342 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~345 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~348 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~351 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~354 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~357 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~869 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~871 minecraft:light_gray_concrete replace
setblock ~336 ~155 ~873 minecraft:light_gray_concrete replace
setblock ~339 ~155 ~877 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~877 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~877 minecraft:light_gray_concrete replace
setblock ~342 ~155 ~879 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~879 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~879 minecraft:light_gray_concrete replace
setblock ~342 ~155 ~881 minecraft:light_gray_concrete replace
setblock ~348 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~351 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~354 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~357 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~883 minecraft:light_gray_concrete replace
setblock ~345 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~348 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~351 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~354 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~357 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~885 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~887 minecraft:light_gray_concrete replace
setblock ~348 ~155 ~889 minecraft:light_gray_concrete replace
setblock ~351 ~155 ~893 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~893 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~893 minecraft:light_gray_concrete replace
setblock ~354 ~155 ~895 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~895 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~895 minecraft:light_gray_concrete replace
setblock ~354 ~155 ~897 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~899 minecraft:light_gray_concrete replace
setblock ~357 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~901 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~903 minecraft:light_gray_concrete replace
setblock ~360 ~155 ~905 minecraft:light_gray_concrete replace
setblock ~363 ~155 ~909 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~909 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~909 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~911 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~911 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~911 minecraft:light_gray_concrete replace
setblock ~366 ~155 ~913 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~915 minecraft:light_gray_concrete replace
setblock ~369 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~917 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~919 minecraft:light_gray_concrete replace
setblock ~372 ~155 ~921 minecraft:light_gray_concrete replace
setblock ~375 ~155 ~925 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~925 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~925 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~927 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~927 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~927 minecraft:light_gray_concrete replace
setblock ~378 ~155 ~929 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~931 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~931 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~931 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~931 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~931 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~931 minecraft:light_gray_concrete replace
setblock ~381 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~933 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~935 minecraft:light_gray_concrete replace
setblock ~384 ~155 ~937 minecraft:light_gray_concrete replace
setblock ~387 ~155 ~941 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~941 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~941 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~943 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~943 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~943 minecraft:light_gray_concrete replace
setblock ~390 ~155 ~945 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~947 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~947 minecraft:light_gray_concrete replace
setblock ~393 ~155 ~949 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~949 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~949 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~949 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~951 minecraft:light_gray_concrete replace
setblock ~396 ~155 ~953 minecraft:light_gray_concrete replace
setblock ~399 ~155 ~957 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~957 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~957 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~959 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~959 minecraft:light_gray_concrete replace
setblock ~432 ~155 ~961 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~963 minecraft:light_gray_concrete replace
setblock ~426 ~155 ~965 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~967 minecraft:light_gray_concrete replace
setblock ~429 ~155 ~969 minecraft:light_gray_concrete replace
fill ~105 ~156 ~234 ~107 ~156 ~234 minecraft:light_gray_concrete replace
fill ~106 ~156 ~235 ~106 ~156 ~236 minecraft:light_gray_concrete replace
fill ~81 ~156 ~238 ~83 ~156 ~238 minecraft:light_gray_concrete replace
fill ~82 ~156 ~239 ~82 ~156 ~240 minecraft:light_gray_concrete replace
fill ~102 ~156 ~266 ~104 ~156 ~266 minecraft:light_gray_concrete replace
fill ~103 ~156 ~267 ~103 ~156 ~268 minecraft:light_gray_concrete replace
fill ~99 ~156 ~290 ~101 ~156 ~290 minecraft:light_gray_concrete replace
fill ~100 ~156 ~291 ~100 ~156 ~292 minecraft:light_gray_concrete replace
fill ~96 ~156 ~306 ~98 ~156 ~306 minecraft:light_gray_concrete replace
fill ~97 ~156 ~307 ~97 ~156 ~308 minecraft:light_gray_concrete replace
fill ~93 ~156 ~334 ~95 ~156 ~334 minecraft:light_gray_concrete replace
fill ~94 ~156 ~335 ~94 ~156 ~336 minecraft:light_gray_concrete replace
fill ~90 ~156 ~370 ~92 ~156 ~370 minecraft:light_gray_concrete replace
fill ~91 ~156 ~371 ~91 ~156 ~372 minecraft:light_gray_concrete replace
fill ~87 ~156 ~402 ~89 ~156 ~402 minecraft:light_gray_concrete replace
fill ~88 ~156 ~403 ~88 ~156 ~404 minecraft:light_gray_concrete replace
fill ~84 ~156 ~434 ~86 ~156 ~434 minecraft:light_gray_concrete replace
fill ~85 ~156 ~435 ~85 ~156 ~436 minecraft:light_gray_concrete replace
fill ~78 ~156 ~450 ~80 ~156 ~450 minecraft:light_gray_concrete replace
fill ~79 ~156 ~451 ~79 ~156 ~452 minecraft:light_gray_concrete replace
fill ~108 ~156 ~538 ~110 ~156 ~538 minecraft:light_gray_concrete replace
fill ~109 ~156 ~539 ~109 ~156 ~540 minecraft:light_gray_concrete replace
fill ~108 ~156 ~542 ~111 ~156 ~542 minecraft:light_gray_concrete replace
fill ~109 ~156 ~543 ~109 ~156 ~544 minecraft:light_gray_concrete replace
fill ~108 ~156 ~546 ~114 ~156 ~546 minecraft:light_gray_concrete replace
fill ~109 ~156 ~547 ~109 ~156 ~548 minecraft:light_gray_concrete replace
fill ~108 ~156 ~550 ~117 ~156 ~550 minecraft:light_gray_concrete replace
fill ~109 ~156 ~551 ~109 ~156 ~552 minecraft:light_gray_concrete replace
fill ~108 ~156 ~554 ~120 ~156 ~554 minecraft:light_gray_concrete replace
fill ~109 ~156 ~555 ~109 ~156 ~556 minecraft:light_gray_concrete replace
fill ~108 ~156 ~558 ~123 ~156 ~558 minecraft:light_gray_concrete replace
fill ~109 ~156 ~559 ~109 ~156 ~560 minecraft:light_gray_concrete replace
fill ~108 ~156 ~562 ~126 ~156 ~562 minecraft:light_gray_concrete replace
fill ~109 ~156 ~563 ~109 ~156 ~564 minecraft:light_gray_concrete replace
fill ~108 ~156 ~566 ~129 ~156 ~566 minecraft:light_gray_concrete replace
fill ~109 ~156 ~567 ~109 ~156 ~568 minecraft:light_gray_concrete replace
fill ~111 ~156 ~570 ~132 ~156 ~570 minecraft:light_gray_concrete replace
fill ~112 ~156 ~571 ~112 ~156 ~572 minecraft:light_gray_concrete replace
fill ~111 ~156 ~574 ~135 ~156 ~574 minecraft:light_gray_concrete replace
fill ~112 ~156 ~575 ~112 ~156 ~576 minecraft:light_gray_concrete replace
fill ~111 ~156 ~578 ~138 ~156 ~578 minecraft:light_gray_concrete replace
fill ~112 ~156 ~579 ~112 ~156 ~580 minecraft:light_gray_concrete replace
fill ~111 ~156 ~582 ~141 ~156 ~582 minecraft:light_gray_concrete replace
fill ~112 ~156 ~583 ~112 ~156 ~584 minecraft:light_gray_concrete replace
fill ~111 ~156 ~586 ~144 ~156 ~586 minecraft:light_gray_concrete replace
fill ~112 ~156 ~587 ~112 ~156 ~588 minecraft:light_gray_concrete replace
fill ~111 ~156 ~590 ~147 ~156 ~590 minecraft:light_gray_concrete replace
fill ~112 ~156 ~591 ~112 ~156 ~592 minecraft:light_gray_concrete replace
fill ~111 ~156 ~594 ~150 ~156 ~594 minecraft:light_gray_concrete replace
fill ~112 ~156 ~595 ~112 ~156 ~596 minecraft:light_gray_concrete replace
fill ~111 ~156 ~598 ~153 ~156 ~598 minecraft:light_gray_concrete replace
fill ~112 ~156 ~599 ~112 ~156 ~600 minecraft:light_gray_concrete replace
fill ~114 ~156 ~602 ~156 ~156 ~602 minecraft:light_gray_concrete replace
fill ~115 ~156 ~603 ~115 ~156 ~604 minecraft:light_gray_concrete replace
fill ~114 ~156 ~606 ~159 ~156 ~606 minecraft:light_gray_concrete replace
fill ~115 ~156 ~607 ~115 ~156 ~608 minecraft:light_gray_concrete replace
fill ~114 ~156 ~610 ~162 ~156 ~610 minecraft:light_gray_concrete replace
fill ~115 ~156 ~611 ~115 ~156 ~612 minecraft:light_gray_concrete replace
fill ~114 ~156 ~614 ~165 ~156 ~614 minecraft:light_gray_concrete replace
fill ~115 ~156 ~615 ~115 ~156 ~616 minecraft:light_gray_concrete replace
fill ~114 ~156 ~618 ~168 ~156 ~618 minecraft:light_gray_concrete replace
fill ~115 ~156 ~619 ~115 ~156 ~620 minecraft:light_gray_concrete replace
fill ~114 ~156 ~622 ~171 ~156 ~622 minecraft:light_gray_concrete replace
fill ~115 ~156 ~623 ~115 ~156 ~624 minecraft:light_gray_concrete replace
fill ~114 ~156 ~626 ~174 ~156 ~626 minecraft:light_gray_concrete replace
fill ~115 ~156 ~627 ~115 ~156 ~628 minecraft:light_gray_concrete replace
fill ~114 ~156 ~630 ~177 ~156 ~630 minecraft:light_gray_concrete replace
fill ~115 ~156 ~631 ~115 ~156 ~632 minecraft:light_gray_concrete replace
fill ~114 ~156 ~634 ~180 ~156 ~634 minecraft:light_gray_concrete replace
fill ~115 ~156 ~635 ~115 ~156 ~636 minecraft:light_gray_concrete replace
fill ~117 ~156 ~638 ~183 ~156 ~638 minecraft:light_gray_concrete replace
fill ~118 ~156 ~639 ~118 ~156 ~640 minecraft:light_gray_concrete replace
fill ~117 ~156 ~642 ~186 ~156 ~642 minecraft:light_gray_concrete replace
fill ~118 ~156 ~643 ~118 ~156 ~644 minecraft:light_gray_concrete replace
fill ~117 ~156 ~646 ~189 ~156 ~646 minecraft:light_gray_concrete replace
fill ~118 ~156 ~647 ~118 ~156 ~648 minecraft:light_gray_concrete replace
fill ~117 ~156 ~650 ~192 ~156 ~650 minecraft:light_gray_concrete replace
fill ~118 ~156 ~651 ~118 ~156 ~652 minecraft:light_gray_concrete replace
fill ~117 ~156 ~654 ~195 ~156 ~654 minecraft:light_gray_concrete replace
fill ~118 ~156 ~655 ~118 ~156 ~656 minecraft:light_gray_concrete replace
fill ~117 ~156 ~658 ~198 ~156 ~658 minecraft:light_gray_concrete replace
fill ~118 ~156 ~659 ~118 ~156 ~660 minecraft:light_gray_concrete replace
fill ~117 ~156 ~662 ~201 ~156 ~662 minecraft:light_gray_concrete replace
fill ~118 ~156 ~663 ~118 ~156 ~664 minecraft:light_gray_concrete replace
fill ~120 ~156 ~666 ~204 ~156 ~666 minecraft:light_gray_concrete replace
fill ~121 ~156 ~667 ~121 ~156 ~668 minecraft:light_gray_concrete replace
fill ~120 ~156 ~670 ~207 ~156 ~670 minecraft:light_gray_concrete replace
fill ~121 ~156 ~671 ~121 ~156 ~672 minecraft:light_gray_concrete replace
fill ~120 ~156 ~674 ~210 ~156 ~674 minecraft:light_gray_concrete replace
fill ~121 ~156 ~675 ~121 ~156 ~676 minecraft:light_gray_concrete replace
fill ~120 ~156 ~678 ~213 ~156 ~678 minecraft:light_gray_concrete replace
fill ~121 ~156 ~679 ~121 ~156 ~680 minecraft:light_gray_concrete replace
fill ~123 ~156 ~682 ~216 ~156 ~682 minecraft:light_gray_concrete replace
fill ~124 ~156 ~683 ~124 ~156 ~684 minecraft:light_gray_concrete replace
fill ~123 ~156 ~686 ~219 ~156 ~686 minecraft:light_gray_concrete replace
fill ~124 ~156 ~687 ~124 ~156 ~688 minecraft:light_gray_concrete replace
fill ~123 ~156 ~690 ~222 ~156 ~690 minecraft:light_gray_concrete replace
fill ~124 ~156 ~691 ~124 ~156 ~692 minecraft:light_gray_concrete replace
fill ~123 ~156 ~694 ~225 ~156 ~694 minecraft:light_gray_concrete replace
fill ~124 ~156 ~695 ~124 ~156 ~696 minecraft:light_gray_concrete replace
fill ~123 ~156 ~698 ~228 ~156 ~698 minecraft:light_gray_concrete replace
fill ~124 ~156 ~699 ~124 ~156 ~700 minecraft:light_gray_concrete replace
fill ~123 ~156 ~702 ~231 ~156 ~702 minecraft:light_gray_concrete replace
fill ~124 ~156 ~703 ~124 ~156 ~704 minecraft:light_gray_concrete replace
fill ~126 ~156 ~706 ~234 ~156 ~706 minecraft:light_gray_concrete replace
fill ~127 ~156 ~707 ~127 ~156 ~708 minecraft:light_gray_concrete replace
fill ~126 ~156 ~710 ~237 ~156 ~710 minecraft:light_gray_concrete replace
fill ~127 ~156 ~711 ~127 ~156 ~712 minecraft:light_gray_concrete replace
fill ~126 ~156 ~714 ~240 ~156 ~714 minecraft:light_gray_concrete replace
fill ~127 ~156 ~715 ~127 ~156 ~716 minecraft:light_gray_concrete replace
fill ~126 ~156 ~718 ~243 ~156 ~718 minecraft:light_gray_concrete replace
fill ~127 ~156 ~719 ~127 ~156 ~720 minecraft:light_gray_concrete replace
fill ~126 ~156 ~722 ~246 ~156 ~722 minecraft:light_gray_concrete replace
fill ~127 ~156 ~723 ~127 ~156 ~724 minecraft:light_gray_concrete replace
fill ~126 ~156 ~726 ~249 ~156 ~726 minecraft:light_gray_concrete replace
fill ~127 ~156 ~727 ~127 ~156 ~728 minecraft:light_gray_concrete replace
fill ~126 ~156 ~730 ~252 ~156 ~730 minecraft:light_gray_concrete replace
fill ~127 ~156 ~731 ~127 ~156 ~732 minecraft:light_gray_concrete replace
fill ~150 ~156 ~734 ~402 ~156 ~734 minecraft:light_gray_concrete replace
fill ~151 ~156 ~735 ~151 ~156 ~736 minecraft:light_gray_concrete replace
fill ~153 ~156 ~738 ~405 ~156 ~738 minecraft:light_gray_concrete replace
fill ~154 ~156 ~739 ~154 ~156 ~740 minecraft:light_gray_concrete replace
fill ~153 ~156 ~742 ~408 ~156 ~742 minecraft:light_gray_concrete replace
fill ~154 ~156 ~743 ~154 ~156 ~744 minecraft:light_gray_concrete replace
fill ~156 ~156 ~746 ~411 ~156 ~746 minecraft:light_gray_concrete replace
fill ~157 ~156 ~747 ~157 ~156 ~748 minecraft:light_gray_concrete replace
fill ~156 ~156 ~750 ~414 ~156 ~750 minecraft:light_gray_concrete replace
fill ~157 ~156 ~751 ~157 ~156 ~752 minecraft:light_gray_concrete replace
fill ~159 ~156 ~754 ~417 ~156 ~754 minecraft:light_gray_concrete replace
fill ~160 ~156 ~755 ~160 ~156 ~756 minecraft:light_gray_concrete replace
fill ~162 ~156 ~758 ~420 ~156 ~758 minecraft:light_gray_concrete replace
fill ~163 ~156 ~759 ~163 ~156 ~760 minecraft:light_gray_concrete replace
fill ~165 ~156 ~762 ~423 ~156 ~762 minecraft:light_gray_concrete replace
fill ~166 ~156 ~763 ~166 ~156 ~764 minecraft:light_gray_concrete replace
fill ~129 ~156 ~766 ~255 ~156 ~766 minecraft:light_gray_concrete replace
fill ~130 ~156 ~767 ~130 ~156 ~768 minecraft:light_gray_concrete replace
fill ~129 ~156 ~770 ~258 ~156 ~770 minecraft:light_gray_concrete replace
fill ~130 ~156 ~771 ~130 ~156 ~772 minecraft:light_gray_concrete replace
fill ~129 ~156 ~774 ~261 ~156 ~774 minecraft:light_gray_concrete replace
fill ~130 ~156 ~775 ~130 ~156 ~776 minecraft:light_gray_concrete replace
fill ~129 ~156 ~778 ~264 ~156 ~778 minecraft:light_gray_concrete replace
fill ~130 ~156 ~779 ~130 ~156 ~780 minecraft:light_gray_concrete replace
fill ~129 ~156 ~782 ~267 ~156 ~782 minecraft:light_gray_concrete replace
fill ~130 ~156 ~783 ~130 ~156 ~784 minecraft:light_gray_concrete replace
fill ~129 ~156 ~786 ~270 ~156 ~786 minecraft:light_gray_concrete replace
fill ~130 ~156 ~787 ~130 ~156 ~788 minecraft:light_gray_concrete replace
fill ~129 ~156 ~790 ~273 ~156 ~790 minecraft:light_gray_concrete replace
fill ~130 ~156 ~791 ~130 ~156 ~792 minecraft:light_gray_concrete replace
fill ~129 ~156 ~794 ~276 ~156 ~794 minecraft:light_gray_concrete replace
fill ~130 ~156 ~795 ~130 ~156 ~796 minecraft:light_gray_concrete replace
fill ~132 ~156 ~798 ~279 ~156 ~798 minecraft:light_gray_concrete replace
fill ~133 ~156 ~799 ~133 ~156 ~800 minecraft:light_gray_concrete replace
fill ~132 ~156 ~802 ~282 ~156 ~802 minecraft:light_gray_concrete replace
fill ~133 ~156 ~803 ~133 ~156 ~804 minecraft:light_gray_concrete replace
fill ~132 ~156 ~806 ~285 ~156 ~806 minecraft:light_gray_concrete replace
fill ~133 ~156 ~807 ~133 ~156 ~808 minecraft:light_gray_concrete replace
fill ~132 ~156 ~810 ~288 ~156 ~810 minecraft:light_gray_concrete replace
fill ~133 ~156 ~811 ~133 ~156 ~812 minecraft:light_gray_concrete replace
fill ~132 ~156 ~814 ~291 ~156 ~814 minecraft:light_gray_concrete replace
fill ~133 ~156 ~815 ~133 ~156 ~816 minecraft:light_gray_concrete replace
fill ~132 ~156 ~818 ~294 ~156 ~818 minecraft:light_gray_concrete replace
fill ~133 ~156 ~819 ~133 ~156 ~820 minecraft:light_gray_concrete replace
fill ~132 ~156 ~822 ~297 ~156 ~822 minecraft:light_gray_concrete replace
fill ~133 ~156 ~823 ~133 ~156 ~824 minecraft:light_gray_concrete replace
fill ~132 ~156 ~826 ~300 ~156 ~826 minecraft:light_gray_concrete replace
fill ~133 ~156 ~827 ~133 ~156 ~828 minecraft:light_gray_concrete replace
fill ~135 ~156 ~830 ~303 ~156 ~830 minecraft:light_gray_concrete replace
fill ~136 ~156 ~831 ~136 ~156 ~832 minecraft:light_gray_concrete replace
fill ~135 ~156 ~834 ~306 ~156 ~834 minecraft:light_gray_concrete replace
fill ~136 ~156 ~835 ~136 ~156 ~836 minecraft:light_gray_concrete replace
fill ~135 ~156 ~838 ~309 ~156 ~838 minecraft:light_gray_concrete replace
fill ~136 ~156 ~839 ~136 ~156 ~840 minecraft:light_gray_concrete replace
fill ~135 ~156 ~842 ~312 ~156 ~842 minecraft:light_gray_concrete replace
fill ~136 ~156 ~843 ~136 ~156 ~844 minecraft:light_gray_concrete replace
fill ~135 ~156 ~846 ~315 ~156 ~846 minecraft:light_gray_concrete replace
fill ~136 ~156 ~847 ~136 ~156 ~848 minecraft:light_gray_concrete replace
fill ~135 ~156 ~850 ~318 ~156 ~850 minecraft:light_gray_concrete replace
fill ~136 ~156 ~851 ~136 ~156 ~852 minecraft:light_gray_concrete replace
fill ~135 ~156 ~854 ~321 ~156 ~854 minecraft:light_gray_concrete replace
fill ~136 ~156 ~855 ~136 ~156 ~856 minecraft:light_gray_concrete replace
fill ~135 ~156 ~858 ~324 ~156 ~858 minecraft:light_gray_concrete replace
fill ~136 ~156 ~859 ~136 ~156 ~860 minecraft:light_gray_concrete replace
fill ~135 ~156 ~862 ~327 ~156 ~862 minecraft:light_gray_concrete replace
fill ~136 ~156 ~863 ~136 ~156 ~864 minecraft:light_gray_concrete replace
fill ~138 ~156 ~866 ~330 ~156 ~866 minecraft:light_gray_concrete replace
fill ~139 ~156 ~867 ~139 ~156 ~868 minecraft:light_gray_concrete replace
fill ~138 ~156 ~870 ~333 ~156 ~870 minecraft:light_gray_concrete replace
fill ~139 ~156 ~871 ~139 ~156 ~872 minecraft:light_gray_concrete replace
fill ~138 ~156 ~874 ~336 ~156 ~874 minecraft:light_gray_concrete replace
fill ~139 ~156 ~875 ~139 ~156 ~876 minecraft:light_gray_concrete replace
fill ~138 ~156 ~878 ~339 ~156 ~878 minecraft:light_gray_concrete replace
fill ~139 ~156 ~879 ~139 ~156 ~880 minecraft:light_gray_concrete replace
fill ~138 ~156 ~882 ~342 ~156 ~882 minecraft:light_gray_concrete replace
fill ~139 ~156 ~883 ~139 ~156 ~884 minecraft:light_gray_concrete replace
fill ~138 ~156 ~886 ~345 ~156 ~886 minecraft:light_gray_concrete replace
fill ~139 ~156 ~887 ~139 ~156 ~888 minecraft:light_gray_concrete replace
fill ~138 ~156 ~890 ~348 ~156 ~890 minecraft:light_gray_concrete replace
fill ~139 ~156 ~891 ~139 ~156 ~892 minecraft:light_gray_concrete replace
fill ~141 ~156 ~894 ~351 ~156 ~894 minecraft:light_gray_concrete replace
fill ~142 ~156 ~895 ~142 ~156 ~896 minecraft:light_gray_concrete replace
fill ~141 ~156 ~898 ~354 ~156 ~898 minecraft:light_gray_concrete replace
fill ~142 ~156 ~899 ~142 ~156 ~900 minecraft:light_gray_concrete replace
fill ~141 ~156 ~902 ~357 ~156 ~902 minecraft:light_gray_concrete replace
fill ~142 ~156 ~903 ~142 ~156 ~904 minecraft:light_gray_concrete replace
fill ~141 ~156 ~906 ~360 ~156 ~906 minecraft:light_gray_concrete replace
fill ~142 ~156 ~907 ~142 ~156 ~908 minecraft:light_gray_concrete replace
fill ~144 ~156 ~910 ~363 ~156 ~910 minecraft:light_gray_concrete replace
fill ~145 ~156 ~911 ~145 ~156 ~912 minecraft:light_gray_concrete replace
fill ~144 ~156 ~914 ~366 ~156 ~914 minecraft:light_gray_concrete replace
fill ~145 ~156 ~915 ~145 ~156 ~916 minecraft:light_gray_concrete replace
fill ~144 ~156 ~918 ~369 ~156 ~918 minecraft:light_gray_concrete replace
fill ~145 ~156 ~919 ~145 ~156 ~920 minecraft:light_gray_concrete replace
fill ~144 ~156 ~922 ~372 ~156 ~922 minecraft:light_gray_concrete replace
fill ~145 ~156 ~923 ~145 ~156 ~924 minecraft:light_gray_concrete replace
fill ~144 ~156 ~926 ~375 ~156 ~926 minecraft:light_gray_concrete replace
fill ~145 ~156 ~927 ~145 ~156 ~928 minecraft:light_gray_concrete replace
fill ~144 ~156 ~930 ~378 ~156 ~930 minecraft:light_gray_concrete replace
fill ~145 ~156 ~931 ~145 ~156 ~932 minecraft:light_gray_concrete replace
fill ~147 ~156 ~934 ~381 ~156 ~934 minecraft:light_gray_concrete replace
fill ~148 ~156 ~935 ~148 ~156 ~936 minecraft:light_gray_concrete replace
fill ~147 ~156 ~938 ~384 ~156 ~938 minecraft:light_gray_concrete replace
fill ~148 ~156 ~939 ~148 ~156 ~940 minecraft:light_gray_concrete replace
fill ~147 ~156 ~942 ~387 ~156 ~942 minecraft:light_gray_concrete replace
fill ~148 ~156 ~943 ~148 ~156 ~944 minecraft:light_gray_concrete replace
fill ~147 ~156 ~946 ~390 ~156 ~946 minecraft:light_gray_concrete replace
fill ~148 ~156 ~947 ~148 ~156 ~948 minecraft:light_gray_concrete replace
fill ~147 ~156 ~950 ~393 ~156 ~950 minecraft:light_gray_concrete replace
fill ~148 ~156 ~951 ~148 ~156 ~952 minecraft:light_gray_concrete replace
fill ~147 ~156 ~954 ~396 ~156 ~954 minecraft:light_gray_concrete replace
fill ~148 ~156 ~955 ~148 ~156 ~956 minecraft:light_gray_concrete replace
fill ~147 ~156 ~958 ~399 ~156 ~958 minecraft:light_gray_concrete replace
fill ~148 ~156 ~959 ~148 ~156 ~960 minecraft:light_gray_concrete replace
fill ~174 ~156 ~962 ~432 ~156 ~962 minecraft:light_gray_concrete replace
fill ~175 ~156 ~963 ~175 ~156 ~964 minecraft:light_gray_concrete replace
fill ~168 ~156 ~966 ~426 ~156 ~966 minecraft:light_gray_concrete replace
fill ~169 ~156 ~967 ~169 ~156 ~968 minecraft:light_gray_concrete replace
fill ~171 ~156 ~970 ~429 ~156 ~970 minecraft:light_gray_concrete replace
fill ~172 ~156 ~971 ~172 ~156 ~972 minecraft:light_gray_concrete replace
setblock ~106 ~157 ~236 minecraft:light_gray_concrete replace
setblock ~82 ~157 ~240 minecraft:light_gray_concrete replace
setblock ~103 ~157 ~268 minecraft:light_gray_concrete replace
setblock ~100 ~157 ~292 minecraft:light_gray_concrete replace
setblock ~97 ~157 ~308 minecraft:light_gray_concrete replace
setblock ~94 ~157 ~336 minecraft:light_gray_concrete replace
setblock ~91 ~157 ~372 minecraft:light_gray_concrete replace
setblock ~88 ~157 ~404 minecraft:light_gray_concrete replace
setblock ~85 ~157 ~436 minecraft:light_gray_concrete replace
setblock ~79 ~157 ~452 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~544 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~552 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~556 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~558 minecraft:light_gray_concrete replace
setblock ~117 ~157 ~558 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~560 minecraft:light_gray_concrete replace
setblock ~111 ~157 ~562 minecraft:light_gray_concrete replace
setblock ~113 ~157 ~562 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~564 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~157 ~566 minecraft:light_gray_concrete replace
setblock ~109 ~157 ~568 minecraft:light_gray_concrete replace
setblock ~120 ~157 ~570 minecraft:light_gray_concrete replace
setblock ~122 ~157 ~570 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~572 minecraft:light_gray_concrete replace
setblock ~128 ~157 ~574 minecraft:light_gray_concrete replace
setblock ~130 ~157 ~574 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~576 minecraft:light_gray_concrete replace
setblock ~123 ~157 ~578 minecraft:light_gray_concrete replace
setblock ~125 ~157 ~578 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~580 minecraft:light_gray_concrete replace
setblock ~128 ~157 ~582 minecraft:light_gray_concrete replace
setblock ~130 ~157 ~582 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~584 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~586 minecraft:light_gray_concrete replace
setblock ~117 ~157 ~586 minecraft:light_gray_concrete replace
setblock ~132 ~157 ~586 minecraft:light_gray_concrete replace
setblock ~134 ~157 ~586 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~588 minecraft:light_gray_concrete replace
setblock ~122 ~157 ~590 minecraft:light_gray_concrete replace
setblock ~124 ~157 ~590 minecraft:light_gray_concrete replace
setblock ~139 ~157 ~590 minecraft:light_gray_concrete replace
setblock ~141 ~157 ~590 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~592 minecraft:light_gray_concrete replace
setblock ~118 ~157 ~594 minecraft:light_gray_concrete replace
setblock ~120 ~157 ~594 minecraft:light_gray_concrete replace
setblock ~135 ~157 ~594 minecraft:light_gray_concrete replace
setblock ~137 ~157 ~594 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~596 minecraft:light_gray_concrete replace
setblock ~122 ~157 ~598 minecraft:light_gray_concrete replace
setblock ~124 ~157 ~598 minecraft:light_gray_concrete replace
setblock ~139 ~157 ~598 minecraft:light_gray_concrete replace
setblock ~141 ~157 ~598 minecraft:light_gray_concrete replace
setblock ~112 ~157 ~600 minecraft:light_gray_concrete replace
setblock ~127 ~157 ~602 minecraft:light_gray_concrete replace
setblock ~129 ~157 ~602 minecraft:light_gray_concrete replace
setblock ~144 ~157 ~602 minecraft:light_gray_concrete replace
setblock ~146 ~157 ~602 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~604 minecraft:light_gray_concrete replace
setblock ~117 ~157 ~606 minecraft:light_gray_concrete replace
setblock ~119 ~157 ~606 minecraft:light_gray_concrete replace
setblock ~134 ~157 ~606 minecraft:light_gray_concrete replace
setblock ~136 ~157 ~606 minecraft:light_gray_concrete replace
setblock ~151 ~157 ~606 minecraft:light_gray_concrete replace
setblock ~153 ~157 ~606 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~608 minecraft:light_gray_concrete replace
setblock ~116 ~157 ~610 minecraft:light_gray_concrete replace
setblock ~118 ~157 ~610 minecraft:light_gray_concrete replace
setblock ~132 ~157 ~610 minecraft:light_gray_concrete replace
setblock ~134 ~157 ~610 minecraft:light_gray_concrete replace
setblock ~148 ~157 ~610 minecraft:light_gray_concrete replace
setblock ~150 ~157 ~610 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~612 minecraft:light_gray_concrete replace
setblock ~117 ~157 ~614 minecraft:light_gray_concrete replace
setblock ~119 ~157 ~614 minecraft:light_gray_concrete replace
setblock ~134 ~157 ~614 minecraft:light_gray_concrete replace
setblock ~136 ~157 ~614 minecraft:light_gray_concrete replace
setblock ~151 ~157 ~614 minecraft:light_gray_concrete replace
setblock ~153 ~157 ~614 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~616 minecraft:light_gray_concrete replace
setblock ~122 ~157 ~618 minecraft:light_gray_concrete replace
setblock ~124 ~157 ~618 minecraft:light_gray_concrete replace
setblock ~139 ~157 ~618 minecraft:light_gray_concrete replace
setblock ~141 ~157 ~618 minecraft:light_gray_concrete replace
setblock ~156 ~157 ~618 minecraft:light_gray_concrete replace
setblock ~158 ~157 ~618 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~620 minecraft:light_gray_concrete replace
setblock ~129 ~157 ~622 minecraft:light_gray_concrete replace
setblock ~131 ~157 ~622 minecraft:light_gray_concrete replace
setblock ~146 ~157 ~622 minecraft:light_gray_concrete replace
setblock ~148 ~157 ~622 minecraft:light_gray_concrete replace
setblock ~163 ~157 ~622 minecraft:light_gray_concrete replace
setblock ~165 ~157 ~622 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~624 minecraft:light_gray_concrete replace
setblock ~125 ~157 ~626 minecraft:light_gray_concrete replace
setblock ~127 ~157 ~626 minecraft:light_gray_concrete replace
setblock ~142 ~157 ~626 minecraft:light_gray_concrete replace
setblock ~144 ~157 ~626 minecraft:light_gray_concrete replace
setblock ~159 ~157 ~626 minecraft:light_gray_concrete replace
setblock ~161 ~157 ~626 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~628 minecraft:light_gray_concrete replace
setblock ~129 ~157 ~630 minecraft:light_gray_concrete replace
setblock ~131 ~157 ~630 minecraft:light_gray_concrete replace
setblock ~146 ~157 ~630 minecraft:light_gray_concrete replace
setblock ~148 ~157 ~630 minecraft:light_gray_concrete replace
setblock ~163 ~157 ~630 minecraft:light_gray_concrete replace
setblock ~165 ~157 ~630 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~632 minecraft:light_gray_concrete replace
setblock ~117 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~119 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~134 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~136 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~151 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~153 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~168 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~170 ~157 ~634 minecraft:light_gray_concrete replace
setblock ~115 ~157 ~636 minecraft:light_gray_concrete replace
setblock ~124 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~126 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~141 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~143 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~158 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~160 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~175 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~177 ~157 ~638 minecraft:light_gray_concrete replace
setblock ~118 ~157 ~640 minecraft:light_gray_concrete replace
setblock ~120 ~157 ~642 minecraft:light_gray_concrete replace
setblock ~122 ~157 ~642 minecraft:light_gray_concrete replace
setblock ~137 ~157 ~642 minecraft:light_gray_concrete replace
setblock ~139 ~157 ~642 minecraft:light_gray_concrete replace
setblock ~154 ~157 ~642 minecraft:light_gray_concrete replace
setblock ~156 ~157 ~642 minecraft:light_gray_concrete replace
setblock ~171 ~157 ~642 minecraft:light_gray_concrete replace
