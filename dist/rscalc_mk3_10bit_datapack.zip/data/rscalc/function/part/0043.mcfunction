setblock ~400 ~153 ~536 minecraft:light_gray_concrete replace
setblock ~256 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~259 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~262 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~265 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~268 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~271 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~274 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~277 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~280 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~283 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~286 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~289 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~292 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~295 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~298 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~301 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~304 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~307 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~310 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~313 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~316 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~319 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~322 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~325 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~328 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~331 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~334 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~337 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~340 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~343 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~346 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~349 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~352 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~355 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~358 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~361 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~364 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~367 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~370 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~373 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~376 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~379 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~382 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~385 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~388 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~391 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~394 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~397 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~400 ~153 ~540 minecraft:light_gray_concrete replace
setblock ~256 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~259 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~262 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~265 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~268 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~271 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~274 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~277 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~280 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~283 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~286 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~289 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~292 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~295 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~298 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~301 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~304 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~307 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~310 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~313 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~316 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~319 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~322 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~325 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~328 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~331 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~334 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~337 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~340 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~343 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~346 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~349 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~352 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~355 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~358 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~361 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~364 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~367 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~370 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~373 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~376 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~379 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~382 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~385 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~388 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~391 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~394 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~397 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~400 ~153 ~564 minecraft:light_gray_concrete replace
setblock ~256 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~259 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~262 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~265 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~268 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~271 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~274 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~277 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~280 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~283 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~286 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~289 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~292 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~295 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~298 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~301 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~304 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~307 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~310 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~313 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~316 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~319 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~322 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~325 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~328 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~331 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~334 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~337 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~340 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~343 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~346 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~349 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~352 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~355 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~358 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~361 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~364 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~367 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~370 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~373 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~376 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~379 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~382 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~385 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~388 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~391 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~394 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~397 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~400 ~153 ~572 minecraft:light_gray_concrete replace
setblock ~403 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~406 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~409 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~412 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~415 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~418 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~421 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~424 ~153 ~596 minecraft:light_gray_concrete replace
setblock ~280 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~282 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~297 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~299 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~314 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~316 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~331 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~333 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~348 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~350 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~365 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~367 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~382 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~384 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~399 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~401 ~153 ~598 minecraft:light_gray_concrete replace
setblock ~403 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~406 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~409 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~412 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~415 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~418 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~421 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~424 ~153 ~600 minecraft:light_gray_concrete replace
setblock ~271 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~273 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~288 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~290 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~305 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~307 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~322 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~324 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~339 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~341 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~356 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~358 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~373 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~375 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~390 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~392 ~153 ~602 minecraft:light_gray_concrete replace
setblock ~256 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~259 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~262 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~265 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~268 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~271 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~274 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~277 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~280 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~283 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~286 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~289 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~292 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~295 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~298 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~301 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~304 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~307 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~310 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~313 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~316 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~319 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~322 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~325 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~328 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~331 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~334 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~337 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~340 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~343 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~346 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~349 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~352 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~355 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~358 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~361 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~364 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~367 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~370 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~373 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~376 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~379 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~382 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~385 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~388 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~391 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~394 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~397 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~400 ~153 ~604 minecraft:light_gray_concrete replace
setblock ~433 ~153 ~640 minecraft:light_gray_concrete replace
setblock ~283 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~285 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~300 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~302 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~317 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~319 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~334 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~336 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~351 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~353 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~368 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~370 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~385 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~387 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~402 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~404 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~419 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~421 ~153 ~642 minecraft:light_gray_concrete replace
setblock ~427 ~153 ~648 minecraft:light_gray_concrete replace
setblock ~277 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~279 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~294 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~296 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~311 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~313 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~328 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~330 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~345 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~347 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~362 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~364 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~379 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~381 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~396 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~398 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~413 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~415 ~153 ~650 minecraft:light_gray_concrete replace
setblock ~430 ~153 ~656 minecraft:light_gray_concrete replace
setblock ~280 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~282 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~297 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~299 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~314 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~316 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~331 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~333 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~348 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~350 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~365 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~367 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~382 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~384 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~399 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~401 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~416 ~153 ~658 minecraft:light_gray_concrete replace
setblock ~418 ~153 ~658 minecraft:light_gray_concrete replace
fill ~105 ~154 ~228 ~105 ~154 ~232 minecraft:light_gray_concrete replace
fill ~81 ~154 ~232 ~81 ~154 ~236 minecraft:light_gray_concrete replace
fill ~102 ~154 ~236 ~102 ~154 ~264 minecraft:light_gray_concrete replace
fill ~99 ~154 ~264 ~99 ~154 ~288 minecraft:light_gray_concrete replace
fill ~96 ~154 ~288 ~96 ~154 ~304 minecraft:light_gray_concrete replace
fill ~93 ~154 ~304 ~93 ~154 ~332 minecraft:light_gray_concrete replace
fill ~90 ~154 ~332 ~90 ~154 ~368 minecraft:light_gray_concrete replace
fill ~87 ~154 ~368 ~87 ~154 ~400 minecraft:light_gray_concrete replace
fill ~84 ~154 ~400 ~84 ~154 ~432 minecraft:light_gray_concrete replace
fill ~78 ~154 ~444 ~78 ~154 ~448 minecraft:light_gray_concrete replace
fill ~108 ~154 ~472 ~108 ~154 ~536 minecraft:light_gray_concrete replace
fill ~111 ~154 ~472 ~111 ~154 ~540 minecraft:light_gray_concrete replace
fill ~114 ~154 ~472 ~114 ~154 ~544 minecraft:light_gray_concrete replace
fill ~117 ~154 ~472 ~117 ~154 ~548 minecraft:light_gray_concrete replace
fill ~120 ~154 ~472 ~120 ~154 ~552 minecraft:light_gray_concrete replace
fill ~123 ~154 ~472 ~123 ~154 ~556 minecraft:light_gray_concrete replace
fill ~126 ~154 ~472 ~126 ~154 ~560 minecraft:light_gray_concrete replace
fill ~129 ~154 ~472 ~129 ~154 ~564 minecraft:light_gray_concrete replace
fill ~132 ~154 ~472 ~132 ~154 ~568 minecraft:light_gray_concrete replace
fill ~135 ~154 ~472 ~135 ~154 ~572 minecraft:light_gray_concrete replace
fill ~138 ~154 ~472 ~138 ~154 ~576 minecraft:light_gray_concrete replace
fill ~141 ~154 ~472 ~141 ~154 ~580 minecraft:light_gray_concrete replace
fill ~144 ~154 ~472 ~144 ~154 ~584 minecraft:light_gray_concrete replace
fill ~147 ~154 ~472 ~147 ~154 ~588 minecraft:light_gray_concrete replace
fill ~150 ~154 ~472 ~150 ~154 ~592 minecraft:light_gray_concrete replace
fill ~153 ~154 ~472 ~153 ~154 ~596 minecraft:light_gray_concrete replace
fill ~156 ~154 ~472 ~156 ~154 ~600 minecraft:light_gray_concrete replace
fill ~159 ~154 ~472 ~159 ~154 ~604 minecraft:light_gray_concrete replace
fill ~162 ~154 ~472 ~162 ~154 ~608 minecraft:light_gray_concrete replace
fill ~165 ~154 ~472 ~165 ~154 ~612 minecraft:light_gray_concrete replace
fill ~168 ~154 ~472 ~168 ~154 ~616 minecraft:light_gray_concrete replace
fill ~171 ~154 ~472 ~171 ~154 ~620 minecraft:light_gray_concrete replace
fill ~174 ~154 ~472 ~174 ~154 ~624 minecraft:light_gray_concrete replace
fill ~177 ~154 ~472 ~177 ~154 ~628 minecraft:light_gray_concrete replace
fill ~180 ~154 ~472 ~180 ~154 ~632 minecraft:light_gray_concrete replace
fill ~183 ~154 ~472 ~183 ~154 ~636 minecraft:light_gray_concrete replace
fill ~186 ~154 ~472 ~186 ~154 ~640 minecraft:light_gray_concrete replace
fill ~189 ~154 ~472 ~189 ~154 ~644 minecraft:light_gray_concrete replace
fill ~192 ~154 ~472 ~192 ~154 ~648 minecraft:light_gray_concrete replace
fill ~195 ~154 ~472 ~195 ~154 ~652 minecraft:light_gray_concrete replace
fill ~198 ~154 ~472 ~198 ~154 ~656 minecraft:light_gray_concrete replace
fill ~201 ~154 ~472 ~201 ~154 ~660 minecraft:light_gray_concrete replace
fill ~204 ~154 ~472 ~204 ~154 ~664 minecraft:light_gray_concrete replace
fill ~207 ~154 ~472 ~207 ~154 ~668 minecraft:light_gray_concrete replace
fill ~210 ~154 ~472 ~210 ~154 ~672 minecraft:light_gray_concrete replace
fill ~213 ~154 ~472 ~213 ~154 ~676 minecraft:light_gray_concrete replace
fill ~216 ~154 ~472 ~216 ~154 ~680 minecraft:light_gray_concrete replace
fill ~219 ~154 ~472 ~219 ~154 ~684 minecraft:light_gray_concrete replace
fill ~222 ~154 ~472 ~222 ~154 ~688 minecraft:light_gray_concrete replace
fill ~225 ~154 ~472 ~225 ~154 ~692 minecraft:light_gray_concrete replace
fill ~228 ~154 ~472 ~228 ~154 ~696 minecraft:light_gray_concrete replace
fill ~231 ~154 ~472 ~231 ~154 ~700 minecraft:light_gray_concrete replace
fill ~234 ~154 ~472 ~234 ~154 ~704 minecraft:light_gray_concrete replace
fill ~237 ~154 ~472 ~237 ~154 ~708 minecraft:light_gray_concrete replace
fill ~240 ~154 ~472 ~240 ~154 ~712 minecraft:light_gray_concrete replace
fill ~243 ~154 ~472 ~243 ~154 ~716 minecraft:light_gray_concrete replace
fill ~246 ~154 ~472 ~246 ~154 ~720 minecraft:light_gray_concrete replace
fill ~249 ~154 ~472 ~249 ~154 ~724 minecraft:light_gray_concrete replace
fill ~252 ~154 ~472 ~252 ~154 ~728 minecraft:light_gray_concrete replace
fill ~255 ~154 ~536 ~255 ~154 ~764 minecraft:light_gray_concrete replace
fill ~258 ~154 ~536 ~258 ~154 ~768 minecraft:light_gray_concrete replace
fill ~261 ~154 ~536 ~261 ~154 ~772 minecraft:light_gray_concrete replace
fill ~264 ~154 ~536 ~264 ~154 ~776 minecraft:light_gray_concrete replace
fill ~267 ~154 ~536 ~267 ~154 ~780 minecraft:light_gray_concrete replace
fill ~270 ~154 ~536 ~270 ~154 ~784 minecraft:light_gray_concrete replace
fill ~273 ~154 ~536 ~273 ~154 ~788 minecraft:light_gray_concrete replace
fill ~276 ~154 ~536 ~276 ~154 ~792 minecraft:light_gray_concrete replace
fill ~279 ~154 ~536 ~279 ~154 ~796 minecraft:light_gray_concrete replace
fill ~282 ~154 ~536 ~282 ~154 ~800 minecraft:light_gray_concrete replace
fill ~285 ~154 ~536 ~285 ~154 ~804 minecraft:light_gray_concrete replace
fill ~288 ~154 ~536 ~288 ~154 ~808 minecraft:light_gray_concrete replace
fill ~291 ~154 ~536 ~291 ~154 ~812 minecraft:light_gray_concrete replace
fill ~294 ~154 ~536 ~294 ~154 ~816 minecraft:light_gray_concrete replace
fill ~297 ~154 ~536 ~297 ~154 ~820 minecraft:light_gray_concrete replace
fill ~300 ~154 ~536 ~300 ~154 ~824 minecraft:light_gray_concrete replace
fill ~303 ~154 ~536 ~303 ~154 ~828 minecraft:light_gray_concrete replace
fill ~306 ~154 ~536 ~306 ~154 ~832 minecraft:light_gray_concrete replace
fill ~309 ~154 ~536 ~309 ~154 ~836 minecraft:light_gray_concrete replace
fill ~312 ~154 ~536 ~312 ~154 ~840 minecraft:light_gray_concrete replace
fill ~315 ~154 ~536 ~315 ~154 ~844 minecraft:light_gray_concrete replace
fill ~318 ~154 ~536 ~318 ~154 ~848 minecraft:light_gray_concrete replace
fill ~321 ~154 ~536 ~321 ~154 ~852 minecraft:light_gray_concrete replace
fill ~324 ~154 ~536 ~324 ~154 ~856 minecraft:light_gray_concrete replace
fill ~327 ~154 ~536 ~327 ~154 ~860 minecraft:light_gray_concrete replace
fill ~330 ~154 ~536 ~330 ~154 ~864 minecraft:light_gray_concrete replace
fill ~333 ~154 ~536 ~333 ~154 ~868 minecraft:light_gray_concrete replace
fill ~336 ~154 ~536 ~336 ~154 ~872 minecraft:light_gray_concrete replace
fill ~339 ~154 ~536 ~339 ~154 ~876 minecraft:light_gray_concrete replace
fill ~342 ~154 ~536 ~342 ~154 ~880 minecraft:light_gray_concrete replace
fill ~345 ~154 ~536 ~345 ~154 ~884 minecraft:light_gray_concrete replace
fill ~348 ~154 ~536 ~348 ~154 ~888 minecraft:light_gray_concrete replace
fill ~351 ~154 ~536 ~351 ~154 ~892 minecraft:light_gray_concrete replace
fill ~354 ~154 ~536 ~354 ~154 ~896 minecraft:light_gray_concrete replace
fill ~357 ~154 ~536 ~357 ~154 ~900 minecraft:light_gray_concrete replace
fill ~360 ~154 ~536 ~360 ~154 ~904 minecraft:light_gray_concrete replace
fill ~363 ~154 ~536 ~363 ~154 ~908 minecraft:light_gray_concrete replace
fill ~366 ~154 ~536 ~366 ~154 ~912 minecraft:light_gray_concrete replace
fill ~369 ~154 ~536 ~369 ~154 ~916 minecraft:light_gray_concrete replace
fill ~372 ~154 ~536 ~372 ~154 ~920 minecraft:light_gray_concrete replace
fill ~375 ~154 ~536 ~375 ~154 ~924 minecraft:light_gray_concrete replace
fill ~378 ~154 ~536 ~378 ~154 ~928 minecraft:light_gray_concrete replace
fill ~381 ~154 ~536 ~381 ~154 ~932 minecraft:light_gray_concrete replace
fill ~384 ~154 ~536 ~384 ~154 ~936 minecraft:light_gray_concrete replace
fill ~387 ~154 ~536 ~387 ~154 ~940 minecraft:light_gray_concrete replace
fill ~390 ~154 ~536 ~390 ~154 ~944 minecraft:light_gray_concrete replace
fill ~393 ~154 ~536 ~393 ~154 ~948 minecraft:light_gray_concrete replace
fill ~396 ~154 ~536 ~396 ~154 ~952 minecraft:light_gray_concrete replace
fill ~399 ~154 ~536 ~399 ~154 ~956 minecraft:light_gray_concrete replace
fill ~402 ~154 ~596 ~402 ~154 ~732 minecraft:light_gray_concrete replace
fill ~405 ~154 ~596 ~405 ~154 ~736 minecraft:light_gray_concrete replace
fill ~408 ~154 ~596 ~408 ~154 ~740 minecraft:light_gray_concrete replace
fill ~411 ~154 ~596 ~411 ~154 ~744 minecraft:light_gray_concrete replace
fill ~414 ~154 ~596 ~414 ~154 ~748 minecraft:light_gray_concrete replace
fill ~417 ~154 ~596 ~417 ~154 ~752 minecraft:light_gray_concrete replace
fill ~420 ~154 ~596 ~420 ~154 ~756 minecraft:light_gray_concrete replace
fill ~423 ~154 ~596 ~423 ~154 ~760 minecraft:light_gray_concrete replace
fill ~432 ~154 ~640 ~432 ~154 ~960 minecraft:light_gray_concrete replace
fill ~426 ~154 ~648 ~426 ~154 ~964 minecraft:light_gray_concrete replace
fill ~429 ~154 ~656 ~429 ~154 ~968 minecraft:light_gray_concrete replace
setblock ~105 ~155 ~233 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~236 minecraft:light_gray_concrete replace
setblock ~81 ~155 ~237 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~240 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~244 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~248 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~252 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~256 minecraft:light_gray_concrete replace
setblock ~103 ~155 ~260 minecraft:light_gray_concrete replace
setblock ~100 ~155 ~264 minecraft:light_gray_concrete replace
setblock ~102 ~155 ~265 minecraft:light_gray_concrete replace
setblock ~100 ~155 ~268 minecraft:light_gray_concrete replace
setblock ~100 ~155 ~272 minecraft:light_gray_concrete replace
setblock ~100 ~155 ~276 minecraft:light_gray_concrete replace
setblock ~100 ~155 ~280 minecraft:light_gray_concrete replace
setblock ~100 ~155 ~284 minecraft:light_gray_concrete replace
setblock ~99 ~155 ~287 minecraft:light_gray_concrete replace
setblock ~97 ~155 ~288 minecraft:light_gray_concrete replace
setblock ~99 ~155 ~289 minecraft:light_gray_concrete replace
setblock ~97 ~155 ~292 minecraft:light_gray_concrete replace
setblock ~97 ~155 ~296 minecraft:light_gray_concrete replace
setblock ~97 ~155 ~300 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~304 minecraft:light_gray_concrete replace
setblock ~96 ~155 ~305 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~308 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~312 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~316 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~320 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~324 minecraft:light_gray_concrete replace
setblock ~94 ~155 ~328 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~332 minecraft:light_gray_concrete replace
setblock ~93 ~155 ~333 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~336 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~340 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~344 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~348 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~352 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~356 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~360 minecraft:light_gray_concrete replace
setblock ~91 ~155 ~364 minecraft:light_gray_concrete replace
setblock ~90 ~155 ~367 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~368 minecraft:light_gray_concrete replace
setblock ~90 ~155 ~369 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~372 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~376 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~380 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~384 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~388 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~155 ~396 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~400 minecraft:light_gray_concrete replace
setblock ~87 ~155 ~401 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~404 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~408 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~412 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~416 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~420 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~424 minecraft:light_gray_concrete replace
setblock ~85 ~155 ~428 minecraft:light_gray_concrete replace
setblock ~84 ~155 ~433 minecraft:light_gray_concrete replace
setblock ~78 ~155 ~449 minecraft:light_gray_concrete replace
setblock ~109 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~112 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~115 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~118 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~121 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~124 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~127 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~130 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~133 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~136 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~139 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~142 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~145 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~148 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~151 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~154 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~157 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~160 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~163 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~166 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~169 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~172 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~175 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~178 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~181 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~184 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~187 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~190 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~193 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~196 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~199 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~202 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~205 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~208 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~211 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~214 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~217 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~220 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~223 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~226 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~229 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~232 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~235 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~238 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~241 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~244 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~247 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~250 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~253 ~155 ~472 minecraft:light_gray_concrete replace
setblock ~115 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~118 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~124 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~130 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~136 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~142 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~148 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~154 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~160 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~163 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~169 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~175 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~181 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~190 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~193 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~202 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~223 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~232 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~238 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~244 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~253 ~155 ~476 minecraft:light_gray_concrete replace
setblock ~108 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~111 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~114 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~117 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~120 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~123 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~126 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~129 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~132 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~135 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~138 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~141 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~144 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~147 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~150 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~153 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~156 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~159 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~162 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~165 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~168 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~171 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~174 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~177 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~180 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~183 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~186 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~189 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~192 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~195 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~198 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~201 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~204 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~207 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~210 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~213 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~216 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~219 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~222 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~225 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~228 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~231 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~234 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~237 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~240 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~243 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~246 ~155 ~485 minecraft:light_gray_concrete replace
setblock ~249 ~155 ~485 minecraft:light_gray_concrete replace
