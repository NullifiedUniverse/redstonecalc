fill ~150 ~27 ~144 ~150 ~27 ~156 minecraft:redstone_wire replace
fill ~174 ~27 ~144 ~174 ~27 ~156 minecraft:redstone_wire replace
fill ~198 ~27 ~144 ~198 ~27 ~156 minecraft:redstone_wire replace
fill ~237 ~27 ~144 ~237 ~27 ~156 minecraft:redstone_wire replace
fill ~315 ~27 ~144 ~315 ~27 ~156 minecraft:redstone_wire replace
fill ~342 ~27 ~144 ~342 ~27 ~156 minecraft:redstone_wire replace
setblock ~78 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~148 ~78 ~27 ~160 minecraft:redstone_wire replace
fill ~81 ~27 ~148 ~81 ~27 ~160 minecraft:redstone_wire replace
fill ~117 ~27 ~148 ~117 ~27 ~160 minecraft:redstone_wire replace
fill ~129 ~27 ~148 ~129 ~27 ~160 minecraft:redstone_wire replace
fill ~132 ~27 ~148 ~132 ~27 ~160 minecraft:redstone_wire replace
fill ~135 ~27 ~148 ~135 ~27 ~160 minecraft:redstone_wire replace
fill ~165 ~27 ~148 ~165 ~27 ~160 minecraft:redstone_wire replace
fill ~186 ~27 ~148 ~186 ~27 ~160 minecraft:redstone_wire replace
fill ~240 ~27 ~148 ~240 ~27 ~160 minecraft:redstone_wire replace
fill ~264 ~27 ~148 ~264 ~27 ~160 minecraft:redstone_wire replace
setblock ~84 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~152 ~84 ~27 ~164 minecraft:redstone_wire replace
fill ~96 ~27 ~152 ~96 ~27 ~164 minecraft:redstone_wire replace
fill ~102 ~27 ~152 ~102 ~27 ~164 minecraft:redstone_wire replace
fill ~111 ~27 ~152 ~111 ~27 ~164 minecraft:redstone_wire replace
fill ~141 ~27 ~152 ~141 ~27 ~164 minecraft:redstone_wire replace
fill ~156 ~27 ~152 ~156 ~27 ~164 minecraft:redstone_wire replace
fill ~159 ~27 ~152 ~159 ~27 ~164 minecraft:redstone_wire replace
fill ~168 ~27 ~152 ~168 ~27 ~164 minecraft:redstone_wire replace
fill ~171 ~27 ~152 ~171 ~27 ~164 minecraft:redstone_wire replace
fill ~201 ~27 ~152 ~201 ~27 ~164 minecraft:redstone_wire replace
fill ~234 ~27 ~152 ~234 ~27 ~164 minecraft:redstone_wire replace
fill ~291 ~27 ~152 ~291 ~27 ~164 minecraft:redstone_wire replace
fill ~312 ~27 ~152 ~312 ~27 ~164 minecraft:redstone_wire replace
fill ~336 ~27 ~152 ~336 ~27 ~164 minecraft:redstone_wire replace
setblock ~87 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~156 ~87 ~27 ~168 minecraft:redstone_wire replace
fill ~99 ~27 ~156 ~99 ~27 ~168 minecraft:redstone_wire replace
fill ~105 ~27 ~156 ~105 ~27 ~168 minecraft:redstone_wire replace
fill ~120 ~27 ~156 ~120 ~27 ~168 minecraft:redstone_wire replace
fill ~144 ~27 ~156 ~144 ~27 ~168 minecraft:redstone_wire replace
fill ~180 ~27 ~156 ~180 ~27 ~168 minecraft:redstone_wire replace
fill ~183 ~27 ~156 ~183 ~27 ~168 minecraft:redstone_wire replace
fill ~204 ~27 ~156 ~204 ~27 ~168 minecraft:redstone_wire replace
fill ~210 ~27 ~156 ~210 ~27 ~168 minecraft:redstone_wire replace
fill ~213 ~27 ~156 ~213 ~27 ~168 minecraft:redstone_wire replace
fill ~261 ~27 ~156 ~261 ~27 ~168 minecraft:redstone_wire replace
fill ~270 ~27 ~156 ~270 ~27 ~168 minecraft:redstone_wire replace
fill ~279 ~27 ~156 ~279 ~27 ~168 minecraft:redstone_wire replace
setblock ~90 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~160 ~90 ~27 ~172 minecraft:redstone_wire replace
fill ~108 ~27 ~160 ~108 ~27 ~172 minecraft:redstone_wire replace
fill ~114 ~27 ~160 ~114 ~27 ~172 minecraft:redstone_wire replace
fill ~123 ~27 ~160 ~123 ~27 ~172 minecraft:redstone_wire replace
fill ~138 ~27 ~160 ~138 ~27 ~172 minecraft:redstone_wire replace
fill ~150 ~27 ~160 ~150 ~27 ~172 minecraft:redstone_wire replace
fill ~174 ~27 ~160 ~174 ~27 ~172 minecraft:redstone_wire replace
fill ~189 ~27 ~160 ~189 ~27 ~172 minecraft:redstone_wire replace
fill ~198 ~27 ~160 ~198 ~27 ~172 minecraft:redstone_wire replace
fill ~237 ~27 ~160 ~237 ~27 ~172 minecraft:redstone_wire replace
fill ~315 ~27 ~160 ~315 ~27 ~172 minecraft:redstone_wire replace
fill ~342 ~27 ~160 ~342 ~27 ~172 minecraft:redstone_wire replace
setblock ~78 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~164 ~78 ~27 ~176 minecraft:redstone_wire replace
fill ~81 ~27 ~164 ~81 ~27 ~176 minecraft:redstone_wire replace
fill ~117 ~27 ~164 ~117 ~27 ~176 minecraft:redstone_wire replace
fill ~129 ~27 ~164 ~129 ~27 ~176 minecraft:redstone_wire replace
fill ~132 ~27 ~164 ~132 ~27 ~176 minecraft:redstone_wire replace
fill ~135 ~27 ~164 ~135 ~27 ~176 minecraft:redstone_wire replace
fill ~165 ~27 ~164 ~165 ~27 ~176 minecraft:redstone_wire replace
fill ~186 ~27 ~164 ~186 ~27 ~176 minecraft:redstone_wire replace
fill ~192 ~27 ~164 ~192 ~27 ~176 minecraft:redstone_wire replace
fill ~240 ~27 ~164 ~240 ~27 ~176 minecraft:redstone_wire replace
fill ~264 ~27 ~164 ~264 ~27 ~176 minecraft:redstone_wire replace
setblock ~84 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~168 ~84 ~27 ~180 minecraft:redstone_wire replace
fill ~96 ~27 ~168 ~96 ~27 ~180 minecraft:redstone_wire replace
fill ~102 ~27 ~168 ~102 ~27 ~180 minecraft:redstone_wire replace
fill ~111 ~27 ~168 ~111 ~27 ~180 minecraft:redstone_wire replace
fill ~141 ~27 ~168 ~141 ~27 ~180 minecraft:redstone_wire replace
fill ~156 ~27 ~168 ~156 ~27 ~180 minecraft:redstone_wire replace
fill ~159 ~27 ~168 ~159 ~27 ~180 minecraft:redstone_wire replace
fill ~168 ~27 ~168 ~168 ~27 ~180 minecraft:redstone_wire replace
fill ~171 ~27 ~168 ~171 ~27 ~180 minecraft:redstone_wire replace
fill ~195 ~27 ~168 ~195 ~27 ~180 minecraft:redstone_wire replace
fill ~201 ~27 ~168 ~201 ~27 ~180 minecraft:redstone_wire replace
fill ~234 ~27 ~168 ~234 ~27 ~180 minecraft:redstone_wire replace
fill ~291 ~27 ~168 ~291 ~27 ~180 minecraft:redstone_wire replace
fill ~312 ~27 ~168 ~312 ~27 ~180 minecraft:redstone_wire replace
fill ~336 ~27 ~168 ~336 ~27 ~180 minecraft:redstone_wire replace
setblock ~87 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~172 ~87 ~27 ~184 minecraft:redstone_wire replace
fill ~99 ~27 ~172 ~99 ~27 ~184 minecraft:redstone_wire replace
fill ~105 ~27 ~172 ~105 ~27 ~184 minecraft:redstone_wire replace
fill ~120 ~27 ~172 ~120 ~27 ~184 minecraft:redstone_wire replace
fill ~144 ~27 ~172 ~144 ~27 ~184 minecraft:redstone_wire replace
fill ~180 ~27 ~172 ~180 ~27 ~184 minecraft:redstone_wire replace
fill ~183 ~27 ~172 ~183 ~27 ~184 minecraft:redstone_wire replace
fill ~204 ~27 ~172 ~204 ~27 ~184 minecraft:redstone_wire replace
fill ~210 ~27 ~172 ~210 ~27 ~184 minecraft:redstone_wire replace
fill ~213 ~27 ~172 ~213 ~27 ~184 minecraft:redstone_wire replace
fill ~228 ~27 ~172 ~228 ~27 ~184 minecraft:redstone_wire replace
fill ~231 ~27 ~172 ~231 ~27 ~184 minecraft:redstone_wire replace
fill ~261 ~27 ~172 ~261 ~27 ~184 minecraft:redstone_wire replace
fill ~270 ~27 ~172 ~270 ~27 ~184 minecraft:redstone_wire replace
fill ~279 ~27 ~172 ~279 ~27 ~184 minecraft:redstone_wire replace
setblock ~90 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~176 ~90 ~27 ~188 minecraft:redstone_wire replace
fill ~108 ~27 ~176 ~108 ~27 ~188 minecraft:redstone_wire replace
fill ~114 ~27 ~176 ~114 ~27 ~188 minecraft:redstone_wire replace
fill ~123 ~27 ~176 ~123 ~27 ~188 minecraft:redstone_wire replace
fill ~138 ~27 ~176 ~138 ~27 ~188 minecraft:redstone_wire replace
fill ~150 ~27 ~176 ~150 ~27 ~188 minecraft:redstone_wire replace
fill ~174 ~27 ~176 ~174 ~27 ~188 minecraft:redstone_wire replace
fill ~189 ~27 ~176 ~189 ~27 ~188 minecraft:redstone_wire replace
fill ~198 ~27 ~176 ~198 ~27 ~188 minecraft:redstone_wire replace
fill ~216 ~27 ~176 ~216 ~27 ~188 minecraft:redstone_wire replace
fill ~237 ~27 ~176 ~237 ~27 ~188 minecraft:redstone_wire replace
fill ~315 ~27 ~176 ~315 ~27 ~188 minecraft:redstone_wire replace
fill ~342 ~27 ~176 ~342 ~27 ~188 minecraft:redstone_wire replace
setblock ~78 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~180 ~78 ~27 ~192 minecraft:redstone_wire replace
fill ~81 ~27 ~180 ~81 ~27 ~192 minecraft:redstone_wire replace
fill ~117 ~27 ~180 ~117 ~27 ~192 minecraft:redstone_wire replace
fill ~129 ~27 ~180 ~129 ~27 ~192 minecraft:redstone_wire replace
fill ~132 ~27 ~180 ~132 ~27 ~192 minecraft:redstone_wire replace
fill ~135 ~27 ~180 ~135 ~27 ~192 minecraft:redstone_wire replace
fill ~165 ~27 ~180 ~165 ~27 ~192 minecraft:redstone_wire replace
fill ~186 ~27 ~180 ~186 ~27 ~192 minecraft:redstone_wire replace
fill ~192 ~27 ~180 ~192 ~27 ~192 minecraft:redstone_wire replace
fill ~219 ~27 ~180 ~219 ~27 ~192 minecraft:redstone_wire replace
fill ~240 ~27 ~180 ~240 ~27 ~192 minecraft:redstone_wire replace
fill ~264 ~27 ~180 ~264 ~27 ~192 minecraft:redstone_wire replace
setblock ~84 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~184 ~84 ~27 ~196 minecraft:redstone_wire replace
fill ~96 ~27 ~184 ~96 ~27 ~196 minecraft:redstone_wire replace
fill ~102 ~27 ~184 ~102 ~27 ~196 minecraft:redstone_wire replace
fill ~111 ~27 ~184 ~111 ~27 ~196 minecraft:redstone_wire replace
fill ~141 ~27 ~184 ~141 ~27 ~196 minecraft:redstone_wire replace
fill ~156 ~27 ~184 ~156 ~27 ~196 minecraft:redstone_wire replace
fill ~159 ~27 ~184 ~159 ~27 ~196 minecraft:redstone_wire replace
fill ~168 ~27 ~184 ~168 ~27 ~196 minecraft:redstone_wire replace
fill ~171 ~27 ~184 ~171 ~27 ~196 minecraft:redstone_wire replace
fill ~195 ~27 ~184 ~195 ~27 ~196 minecraft:redstone_wire replace
fill ~201 ~27 ~184 ~201 ~27 ~196 minecraft:redstone_wire replace
fill ~222 ~27 ~184 ~222 ~27 ~196 minecraft:redstone_wire replace
fill ~234 ~27 ~184 ~234 ~27 ~196 minecraft:redstone_wire replace
fill ~291 ~27 ~184 ~291 ~27 ~196 minecraft:redstone_wire replace
fill ~312 ~27 ~184 ~312 ~27 ~196 minecraft:redstone_wire replace
fill ~336 ~27 ~184 ~336 ~27 ~196 minecraft:redstone_wire replace
setblock ~87 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~188 ~87 ~27 ~200 minecraft:redstone_wire replace
fill ~99 ~27 ~188 ~99 ~27 ~200 minecraft:redstone_wire replace
fill ~105 ~27 ~188 ~105 ~27 ~200 minecraft:redstone_wire replace
fill ~120 ~27 ~188 ~120 ~27 ~200 minecraft:redstone_wire replace
fill ~144 ~27 ~188 ~144 ~27 ~200 minecraft:redstone_wire replace
fill ~180 ~27 ~188 ~180 ~27 ~200 minecraft:redstone_wire replace
fill ~183 ~27 ~188 ~183 ~27 ~200 minecraft:redstone_wire replace
fill ~204 ~27 ~188 ~204 ~27 ~200 minecraft:redstone_wire replace
fill ~210 ~27 ~188 ~210 ~27 ~200 minecraft:redstone_wire replace
fill ~213 ~27 ~188 ~213 ~27 ~200 minecraft:redstone_wire replace
fill ~228 ~27 ~188 ~228 ~27 ~200 minecraft:redstone_wire replace
fill ~231 ~27 ~188 ~231 ~27 ~200 minecraft:redstone_wire replace
fill ~252 ~27 ~188 ~252 ~27 ~200 minecraft:redstone_wire replace
fill ~255 ~27 ~188 ~255 ~27 ~200 minecraft:redstone_wire replace
fill ~261 ~27 ~188 ~261 ~27 ~200 minecraft:redstone_wire replace
fill ~270 ~27 ~188 ~270 ~27 ~200 minecraft:redstone_wire replace
fill ~279 ~27 ~188 ~279 ~27 ~200 minecraft:redstone_wire replace
setblock ~90 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~192 ~90 ~27 ~204 minecraft:redstone_wire replace
fill ~108 ~27 ~192 ~108 ~27 ~204 minecraft:redstone_wire replace
fill ~114 ~27 ~192 ~114 ~27 ~204 minecraft:redstone_wire replace
fill ~123 ~27 ~192 ~123 ~27 ~204 minecraft:redstone_wire replace
fill ~138 ~27 ~192 ~138 ~27 ~204 minecraft:redstone_wire replace
fill ~150 ~27 ~192 ~150 ~27 ~204 minecraft:redstone_wire replace
fill ~174 ~27 ~192 ~174 ~27 ~204 minecraft:redstone_wire replace
fill ~189 ~27 ~192 ~189 ~27 ~204 minecraft:redstone_wire replace
fill ~198 ~27 ~192 ~198 ~27 ~204 minecraft:redstone_wire replace
fill ~216 ~27 ~192 ~216 ~27 ~204 minecraft:redstone_wire replace
fill ~237 ~27 ~192 ~237 ~27 ~204 minecraft:redstone_wire replace
fill ~243 ~27 ~192 ~243 ~27 ~204 minecraft:redstone_wire replace
fill ~315 ~27 ~192 ~315 ~27 ~204 minecraft:redstone_wire replace
fill ~342 ~27 ~192 ~342 ~27 ~204 minecraft:redstone_wire replace
setblock ~78 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~196 ~78 ~27 ~208 minecraft:redstone_wire replace
fill ~81 ~27 ~196 ~81 ~27 ~208 minecraft:redstone_wire replace
fill ~117 ~27 ~196 ~117 ~27 ~208 minecraft:redstone_wire replace
fill ~129 ~27 ~196 ~129 ~27 ~208 minecraft:redstone_wire replace
fill ~132 ~27 ~196 ~132 ~27 ~208 minecraft:redstone_wire replace
fill ~135 ~27 ~196 ~135 ~27 ~208 minecraft:redstone_wire replace
fill ~165 ~27 ~196 ~165 ~27 ~208 minecraft:redstone_wire replace
fill ~186 ~27 ~196 ~186 ~27 ~208 minecraft:redstone_wire replace
fill ~192 ~27 ~196 ~192 ~27 ~208 minecraft:redstone_wire replace
fill ~219 ~27 ~196 ~219 ~27 ~208 minecraft:redstone_wire replace
fill ~240 ~27 ~196 ~240 ~27 ~208 minecraft:redstone_wire replace
fill ~246 ~27 ~196 ~246 ~27 ~208 minecraft:redstone_wire replace
fill ~264 ~27 ~196 ~264 ~27 ~208 minecraft:redstone_wire replace
setblock ~84 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~200 ~84 ~27 ~212 minecraft:redstone_wire replace
fill ~96 ~27 ~200 ~96 ~27 ~212 minecraft:redstone_wire replace
fill ~102 ~27 ~200 ~102 ~27 ~212 minecraft:redstone_wire replace
fill ~111 ~27 ~200 ~111 ~27 ~212 minecraft:redstone_wire replace
fill ~141 ~27 ~200 ~141 ~27 ~212 minecraft:redstone_wire replace
fill ~156 ~27 ~200 ~156 ~27 ~212 minecraft:redstone_wire replace
fill ~159 ~27 ~200 ~159 ~27 ~212 minecraft:redstone_wire replace
fill ~168 ~27 ~200 ~168 ~27 ~212 minecraft:redstone_wire replace
fill ~171 ~27 ~200 ~171 ~27 ~212 minecraft:redstone_wire replace
fill ~195 ~27 ~200 ~195 ~27 ~212 minecraft:redstone_wire replace
fill ~201 ~27 ~200 ~201 ~27 ~212 minecraft:redstone_wire replace
fill ~222 ~27 ~200 ~222 ~27 ~212 minecraft:redstone_wire replace
fill ~234 ~27 ~200 ~234 ~27 ~212 minecraft:redstone_wire replace
fill ~258 ~27 ~200 ~258 ~27 ~212 minecraft:redstone_wire replace
fill ~291 ~27 ~200 ~291 ~27 ~212 minecraft:redstone_wire replace
fill ~312 ~27 ~200 ~312 ~27 ~212 minecraft:redstone_wire replace
fill ~336 ~27 ~200 ~336 ~27 ~212 minecraft:redstone_wire replace
setblock ~87 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~204 ~87 ~27 ~216 minecraft:redstone_wire replace
fill ~99 ~27 ~204 ~99 ~27 ~216 minecraft:redstone_wire replace
fill ~105 ~27 ~204 ~105 ~27 ~216 minecraft:redstone_wire replace
fill ~120 ~27 ~204 ~120 ~27 ~216 minecraft:redstone_wire replace
fill ~144 ~27 ~204 ~144 ~27 ~216 minecraft:redstone_wire replace
fill ~180 ~27 ~204 ~180 ~27 ~216 minecraft:redstone_wire replace
fill ~183 ~27 ~204 ~183 ~27 ~216 minecraft:redstone_wire replace
fill ~204 ~27 ~204 ~204 ~27 ~216 minecraft:redstone_wire replace
fill ~210 ~27 ~204 ~210 ~27 ~216 minecraft:redstone_wire replace
fill ~213 ~27 ~204 ~213 ~27 ~216 minecraft:redstone_wire replace
fill ~228 ~27 ~204 ~228 ~27 ~216 minecraft:redstone_wire replace
fill ~231 ~27 ~204 ~231 ~27 ~216 minecraft:redstone_wire replace
fill ~252 ~27 ~204 ~252 ~27 ~216 minecraft:redstone_wire replace
fill ~255 ~27 ~204 ~255 ~27 ~216 minecraft:redstone_wire replace
fill ~261 ~27 ~204 ~261 ~27 ~216 minecraft:redstone_wire replace
fill ~270 ~27 ~204 ~270 ~27 ~216 minecraft:redstone_wire replace
fill ~279 ~27 ~204 ~279 ~27 ~216 minecraft:redstone_wire replace
fill ~285 ~27 ~204 ~285 ~27 ~216 minecraft:redstone_wire replace
fill ~288 ~27 ~204 ~288 ~27 ~216 minecraft:redstone_wire replace
setblock ~90 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~208 ~90 ~27 ~220 minecraft:redstone_wire replace
fill ~108 ~27 ~208 ~108 ~27 ~220 minecraft:redstone_wire replace
fill ~114 ~27 ~208 ~114 ~27 ~220 minecraft:redstone_wire replace
fill ~123 ~27 ~208 ~123 ~27 ~220 minecraft:redstone_wire replace
fill ~138 ~27 ~208 ~138 ~27 ~220 minecraft:redstone_wire replace
fill ~150 ~27 ~208 ~150 ~27 ~220 minecraft:redstone_wire replace
fill ~174 ~27 ~208 ~174 ~27 ~220 minecraft:redstone_wire replace
fill ~189 ~27 ~208 ~189 ~27 ~220 minecraft:redstone_wire replace
fill ~198 ~27 ~208 ~198 ~27 ~220 minecraft:redstone_wire replace
fill ~216 ~27 ~208 ~216 ~27 ~220 minecraft:redstone_wire replace
fill ~237 ~27 ~208 ~237 ~27 ~220 minecraft:redstone_wire replace
fill ~243 ~27 ~208 ~243 ~27 ~220 minecraft:redstone_wire replace
fill ~294 ~27 ~208 ~294 ~27 ~220 minecraft:redstone_wire replace
fill ~297 ~27 ~208 ~297 ~27 ~220 minecraft:redstone_wire replace
fill ~315 ~27 ~208 ~315 ~27 ~220 minecraft:redstone_wire replace
fill ~342 ~27 ~208 ~342 ~27 ~220 minecraft:redstone_wire replace
setblock ~78 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~212 ~78 ~27 ~224 minecraft:redstone_wire replace
fill ~81 ~27 ~212 ~81 ~27 ~224 minecraft:redstone_wire replace
fill ~117 ~27 ~212 ~117 ~27 ~224 minecraft:redstone_wire replace
fill ~129 ~27 ~212 ~129 ~27 ~224 minecraft:redstone_wire replace
fill ~132 ~27 ~212 ~132 ~27 ~224 minecraft:redstone_wire replace
fill ~135 ~27 ~212 ~135 ~27 ~224 minecraft:redstone_wire replace
fill ~165 ~27 ~212 ~165 ~27 ~224 minecraft:redstone_wire replace
fill ~186 ~27 ~212 ~186 ~27 ~224 minecraft:redstone_wire replace
fill ~192 ~27 ~212 ~192 ~27 ~224 minecraft:redstone_wire replace
fill ~219 ~27 ~212 ~219 ~27 ~224 minecraft:redstone_wire replace
fill ~240 ~27 ~212 ~240 ~27 ~224 minecraft:redstone_wire replace
fill ~246 ~27 ~212 ~246 ~27 ~224 minecraft:redstone_wire replace
fill ~264 ~27 ~212 ~264 ~27 ~224 minecraft:redstone_wire replace
fill ~318 ~27 ~212 ~318 ~27 ~224 minecraft:redstone_wire replace
setblock ~84 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~216 ~84 ~27 ~228 minecraft:redstone_wire replace
fill ~96 ~27 ~216 ~96 ~27 ~228 minecraft:redstone_wire replace
fill ~102 ~27 ~216 ~102 ~27 ~228 minecraft:redstone_wire replace
fill ~111 ~27 ~216 ~111 ~27 ~228 minecraft:redstone_wire replace
fill ~141 ~27 ~216 ~141 ~27 ~228 minecraft:redstone_wire replace
fill ~156 ~27 ~216 ~156 ~27 ~228 minecraft:redstone_wire replace
fill ~159 ~27 ~216 ~159 ~27 ~228 minecraft:redstone_wire replace
fill ~168 ~27 ~216 ~168 ~27 ~228 minecraft:redstone_wire replace
fill ~171 ~27 ~216 ~171 ~27 ~228 minecraft:redstone_wire replace
fill ~195 ~27 ~216 ~195 ~27 ~228 minecraft:redstone_wire replace
fill ~201 ~27 ~216 ~201 ~27 ~228 minecraft:redstone_wire replace
fill ~222 ~27 ~216 ~222 ~27 ~228 minecraft:redstone_wire replace
fill ~234 ~27 ~216 ~234 ~27 ~228 minecraft:redstone_wire replace
fill ~258 ~27 ~216 ~258 ~27 ~228 minecraft:redstone_wire replace
fill ~291 ~27 ~216 ~291 ~27 ~228 minecraft:redstone_wire replace
fill ~312 ~27 ~216 ~312 ~27 ~228 minecraft:redstone_wire replace
fill ~330 ~27 ~216 ~330 ~27 ~228 minecraft:redstone_wire replace
fill ~336 ~27 ~216 ~336 ~27 ~228 minecraft:redstone_wire replace
setblock ~87 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~220 ~87 ~27 ~232 minecraft:redstone_wire replace
fill ~99 ~27 ~220 ~99 ~27 ~232 minecraft:redstone_wire replace
fill ~105 ~27 ~220 ~105 ~27 ~232 minecraft:redstone_wire replace
fill ~120 ~27 ~220 ~120 ~27 ~232 minecraft:redstone_wire replace
fill ~144 ~27 ~220 ~144 ~27 ~232 minecraft:redstone_wire replace
fill ~180 ~27 ~220 ~180 ~27 ~232 minecraft:redstone_wire replace
fill ~183 ~27 ~220 ~183 ~27 ~232 minecraft:redstone_wire replace
fill ~204 ~27 ~220 ~204 ~27 ~232 minecraft:redstone_wire replace
fill ~210 ~27 ~220 ~210 ~27 ~232 minecraft:redstone_wire replace
fill ~213 ~27 ~220 ~213 ~27 ~232 minecraft:redstone_wire replace
fill ~228 ~27 ~220 ~228 ~27 ~232 minecraft:redstone_wire replace
fill ~231 ~27 ~220 ~231 ~27 ~232 minecraft:redstone_wire replace
fill ~252 ~27 ~220 ~252 ~27 ~232 minecraft:redstone_wire replace
fill ~255 ~27 ~220 ~255 ~27 ~232 minecraft:redstone_wire replace
fill ~261 ~27 ~220 ~261 ~27 ~232 minecraft:redstone_wire replace
fill ~270 ~27 ~220 ~270 ~27 ~232 minecraft:redstone_wire replace
fill ~279 ~27 ~220 ~279 ~27 ~232 minecraft:redstone_wire replace
fill ~285 ~27 ~220 ~285 ~27 ~232 minecraft:redstone_wire replace
fill ~288 ~27 ~220 ~288 ~27 ~232 minecraft:redstone_wire replace
fill ~333 ~27 ~220 ~333 ~27 ~232 minecraft:redstone_wire replace
setblock ~90 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~224 ~90 ~27 ~236 minecraft:redstone_wire replace
fill ~108 ~27 ~224 ~108 ~27 ~236 minecraft:redstone_wire replace
fill ~114 ~27 ~224 ~114 ~27 ~236 minecraft:redstone_wire replace
fill ~123 ~27 ~224 ~123 ~27 ~236 minecraft:redstone_wire replace
fill ~138 ~27 ~224 ~138 ~27 ~236 minecraft:redstone_wire replace
fill ~150 ~27 ~224 ~150 ~27 ~236 minecraft:redstone_wire replace
fill ~174 ~27 ~224 ~174 ~27 ~236 minecraft:redstone_wire replace
fill ~189 ~27 ~224 ~189 ~27 ~236 minecraft:redstone_wire replace
fill ~198 ~27 ~224 ~198 ~27 ~236 minecraft:redstone_wire replace
fill ~216 ~27 ~224 ~216 ~27 ~236 minecraft:redstone_wire replace
fill ~237 ~27 ~224 ~237 ~27 ~236 minecraft:redstone_wire replace
fill ~243 ~27 ~224 ~243 ~27 ~236 minecraft:redstone_wire replace
fill ~267 ~27 ~224 ~267 ~27 ~236 minecraft:redstone_wire replace
fill ~294 ~27 ~224 ~294 ~27 ~236 minecraft:redstone_wire replace
fill ~297 ~27 ~224 ~297 ~27 ~236 minecraft:redstone_wire replace
fill ~315 ~27 ~224 ~315 ~27 ~236 minecraft:redstone_wire replace
fill ~342 ~27 ~224 ~342 ~27 ~236 minecraft:redstone_wire replace
setblock ~78 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~228 ~78 ~27 ~240 minecraft:redstone_wire replace
fill ~81 ~27 ~228 ~81 ~27 ~240 minecraft:redstone_wire replace
fill ~117 ~27 ~228 ~117 ~27 ~240 minecraft:redstone_wire replace
fill ~129 ~27 ~228 ~129 ~27 ~240 minecraft:redstone_wire replace
fill ~132 ~27 ~228 ~132 ~27 ~240 minecraft:redstone_wire replace
fill ~135 ~27 ~228 ~135 ~27 ~240 minecraft:redstone_wire replace
fill ~165 ~27 ~228 ~165 ~27 ~240 minecraft:redstone_wire replace
fill ~186 ~27 ~228 ~186 ~27 ~240 minecraft:redstone_wire replace
fill ~192 ~27 ~228 ~192 ~27 ~240 minecraft:redstone_wire replace
fill ~219 ~27 ~228 ~219 ~27 ~240 minecraft:redstone_wire replace
fill ~240 ~27 ~228 ~240 ~27 ~240 minecraft:redstone_wire replace
fill ~246 ~27 ~228 ~246 ~27 ~240 minecraft:redstone_wire replace
fill ~264 ~27 ~228 ~264 ~27 ~240 minecraft:redstone_wire replace
