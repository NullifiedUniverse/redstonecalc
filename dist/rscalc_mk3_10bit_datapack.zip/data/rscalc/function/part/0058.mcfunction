setblock ~183 ~19 ~48 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~19 ~48 ~249 ~19 ~60 minecraft:redstone_wire replace
fill ~264 ~19 ~48 ~264 ~19 ~60 minecraft:redstone_wire replace
fill ~267 ~19 ~48 ~267 ~19 ~60 minecraft:redstone_wire replace
fill ~276 ~19 ~48 ~276 ~19 ~60 minecraft:redstone_wire replace
fill ~279 ~19 ~48 ~279 ~19 ~60 minecraft:redstone_wire replace
fill ~282 ~19 ~48 ~282 ~19 ~60 minecraft:redstone_wire replace
setblock ~81 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~52 ~81 ~19 ~64 minecraft:redstone_wire replace
fill ~84 ~19 ~52 ~84 ~19 ~64 minecraft:redstone_wire replace
fill ~87 ~19 ~52 ~87 ~19 ~64 minecraft:redstone_wire replace
fill ~90 ~19 ~52 ~90 ~19 ~64 minecraft:redstone_wire replace
fill ~156 ~19 ~52 ~156 ~19 ~64 minecraft:redstone_wire replace
fill ~162 ~19 ~52 ~162 ~19 ~64 minecraft:redstone_wire replace
fill ~165 ~19 ~52 ~165 ~19 ~64 minecraft:redstone_wire replace
fill ~168 ~19 ~52 ~168 ~19 ~64 minecraft:redstone_wire replace
fill ~171 ~19 ~52 ~171 ~19 ~64 minecraft:redstone_wire replace
setblock ~204 ~19 ~52 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~19 ~52 ~231 ~19 ~64 minecraft:redstone_wire replace
fill ~234 ~19 ~52 ~234 ~19 ~64 minecraft:redstone_wire replace
fill ~240 ~19 ~52 ~240 ~19 ~64 minecraft:redstone_wire replace
fill ~243 ~19 ~52 ~243 ~19 ~64 minecraft:redstone_wire replace
fill ~246 ~19 ~52 ~246 ~19 ~64 minecraft:redstone_wire replace
fill ~270 ~19 ~52 ~270 ~19 ~64 minecraft:redstone_wire replace
setblock ~96 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~56 ~96 ~19 ~68 minecraft:redstone_wire replace
fill ~99 ~19 ~56 ~99 ~19 ~68 minecraft:redstone_wire replace
fill ~102 ~19 ~56 ~102 ~19 ~68 minecraft:redstone_wire replace
fill ~105 ~19 ~56 ~105 ~19 ~68 minecraft:redstone_wire replace
fill ~189 ~19 ~56 ~189 ~19 ~68 minecraft:redstone_wire replace
fill ~192 ~19 ~56 ~192 ~19 ~68 minecraft:redstone_wire replace
fill ~195 ~19 ~56 ~195 ~19 ~68 minecraft:redstone_wire replace
fill ~198 ~19 ~56 ~198 ~19 ~68 minecraft:redstone_wire replace
fill ~201 ~19 ~56 ~201 ~19 ~68 minecraft:redstone_wire replace
setblock ~210 ~19 ~56 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~19 ~56 ~258 ~19 ~68 minecraft:redstone_wire replace
fill ~285 ~19 ~56 ~285 ~19 ~68 minecraft:redstone_wire replace
fill ~288 ~19 ~56 ~288 ~19 ~68 minecraft:redstone_wire replace
fill ~291 ~19 ~56 ~291 ~19 ~68 minecraft:redstone_wire replace
fill ~294 ~19 ~56 ~294 ~19 ~68 minecraft:redstone_wire replace
fill ~297 ~19 ~56 ~297 ~19 ~68 minecraft:redstone_wire replace
setblock ~117 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~60 ~117 ~19 ~72 minecraft:redstone_wire replace
fill ~120 ~19 ~60 ~120 ~19 ~72 minecraft:redstone_wire replace
fill ~123 ~19 ~60 ~123 ~19 ~72 minecraft:redstone_wire replace
fill ~126 ~19 ~60 ~126 ~19 ~72 minecraft:redstone_wire replace
fill ~129 ~19 ~60 ~129 ~19 ~72 minecraft:redstone_wire replace
fill ~207 ~19 ~60 ~207 ~19 ~72 minecraft:redstone_wire replace
fill ~213 ~19 ~60 ~213 ~19 ~72 minecraft:redstone_wire replace
fill ~216 ~19 ~60 ~216 ~19 ~72 minecraft:redstone_wire replace
fill ~222 ~19 ~60 ~222 ~19 ~72 minecraft:redstone_wire replace
fill ~225 ~19 ~60 ~225 ~19 ~72 minecraft:redstone_wire replace
setblock ~237 ~19 ~60 minecraft:redstone_wire replace
setblock ~138 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~64 ~138 ~19 ~76 minecraft:redstone_wire replace
fill ~141 ~19 ~64 ~141 ~19 ~76 minecraft:redstone_wire replace
fill ~144 ~19 ~64 ~144 ~19 ~76 minecraft:redstone_wire replace
fill ~147 ~19 ~64 ~147 ~19 ~76 minecraft:redstone_wire replace
fill ~150 ~19 ~64 ~150 ~19 ~76 minecraft:redstone_wire replace
fill ~219 ~19 ~64 ~219 ~19 ~76 minecraft:redstone_wire replace
setblock ~249 ~19 ~64 minecraft:redstone_wire replace
fill ~264 ~19 ~64 ~264 ~19 ~68 minecraft:redstone_wire replace
fill ~267 ~19 ~64 ~267 ~19 ~76 minecraft:redstone_wire replace
fill ~276 ~19 ~64 ~276 ~19 ~76 minecraft:redstone_wire replace
fill ~279 ~19 ~64 ~279 ~19 ~76 minecraft:redstone_wire replace
fill ~282 ~19 ~64 ~282 ~19 ~76 minecraft:redstone_wire replace
setblock ~81 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~68 ~81 ~19 ~80 minecraft:redstone_wire replace
fill ~84 ~19 ~68 ~84 ~19 ~80 minecraft:redstone_wire replace
fill ~87 ~19 ~68 ~87 ~19 ~80 minecraft:redstone_wire replace
fill ~90 ~19 ~68 ~90 ~19 ~80 minecraft:redstone_wire replace
fill ~156 ~19 ~68 ~156 ~19 ~80 minecraft:redstone_wire replace
fill ~162 ~19 ~68 ~162 ~19 ~80 minecraft:redstone_wire replace
fill ~165 ~19 ~68 ~165 ~19 ~80 minecraft:redstone_wire replace
fill ~168 ~19 ~68 ~168 ~19 ~80 minecraft:redstone_wire replace
fill ~171 ~19 ~68 ~171 ~19 ~80 minecraft:redstone_wire replace
fill ~231 ~19 ~68 ~231 ~19 ~72 minecraft:redstone_wire replace
fill ~234 ~19 ~68 ~234 ~19 ~80 minecraft:redstone_wire replace
fill ~240 ~19 ~68 ~240 ~19 ~80 minecraft:redstone_wire replace
fill ~243 ~19 ~68 ~243 ~19 ~80 minecraft:redstone_wire replace
fill ~246 ~19 ~68 ~246 ~19 ~80 minecraft:redstone_wire replace
fill ~252 ~19 ~68 ~252 ~19 ~80 minecraft:redstone_wire replace
fill ~270 ~19 ~68 ~270 ~19 ~74 minecraft:redstone_wire replace
setblock ~96 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~72 ~96 ~19 ~84 minecraft:redstone_wire replace
fill ~99 ~19 ~72 ~99 ~19 ~84 minecraft:redstone_wire replace
fill ~102 ~19 ~72 ~102 ~19 ~84 minecraft:redstone_wire replace
fill ~105 ~19 ~72 ~105 ~19 ~84 minecraft:redstone_wire replace
fill ~189 ~19 ~72 ~189 ~19 ~84 minecraft:redstone_wire replace
fill ~192 ~19 ~72 ~192 ~19 ~84 minecraft:redstone_wire replace
fill ~195 ~19 ~72 ~195 ~19 ~84 minecraft:redstone_wire replace
fill ~198 ~19 ~72 ~198 ~19 ~84 minecraft:redstone_wire replace
fill ~201 ~19 ~72 ~201 ~19 ~84 minecraft:redstone_wire replace
fill ~255 ~19 ~72 ~255 ~19 ~84 minecraft:redstone_wire replace
fill ~258 ~19 ~72 ~258 ~19 ~78 minecraft:redstone_wire replace
fill ~285 ~19 ~72 ~285 ~19 ~82 minecraft:redstone_wire replace
fill ~288 ~19 ~72 ~288 ~19 ~84 minecraft:redstone_wire replace
fill ~291 ~19 ~72 ~291 ~19 ~84 minecraft:redstone_wire replace
fill ~294 ~19 ~72 ~294 ~19 ~84 minecraft:redstone_wire replace
fill ~297 ~19 ~72 ~297 ~19 ~84 minecraft:redstone_wire replace
setblock ~117 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~76 ~117 ~19 ~88 minecraft:redstone_wire replace
fill ~120 ~19 ~76 ~120 ~19 ~88 minecraft:redstone_wire replace
fill ~123 ~19 ~76 ~123 ~19 ~88 minecraft:redstone_wire replace
fill ~126 ~19 ~76 ~126 ~19 ~88 minecraft:redstone_wire replace
fill ~129 ~19 ~76 ~129 ~19 ~88 minecraft:redstone_wire replace
fill ~207 ~19 ~76 ~207 ~19 ~88 minecraft:redstone_wire replace
fill ~213 ~19 ~76 ~213 ~19 ~88 minecraft:redstone_wire replace
fill ~216 ~19 ~76 ~216 ~19 ~88 minecraft:redstone_wire replace
fill ~222 ~19 ~76 ~222 ~19 ~88 minecraft:redstone_wire replace
fill ~225 ~19 ~76 ~225 ~19 ~88 minecraft:redstone_wire replace
fill ~261 ~19 ~76 ~261 ~19 ~88 minecraft:redstone_wire replace
setblock ~270 ~19 ~76 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~80 ~138 ~19 ~92 minecraft:redstone_wire replace
fill ~141 ~19 ~80 ~141 ~19 ~92 minecraft:redstone_wire replace
fill ~144 ~19 ~80 ~144 ~19 ~92 minecraft:redstone_wire replace
fill ~147 ~19 ~80 ~147 ~19 ~92 minecraft:redstone_wire replace
fill ~150 ~19 ~80 ~150 ~19 ~92 minecraft:redstone_wire replace
fill ~219 ~19 ~80 ~219 ~19 ~92 minecraft:redstone_wire replace
setblock ~258 ~19 ~80 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~19 ~80 ~267 ~19 ~92 minecraft:redstone_wire replace
fill ~273 ~19 ~80 ~273 ~19 ~92 minecraft:redstone_wire replace
fill ~276 ~19 ~80 ~276 ~19 ~92 minecraft:redstone_wire replace
fill ~279 ~19 ~80 ~279 ~19 ~92 minecraft:redstone_wire replace
fill ~282 ~19 ~80 ~282 ~19 ~92 minecraft:redstone_wire replace
setblock ~81 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~84 ~81 ~19 ~88 minecraft:redstone_wire replace
fill ~84 ~19 ~84 ~84 ~19 ~90 minecraft:redstone_wire replace
fill ~87 ~19 ~84 ~87 ~19 ~94 minecraft:redstone_wire replace
fill ~90 ~19 ~84 ~90 ~19 ~96 minecraft:redstone_wire replace
fill ~156 ~19 ~84 ~156 ~19 ~96 minecraft:redstone_wire replace
fill ~162 ~19 ~84 ~162 ~19 ~96 minecraft:redstone_wire replace
fill ~165 ~19 ~84 ~165 ~19 ~96 minecraft:redstone_wire replace
fill ~168 ~19 ~84 ~168 ~19 ~96 minecraft:redstone_wire replace
fill ~171 ~19 ~84 ~171 ~19 ~96 minecraft:redstone_wire replace
fill ~234 ~19 ~84 ~234 ~19 ~96 minecraft:redstone_wire replace
fill ~240 ~19 ~84 ~240 ~19 ~96 minecraft:redstone_wire replace
fill ~243 ~19 ~84 ~243 ~19 ~96 minecraft:redstone_wire replace
fill ~246 ~19 ~84 ~246 ~19 ~96 minecraft:redstone_wire replace
fill ~252 ~19 ~84 ~252 ~19 ~96 minecraft:redstone_wire replace
setblock ~285 ~19 ~84 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~84 ~300 ~19 ~96 minecraft:redstone_wire replace
setblock ~96 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~88 ~96 ~19 ~100 minecraft:redstone_wire replace
fill ~99 ~19 ~88 ~99 ~19 ~100 minecraft:redstone_wire replace
fill ~102 ~19 ~88 ~102 ~19 ~100 minecraft:redstone_wire replace
fill ~105 ~19 ~88 ~105 ~19 ~100 minecraft:redstone_wire replace
fill ~189 ~19 ~88 ~189 ~19 ~100 minecraft:redstone_wire replace
fill ~192 ~19 ~88 ~192 ~19 ~100 minecraft:redstone_wire replace
fill ~195 ~19 ~88 ~195 ~19 ~100 minecraft:redstone_wire replace
fill ~198 ~19 ~88 ~198 ~19 ~100 minecraft:redstone_wire replace
fill ~201 ~19 ~88 ~201 ~19 ~100 minecraft:redstone_wire replace
fill ~255 ~19 ~88 ~255 ~19 ~100 minecraft:redstone_wire replace
fill ~288 ~19 ~88 ~288 ~19 ~100 minecraft:redstone_wire replace
fill ~291 ~19 ~88 ~291 ~19 ~100 minecraft:redstone_wire replace
fill ~294 ~19 ~88 ~294 ~19 ~100 minecraft:redstone_wire replace
fill ~297 ~19 ~88 ~297 ~19 ~100 minecraft:redstone_wire replace
setblock ~117 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~92 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~92 ~117 ~19 ~104 minecraft:redstone_wire replace
fill ~120 ~19 ~92 ~120 ~19 ~104 minecraft:redstone_wire replace
fill ~123 ~19 ~92 ~123 ~19 ~104 minecraft:redstone_wire replace
fill ~126 ~19 ~92 ~126 ~19 ~104 minecraft:redstone_wire replace
fill ~129 ~19 ~92 ~129 ~19 ~102 minecraft:redstone_wire replace
fill ~207 ~19 ~92 ~207 ~19 ~104 minecraft:redstone_wire replace
fill ~213 ~19 ~92 ~213 ~19 ~104 minecraft:redstone_wire replace
fill ~216 ~19 ~92 ~216 ~19 ~104 minecraft:redstone_wire replace
fill ~222 ~19 ~92 ~222 ~19 ~104 minecraft:redstone_wire replace
fill ~225 ~19 ~92 ~225 ~19 ~104 minecraft:redstone_wire replace
fill ~261 ~19 ~92 ~261 ~19 ~104 minecraft:redstone_wire replace
setblock ~138 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~96 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~96 ~138 ~19 ~108 minecraft:redstone_wire replace
fill ~141 ~19 ~96 ~141 ~19 ~108 minecraft:redstone_wire replace
fill ~144 ~19 ~96 ~144 ~19 ~108 minecraft:redstone_wire replace
fill ~147 ~19 ~96 ~147 ~19 ~108 minecraft:redstone_wire replace
fill ~150 ~19 ~96 ~150 ~19 ~108 minecraft:redstone_wire replace
fill ~219 ~19 ~96 ~219 ~19 ~108 minecraft:redstone_wire replace
fill ~267 ~19 ~96 ~267 ~19 ~108 minecraft:redstone_wire replace
fill ~273 ~19 ~96 ~273 ~19 ~108 minecraft:redstone_wire replace
fill ~276 ~19 ~96 ~276 ~19 ~108 minecraft:redstone_wire replace
fill ~279 ~19 ~96 ~279 ~19 ~108 minecraft:redstone_wire replace
fill ~282 ~19 ~96 ~282 ~19 ~108 minecraft:redstone_wire replace
setblock ~300 ~19 ~97 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~98 ~300 ~19 ~110 minecraft:redstone_wire replace
setblock ~90 ~19 ~100 minecraft:redstone_wire replace
fill ~156 ~19 ~100 ~156 ~19 ~112 minecraft:redstone_wire replace
fill ~162 ~19 ~100 ~162 ~19 ~112 minecraft:redstone_wire replace
fill ~165 ~19 ~100 ~165 ~19 ~112 minecraft:redstone_wire replace
fill ~168 ~19 ~100 ~168 ~19 ~112 minecraft:redstone_wire replace
fill ~171 ~19 ~100 ~171 ~19 ~112 minecraft:redstone_wire replace
fill ~186 ~19 ~100 ~186 ~19 ~112 minecraft:redstone_wire replace
fill ~234 ~19 ~100 ~234 ~19 ~112 minecraft:redstone_wire replace
fill ~240 ~19 ~100 ~240 ~19 ~112 minecraft:redstone_wire replace
fill ~243 ~19 ~100 ~243 ~19 ~112 minecraft:redstone_wire replace
fill ~246 ~19 ~100 ~246 ~19 ~112 minecraft:redstone_wire replace
fill ~252 ~19 ~100 ~252 ~19 ~112 minecraft:redstone_wire replace
setblock ~96 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~104 ~96 ~19 ~108 minecraft:redstone_wire replace
fill ~99 ~19 ~104 ~99 ~19 ~110 minecraft:redstone_wire replace
fill ~102 ~19 ~104 ~102 ~19 ~114 minecraft:redstone_wire replace
fill ~105 ~19 ~104 ~105 ~19 ~116 minecraft:redstone_wire replace
setblock ~129 ~19 ~104 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~104 ~177 ~19 ~116 minecraft:redstone_wire replace
fill ~189 ~19 ~104 ~189 ~19 ~116 minecraft:redstone_wire replace
fill ~192 ~19 ~104 ~192 ~19 ~116 minecraft:redstone_wire replace
fill ~195 ~19 ~104 ~195 ~19 ~116 minecraft:redstone_wire replace
fill ~198 ~19 ~104 ~198 ~19 ~116 minecraft:redstone_wire replace
fill ~201 ~19 ~104 ~201 ~19 ~116 minecraft:redstone_wire replace
fill ~255 ~19 ~104 ~255 ~19 ~116 minecraft:redstone_wire replace
fill ~288 ~19 ~104 ~288 ~19 ~116 minecraft:redstone_wire replace
fill ~291 ~19 ~104 ~291 ~19 ~116 minecraft:redstone_wire replace
fill ~294 ~19 ~104 ~294 ~19 ~116 minecraft:redstone_wire replace
fill ~297 ~19 ~104 ~297 ~19 ~116 minecraft:redstone_wire replace
setblock ~117 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~108 ~117 ~19 ~120 minecraft:redstone_wire replace
fill ~120 ~19 ~108 ~120 ~19 ~120 minecraft:redstone_wire replace
fill ~123 ~19 ~108 ~123 ~19 ~120 minecraft:redstone_wire replace
fill ~126 ~19 ~108 ~126 ~19 ~120 minecraft:redstone_wire replace
fill ~207 ~19 ~108 ~207 ~19 ~120 minecraft:redstone_wire replace
fill ~213 ~19 ~108 ~213 ~19 ~120 minecraft:redstone_wire replace
fill ~216 ~19 ~108 ~216 ~19 ~120 minecraft:redstone_wire replace
fill ~222 ~19 ~108 ~222 ~19 ~120 minecraft:redstone_wire replace
fill ~225 ~19 ~108 ~225 ~19 ~120 minecraft:redstone_wire replace
fill ~261 ~19 ~108 ~261 ~19 ~120 minecraft:redstone_wire replace
setblock ~138 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~111 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~112 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~112 ~138 ~19 ~124 minecraft:redstone_wire replace
fill ~141 ~19 ~112 ~141 ~19 ~122 minecraft:redstone_wire replace
fill ~144 ~19 ~112 ~144 ~19 ~124 minecraft:redstone_wire replace
fill ~147 ~19 ~112 ~147 ~19 ~124 minecraft:redstone_wire replace
fill ~150 ~19 ~112 ~150 ~19 ~124 minecraft:redstone_wire replace
fill ~180 ~19 ~112 ~180 ~19 ~124 minecraft:redstone_wire replace
fill ~219 ~19 ~112 ~219 ~19 ~124 minecraft:redstone_wire replace
fill ~267 ~19 ~112 ~267 ~19 ~124 minecraft:redstone_wire replace
fill ~273 ~19 ~112 ~273 ~19 ~124 minecraft:redstone_wire replace
fill ~276 ~19 ~112 ~276 ~19 ~124 minecraft:redstone_wire replace
fill ~279 ~19 ~112 ~279 ~19 ~124 minecraft:redstone_wire replace
fill ~282 ~19 ~112 ~282 ~19 ~124 minecraft:redstone_wire replace
fill ~300 ~19 ~112 ~300 ~19 ~124 minecraft:redstone_wire replace
setblock ~156 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~116 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~19 ~116 ~156 ~19 ~128 minecraft:redstone_wire replace
fill ~162 ~19 ~116 ~162 ~19 ~128 minecraft:redstone_wire replace
fill ~165 ~19 ~116 ~165 ~19 ~128 minecraft:redstone_wire replace
fill ~168 ~19 ~116 ~168 ~19 ~128 minecraft:redstone_wire replace
fill ~171 ~19 ~116 ~171 ~19 ~128 minecraft:redstone_wire replace
fill ~186 ~19 ~116 ~186 ~19 ~128 minecraft:redstone_wire replace
fill ~234 ~19 ~116 ~234 ~19 ~128 minecraft:redstone_wire replace
fill ~240 ~19 ~116 ~240 ~19 ~128 minecraft:redstone_wire replace
fill ~243 ~19 ~116 ~243 ~19 ~128 minecraft:redstone_wire replace
fill ~246 ~19 ~116 ~246 ~19 ~128 minecraft:redstone_wire replace
fill ~252 ~19 ~116 ~252 ~19 ~128 minecraft:redstone_wire replace
setblock ~105 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~120 minecraft:redstone_wire replace
fill ~177 ~19 ~120 ~177 ~19 ~132 minecraft:redstone_wire replace
fill ~189 ~19 ~120 ~189 ~19 ~132 minecraft:redstone_wire replace
fill ~192 ~19 ~120 ~192 ~19 ~132 minecraft:redstone_wire replace
fill ~195 ~19 ~120 ~195 ~19 ~132 minecraft:redstone_wire replace
fill ~198 ~19 ~120 ~198 ~19 ~132 minecraft:redstone_wire replace
fill ~201 ~19 ~120 ~201 ~19 ~132 minecraft:redstone_wire replace
fill ~255 ~19 ~120 ~255 ~19 ~132 minecraft:redstone_wire replace
fill ~288 ~19 ~120 ~288 ~19 ~132 minecraft:redstone_wire replace
fill ~291 ~19 ~120 ~291 ~19 ~132 minecraft:redstone_wire replace
fill ~294 ~19 ~120 ~294 ~19 ~132 minecraft:redstone_wire replace
fill ~297 ~19 ~120 ~297 ~19 ~132 minecraft:redstone_wire replace
setblock ~117 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~124 ~117 ~19 ~128 minecraft:redstone_wire replace
fill ~120 ~19 ~124 ~120 ~19 ~130 minecraft:redstone_wire replace
fill ~123 ~19 ~124 ~123 ~19 ~134 minecraft:redstone_wire replace
fill ~126 ~19 ~124 ~126 ~19 ~136 minecraft:redstone_wire replace
setblock ~141 ~19 ~124 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~124 ~207 ~19 ~136 minecraft:redstone_wire replace
fill ~213 ~19 ~124 ~213 ~19 ~136 minecraft:redstone_wire replace
fill ~216 ~19 ~124 ~216 ~19 ~136 minecraft:redstone_wire replace
fill ~222 ~19 ~124 ~222 ~19 ~136 minecraft:redstone_wire replace
fill ~225 ~19 ~124 ~225 ~19 ~136 minecraft:redstone_wire replace
fill ~261 ~19 ~124 ~261 ~19 ~136 minecraft:redstone_wire replace
setblock ~180 ~19 ~125 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~125 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~126 ~180 ~19 ~138 minecraft:redstone_wire replace
setblock ~219 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~126 ~300 ~19 ~138 minecraft:redstone_wire replace
fill ~138 ~19 ~128 ~138 ~19 ~140 minecraft:redstone_wire replace
fill ~144 ~19 ~128 ~144 ~19 ~140 minecraft:redstone_wire replace
fill ~147 ~19 ~128 ~147 ~19 ~140 minecraft:redstone_wire replace
fill ~150 ~19 ~128 ~150 ~19 ~140 minecraft:redstone_wire replace
fill ~219 ~19 ~128 ~219 ~19 ~140 minecraft:redstone_wire replace
fill ~228 ~19 ~128 ~228 ~19 ~140 minecraft:redstone_wire replace
fill ~267 ~19 ~128 ~267 ~19 ~140 minecraft:redstone_wire replace
fill ~273 ~19 ~128 ~273 ~19 ~140 minecraft:redstone_wire replace
fill ~276 ~19 ~128 ~276 ~19 ~140 minecraft:redstone_wire replace
fill ~279 ~19 ~128 ~279 ~19 ~140 minecraft:redstone_wire replace
fill ~282 ~19 ~128 ~282 ~19 ~140 minecraft:redstone_wire replace
setblock ~156 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~132 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~19 ~132 ~156 ~19 ~142 minecraft:redstone_wire replace
fill ~162 ~19 ~132 ~162 ~19 ~144 minecraft:redstone_wire replace
fill ~165 ~19 ~132 ~165 ~19 ~144 minecraft:redstone_wire replace
fill ~168 ~19 ~132 ~168 ~19 ~144 minecraft:redstone_wire replace
fill ~171 ~19 ~132 ~171 ~19 ~144 minecraft:redstone_wire replace
fill ~186 ~19 ~132 ~186 ~19 ~144 minecraft:redstone_wire replace
fill ~234 ~19 ~132 ~234 ~19 ~144 minecraft:redstone_wire replace
fill ~240 ~19 ~132 ~240 ~19 ~144 minecraft:redstone_wire replace
fill ~243 ~19 ~132 ~243 ~19 ~144 minecraft:redstone_wire replace
fill ~246 ~19 ~132 ~246 ~19 ~144 minecraft:redstone_wire replace
fill ~252 ~19 ~132 ~252 ~19 ~144 minecraft:redstone_wire replace
setblock ~177 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~136 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~136 ~177 ~19 ~148 minecraft:redstone_wire replace
fill ~189 ~19 ~136 ~189 ~19 ~148 minecraft:redstone_wire replace
fill ~192 ~19 ~136 ~192 ~19 ~148 minecraft:redstone_wire replace
fill ~195 ~19 ~136 ~195 ~19 ~148 minecraft:redstone_wire replace
fill ~198 ~19 ~136 ~198 ~19 ~148 minecraft:redstone_wire replace
fill ~201 ~19 ~136 ~201 ~19 ~148 minecraft:redstone_wire replace
fill ~255 ~19 ~136 ~255 ~19 ~148 minecraft:redstone_wire replace
fill ~288 ~19 ~136 ~288 ~19 ~148 minecraft:redstone_wire replace
fill ~291 ~19 ~136 ~291 ~19 ~148 minecraft:redstone_wire replace
fill ~294 ~19 ~136 ~294 ~19 ~148 minecraft:redstone_wire replace
fill ~297 ~19 ~136 ~297 ~19 ~148 minecraft:redstone_wire replace
setblock ~126 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~140 minecraft:redstone_wire replace
setblock ~180 ~19 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~140 ~207 ~19 ~152 minecraft:redstone_wire replace
fill ~213 ~19 ~140 ~213 ~19 ~152 minecraft:redstone_wire replace
fill ~216 ~19 ~140 ~216 ~19 ~152 minecraft:redstone_wire replace
fill ~222 ~19 ~140 ~222 ~19 ~152 minecraft:redstone_wire replace
fill ~225 ~19 ~140 ~225 ~19 ~152 minecraft:redstone_wire replace
fill ~261 ~19 ~140 ~261 ~19 ~152 minecraft:redstone_wire replace
setblock ~300 ~19 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~142 ~180 ~19 ~154 minecraft:redstone_wire replace
setblock ~219 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~142 ~300 ~19 ~154 minecraft:redstone_wire replace
fill ~138 ~19 ~144 ~138 ~19 ~148 minecraft:redstone_wire replace
fill ~144 ~19 ~144 ~144 ~19 ~150 minecraft:redstone_wire replace
fill ~147 ~19 ~144 ~147 ~19 ~154 minecraft:redstone_wire replace
fill ~150 ~19 ~144 ~150 ~19 ~156 minecraft:redstone_wire replace
setblock ~156 ~19 ~144 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~19 ~144 ~219 ~19 ~156 minecraft:redstone_wire replace
fill ~228 ~19 ~144 ~228 ~19 ~156 minecraft:redstone_wire replace
fill ~267 ~19 ~144 ~267 ~19 ~156 minecraft:redstone_wire replace
fill ~273 ~19 ~144 ~273 ~19 ~156 minecraft:redstone_wire replace
fill ~276 ~19 ~144 ~276 ~19 ~156 minecraft:redstone_wire replace
