fill ~279 ~19 ~144 ~279 ~19 ~156 minecraft:redstone_wire replace
fill ~282 ~19 ~144 ~282 ~19 ~156 minecraft:redstone_wire replace
setblock ~162 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~19 ~148 ~162 ~19 ~160 minecraft:redstone_wire replace
fill ~165 ~19 ~148 ~165 ~19 ~160 minecraft:redstone_wire replace
fill ~168 ~19 ~148 ~168 ~19 ~160 minecraft:redstone_wire replace
fill ~171 ~19 ~148 ~171 ~19 ~160 minecraft:redstone_wire replace
fill ~186 ~19 ~148 ~186 ~19 ~160 minecraft:redstone_wire replace
fill ~234 ~19 ~148 ~234 ~19 ~160 minecraft:redstone_wire replace
fill ~240 ~19 ~148 ~240 ~19 ~160 minecraft:redstone_wire replace
fill ~243 ~19 ~148 ~243 ~19 ~160 minecraft:redstone_wire replace
fill ~246 ~19 ~148 ~246 ~19 ~160 minecraft:redstone_wire replace
fill ~252 ~19 ~148 ~252 ~19 ~160 minecraft:redstone_wire replace
setblock ~177 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~152 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~152 ~177 ~19 ~164 minecraft:redstone_wire replace
fill ~189 ~19 ~152 ~189 ~19 ~162 minecraft:redstone_wire replace
fill ~192 ~19 ~152 ~192 ~19 ~164 minecraft:redstone_wire replace
fill ~195 ~19 ~152 ~195 ~19 ~164 minecraft:redstone_wire replace
fill ~198 ~19 ~152 ~198 ~19 ~164 minecraft:redstone_wire replace
fill ~201 ~19 ~152 ~201 ~19 ~164 minecraft:redstone_wire replace
fill ~255 ~19 ~152 ~255 ~19 ~164 minecraft:redstone_wire replace
fill ~288 ~19 ~152 ~288 ~19 ~164 minecraft:redstone_wire replace
fill ~291 ~19 ~152 ~291 ~19 ~164 minecraft:redstone_wire replace
fill ~294 ~19 ~152 ~294 ~19 ~164 minecraft:redstone_wire replace
fill ~297 ~19 ~152 ~297 ~19 ~164 minecraft:redstone_wire replace
setblock ~207 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~156 ~207 ~19 ~168 minecraft:redstone_wire replace
fill ~213 ~19 ~156 ~213 ~19 ~168 minecraft:redstone_wire replace
fill ~216 ~19 ~156 ~216 ~19 ~168 minecraft:redstone_wire replace
fill ~222 ~19 ~156 ~222 ~19 ~168 minecraft:redstone_wire replace
fill ~225 ~19 ~156 ~225 ~19 ~168 minecraft:redstone_wire replace
fill ~261 ~19 ~156 ~261 ~19 ~168 minecraft:redstone_wire replace
setblock ~300 ~19 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~158 ~180 ~19 ~170 minecraft:redstone_wire replace
setblock ~219 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~158 ~300 ~19 ~170 minecraft:redstone_wire replace
setblock ~150 ~19 ~160 minecraft:redstone_wire replace
fill ~219 ~19 ~160 ~219 ~19 ~172 minecraft:redstone_wire replace
fill ~228 ~19 ~160 ~228 ~19 ~172 minecraft:redstone_wire replace
fill ~267 ~19 ~160 ~267 ~19 ~172 minecraft:redstone_wire replace
fill ~273 ~19 ~160 ~273 ~19 ~172 minecraft:redstone_wire replace
fill ~276 ~19 ~160 ~276 ~19 ~172 minecraft:redstone_wire replace
fill ~279 ~19 ~160 ~279 ~19 ~172 minecraft:redstone_wire replace
fill ~282 ~19 ~160 ~282 ~19 ~172 minecraft:redstone_wire replace
setblock ~162 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~19 ~164 ~162 ~19 ~168 minecraft:redstone_wire replace
fill ~165 ~19 ~164 ~165 ~19 ~170 minecraft:redstone_wire replace
fill ~168 ~19 ~164 ~168 ~19 ~174 minecraft:redstone_wire replace
fill ~171 ~19 ~164 ~171 ~19 ~176 minecraft:redstone_wire replace
fill ~186 ~19 ~164 ~186 ~19 ~176 minecraft:redstone_wire replace
setblock ~189 ~19 ~164 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~19 ~164 ~234 ~19 ~176 minecraft:redstone_wire replace
fill ~240 ~19 ~164 ~240 ~19 ~176 minecraft:redstone_wire replace
fill ~243 ~19 ~164 ~243 ~19 ~176 minecraft:redstone_wire replace
fill ~246 ~19 ~164 ~246 ~19 ~176 minecraft:redstone_wire replace
fill ~252 ~19 ~164 ~252 ~19 ~176 minecraft:redstone_wire replace
setblock ~177 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~168 ~177 ~19 ~180 minecraft:redstone_wire replace
fill ~192 ~19 ~168 ~192 ~19 ~180 minecraft:redstone_wire replace
fill ~195 ~19 ~168 ~195 ~19 ~180 minecraft:redstone_wire replace
fill ~198 ~19 ~168 ~198 ~19 ~180 minecraft:redstone_wire replace
fill ~201 ~19 ~168 ~201 ~19 ~180 minecraft:redstone_wire replace
fill ~255 ~19 ~168 ~255 ~19 ~180 minecraft:redstone_wire replace
fill ~288 ~19 ~168 ~288 ~19 ~180 minecraft:redstone_wire replace
fill ~291 ~19 ~168 ~291 ~19 ~180 minecraft:redstone_wire replace
fill ~294 ~19 ~168 ~294 ~19 ~180 minecraft:redstone_wire replace
fill ~297 ~19 ~168 ~297 ~19 ~180 minecraft:redstone_wire replace
setblock ~207 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~172 ~207 ~19 ~182 minecraft:redstone_wire replace
fill ~213 ~19 ~172 ~213 ~19 ~184 minecraft:redstone_wire replace
fill ~216 ~19 ~172 ~216 ~19 ~184 minecraft:redstone_wire replace
fill ~222 ~19 ~172 ~222 ~19 ~184 minecraft:redstone_wire replace
fill ~225 ~19 ~172 ~225 ~19 ~184 minecraft:redstone_wire replace
fill ~261 ~19 ~172 ~261 ~19 ~184 minecraft:redstone_wire replace
setblock ~300 ~19 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~174 ~180 ~19 ~186 minecraft:redstone_wire replace
setblock ~219 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~174 ~300 ~19 ~186 minecraft:redstone_wire replace
setblock ~168 ~19 ~176 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~19 ~176 ~219 ~19 ~188 minecraft:redstone_wire replace
fill ~228 ~19 ~176 ~228 ~19 ~188 minecraft:redstone_wire replace
fill ~267 ~19 ~176 ~267 ~19 ~188 minecraft:redstone_wire replace
fill ~273 ~19 ~176 ~273 ~19 ~188 minecraft:redstone_wire replace
fill ~276 ~19 ~176 ~276 ~19 ~188 minecraft:redstone_wire replace
fill ~279 ~19 ~176 ~279 ~19 ~188 minecraft:redstone_wire replace
fill ~282 ~19 ~176 ~282 ~19 ~188 minecraft:redstone_wire replace
setblock ~171 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~180 minecraft:redstone_wire replace
fill ~186 ~19 ~180 ~186 ~19 ~192 minecraft:redstone_wire replace
fill ~234 ~19 ~180 ~234 ~19 ~192 minecraft:redstone_wire replace
fill ~240 ~19 ~180 ~240 ~19 ~192 minecraft:redstone_wire replace
fill ~243 ~19 ~180 ~243 ~19 ~192 minecraft:redstone_wire replace
fill ~246 ~19 ~180 ~246 ~19 ~192 minecraft:redstone_wire replace
fill ~252 ~19 ~180 ~252 ~19 ~192 minecraft:redstone_wire replace
setblock ~177 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~184 ~177 ~19 ~196 minecraft:redstone_wire replace
fill ~192 ~19 ~184 ~192 ~19 ~188 minecraft:redstone_wire replace
fill ~195 ~19 ~184 ~195 ~19 ~190 minecraft:redstone_wire replace
fill ~198 ~19 ~184 ~198 ~19 ~194 minecraft:redstone_wire replace
fill ~201 ~19 ~184 ~201 ~19 ~196 minecraft:redstone_wire replace
setblock ~207 ~19 ~184 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~19 ~184 ~255 ~19 ~196 minecraft:redstone_wire replace
fill ~288 ~19 ~184 ~288 ~19 ~196 minecraft:redstone_wire replace
fill ~291 ~19 ~184 ~291 ~19 ~196 minecraft:redstone_wire replace
fill ~294 ~19 ~184 ~294 ~19 ~196 minecraft:redstone_wire replace
fill ~297 ~19 ~184 ~297 ~19 ~196 minecraft:redstone_wire replace
setblock ~213 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~19 ~188 ~213 ~19 ~200 minecraft:redstone_wire replace
fill ~216 ~19 ~188 ~216 ~19 ~200 minecraft:redstone_wire replace
fill ~222 ~19 ~188 ~222 ~19 ~200 minecraft:redstone_wire replace
fill ~225 ~19 ~188 ~225 ~19 ~200 minecraft:redstone_wire replace
fill ~261 ~19 ~188 ~261 ~19 ~200 minecraft:redstone_wire replace
setblock ~300 ~19 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~190 ~180 ~19 ~202 minecraft:redstone_wire replace
setblock ~219 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~190 ~300 ~19 ~202 minecraft:redstone_wire replace
setblock ~195 ~19 ~192 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~19 ~192 ~219 ~19 ~202 minecraft:redstone_wire replace
fill ~228 ~19 ~192 ~228 ~19 ~204 minecraft:redstone_wire replace
fill ~267 ~19 ~192 ~267 ~19 ~204 minecraft:redstone_wire replace
fill ~273 ~19 ~192 ~273 ~19 ~204 minecraft:redstone_wire replace
fill ~276 ~19 ~192 ~276 ~19 ~204 minecraft:redstone_wire replace
fill ~279 ~19 ~192 ~279 ~19 ~204 minecraft:redstone_wire replace
fill ~282 ~19 ~192 ~282 ~19 ~204 minecraft:redstone_wire replace
setblock ~186 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~196 ~186 ~19 ~208 minecraft:redstone_wire replace
setblock ~198 ~19 ~196 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~19 ~196 ~234 ~19 ~208 minecraft:redstone_wire replace
fill ~240 ~19 ~196 ~240 ~19 ~208 minecraft:redstone_wire replace
fill ~243 ~19 ~196 ~243 ~19 ~208 minecraft:redstone_wire replace
fill ~246 ~19 ~196 ~246 ~19 ~208 minecraft:redstone_wire replace
fill ~252 ~19 ~196 ~252 ~19 ~208 minecraft:redstone_wire replace
setblock ~177 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~200 ~177 ~19 ~212 minecraft:redstone_wire replace
setblock ~201 ~19 ~200 minecraft:redstone_wire replace
fill ~255 ~19 ~200 ~255 ~19 ~212 minecraft:redstone_wire replace
fill ~288 ~19 ~200 ~288 ~19 ~212 minecraft:redstone_wire replace
fill ~291 ~19 ~200 ~291 ~19 ~212 minecraft:redstone_wire replace
fill ~294 ~19 ~200 ~294 ~19 ~212 minecraft:redstone_wire replace
fill ~297 ~19 ~200 ~297 ~19 ~212 minecraft:redstone_wire replace
setblock ~213 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~19 ~204 ~213 ~19 ~208 minecraft:redstone_wire replace
fill ~216 ~19 ~204 ~216 ~19 ~210 minecraft:redstone_wire replace
setblock ~219 ~19 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~19 ~204 ~222 ~19 ~214 minecraft:redstone_wire replace
fill ~225 ~19 ~204 ~225 ~19 ~216 minecraft:redstone_wire replace
fill ~261 ~19 ~204 ~261 ~19 ~216 minecraft:redstone_wire replace
setblock ~300 ~19 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~206 ~180 ~19 ~218 minecraft:redstone_wire replace
setblock ~228 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~206 ~300 ~19 ~218 minecraft:redstone_wire replace
fill ~228 ~19 ~208 ~228 ~19 ~220 minecraft:redstone_wire replace
fill ~267 ~19 ~208 ~267 ~19 ~220 minecraft:redstone_wire replace
fill ~273 ~19 ~208 ~273 ~19 ~220 minecraft:redstone_wire replace
fill ~276 ~19 ~208 ~276 ~19 ~220 minecraft:redstone_wire replace
fill ~279 ~19 ~208 ~279 ~19 ~220 minecraft:redstone_wire replace
fill ~282 ~19 ~208 ~282 ~19 ~220 minecraft:redstone_wire replace
setblock ~186 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~212 ~186 ~19 ~224 minecraft:redstone_wire replace
setblock ~216 ~19 ~212 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~19 ~212 ~234 ~19 ~224 minecraft:redstone_wire replace
fill ~240 ~19 ~212 ~240 ~19 ~224 minecraft:redstone_wire replace
fill ~243 ~19 ~212 ~243 ~19 ~224 minecraft:redstone_wire replace
fill ~246 ~19 ~212 ~246 ~19 ~224 minecraft:redstone_wire replace
fill ~252 ~19 ~212 ~252 ~19 ~222 minecraft:redstone_wire replace
setblock ~177 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~216 ~177 ~19 ~228 minecraft:redstone_wire replace
setblock ~222 ~19 ~216 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~19 ~216 ~255 ~19 ~226 minecraft:redstone_wire replace
fill ~288 ~19 ~216 ~288 ~19 ~228 minecraft:redstone_wire replace
fill ~291 ~19 ~216 ~291 ~19 ~228 minecraft:redstone_wire replace
fill ~294 ~19 ~216 ~294 ~19 ~228 minecraft:redstone_wire replace
fill ~297 ~19 ~216 ~297 ~19 ~228 minecraft:redstone_wire replace
setblock ~225 ~19 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~220 minecraft:redstone_wire replace
fill ~261 ~19 ~220 ~261 ~19 ~232 minecraft:redstone_wire replace
setblock ~300 ~19 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~222 ~180 ~19 ~234 minecraft:redstone_wire replace
setblock ~228 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~222 ~300 ~19 ~234 minecraft:redstone_wire replace
fill ~228 ~19 ~224 ~228 ~19 ~236 minecraft:redstone_wire replace
setblock ~252 ~19 ~224 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~19 ~224 ~267 ~19 ~230 minecraft:redstone_wire replace
fill ~273 ~19 ~224 ~273 ~19 ~236 minecraft:redstone_wire replace
fill ~276 ~19 ~224 ~276 ~19 ~234 minecraft:redstone_wire replace
fill ~279 ~19 ~224 ~279 ~19 ~236 minecraft:redstone_wire replace
fill ~282 ~19 ~224 ~282 ~19 ~236 minecraft:redstone_wire replace
setblock ~186 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~228 ~186 ~19 ~240 minecraft:redstone_wire replace
fill ~234 ~19 ~228 ~234 ~19 ~240 minecraft:redstone_wire replace
fill ~240 ~19 ~228 ~240 ~19 ~240 minecraft:redstone_wire replace
fill ~243 ~19 ~228 ~243 ~19 ~240 minecraft:redstone_wire replace
fill ~246 ~19 ~228 ~246 ~19 ~240 minecraft:redstone_wire replace
setblock ~255 ~19 ~228 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~232 ~177 ~19 ~244 minecraft:redstone_wire replace
setblock ~267 ~19 ~232 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~19 ~232 ~288 ~19 ~244 minecraft:redstone_wire replace
fill ~291 ~19 ~232 ~291 ~19 ~244 minecraft:redstone_wire replace
fill ~294 ~19 ~232 ~294 ~19 ~244 minecraft:redstone_wire replace
fill ~297 ~19 ~232 ~297 ~19 ~244 minecraft:redstone_wire replace
setblock ~261 ~19 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~19 ~236 ~261 ~19 ~248 minecraft:redstone_wire replace
setblock ~276 ~19 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~238 ~180 ~19 ~250 minecraft:redstone_wire replace
setblock ~228 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~238 ~300 ~19 ~250 minecraft:redstone_wire replace
fill ~228 ~19 ~240 ~228 ~19 ~252 minecraft:redstone_wire replace
fill ~273 ~19 ~240 ~273 ~19 ~252 minecraft:redstone_wire replace
setblock ~279 ~19 ~240 minecraft:redstone_wire replace
fill ~282 ~19 ~240 ~282 ~19 ~244 minecraft:redstone_wire replace
setblock ~186 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~244 ~186 ~19 ~256 minecraft:redstone_wire replace
fill ~234 ~19 ~244 ~234 ~19 ~248 minecraft:redstone_wire replace
fill ~240 ~19 ~244 ~240 ~19 ~250 minecraft:redstone_wire replace
fill ~243 ~19 ~244 ~243 ~19 ~254 minecraft:redstone_wire replace
fill ~246 ~19 ~244 ~246 ~19 ~256 minecraft:redstone_wire replace
setblock ~177 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~248 ~177 ~19 ~260 minecraft:redstone_wire replace
fill ~288 ~19 ~248 ~288 ~19 ~260 minecraft:redstone_wire replace
fill ~291 ~19 ~248 ~291 ~19 ~260 minecraft:redstone_wire replace
fill ~294 ~19 ~248 ~294 ~19 ~260 minecraft:redstone_wire replace
fill ~297 ~19 ~248 ~297 ~19 ~260 minecraft:redstone_wire replace
setblock ~261 ~19 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~19 ~252 ~261 ~19 ~262 minecraft:redstone_wire replace
setblock ~300 ~19 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~254 ~180 ~19 ~266 minecraft:redstone_wire replace
setblock ~228 ~19 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~254 ~300 ~19 ~266 minecraft:redstone_wire replace
fill ~228 ~19 ~256 ~228 ~19 ~268 minecraft:redstone_wire replace
setblock ~243 ~19 ~256 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~19 ~256 ~273 ~19 ~266 minecraft:redstone_wire replace
setblock ~186 ~19 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~260 ~186 ~19 ~272 minecraft:redstone_wire replace
setblock ~246 ~19 ~260 minecraft:redstone_wire replace
setblock ~177 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~264 ~177 ~19 ~276 minecraft:redstone_wire replace
setblock ~261 ~19 ~264 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~19 ~264 ~288 ~19 ~270 minecraft:redstone_wire replace
fill ~291 ~19 ~264 ~291 ~19 ~274 minecraft:redstone_wire replace
fill ~294 ~19 ~264 ~294 ~19 ~276 minecraft:redstone_wire replace
fill ~297 ~19 ~264 ~297 ~19 ~276 minecraft:redstone_wire replace
setblock ~180 ~19 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~270 ~180 ~19 ~282 minecraft:redstone_wire replace
setblock ~228 ~19 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~270 ~300 ~19 ~282 minecraft:redstone_wire replace
fill ~228 ~19 ~272 ~228 ~19 ~284 minecraft:redstone_wire replace
setblock ~288 ~19 ~272 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~276 ~186 ~19 ~288 minecraft:redstone_wire replace
setblock ~291 ~19 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~19 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~280 ~177 ~19 ~286 minecraft:redstone_wire replace
setblock ~294 ~19 ~280 minecraft:redstone_wire replace
fill ~297 ~19 ~280 ~297 ~19 ~284 minecraft:redstone_wire replace
setblock ~180 ~19 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~286 ~180 ~19 ~292 minecraft:redstone_wire replace
setblock ~228 ~19 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~286 ~300 ~19 ~298 minecraft:redstone_wire replace
setblock ~177 ~19 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~19 ~288 ~228 ~19 ~300 minecraft:redstone_wire replace
setblock ~186 ~19 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~292 ~186 ~19 ~296 minecraft:redstone_wire replace
setblock ~300 ~19 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~300 minecraft:redstone_wire replace
setblock ~228 ~19 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~304 minecraft:redstone_wire replace
setblock ~78 ~20 ~9 minecraft:redstone_wire replace
setblock ~108 ~20 ~13 minecraft:redstone_wire replace
setblock ~93 ~20 ~17 minecraft:redstone_wire replace
setblock ~114 ~20 ~21 minecraft:redstone_wire replace
setblock ~111 ~20 ~25 minecraft:redstone_wire replace
setblock ~132 ~20 ~29 minecraft:redstone_wire replace
setblock ~135 ~20 ~33 minecraft:redstone_wire replace
setblock ~153 ~20 ~37 minecraft:redstone_wire replace
setblock ~159 ~20 ~41 minecraft:redstone_wire replace
setblock ~174 ~20 ~45 minecraft:redstone_wire replace
setblock ~183 ~20 ~49 minecraft:redstone_wire replace
setblock ~204 ~20 ~53 minecraft:redstone_wire replace
setblock ~210 ~20 ~57 minecraft:redstone_wire replace
setblock ~237 ~20 ~61 minecraft:redstone_wire replace
setblock ~249 ~20 ~65 minecraft:redstone_wire replace
setblock ~264 ~20 ~69 minecraft:redstone_wire replace
setblock ~231 ~20 ~73 minecraft:redstone_wire replace
setblock ~270 ~20 ~77 minecraft:redstone_wire replace
setblock ~258 ~20 ~81 minecraft:redstone_wire replace
setblock ~285 ~20 ~85 minecraft:redstone_wire replace
setblock ~81 ~20 ~89 minecraft:redstone_wire replace
setblock ~84 ~20 ~93 minecraft:redstone_wire replace
setblock ~87 ~20 ~97 minecraft:redstone_wire replace
setblock ~90 ~20 ~101 minecraft:redstone_wire replace
setblock ~129 ~20 ~105 minecraft:redstone_wire replace
setblock ~96 ~20 ~109 minecraft:redstone_wire replace
setblock ~99 ~20 ~113 minecraft:redstone_wire replace
setblock ~102 ~20 ~117 minecraft:redstone_wire replace
setblock ~105 ~20 ~121 minecraft:redstone_wire replace
setblock ~141 ~20 ~125 minecraft:redstone_wire replace
setblock ~117 ~20 ~129 minecraft:redstone_wire replace
setblock ~120 ~20 ~133 minecraft:redstone_wire replace
setblock ~123 ~20 ~137 minecraft:redstone_wire replace
setblock ~126 ~20 ~141 minecraft:redstone_wire replace
setblock ~156 ~20 ~145 minecraft:redstone_wire replace
setblock ~138 ~20 ~149 minecraft:redstone_wire replace
setblock ~144 ~20 ~153 minecraft:redstone_wire replace
setblock ~147 ~20 ~157 minecraft:redstone_wire replace
setblock ~150 ~20 ~161 minecraft:redstone_wire replace
setblock ~189 ~20 ~165 minecraft:redstone_wire replace
setblock ~162 ~20 ~169 minecraft:redstone_wire replace
setblock ~165 ~20 ~173 minecraft:redstone_wire replace
setblock ~168 ~20 ~177 minecraft:redstone_wire replace
setblock ~171 ~20 ~181 minecraft:redstone_wire replace
setblock ~207 ~20 ~185 minecraft:redstone_wire replace
setblock ~192 ~20 ~189 minecraft:redstone_wire replace
setblock ~195 ~20 ~193 minecraft:redstone_wire replace
setblock ~198 ~20 ~197 minecraft:redstone_wire replace
setblock ~201 ~20 ~201 minecraft:redstone_wire replace
setblock ~219 ~20 ~205 minecraft:redstone_wire replace
setblock ~213 ~20 ~209 minecraft:redstone_wire replace
setblock ~216 ~20 ~213 minecraft:redstone_wire replace
setblock ~222 ~20 ~217 minecraft:redstone_wire replace
setblock ~225 ~20 ~221 minecraft:redstone_wire replace
setblock ~252 ~20 ~225 minecraft:redstone_wire replace
setblock ~255 ~20 ~229 minecraft:redstone_wire replace
setblock ~267 ~20 ~233 minecraft:redstone_wire replace
setblock ~276 ~20 ~237 minecraft:redstone_wire replace
setblock ~279 ~20 ~241 minecraft:redstone_wire replace
setblock ~282 ~20 ~245 minecraft:redstone_wire replace
setblock ~234 ~20 ~249 minecraft:redstone_wire replace
setblock ~240 ~20 ~253 minecraft:redstone_wire replace
setblock ~243 ~20 ~257 minecraft:redstone_wire replace
setblock ~246 ~20 ~261 minecraft:redstone_wire replace
setblock ~261 ~20 ~265 minecraft:redstone_wire replace
setblock ~273 ~20 ~269 minecraft:redstone_wire replace
setblock ~288 ~20 ~273 minecraft:redstone_wire replace
setblock ~291 ~20 ~277 minecraft:redstone_wire replace
setblock ~294 ~20 ~281 minecraft:redstone_wire replace
setblock ~297 ~20 ~285 minecraft:redstone_wire replace
setblock ~177 ~20 ~289 minecraft:redstone_wire replace
setblock ~180 ~20 ~293 minecraft:redstone_wire replace
setblock ~186 ~20 ~297 minecraft:redstone_wire replace
setblock ~300 ~20 ~301 minecraft:redstone_wire replace
setblock ~228 ~20 ~305 minecraft:redstone_wire replace
fill ~78 ~21 ~10 ~80 ~21 ~10 minecraft:redstone_wire replace
setblock ~79 ~21 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~21 ~14 ~108 ~21 ~14 minecraft:redstone_wire replace
setblock ~103 ~21 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~21 ~18 ~93 ~21 ~18 minecraft:redstone_wire replace
setblock ~91 ~21 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~21 ~22 ~114 ~21 ~22 minecraft:redstone_wire replace
setblock ~109 ~21 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~21 ~26 ~111 ~21 ~26 minecraft:redstone_wire replace
setblock ~106 ~21 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~21 ~30 ~132 ~21 ~30 minecraft:redstone_wire replace
setblock ~124 ~21 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~21 ~34 ~135 ~21 ~34 minecraft:redstone_wire replace
setblock ~127 ~21 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~21 ~38 ~145 ~21 ~38 minecraft:redstone_wire replace
setblock ~146 ~21 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~21 ~38 ~153 ~21 ~38 minecraft:redstone_wire replace
setblock ~145 ~21 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~21 ~42 ~151 ~21 ~42 minecraft:redstone_wire replace
setblock ~152 ~21 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~21 ~42 ~159 ~21 ~42 minecraft:redstone_wire replace
setblock ~151 ~21 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~21 ~46 ~174 ~21 ~46 minecraft:redstone_wire replace
setblock ~169 ~21 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~21 ~50 ~183 ~21 ~50 minecraft:redstone_wire replace
setblock ~175 ~21 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~21 ~54 ~204 ~21 ~54 minecraft:redstone_wire replace
setblock ~199 ~21 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~21 ~58 ~210 ~21 ~58 minecraft:redstone_wire replace
setblock ~208 ~21 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~21 ~62 ~237 ~21 ~62 minecraft:redstone_wire replace
setblock ~232 ~21 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~21 ~66 ~249 ~21 ~66 minecraft:redstone_wire replace
setblock ~241 ~21 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~21 ~70 ~256 ~21 ~70 minecraft:redstone_wire replace
setblock ~257 ~21 ~70 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~21 ~70 ~264 ~21 ~70 minecraft:redstone_wire replace
setblock ~256 ~21 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~21 ~74 ~231 ~21 ~74 minecraft:redstone_wire replace
setblock ~226 ~21 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~21 ~78 ~270 ~21 ~78 minecraft:redstone_wire replace
setblock ~262 ~21 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~21 ~82 ~258 ~21 ~82 minecraft:redstone_wire replace
setblock ~250 ~21 ~83 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~21 ~86 ~285 ~21 ~86 minecraft:redstone_wire replace
setblock ~274 ~21 ~87 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~21 ~90 ~83 ~21 ~90 minecraft:redstone_wire replace
setblock ~82 ~21 ~91 minecraft:redstone_wire replace
fill ~84 ~21 ~94 ~86 ~21 ~94 minecraft:redstone_wire replace
setblock ~85 ~21 ~95 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~21 ~98 ~89 ~21 ~98 minecraft:redstone_wire replace
setblock ~88 ~21 ~99 minecraft:redstone_wire replace
fill ~87 ~21 ~102 ~90 ~21 ~102 minecraft:redstone_wire replace
setblock ~88 ~21 ~103 minecraft:redstone_wire replace
fill ~120 ~21 ~106 ~129 ~21 ~106 minecraft:redstone_wire replace
setblock ~121 ~21 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~21 ~110 ~96 ~21 ~110 minecraft:redstone_wire replace
setblock ~94 ~21 ~111 minecraft:redstone_wire replace
fill ~96 ~21 ~114 ~99 ~21 ~114 minecraft:redstone_wire replace
setblock ~97 ~21 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~21 ~118 ~102 ~21 ~118 minecraft:redstone_wire replace
setblock ~100 ~21 ~119 minecraft:redstone_wire replace
fill ~99 ~21 ~122 ~105 ~21 ~122 minecraft:redstone_wire replace
setblock ~100 ~21 ~123 minecraft:redstone_wire replace
fill ~132 ~21 ~126 ~141 ~21 ~126 minecraft:redstone_wire replace
setblock ~133 ~21 ~127 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~21 ~130 ~117 ~21 ~130 minecraft:redstone_wire replace
setblock ~112 ~21 ~131 minecraft:redstone_wire replace
fill ~114 ~21 ~134 ~120 ~21 ~134 minecraft:redstone_wire replace
setblock ~115 ~21 ~135 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~21 ~138 ~123 ~21 ~138 minecraft:redstone_wire replace
setblock ~118 ~21 ~139 minecraft:redstone_wire replace
fill ~117 ~21 ~142 ~126 ~21 ~142 minecraft:redstone_wire replace
setblock ~118 ~21 ~143 minecraft:redstone_wire replace
fill ~147 ~21 ~146 ~156 ~21 ~146 minecraft:redstone_wire replace
setblock ~148 ~21 ~147 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~21 ~150 ~130 ~21 ~150 minecraft:redstone_wire replace
setblock ~131 ~21 ~150 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~21 ~150 ~138 ~21 ~150 minecraft:redstone_wire replace
setblock ~130 ~21 ~151 minecraft:redstone_wire replace
fill ~138 ~21 ~154 ~144 ~21 ~154 minecraft:redstone_wire replace
setblock ~139 ~21 ~155 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~21 ~158 ~147 ~21 ~158 minecraft:redstone_wire replace
setblock ~142 ~21 ~159 minecraft:redstone_wire replace
fill ~141 ~21 ~162 ~150 ~21 ~162 minecraft:redstone_wire replace
setblock ~142 ~21 ~163 minecraft:redstone_wire replace
fill ~180 ~21 ~166 ~189 ~21 ~166 minecraft:redstone_wire replace
setblock ~181 ~21 ~167 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~21 ~170 ~154 ~21 ~170 minecraft:redstone_wire replace
setblock ~155 ~21 ~170 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~21 ~170 ~162 ~21 ~170 minecraft:redstone_wire replace
setblock ~154 ~21 ~171 minecraft:redstone_wire replace
fill ~156 ~21 ~174 ~165 ~21 ~174 minecraft:redstone_wire replace
setblock ~157 ~21 ~175 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~21 ~178 ~168 ~21 ~178 minecraft:redstone_wire replace
