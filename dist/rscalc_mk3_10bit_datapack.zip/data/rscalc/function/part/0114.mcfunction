setblock ~494 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~142 ~440 ~169 ~152 minecraft:redstone_wire replace
fill ~444 ~169 ~142 ~444 ~169 ~152 minecraft:redstone_wire replace
fill ~448 ~169 ~142 ~448 ~169 ~152 minecraft:redstone_wire replace
fill ~458 ~169 ~142 ~458 ~169 ~152 minecraft:redstone_wire replace
fill ~460 ~169 ~142 ~460 ~169 ~152 minecraft:redstone_wire replace
fill ~472 ~169 ~142 ~472 ~169 ~152 minecraft:redstone_wire replace
fill ~474 ~169 ~142 ~474 ~169 ~152 minecraft:redstone_wire replace
fill ~482 ~169 ~142 ~482 ~169 ~152 minecraft:redstone_wire replace
fill ~484 ~169 ~142 ~484 ~169 ~152 minecraft:redstone_wire replace
fill ~494 ~169 ~142 ~494 ~169 ~152 minecraft:redstone_wire replace
setblock ~442 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~146 ~442 ~169 ~156 minecraft:redstone_wire replace
fill ~450 ~169 ~146 ~450 ~169 ~156 minecraft:redstone_wire replace
fill ~456 ~169 ~146 ~456 ~169 ~156 minecraft:redstone_wire replace
fill ~462 ~169 ~146 ~462 ~169 ~156 minecraft:redstone_wire replace
fill ~470 ~169 ~146 ~470 ~169 ~156 minecraft:redstone_wire replace
fill ~476 ~169 ~146 ~476 ~169 ~156 minecraft:redstone_wire replace
fill ~486 ~169 ~146 ~486 ~169 ~156 minecraft:redstone_wire replace
fill ~492 ~169 ~146 ~492 ~169 ~156 minecraft:redstone_wire replace
fill ~496 ~169 ~146 ~496 ~169 ~156 minecraft:redstone_wire replace
fill ~500 ~169 ~146 ~500 ~169 ~156 minecraft:redstone_wire replace
fill ~502 ~169 ~146 ~502 ~169 ~156 minecraft:redstone_wire replace
setblock ~446 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~150 ~446 ~169 ~160 minecraft:redstone_wire replace
fill ~452 ~169 ~150 ~452 ~169 ~160 minecraft:redstone_wire replace
fill ~454 ~169 ~150 ~454 ~169 ~160 minecraft:redstone_wire replace
fill ~464 ~169 ~150 ~464 ~169 ~160 minecraft:redstone_wire replace
fill ~466 ~169 ~150 ~466 ~169 ~160 minecraft:redstone_wire replace
fill ~468 ~169 ~150 ~468 ~169 ~160 minecraft:redstone_wire replace
fill ~478 ~169 ~150 ~478 ~169 ~160 minecraft:redstone_wire replace
fill ~480 ~169 ~150 ~480 ~169 ~160 minecraft:redstone_wire replace
fill ~488 ~169 ~150 ~488 ~169 ~160 minecraft:redstone_wire replace
fill ~490 ~169 ~150 ~490 ~169 ~160 minecraft:redstone_wire replace
fill ~498 ~169 ~150 ~498 ~169 ~160 minecraft:redstone_wire replace
setblock ~440 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~154 ~440 ~169 ~164 minecraft:redstone_wire replace
fill ~444 ~169 ~154 ~444 ~169 ~164 minecraft:redstone_wire replace
fill ~448 ~169 ~154 ~448 ~169 ~164 minecraft:redstone_wire replace
fill ~458 ~169 ~154 ~458 ~169 ~164 minecraft:redstone_wire replace
fill ~460 ~169 ~154 ~460 ~169 ~164 minecraft:redstone_wire replace
fill ~472 ~169 ~154 ~472 ~169 ~164 minecraft:redstone_wire replace
fill ~474 ~169 ~154 ~474 ~169 ~164 minecraft:redstone_wire replace
fill ~482 ~169 ~154 ~482 ~169 ~164 minecraft:redstone_wire replace
fill ~484 ~169 ~154 ~484 ~169 ~164 minecraft:redstone_wire replace
fill ~494 ~169 ~154 ~494 ~169 ~164 minecraft:redstone_wire replace
setblock ~442 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~158 ~442 ~169 ~168 minecraft:redstone_wire replace
fill ~450 ~169 ~158 ~450 ~169 ~168 minecraft:redstone_wire replace
fill ~456 ~169 ~158 ~456 ~169 ~168 minecraft:redstone_wire replace
fill ~462 ~169 ~158 ~462 ~169 ~168 minecraft:redstone_wire replace
fill ~470 ~169 ~158 ~470 ~169 ~168 minecraft:redstone_wire replace
fill ~476 ~169 ~158 ~476 ~169 ~168 minecraft:redstone_wire replace
fill ~486 ~169 ~158 ~486 ~169 ~168 minecraft:redstone_wire replace
fill ~492 ~169 ~158 ~492 ~169 ~168 minecraft:redstone_wire replace
fill ~496 ~169 ~158 ~496 ~169 ~168 minecraft:redstone_wire replace
fill ~500 ~169 ~158 ~500 ~169 ~168 minecraft:redstone_wire replace
fill ~502 ~169 ~158 ~502 ~169 ~168 minecraft:redstone_wire replace
setblock ~446 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~162 ~446 ~169 ~172 minecraft:redstone_wire replace
fill ~452 ~169 ~162 ~452 ~169 ~172 minecraft:redstone_wire replace
fill ~454 ~169 ~162 ~454 ~169 ~172 minecraft:redstone_wire replace
fill ~464 ~169 ~162 ~464 ~169 ~172 minecraft:redstone_wire replace
fill ~466 ~169 ~162 ~466 ~169 ~172 minecraft:redstone_wire replace
fill ~468 ~169 ~162 ~468 ~169 ~172 minecraft:redstone_wire replace
fill ~478 ~169 ~162 ~478 ~169 ~172 minecraft:redstone_wire replace
fill ~480 ~169 ~162 ~480 ~169 ~172 minecraft:redstone_wire replace
fill ~488 ~169 ~162 ~488 ~169 ~172 minecraft:redstone_wire replace
fill ~490 ~169 ~162 ~490 ~169 ~172 minecraft:redstone_wire replace
fill ~498 ~169 ~162 ~498 ~169 ~172 minecraft:redstone_wire replace
setblock ~440 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~166 ~440 ~169 ~176 minecraft:redstone_wire replace
fill ~444 ~169 ~166 ~444 ~169 ~176 minecraft:redstone_wire replace
fill ~448 ~169 ~166 ~448 ~169 ~176 minecraft:redstone_wire replace
fill ~458 ~169 ~166 ~458 ~169 ~176 minecraft:redstone_wire replace
fill ~460 ~169 ~166 ~460 ~169 ~176 minecraft:redstone_wire replace
fill ~472 ~169 ~166 ~472 ~169 ~176 minecraft:redstone_wire replace
fill ~474 ~169 ~166 ~474 ~169 ~176 minecraft:redstone_wire replace
fill ~482 ~169 ~166 ~482 ~169 ~176 minecraft:redstone_wire replace
fill ~484 ~169 ~166 ~484 ~169 ~176 minecraft:redstone_wire replace
fill ~494 ~169 ~166 ~494 ~169 ~176 minecraft:redstone_wire replace
setblock ~442 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~170 ~442 ~169 ~180 minecraft:redstone_wire replace
fill ~450 ~169 ~170 ~450 ~169 ~180 minecraft:redstone_wire replace
fill ~456 ~169 ~170 ~456 ~169 ~180 minecraft:redstone_wire replace
fill ~462 ~169 ~170 ~462 ~169 ~180 minecraft:redstone_wire replace
fill ~470 ~169 ~170 ~470 ~169 ~180 minecraft:redstone_wire replace
fill ~476 ~169 ~170 ~476 ~169 ~180 minecraft:redstone_wire replace
fill ~486 ~169 ~170 ~486 ~169 ~180 minecraft:redstone_wire replace
fill ~492 ~169 ~170 ~492 ~169 ~180 minecraft:redstone_wire replace
fill ~496 ~169 ~170 ~496 ~169 ~180 minecraft:redstone_wire replace
fill ~500 ~169 ~170 ~500 ~169 ~180 minecraft:redstone_wire replace
fill ~502 ~169 ~170 ~502 ~169 ~180 minecraft:redstone_wire replace
setblock ~446 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~174 ~446 ~169 ~184 minecraft:redstone_wire replace
fill ~452 ~169 ~174 ~452 ~169 ~184 minecraft:redstone_wire replace
fill ~454 ~169 ~174 ~454 ~169 ~184 minecraft:redstone_wire replace
fill ~464 ~169 ~174 ~464 ~169 ~184 minecraft:redstone_wire replace
fill ~466 ~169 ~174 ~466 ~169 ~184 minecraft:redstone_wire replace
fill ~468 ~169 ~174 ~468 ~169 ~184 minecraft:redstone_wire replace
fill ~478 ~169 ~174 ~478 ~169 ~184 minecraft:redstone_wire replace
fill ~480 ~169 ~174 ~480 ~169 ~184 minecraft:redstone_wire replace
fill ~488 ~169 ~174 ~488 ~169 ~184 minecraft:redstone_wire replace
fill ~490 ~169 ~174 ~490 ~169 ~184 minecraft:redstone_wire replace
fill ~498 ~169 ~174 ~498 ~169 ~184 minecraft:redstone_wire replace
setblock ~440 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~178 ~440 ~169 ~188 minecraft:redstone_wire replace
fill ~444 ~169 ~178 ~444 ~169 ~188 minecraft:redstone_wire replace
fill ~448 ~169 ~178 ~448 ~169 ~188 minecraft:redstone_wire replace
fill ~458 ~169 ~178 ~458 ~169 ~188 minecraft:redstone_wire replace
fill ~460 ~169 ~178 ~460 ~169 ~188 minecraft:redstone_wire replace
fill ~472 ~169 ~178 ~472 ~169 ~188 minecraft:redstone_wire replace
fill ~474 ~169 ~178 ~474 ~169 ~188 minecraft:redstone_wire replace
fill ~482 ~169 ~178 ~482 ~169 ~188 minecraft:redstone_wire replace
fill ~484 ~169 ~178 ~484 ~169 ~188 minecraft:redstone_wire replace
fill ~494 ~169 ~178 ~494 ~169 ~188 minecraft:redstone_wire replace
setblock ~442 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~182 ~442 ~169 ~192 minecraft:redstone_wire replace
fill ~450 ~169 ~182 ~450 ~169 ~192 minecraft:redstone_wire replace
fill ~456 ~169 ~182 ~456 ~169 ~192 minecraft:redstone_wire replace
fill ~462 ~169 ~182 ~462 ~169 ~192 minecraft:redstone_wire replace
fill ~470 ~169 ~182 ~470 ~169 ~192 minecraft:redstone_wire replace
fill ~476 ~169 ~182 ~476 ~169 ~192 minecraft:redstone_wire replace
fill ~486 ~169 ~182 ~486 ~169 ~192 minecraft:redstone_wire replace
fill ~492 ~169 ~182 ~492 ~169 ~192 minecraft:redstone_wire replace
fill ~496 ~169 ~182 ~496 ~169 ~192 minecraft:redstone_wire replace
fill ~500 ~169 ~182 ~500 ~169 ~192 minecraft:redstone_wire replace
fill ~502 ~169 ~182 ~502 ~169 ~192 minecraft:redstone_wire replace
setblock ~446 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~186 ~446 ~169 ~196 minecraft:redstone_wire replace
fill ~452 ~169 ~186 ~452 ~169 ~196 minecraft:redstone_wire replace
fill ~454 ~169 ~186 ~454 ~169 ~196 minecraft:redstone_wire replace
fill ~464 ~169 ~186 ~464 ~169 ~196 minecraft:redstone_wire replace
fill ~466 ~169 ~186 ~466 ~169 ~196 minecraft:redstone_wire replace
fill ~468 ~169 ~186 ~468 ~169 ~196 minecraft:redstone_wire replace
fill ~478 ~169 ~186 ~478 ~169 ~196 minecraft:redstone_wire replace
fill ~480 ~169 ~186 ~480 ~169 ~196 minecraft:redstone_wire replace
fill ~488 ~169 ~186 ~488 ~169 ~196 minecraft:redstone_wire replace
fill ~490 ~169 ~186 ~490 ~169 ~196 minecraft:redstone_wire replace
fill ~498 ~169 ~186 ~498 ~169 ~196 minecraft:redstone_wire replace
setblock ~440 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~190 ~440 ~169 ~200 minecraft:redstone_wire replace
fill ~444 ~169 ~190 ~444 ~169 ~200 minecraft:redstone_wire replace
fill ~448 ~169 ~190 ~448 ~169 ~200 minecraft:redstone_wire replace
fill ~458 ~169 ~190 ~458 ~169 ~200 minecraft:redstone_wire replace
fill ~460 ~169 ~190 ~460 ~169 ~200 minecraft:redstone_wire replace
fill ~472 ~169 ~190 ~472 ~169 ~200 minecraft:redstone_wire replace
fill ~474 ~169 ~190 ~474 ~169 ~200 minecraft:redstone_wire replace
fill ~482 ~169 ~190 ~482 ~169 ~200 minecraft:redstone_wire replace
fill ~484 ~169 ~190 ~484 ~169 ~200 minecraft:redstone_wire replace
fill ~494 ~169 ~190 ~494 ~169 ~200 minecraft:redstone_wire replace
setblock ~442 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~194 ~442 ~169 ~204 minecraft:redstone_wire replace
fill ~450 ~169 ~194 ~450 ~169 ~204 minecraft:redstone_wire replace
fill ~456 ~169 ~194 ~456 ~169 ~204 minecraft:redstone_wire replace
fill ~462 ~169 ~194 ~462 ~169 ~204 minecraft:redstone_wire replace
fill ~470 ~169 ~194 ~470 ~169 ~204 minecraft:redstone_wire replace
fill ~476 ~169 ~194 ~476 ~169 ~204 minecraft:redstone_wire replace
fill ~486 ~169 ~194 ~486 ~169 ~204 minecraft:redstone_wire replace
fill ~492 ~169 ~194 ~492 ~169 ~204 minecraft:redstone_wire replace
fill ~496 ~169 ~194 ~496 ~169 ~204 minecraft:redstone_wire replace
fill ~500 ~169 ~194 ~500 ~169 ~204 minecraft:redstone_wire replace
fill ~502 ~169 ~194 ~502 ~169 ~204 minecraft:redstone_wire replace
setblock ~446 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~198 ~446 ~169 ~208 minecraft:redstone_wire replace
fill ~452 ~169 ~198 ~452 ~169 ~208 minecraft:redstone_wire replace
fill ~454 ~169 ~198 ~454 ~169 ~208 minecraft:redstone_wire replace
fill ~464 ~169 ~198 ~464 ~169 ~208 minecraft:redstone_wire replace
fill ~466 ~169 ~198 ~466 ~169 ~208 minecraft:redstone_wire replace
fill ~468 ~169 ~198 ~468 ~169 ~208 minecraft:redstone_wire replace
fill ~478 ~169 ~198 ~478 ~169 ~208 minecraft:redstone_wire replace
fill ~480 ~169 ~198 ~480 ~169 ~208 minecraft:redstone_wire replace
fill ~488 ~169 ~198 ~488 ~169 ~208 minecraft:redstone_wire replace
fill ~490 ~169 ~198 ~490 ~169 ~208 minecraft:redstone_wire replace
fill ~498 ~169 ~198 ~498 ~169 ~208 minecraft:redstone_wire replace
setblock ~440 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~202 ~440 ~169 ~212 minecraft:redstone_wire replace
fill ~444 ~169 ~202 ~444 ~169 ~212 minecraft:redstone_wire replace
fill ~448 ~169 ~202 ~448 ~169 ~212 minecraft:redstone_wire replace
fill ~458 ~169 ~202 ~458 ~169 ~212 minecraft:redstone_wire replace
fill ~460 ~169 ~202 ~460 ~169 ~212 minecraft:redstone_wire replace
fill ~472 ~169 ~202 ~472 ~169 ~212 minecraft:redstone_wire replace
fill ~474 ~169 ~202 ~474 ~169 ~212 minecraft:redstone_wire replace
fill ~482 ~169 ~202 ~482 ~169 ~212 minecraft:redstone_wire replace
fill ~484 ~169 ~202 ~484 ~169 ~212 minecraft:redstone_wire replace
fill ~494 ~169 ~202 ~494 ~169 ~212 minecraft:redstone_wire replace
setblock ~442 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~206 ~442 ~169 ~216 minecraft:redstone_wire replace
fill ~450 ~169 ~206 ~450 ~169 ~216 minecraft:redstone_wire replace
fill ~456 ~169 ~206 ~456 ~169 ~216 minecraft:redstone_wire replace
fill ~462 ~169 ~206 ~462 ~169 ~216 minecraft:redstone_wire replace
fill ~470 ~169 ~206 ~470 ~169 ~216 minecraft:redstone_wire replace
fill ~476 ~169 ~206 ~476 ~169 ~216 minecraft:redstone_wire replace
fill ~486 ~169 ~206 ~486 ~169 ~216 minecraft:redstone_wire replace
fill ~492 ~169 ~206 ~492 ~169 ~216 minecraft:redstone_wire replace
fill ~496 ~169 ~206 ~496 ~169 ~216 minecraft:redstone_wire replace
fill ~500 ~169 ~206 ~500 ~169 ~216 minecraft:redstone_wire replace
fill ~502 ~169 ~206 ~502 ~169 ~216 minecraft:redstone_wire replace
setblock ~446 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~210 ~446 ~169 ~220 minecraft:redstone_wire replace
fill ~452 ~169 ~210 ~452 ~169 ~220 minecraft:redstone_wire replace
fill ~454 ~169 ~210 ~454 ~169 ~220 minecraft:redstone_wire replace
fill ~464 ~169 ~210 ~464 ~169 ~220 minecraft:redstone_wire replace
fill ~466 ~169 ~210 ~466 ~169 ~220 minecraft:redstone_wire replace
fill ~468 ~169 ~210 ~468 ~169 ~220 minecraft:redstone_wire replace
fill ~478 ~169 ~210 ~478 ~169 ~220 minecraft:redstone_wire replace
fill ~480 ~169 ~210 ~480 ~169 ~220 minecraft:redstone_wire replace
fill ~488 ~169 ~210 ~488 ~169 ~220 minecraft:redstone_wire replace
fill ~490 ~169 ~210 ~490 ~169 ~220 minecraft:redstone_wire replace
fill ~498 ~169 ~210 ~498 ~169 ~220 minecraft:redstone_wire replace
setblock ~440 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~214 ~440 ~169 ~224 minecraft:redstone_wire replace
fill ~444 ~169 ~214 ~444 ~169 ~224 minecraft:redstone_wire replace
fill ~448 ~169 ~214 ~448 ~169 ~224 minecraft:redstone_wire replace
fill ~458 ~169 ~214 ~458 ~169 ~224 minecraft:redstone_wire replace
fill ~460 ~169 ~214 ~460 ~169 ~224 minecraft:redstone_wire replace
fill ~472 ~169 ~214 ~472 ~169 ~224 minecraft:redstone_wire replace
fill ~474 ~169 ~214 ~474 ~169 ~224 minecraft:redstone_wire replace
fill ~482 ~169 ~214 ~482 ~169 ~224 minecraft:redstone_wire replace
fill ~484 ~169 ~214 ~484 ~169 ~224 minecraft:redstone_wire replace
fill ~494 ~169 ~214 ~494 ~169 ~224 minecraft:redstone_wire replace
setblock ~442 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~218 ~442 ~169 ~228 minecraft:redstone_wire replace
fill ~450 ~169 ~218 ~450 ~169 ~228 minecraft:redstone_wire replace
fill ~456 ~169 ~218 ~456 ~169 ~228 minecraft:redstone_wire replace
fill ~462 ~169 ~218 ~462 ~169 ~228 minecraft:redstone_wire replace
fill ~470 ~169 ~218 ~470 ~169 ~228 minecraft:redstone_wire replace
fill ~476 ~169 ~218 ~476 ~169 ~228 minecraft:redstone_wire replace
fill ~486 ~169 ~218 ~486 ~169 ~228 minecraft:redstone_wire replace
fill ~492 ~169 ~218 ~492 ~169 ~228 minecraft:redstone_wire replace
fill ~496 ~169 ~218 ~496 ~169 ~228 minecraft:redstone_wire replace
fill ~500 ~169 ~218 ~500 ~169 ~228 minecraft:redstone_wire replace
fill ~502 ~169 ~218 ~502 ~169 ~228 minecraft:redstone_wire replace
setblock ~446 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~222 ~446 ~169 ~232 minecraft:redstone_wire replace
fill ~452 ~169 ~222 ~452 ~169 ~232 minecraft:redstone_wire replace
fill ~454 ~169 ~222 ~454 ~169 ~232 minecraft:redstone_wire replace
fill ~464 ~169 ~222 ~464 ~169 ~232 minecraft:redstone_wire replace
fill ~466 ~169 ~222 ~466 ~169 ~232 minecraft:redstone_wire replace
fill ~468 ~169 ~222 ~468 ~169 ~232 minecraft:redstone_wire replace
fill ~478 ~169 ~222 ~478 ~169 ~232 minecraft:redstone_wire replace
fill ~480 ~169 ~222 ~480 ~169 ~232 minecraft:redstone_wire replace
fill ~488 ~169 ~222 ~488 ~169 ~232 minecraft:redstone_wire replace
fill ~490 ~169 ~222 ~490 ~169 ~232 minecraft:redstone_wire replace
fill ~498 ~169 ~222 ~498 ~169 ~232 minecraft:redstone_wire replace
setblock ~440 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~226 ~440 ~169 ~236 minecraft:redstone_wire replace
fill ~444 ~169 ~226 ~444 ~169 ~236 minecraft:redstone_wire replace
fill ~448 ~169 ~226 ~448 ~169 ~236 minecraft:redstone_wire replace
fill ~458 ~169 ~226 ~458 ~169 ~236 minecraft:redstone_wire replace
fill ~460 ~169 ~226 ~460 ~169 ~236 minecraft:redstone_wire replace
fill ~472 ~169 ~226 ~472 ~169 ~236 minecraft:redstone_wire replace
fill ~474 ~169 ~226 ~474 ~169 ~236 minecraft:redstone_wire replace
fill ~482 ~169 ~226 ~482 ~169 ~236 minecraft:redstone_wire replace
fill ~484 ~169 ~226 ~484 ~169 ~236 minecraft:redstone_wire replace
fill ~494 ~169 ~226 ~494 ~169 ~236 minecraft:redstone_wire replace
setblock ~442 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~230 ~442 ~169 ~240 minecraft:redstone_wire replace
fill ~450 ~169 ~230 ~450 ~169 ~240 minecraft:redstone_wire replace
fill ~456 ~169 ~230 ~456 ~169 ~240 minecraft:redstone_wire replace
fill ~462 ~169 ~230 ~462 ~169 ~240 minecraft:redstone_wire replace
fill ~470 ~169 ~230 ~470 ~169 ~240 minecraft:redstone_wire replace
fill ~476 ~169 ~230 ~476 ~169 ~240 minecraft:redstone_wire replace
fill ~486 ~169 ~230 ~486 ~169 ~240 minecraft:redstone_wire replace
fill ~492 ~169 ~230 ~492 ~169 ~240 minecraft:redstone_wire replace
fill ~500 ~169 ~230 ~500 ~169 ~240 minecraft:redstone_wire replace
fill ~502 ~169 ~230 ~502 ~169 ~240 minecraft:redstone_wire replace
setblock ~446 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~234 ~446 ~169 ~244 minecraft:redstone_wire replace
fill ~452 ~169 ~234 ~452 ~169 ~244 minecraft:redstone_wire replace
fill ~454 ~169 ~234 ~454 ~169 ~244 minecraft:redstone_wire replace
fill ~464 ~169 ~234 ~464 ~169 ~244 minecraft:redstone_wire replace
fill ~466 ~169 ~234 ~466 ~169 ~244 minecraft:redstone_wire replace
fill ~468 ~169 ~234 ~468 ~169 ~244 minecraft:redstone_wire replace
fill ~478 ~169 ~234 ~478 ~169 ~244 minecraft:redstone_wire replace
fill ~480 ~169 ~234 ~480 ~169 ~244 minecraft:redstone_wire replace
fill ~488 ~169 ~234 ~488 ~169 ~244 minecraft:redstone_wire replace
fill ~490 ~169 ~234 ~490 ~169 ~244 minecraft:redstone_wire replace
setblock ~440 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~238 ~440 ~169 ~248 minecraft:redstone_wire replace
fill ~444 ~169 ~238 ~444 ~169 ~248 minecraft:redstone_wire replace
fill ~448 ~169 ~238 ~448 ~169 ~248 minecraft:redstone_wire replace
fill ~458 ~169 ~238 ~458 ~169 ~248 minecraft:redstone_wire replace
fill ~460 ~169 ~238 ~460 ~169 ~248 minecraft:redstone_wire replace
fill ~472 ~169 ~238 ~472 ~169 ~248 minecraft:redstone_wire replace
fill ~474 ~169 ~238 ~474 ~169 ~248 minecraft:redstone_wire replace
fill ~482 ~169 ~238 ~482 ~169 ~248 minecraft:redstone_wire replace
fill ~484 ~169 ~238 ~484 ~169 ~248 minecraft:redstone_wire replace
fill ~494 ~169 ~238 ~494 ~169 ~248 minecraft:redstone_wire replace
setblock ~442 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~242 ~442 ~169 ~252 minecraft:redstone_wire replace
fill ~450 ~169 ~242 ~450 ~169 ~252 minecraft:redstone_wire replace
fill ~456 ~169 ~242 ~456 ~169 ~252 minecraft:redstone_wire replace
fill ~462 ~169 ~242 ~462 ~169 ~252 minecraft:redstone_wire replace
fill ~470 ~169 ~242 ~470 ~169 ~252 minecraft:redstone_wire replace
fill ~476 ~169 ~242 ~476 ~169 ~252 minecraft:redstone_wire replace
fill ~486 ~169 ~242 ~486 ~169 ~252 minecraft:redstone_wire replace
fill ~492 ~169 ~242 ~492 ~169 ~252 minecraft:redstone_wire replace
fill ~500 ~169 ~242 ~500 ~169 ~252 minecraft:redstone_wire replace
fill ~502 ~169 ~242 ~502 ~169 ~252 minecraft:redstone_wire replace
setblock ~446 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~246 ~446 ~169 ~256 minecraft:redstone_wire replace
fill ~452 ~169 ~246 ~452 ~169 ~256 minecraft:redstone_wire replace
fill ~454 ~169 ~246 ~454 ~169 ~256 minecraft:redstone_wire replace
fill ~464 ~169 ~246 ~464 ~169 ~256 minecraft:redstone_wire replace
fill ~466 ~169 ~246 ~466 ~169 ~256 minecraft:redstone_wire replace
fill ~468 ~169 ~246 ~468 ~169 ~256 minecraft:redstone_wire replace
fill ~478 ~169 ~246 ~478 ~169 ~256 minecraft:redstone_wire replace
fill ~480 ~169 ~246 ~480 ~169 ~256 minecraft:redstone_wire replace
fill ~488 ~169 ~246 ~488 ~169 ~256 minecraft:redstone_wire replace
fill ~490 ~169 ~246 ~490 ~169 ~256 minecraft:redstone_wire replace
setblock ~440 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~250 ~440 ~169 ~260 minecraft:redstone_wire replace
fill ~444 ~169 ~250 ~444 ~169 ~260 minecraft:redstone_wire replace
fill ~448 ~169 ~250 ~448 ~169 ~260 minecraft:redstone_wire replace
fill ~458 ~169 ~250 ~458 ~169 ~260 minecraft:redstone_wire replace
fill ~460 ~169 ~250 ~460 ~169 ~260 minecraft:redstone_wire replace
fill ~472 ~169 ~250 ~472 ~169 ~260 minecraft:redstone_wire replace
fill ~474 ~169 ~250 ~474 ~169 ~260 minecraft:redstone_wire replace
fill ~482 ~169 ~250 ~482 ~169 ~260 minecraft:redstone_wire replace
fill ~484 ~169 ~250 ~484 ~169 ~260 minecraft:redstone_wire replace
fill ~494 ~169 ~250 ~494 ~169 ~260 minecraft:redstone_wire replace
setblock ~442 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~254 ~442 ~169 ~264 minecraft:redstone_wire replace
fill ~450 ~169 ~254 ~450 ~169 ~264 minecraft:redstone_wire replace
fill ~456 ~169 ~254 ~456 ~169 ~264 minecraft:redstone_wire replace
fill ~462 ~169 ~254 ~462 ~169 ~264 minecraft:redstone_wire replace
fill ~470 ~169 ~254 ~470 ~169 ~264 minecraft:redstone_wire replace
fill ~476 ~169 ~254 ~476 ~169 ~264 minecraft:redstone_wire replace
fill ~486 ~169 ~254 ~486 ~169 ~264 minecraft:redstone_wire replace
fill ~492 ~169 ~254 ~492 ~169 ~264 minecraft:redstone_wire replace
fill ~500 ~169 ~254 ~500 ~169 ~264 minecraft:redstone_wire replace
