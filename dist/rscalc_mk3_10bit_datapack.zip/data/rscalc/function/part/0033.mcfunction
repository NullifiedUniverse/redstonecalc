fill ~464 ~165 ~286 ~474 ~165 ~286 minecraft:redstone_wire replace
setblock ~475 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~165 ~286 ~483 ~165 ~286 minecraft:redstone_wire replace
setblock ~100 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~101 ~165 ~302 ~111 ~165 ~302 minecraft:redstone_wire replace
setblock ~112 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~113 ~165 ~302 ~123 ~165 ~302 minecraft:redstone_wire replace
setblock ~124 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~302 ~135 ~165 ~302 minecraft:redstone_wire replace
setblock ~136 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~302 ~147 ~165 ~302 minecraft:redstone_wire replace
setblock ~148 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~302 ~159 ~165 ~302 minecraft:redstone_wire replace
setblock ~160 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~302 ~171 ~165 ~302 minecraft:redstone_wire replace
setblock ~172 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~302 ~183 ~165 ~302 minecraft:redstone_wire replace
setblock ~184 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~302 ~195 ~165 ~302 minecraft:redstone_wire replace
setblock ~196 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~302 ~207 ~165 ~302 minecraft:redstone_wire replace
setblock ~208 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~302 ~219 ~165 ~302 minecraft:redstone_wire replace
setblock ~220 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~302 ~231 ~165 ~302 minecraft:redstone_wire replace
setblock ~232 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~302 ~243 ~165 ~302 minecraft:redstone_wire replace
setblock ~244 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~302 ~255 ~165 ~302 minecraft:redstone_wire replace
setblock ~256 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~302 ~267 ~165 ~302 minecraft:redstone_wire replace
setblock ~268 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~302 ~279 ~165 ~302 minecraft:redstone_wire replace
setblock ~280 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~302 ~291 ~165 ~302 minecraft:redstone_wire replace
setblock ~292 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~302 ~303 ~165 ~302 minecraft:redstone_wire replace
setblock ~304 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~302 ~315 ~165 ~302 minecraft:redstone_wire replace
setblock ~316 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~302 ~327 ~165 ~302 minecraft:redstone_wire replace
setblock ~328 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~302 ~339 ~165 ~302 minecraft:redstone_wire replace
setblock ~340 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~302 ~351 ~165 ~302 minecraft:redstone_wire replace
setblock ~352 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~302 ~363 ~165 ~302 minecraft:redstone_wire replace
setblock ~364 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~302 ~375 ~165 ~302 minecraft:redstone_wire replace
setblock ~376 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~302 ~387 ~165 ~302 minecraft:redstone_wire replace
setblock ~388 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~302 ~399 ~165 ~302 minecraft:redstone_wire replace
setblock ~400 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~302 ~411 ~165 ~302 minecraft:redstone_wire replace
setblock ~412 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~302 ~423 ~165 ~302 minecraft:redstone_wire replace
setblock ~424 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~302 ~435 ~165 ~302 minecraft:redstone_wire replace
setblock ~436 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~302 ~447 ~165 ~302 minecraft:redstone_wire replace
setblock ~448 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~302 ~459 ~165 ~302 minecraft:redstone_wire replace
setblock ~460 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~302 ~471 ~165 ~302 minecraft:redstone_wire replace
setblock ~472 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~302 ~483 ~165 ~302 minecraft:redstone_wire replace
setblock ~484 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~485 ~165 ~302 minecraft:redstone_wire replace
setblock ~97 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~98 ~165 ~330 ~108 ~165 ~330 minecraft:redstone_wire replace
setblock ~109 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~110 ~165 ~330 ~120 ~165 ~330 minecraft:redstone_wire replace
setblock ~121 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~330 ~132 ~165 ~330 minecraft:redstone_wire replace
setblock ~133 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~330 ~144 ~165 ~330 minecraft:redstone_wire replace
setblock ~145 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~330 ~156 ~165 ~330 minecraft:redstone_wire replace
setblock ~157 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~330 ~168 ~165 ~330 minecraft:redstone_wire replace
setblock ~169 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~330 ~180 ~165 ~330 minecraft:redstone_wire replace
setblock ~181 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~330 ~192 ~165 ~330 minecraft:redstone_wire replace
setblock ~193 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~330 ~204 ~165 ~330 minecraft:redstone_wire replace
setblock ~205 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~330 ~216 ~165 ~330 minecraft:redstone_wire replace
setblock ~217 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~330 ~228 ~165 ~330 minecraft:redstone_wire replace
setblock ~229 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~330 ~240 ~165 ~330 minecraft:redstone_wire replace
setblock ~241 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~330 ~252 ~165 ~330 minecraft:redstone_wire replace
setblock ~253 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~330 ~264 ~165 ~330 minecraft:redstone_wire replace
setblock ~265 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~330 ~276 ~165 ~330 minecraft:redstone_wire replace
setblock ~277 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~330 ~288 ~165 ~330 minecraft:redstone_wire replace
setblock ~289 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~330 ~300 ~165 ~330 minecraft:redstone_wire replace
setblock ~301 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~330 ~312 ~165 ~330 minecraft:redstone_wire replace
setblock ~313 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~330 ~324 ~165 ~330 minecraft:redstone_wire replace
setblock ~325 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~330 ~336 ~165 ~330 minecraft:redstone_wire replace
setblock ~337 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~330 ~348 ~165 ~330 minecraft:redstone_wire replace
setblock ~349 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~330 ~360 ~165 ~330 minecraft:redstone_wire replace
setblock ~361 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~330 ~372 ~165 ~330 minecraft:redstone_wire replace
setblock ~373 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~330 ~384 ~165 ~330 minecraft:redstone_wire replace
setblock ~385 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~330 ~396 ~165 ~330 minecraft:redstone_wire replace
setblock ~397 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~330 ~408 ~165 ~330 minecraft:redstone_wire replace
setblock ~409 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~330 ~420 ~165 ~330 minecraft:redstone_wire replace
setblock ~421 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~330 ~432 ~165 ~330 minecraft:redstone_wire replace
setblock ~433 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~330 ~444 ~165 ~330 minecraft:redstone_wire replace
setblock ~445 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~330 ~456 ~165 ~330 minecraft:redstone_wire replace
setblock ~457 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~330 ~468 ~165 ~330 minecraft:redstone_wire replace
setblock ~469 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~330 ~480 ~165 ~330 minecraft:redstone_wire replace
setblock ~481 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~165 ~330 ~487 ~165 ~330 minecraft:redstone_wire replace
setblock ~94 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~95 ~165 ~366 ~105 ~165 ~366 minecraft:redstone_wire replace
setblock ~106 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~107 ~165 ~366 ~117 ~165 ~366 minecraft:redstone_wire replace
setblock ~118 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~366 ~129 ~165 ~366 minecraft:redstone_wire replace
setblock ~130 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~366 ~141 ~165 ~366 minecraft:redstone_wire replace
setblock ~142 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~366 ~153 ~165 ~366 minecraft:redstone_wire replace
setblock ~154 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~366 ~165 ~165 ~366 minecraft:redstone_wire replace
setblock ~166 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~366 ~177 ~165 ~366 minecraft:redstone_wire replace
setblock ~178 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~366 ~189 ~165 ~366 minecraft:redstone_wire replace
setblock ~190 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~366 ~201 ~165 ~366 minecraft:redstone_wire replace
setblock ~202 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~366 ~213 ~165 ~366 minecraft:redstone_wire replace
setblock ~214 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~366 ~225 ~165 ~366 minecraft:redstone_wire replace
setblock ~226 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~366 ~237 ~165 ~366 minecraft:redstone_wire replace
setblock ~238 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~366 ~249 ~165 ~366 minecraft:redstone_wire replace
setblock ~250 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~366 ~261 ~165 ~366 minecraft:redstone_wire replace
setblock ~262 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~366 ~273 ~165 ~366 minecraft:redstone_wire replace
setblock ~274 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~366 ~285 ~165 ~366 minecraft:redstone_wire replace
setblock ~286 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~366 ~297 ~165 ~366 minecraft:redstone_wire replace
setblock ~298 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~366 ~309 ~165 ~366 minecraft:redstone_wire replace
setblock ~310 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~366 ~321 ~165 ~366 minecraft:redstone_wire replace
setblock ~322 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~366 ~333 ~165 ~366 minecraft:redstone_wire replace
setblock ~334 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~366 ~345 ~165 ~366 minecraft:redstone_wire replace
setblock ~346 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~366 ~357 ~165 ~366 minecraft:redstone_wire replace
setblock ~358 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~366 ~369 ~165 ~366 minecraft:redstone_wire replace
setblock ~370 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~366 ~381 ~165 ~366 minecraft:redstone_wire replace
setblock ~382 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~366 ~393 ~165 ~366 minecraft:redstone_wire replace
setblock ~394 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~366 ~405 ~165 ~366 minecraft:redstone_wire replace
setblock ~406 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~366 ~417 ~165 ~366 minecraft:redstone_wire replace
setblock ~418 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~366 ~429 ~165 ~366 minecraft:redstone_wire replace
setblock ~430 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~366 ~441 ~165 ~366 minecraft:redstone_wire replace
setblock ~442 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~366 ~453 ~165 ~366 minecraft:redstone_wire replace
setblock ~454 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~366 ~465 ~165 ~366 minecraft:redstone_wire replace
setblock ~466 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~366 ~477 ~165 ~366 minecraft:redstone_wire replace
setblock ~478 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~479 ~165 ~366 ~489 ~165 ~366 minecraft:redstone_wire replace
setblock ~91 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~92 ~165 ~398 ~102 ~165 ~398 minecraft:redstone_wire replace
setblock ~103 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~104 ~165 ~398 ~114 ~165 ~398 minecraft:redstone_wire replace
setblock ~115 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~116 ~165 ~398 ~126 ~165 ~398 minecraft:redstone_wire replace
setblock ~127 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~398 ~138 ~165 ~398 minecraft:redstone_wire replace
setblock ~139 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~398 ~150 ~165 ~398 minecraft:redstone_wire replace
setblock ~151 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~398 ~162 ~165 ~398 minecraft:redstone_wire replace
setblock ~163 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~398 ~174 ~165 ~398 minecraft:redstone_wire replace
setblock ~175 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~398 ~186 ~165 ~398 minecraft:redstone_wire replace
setblock ~187 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~398 ~198 ~165 ~398 minecraft:redstone_wire replace
setblock ~199 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~398 ~210 ~165 ~398 minecraft:redstone_wire replace
setblock ~211 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~398 ~222 ~165 ~398 minecraft:redstone_wire replace
setblock ~223 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~398 ~234 ~165 ~398 minecraft:redstone_wire replace
setblock ~235 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~398 ~246 ~165 ~398 minecraft:redstone_wire replace
setblock ~247 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~398 ~258 ~165 ~398 minecraft:redstone_wire replace
setblock ~259 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~398 ~270 ~165 ~398 minecraft:redstone_wire replace
setblock ~271 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~398 ~282 ~165 ~398 minecraft:redstone_wire replace
setblock ~283 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~398 ~294 ~165 ~398 minecraft:redstone_wire replace
setblock ~295 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~398 ~306 ~165 ~398 minecraft:redstone_wire replace
setblock ~307 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~398 ~318 ~165 ~398 minecraft:redstone_wire replace
setblock ~319 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~398 ~330 ~165 ~398 minecraft:redstone_wire replace
setblock ~331 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~398 ~342 ~165 ~398 minecraft:redstone_wire replace
setblock ~343 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~398 ~354 ~165 ~398 minecraft:redstone_wire replace
setblock ~355 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~398 ~366 ~165 ~398 minecraft:redstone_wire replace
setblock ~367 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~398 ~378 ~165 ~398 minecraft:redstone_wire replace
setblock ~379 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~398 ~390 ~165 ~398 minecraft:redstone_wire replace
setblock ~391 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~398 ~402 ~165 ~398 minecraft:redstone_wire replace
setblock ~403 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~398 ~414 ~165 ~398 minecraft:redstone_wire replace
setblock ~415 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~398 ~426 ~165 ~398 minecraft:redstone_wire replace
setblock ~427 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~398 ~438 ~165 ~398 minecraft:redstone_wire replace
setblock ~439 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~398 ~450 ~165 ~398 minecraft:redstone_wire replace
setblock ~451 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~398 ~462 ~165 ~398 minecraft:redstone_wire replace
setblock ~463 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~398 ~474 ~165 ~398 minecraft:redstone_wire replace
setblock ~475 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~165 ~398 ~486 ~165 ~398 minecraft:redstone_wire replace
setblock ~487 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~165 ~398 ~491 ~165 ~398 minecraft:redstone_wire replace
setblock ~88 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~89 ~165 ~430 ~99 ~165 ~430 minecraft:redstone_wire replace
setblock ~100 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~101 ~165 ~430 ~111 ~165 ~430 minecraft:redstone_wire replace
setblock ~112 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~113 ~165 ~430 ~123 ~165 ~430 minecraft:redstone_wire replace
setblock ~124 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~430 ~135 ~165 ~430 minecraft:redstone_wire replace
setblock ~136 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~430 ~147 ~165 ~430 minecraft:redstone_wire replace
setblock ~148 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~430 ~159 ~165 ~430 minecraft:redstone_wire replace
setblock ~160 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~430 ~171 ~165 ~430 minecraft:redstone_wire replace
setblock ~172 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~430 ~183 ~165 ~430 minecraft:redstone_wire replace
setblock ~184 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~430 ~195 ~165 ~430 minecraft:redstone_wire replace
setblock ~196 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~430 ~207 ~165 ~430 minecraft:redstone_wire replace
setblock ~208 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~430 ~219 ~165 ~430 minecraft:redstone_wire replace
setblock ~220 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~430 ~231 ~165 ~430 minecraft:redstone_wire replace
setblock ~232 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~430 ~243 ~165 ~430 minecraft:redstone_wire replace
setblock ~244 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~430 ~255 ~165 ~430 minecraft:redstone_wire replace
setblock ~256 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~430 ~267 ~165 ~430 minecraft:redstone_wire replace
setblock ~268 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~430 ~279 ~165 ~430 minecraft:redstone_wire replace
setblock ~280 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~430 ~291 ~165 ~430 minecraft:redstone_wire replace
setblock ~292 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~430 ~303 ~165 ~430 minecraft:redstone_wire replace
setblock ~304 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~430 ~315 ~165 ~430 minecraft:redstone_wire replace
setblock ~316 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~430 ~327 ~165 ~430 minecraft:redstone_wire replace
setblock ~328 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~430 ~339 ~165 ~430 minecraft:redstone_wire replace
setblock ~340 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~430 ~351 ~165 ~430 minecraft:redstone_wire replace
setblock ~352 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~430 ~363 ~165 ~430 minecraft:redstone_wire replace
setblock ~364 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~430 ~375 ~165 ~430 minecraft:redstone_wire replace
setblock ~376 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~430 ~387 ~165 ~430 minecraft:redstone_wire replace
setblock ~388 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~430 ~399 ~165 ~430 minecraft:redstone_wire replace
setblock ~400 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~430 ~411 ~165 ~430 minecraft:redstone_wire replace
setblock ~412 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~430 ~423 ~165 ~430 minecraft:redstone_wire replace
setblock ~424 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~430 ~435 ~165 ~430 minecraft:redstone_wire replace
setblock ~436 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~430 ~447 ~165 ~430 minecraft:redstone_wire replace
setblock ~448 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~430 ~459 ~165 ~430 minecraft:redstone_wire replace
setblock ~460 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~430 ~471 ~165 ~430 minecraft:redstone_wire replace
setblock ~472 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~430 ~483 ~165 ~430 minecraft:redstone_wire replace
setblock ~484 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~485 ~165 ~430 ~493 ~165 ~430 minecraft:redstone_wire replace
setblock ~82 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~83 ~165 ~446 ~93 ~165 ~446 minecraft:redstone_wire replace
setblock ~94 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~95 ~165 ~446 ~105 ~165 ~446 minecraft:redstone_wire replace
setblock ~106 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~107 ~165 ~446 ~117 ~165 ~446 minecraft:redstone_wire replace
setblock ~118 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~446 ~129 ~165 ~446 minecraft:redstone_wire replace
setblock ~130 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~446 ~141 ~165 ~446 minecraft:redstone_wire replace
setblock ~142 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~446 ~153 ~165 ~446 minecraft:redstone_wire replace
setblock ~154 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~446 ~165 ~165 ~446 minecraft:redstone_wire replace
setblock ~166 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~446 ~177 ~165 ~446 minecraft:redstone_wire replace
setblock ~178 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~446 ~189 ~165 ~446 minecraft:redstone_wire replace
setblock ~190 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~446 ~201 ~165 ~446 minecraft:redstone_wire replace
setblock ~202 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~446 ~213 ~165 ~446 minecraft:redstone_wire replace
setblock ~214 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~446 ~225 ~165 ~446 minecraft:redstone_wire replace
setblock ~226 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~446 ~237 ~165 ~446 minecraft:redstone_wire replace
setblock ~238 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~446 ~249 ~165 ~446 minecraft:redstone_wire replace
setblock ~250 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~446 ~261 ~165 ~446 minecraft:redstone_wire replace
setblock ~262 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~446 ~273 ~165 ~446 minecraft:redstone_wire replace
setblock ~274 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~446 ~285 ~165 ~446 minecraft:redstone_wire replace
setblock ~286 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~446 ~297 ~165 ~446 minecraft:redstone_wire replace
setblock ~298 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~446 ~309 ~165 ~446 minecraft:redstone_wire replace
setblock ~310 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~446 ~321 ~165 ~446 minecraft:redstone_wire replace
setblock ~322 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~446 ~333 ~165 ~446 minecraft:redstone_wire replace
setblock ~334 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~446 ~345 ~165 ~446 minecraft:redstone_wire replace
setblock ~346 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~446 ~357 ~165 ~446 minecraft:redstone_wire replace
setblock ~358 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~446 ~369 ~165 ~446 minecraft:redstone_wire replace
setblock ~370 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~446 ~381 ~165 ~446 minecraft:redstone_wire replace
setblock ~382 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~446 ~393 ~165 ~446 minecraft:redstone_wire replace
setblock ~394 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~446 ~405 ~165 ~446 minecraft:redstone_wire replace
setblock ~406 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~446 ~417 ~165 ~446 minecraft:redstone_wire replace
setblock ~418 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~446 ~429 ~165 ~446 minecraft:redstone_wire replace
setblock ~430 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~446 ~441 ~165 ~446 minecraft:redstone_wire replace
setblock ~442 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~446 ~453 ~165 ~446 minecraft:redstone_wire replace
setblock ~454 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~446 ~465 ~165 ~446 minecraft:redstone_wire replace
setblock ~466 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~446 ~477 ~165 ~446 minecraft:redstone_wire replace
setblock ~478 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~479 ~165 ~446 ~489 ~165 ~446 minecraft:redstone_wire replace
setblock ~490 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~491 ~165 ~446 ~499 ~165 ~446 minecraft:redstone_wire replace
setblock ~112 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~113 ~165 ~534 ~123 ~165 ~534 minecraft:redstone_wire replace
setblock ~124 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~534 ~135 ~165 ~534 minecraft:redstone_wire replace
setblock ~136 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~534 ~147 ~165 ~534 minecraft:redstone_wire replace
setblock ~148 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~534 ~159 ~165 ~534 minecraft:redstone_wire replace
setblock ~160 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~534 ~171 ~165 ~534 minecraft:redstone_wire replace
setblock ~172 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~534 ~183 ~165 ~534 minecraft:redstone_wire replace
setblock ~184 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~534 ~195 ~165 ~534 minecraft:redstone_wire replace
setblock ~196 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~534 ~207 ~165 ~534 minecraft:redstone_wire replace
setblock ~208 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~534 ~219 ~165 ~534 minecraft:redstone_wire replace
setblock ~220 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~534 ~231 ~165 ~534 minecraft:redstone_wire replace
setblock ~232 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~534 ~243 ~165 ~534 minecraft:redstone_wire replace
setblock ~244 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~534 ~255 ~165 ~534 minecraft:redstone_wire replace
setblock ~256 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~534 ~267 ~165 ~534 minecraft:redstone_wire replace
setblock ~268 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~534 ~279 ~165 ~534 minecraft:redstone_wire replace
setblock ~280 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~534 ~291 ~165 ~534 minecraft:redstone_wire replace
setblock ~292 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~534 ~303 ~165 ~534 minecraft:redstone_wire replace
setblock ~304 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~534 ~315 ~165 ~534 minecraft:redstone_wire replace
setblock ~316 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~534 ~327 ~165 ~534 minecraft:redstone_wire replace
setblock ~328 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~534 ~339 ~165 ~534 minecraft:redstone_wire replace
setblock ~340 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~534 ~351 ~165 ~534 minecraft:redstone_wire replace
setblock ~352 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~534 ~363 ~165 ~534 minecraft:redstone_wire replace
setblock ~364 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~534 ~375 ~165 ~534 minecraft:redstone_wire replace
setblock ~376 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~534 ~387 ~165 ~534 minecraft:redstone_wire replace
setblock ~388 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~534 ~399 ~165 ~534 minecraft:redstone_wire replace
setblock ~400 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~534 ~411 ~165 ~534 minecraft:redstone_wire replace
setblock ~412 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~534 ~423 ~165 ~534 minecraft:redstone_wire replace
setblock ~424 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~534 ~435 ~165 ~534 minecraft:redstone_wire replace
setblock ~436 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~534 ~447 ~165 ~534 minecraft:redstone_wire replace
setblock ~448 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~534 ~459 ~165 ~534 minecraft:redstone_wire replace
setblock ~460 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~534 ~467 ~165 ~534 minecraft:redstone_wire replace
setblock ~115 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~116 ~165 ~566 ~126 ~165 ~566 minecraft:redstone_wire replace
setblock ~127 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~566 ~138 ~165 ~566 minecraft:redstone_wire replace
setblock ~139 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~566 ~150 ~165 ~566 minecraft:redstone_wire replace
setblock ~151 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~566 ~162 ~165 ~566 minecraft:redstone_wire replace
setblock ~163 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~566 ~174 ~165 ~566 minecraft:redstone_wire replace
setblock ~175 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~566 ~186 ~165 ~566 minecraft:redstone_wire replace
setblock ~187 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~566 ~198 ~165 ~566 minecraft:redstone_wire replace
setblock ~199 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~566 ~210 ~165 ~566 minecraft:redstone_wire replace
setblock ~211 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~566 ~222 ~165 ~566 minecraft:redstone_wire replace
setblock ~223 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~566 ~234 ~165 ~566 minecraft:redstone_wire replace
setblock ~235 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~566 ~246 ~165 ~566 minecraft:redstone_wire replace
setblock ~247 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~566 ~258 ~165 ~566 minecraft:redstone_wire replace
setblock ~259 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~566 ~270 ~165 ~566 minecraft:redstone_wire replace
setblock ~271 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~566 ~282 ~165 ~566 minecraft:redstone_wire replace
setblock ~283 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~566 ~294 ~165 ~566 minecraft:redstone_wire replace
setblock ~295 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~566 ~306 ~165 ~566 minecraft:redstone_wire replace
setblock ~307 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~566 ~318 ~165 ~566 minecraft:redstone_wire replace
setblock ~319 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~566 ~330 ~165 ~566 minecraft:redstone_wire replace
setblock ~331 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~566 ~342 ~165 ~566 minecraft:redstone_wire replace
setblock ~343 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~566 ~354 ~165 ~566 minecraft:redstone_wire replace
setblock ~355 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~566 ~366 ~165 ~566 minecraft:redstone_wire replace
setblock ~367 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~566 ~378 ~165 ~566 minecraft:redstone_wire replace
setblock ~379 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~566 ~390 ~165 ~566 minecraft:redstone_wire replace
setblock ~391 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~566 ~402 ~165 ~566 minecraft:redstone_wire replace
setblock ~403 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~566 ~414 ~165 ~566 minecraft:redstone_wire replace
setblock ~415 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~566 ~426 ~165 ~566 minecraft:redstone_wire replace
setblock ~427 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~566 ~438 ~165 ~566 minecraft:redstone_wire replace
setblock ~439 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~566 ~450 ~165 ~566 minecraft:redstone_wire replace
setblock ~451 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~566 ~462 ~165 ~566 minecraft:redstone_wire replace
setblock ~463 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~566 ~469 ~165 ~566 minecraft:redstone_wire replace
setblock ~118 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~598 ~129 ~165 ~598 minecraft:redstone_wire replace
setblock ~130 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~598 ~141 ~165 ~598 minecraft:redstone_wire replace
setblock ~142 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~598 ~153 ~165 ~598 minecraft:redstone_wire replace
setblock ~154 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~598 ~165 ~165 ~598 minecraft:redstone_wire replace
setblock ~166 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~598 ~177 ~165 ~598 minecraft:redstone_wire replace
setblock ~178 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~598 ~189 ~165 ~598 minecraft:redstone_wire replace
setblock ~190 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~598 ~201 ~165 ~598 minecraft:redstone_wire replace
setblock ~202 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~598 ~213 ~165 ~598 minecraft:redstone_wire replace
setblock ~214 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~598 ~225 ~165 ~598 minecraft:redstone_wire replace
setblock ~226 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~598 ~237 ~165 ~598 minecraft:redstone_wire replace
setblock ~238 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~598 ~249 ~165 ~598 minecraft:redstone_wire replace
setblock ~250 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~598 ~261 ~165 ~598 minecraft:redstone_wire replace
setblock ~262 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~598 ~273 ~165 ~598 minecraft:redstone_wire replace
setblock ~274 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~598 ~285 ~165 ~598 minecraft:redstone_wire replace
setblock ~286 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~598 ~297 ~165 ~598 minecraft:redstone_wire replace
setblock ~298 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~598 ~309 ~165 ~598 minecraft:redstone_wire replace
setblock ~310 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~598 ~321 ~165 ~598 minecraft:redstone_wire replace
setblock ~322 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~598 ~333 ~165 ~598 minecraft:redstone_wire replace
setblock ~334 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~598 ~345 ~165 ~598 minecraft:redstone_wire replace
setblock ~346 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~598 ~357 ~165 ~598 minecraft:redstone_wire replace
setblock ~358 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~598 ~369 ~165 ~598 minecraft:redstone_wire replace
setblock ~370 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~598 ~381 ~165 ~598 minecraft:redstone_wire replace
setblock ~382 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~598 ~393 ~165 ~598 minecraft:redstone_wire replace
setblock ~394 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~598 ~405 ~165 ~598 minecraft:redstone_wire replace
setblock ~406 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~598 ~417 ~165 ~598 minecraft:redstone_wire replace
setblock ~418 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~598 ~429 ~165 ~598 minecraft:redstone_wire replace
setblock ~430 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~598 ~441 ~165 ~598 minecraft:redstone_wire replace
setblock ~442 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~598 ~453 ~165 ~598 minecraft:redstone_wire replace
setblock ~454 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~598 ~465 ~165 ~598 minecraft:redstone_wire replace
setblock ~466 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~598 ~471 ~165 ~598 minecraft:redstone_wire replace
setblock ~121 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~634 ~132 ~165 ~634 minecraft:redstone_wire replace
setblock ~133 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~634 ~144 ~165 ~634 minecraft:redstone_wire replace
setblock ~145 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~634 ~156 ~165 ~634 minecraft:redstone_wire replace
setblock ~157 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~634 ~168 ~165 ~634 minecraft:redstone_wire replace
setblock ~169 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~634 ~180 ~165 ~634 minecraft:redstone_wire replace
setblock ~181 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~634 ~192 ~165 ~634 minecraft:redstone_wire replace
setblock ~193 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~634 ~204 ~165 ~634 minecraft:redstone_wire replace
setblock ~205 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~634 ~216 ~165 ~634 minecraft:redstone_wire replace
setblock ~217 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~634 ~228 ~165 ~634 minecraft:redstone_wire replace
setblock ~229 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~634 ~240 ~165 ~634 minecraft:redstone_wire replace
setblock ~241 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~634 ~252 ~165 ~634 minecraft:redstone_wire replace
setblock ~253 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~634 ~264 ~165 ~634 minecraft:redstone_wire replace
setblock ~265 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~634 ~276 ~165 ~634 minecraft:redstone_wire replace
setblock ~277 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~634 ~288 ~165 ~634 minecraft:redstone_wire replace
setblock ~289 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~634 ~300 ~165 ~634 minecraft:redstone_wire replace
setblock ~301 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~634 ~312 ~165 ~634 minecraft:redstone_wire replace
setblock ~313 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~634 ~324 ~165 ~634 minecraft:redstone_wire replace
setblock ~325 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~634 ~336 ~165 ~634 minecraft:redstone_wire replace
setblock ~337 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~634 ~348 ~165 ~634 minecraft:redstone_wire replace
setblock ~349 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~634 ~360 ~165 ~634 minecraft:redstone_wire replace
setblock ~361 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~634 ~372 ~165 ~634 minecraft:redstone_wire replace
setblock ~373 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~634 ~384 ~165 ~634 minecraft:redstone_wire replace
setblock ~385 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~634 ~396 ~165 ~634 minecraft:redstone_wire replace
setblock ~397 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~634 ~408 ~165 ~634 minecraft:redstone_wire replace
setblock ~409 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~634 ~420 ~165 ~634 minecraft:redstone_wire replace
setblock ~421 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~634 ~432 ~165 ~634 minecraft:redstone_wire replace
setblock ~433 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~634 ~444 ~165 ~634 minecraft:redstone_wire replace
setblock ~445 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~634 ~456 ~165 ~634 minecraft:redstone_wire replace
setblock ~457 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~634 ~468 ~165 ~634 minecraft:redstone_wire replace
setblock ~469 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~634 ~473 ~165 ~634 minecraft:redstone_wire replace
setblock ~124 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~662 ~135 ~165 ~662 minecraft:redstone_wire replace
setblock ~136 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~662 ~147 ~165 ~662 minecraft:redstone_wire replace
setblock ~148 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~662 ~159 ~165 ~662 minecraft:redstone_wire replace
setblock ~160 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~662 ~171 ~165 ~662 minecraft:redstone_wire replace
setblock ~172 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~662 ~183 ~165 ~662 minecraft:redstone_wire replace
setblock ~184 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~662 ~195 ~165 ~662 minecraft:redstone_wire replace
setblock ~196 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~662 ~207 ~165 ~662 minecraft:redstone_wire replace
setblock ~208 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~662 ~219 ~165 ~662 minecraft:redstone_wire replace
setblock ~220 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~662 ~231 ~165 ~662 minecraft:redstone_wire replace
setblock ~232 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~662 ~243 ~165 ~662 minecraft:redstone_wire replace
setblock ~244 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~662 ~255 ~165 ~662 minecraft:redstone_wire replace
setblock ~256 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~662 ~267 ~165 ~662 minecraft:redstone_wire replace
setblock ~268 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~662 ~279 ~165 ~662 minecraft:redstone_wire replace
setblock ~280 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~662 ~291 ~165 ~662 minecraft:redstone_wire replace
setblock ~292 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~662 ~303 ~165 ~662 minecraft:redstone_wire replace
setblock ~304 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~662 ~315 ~165 ~662 minecraft:redstone_wire replace
setblock ~316 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~662 ~327 ~165 ~662 minecraft:redstone_wire replace
setblock ~328 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~662 ~339 ~165 ~662 minecraft:redstone_wire replace
setblock ~340 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~662 ~351 ~165 ~662 minecraft:redstone_wire replace
setblock ~352 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~662 ~363 ~165 ~662 minecraft:redstone_wire replace
setblock ~364 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~662 ~375 ~165 ~662 minecraft:redstone_wire replace
setblock ~376 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~662 ~387 ~165 ~662 minecraft:redstone_wire replace
setblock ~388 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~662 ~399 ~165 ~662 minecraft:redstone_wire replace
setblock ~400 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~662 ~411 ~165 ~662 minecraft:redstone_wire replace
setblock ~412 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~662 ~423 ~165 ~662 minecraft:redstone_wire replace
setblock ~424 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~662 ~435 ~165 ~662 minecraft:redstone_wire replace
setblock ~436 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~662 ~447 ~165 ~662 minecraft:redstone_wire replace
setblock ~448 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~662 ~459 ~165 ~662 minecraft:redstone_wire replace
setblock ~460 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~662 ~471 ~165 ~662 minecraft:redstone_wire replace
setblock ~472 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~662 ~475 ~165 ~662 minecraft:redstone_wire replace
setblock ~127 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~678 ~138 ~165 ~678 minecraft:redstone_wire replace
setblock ~139 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~678 ~150 ~165 ~678 minecraft:redstone_wire replace
setblock ~151 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~678 ~162 ~165 ~678 minecraft:redstone_wire replace
setblock ~163 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~678 ~174 ~165 ~678 minecraft:redstone_wire replace
setblock ~175 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~678 ~186 ~165 ~678 minecraft:redstone_wire replace
setblock ~187 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~678 ~198 ~165 ~678 minecraft:redstone_wire replace
setblock ~199 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~678 ~210 ~165 ~678 minecraft:redstone_wire replace
setblock ~211 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~678 ~222 ~165 ~678 minecraft:redstone_wire replace
setblock ~223 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~678 ~234 ~165 ~678 minecraft:redstone_wire replace
setblock ~235 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~678 ~246 ~165 ~678 minecraft:redstone_wire replace
setblock ~247 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~678 ~258 ~165 ~678 minecraft:redstone_wire replace
setblock ~259 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~678 ~270 ~165 ~678 minecraft:redstone_wire replace
setblock ~271 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~678 ~282 ~165 ~678 minecraft:redstone_wire replace
setblock ~283 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~678 ~294 ~165 ~678 minecraft:redstone_wire replace
setblock ~295 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~678 ~306 ~165 ~678 minecraft:redstone_wire replace
setblock ~307 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~678 ~318 ~165 ~678 minecraft:redstone_wire replace
setblock ~319 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~678 ~330 ~165 ~678 minecraft:redstone_wire replace
setblock ~331 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~678 ~342 ~165 ~678 minecraft:redstone_wire replace
setblock ~343 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~678 ~354 ~165 ~678 minecraft:redstone_wire replace
setblock ~355 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~678 ~366 ~165 ~678 minecraft:redstone_wire replace
setblock ~367 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~678 ~378 ~165 ~678 minecraft:redstone_wire replace
setblock ~379 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~678 ~390 ~165 ~678 minecraft:redstone_wire replace
setblock ~391 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~678 ~402 ~165 ~678 minecraft:redstone_wire replace
setblock ~403 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~678 ~414 ~165 ~678 minecraft:redstone_wire replace
setblock ~415 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~678 ~426 ~165 ~678 minecraft:redstone_wire replace
setblock ~427 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~678 ~438 ~165 ~678 minecraft:redstone_wire replace
setblock ~439 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~678 ~450 ~165 ~678 minecraft:redstone_wire replace
setblock ~451 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~678 ~462 ~165 ~678 minecraft:redstone_wire replace
setblock ~463 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~678 ~474 ~165 ~678 minecraft:redstone_wire replace
setblock ~475 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~165 ~678 ~477 ~165 ~678 minecraft:redstone_wire replace
setblock ~130 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~702 ~141 ~165 ~702 minecraft:redstone_wire replace
setblock ~142 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~702 ~153 ~165 ~702 minecraft:redstone_wire replace
setblock ~154 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~702 ~165 ~165 ~702 minecraft:redstone_wire replace
setblock ~166 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~702 ~177 ~165 ~702 minecraft:redstone_wire replace
setblock ~178 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~702 ~189 ~165 ~702 minecraft:redstone_wire replace
setblock ~190 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~702 ~201 ~165 ~702 minecraft:redstone_wire replace
setblock ~202 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~702 ~213 ~165 ~702 minecraft:redstone_wire replace
setblock ~214 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~702 ~225 ~165 ~702 minecraft:redstone_wire replace
setblock ~226 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~702 ~237 ~165 ~702 minecraft:redstone_wire replace
setblock ~238 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~702 ~249 ~165 ~702 minecraft:redstone_wire replace
setblock ~250 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~702 ~261 ~165 ~702 minecraft:redstone_wire replace
setblock ~262 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~702 ~273 ~165 ~702 minecraft:redstone_wire replace
setblock ~274 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~702 ~285 ~165 ~702 minecraft:redstone_wire replace
setblock ~286 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~702 ~297 ~165 ~702 minecraft:redstone_wire replace
setblock ~298 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~702 ~309 ~165 ~702 minecraft:redstone_wire replace
setblock ~310 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~702 ~321 ~165 ~702 minecraft:redstone_wire replace
setblock ~322 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~702 ~333 ~165 ~702 minecraft:redstone_wire replace
setblock ~334 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~702 ~345 ~165 ~702 minecraft:redstone_wire replace
setblock ~346 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~702 ~357 ~165 ~702 minecraft:redstone_wire replace
setblock ~358 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~702 ~369 ~165 ~702 minecraft:redstone_wire replace
setblock ~370 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~702 ~381 ~165 ~702 minecraft:redstone_wire replace
setblock ~382 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~702 ~393 ~165 ~702 minecraft:redstone_wire replace
setblock ~394 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~702 ~405 ~165 ~702 minecraft:redstone_wire replace
setblock ~406 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~702 ~417 ~165 ~702 minecraft:redstone_wire replace
setblock ~418 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~702 ~429 ~165 ~702 minecraft:redstone_wire replace
setblock ~430 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~702 ~441 ~165 ~702 minecraft:redstone_wire replace
setblock ~442 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~702 ~453 ~165 ~702 minecraft:redstone_wire replace
setblock ~454 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~702 ~465 ~165 ~702 minecraft:redstone_wire replace
setblock ~466 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~702 ~477 ~165 ~702 minecraft:redstone_wire replace
setblock ~478 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~479 ~165 ~702 minecraft:redstone_wire replace
setblock ~154 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~730 ~165 ~165 ~730 minecraft:redstone_wire replace
setblock ~166 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~730 ~177 ~165 ~730 minecraft:redstone_wire replace
setblock ~178 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~730 ~189 ~165 ~730 minecraft:redstone_wire replace
setblock ~190 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~730 ~201 ~165 ~730 minecraft:redstone_wire replace
setblock ~202 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~730 ~213 ~165 ~730 minecraft:redstone_wire replace
setblock ~214 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~730 ~225 ~165 ~730 minecraft:redstone_wire replace
setblock ~226 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~730 ~237 ~165 ~730 minecraft:redstone_wire replace
setblock ~238 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~730 ~249 ~165 ~730 minecraft:redstone_wire replace
setblock ~250 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~730 ~261 ~165 ~730 minecraft:redstone_wire replace
setblock ~262 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~730 ~273 ~165 ~730 minecraft:redstone_wire replace
setblock ~274 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~730 ~285 ~165 ~730 minecraft:redstone_wire replace
setblock ~286 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~730 ~297 ~165 ~730 minecraft:redstone_wire replace
setblock ~298 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~730 ~309 ~165 ~730 minecraft:redstone_wire replace
setblock ~310 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~730 ~321 ~165 ~730 minecraft:redstone_wire replace
setblock ~322 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~730 ~333 ~165 ~730 minecraft:redstone_wire replace
setblock ~334 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~730 ~345 ~165 ~730 minecraft:redstone_wire replace
setblock ~346 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~730 ~357 ~165 ~730 minecraft:redstone_wire replace
setblock ~358 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~730 ~369 ~165 ~730 minecraft:redstone_wire replace
setblock ~370 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~730 ~381 ~165 ~730 minecraft:redstone_wire replace
setblock ~382 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~730 ~393 ~165 ~730 minecraft:redstone_wire replace
setblock ~394 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~730 ~405 ~165 ~730 minecraft:redstone_wire replace
setblock ~406 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~730 ~417 ~165 ~730 minecraft:redstone_wire replace
setblock ~418 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~730 ~429 ~165 ~730 minecraft:redstone_wire replace
setblock ~430 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~730 ~439 ~165 ~730 minecraft:redstone_wire replace
setblock ~157 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~734 ~168 ~165 ~734 minecraft:redstone_wire replace
setblock ~169 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~734 ~180 ~165 ~734 minecraft:redstone_wire replace
setblock ~181 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~734 ~192 ~165 ~734 minecraft:redstone_wire replace
setblock ~193 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~734 ~204 ~165 ~734 minecraft:redstone_wire replace
setblock ~205 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~734 ~216 ~165 ~734 minecraft:redstone_wire replace
setblock ~217 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~734 ~228 ~165 ~734 minecraft:redstone_wire replace
setblock ~229 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~734 ~240 ~165 ~734 minecraft:redstone_wire replace
setblock ~241 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~734 ~252 ~165 ~734 minecraft:redstone_wire replace
setblock ~253 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~734 ~264 ~165 ~734 minecraft:redstone_wire replace
setblock ~265 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~734 ~276 ~165 ~734 minecraft:redstone_wire replace
setblock ~277 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~734 ~288 ~165 ~734 minecraft:redstone_wire replace
setblock ~289 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~734 ~300 ~165 ~734 minecraft:redstone_wire replace
setblock ~301 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~734 ~312 ~165 ~734 minecraft:redstone_wire replace
setblock ~313 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~734 ~324 ~165 ~734 minecraft:redstone_wire replace
setblock ~325 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~734 ~336 ~165 ~734 minecraft:redstone_wire replace
setblock ~337 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~734 ~348 ~165 ~734 minecraft:redstone_wire replace
setblock ~349 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~734 ~360 ~165 ~734 minecraft:redstone_wire replace
setblock ~361 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~734 ~372 ~165 ~734 minecraft:redstone_wire replace
setblock ~373 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~734 ~384 ~165 ~734 minecraft:redstone_wire replace
setblock ~385 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~734 ~396 ~165 ~734 minecraft:redstone_wire replace
setblock ~397 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~734 ~408 ~165 ~734 minecraft:redstone_wire replace
setblock ~409 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~734 ~420 ~165 ~734 minecraft:redstone_wire replace
setblock ~421 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~734 ~432 ~165 ~734 minecraft:redstone_wire replace
setblock ~433 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~734 ~441 ~165 ~734 minecraft:redstone_wire replace
setblock ~160 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~742 ~171 ~165 ~742 minecraft:redstone_wire replace
setblock ~172 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~742 ~183 ~165 ~742 minecraft:redstone_wire replace
setblock ~184 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~742 ~195 ~165 ~742 minecraft:redstone_wire replace
setblock ~196 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~742 ~207 ~165 ~742 minecraft:redstone_wire replace
setblock ~208 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~742 ~219 ~165 ~742 minecraft:redstone_wire replace
setblock ~220 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~742 ~231 ~165 ~742 minecraft:redstone_wire replace
setblock ~232 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~742 ~243 ~165 ~742 minecraft:redstone_wire replace
setblock ~244 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~742 ~255 ~165 ~742 minecraft:redstone_wire replace
setblock ~256 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~742 ~267 ~165 ~742 minecraft:redstone_wire replace
setblock ~268 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~742 ~279 ~165 ~742 minecraft:redstone_wire replace
setblock ~280 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~742 ~291 ~165 ~742 minecraft:redstone_wire replace
setblock ~292 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~742 ~303 ~165 ~742 minecraft:redstone_wire replace
setblock ~304 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~742 ~315 ~165 ~742 minecraft:redstone_wire replace
setblock ~316 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~742 ~327 ~165 ~742 minecraft:redstone_wire replace
setblock ~328 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~742 ~339 ~165 ~742 minecraft:redstone_wire replace
setblock ~340 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~742 ~351 ~165 ~742 minecraft:redstone_wire replace
setblock ~352 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~742 ~363 ~165 ~742 minecraft:redstone_wire replace
setblock ~364 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~742 ~375 ~165 ~742 minecraft:redstone_wire replace
setblock ~376 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~742 ~387 ~165 ~742 minecraft:redstone_wire replace
setblock ~388 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~742 ~399 ~165 ~742 minecraft:redstone_wire replace
setblock ~400 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~742 ~411 ~165 ~742 minecraft:redstone_wire replace
setblock ~412 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~742 ~423 ~165 ~742 minecraft:redstone_wire replace
setblock ~424 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~742 ~435 ~165 ~742 minecraft:redstone_wire replace
setblock ~436 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~742 ~443 ~165 ~742 minecraft:redstone_wire replace
setblock ~163 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~750 ~174 ~165 ~750 minecraft:redstone_wire replace
setblock ~175 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~750 ~186 ~165 ~750 minecraft:redstone_wire replace
setblock ~187 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~750 ~198 ~165 ~750 minecraft:redstone_wire replace
setblock ~199 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~750 ~210 ~165 ~750 minecraft:redstone_wire replace
setblock ~211 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~750 ~222 ~165 ~750 minecraft:redstone_wire replace
setblock ~223 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~750 ~234 ~165 ~750 minecraft:redstone_wire replace
setblock ~235 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~750 ~246 ~165 ~750 minecraft:redstone_wire replace
setblock ~247 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~750 ~258 ~165 ~750 minecraft:redstone_wire replace
setblock ~259 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~750 ~270 ~165 ~750 minecraft:redstone_wire replace
setblock ~271 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~750 ~282 ~165 ~750 minecraft:redstone_wire replace
setblock ~283 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~750 ~294 ~165 ~750 minecraft:redstone_wire replace
setblock ~295 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~750 ~306 ~165 ~750 minecraft:redstone_wire replace
setblock ~307 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~750 ~318 ~165 ~750 minecraft:redstone_wire replace
setblock ~319 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~750 ~330 ~165 ~750 minecraft:redstone_wire replace
setblock ~331 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~750 ~342 ~165 ~750 minecraft:redstone_wire replace
setblock ~343 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~750 ~354 ~165 ~750 minecraft:redstone_wire replace
setblock ~355 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~750 ~366 ~165 ~750 minecraft:redstone_wire replace
setblock ~367 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~750 ~378 ~165 ~750 minecraft:redstone_wire replace
setblock ~379 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~750 ~390 ~165 ~750 minecraft:redstone_wire replace
setblock ~391 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~750 ~402 ~165 ~750 minecraft:redstone_wire replace
setblock ~403 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~750 ~414 ~165 ~750 minecraft:redstone_wire replace
setblock ~415 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~750 ~426 ~165 ~750 minecraft:redstone_wire replace
setblock ~427 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~750 ~438 ~165 ~750 minecraft:redstone_wire replace
setblock ~439 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~750 ~445 ~165 ~750 minecraft:redstone_wire replace
setblock ~166 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~754 ~177 ~165 ~754 minecraft:redstone_wire replace
setblock ~178 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~754 ~189 ~165 ~754 minecraft:redstone_wire replace
setblock ~190 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~754 ~201 ~165 ~754 minecraft:redstone_wire replace
setblock ~202 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~754 ~213 ~165 ~754 minecraft:redstone_wire replace
setblock ~214 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~754 ~225 ~165 ~754 minecraft:redstone_wire replace
setblock ~226 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~754 ~237 ~165 ~754 minecraft:redstone_wire replace
setblock ~238 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~754 ~249 ~165 ~754 minecraft:redstone_wire replace
setblock ~250 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~754 ~261 ~165 ~754 minecraft:redstone_wire replace
setblock ~262 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~754 ~273 ~165 ~754 minecraft:redstone_wire replace
setblock ~274 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~754 ~285 ~165 ~754 minecraft:redstone_wire replace
setblock ~286 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~754 ~297 ~165 ~754 minecraft:redstone_wire replace
setblock ~298 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~754 ~309 ~165 ~754 minecraft:redstone_wire replace
setblock ~310 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~754 ~321 ~165 ~754 minecraft:redstone_wire replace
setblock ~322 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~754 ~333 ~165 ~754 minecraft:redstone_wire replace
setblock ~334 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~754 ~345 ~165 ~754 minecraft:redstone_wire replace
setblock ~346 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~754 ~357 ~165 ~754 minecraft:redstone_wire replace
setblock ~358 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~754 ~369 ~165 ~754 minecraft:redstone_wire replace
setblock ~370 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~754 ~381 ~165 ~754 minecraft:redstone_wire replace
setblock ~382 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~754 ~393 ~165 ~754 minecraft:redstone_wire replace
setblock ~394 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~754 ~405 ~165 ~754 minecraft:redstone_wire replace
setblock ~406 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~754 ~417 ~165 ~754 minecraft:redstone_wire replace
setblock ~418 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~754 ~429 ~165 ~754 minecraft:redstone_wire replace
setblock ~430 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~754 ~441 ~165 ~754 minecraft:redstone_wire replace
setblock ~442 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~754 ~447 ~165 ~754 minecraft:redstone_wire replace
setblock ~169 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~758 ~180 ~165 ~758 minecraft:redstone_wire replace
setblock ~181 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~758 ~192 ~165 ~758 minecraft:redstone_wire replace
setblock ~193 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~758 ~204 ~165 ~758 minecraft:redstone_wire replace
setblock ~205 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~758 ~216 ~165 ~758 minecraft:redstone_wire replace
setblock ~217 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~758 ~228 ~165 ~758 minecraft:redstone_wire replace
setblock ~229 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~758 ~240 ~165 ~758 minecraft:redstone_wire replace
setblock ~241 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~758 ~252 ~165 ~758 minecraft:redstone_wire replace
setblock ~253 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~758 ~264 ~165 ~758 minecraft:redstone_wire replace
setblock ~265 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~758 ~276 ~165 ~758 minecraft:redstone_wire replace
setblock ~277 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~758 ~288 ~165 ~758 minecraft:redstone_wire replace
setblock ~289 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~758 ~300 ~165 ~758 minecraft:redstone_wire replace
setblock ~301 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~758 ~312 ~165 ~758 minecraft:redstone_wire replace
setblock ~313 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~758 ~324 ~165 ~758 minecraft:redstone_wire replace
setblock ~325 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~758 ~336 ~165 ~758 minecraft:redstone_wire replace
setblock ~337 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~758 ~348 ~165 ~758 minecraft:redstone_wire replace
setblock ~349 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~758 ~360 ~165 ~758 minecraft:redstone_wire replace
setblock ~361 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~758 ~372 ~165 ~758 minecraft:redstone_wire replace
setblock ~373 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~758 ~384 ~165 ~758 minecraft:redstone_wire replace
setblock ~385 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~758 ~396 ~165 ~758 minecraft:redstone_wire replace
setblock ~397 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~758 ~408 ~165 ~758 minecraft:redstone_wire replace
setblock ~409 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~758 ~420 ~165 ~758 minecraft:redstone_wire replace
setblock ~421 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~758 ~432 ~165 ~758 minecraft:redstone_wire replace
setblock ~433 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~758 ~444 ~165 ~758 minecraft:redstone_wire replace
setblock ~445 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~758 ~449 ~165 ~758 minecraft:redstone_wire replace
setblock ~133 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~762 ~144 ~165 ~762 minecraft:redstone_wire replace
setblock ~145 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~762 ~156 ~165 ~762 minecraft:redstone_wire replace
setblock ~157 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~762 ~168 ~165 ~762 minecraft:redstone_wire replace
setblock ~169 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~762 ~180 ~165 ~762 minecraft:redstone_wire replace
setblock ~181 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~762 ~192 ~165 ~762 minecraft:redstone_wire replace
setblock ~193 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~762 ~204 ~165 ~762 minecraft:redstone_wire replace
setblock ~205 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~762 ~216 ~165 ~762 minecraft:redstone_wire replace
setblock ~217 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~762 ~228 ~165 ~762 minecraft:redstone_wire replace
setblock ~229 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~762 ~240 ~165 ~762 minecraft:redstone_wire replace
setblock ~241 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~762 ~252 ~165 ~762 minecraft:redstone_wire replace
setblock ~253 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~762 ~264 ~165 ~762 minecraft:redstone_wire replace
setblock ~265 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~762 ~276 ~165 ~762 minecraft:redstone_wire replace
setblock ~277 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~762 ~288 ~165 ~762 minecraft:redstone_wire replace
setblock ~289 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~762 ~300 ~165 ~762 minecraft:redstone_wire replace
setblock ~301 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~762 ~312 ~165 ~762 minecraft:redstone_wire replace
setblock ~313 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~762 ~324 ~165 ~762 minecraft:redstone_wire replace
setblock ~325 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~762 ~336 ~165 ~762 minecraft:redstone_wire replace
setblock ~337 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~762 ~348 ~165 ~762 minecraft:redstone_wire replace
setblock ~349 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~762 ~360 ~165 ~762 minecraft:redstone_wire replace
setblock ~361 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~762 ~372 ~165 ~762 minecraft:redstone_wire replace
setblock ~373 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~762 ~384 ~165 ~762 minecraft:redstone_wire replace
setblock ~385 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~762 ~396 ~165 ~762 minecraft:redstone_wire replace
setblock ~397 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~762 ~408 ~165 ~762 minecraft:redstone_wire replace
setblock ~409 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~762 ~420 ~165 ~762 minecraft:redstone_wire replace
setblock ~421 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~762 ~432 ~165 ~762 minecraft:redstone_wire replace
setblock ~433 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~762 ~444 ~165 ~762 minecraft:redstone_wire replace
setblock ~445 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~762 ~453 ~165 ~762 minecraft:redstone_wire replace
setblock ~136 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~794 ~147 ~165 ~794 minecraft:redstone_wire replace
setblock ~148 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~794 ~159 ~165 ~794 minecraft:redstone_wire replace
setblock ~160 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~794 ~171 ~165 ~794 minecraft:redstone_wire replace
setblock ~172 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~794 ~183 ~165 ~794 minecraft:redstone_wire replace
setblock ~184 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~794 ~195 ~165 ~794 minecraft:redstone_wire replace
setblock ~196 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~794 ~207 ~165 ~794 minecraft:redstone_wire replace
setblock ~208 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~794 ~219 ~165 ~794 minecraft:redstone_wire replace
setblock ~220 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~794 ~231 ~165 ~794 minecraft:redstone_wire replace
setblock ~232 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~794 ~243 ~165 ~794 minecraft:redstone_wire replace
setblock ~244 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~794 ~255 ~165 ~794 minecraft:redstone_wire replace
setblock ~256 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~794 ~267 ~165 ~794 minecraft:redstone_wire replace
setblock ~268 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~794 ~279 ~165 ~794 minecraft:redstone_wire replace
setblock ~280 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~794 ~291 ~165 ~794 minecraft:redstone_wire replace
setblock ~292 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~794 ~303 ~165 ~794 minecraft:redstone_wire replace
setblock ~304 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~794 ~315 ~165 ~794 minecraft:redstone_wire replace
setblock ~316 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~794 ~327 ~165 ~794 minecraft:redstone_wire replace
setblock ~328 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~794 ~339 ~165 ~794 minecraft:redstone_wire replace
setblock ~340 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~794 ~351 ~165 ~794 minecraft:redstone_wire replace
setblock ~352 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~794 ~363 ~165 ~794 minecraft:redstone_wire replace
setblock ~364 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~794 ~375 ~165 ~794 minecraft:redstone_wire replace
setblock ~376 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~794 ~387 ~165 ~794 minecraft:redstone_wire replace
setblock ~388 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~794 ~399 ~165 ~794 minecraft:redstone_wire replace
setblock ~400 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~794 ~411 ~165 ~794 minecraft:redstone_wire replace
setblock ~412 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~794 ~423 ~165 ~794 minecraft:redstone_wire replace
setblock ~424 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~794 ~435 ~165 ~794 minecraft:redstone_wire replace
setblock ~436 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~794 ~447 ~165 ~794 minecraft:redstone_wire replace
setblock ~448 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~794 ~455 ~165 ~794 minecraft:redstone_wire replace
setblock ~139 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~826 ~150 ~165 ~826 minecraft:redstone_wire replace
setblock ~151 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~826 ~162 ~165 ~826 minecraft:redstone_wire replace
setblock ~163 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~826 ~174 ~165 ~826 minecraft:redstone_wire replace
setblock ~175 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~826 ~186 ~165 ~826 minecraft:redstone_wire replace
setblock ~187 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~826 ~198 ~165 ~826 minecraft:redstone_wire replace
setblock ~199 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~826 ~210 ~165 ~826 minecraft:redstone_wire replace
setblock ~211 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~826 ~222 ~165 ~826 minecraft:redstone_wire replace
setblock ~223 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~826 ~234 ~165 ~826 minecraft:redstone_wire replace
setblock ~235 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~826 ~246 ~165 ~826 minecraft:redstone_wire replace
setblock ~247 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~826 ~258 ~165 ~826 minecraft:redstone_wire replace
setblock ~259 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~826 ~270 ~165 ~826 minecraft:redstone_wire replace
setblock ~271 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~826 ~282 ~165 ~826 minecraft:redstone_wire replace
setblock ~283 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~826 ~294 ~165 ~826 minecraft:redstone_wire replace
setblock ~295 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~826 ~306 ~165 ~826 minecraft:redstone_wire replace
setblock ~307 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~826 ~318 ~165 ~826 minecraft:redstone_wire replace
setblock ~319 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~826 ~330 ~165 ~826 minecraft:redstone_wire replace
setblock ~331 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~826 ~342 ~165 ~826 minecraft:redstone_wire replace
setblock ~343 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~826 ~354 ~165 ~826 minecraft:redstone_wire replace
setblock ~355 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~826 ~366 ~165 ~826 minecraft:redstone_wire replace
setblock ~367 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~826 ~378 ~165 ~826 minecraft:redstone_wire replace
setblock ~379 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~826 ~390 ~165 ~826 minecraft:redstone_wire replace
setblock ~391 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~826 ~402 ~165 ~826 minecraft:redstone_wire replace
setblock ~403 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~826 ~414 ~165 ~826 minecraft:redstone_wire replace
setblock ~415 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~826 ~426 ~165 ~826 minecraft:redstone_wire replace
setblock ~427 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~826 ~438 ~165 ~826 minecraft:redstone_wire replace
setblock ~439 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~826 ~450 ~165 ~826 minecraft:redstone_wire replace
setblock ~451 ~165 ~826 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~826 ~457 ~165 ~826 minecraft:redstone_wire replace
setblock ~142 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~862 ~153 ~165 ~862 minecraft:redstone_wire replace
setblock ~154 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~862 ~165 ~165 ~862 minecraft:redstone_wire replace
setblock ~166 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~862 ~177 ~165 ~862 minecraft:redstone_wire replace
setblock ~178 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~862 ~189 ~165 ~862 minecraft:redstone_wire replace
setblock ~190 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~862 ~201 ~165 ~862 minecraft:redstone_wire replace
setblock ~202 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~862 ~213 ~165 ~862 minecraft:redstone_wire replace
setblock ~214 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~862 ~225 ~165 ~862 minecraft:redstone_wire replace
setblock ~226 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~862 ~237 ~165 ~862 minecraft:redstone_wire replace
setblock ~238 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~862 ~249 ~165 ~862 minecraft:redstone_wire replace
setblock ~250 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~862 ~261 ~165 ~862 minecraft:redstone_wire replace
setblock ~262 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~862 ~273 ~165 ~862 minecraft:redstone_wire replace
setblock ~274 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~862 ~285 ~165 ~862 minecraft:redstone_wire replace
setblock ~286 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~862 ~297 ~165 ~862 minecraft:redstone_wire replace
setblock ~298 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~862 ~309 ~165 ~862 minecraft:redstone_wire replace
setblock ~310 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~862 ~321 ~165 ~862 minecraft:redstone_wire replace
setblock ~322 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~862 ~333 ~165 ~862 minecraft:redstone_wire replace
setblock ~334 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~862 ~345 ~165 ~862 minecraft:redstone_wire replace
setblock ~346 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~862 ~357 ~165 ~862 minecraft:redstone_wire replace
setblock ~358 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~862 ~369 ~165 ~862 minecraft:redstone_wire replace
setblock ~370 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~862 ~381 ~165 ~862 minecraft:redstone_wire replace
setblock ~382 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~862 ~393 ~165 ~862 minecraft:redstone_wire replace
setblock ~394 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~862 ~405 ~165 ~862 minecraft:redstone_wire replace
setblock ~406 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~862 ~417 ~165 ~862 minecraft:redstone_wire replace
setblock ~418 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~862 ~429 ~165 ~862 minecraft:redstone_wire replace
setblock ~430 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~862 ~441 ~165 ~862 minecraft:redstone_wire replace
setblock ~442 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~862 ~453 ~165 ~862 minecraft:redstone_wire replace
setblock ~454 ~165 ~862 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~862 ~459 ~165 ~862 minecraft:redstone_wire replace
setblock ~145 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~890 ~156 ~165 ~890 minecraft:redstone_wire replace
setblock ~157 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~890 ~168 ~165 ~890 minecraft:redstone_wire replace
setblock ~169 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~890 ~180 ~165 ~890 minecraft:redstone_wire replace
setblock ~181 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~890 ~192 ~165 ~890 minecraft:redstone_wire replace
setblock ~193 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~890 ~204 ~165 ~890 minecraft:redstone_wire replace
setblock ~205 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~890 ~216 ~165 ~890 minecraft:redstone_wire replace
setblock ~217 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~890 ~228 ~165 ~890 minecraft:redstone_wire replace
setblock ~229 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~890 ~240 ~165 ~890 minecraft:redstone_wire replace
setblock ~241 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~890 ~252 ~165 ~890 minecraft:redstone_wire replace
setblock ~253 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~890 ~264 ~165 ~890 minecraft:redstone_wire replace
setblock ~265 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~890 ~276 ~165 ~890 minecraft:redstone_wire replace
setblock ~277 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~890 ~288 ~165 ~890 minecraft:redstone_wire replace
setblock ~289 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~890 ~300 ~165 ~890 minecraft:redstone_wire replace
setblock ~301 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~890 ~312 ~165 ~890 minecraft:redstone_wire replace
setblock ~313 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~890 ~324 ~165 ~890 minecraft:redstone_wire replace
setblock ~325 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~890 ~336 ~165 ~890 minecraft:redstone_wire replace
setblock ~337 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~890 ~348 ~165 ~890 minecraft:redstone_wire replace
setblock ~349 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~890 ~360 ~165 ~890 minecraft:redstone_wire replace
setblock ~361 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~890 ~372 ~165 ~890 minecraft:redstone_wire replace
setblock ~373 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~890 ~384 ~165 ~890 minecraft:redstone_wire replace
setblock ~385 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~890 ~396 ~165 ~890 minecraft:redstone_wire replace
setblock ~397 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~890 ~408 ~165 ~890 minecraft:redstone_wire replace
setblock ~409 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~890 ~420 ~165 ~890 minecraft:redstone_wire replace
setblock ~421 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~890 ~432 ~165 ~890 minecraft:redstone_wire replace
setblock ~433 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~890 ~444 ~165 ~890 minecraft:redstone_wire replace
setblock ~445 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~890 ~456 ~165 ~890 minecraft:redstone_wire replace
setblock ~457 ~165 ~890 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~890 ~461 ~165 ~890 minecraft:redstone_wire replace
setblock ~148 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~906 ~159 ~165 ~906 minecraft:redstone_wire replace
setblock ~160 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~906 ~171 ~165 ~906 minecraft:redstone_wire replace
setblock ~172 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~906 ~183 ~165 ~906 minecraft:redstone_wire replace
setblock ~184 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~906 ~195 ~165 ~906 minecraft:redstone_wire replace
setblock ~196 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~906 ~207 ~165 ~906 minecraft:redstone_wire replace
setblock ~208 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~906 ~219 ~165 ~906 minecraft:redstone_wire replace
setblock ~220 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~906 ~231 ~165 ~906 minecraft:redstone_wire replace
setblock ~232 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~906 ~243 ~165 ~906 minecraft:redstone_wire replace
setblock ~244 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~906 ~255 ~165 ~906 minecraft:redstone_wire replace
setblock ~256 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~906 ~267 ~165 ~906 minecraft:redstone_wire replace
setblock ~268 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~906 ~279 ~165 ~906 minecraft:redstone_wire replace
setblock ~280 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~906 ~291 ~165 ~906 minecraft:redstone_wire replace
setblock ~292 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~906 ~303 ~165 ~906 minecraft:redstone_wire replace
setblock ~304 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~906 ~315 ~165 ~906 minecraft:redstone_wire replace
setblock ~316 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~906 ~327 ~165 ~906 minecraft:redstone_wire replace
setblock ~328 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~906 ~339 ~165 ~906 minecraft:redstone_wire replace
setblock ~340 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~906 ~351 ~165 ~906 minecraft:redstone_wire replace
setblock ~352 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~906 ~363 ~165 ~906 minecraft:redstone_wire replace
setblock ~364 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~906 ~375 ~165 ~906 minecraft:redstone_wire replace
setblock ~376 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~906 ~387 ~165 ~906 minecraft:redstone_wire replace
setblock ~388 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~906 ~399 ~165 ~906 minecraft:redstone_wire replace
setblock ~400 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~906 ~411 ~165 ~906 minecraft:redstone_wire replace
setblock ~412 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~906 ~423 ~165 ~906 minecraft:redstone_wire replace
setblock ~424 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~906 ~435 ~165 ~906 minecraft:redstone_wire replace
setblock ~436 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~906 ~447 ~165 ~906 minecraft:redstone_wire replace
setblock ~448 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~906 ~459 ~165 ~906 minecraft:redstone_wire replace
setblock ~460 ~165 ~906 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~906 ~463 ~165 ~906 minecraft:redstone_wire replace
setblock ~151 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~930 ~162 ~165 ~930 minecraft:redstone_wire replace
setblock ~163 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~930 ~174 ~165 ~930 minecraft:redstone_wire replace
setblock ~175 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~930 ~186 ~165 ~930 minecraft:redstone_wire replace
setblock ~187 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~930 ~198 ~165 ~930 minecraft:redstone_wire replace
setblock ~199 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~930 ~210 ~165 ~930 minecraft:redstone_wire replace
setblock ~211 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~930 ~222 ~165 ~930 minecraft:redstone_wire replace
setblock ~223 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~930 ~234 ~165 ~930 minecraft:redstone_wire replace
setblock ~235 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~930 ~246 ~165 ~930 minecraft:redstone_wire replace
setblock ~247 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~930 ~258 ~165 ~930 minecraft:redstone_wire replace
setblock ~259 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~930 ~270 ~165 ~930 minecraft:redstone_wire replace
setblock ~271 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~930 ~282 ~165 ~930 minecraft:redstone_wire replace
setblock ~283 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~930 ~294 ~165 ~930 minecraft:redstone_wire replace
setblock ~295 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~930 ~306 ~165 ~930 minecraft:redstone_wire replace
setblock ~307 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~930 ~318 ~165 ~930 minecraft:redstone_wire replace
setblock ~319 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~930 ~330 ~165 ~930 minecraft:redstone_wire replace
setblock ~331 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~930 ~342 ~165 ~930 minecraft:redstone_wire replace
setblock ~343 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~930 ~354 ~165 ~930 minecraft:redstone_wire replace
setblock ~355 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~930 ~366 ~165 ~930 minecraft:redstone_wire replace
setblock ~367 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~930 ~378 ~165 ~930 minecraft:redstone_wire replace
setblock ~379 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~930 ~390 ~165 ~930 minecraft:redstone_wire replace
setblock ~391 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~930 ~402 ~165 ~930 minecraft:redstone_wire replace
setblock ~403 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~930 ~414 ~165 ~930 minecraft:redstone_wire replace
setblock ~415 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~930 ~426 ~165 ~930 minecraft:redstone_wire replace
setblock ~427 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~930 ~438 ~165 ~930 minecraft:redstone_wire replace
setblock ~439 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~930 ~450 ~165 ~930 minecraft:redstone_wire replace
setblock ~451 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~930 ~462 ~165 ~930 minecraft:redstone_wire replace
setblock ~463 ~165 ~930 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~930 ~465 ~165 ~930 minecraft:redstone_wire replace
setblock ~172 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~962 ~183 ~165 ~962 minecraft:redstone_wire replace
setblock ~184 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~962 ~195 ~165 ~962 minecraft:redstone_wire replace
setblock ~196 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~962 ~207 ~165 ~962 minecraft:redstone_wire replace
setblock ~208 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~962 ~219 ~165 ~962 minecraft:redstone_wire replace
setblock ~220 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~962 ~231 ~165 ~962 minecraft:redstone_wire replace
setblock ~232 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~962 ~243 ~165 ~962 minecraft:redstone_wire replace
setblock ~244 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~962 ~255 ~165 ~962 minecraft:redstone_wire replace
setblock ~256 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~962 ~267 ~165 ~962 minecraft:redstone_wire replace
setblock ~268 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~962 ~279 ~165 ~962 minecraft:redstone_wire replace
setblock ~280 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~962 ~291 ~165 ~962 minecraft:redstone_wire replace
setblock ~292 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~962 ~303 ~165 ~962 minecraft:redstone_wire replace
setblock ~304 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~962 ~315 ~165 ~962 minecraft:redstone_wire replace
setblock ~316 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~962 ~327 ~165 ~962 minecraft:redstone_wire replace
setblock ~328 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~962 ~339 ~165 ~962 minecraft:redstone_wire replace
setblock ~340 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~962 ~351 ~165 ~962 minecraft:redstone_wire replace
setblock ~352 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~962 ~363 ~165 ~962 minecraft:redstone_wire replace
setblock ~364 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~962 ~375 ~165 ~962 minecraft:redstone_wire replace
setblock ~376 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~962 ~387 ~165 ~962 minecraft:redstone_wire replace
setblock ~388 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~962 ~399 ~165 ~962 minecraft:redstone_wire replace
setblock ~400 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~962 ~411 ~165 ~962 minecraft:redstone_wire replace
setblock ~412 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~962 ~423 ~165 ~962 minecraft:redstone_wire replace
setblock ~424 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~962 ~435 ~165 ~962 minecraft:redstone_wire replace
setblock ~436 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~962 ~447 ~165 ~962 minecraft:redstone_wire replace
setblock ~448 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~962 ~459 ~165 ~962 minecraft:redstone_wire replace
setblock ~460 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~962 ~471 ~165 ~962 minecraft:redstone_wire replace
setblock ~472 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~962 ~483 ~165 ~962 minecraft:redstone_wire replace
setblock ~484 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~485 ~165 ~962 ~495 ~165 ~962 minecraft:redstone_wire replace
setblock ~496 ~165 ~962 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~497 ~165 ~962 ~501 ~165 ~962 minecraft:redstone_wire replace
setblock ~175 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~966 ~186 ~165 ~966 minecraft:redstone_wire replace
setblock ~187 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~966 ~198 ~165 ~966 minecraft:redstone_wire replace
setblock ~199 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~966 ~210 ~165 ~966 minecraft:redstone_wire replace
setblock ~211 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~966 ~222 ~165 ~966 minecraft:redstone_wire replace
setblock ~223 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~966 ~234 ~165 ~966 minecraft:redstone_wire replace
setblock ~235 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~966 ~246 ~165 ~966 minecraft:redstone_wire replace
setblock ~247 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~966 ~258 ~165 ~966 minecraft:redstone_wire replace
setblock ~259 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~966 ~270 ~165 ~966 minecraft:redstone_wire replace
setblock ~271 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~966 ~282 ~165 ~966 minecraft:redstone_wire replace
setblock ~283 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~966 ~294 ~165 ~966 minecraft:redstone_wire replace
setblock ~295 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~966 ~306 ~165 ~966 minecraft:redstone_wire replace
setblock ~307 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~966 ~318 ~165 ~966 minecraft:redstone_wire replace
setblock ~319 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~966 ~330 ~165 ~966 minecraft:redstone_wire replace
setblock ~331 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~966 ~342 ~165 ~966 minecraft:redstone_wire replace
setblock ~343 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~966 ~354 ~165 ~966 minecraft:redstone_wire replace
setblock ~355 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~966 ~366 ~165 ~966 minecraft:redstone_wire replace
setblock ~367 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~966 ~378 ~165 ~966 minecraft:redstone_wire replace
setblock ~379 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~966 ~390 ~165 ~966 minecraft:redstone_wire replace
setblock ~391 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~966 ~402 ~165 ~966 minecraft:redstone_wire replace
setblock ~403 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~966 ~414 ~165 ~966 minecraft:redstone_wire replace
setblock ~415 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~966 ~426 ~165 ~966 minecraft:redstone_wire replace
setblock ~427 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~966 ~438 ~165 ~966 minecraft:redstone_wire replace
setblock ~439 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~966 ~450 ~165 ~966 minecraft:redstone_wire replace
setblock ~451 ~165 ~966 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~496 ~166 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~166 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~166 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~166 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~166 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~166 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~166 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~166 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~166 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~166 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~166 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~166 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~166 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~166 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~166 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~166 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~166 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~166 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~166 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~166 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~166 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~166 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~166 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~166 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~166 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~166 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~166 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~166 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~166 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~166 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~166 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~166 ~966 minecraft:redstone_torch[lit=true] replace
setblock ~496 ~168 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~168 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~168 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~168 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~168 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~168 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~168 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~168 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~168 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~168 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~168 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~168 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~168 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~168 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~168 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~168 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~168 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~168 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~168 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~168 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~168 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~168 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~168 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~168 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~168 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~168 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~168 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~168 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~168 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~168 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~168 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~168 ~966 minecraft:redstone_torch[lit=true] replace
fill ~440 ~169 ~3 ~440 ~169 ~8 minecraft:redstone_wire replace
fill ~454 ~169 ~3 ~454 ~169 ~4 minecraft:redstone_wire replace
fill ~468 ~169 ~3 ~468 ~169 ~4 minecraft:redstone_wire replace
fill ~494 ~169 ~3 ~494 ~169 ~8 minecraft:redstone_wire replace
fill ~498 ~169 ~3 ~498 ~169 ~4 minecraft:redstone_wire replace
fill ~450 ~169 ~5 ~450 ~169 ~12 minecraft:redstone_wire replace
setblock ~454 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~484 ~169 ~5 ~484 ~169 ~8 minecraft:redstone_wire replace
setblock ~498 ~169 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~500 ~169 ~5 ~500 ~169 ~12 minecraft:redstone_wire replace
fill ~454 ~169 ~6 ~454 ~169 ~16 minecraft:redstone_wire replace
fill ~464 ~169 ~6 ~464 ~169 ~16 minecraft:redstone_wire replace
fill ~468 ~169 ~6 ~468 ~169 ~16 minecraft:redstone_wire replace
fill ~478 ~169 ~6 ~478 ~169 ~16 minecraft:redstone_wire replace
fill ~498 ~169 ~6 ~498 ~169 ~16 minecraft:redstone_wire replace
fill ~442 ~169 ~7 ~442 ~169 ~12 minecraft:redstone_wire replace
fill ~456 ~169 ~7 ~456 ~169 ~12 minecraft:redstone_wire replace
fill ~470 ~169 ~7 ~470 ~169 ~12 minecraft:redstone_wire replace
fill ~492 ~169 ~7 ~492 ~169 ~12 minecraft:redstone_wire replace
fill ~502 ~169 ~7 ~502 ~169 ~12 minecraft:redstone_wire replace
setblock ~440 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~9 ~452 ~169 ~16 minecraft:redstone_wire replace
fill ~466 ~169 ~9 ~466 ~169 ~16 minecraft:redstone_wire replace
fill ~480 ~169 ~9 ~480 ~169 ~16 minecraft:redstone_wire replace
setblock ~482 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~9 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~496 ~169 ~9 ~496 ~169 ~12 minecraft:redstone_wire replace
fill ~440 ~169 ~10 ~440 ~169 ~20 minecraft:redstone_wire replace
fill ~482 ~169 ~10 ~482 ~169 ~20 minecraft:redstone_wire replace
fill ~484 ~169 ~10 ~484 ~169 ~20 minecraft:redstone_wire replace
fill ~494 ~169 ~10 ~494 ~169 ~20 minecraft:redstone_wire replace
fill ~448 ~169 ~11 ~448 ~169 ~20 minecraft:redstone_wire replace
fill ~462 ~169 ~11 ~462 ~169 ~12 minecraft:redstone_wire replace
fill ~476 ~169 ~11 ~476 ~169 ~12 minecraft:redstone_wire replace
fill ~486 ~169 ~11 ~486 ~169 ~12 minecraft:redstone_wire replace
setblock ~442 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~444 ~169 ~13 ~444 ~169 ~20 minecraft:redstone_wire replace
setblock ~450 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~13 ~458 ~169 ~20 minecraft:redstone_wire replace
setblock ~462 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~472 ~169 ~13 ~472 ~169 ~20 minecraft:redstone_wire replace
setblock ~476 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~490 ~169 ~13 ~490 ~169 ~16 minecraft:redstone_wire replace
setblock ~492 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~13 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~14 ~442 ~169 ~24 minecraft:redstone_wire replace
fill ~450 ~169 ~14 ~450 ~169 ~24 minecraft:redstone_wire replace
fill ~456 ~169 ~14 ~456 ~169 ~24 minecraft:redstone_wire replace
fill ~462 ~169 ~14 ~462 ~169 ~24 minecraft:redstone_wire replace
fill ~470 ~169 ~14 ~470 ~169 ~24 minecraft:redstone_wire replace
fill ~476 ~169 ~14 ~476 ~169 ~24 minecraft:redstone_wire replace
fill ~486 ~169 ~14 ~486 ~169 ~24 minecraft:redstone_wire replace
fill ~492 ~169 ~14 ~492 ~169 ~24 minecraft:redstone_wire replace
fill ~496 ~169 ~14 ~496 ~169 ~24 minecraft:redstone_wire replace
fill ~500 ~169 ~14 ~500 ~169 ~24 minecraft:redstone_wire replace
fill ~502 ~169 ~14 ~502 ~169 ~24 minecraft:redstone_wire replace
fill ~446 ~169 ~15 ~446 ~169 ~16 minecraft:redstone_wire replace
fill ~460 ~169 ~15 ~460 ~169 ~20 minecraft:redstone_wire replace
fill ~474 ~169 ~15 ~474 ~169 ~20 minecraft:redstone_wire replace
fill ~488 ~169 ~15 ~488 ~169 ~16 minecraft:redstone_wire replace
setblock ~446 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~18 ~446 ~169 ~28 minecraft:redstone_wire replace
fill ~452 ~169 ~18 ~452 ~169 ~28 minecraft:redstone_wire replace
fill ~454 ~169 ~18 ~454 ~169 ~28 minecraft:redstone_wire replace
fill ~464 ~169 ~18 ~464 ~169 ~28 minecraft:redstone_wire replace
fill ~466 ~169 ~18 ~466 ~169 ~28 minecraft:redstone_wire replace
fill ~468 ~169 ~18 ~468 ~169 ~28 minecraft:redstone_wire replace
fill ~478 ~169 ~18 ~478 ~169 ~28 minecraft:redstone_wire replace
fill ~480 ~169 ~18 ~480 ~169 ~28 minecraft:redstone_wire replace
fill ~488 ~169 ~18 ~488 ~169 ~28 minecraft:redstone_wire replace
fill ~490 ~169 ~18 ~490 ~169 ~28 minecraft:redstone_wire replace
fill ~498 ~169 ~18 ~498 ~169 ~28 minecraft:redstone_wire replace
setblock ~440 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~22 ~440 ~169 ~32 minecraft:redstone_wire replace
fill ~444 ~169 ~22 ~444 ~169 ~32 minecraft:redstone_wire replace
fill ~448 ~169 ~22 ~448 ~169 ~32 minecraft:redstone_wire replace
fill ~458 ~169 ~22 ~458 ~169 ~32 minecraft:redstone_wire replace
fill ~460 ~169 ~22 ~460 ~169 ~32 minecraft:redstone_wire replace
fill ~472 ~169 ~22 ~472 ~169 ~32 minecraft:redstone_wire replace
fill ~474 ~169 ~22 ~474 ~169 ~32 minecraft:redstone_wire replace
fill ~482 ~169 ~22 ~482 ~169 ~32 minecraft:redstone_wire replace
fill ~484 ~169 ~22 ~484 ~169 ~32 minecraft:redstone_wire replace
fill ~494 ~169 ~22 ~494 ~169 ~32 minecraft:redstone_wire replace
setblock ~442 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~26 ~442 ~169 ~36 minecraft:redstone_wire replace
fill ~450 ~169 ~26 ~450 ~169 ~36 minecraft:redstone_wire replace
fill ~456 ~169 ~26 ~456 ~169 ~36 minecraft:redstone_wire replace
fill ~462 ~169 ~26 ~462 ~169 ~36 minecraft:redstone_wire replace
fill ~470 ~169 ~26 ~470 ~169 ~36 minecraft:redstone_wire replace
fill ~476 ~169 ~26 ~476 ~169 ~36 minecraft:redstone_wire replace
fill ~486 ~169 ~26 ~486 ~169 ~36 minecraft:redstone_wire replace
fill ~492 ~169 ~26 ~492 ~169 ~36 minecraft:redstone_wire replace
fill ~496 ~169 ~26 ~496 ~169 ~36 minecraft:redstone_wire replace
fill ~500 ~169 ~26 ~500 ~169 ~36 minecraft:redstone_wire replace
fill ~502 ~169 ~26 ~502 ~169 ~36 minecraft:redstone_wire replace
setblock ~446 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~30 ~446 ~169 ~40 minecraft:redstone_wire replace
fill ~452 ~169 ~30 ~452 ~169 ~40 minecraft:redstone_wire replace
fill ~454 ~169 ~30 ~454 ~169 ~40 minecraft:redstone_wire replace
fill ~464 ~169 ~30 ~464 ~169 ~40 minecraft:redstone_wire replace
fill ~466 ~169 ~30 ~466 ~169 ~40 minecraft:redstone_wire replace
fill ~468 ~169 ~30 ~468 ~169 ~40 minecraft:redstone_wire replace
fill ~478 ~169 ~30 ~478 ~169 ~40 minecraft:redstone_wire replace
fill ~480 ~169 ~30 ~480 ~169 ~40 minecraft:redstone_wire replace
fill ~488 ~169 ~30 ~488 ~169 ~40 minecraft:redstone_wire replace
fill ~490 ~169 ~30 ~490 ~169 ~40 minecraft:redstone_wire replace
fill ~498 ~169 ~30 ~498 ~169 ~40 minecraft:redstone_wire replace
setblock ~440 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~34 ~440 ~169 ~44 minecraft:redstone_wire replace
fill ~444 ~169 ~34 ~444 ~169 ~44 minecraft:redstone_wire replace
fill ~448 ~169 ~34 ~448 ~169 ~44 minecraft:redstone_wire replace
fill ~458 ~169 ~34 ~458 ~169 ~44 minecraft:redstone_wire replace
fill ~460 ~169 ~34 ~460 ~169 ~44 minecraft:redstone_wire replace
fill ~472 ~169 ~34 ~472 ~169 ~44 minecraft:redstone_wire replace
fill ~474 ~169 ~34 ~474 ~169 ~44 minecraft:redstone_wire replace
fill ~482 ~169 ~34 ~482 ~169 ~44 minecraft:redstone_wire replace
fill ~484 ~169 ~34 ~484 ~169 ~44 minecraft:redstone_wire replace
fill ~494 ~169 ~34 ~494 ~169 ~44 minecraft:redstone_wire replace
setblock ~442 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~38 ~442 ~169 ~48 minecraft:redstone_wire replace
fill ~450 ~169 ~38 ~450 ~169 ~48 minecraft:redstone_wire replace
fill ~456 ~169 ~38 ~456 ~169 ~48 minecraft:redstone_wire replace
fill ~462 ~169 ~38 ~462 ~169 ~48 minecraft:redstone_wire replace
fill ~470 ~169 ~38 ~470 ~169 ~48 minecraft:redstone_wire replace
fill ~476 ~169 ~38 ~476 ~169 ~48 minecraft:redstone_wire replace
fill ~486 ~169 ~38 ~486 ~169 ~48 minecraft:redstone_wire replace
fill ~492 ~169 ~38 ~492 ~169 ~48 minecraft:redstone_wire replace
fill ~496 ~169 ~38 ~496 ~169 ~48 minecraft:redstone_wire replace
fill ~500 ~169 ~38 ~500 ~169 ~48 minecraft:redstone_wire replace
fill ~502 ~169 ~38 ~502 ~169 ~48 minecraft:redstone_wire replace
setblock ~446 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~42 ~446 ~169 ~52 minecraft:redstone_wire replace
fill ~452 ~169 ~42 ~452 ~169 ~52 minecraft:redstone_wire replace
fill ~454 ~169 ~42 ~454 ~169 ~52 minecraft:redstone_wire replace
fill ~464 ~169 ~42 ~464 ~169 ~52 minecraft:redstone_wire replace
fill ~466 ~169 ~42 ~466 ~169 ~52 minecraft:redstone_wire replace
fill ~468 ~169 ~42 ~468 ~169 ~52 minecraft:redstone_wire replace
fill ~478 ~169 ~42 ~478 ~169 ~52 minecraft:redstone_wire replace
fill ~480 ~169 ~42 ~480 ~169 ~52 minecraft:redstone_wire replace
fill ~488 ~169 ~42 ~488 ~169 ~52 minecraft:redstone_wire replace
fill ~490 ~169 ~42 ~490 ~169 ~52 minecraft:redstone_wire replace
fill ~498 ~169 ~42 ~498 ~169 ~52 minecraft:redstone_wire replace
setblock ~440 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~46 ~440 ~169 ~56 minecraft:redstone_wire replace
fill ~444 ~169 ~46 ~444 ~169 ~56 minecraft:redstone_wire replace
fill ~448 ~169 ~46 ~448 ~169 ~56 minecraft:redstone_wire replace
fill ~458 ~169 ~46 ~458 ~169 ~56 minecraft:redstone_wire replace
fill ~460 ~169 ~46 ~460 ~169 ~56 minecraft:redstone_wire replace
fill ~472 ~169 ~46 ~472 ~169 ~56 minecraft:redstone_wire replace
fill ~474 ~169 ~46 ~474 ~169 ~56 minecraft:redstone_wire replace
fill ~482 ~169 ~46 ~482 ~169 ~56 minecraft:redstone_wire replace
fill ~484 ~169 ~46 ~484 ~169 ~56 minecraft:redstone_wire replace
fill ~494 ~169 ~46 ~494 ~169 ~56 minecraft:redstone_wire replace
setblock ~442 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~50 ~442 ~169 ~60 minecraft:redstone_wire replace
fill ~450 ~169 ~50 ~450 ~169 ~60 minecraft:redstone_wire replace
fill ~456 ~169 ~50 ~456 ~169 ~60 minecraft:redstone_wire replace
fill ~462 ~169 ~50 ~462 ~169 ~60 minecraft:redstone_wire replace
fill ~470 ~169 ~50 ~470 ~169 ~60 minecraft:redstone_wire replace
fill ~476 ~169 ~50 ~476 ~169 ~60 minecraft:redstone_wire replace
fill ~486 ~169 ~50 ~486 ~169 ~60 minecraft:redstone_wire replace
fill ~492 ~169 ~50 ~492 ~169 ~60 minecraft:redstone_wire replace
fill ~496 ~169 ~50 ~496 ~169 ~60 minecraft:redstone_wire replace
fill ~500 ~169 ~50 ~500 ~169 ~60 minecraft:redstone_wire replace
fill ~502 ~169 ~50 ~502 ~169 ~60 minecraft:redstone_wire replace
setblock ~446 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~54 ~446 ~169 ~64 minecraft:redstone_wire replace
fill ~452 ~169 ~54 ~452 ~169 ~64 minecraft:redstone_wire replace
fill ~454 ~169 ~54 ~454 ~169 ~64 minecraft:redstone_wire replace
fill ~464 ~169 ~54 ~464 ~169 ~64 minecraft:redstone_wire replace
fill ~466 ~169 ~54 ~466 ~169 ~64 minecraft:redstone_wire replace
fill ~468 ~169 ~54 ~468 ~169 ~64 minecraft:redstone_wire replace
fill ~478 ~169 ~54 ~478 ~169 ~64 minecraft:redstone_wire replace
fill ~480 ~169 ~54 ~480 ~169 ~64 minecraft:redstone_wire replace
fill ~488 ~169 ~54 ~488 ~169 ~64 minecraft:redstone_wire replace
fill ~490 ~169 ~54 ~490 ~169 ~64 minecraft:redstone_wire replace
fill ~498 ~169 ~54 ~498 ~169 ~64 minecraft:redstone_wire replace
setblock ~440 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~58 ~440 ~169 ~68 minecraft:redstone_wire replace
fill ~444 ~169 ~58 ~444 ~169 ~68 minecraft:redstone_wire replace
fill ~448 ~169 ~58 ~448 ~169 ~68 minecraft:redstone_wire replace
fill ~458 ~169 ~58 ~458 ~169 ~68 minecraft:redstone_wire replace
fill ~460 ~169 ~58 ~460 ~169 ~68 minecraft:redstone_wire replace
fill ~472 ~169 ~58 ~472 ~169 ~68 minecraft:redstone_wire replace
fill ~474 ~169 ~58 ~474 ~169 ~68 minecraft:redstone_wire replace
fill ~482 ~169 ~58 ~482 ~169 ~68 minecraft:redstone_wire replace
fill ~484 ~169 ~58 ~484 ~169 ~68 minecraft:redstone_wire replace
fill ~494 ~169 ~58 ~494 ~169 ~68 minecraft:redstone_wire replace
setblock ~442 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~62 ~442 ~169 ~72 minecraft:redstone_wire replace
fill ~450 ~169 ~62 ~450 ~169 ~72 minecraft:redstone_wire replace
fill ~456 ~169 ~62 ~456 ~169 ~72 minecraft:redstone_wire replace
fill ~462 ~169 ~62 ~462 ~169 ~72 minecraft:redstone_wire replace
fill ~470 ~169 ~62 ~470 ~169 ~72 minecraft:redstone_wire replace
fill ~476 ~169 ~62 ~476 ~169 ~72 minecraft:redstone_wire replace
fill ~486 ~169 ~62 ~486 ~169 ~72 minecraft:redstone_wire replace
fill ~492 ~169 ~62 ~492 ~169 ~72 minecraft:redstone_wire replace
fill ~496 ~169 ~62 ~496 ~169 ~72 minecraft:redstone_wire replace
fill ~500 ~169 ~62 ~500 ~169 ~72 minecraft:redstone_wire replace
fill ~502 ~169 ~62 ~502 ~169 ~72 minecraft:redstone_wire replace
setblock ~446 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~66 ~446 ~169 ~76 minecraft:redstone_wire replace
fill ~452 ~169 ~66 ~452 ~169 ~76 minecraft:redstone_wire replace
fill ~454 ~169 ~66 ~454 ~169 ~76 minecraft:redstone_wire replace
fill ~464 ~169 ~66 ~464 ~169 ~76 minecraft:redstone_wire replace
