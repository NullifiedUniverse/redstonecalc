fill ~141 ~126 ~560 ~141 ~126 ~628 minecraft:light_gray_concrete replace
fill ~138 ~126 ~564 ~138 ~126 ~612 minecraft:light_gray_concrete replace
fill ~135 ~126 ~568 ~135 ~126 ~628 minecraft:light_gray_concrete replace
fill ~132 ~126 ~572 ~132 ~126 ~628 minecraft:light_gray_concrete replace
fill ~129 ~126 ~576 ~129 ~126 ~612 minecraft:light_gray_concrete replace
fill ~162 ~126 ~600 ~162 ~126 ~628 minecraft:light_gray_concrete replace
fill ~150 ~126 ~604 ~150 ~126 ~628 minecraft:light_gray_concrete replace
fill ~156 ~126 ~608 ~156 ~126 ~612 minecraft:light_gray_concrete replace
fill ~153 ~126 ~620 ~153 ~126 ~624 minecraft:light_gray_concrete replace
fill ~171 ~126 ~644 ~171 ~126 ~648 minecraft:light_gray_concrete replace
fill ~84 ~126 ~648 ~84 ~126 ~652 minecraft:light_gray_concrete replace
fill ~165 ~126 ~652 ~165 ~126 ~656 minecraft:light_gray_concrete replace
fill ~168 ~126 ~660 ~168 ~126 ~664 minecraft:light_gray_concrete replace
setblock ~117 ~127 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~127 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~471 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~473 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~475 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~475 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~477 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~479 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~479 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~481 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~483 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~483 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~487 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~489 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~489 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~493 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~493 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~493 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~495 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~495 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~497 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~497 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~499 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~499 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~501 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~501 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~503 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~503 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~503 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~505 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~511 minecraft:light_gray_concrete replace
setblock ~97 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~103 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~517 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~517 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~517 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~519 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~519 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~519 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~521 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~521 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~525 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~525 minecraft:light_gray_concrete replace
setblock ~126 ~127 ~531 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~533 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~533 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~533 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~114 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~537 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~537 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~539 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~539 minecraft:light_gray_concrete replace
setblock ~100 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~115 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~127 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~123 ~127 ~543 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~547 minecraft:light_gray_concrete replace
setblock ~94 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~549 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~551 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~551 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~114 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~126 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~114 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~126 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~557 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~559 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~563 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~100 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~106 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~127 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~569 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~571 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~573 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~575 minecraft:light_gray_concrete replace
setblock ~133 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~139 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~160 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~601 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~603 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~605 minecraft:light_gray_concrete replace
setblock ~156 ~127 ~607 minecraft:light_gray_concrete replace
setblock ~136 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~148 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~163 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~130 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~145 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~157 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~153 ~127 ~619 minecraft:light_gray_concrete replace
setblock ~154 ~127 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~148 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~160 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~163 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~171 ~127 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~127 ~647 minecraft:light_gray_concrete replace
setblock ~165 ~127 ~651 minecraft:light_gray_concrete replace
setblock ~168 ~127 ~659 minecraft:light_gray_concrete replace
fill ~103 ~128 ~380 ~103 ~128 ~381 minecraft:light_gray_concrete replace
fill ~102 ~128 ~382 ~117 ~128 ~382 minecraft:light_gray_concrete replace
fill ~82 ~128 ~392 ~82 ~128 ~393 minecraft:light_gray_concrete replace
fill ~81 ~128 ~394 ~83 ~128 ~394 minecraft:light_gray_concrete replace
fill ~88 ~128 ~468 ~88 ~128 ~469 minecraft:light_gray_concrete replace
fill ~87 ~128 ~470 ~89 ~128 ~470 minecraft:light_gray_concrete replace
fill ~79 ~128 ~472 ~79 ~128 ~473 minecraft:light_gray_concrete replace
fill ~78 ~128 ~474 ~80 ~128 ~474 minecraft:light_gray_concrete replace
fill ~91 ~128 ~476 ~91 ~128 ~477 minecraft:light_gray_concrete replace
fill ~90 ~128 ~478 ~92 ~128 ~478 minecraft:light_gray_concrete replace
fill ~106 ~128 ~480 ~106 ~128 ~481 minecraft:light_gray_concrete replace
fill ~105 ~128 ~482 ~120 ~128 ~482 minecraft:light_gray_concrete replace
fill ~100 ~128 ~484 ~100 ~128 ~485 minecraft:light_gray_concrete replace
fill ~99 ~128 ~486 ~111 ~128 ~486 minecraft:light_gray_concrete replace
fill ~100 ~128 ~488 ~100 ~128 ~489 minecraft:light_gray_concrete replace
fill ~99 ~128 ~490 ~108 ~128 ~490 minecraft:light_gray_concrete replace
fill ~97 ~128 ~492 ~97 ~128 ~493 minecraft:light_gray_concrete replace
fill ~96 ~128 ~494 ~105 ~128 ~494 minecraft:light_gray_concrete replace
fill ~97 ~128 ~496 ~97 ~128 ~497 minecraft:light_gray_concrete replace
fill ~96 ~128 ~498 ~102 ~128 ~498 minecraft:light_gray_concrete replace
fill ~94 ~128 ~500 ~94 ~128 ~501 minecraft:light_gray_concrete replace
fill ~93 ~128 ~502 ~99 ~128 ~502 minecraft:light_gray_concrete replace
fill ~94 ~128 ~504 ~94 ~128 ~505 minecraft:light_gray_concrete replace
fill ~93 ~128 ~506 ~96 ~128 ~506 minecraft:light_gray_concrete replace
fill ~94 ~128 ~508 ~94 ~128 ~509 minecraft:light_gray_concrete replace
fill ~93 ~128 ~510 ~95 ~128 ~510 minecraft:light_gray_concrete replace
fill ~106 ~128 ~528 ~106 ~128 ~529 minecraft:light_gray_concrete replace
fill ~105 ~128 ~530 ~126 ~128 ~530 minecraft:light_gray_concrete replace
fill ~100 ~128 ~532 ~100 ~128 ~533 minecraft:light_gray_concrete replace
fill ~99 ~128 ~534 ~114 ~128 ~534 minecraft:light_gray_concrete replace
fill ~106 ~128 ~540 ~106 ~128 ~541 minecraft:light_gray_concrete replace
fill ~105 ~128 ~542 ~123 ~128 ~542 minecraft:light_gray_concrete replace
fill ~121 ~128 ~544 ~121 ~128 ~545 minecraft:light_gray_concrete replace
fill ~120 ~128 ~546 ~159 ~128 ~546 minecraft:light_gray_concrete replace
fill ~115 ~128 ~548 ~115 ~128 ~549 minecraft:light_gray_concrete replace
fill ~114 ~128 ~550 ~147 ~128 ~550 minecraft:light_gray_concrete replace
fill ~115 ~128 ~552 ~115 ~128 ~553 minecraft:light_gray_concrete replace
fill ~114 ~128 ~554 ~144 ~128 ~554 minecraft:light_gray_concrete replace
fill ~112 ~128 ~556 ~112 ~128 ~557 minecraft:light_gray_concrete replace
fill ~111 ~128 ~558 ~141 ~128 ~558 minecraft:light_gray_concrete replace
fill ~112 ~128 ~560 ~112 ~128 ~561 minecraft:light_gray_concrete replace
fill ~111 ~128 ~562 ~138 ~128 ~562 minecraft:light_gray_concrete replace
fill ~109 ~128 ~564 ~109 ~128 ~565 minecraft:light_gray_concrete replace
fill ~108 ~128 ~566 ~135 ~128 ~566 minecraft:light_gray_concrete replace
fill ~109 ~128 ~568 ~109 ~128 ~569 minecraft:light_gray_concrete replace
fill ~108 ~128 ~570 ~132 ~128 ~570 minecraft:light_gray_concrete replace
fill ~109 ~128 ~572 ~109 ~128 ~573 minecraft:light_gray_concrete replace
fill ~108 ~128 ~574 ~129 ~128 ~574 minecraft:light_gray_concrete replace
fill ~121 ~128 ~596 ~121 ~128 ~597 minecraft:light_gray_concrete replace
fill ~120 ~128 ~598 ~162 ~128 ~598 minecraft:light_gray_concrete replace
fill ~115 ~128 ~600 ~115 ~128 ~601 minecraft:light_gray_concrete replace
fill ~114 ~128 ~602 ~150 ~128 ~602 minecraft:light_gray_concrete replace
fill ~121 ~128 ~604 ~121 ~128 ~605 minecraft:light_gray_concrete replace
fill ~120 ~128 ~606 ~156 ~128 ~606 minecraft:light_gray_concrete replace
fill ~118 ~128 ~616 ~118 ~128 ~617 minecraft:light_gray_concrete replace
fill ~117 ~128 ~618 ~153 ~128 ~618 minecraft:light_gray_concrete replace
fill ~130 ~128 ~640 ~130 ~128 ~641 minecraft:light_gray_concrete replace
fill ~129 ~128 ~642 ~171 ~128 ~642 minecraft:light_gray_concrete replace
fill ~85 ~128 ~644 ~85 ~128 ~645 minecraft:light_gray_concrete replace
fill ~84 ~128 ~646 ~86 ~128 ~646 minecraft:light_gray_concrete replace
fill ~124 ~128 ~648 ~124 ~128 ~649 minecraft:light_gray_concrete replace
fill ~123 ~128 ~650 ~165 ~128 ~650 minecraft:light_gray_concrete replace
fill ~127 ~128 ~656 ~127 ~128 ~657 minecraft:light_gray_concrete replace
fill ~126 ~128 ~658 ~168 ~128 ~658 minecraft:light_gray_concrete replace
setblock ~103 ~129 ~380 minecraft:light_gray_concrete replace
setblock ~108 ~129 ~382 minecraft:light_gray_concrete replace
setblock ~110 ~129 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~129 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~129 ~468 minecraft:light_gray_concrete replace
setblock ~79 ~129 ~472 minecraft:light_gray_concrete replace
setblock ~91 ~129 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~129 ~480 minecraft:light_gray_concrete replace
setblock ~110 ~129 ~482 minecraft:light_gray_concrete replace
setblock ~112 ~129 ~482 minecraft:light_gray_concrete replace
setblock ~100 ~129 ~484 minecraft:light_gray_concrete replace
setblock ~100 ~129 ~488 minecraft:light_gray_concrete replace
setblock ~97 ~129 ~492 minecraft:light_gray_concrete replace
setblock ~97 ~129 ~496 minecraft:light_gray_concrete replace
setblock ~94 ~129 ~500 minecraft:light_gray_concrete replace
setblock ~94 ~129 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~129 ~508 minecraft:light_gray_concrete replace
setblock ~106 ~129 ~528 minecraft:light_gray_concrete replace
setblock ~118 ~129 ~530 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~530 minecraft:light_gray_concrete replace
setblock ~100 ~129 ~532 minecraft:light_gray_concrete replace
setblock ~102 ~129 ~534 minecraft:light_gray_concrete replace
setblock ~104 ~129 ~534 minecraft:light_gray_concrete replace
setblock ~106 ~129 ~540 minecraft:light_gray_concrete replace
setblock ~114 ~129 ~542 minecraft:light_gray_concrete replace
setblock ~116 ~129 ~542 minecraft:light_gray_concrete replace
setblock ~121 ~129 ~544 minecraft:light_gray_concrete replace
setblock ~128 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~145 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~115 ~129 ~548 minecraft:light_gray_concrete replace
setblock ~132 ~129 ~550 minecraft:light_gray_concrete replace
setblock ~134 ~129 ~550 minecraft:light_gray_concrete replace
setblock ~115 ~129 ~552 minecraft:light_gray_concrete replace
setblock ~129 ~129 ~554 minecraft:light_gray_concrete replace
setblock ~131 ~129 ~554 minecraft:light_gray_concrete replace
setblock ~112 ~129 ~556 minecraft:light_gray_concrete replace
setblock ~114 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~116 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~131 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~133 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~112 ~129 ~560 minecraft:light_gray_concrete replace
setblock ~124 ~129 ~562 minecraft:light_gray_concrete replace
setblock ~126 ~129 ~562 minecraft:light_gray_concrete replace
setblock ~109 ~129 ~564 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~566 minecraft:light_gray_concrete replace
setblock ~122 ~129 ~566 minecraft:light_gray_concrete replace
setblock ~109 ~129 ~568 minecraft:light_gray_concrete replace
setblock ~117 ~129 ~570 minecraft:light_gray_concrete replace
setblock ~119 ~129 ~570 minecraft:light_gray_concrete replace
setblock ~109 ~129 ~572 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~574 minecraft:light_gray_concrete replace
setblock ~122 ~129 ~574 minecraft:light_gray_concrete replace
setblock ~121 ~129 ~596 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~132 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~149 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~115 ~129 ~600 minecraft:light_gray_concrete replace
setblock ~118 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~135 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~137 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~121 ~129 ~604 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~132 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~149 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~118 ~129 ~616 minecraft:light_gray_concrete replace
setblock ~127 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~129 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~144 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~146 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~640 minecraft:light_gray_concrete replace
setblock ~131 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~133 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~149 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~163 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~165 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~129 ~644 minecraft:light_gray_concrete replace
setblock ~124 ~129 ~648 minecraft:light_gray_concrete replace
setblock ~125 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~141 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~143 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~157 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~159 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~129 ~656 minecraft:light_gray_concrete replace
setblock ~128 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~144 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~146 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~160 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~162 ~129 ~658 minecraft:light_gray_concrete replace
fill ~102 ~130 ~380 ~102 ~130 ~384 minecraft:light_gray_concrete replace
fill ~81 ~130 ~392 ~81 ~130 ~396 minecraft:light_gray_concrete replace
fill ~87 ~130 ~468 ~87 ~130 ~472 minecraft:light_gray_concrete replace
fill ~78 ~130 ~472 ~78 ~130 ~476 minecraft:light_gray_concrete replace
fill ~90 ~130 ~476 ~90 ~130 ~480 minecraft:light_gray_concrete replace
fill ~105 ~130 ~480 ~105 ~130 ~544 minecraft:light_gray_concrete replace
fill ~99 ~130 ~484 ~99 ~130 ~536 minecraft:light_gray_concrete replace
fill ~96 ~130 ~492 ~96 ~130 ~500 minecraft:light_gray_concrete replace
fill ~93 ~130 ~500 ~93 ~130 ~512 minecraft:light_gray_concrete replace
fill ~120 ~130 ~544 ~120 ~130 ~608 minecraft:light_gray_concrete replace
fill ~114 ~130 ~548 ~114 ~130 ~604 minecraft:light_gray_concrete replace
fill ~111 ~130 ~556 ~111 ~130 ~564 minecraft:light_gray_concrete replace
fill ~108 ~130 ~564 ~108 ~130 ~576 minecraft:light_gray_concrete replace
fill ~117 ~130 ~616 ~117 ~130 ~620 minecraft:light_gray_concrete replace
fill ~129 ~130 ~640 ~129 ~130 ~644 minecraft:light_gray_concrete replace
fill ~84 ~130 ~644 ~84 ~130 ~648 minecraft:light_gray_concrete replace
fill ~123 ~130 ~648 ~123 ~130 ~652 minecraft:light_gray_concrete replace
fill ~126 ~130 ~656 ~126 ~130 ~660 minecraft:light_gray_concrete replace
setblock ~102 ~131 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~131 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~131 ~473 minecraft:light_gray_concrete replace
setblock ~78 ~131 ~477 minecraft:light_gray_concrete replace
setblock ~106 ~131 ~480 minecraft:light_gray_concrete replace
setblock ~90 ~131 ~481 minecraft:light_gray_concrete replace
setblock ~100 ~131 ~484 minecraft:light_gray_concrete replace
setblock ~100 ~131 ~488 minecraft:light_gray_concrete replace
setblock ~97 ~131 ~492 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~493 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~495 minecraft:light_gray_concrete replace
setblock ~97 ~131 ~496 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~497 minecraft:light_gray_concrete replace
setblock ~96 ~131 ~499 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~499 minecraft:light_gray_concrete replace
setblock ~94 ~131 ~500 minecraft:light_gray_concrete replace
setblock ~96 ~131 ~501 minecraft:light_gray_concrete replace
setblock ~94 ~131 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~131 ~508 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~509 minecraft:light_gray_concrete replace
setblock ~93 ~131 ~511 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~511 minecraft:light_gray_concrete replace
setblock ~93 ~131 ~513 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~513 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~515 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~525 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~527 minecraft:light_gray_concrete replace
setblock ~106 ~131 ~528 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~529 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~531 minecraft:light_gray_concrete replace
setblock ~100 ~131 ~532 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~537 minecraft:light_gray_concrete replace
setblock ~106 ~131 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~131 ~544 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~545 minecraft:light_gray_concrete replace
setblock ~115 ~131 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~131 ~552 minecraft:light_gray_concrete replace
setblock ~112 ~131 ~556 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~557 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~559 minecraft:light_gray_concrete replace
setblock ~112 ~131 ~560 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~561 minecraft:light_gray_concrete replace
setblock ~111 ~131 ~563 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~563 minecraft:light_gray_concrete replace
setblock ~109 ~131 ~564 minecraft:light_gray_concrete replace
setblock ~111 ~131 ~565 minecraft:light_gray_concrete replace
setblock ~109 ~131 ~568 minecraft:light_gray_concrete replace
setblock ~109 ~131 ~572 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~573 minecraft:light_gray_concrete replace
setblock ~108 ~131 ~575 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~575 minecraft:light_gray_concrete replace
setblock ~108 ~131 ~577 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~577 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~579 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~589 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~591 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~593 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~595 minecraft:light_gray_concrete replace
setblock ~121 ~131 ~596 minecraft:light_gray_concrete replace
setblock ~115 ~131 ~600 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~603 minecraft:light_gray_concrete replace
setblock ~121 ~131 ~604 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~605 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~609 minecraft:light_gray_concrete replace
setblock ~118 ~131 ~616 minecraft:light_gray_concrete replace
setblock ~117 ~131 ~621 minecraft:light_gray_concrete replace
setblock ~129 ~131 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~131 ~649 minecraft:light_gray_concrete replace
setblock ~123 ~131 ~653 minecraft:light_gray_concrete replace
setblock ~126 ~131 ~661 minecraft:light_gray_concrete replace
fill ~102 ~132 ~386 ~116 ~132 ~386 minecraft:light_gray_concrete replace
fill ~115 ~132 ~387 ~115 ~132 ~388 minecraft:light_gray_concrete replace
fill ~81 ~132 ~398 ~83 ~132 ~398 minecraft:light_gray_concrete replace
fill ~82 ~132 ~399 ~82 ~132 ~400 minecraft:light_gray_concrete replace
fill ~87 ~132 ~474 ~89 ~132 ~474 minecraft:light_gray_concrete replace
fill ~88 ~132 ~475 ~88 ~132 ~476 minecraft:light_gray_concrete replace
fill ~78 ~132 ~478 ~80 ~132 ~478 minecraft:light_gray_concrete replace
fill ~79 ~132 ~479 ~79 ~132 ~480 minecraft:light_gray_concrete replace
fill ~90 ~132 ~482 ~119 ~132 ~482 minecraft:light_gray_concrete replace
fill ~91 ~132 ~483 ~91 ~132 ~484 minecraft:light_gray_concrete replace
fill ~94 ~132 ~483 ~94 ~132 ~484 minecraft:light_gray_concrete replace
fill ~97 ~132 ~483 ~97 ~132 ~484 minecraft:light_gray_concrete replace
fill ~100 ~132 ~483 ~100 ~132 ~484 minecraft:light_gray_concrete replace
fill ~103 ~132 ~483 ~103 ~132 ~484 minecraft:light_gray_concrete replace
fill ~106 ~132 ~483 ~106 ~132 ~484 minecraft:light_gray_concrete replace
fill ~109 ~132 ~483 ~109 ~132 ~484 minecraft:light_gray_concrete replace
fill ~118 ~132 ~483 ~118 ~132 ~484 minecraft:light_gray_concrete replace
fill ~90 ~132 ~502 ~125 ~132 ~502 minecraft:light_gray_concrete replace
fill ~91 ~132 ~503 ~91 ~132 ~504 minecraft:light_gray_concrete replace
fill ~97 ~132 ~503 ~97 ~132 ~504 minecraft:light_gray_concrete replace
fill ~103 ~132 ~503 ~103 ~132 ~504 minecraft:light_gray_concrete replace
fill ~106 ~132 ~503 ~106 ~132 ~504 minecraft:light_gray_concrete replace
fill ~112 ~132 ~503 ~112 ~132 ~504 minecraft:light_gray_concrete replace
fill ~124 ~132 ~503 ~124 ~132 ~504 minecraft:light_gray_concrete replace
fill ~90 ~132 ~514 ~122 ~132 ~514 minecraft:light_gray_concrete replace
fill ~91 ~132 ~515 ~91 ~132 ~516 minecraft:light_gray_concrete replace
fill ~94 ~132 ~515 ~94 ~132 ~516 minecraft:light_gray_concrete replace
fill ~97 ~132 ~515 ~97 ~132 ~516 minecraft:light_gray_concrete replace
fill ~100 ~132 ~515 ~100 ~132 ~516 minecraft:light_gray_concrete replace
fill ~109 ~132 ~515 ~109 ~132 ~516 minecraft:light_gray_concrete replace
fill ~112 ~132 ~515 ~112 ~132 ~516 minecraft:light_gray_concrete replace
fill ~121 ~132 ~515 ~121 ~132 ~516 minecraft:light_gray_concrete replace
fill ~93 ~132 ~538 ~122 ~132 ~538 minecraft:light_gray_concrete replace
fill ~94 ~132 ~539 ~94 ~132 ~540 minecraft:light_gray_concrete replace
fill ~100 ~132 ~539 ~100 ~132 ~540 minecraft:light_gray_concrete replace
fill ~103 ~132 ~539 ~103 ~132 ~540 minecraft:light_gray_concrete replace
fill ~109 ~132 ~539 ~109 ~132 ~540 minecraft:light_gray_concrete replace
fill ~112 ~132 ~539 ~112 ~132 ~540 minecraft:light_gray_concrete replace
fill ~118 ~132 ~539 ~118 ~132 ~540 minecraft:light_gray_concrete replace
fill ~121 ~132 ~539 ~121 ~132 ~540 minecraft:light_gray_concrete replace
fill ~105 ~132 ~546 ~152 ~132 ~546 minecraft:light_gray_concrete replace
fill ~127 ~132 ~547 ~127 ~132 ~548 minecraft:light_gray_concrete replace
fill ~130 ~132 ~547 ~130 ~132 ~548 minecraft:light_gray_concrete replace
fill ~133 ~132 ~547 ~133 ~132 ~548 minecraft:light_gray_concrete replace
fill ~136 ~132 ~547 ~136 ~132 ~548 minecraft:light_gray_concrete replace
fill ~139 ~132 ~547 ~139 ~132 ~548 minecraft:light_gray_concrete replace
fill ~142 ~132 ~547 ~142 ~132 ~548 minecraft:light_gray_concrete replace
fill ~145 ~132 ~547 ~145 ~132 ~548 minecraft:light_gray_concrete replace
fill ~151 ~132 ~547 ~151 ~132 ~548 minecraft:light_gray_concrete replace
fill ~111 ~132 ~566 ~155 ~132 ~566 minecraft:light_gray_concrete replace
fill ~127 ~132 ~567 ~127 ~132 ~568 minecraft:light_gray_concrete replace
fill ~133 ~132 ~567 ~133 ~132 ~568 minecraft:light_gray_concrete replace
fill ~139 ~132 ~567 ~139 ~132 ~568 minecraft:light_gray_concrete replace
fill ~142 ~132 ~567 ~142 ~132 ~568 minecraft:light_gray_concrete replace
fill ~148 ~132 ~567 ~148 ~132 ~568 minecraft:light_gray_concrete replace
fill ~154 ~132 ~567 ~154 ~132 ~568 minecraft:light_gray_concrete replace
fill ~108 ~132 ~578 ~158 ~132 ~578 minecraft:light_gray_concrete replace
fill ~127 ~132 ~579 ~127 ~132 ~580 minecraft:light_gray_concrete replace
fill ~130 ~132 ~579 ~130 ~132 ~580 minecraft:light_gray_concrete replace
fill ~133 ~132 ~579 ~133 ~132 ~580 minecraft:light_gray_concrete replace
fill ~136 ~132 ~579 ~136 ~132 ~580 minecraft:light_gray_concrete replace
fill ~145 ~132 ~579 ~145 ~132 ~580 minecraft:light_gray_concrete replace
fill ~148 ~132 ~579 ~148 ~132 ~580 minecraft:light_gray_concrete replace
fill ~157 ~132 ~579 ~157 ~132 ~580 minecraft:light_gray_concrete replace
fill ~114 ~132 ~606 ~158 ~132 ~606 minecraft:light_gray_concrete replace
fill ~130 ~132 ~607 ~130 ~132 ~608 minecraft:light_gray_concrete replace
fill ~136 ~132 ~607 ~136 ~132 ~608 minecraft:light_gray_concrete replace
fill ~139 ~132 ~607 ~139 ~132 ~608 minecraft:light_gray_concrete replace
fill ~145 ~132 ~607 ~145 ~132 ~608 minecraft:light_gray_concrete replace
fill ~148 ~132 ~607 ~148 ~132 ~608 minecraft:light_gray_concrete replace
fill ~151 ~132 ~607 ~151 ~132 ~608 minecraft:light_gray_concrete replace
fill ~157 ~132 ~607 ~157 ~132 ~608 minecraft:light_gray_concrete replace
fill ~120 ~132 ~610 ~164 ~132 ~610 minecraft:light_gray_concrete replace
fill ~163 ~132 ~611 ~163 ~132 ~612 minecraft:light_gray_concrete replace
fill ~117 ~132 ~622 ~161 ~132 ~622 minecraft:light_gray_concrete replace
fill ~160 ~132 ~623 ~160 ~132 ~624 minecraft:light_gray_concrete replace
fill ~129 ~132 ~646 ~173 ~132 ~646 minecraft:light_gray_concrete replace
fill ~172 ~132 ~647 ~172 ~132 ~648 minecraft:light_gray_concrete replace
fill ~84 ~132 ~650 ~86 ~132 ~650 minecraft:light_gray_concrete replace
fill ~85 ~132 ~651 ~85 ~132 ~652 minecraft:light_gray_concrete replace
fill ~123 ~132 ~654 ~167 ~132 ~654 minecraft:light_gray_concrete replace
fill ~166 ~132 ~655 ~166 ~132 ~656 minecraft:light_gray_concrete replace
fill ~126 ~132 ~662 ~170 ~132 ~662 minecraft:light_gray_concrete replace
fill ~169 ~132 ~663 ~169 ~132 ~664 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~386 minecraft:light_gray_concrete replace
setblock ~111 ~133 ~386 minecraft:light_gray_concrete replace
setblock ~115 ~133 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~133 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~133 ~476 minecraft:light_gray_concrete replace
setblock ~79 ~133 ~480 minecraft:light_gray_concrete replace
setblock ~91 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~94 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~97 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~100 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~502 minecraft:light_gray_concrete replace
setblock ~111 ~133 ~502 minecraft:light_gray_concrete replace
setblock ~91 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~97 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~103 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~112 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~124 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~514 minecraft:light_gray_concrete replace
setblock ~108 ~133 ~514 minecraft:light_gray_concrete replace
setblock ~91 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~94 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~97 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~100 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~538 minecraft:light_gray_concrete replace
setblock ~108 ~133 ~538 minecraft:light_gray_concrete replace
setblock ~94 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~100 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~103 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~115 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~117 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~147 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~149 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~142 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~145 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~133 ~566 minecraft:light_gray_concrete replace
