setblock ~193 ~33 ~394 minecraft:light_gray_concrete replace
setblock ~195 ~33 ~394 minecraft:light_gray_concrete replace
setblock ~238 ~33 ~396 minecraft:light_gray_concrete replace
setblock ~217 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~219 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~234 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~236 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~277 ~33 ~400 minecraft:light_gray_concrete replace
setblock ~247 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~249 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~264 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~266 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~307 ~33 ~404 minecraft:light_gray_concrete replace
setblock ~265 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~267 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~282 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~284 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~299 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~301 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~370 ~33 ~408 minecraft:light_gray_concrete replace
setblock ~310 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~312 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~327 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~329 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~344 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~346 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~363 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~394 ~33 ~412 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~330 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~345 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~347 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~362 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~364 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~379 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~381 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~85 ~33 ~416 minecraft:light_gray_concrete replace
setblock ~109 ~33 ~420 minecraft:light_gray_concrete replace
setblock ~133 ~33 ~424 minecraft:light_gray_concrete replace
setblock ~130 ~33 ~426 minecraft:light_gray_concrete replace
setblock ~132 ~33 ~426 minecraft:light_gray_concrete replace
setblock ~166 ~33 ~428 minecraft:light_gray_concrete replace
setblock ~205 ~33 ~432 minecraft:light_gray_concrete replace
setblock ~190 ~33 ~434 minecraft:light_gray_concrete replace
setblock ~192 ~33 ~434 minecraft:light_gray_concrete replace
setblock ~235 ~33 ~436 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~216 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~233 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~274 ~33 ~440 minecraft:light_gray_concrete replace
setblock ~238 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~240 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~255 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~257 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~298 ~33 ~444 minecraft:light_gray_concrete replace
setblock ~262 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~264 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~279 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~281 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~448 minecraft:light_gray_concrete replace
setblock ~307 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~324 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~360 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~391 ~33 ~452 minecraft:light_gray_concrete replace
setblock ~325 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~327 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~342 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~344 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~359 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~376 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~378 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~82 ~33 ~456 minecraft:light_gray_concrete replace
setblock ~106 ~33 ~460 minecraft:light_gray_concrete replace
setblock ~130 ~33 ~464 minecraft:light_gray_concrete replace
setblock ~127 ~33 ~466 minecraft:light_gray_concrete replace
setblock ~129 ~33 ~466 minecraft:light_gray_concrete replace
setblock ~160 ~33 ~468 minecraft:light_gray_concrete replace
setblock ~154 ~33 ~470 minecraft:light_gray_concrete replace
setblock ~156 ~33 ~470 minecraft:light_gray_concrete replace
setblock ~199 ~33 ~472 minecraft:light_gray_concrete replace
setblock ~187 ~33 ~474 minecraft:light_gray_concrete replace
setblock ~189 ~33 ~474 minecraft:light_gray_concrete replace
setblock ~232 ~33 ~476 minecraft:light_gray_concrete replace
setblock ~211 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~213 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~228 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~230 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~271 ~33 ~480 minecraft:light_gray_concrete replace
setblock ~235 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~237 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~252 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~254 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~484 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~258 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~273 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~275 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~364 ~33 ~488 minecraft:light_gray_concrete replace
setblock ~298 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~300 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~315 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~317 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~332 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~349 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~351 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~385 ~33 ~492 minecraft:light_gray_concrete replace
setblock ~322 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~324 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~339 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~356 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~373 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~375 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~79 ~33 ~496 minecraft:light_gray_concrete replace
setblock ~103 ~33 ~500 minecraft:light_gray_concrete replace
setblock ~127 ~33 ~504 minecraft:light_gray_concrete replace
setblock ~124 ~33 ~506 minecraft:light_gray_concrete replace
setblock ~126 ~33 ~506 minecraft:light_gray_concrete replace
setblock ~154 ~33 ~508 minecraft:light_gray_concrete replace
setblock ~148 ~33 ~510 minecraft:light_gray_concrete replace
setblock ~150 ~33 ~510 minecraft:light_gray_concrete replace
setblock ~193 ~33 ~512 minecraft:light_gray_concrete replace
setblock ~184 ~33 ~514 minecraft:light_gray_concrete replace
setblock ~186 ~33 ~514 minecraft:light_gray_concrete replace
setblock ~223 ~33 ~516 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~204 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~219 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~221 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~268 ~33 ~520 minecraft:light_gray_concrete replace
setblock ~232 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~234 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~249 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~251 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~289 ~33 ~524 minecraft:light_gray_concrete replace
setblock ~253 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~255 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~270 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~272 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~528 minecraft:light_gray_concrete replace
setblock ~295 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~297 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~312 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~314 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~329 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~346 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~348 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~382 ~33 ~532 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~321 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~336 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~338 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~353 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~355 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~370 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~372 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~100 ~33 ~536 minecraft:light_gray_concrete replace
setblock ~124 ~33 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~542 minecraft:light_gray_concrete replace
setblock ~123 ~33 ~542 minecraft:light_gray_concrete replace
setblock ~148 ~33 ~544 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~546 minecraft:light_gray_concrete replace
setblock ~147 ~33 ~546 minecraft:light_gray_concrete replace
setblock ~190 ~33 ~548 minecraft:light_gray_concrete replace
setblock ~175 ~33 ~550 minecraft:light_gray_concrete replace
setblock ~177 ~33 ~550 minecraft:light_gray_concrete replace
setblock ~220 ~33 ~552 minecraft:light_gray_concrete replace
setblock ~199 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~201 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~216 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~218 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~556 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~246 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~248 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~295 ~33 ~560 minecraft:light_gray_concrete replace
setblock ~259 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~261 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~276 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~278 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~313 ~33 ~564 minecraft:light_gray_concrete replace
setblock ~277 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~279 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~296 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~373 ~33 ~568 minecraft:light_gray_concrete replace
setblock ~313 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~315 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~330 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~332 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~347 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~349 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~364 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~366 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~163 ~33 ~572 minecraft:light_gray_concrete replace
setblock ~400 ~33 ~576 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~336 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~351 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~353 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~368 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~370 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~385 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~387 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~97 ~33 ~580 minecraft:light_gray_concrete replace
setblock ~376 ~33 ~584 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~318 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~333 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~335 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~350 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~352 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~369 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~397 ~33 ~588 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~333 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~348 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~350 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~365 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~382 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~384 ~33 ~590 minecraft:light_gray_concrete replace
fill ~93 ~34 ~8 ~93 ~34 ~260 minecraft:light_gray_concrete replace
fill ~120 ~34 ~8 ~120 ~34 ~264 minecraft:light_gray_concrete replace
fill ~150 ~34 ~8 ~150 ~34 ~268 minecraft:light_gray_concrete replace
fill ~177 ~34 ~8 ~177 ~34 ~12 minecraft:light_gray_concrete replace
fill ~117 ~34 ~16 ~117 ~34 ~280 minecraft:light_gray_concrete replace
fill ~141 ~34 ~16 ~141 ~34 ~284 minecraft:light_gray_concrete replace
fill ~171 ~34 ~16 ~171 ~34 ~288 minecraft:light_gray_concrete replace
fill ~210 ~34 ~16 ~210 ~34 ~20 minecraft:light_gray_concrete replace
fill ~144 ~34 ~24 ~144 ~34 ~296 minecraft:light_gray_concrete replace
fill ~168 ~34 ~24 ~168 ~34 ~300 minecraft:light_gray_concrete replace
fill ~201 ~34 ~24 ~201 ~34 ~304 minecraft:light_gray_concrete replace
fill ~252 ~34 ~24 ~252 ~34 ~28 minecraft:light_gray_concrete replace
fill ~174 ~34 ~32 ~174 ~34 ~312 minecraft:light_gray_concrete replace
fill ~240 ~34 ~32 ~240 ~34 ~316 minecraft:light_gray_concrete replace
fill ~258 ~34 ~32 ~258 ~34 ~320 minecraft:light_gray_concrete replace
fill ~195 ~34 ~40 ~195 ~34 ~324 minecraft:light_gray_concrete replace
fill ~225 ~34 ~40 ~225 ~34 ~328 minecraft:light_gray_concrete replace
fill ~246 ~34 ~40 ~246 ~34 ~332 minecraft:light_gray_concrete replace
fill ~300 ~34 ~40 ~300 ~34 ~44 minecraft:light_gray_concrete replace
fill ~228 ~34 ~48 ~228 ~34 ~340 minecraft:light_gray_concrete replace
fill ~261 ~34 ~48 ~261 ~34 ~344 minecraft:light_gray_concrete replace
fill ~282 ~34 ~48 ~282 ~34 ~348 minecraft:light_gray_concrete replace
fill ~330 ~34 ~48 ~330 ~34 ~52 minecraft:light_gray_concrete replace
fill ~264 ~34 ~56 ~264 ~34 ~356 minecraft:light_gray_concrete replace
fill ~315 ~34 ~56 ~315 ~34 ~360 minecraft:light_gray_concrete replace
fill ~321 ~34 ~56 ~321 ~34 ~60 minecraft:light_gray_concrete replace
fill ~339 ~34 ~56 ~339 ~34 ~368 minecraft:light_gray_concrete replace
fill ~318 ~34 ~60 ~318 ~34 ~372 minecraft:light_gray_concrete replace
fill ~336 ~34 ~60 ~336 ~34 ~376 minecraft:light_gray_concrete replace
fill ~342 ~34 ~60 ~342 ~34 ~380 minecraft:light_gray_concrete replace
fill ~285 ~34 ~72 ~285 ~34 ~384 minecraft:light_gray_concrete replace
fill ~327 ~34 ~72 ~327 ~34 ~388 minecraft:light_gray_concrete replace
fill ~351 ~34 ~72 ~351 ~34 ~76 minecraft:light_gray_concrete replace
fill ~387 ~34 ~72 ~387 ~34 ~396 minecraft:light_gray_concrete replace
fill ~354 ~34 ~76 ~354 ~34 ~400 minecraft:light_gray_concrete replace
fill ~360 ~34 ~76 ~360 ~34 ~404 minecraft:light_gray_concrete replace
fill ~378 ~34 ~76 ~378 ~34 ~408 minecraft:light_gray_concrete replace
fill ~180 ~34 ~256 ~180 ~34 ~272 minecraft:light_gray_concrete replace
fill ~156 ~34 ~264 ~156 ~34 ~276 minecraft:light_gray_concrete replace
fill ~213 ~34 ~268 ~213 ~34 ~292 minecraft:light_gray_concrete replace
fill ~255 ~34 ~276 ~255 ~34 ~308 minecraft:light_gray_concrete replace
fill ~303 ~34 ~292 ~303 ~34 ~336 minecraft:light_gray_concrete replace
fill ~333 ~34 ~300 ~333 ~34 ~352 minecraft:light_gray_concrete replace
fill ~324 ~34 ~308 ~324 ~34 ~364 minecraft:light_gray_concrete replace
fill ~348 ~34 ~324 ~348 ~34 ~392 minecraft:light_gray_concrete replace
fill ~90 ~34 ~340 ~90 ~34 ~412 minecraft:light_gray_concrete replace
fill ~114 ~34 ~344 ~114 ~34 ~416 minecraft:light_gray_concrete replace
fill ~138 ~34 ~348 ~138 ~34 ~420 minecraft:light_gray_concrete replace
fill ~186 ~34 ~352 ~186 ~34 ~424 minecraft:light_gray_concrete replace
fill ~216 ~34 ~356 ~216 ~34 ~428 minecraft:light_gray_concrete replace
fill ~243 ~34 ~360 ~243 ~34 ~432 minecraft:light_gray_concrete replace
fill ~279 ~34 ~364 ~279 ~34 ~436 minecraft:light_gray_concrete replace
fill ~309 ~34 ~368 ~309 ~34 ~440 minecraft:light_gray_concrete replace
fill ~345 ~34 ~372 ~345 ~34 ~444 minecraft:light_gray_concrete replace
fill ~87 ~34 ~376 ~87 ~34 ~448 minecraft:light_gray_concrete replace
fill ~111 ~34 ~380 ~111 ~34 ~452 minecraft:light_gray_concrete replace
fill ~135 ~34 ~384 ~135 ~34 ~456 minecraft:light_gray_concrete replace
fill ~183 ~34 ~388 ~183 ~34 ~460 minecraft:light_gray_concrete replace
fill ~207 ~34 ~392 ~207 ~34 ~464 minecraft:light_gray_concrete replace
fill ~237 ~34 ~396 ~237 ~34 ~468 minecraft:light_gray_concrete replace
fill ~276 ~34 ~400 ~276 ~34 ~472 minecraft:light_gray_concrete replace
fill ~306 ~34 ~404 ~306 ~34 ~476 minecraft:light_gray_concrete replace
fill ~369 ~34 ~408 ~369 ~34 ~480 minecraft:light_gray_concrete replace
fill ~393 ~34 ~412 ~393 ~34 ~484 minecraft:light_gray_concrete replace
fill ~84 ~34 ~416 ~84 ~34 ~488 minecraft:light_gray_concrete replace
fill ~108 ~34 ~420 ~108 ~34 ~492 minecraft:light_gray_concrete replace
fill ~132 ~34 ~424 ~132 ~34 ~496 minecraft:light_gray_concrete replace
fill ~165 ~34 ~428 ~165 ~34 ~500 minecraft:light_gray_concrete replace
fill ~204 ~34 ~432 ~204 ~34 ~504 minecraft:light_gray_concrete replace
fill ~234 ~34 ~436 ~234 ~34 ~508 minecraft:light_gray_concrete replace
fill ~273 ~34 ~440 ~273 ~34 ~512 minecraft:light_gray_concrete replace
fill ~297 ~34 ~444 ~297 ~34 ~516 minecraft:light_gray_concrete replace
fill ~366 ~34 ~448 ~366 ~34 ~520 minecraft:light_gray_concrete replace
fill ~390 ~34 ~452 ~390 ~34 ~524 minecraft:light_gray_concrete replace
fill ~81 ~34 ~456 ~81 ~34 ~528 minecraft:light_gray_concrete replace
fill ~105 ~34 ~460 ~105 ~34 ~532 minecraft:light_gray_concrete replace
fill ~129 ~34 ~464 ~129 ~34 ~536 minecraft:light_gray_concrete replace
fill ~159 ~34 ~468 ~159 ~34 ~540 minecraft:light_gray_concrete replace
fill ~198 ~34 ~472 ~198 ~34 ~544 minecraft:light_gray_concrete replace
fill ~231 ~34 ~476 ~231 ~34 ~548 minecraft:light_gray_concrete replace
fill ~270 ~34 ~480 ~270 ~34 ~552 minecraft:light_gray_concrete replace
fill ~291 ~34 ~484 ~291 ~34 ~556 minecraft:light_gray_concrete replace
fill ~363 ~34 ~488 ~363 ~34 ~560 minecraft:light_gray_concrete replace
fill ~384 ~34 ~492 ~384 ~34 ~564 minecraft:light_gray_concrete replace
fill ~78 ~34 ~496 ~78 ~34 ~568 minecraft:light_gray_concrete replace
fill ~102 ~34 ~500 ~102 ~34 ~572 minecraft:light_gray_concrete replace
fill ~126 ~34 ~504 ~126 ~34 ~576 minecraft:light_gray_concrete replace
fill ~153 ~34 ~508 ~153 ~34 ~580 minecraft:light_gray_concrete replace
fill ~192 ~34 ~512 ~192 ~34 ~584 minecraft:light_gray_concrete replace
fill ~222 ~34 ~516 ~222 ~34 ~588 minecraft:light_gray_concrete replace
fill ~267 ~34 ~520 ~267 ~34 ~592 minecraft:light_gray_concrete replace
fill ~288 ~34 ~524 ~288 ~34 ~596 minecraft:light_gray_concrete replace
fill ~357 ~34 ~528 ~357 ~34 ~600 minecraft:light_gray_concrete replace
fill ~381 ~34 ~532 ~381 ~34 ~604 minecraft:light_gray_concrete replace
fill ~99 ~34 ~536 ~99 ~34 ~608 minecraft:light_gray_concrete replace
fill ~123 ~34 ~540 ~123 ~34 ~612 minecraft:light_gray_concrete replace
fill ~147 ~34 ~544 ~147 ~34 ~616 minecraft:light_gray_concrete replace
fill ~189 ~34 ~548 ~189 ~34 ~620 minecraft:light_gray_concrete replace
fill ~219 ~34 ~552 ~219 ~34 ~624 minecraft:light_gray_concrete replace
fill ~249 ~34 ~556 ~249 ~34 ~628 minecraft:light_gray_concrete replace
fill ~294 ~34 ~560 ~294 ~34 ~632 minecraft:light_gray_concrete replace
fill ~312 ~34 ~564 ~312 ~34 ~636 minecraft:light_gray_concrete replace
fill ~372 ~34 ~568 ~372 ~34 ~640 minecraft:light_gray_concrete replace
fill ~162 ~34 ~572 ~162 ~34 ~644 minecraft:light_gray_concrete replace
fill ~399 ~34 ~576 ~399 ~34 ~648 minecraft:light_gray_concrete replace
fill ~96 ~34 ~580 ~96 ~34 ~652 minecraft:light_gray_concrete replace
fill ~375 ~34 ~584 ~375 ~34 ~656 minecraft:light_gray_concrete replace
fill ~396 ~34 ~588 ~396 ~34 ~660 minecraft:light_gray_concrete replace
setblock ~94 ~35 ~8 minecraft:light_gray_concrete replace
setblock ~121 ~35 ~8 minecraft:light_gray_concrete replace
setblock ~177 ~35 ~13 minecraft:light_gray_concrete replace
setblock ~118 ~35 ~16 minecraft:light_gray_concrete replace
setblock ~142 ~35 ~16 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~210 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~23 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~23 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~23 minecraft:light_gray_concrete replace
setblock ~145 ~35 ~24 minecraft:light_gray_concrete replace
setblock ~169 ~35 ~24 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~252 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~31 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~31 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~31 minecraft:light_gray_concrete replace
setblock ~175 ~35 ~32 minecraft:light_gray_concrete replace
setblock ~259 ~35 ~32 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~196 ~35 ~40 minecraft:light_gray_concrete replace
setblock ~226 ~35 ~40 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~300 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~229 ~35 ~48 minecraft:light_gray_concrete replace
setblock ~262 ~35 ~48 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~330 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~265 ~35 ~56 minecraft:light_gray_concrete replace
setblock ~340 ~35 ~56 minecraft:light_gray_concrete replace
setblock ~337 ~35 ~60 minecraft:light_gray_concrete replace
setblock ~343 ~35 ~60 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~321 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~286 ~35 ~72 minecraft:light_gray_concrete replace
setblock ~388 ~35 ~72 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~73 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~73 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~73 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~75 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~75 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~75 minecraft:light_gray_concrete replace
setblock ~355 ~35 ~76 minecraft:light_gray_concrete replace
setblock ~379 ~35 ~76 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~351 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~109 minecraft:light_gray_concrete replace
