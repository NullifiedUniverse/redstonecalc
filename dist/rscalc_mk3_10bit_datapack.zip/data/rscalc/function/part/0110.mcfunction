fill ~464 ~165 ~286 ~474 ~165 ~286 minecraft:redstone_wire replace
setblock ~475 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~165 ~286 ~483 ~165 ~286 minecraft:redstone_wire replace
setblock ~100 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~101 ~165 ~302 ~111 ~165 ~302 minecraft:redstone_wire replace
setblock ~112 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~113 ~165 ~302 ~123 ~165 ~302 minecraft:redstone_wire replace
setblock ~124 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~302 ~135 ~165 ~302 minecraft:redstone_wire replace
setblock ~136 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~302 ~147 ~165 ~302 minecraft:redstone_wire replace
setblock ~148 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~302 ~159 ~165 ~302 minecraft:redstone_wire replace
setblock ~160 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~302 ~171 ~165 ~302 minecraft:redstone_wire replace
setblock ~172 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~302 ~183 ~165 ~302 minecraft:redstone_wire replace
setblock ~184 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~302 ~195 ~165 ~302 minecraft:redstone_wire replace
setblock ~196 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~302 ~207 ~165 ~302 minecraft:redstone_wire replace
setblock ~208 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~302 ~219 ~165 ~302 minecraft:redstone_wire replace
setblock ~220 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~302 ~231 ~165 ~302 minecraft:redstone_wire replace
setblock ~232 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~302 ~243 ~165 ~302 minecraft:redstone_wire replace
setblock ~244 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~302 ~255 ~165 ~302 minecraft:redstone_wire replace
setblock ~256 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~302 ~267 ~165 ~302 minecraft:redstone_wire replace
setblock ~268 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~302 ~279 ~165 ~302 minecraft:redstone_wire replace
setblock ~280 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~302 ~291 ~165 ~302 minecraft:redstone_wire replace
setblock ~292 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~302 ~303 ~165 ~302 minecraft:redstone_wire replace
setblock ~304 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~302 ~315 ~165 ~302 minecraft:redstone_wire replace
setblock ~316 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~302 ~327 ~165 ~302 minecraft:redstone_wire replace
setblock ~328 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~302 ~339 ~165 ~302 minecraft:redstone_wire replace
setblock ~340 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~302 ~351 ~165 ~302 minecraft:redstone_wire replace
setblock ~352 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~302 ~363 ~165 ~302 minecraft:redstone_wire replace
setblock ~364 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~302 ~375 ~165 ~302 minecraft:redstone_wire replace
setblock ~376 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~302 ~387 ~165 ~302 minecraft:redstone_wire replace
setblock ~388 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~302 ~399 ~165 ~302 minecraft:redstone_wire replace
setblock ~400 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~302 ~411 ~165 ~302 minecraft:redstone_wire replace
setblock ~412 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~302 ~423 ~165 ~302 minecraft:redstone_wire replace
setblock ~424 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~302 ~435 ~165 ~302 minecraft:redstone_wire replace
setblock ~436 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~302 ~447 ~165 ~302 minecraft:redstone_wire replace
setblock ~448 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~302 ~459 ~165 ~302 minecraft:redstone_wire replace
setblock ~460 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~302 ~471 ~165 ~302 minecraft:redstone_wire replace
setblock ~472 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~302 ~483 ~165 ~302 minecraft:redstone_wire replace
setblock ~484 ~165 ~302 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~485 ~165 ~302 minecraft:redstone_wire replace
setblock ~97 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~98 ~165 ~330 ~108 ~165 ~330 minecraft:redstone_wire replace
setblock ~109 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~110 ~165 ~330 ~120 ~165 ~330 minecraft:redstone_wire replace
setblock ~121 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~330 ~132 ~165 ~330 minecraft:redstone_wire replace
setblock ~133 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~330 ~144 ~165 ~330 minecraft:redstone_wire replace
setblock ~145 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~330 ~156 ~165 ~330 minecraft:redstone_wire replace
setblock ~157 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~330 ~168 ~165 ~330 minecraft:redstone_wire replace
setblock ~169 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~330 ~180 ~165 ~330 minecraft:redstone_wire replace
setblock ~181 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~330 ~192 ~165 ~330 minecraft:redstone_wire replace
setblock ~193 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~330 ~204 ~165 ~330 minecraft:redstone_wire replace
setblock ~205 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~330 ~216 ~165 ~330 minecraft:redstone_wire replace
setblock ~217 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~330 ~228 ~165 ~330 minecraft:redstone_wire replace
setblock ~229 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~330 ~240 ~165 ~330 minecraft:redstone_wire replace
setblock ~241 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~330 ~252 ~165 ~330 minecraft:redstone_wire replace
setblock ~253 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~330 ~264 ~165 ~330 minecraft:redstone_wire replace
setblock ~265 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~330 ~276 ~165 ~330 minecraft:redstone_wire replace
setblock ~277 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~330 ~288 ~165 ~330 minecraft:redstone_wire replace
setblock ~289 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~330 ~300 ~165 ~330 minecraft:redstone_wire replace
setblock ~301 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~330 ~312 ~165 ~330 minecraft:redstone_wire replace
setblock ~313 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~330 ~324 ~165 ~330 minecraft:redstone_wire replace
setblock ~325 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~330 ~336 ~165 ~330 minecraft:redstone_wire replace
setblock ~337 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~330 ~348 ~165 ~330 minecraft:redstone_wire replace
setblock ~349 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~330 ~360 ~165 ~330 minecraft:redstone_wire replace
setblock ~361 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~330 ~372 ~165 ~330 minecraft:redstone_wire replace
setblock ~373 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~330 ~384 ~165 ~330 minecraft:redstone_wire replace
setblock ~385 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~330 ~396 ~165 ~330 minecraft:redstone_wire replace
setblock ~397 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~330 ~408 ~165 ~330 minecraft:redstone_wire replace
setblock ~409 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~330 ~420 ~165 ~330 minecraft:redstone_wire replace
setblock ~421 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~330 ~432 ~165 ~330 minecraft:redstone_wire replace
setblock ~433 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~330 ~444 ~165 ~330 minecraft:redstone_wire replace
setblock ~445 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~330 ~456 ~165 ~330 minecraft:redstone_wire replace
setblock ~457 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~330 ~468 ~165 ~330 minecraft:redstone_wire replace
setblock ~469 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~330 ~480 ~165 ~330 minecraft:redstone_wire replace
setblock ~481 ~165 ~330 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~165 ~330 ~487 ~165 ~330 minecraft:redstone_wire replace
setblock ~94 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~95 ~165 ~366 ~105 ~165 ~366 minecraft:redstone_wire replace
setblock ~106 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~107 ~165 ~366 ~117 ~165 ~366 minecraft:redstone_wire replace
setblock ~118 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~366 ~129 ~165 ~366 minecraft:redstone_wire replace
setblock ~130 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~366 ~141 ~165 ~366 minecraft:redstone_wire replace
setblock ~142 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~366 ~153 ~165 ~366 minecraft:redstone_wire replace
setblock ~154 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~366 ~165 ~165 ~366 minecraft:redstone_wire replace
setblock ~166 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~366 ~177 ~165 ~366 minecraft:redstone_wire replace
setblock ~178 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~366 ~189 ~165 ~366 minecraft:redstone_wire replace
setblock ~190 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~366 ~201 ~165 ~366 minecraft:redstone_wire replace
setblock ~202 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~366 ~213 ~165 ~366 minecraft:redstone_wire replace
setblock ~214 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~366 ~225 ~165 ~366 minecraft:redstone_wire replace
setblock ~226 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~366 ~237 ~165 ~366 minecraft:redstone_wire replace
setblock ~238 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~366 ~249 ~165 ~366 minecraft:redstone_wire replace
setblock ~250 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~366 ~261 ~165 ~366 minecraft:redstone_wire replace
setblock ~262 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~366 ~273 ~165 ~366 minecraft:redstone_wire replace
setblock ~274 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~366 ~285 ~165 ~366 minecraft:redstone_wire replace
setblock ~286 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~366 ~297 ~165 ~366 minecraft:redstone_wire replace
setblock ~298 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~366 ~309 ~165 ~366 minecraft:redstone_wire replace
setblock ~310 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~366 ~321 ~165 ~366 minecraft:redstone_wire replace
setblock ~322 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~366 ~333 ~165 ~366 minecraft:redstone_wire replace
setblock ~334 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~366 ~345 ~165 ~366 minecraft:redstone_wire replace
setblock ~346 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~366 ~357 ~165 ~366 minecraft:redstone_wire replace
setblock ~358 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~366 ~369 ~165 ~366 minecraft:redstone_wire replace
setblock ~370 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~366 ~381 ~165 ~366 minecraft:redstone_wire replace
setblock ~382 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~366 ~393 ~165 ~366 minecraft:redstone_wire replace
setblock ~394 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~366 ~405 ~165 ~366 minecraft:redstone_wire replace
setblock ~406 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~366 ~417 ~165 ~366 minecraft:redstone_wire replace
setblock ~418 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~366 ~429 ~165 ~366 minecraft:redstone_wire replace
setblock ~430 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~366 ~441 ~165 ~366 minecraft:redstone_wire replace
setblock ~442 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~366 ~453 ~165 ~366 minecraft:redstone_wire replace
setblock ~454 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~366 ~465 ~165 ~366 minecraft:redstone_wire replace
setblock ~466 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~366 ~477 ~165 ~366 minecraft:redstone_wire replace
setblock ~478 ~165 ~366 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~479 ~165 ~366 ~489 ~165 ~366 minecraft:redstone_wire replace
setblock ~91 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~92 ~165 ~398 ~102 ~165 ~398 minecraft:redstone_wire replace
setblock ~103 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~104 ~165 ~398 ~114 ~165 ~398 minecraft:redstone_wire replace
setblock ~115 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~116 ~165 ~398 ~126 ~165 ~398 minecraft:redstone_wire replace
setblock ~127 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~398 ~138 ~165 ~398 minecraft:redstone_wire replace
setblock ~139 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~398 ~150 ~165 ~398 minecraft:redstone_wire replace
setblock ~151 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~398 ~162 ~165 ~398 minecraft:redstone_wire replace
setblock ~163 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~398 ~174 ~165 ~398 minecraft:redstone_wire replace
setblock ~175 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~398 ~186 ~165 ~398 minecraft:redstone_wire replace
setblock ~187 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~398 ~198 ~165 ~398 minecraft:redstone_wire replace
setblock ~199 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~398 ~210 ~165 ~398 minecraft:redstone_wire replace
setblock ~211 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~398 ~222 ~165 ~398 minecraft:redstone_wire replace
setblock ~223 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~398 ~234 ~165 ~398 minecraft:redstone_wire replace
setblock ~235 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~398 ~246 ~165 ~398 minecraft:redstone_wire replace
setblock ~247 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~398 ~258 ~165 ~398 minecraft:redstone_wire replace
setblock ~259 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~398 ~270 ~165 ~398 minecraft:redstone_wire replace
setblock ~271 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~398 ~282 ~165 ~398 minecraft:redstone_wire replace
setblock ~283 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~398 ~294 ~165 ~398 minecraft:redstone_wire replace
setblock ~295 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~398 ~306 ~165 ~398 minecraft:redstone_wire replace
setblock ~307 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~398 ~318 ~165 ~398 minecraft:redstone_wire replace
setblock ~319 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~398 ~330 ~165 ~398 minecraft:redstone_wire replace
setblock ~331 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~398 ~342 ~165 ~398 minecraft:redstone_wire replace
setblock ~343 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~398 ~354 ~165 ~398 minecraft:redstone_wire replace
setblock ~355 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~398 ~366 ~165 ~398 minecraft:redstone_wire replace
setblock ~367 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~398 ~378 ~165 ~398 minecraft:redstone_wire replace
setblock ~379 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~398 ~390 ~165 ~398 minecraft:redstone_wire replace
setblock ~391 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~398 ~402 ~165 ~398 minecraft:redstone_wire replace
setblock ~403 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~398 ~414 ~165 ~398 minecraft:redstone_wire replace
setblock ~415 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~398 ~426 ~165 ~398 minecraft:redstone_wire replace
setblock ~427 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~398 ~438 ~165 ~398 minecraft:redstone_wire replace
setblock ~439 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~398 ~450 ~165 ~398 minecraft:redstone_wire replace
setblock ~451 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~398 ~462 ~165 ~398 minecraft:redstone_wire replace
setblock ~463 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~398 ~474 ~165 ~398 minecraft:redstone_wire replace
setblock ~475 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~165 ~398 ~486 ~165 ~398 minecraft:redstone_wire replace
setblock ~487 ~165 ~398 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~165 ~398 ~491 ~165 ~398 minecraft:redstone_wire replace
setblock ~88 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~89 ~165 ~430 ~99 ~165 ~430 minecraft:redstone_wire replace
setblock ~100 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~101 ~165 ~430 ~111 ~165 ~430 minecraft:redstone_wire replace
setblock ~112 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~113 ~165 ~430 ~123 ~165 ~430 minecraft:redstone_wire replace
setblock ~124 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~430 ~135 ~165 ~430 minecraft:redstone_wire replace
setblock ~136 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~430 ~147 ~165 ~430 minecraft:redstone_wire replace
setblock ~148 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~430 ~159 ~165 ~430 minecraft:redstone_wire replace
setblock ~160 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~430 ~171 ~165 ~430 minecraft:redstone_wire replace
setblock ~172 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~430 ~183 ~165 ~430 minecraft:redstone_wire replace
setblock ~184 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~430 ~195 ~165 ~430 minecraft:redstone_wire replace
setblock ~196 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~430 ~207 ~165 ~430 minecraft:redstone_wire replace
setblock ~208 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~430 ~219 ~165 ~430 minecraft:redstone_wire replace
setblock ~220 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~430 ~231 ~165 ~430 minecraft:redstone_wire replace
setblock ~232 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~430 ~243 ~165 ~430 minecraft:redstone_wire replace
setblock ~244 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~430 ~255 ~165 ~430 minecraft:redstone_wire replace
setblock ~256 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~430 ~267 ~165 ~430 minecraft:redstone_wire replace
setblock ~268 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~430 ~279 ~165 ~430 minecraft:redstone_wire replace
setblock ~280 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~430 ~291 ~165 ~430 minecraft:redstone_wire replace
setblock ~292 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~430 ~303 ~165 ~430 minecraft:redstone_wire replace
setblock ~304 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~430 ~315 ~165 ~430 minecraft:redstone_wire replace
setblock ~316 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~430 ~327 ~165 ~430 minecraft:redstone_wire replace
setblock ~328 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~430 ~339 ~165 ~430 minecraft:redstone_wire replace
setblock ~340 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~430 ~351 ~165 ~430 minecraft:redstone_wire replace
setblock ~352 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~430 ~363 ~165 ~430 minecraft:redstone_wire replace
setblock ~364 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~430 ~375 ~165 ~430 minecraft:redstone_wire replace
setblock ~376 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~430 ~387 ~165 ~430 minecraft:redstone_wire replace
setblock ~388 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~430 ~399 ~165 ~430 minecraft:redstone_wire replace
setblock ~400 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~430 ~411 ~165 ~430 minecraft:redstone_wire replace
setblock ~412 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~430 ~423 ~165 ~430 minecraft:redstone_wire replace
setblock ~424 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~430 ~435 ~165 ~430 minecraft:redstone_wire replace
setblock ~436 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~430 ~447 ~165 ~430 minecraft:redstone_wire replace
setblock ~448 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~430 ~459 ~165 ~430 minecraft:redstone_wire replace
setblock ~460 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~430 ~471 ~165 ~430 minecraft:redstone_wire replace
setblock ~472 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~430 ~483 ~165 ~430 minecraft:redstone_wire replace
setblock ~484 ~165 ~430 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~485 ~165 ~430 ~493 ~165 ~430 minecraft:redstone_wire replace
setblock ~82 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~83 ~165 ~446 ~93 ~165 ~446 minecraft:redstone_wire replace
setblock ~94 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~95 ~165 ~446 ~105 ~165 ~446 minecraft:redstone_wire replace
setblock ~106 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~107 ~165 ~446 ~117 ~165 ~446 minecraft:redstone_wire replace
setblock ~118 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~446 ~129 ~165 ~446 minecraft:redstone_wire replace
setblock ~130 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~446 ~141 ~165 ~446 minecraft:redstone_wire replace
setblock ~142 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~446 ~153 ~165 ~446 minecraft:redstone_wire replace
setblock ~154 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~446 ~165 ~165 ~446 minecraft:redstone_wire replace
setblock ~166 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~446 ~177 ~165 ~446 minecraft:redstone_wire replace
setblock ~178 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~446 ~189 ~165 ~446 minecraft:redstone_wire replace
setblock ~190 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~446 ~201 ~165 ~446 minecraft:redstone_wire replace
setblock ~202 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~446 ~213 ~165 ~446 minecraft:redstone_wire replace
setblock ~214 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~446 ~225 ~165 ~446 minecraft:redstone_wire replace
setblock ~226 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~446 ~237 ~165 ~446 minecraft:redstone_wire replace
setblock ~238 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~446 ~249 ~165 ~446 minecraft:redstone_wire replace
setblock ~250 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~446 ~261 ~165 ~446 minecraft:redstone_wire replace
setblock ~262 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~446 ~273 ~165 ~446 minecraft:redstone_wire replace
setblock ~274 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~446 ~285 ~165 ~446 minecraft:redstone_wire replace
setblock ~286 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~446 ~297 ~165 ~446 minecraft:redstone_wire replace
setblock ~298 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~446 ~309 ~165 ~446 minecraft:redstone_wire replace
setblock ~310 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~446 ~321 ~165 ~446 minecraft:redstone_wire replace
setblock ~322 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~446 ~333 ~165 ~446 minecraft:redstone_wire replace
setblock ~334 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~446 ~345 ~165 ~446 minecraft:redstone_wire replace
setblock ~346 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~446 ~357 ~165 ~446 minecraft:redstone_wire replace
setblock ~358 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~446 ~369 ~165 ~446 minecraft:redstone_wire replace
setblock ~370 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~446 ~381 ~165 ~446 minecraft:redstone_wire replace
setblock ~382 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~446 ~393 ~165 ~446 minecraft:redstone_wire replace
setblock ~394 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~446 ~405 ~165 ~446 minecraft:redstone_wire replace
setblock ~406 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~446 ~417 ~165 ~446 minecraft:redstone_wire replace
setblock ~418 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~446 ~429 ~165 ~446 minecraft:redstone_wire replace
setblock ~430 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~446 ~441 ~165 ~446 minecraft:redstone_wire replace
setblock ~442 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~446 ~453 ~165 ~446 minecraft:redstone_wire replace
setblock ~454 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~446 ~465 ~165 ~446 minecraft:redstone_wire replace
setblock ~466 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~446 ~477 ~165 ~446 minecraft:redstone_wire replace
setblock ~478 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~479 ~165 ~446 ~489 ~165 ~446 minecraft:redstone_wire replace
setblock ~490 ~165 ~446 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~491 ~165 ~446 ~499 ~165 ~446 minecraft:redstone_wire replace
setblock ~112 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~113 ~165 ~534 ~123 ~165 ~534 minecraft:redstone_wire replace
setblock ~124 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~534 ~135 ~165 ~534 minecraft:redstone_wire replace
setblock ~136 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~534 ~147 ~165 ~534 minecraft:redstone_wire replace
setblock ~148 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~534 ~159 ~165 ~534 minecraft:redstone_wire replace
setblock ~160 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~534 ~171 ~165 ~534 minecraft:redstone_wire replace
setblock ~172 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~534 ~183 ~165 ~534 minecraft:redstone_wire replace
setblock ~184 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~534 ~195 ~165 ~534 minecraft:redstone_wire replace
setblock ~196 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~534 ~207 ~165 ~534 minecraft:redstone_wire replace
setblock ~208 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~534 ~219 ~165 ~534 minecraft:redstone_wire replace
setblock ~220 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~534 ~231 ~165 ~534 minecraft:redstone_wire replace
setblock ~232 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~534 ~243 ~165 ~534 minecraft:redstone_wire replace
setblock ~244 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~534 ~255 ~165 ~534 minecraft:redstone_wire replace
setblock ~256 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~534 ~267 ~165 ~534 minecraft:redstone_wire replace
setblock ~268 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~534 ~279 ~165 ~534 minecraft:redstone_wire replace
setblock ~280 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~534 ~291 ~165 ~534 minecraft:redstone_wire replace
setblock ~292 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~534 ~303 ~165 ~534 minecraft:redstone_wire replace
setblock ~304 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~534 ~315 ~165 ~534 minecraft:redstone_wire replace
setblock ~316 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~534 ~327 ~165 ~534 minecraft:redstone_wire replace
setblock ~328 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~534 ~339 ~165 ~534 minecraft:redstone_wire replace
setblock ~340 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~534 ~351 ~165 ~534 minecraft:redstone_wire replace
setblock ~352 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~534 ~363 ~165 ~534 minecraft:redstone_wire replace
setblock ~364 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~534 ~375 ~165 ~534 minecraft:redstone_wire replace
setblock ~376 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~534 ~387 ~165 ~534 minecraft:redstone_wire replace
setblock ~388 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~534 ~399 ~165 ~534 minecraft:redstone_wire replace
setblock ~400 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~534 ~411 ~165 ~534 minecraft:redstone_wire replace
setblock ~412 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~534 ~423 ~165 ~534 minecraft:redstone_wire replace
setblock ~424 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~534 ~435 ~165 ~534 minecraft:redstone_wire replace
setblock ~436 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~534 ~447 ~165 ~534 minecraft:redstone_wire replace
setblock ~448 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~534 ~459 ~165 ~534 minecraft:redstone_wire replace
setblock ~460 ~165 ~534 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~534 ~467 ~165 ~534 minecraft:redstone_wire replace
setblock ~115 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~116 ~165 ~566 ~126 ~165 ~566 minecraft:redstone_wire replace
setblock ~127 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~566 ~138 ~165 ~566 minecraft:redstone_wire replace
setblock ~139 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~566 ~150 ~165 ~566 minecraft:redstone_wire replace
setblock ~151 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~566 ~162 ~165 ~566 minecraft:redstone_wire replace
setblock ~163 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~566 ~174 ~165 ~566 minecraft:redstone_wire replace
setblock ~175 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~566 ~186 ~165 ~566 minecraft:redstone_wire replace
setblock ~187 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~566 ~198 ~165 ~566 minecraft:redstone_wire replace
setblock ~199 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~566 ~210 ~165 ~566 minecraft:redstone_wire replace
setblock ~211 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~566 ~222 ~165 ~566 minecraft:redstone_wire replace
setblock ~223 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~566 ~234 ~165 ~566 minecraft:redstone_wire replace
setblock ~235 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~566 ~246 ~165 ~566 minecraft:redstone_wire replace
setblock ~247 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~566 ~258 ~165 ~566 minecraft:redstone_wire replace
setblock ~259 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~566 ~270 ~165 ~566 minecraft:redstone_wire replace
setblock ~271 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~566 ~282 ~165 ~566 minecraft:redstone_wire replace
setblock ~283 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~566 ~294 ~165 ~566 minecraft:redstone_wire replace
setblock ~295 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~566 ~306 ~165 ~566 minecraft:redstone_wire replace
setblock ~307 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~566 ~318 ~165 ~566 minecraft:redstone_wire replace
setblock ~319 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~566 ~330 ~165 ~566 minecraft:redstone_wire replace
setblock ~331 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~566 ~342 ~165 ~566 minecraft:redstone_wire replace
setblock ~343 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~566 ~354 ~165 ~566 minecraft:redstone_wire replace
setblock ~355 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~566 ~366 ~165 ~566 minecraft:redstone_wire replace
setblock ~367 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~566 ~378 ~165 ~566 minecraft:redstone_wire replace
setblock ~379 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~566 ~390 ~165 ~566 minecraft:redstone_wire replace
setblock ~391 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~566 ~402 ~165 ~566 minecraft:redstone_wire replace
setblock ~403 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~566 ~414 ~165 ~566 minecraft:redstone_wire replace
setblock ~415 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~566 ~426 ~165 ~566 minecraft:redstone_wire replace
setblock ~427 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~566 ~438 ~165 ~566 minecraft:redstone_wire replace
setblock ~439 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~566 ~450 ~165 ~566 minecraft:redstone_wire replace
setblock ~451 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~566 ~462 ~165 ~566 minecraft:redstone_wire replace
setblock ~463 ~165 ~566 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~566 ~469 ~165 ~566 minecraft:redstone_wire replace
setblock ~118 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~598 ~129 ~165 ~598 minecraft:redstone_wire replace
setblock ~130 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~598 ~141 ~165 ~598 minecraft:redstone_wire replace
setblock ~142 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~598 ~153 ~165 ~598 minecraft:redstone_wire replace
setblock ~154 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~598 ~165 ~165 ~598 minecraft:redstone_wire replace
setblock ~166 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~598 ~177 ~165 ~598 minecraft:redstone_wire replace
setblock ~178 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~598 ~189 ~165 ~598 minecraft:redstone_wire replace
setblock ~190 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~598 ~201 ~165 ~598 minecraft:redstone_wire replace
setblock ~202 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~598 ~213 ~165 ~598 minecraft:redstone_wire replace
setblock ~214 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~598 ~225 ~165 ~598 minecraft:redstone_wire replace
setblock ~226 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~598 ~237 ~165 ~598 minecraft:redstone_wire replace
setblock ~238 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~598 ~249 ~165 ~598 minecraft:redstone_wire replace
setblock ~250 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~598 ~261 ~165 ~598 minecraft:redstone_wire replace
setblock ~262 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~598 ~273 ~165 ~598 minecraft:redstone_wire replace
setblock ~274 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~598 ~285 ~165 ~598 minecraft:redstone_wire replace
setblock ~286 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~598 ~297 ~165 ~598 minecraft:redstone_wire replace
setblock ~298 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~598 ~309 ~165 ~598 minecraft:redstone_wire replace
setblock ~310 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~598 ~321 ~165 ~598 minecraft:redstone_wire replace
setblock ~322 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~598 ~333 ~165 ~598 minecraft:redstone_wire replace
setblock ~334 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~598 ~345 ~165 ~598 minecraft:redstone_wire replace
setblock ~346 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~598 ~357 ~165 ~598 minecraft:redstone_wire replace
setblock ~358 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~598 ~369 ~165 ~598 minecraft:redstone_wire replace
setblock ~370 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~598 ~381 ~165 ~598 minecraft:redstone_wire replace
setblock ~382 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~598 ~393 ~165 ~598 minecraft:redstone_wire replace
setblock ~394 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~598 ~405 ~165 ~598 minecraft:redstone_wire replace
setblock ~406 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~598 ~417 ~165 ~598 minecraft:redstone_wire replace
setblock ~418 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~598 ~429 ~165 ~598 minecraft:redstone_wire replace
setblock ~430 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~598 ~441 ~165 ~598 minecraft:redstone_wire replace
setblock ~442 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~598 ~453 ~165 ~598 minecraft:redstone_wire replace
setblock ~454 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~598 ~465 ~165 ~598 minecraft:redstone_wire replace
setblock ~466 ~165 ~598 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~598 ~471 ~165 ~598 minecraft:redstone_wire replace
setblock ~121 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~634 ~132 ~165 ~634 minecraft:redstone_wire replace
setblock ~133 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~634 ~144 ~165 ~634 minecraft:redstone_wire replace
setblock ~145 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~634 ~156 ~165 ~634 minecraft:redstone_wire replace
setblock ~157 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~634 ~168 ~165 ~634 minecraft:redstone_wire replace
setblock ~169 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~634 ~180 ~165 ~634 minecraft:redstone_wire replace
setblock ~181 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~634 ~192 ~165 ~634 minecraft:redstone_wire replace
setblock ~193 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
