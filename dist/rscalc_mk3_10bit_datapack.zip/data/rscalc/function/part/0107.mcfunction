fill ~211 ~157 ~782 ~224 ~157 ~782 minecraft:redstone_wire replace
setblock ~226 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~782 ~241 ~157 ~782 minecraft:redstone_wire replace
setblock ~243 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~782 ~258 ~157 ~782 minecraft:redstone_wire replace
setblock ~260 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~782 ~267 ~157 ~782 minecraft:redstone_wire replace
setblock ~130 ~157 ~783 minecraft:redstone_wire replace
fill ~129 ~157 ~786 ~135 ~157 ~786 minecraft:redstone_wire replace
setblock ~137 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~786 ~152 ~157 ~786 minecraft:redstone_wire replace
setblock ~154 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~786 ~169 ~157 ~786 minecraft:redstone_wire replace
setblock ~171 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~786 ~186 ~157 ~786 minecraft:redstone_wire replace
setblock ~188 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~786 ~203 ~157 ~786 minecraft:redstone_wire replace
setblock ~205 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~786 ~220 ~157 ~786 minecraft:redstone_wire replace
setblock ~222 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~157 ~786 ~237 ~157 ~786 minecraft:redstone_wire replace
setblock ~239 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~157 ~786 ~254 ~157 ~786 minecraft:redstone_wire replace
setblock ~256 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~157 ~786 ~270 ~157 ~786 minecraft:redstone_wire replace
setblock ~130 ~157 ~787 minecraft:redstone_wire replace
fill ~129 ~157 ~790 ~139 ~157 ~790 minecraft:redstone_wire replace
setblock ~141 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~790 ~156 ~157 ~790 minecraft:redstone_wire replace
setblock ~158 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~790 ~173 ~157 ~790 minecraft:redstone_wire replace
setblock ~175 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~790 ~190 ~157 ~790 minecraft:redstone_wire replace
setblock ~192 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~790 ~207 ~157 ~790 minecraft:redstone_wire replace
setblock ~209 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~790 ~224 ~157 ~790 minecraft:redstone_wire replace
setblock ~226 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~790 ~241 ~157 ~790 minecraft:redstone_wire replace
setblock ~243 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~790 ~258 ~157 ~790 minecraft:redstone_wire replace
setblock ~260 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~790 ~273 ~157 ~790 minecraft:redstone_wire replace
setblock ~130 ~157 ~791 minecraft:redstone_wire replace
fill ~129 ~157 ~794 ~136 ~157 ~794 minecraft:redstone_wire replace
setblock ~138 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~794 ~152 ~157 ~794 minecraft:redstone_wire replace
setblock ~154 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~794 ~168 ~157 ~794 minecraft:redstone_wire replace
setblock ~170 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~794 ~184 ~157 ~794 minecraft:redstone_wire replace
setblock ~186 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~794 ~200 ~157 ~794 minecraft:redstone_wire replace
setblock ~202 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~794 ~216 ~157 ~794 minecraft:redstone_wire replace
setblock ~218 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~794 ~232 ~157 ~794 minecraft:redstone_wire replace
setblock ~234 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~157 ~794 ~248 ~157 ~794 minecraft:redstone_wire replace
setblock ~250 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~794 ~264 ~157 ~794 minecraft:redstone_wire replace
setblock ~266 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~794 ~276 ~157 ~794 minecraft:redstone_wire replace
setblock ~130 ~157 ~795 minecraft:redstone_wire replace
fill ~132 ~157 ~798 ~134 ~157 ~798 minecraft:redstone_wire replace
setblock ~136 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~798 ~151 ~157 ~798 minecraft:redstone_wire replace
setblock ~153 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~798 ~168 ~157 ~798 minecraft:redstone_wire replace
setblock ~170 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~798 ~185 ~157 ~798 minecraft:redstone_wire replace
setblock ~187 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~798 ~202 ~157 ~798 minecraft:redstone_wire replace
setblock ~204 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~798 ~219 ~157 ~798 minecraft:redstone_wire replace
setblock ~221 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~798 ~236 ~157 ~798 minecraft:redstone_wire replace
setblock ~238 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~798 ~253 ~157 ~798 minecraft:redstone_wire replace
setblock ~255 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~798 ~270 ~157 ~798 minecraft:redstone_wire replace
setblock ~272 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~798 ~279 ~157 ~798 minecraft:redstone_wire replace
setblock ~133 ~157 ~799 minecraft:redstone_wire replace
fill ~132 ~157 ~802 ~139 ~157 ~802 minecraft:redstone_wire replace
setblock ~141 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~802 ~155 ~157 ~802 minecraft:redstone_wire replace
setblock ~157 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~802 ~171 ~157 ~802 minecraft:redstone_wire replace
setblock ~173 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~802 ~187 ~157 ~802 minecraft:redstone_wire replace
setblock ~189 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~802 ~203 ~157 ~802 minecraft:redstone_wire replace
setblock ~205 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~802 ~219 ~157 ~802 minecraft:redstone_wire replace
setblock ~221 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~802 ~235 ~157 ~802 minecraft:redstone_wire replace
setblock ~237 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~802 ~251 ~157 ~802 minecraft:redstone_wire replace
setblock ~253 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~157 ~802 ~267 ~157 ~802 minecraft:redstone_wire replace
setblock ~269 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~802 ~282 ~157 ~802 minecraft:redstone_wire replace
setblock ~133 ~157 ~803 minecraft:redstone_wire replace
fill ~132 ~157 ~806 ~134 ~157 ~806 minecraft:redstone_wire replace
setblock ~136 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~806 ~151 ~157 ~806 minecraft:redstone_wire replace
setblock ~153 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~806 ~168 ~157 ~806 minecraft:redstone_wire replace
setblock ~170 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~806 ~185 ~157 ~806 minecraft:redstone_wire replace
setblock ~187 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~806 ~202 ~157 ~806 minecraft:redstone_wire replace
setblock ~204 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~806 ~219 ~157 ~806 minecraft:redstone_wire replace
setblock ~221 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~806 ~236 ~157 ~806 minecraft:redstone_wire replace
setblock ~238 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~806 ~253 ~157 ~806 minecraft:redstone_wire replace
setblock ~255 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~806 ~270 ~157 ~806 minecraft:redstone_wire replace
setblock ~272 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~806 ~285 ~157 ~806 minecraft:redstone_wire replace
setblock ~133 ~157 ~807 minecraft:redstone_wire replace
fill ~132 ~157 ~810 ~139 ~157 ~810 minecraft:redstone_wire replace
setblock ~141 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~810 ~156 ~157 ~810 minecraft:redstone_wire replace
setblock ~158 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~810 ~173 ~157 ~810 minecraft:redstone_wire replace
setblock ~175 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~810 ~190 ~157 ~810 minecraft:redstone_wire replace
setblock ~192 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~810 ~207 ~157 ~810 minecraft:redstone_wire replace
setblock ~209 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~810 ~224 ~157 ~810 minecraft:redstone_wire replace
setblock ~226 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~810 ~241 ~157 ~810 minecraft:redstone_wire replace
setblock ~243 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~810 ~258 ~157 ~810 minecraft:redstone_wire replace
setblock ~260 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~810 ~275 ~157 ~810 minecraft:redstone_wire replace
setblock ~277 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~157 ~810 ~288 ~157 ~810 minecraft:redstone_wire replace
setblock ~133 ~157 ~811 minecraft:redstone_wire replace
setblock ~132 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~157 ~814 ~146 ~157 ~814 minecraft:redstone_wire replace
setblock ~148 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~814 ~163 ~157 ~814 minecraft:redstone_wire replace
setblock ~165 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~814 ~180 ~157 ~814 minecraft:redstone_wire replace
setblock ~182 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~814 ~197 ~157 ~814 minecraft:redstone_wire replace
setblock ~199 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~814 ~214 ~157 ~814 minecraft:redstone_wire replace
setblock ~216 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~814 ~231 ~157 ~814 minecraft:redstone_wire replace
setblock ~233 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~814 ~248 ~157 ~814 minecraft:redstone_wire replace
setblock ~250 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~814 ~265 ~157 ~814 minecraft:redstone_wire replace
setblock ~267 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~814 ~282 ~157 ~814 minecraft:redstone_wire replace
setblock ~284 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~814 ~291 ~157 ~814 minecraft:redstone_wire replace
setblock ~133 ~157 ~815 minecraft:redstone_wire replace
fill ~132 ~157 ~818 ~142 ~157 ~818 minecraft:redstone_wire replace
setblock ~144 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~818 ~159 ~157 ~818 minecraft:redstone_wire replace
setblock ~161 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~818 ~176 ~157 ~818 minecraft:redstone_wire replace
setblock ~178 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~818 ~193 ~157 ~818 minecraft:redstone_wire replace
setblock ~195 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~818 ~210 ~157 ~818 minecraft:redstone_wire replace
setblock ~212 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~818 ~227 ~157 ~818 minecraft:redstone_wire replace
setblock ~229 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~157 ~818 ~244 ~157 ~818 minecraft:redstone_wire replace
setblock ~246 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~248 ~157 ~818 ~261 ~157 ~818 minecraft:redstone_wire replace
setblock ~263 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~157 ~818 ~278 ~157 ~818 minecraft:redstone_wire replace
setblock ~280 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~157 ~818 ~294 ~157 ~818 minecraft:redstone_wire replace
setblock ~133 ~157 ~819 minecraft:redstone_wire replace
setblock ~132 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~157 ~822 ~146 ~157 ~822 minecraft:redstone_wire replace
setblock ~148 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~822 ~163 ~157 ~822 minecraft:redstone_wire replace
setblock ~165 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~822 ~180 ~157 ~822 minecraft:redstone_wire replace
setblock ~182 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~822 ~197 ~157 ~822 minecraft:redstone_wire replace
setblock ~199 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~822 ~214 ~157 ~822 minecraft:redstone_wire replace
setblock ~216 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~822 ~231 ~157 ~822 minecraft:redstone_wire replace
setblock ~233 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~822 ~248 ~157 ~822 minecraft:redstone_wire replace
setblock ~250 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~822 ~265 ~157 ~822 minecraft:redstone_wire replace
setblock ~267 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~822 ~282 ~157 ~822 minecraft:redstone_wire replace
setblock ~284 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~822 ~297 ~157 ~822 minecraft:redstone_wire replace
setblock ~133 ~157 ~823 minecraft:redstone_wire replace
fill ~132 ~157 ~826 ~134 ~157 ~826 minecraft:redstone_wire replace
setblock ~136 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~826 ~151 ~157 ~826 minecraft:redstone_wire replace
setblock ~153 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~826 ~168 ~157 ~826 minecraft:redstone_wire replace
setblock ~170 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~826 ~185 ~157 ~826 minecraft:redstone_wire replace
setblock ~187 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~826 ~202 ~157 ~826 minecraft:redstone_wire replace
setblock ~204 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~826 ~219 ~157 ~826 minecraft:redstone_wire replace
setblock ~221 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~826 ~236 ~157 ~826 minecraft:redstone_wire replace
setblock ~238 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~826 ~253 ~157 ~826 minecraft:redstone_wire replace
setblock ~255 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~826 ~270 ~157 ~826 minecraft:redstone_wire replace
setblock ~272 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~826 ~287 ~157 ~826 minecraft:redstone_wire replace
setblock ~289 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~157 ~826 ~300 ~157 ~826 minecraft:redstone_wire replace
setblock ~133 ~157 ~827 minecraft:redstone_wire replace
fill ~135 ~157 ~830 ~141 ~157 ~830 minecraft:redstone_wire replace
setblock ~143 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~830 ~158 ~157 ~830 minecraft:redstone_wire replace
setblock ~160 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~830 ~175 ~157 ~830 minecraft:redstone_wire replace
setblock ~177 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~830 ~192 ~157 ~830 minecraft:redstone_wire replace
setblock ~194 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~830 ~209 ~157 ~830 minecraft:redstone_wire replace
setblock ~211 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~830 ~226 ~157 ~830 minecraft:redstone_wire replace
setblock ~228 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~830 ~243 ~157 ~830 minecraft:redstone_wire replace
setblock ~245 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~830 ~260 ~157 ~830 minecraft:redstone_wire replace
setblock ~262 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~830 ~277 ~157 ~830 minecraft:redstone_wire replace
setblock ~279 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~830 ~294 ~157 ~830 minecraft:redstone_wire replace
setblock ~296 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~830 ~303 ~157 ~830 minecraft:redstone_wire replace
setblock ~136 ~157 ~831 minecraft:redstone_wire replace
fill ~135 ~157 ~834 ~137 ~157 ~834 minecraft:redstone_wire replace
setblock ~139 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~834 ~154 ~157 ~834 minecraft:redstone_wire replace
setblock ~156 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~834 ~171 ~157 ~834 minecraft:redstone_wire replace
setblock ~173 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~834 ~188 ~157 ~834 minecraft:redstone_wire replace
setblock ~190 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~834 ~205 ~157 ~834 minecraft:redstone_wire replace
setblock ~207 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~834 ~222 ~157 ~834 minecraft:redstone_wire replace
setblock ~224 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~834 ~239 ~157 ~834 minecraft:redstone_wire replace
setblock ~241 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~157 ~834 ~256 ~157 ~834 minecraft:redstone_wire replace
setblock ~258 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~260 ~157 ~834 ~273 ~157 ~834 minecraft:redstone_wire replace
setblock ~275 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~157 ~834 ~290 ~157 ~834 minecraft:redstone_wire replace
setblock ~292 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~157 ~834 ~306 ~157 ~834 minecraft:redstone_wire replace
setblock ~136 ~157 ~835 minecraft:redstone_wire replace
fill ~135 ~157 ~838 ~141 ~157 ~838 minecraft:redstone_wire replace
setblock ~143 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~838 ~158 ~157 ~838 minecraft:redstone_wire replace
setblock ~160 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~838 ~175 ~157 ~838 minecraft:redstone_wire replace
setblock ~177 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~838 ~192 ~157 ~838 minecraft:redstone_wire replace
setblock ~194 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~838 ~209 ~157 ~838 minecraft:redstone_wire replace
setblock ~211 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~838 ~226 ~157 ~838 minecraft:redstone_wire replace
setblock ~228 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~838 ~243 ~157 ~838 minecraft:redstone_wire replace
setblock ~245 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~838 ~260 ~157 ~838 minecraft:redstone_wire replace
setblock ~262 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~838 ~277 ~157 ~838 minecraft:redstone_wire replace
setblock ~279 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~838 ~294 ~157 ~838 minecraft:redstone_wire replace
setblock ~296 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~838 ~309 ~157 ~838 minecraft:redstone_wire replace
setblock ~136 ~157 ~839 minecraft:redstone_wire replace
fill ~135 ~157 ~842 ~146 ~157 ~842 minecraft:redstone_wire replace
setblock ~148 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~842 ~163 ~157 ~842 minecraft:redstone_wire replace
setblock ~165 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~842 ~180 ~157 ~842 minecraft:redstone_wire replace
setblock ~182 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~842 ~197 ~157 ~842 minecraft:redstone_wire replace
setblock ~199 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~842 ~214 ~157 ~842 minecraft:redstone_wire replace
setblock ~216 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~842 ~231 ~157 ~842 minecraft:redstone_wire replace
setblock ~233 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~842 ~248 ~157 ~842 minecraft:redstone_wire replace
setblock ~250 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~842 ~265 ~157 ~842 minecraft:redstone_wire replace
setblock ~267 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~842 ~282 ~157 ~842 minecraft:redstone_wire replace
setblock ~284 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~842 ~299 ~157 ~842 minecraft:redstone_wire replace
setblock ~301 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~157 ~842 ~312 ~157 ~842 minecraft:redstone_wire replace
setblock ~136 ~157 ~843 minecraft:redstone_wire replace
fill ~135 ~157 ~846 ~136 ~157 ~846 minecraft:redstone_wire replace
setblock ~138 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~846 ~153 ~157 ~846 minecraft:redstone_wire replace
setblock ~155 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~846 ~170 ~157 ~846 minecraft:redstone_wire replace
setblock ~172 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~846 ~187 ~157 ~846 minecraft:redstone_wire replace
setblock ~189 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~846 ~204 ~157 ~846 minecraft:redstone_wire replace
setblock ~206 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~157 ~846 ~221 ~157 ~846 minecraft:redstone_wire replace
setblock ~223 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~157 ~846 ~238 ~157 ~846 minecraft:redstone_wire replace
setblock ~240 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~157 ~846 ~255 ~157 ~846 minecraft:redstone_wire replace
setblock ~257 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~846 ~272 ~157 ~846 minecraft:redstone_wire replace
setblock ~274 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~846 ~289 ~157 ~846 minecraft:redstone_wire replace
setblock ~291 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~157 ~846 ~306 ~157 ~846 minecraft:redstone_wire replace
setblock ~308 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~157 ~846 ~315 ~157 ~846 minecraft:redstone_wire replace
setblock ~136 ~157 ~847 minecraft:redstone_wire replace
setblock ~135 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~850 ~149 ~157 ~850 minecraft:redstone_wire replace
setblock ~151 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~850 ~166 ~157 ~850 minecraft:redstone_wire replace
setblock ~168 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~850 ~183 ~157 ~850 minecraft:redstone_wire replace
setblock ~185 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~850 ~200 ~157 ~850 minecraft:redstone_wire replace
setblock ~202 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~850 ~217 ~157 ~850 minecraft:redstone_wire replace
setblock ~219 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~850 ~234 ~157 ~850 minecraft:redstone_wire replace
setblock ~236 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~850 ~251 ~157 ~850 minecraft:redstone_wire replace
setblock ~253 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~157 ~850 ~268 ~157 ~850 minecraft:redstone_wire replace
setblock ~270 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~157 ~850 ~285 ~157 ~850 minecraft:redstone_wire replace
setblock ~287 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~157 ~850 ~302 ~157 ~850 minecraft:redstone_wire replace
setblock ~304 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~157 ~850 ~318 ~157 ~850 minecraft:redstone_wire replace
setblock ~136 ~157 ~851 minecraft:redstone_wire replace
fill ~135 ~157 ~854 ~136 ~157 ~854 minecraft:redstone_wire replace
setblock ~138 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~854 ~153 ~157 ~854 minecraft:redstone_wire replace
setblock ~155 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~854 ~170 ~157 ~854 minecraft:redstone_wire replace
setblock ~172 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~854 ~187 ~157 ~854 minecraft:redstone_wire replace
setblock ~189 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~854 ~204 ~157 ~854 minecraft:redstone_wire replace
setblock ~206 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~157 ~854 ~221 ~157 ~854 minecraft:redstone_wire replace
setblock ~223 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~157 ~854 ~238 ~157 ~854 minecraft:redstone_wire replace
setblock ~240 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~157 ~854 ~255 ~157 ~854 minecraft:redstone_wire replace
setblock ~257 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~854 ~272 ~157 ~854 minecraft:redstone_wire replace
setblock ~274 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~854 ~289 ~157 ~854 minecraft:redstone_wire replace
setblock ~291 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~157 ~854 ~306 ~157 ~854 minecraft:redstone_wire replace
setblock ~308 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~157 ~854 ~321 ~157 ~854 minecraft:redstone_wire replace
setblock ~136 ~157 ~855 minecraft:redstone_wire replace
fill ~135 ~157 ~858 ~141 ~157 ~858 minecraft:redstone_wire replace
setblock ~143 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~858 ~158 ~157 ~858 minecraft:redstone_wire replace
setblock ~160 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~858 ~175 ~157 ~858 minecraft:redstone_wire replace
setblock ~177 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~858 ~192 ~157 ~858 minecraft:redstone_wire replace
setblock ~194 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~858 ~209 ~157 ~858 minecraft:redstone_wire replace
setblock ~211 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~858 ~226 ~157 ~858 minecraft:redstone_wire replace
setblock ~228 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~858 ~243 ~157 ~858 minecraft:redstone_wire replace
setblock ~245 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~858 ~260 ~157 ~858 minecraft:redstone_wire replace
setblock ~262 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~858 ~277 ~157 ~858 minecraft:redstone_wire replace
setblock ~279 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~858 ~294 ~157 ~858 minecraft:redstone_wire replace
setblock ~296 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~858 ~311 ~157 ~858 minecraft:redstone_wire replace
setblock ~313 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~157 ~858 ~324 ~157 ~858 minecraft:redstone_wire replace
setblock ~136 ~157 ~859 minecraft:redstone_wire replace
fill ~135 ~157 ~862 ~148 ~157 ~862 minecraft:redstone_wire replace
setblock ~150 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~862 ~165 ~157 ~862 minecraft:redstone_wire replace
setblock ~167 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~862 ~182 ~157 ~862 minecraft:redstone_wire replace
setblock ~184 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~862 ~199 ~157 ~862 minecraft:redstone_wire replace
setblock ~201 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~862 ~216 ~157 ~862 minecraft:redstone_wire replace
setblock ~218 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~862 ~233 ~157 ~862 minecraft:redstone_wire replace
setblock ~235 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~157 ~862 ~250 ~157 ~862 minecraft:redstone_wire replace
setblock ~252 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~157 ~862 ~267 ~157 ~862 minecraft:redstone_wire replace
setblock ~269 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~862 ~284 ~157 ~862 minecraft:redstone_wire replace
setblock ~286 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~157 ~862 ~301 ~157 ~862 minecraft:redstone_wire replace
setblock ~303 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~157 ~862 ~318 ~157 ~862 minecraft:redstone_wire replace
setblock ~320 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~157 ~862 ~327 ~157 ~862 minecraft:redstone_wire replace
setblock ~136 ~157 ~863 minecraft:redstone_wire replace
fill ~138 ~157 ~866 ~144 ~157 ~866 minecraft:redstone_wire replace
setblock ~146 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~157 ~866 ~161 ~157 ~866 minecraft:redstone_wire replace
setblock ~163 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~157 ~866 ~178 ~157 ~866 minecraft:redstone_wire replace
setblock ~180 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~157 ~866 ~195 ~157 ~866 minecraft:redstone_wire replace
setblock ~197 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~157 ~866 ~212 ~157 ~866 minecraft:redstone_wire replace
setblock ~214 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~157 ~866 ~229 ~157 ~866 minecraft:redstone_wire replace
setblock ~231 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~233 ~157 ~866 ~246 ~157 ~866 minecraft:redstone_wire replace
setblock ~248 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~157 ~866 ~263 ~157 ~866 minecraft:redstone_wire replace
setblock ~265 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~157 ~866 ~280 ~157 ~866 minecraft:redstone_wire replace
setblock ~282 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~284 ~157 ~866 ~297 ~157 ~866 minecraft:redstone_wire replace
setblock ~299 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~157 ~866 ~314 ~157 ~866 minecraft:redstone_wire replace
setblock ~316 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~157 ~866 ~330 ~157 ~866 minecraft:redstone_wire replace
setblock ~139 ~157 ~867 minecraft:redstone_wire replace
fill ~138 ~157 ~870 ~148 ~157 ~870 minecraft:redstone_wire replace
setblock ~150 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~870 ~165 ~157 ~870 minecraft:redstone_wire replace
setblock ~167 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~870 ~182 ~157 ~870 minecraft:redstone_wire replace
setblock ~184 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~870 ~199 ~157 ~870 minecraft:redstone_wire replace
setblock ~201 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~870 ~216 ~157 ~870 minecraft:redstone_wire replace
setblock ~218 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~870 ~233 ~157 ~870 minecraft:redstone_wire replace
setblock ~235 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~157 ~870 ~250 ~157 ~870 minecraft:redstone_wire replace
setblock ~252 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~157 ~870 ~267 ~157 ~870 minecraft:redstone_wire replace
setblock ~269 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~870 ~284 ~157 ~870 minecraft:redstone_wire replace
setblock ~286 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~157 ~870 ~301 ~157 ~870 minecraft:redstone_wire replace
setblock ~303 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~157 ~870 ~318 ~157 ~870 minecraft:redstone_wire replace
setblock ~320 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~157 ~870 ~333 ~157 ~870 minecraft:redstone_wire replace
setblock ~139 ~157 ~871 minecraft:redstone_wire replace
fill ~138 ~157 ~874 ~148 ~157 ~874 minecraft:redstone_wire replace
setblock ~150 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~874 ~164 ~157 ~874 minecraft:redstone_wire replace
setblock ~166 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~874 ~180 ~157 ~874 minecraft:redstone_wire replace
setblock ~182 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~874 ~196 ~157 ~874 minecraft:redstone_wire replace
setblock ~198 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~874 ~212 ~157 ~874 minecraft:redstone_wire replace
setblock ~214 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~157 ~874 ~228 ~157 ~874 minecraft:redstone_wire replace
setblock ~230 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~874 ~244 ~157 ~874 minecraft:redstone_wire replace
setblock ~246 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~248 ~157 ~874 ~260 ~157 ~874 minecraft:redstone_wire replace
setblock ~262 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~874 ~276 ~157 ~874 minecraft:redstone_wire replace
setblock ~278 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~874 ~292 ~157 ~874 minecraft:redstone_wire replace
setblock ~294 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~157 ~874 ~308 ~157 ~874 minecraft:redstone_wire replace
setblock ~310 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~874 ~324 ~157 ~874 minecraft:redstone_wire replace
setblock ~326 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~328 ~157 ~874 ~336 ~157 ~874 minecraft:redstone_wire replace
setblock ~139 ~157 ~875 minecraft:redstone_wire replace
fill ~138 ~157 ~878 ~143 ~157 ~878 minecraft:redstone_wire replace
setblock ~145 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~878 ~160 ~157 ~878 minecraft:redstone_wire replace
setblock ~162 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~878 ~177 ~157 ~878 minecraft:redstone_wire replace
setblock ~179 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~878 ~194 ~157 ~878 minecraft:redstone_wire replace
setblock ~196 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~878 ~211 ~157 ~878 minecraft:redstone_wire replace
setblock ~213 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~878 ~228 ~157 ~878 minecraft:redstone_wire replace
setblock ~230 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~878 ~245 ~157 ~878 minecraft:redstone_wire replace
setblock ~247 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~878 ~262 ~157 ~878 minecraft:redstone_wire replace
setblock ~264 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~878 ~279 ~157 ~878 minecraft:redstone_wire replace
setblock ~281 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~878 ~296 ~157 ~878 minecraft:redstone_wire replace
setblock ~298 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~878 ~313 ~157 ~878 minecraft:redstone_wire replace
setblock ~315 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~878 ~330 ~157 ~878 minecraft:redstone_wire replace
setblock ~332 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~878 ~339 ~157 ~878 minecraft:redstone_wire replace
setblock ~139 ~157 ~879 minecraft:redstone_wire replace
fill ~138 ~157 ~882 ~139 ~157 ~882 minecraft:redstone_wire replace
setblock ~141 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~882 ~156 ~157 ~882 minecraft:redstone_wire replace
setblock ~158 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~882 ~173 ~157 ~882 minecraft:redstone_wire replace
setblock ~175 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~882 ~190 ~157 ~882 minecraft:redstone_wire replace
setblock ~192 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~882 ~207 ~157 ~882 minecraft:redstone_wire replace
setblock ~209 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~882 ~224 ~157 ~882 minecraft:redstone_wire replace
setblock ~226 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~882 ~241 ~157 ~882 minecraft:redstone_wire replace
setblock ~243 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~882 ~258 ~157 ~882 minecraft:redstone_wire replace
setblock ~260 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~882 ~275 ~157 ~882 minecraft:redstone_wire replace
setblock ~277 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~157 ~882 ~292 ~157 ~882 minecraft:redstone_wire replace
setblock ~294 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~157 ~882 ~309 ~157 ~882 minecraft:redstone_wire replace
setblock ~311 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~157 ~882 ~326 ~157 ~882 minecraft:redstone_wire replace
setblock ~328 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~157 ~882 ~342 ~157 ~882 minecraft:redstone_wire replace
setblock ~139 ~157 ~883 minecraft:redstone_wire replace
fill ~138 ~157 ~886 ~143 ~157 ~886 minecraft:redstone_wire replace
setblock ~145 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~886 ~160 ~157 ~886 minecraft:redstone_wire replace
setblock ~162 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~886 ~177 ~157 ~886 minecraft:redstone_wire replace
setblock ~179 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~886 ~194 ~157 ~886 minecraft:redstone_wire replace
setblock ~196 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~886 ~211 ~157 ~886 minecraft:redstone_wire replace
setblock ~213 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~886 ~228 ~157 ~886 minecraft:redstone_wire replace
setblock ~230 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~886 ~245 ~157 ~886 minecraft:redstone_wire replace
setblock ~247 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~886 ~262 ~157 ~886 minecraft:redstone_wire replace
setblock ~264 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~886 ~279 ~157 ~886 minecraft:redstone_wire replace
setblock ~281 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~886 ~296 ~157 ~886 minecraft:redstone_wire replace
setblock ~298 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~886 ~313 ~157 ~886 minecraft:redstone_wire replace
setblock ~315 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~886 ~330 ~157 ~886 minecraft:redstone_wire replace
setblock ~332 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~886 ~345 ~157 ~886 minecraft:redstone_wire replace
setblock ~139 ~157 ~887 minecraft:redstone_wire replace
fill ~138 ~157 ~890 ~148 ~157 ~890 minecraft:redstone_wire replace
setblock ~150 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~890 ~165 ~157 ~890 minecraft:redstone_wire replace
setblock ~167 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~890 ~182 ~157 ~890 minecraft:redstone_wire replace
setblock ~184 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~890 ~199 ~157 ~890 minecraft:redstone_wire replace
setblock ~201 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~890 ~216 ~157 ~890 minecraft:redstone_wire replace
setblock ~218 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~890 ~233 ~157 ~890 minecraft:redstone_wire replace
setblock ~235 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~157 ~890 ~250 ~157 ~890 minecraft:redstone_wire replace
