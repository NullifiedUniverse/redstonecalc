setblock ~298 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~25 ~82 ~313 ~25 ~82 minecraft:redstone_wire replace
setblock ~315 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~25 ~82 ~330 ~25 ~82 minecraft:redstone_wire replace
setblock ~332 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~25 ~82 ~344 ~25 ~82 minecraft:redstone_wire replace
setblock ~82 ~25 ~85 minecraft:redstone_wire replace
fill ~81 ~25 ~86 ~83 ~25 ~86 minecraft:redstone_wire replace
setblock ~85 ~25 ~89 minecraft:redstone_wire replace
fill ~84 ~25 ~90 ~86 ~25 ~90 minecraft:redstone_wire replace
setblock ~88 ~25 ~93 minecraft:redstone_wire replace
fill ~87 ~25 ~94 ~89 ~25 ~94 minecraft:redstone_wire replace
setblock ~133 ~25 ~101 minecraft:redstone_wire replace
setblock ~136 ~25 ~101 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~25 ~102 ~126 ~25 ~102 minecraft:redstone_wire replace
setblock ~128 ~25 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~25 ~102 ~137 ~25 ~102 minecraft:redstone_wire replace
setblock ~103 ~25 ~105 minecraft:redstone_wire replace
fill ~93 ~25 ~106 ~99 ~25 ~106 minecraft:redstone_wire replace
setblock ~101 ~25 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~25 ~106 ~104 ~25 ~106 minecraft:redstone_wire replace
setblock ~106 ~25 ~109 minecraft:redstone_wire replace
fill ~96 ~25 ~110 ~102 ~25 ~110 minecraft:redstone_wire replace
setblock ~104 ~25 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~25 ~110 ~107 ~25 ~110 minecraft:redstone_wire replace
setblock ~109 ~25 ~113 minecraft:redstone_wire replace
fill ~99 ~25 ~114 ~110 ~25 ~114 minecraft:redstone_wire replace
setblock ~157 ~25 ~121 minecraft:redstone_wire replace
setblock ~160 ~25 ~121 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~25 ~122 ~138 ~25 ~122 minecraft:redstone_wire replace
setblock ~140 ~25 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~25 ~122 ~155 ~25 ~122 minecraft:redstone_wire replace
setblock ~156 ~25 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~25 ~122 ~161 ~25 ~122 minecraft:redstone_wire replace
setblock ~121 ~25 ~125 minecraft:redstone_wire replace
fill ~111 ~25 ~126 ~117 ~25 ~126 minecraft:redstone_wire replace
setblock ~119 ~25 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~25 ~126 ~122 ~25 ~126 minecraft:redstone_wire replace
setblock ~124 ~25 ~129 minecraft:redstone_wire replace
fill ~114 ~25 ~130 ~120 ~25 ~130 minecraft:redstone_wire replace
setblock ~122 ~25 ~130 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~25 ~130 ~125 ~25 ~130 minecraft:redstone_wire replace
setblock ~130 ~25 ~133 minecraft:redstone_wire replace
fill ~117 ~25 ~134 ~128 ~25 ~134 minecraft:redstone_wire replace
setblock ~129 ~25 ~134 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~25 ~134 ~131 ~25 ~134 minecraft:redstone_wire replace
setblock ~181 ~25 ~141 minecraft:redstone_wire replace
setblock ~184 ~25 ~141 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~25 ~142 ~153 ~25 ~142 minecraft:redstone_wire replace
setblock ~155 ~25 ~142 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~25 ~142 ~170 ~25 ~142 minecraft:redstone_wire replace
setblock ~172 ~25 ~142 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~25 ~142 ~185 ~25 ~142 minecraft:redstone_wire replace
setblock ~151 ~25 ~145 minecraft:redstone_wire replace
fill ~129 ~25 ~146 ~135 ~25 ~146 minecraft:redstone_wire replace
setblock ~137 ~25 ~146 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~25 ~146 ~152 ~25 ~146 minecraft:redstone_wire replace
setblock ~166 ~25 ~149 minecraft:redstone_wire replace
fill ~138 ~25 ~150 ~144 ~25 ~150 minecraft:redstone_wire replace
setblock ~146 ~25 ~150 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~25 ~150 ~161 ~25 ~150 minecraft:redstone_wire replace
setblock ~163 ~25 ~150 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~25 ~150 ~167 ~25 ~150 minecraft:redstone_wire replace
setblock ~169 ~25 ~153 minecraft:redstone_wire replace
fill ~141 ~25 ~154 ~153 ~25 ~154 minecraft:redstone_wire replace
setblock ~155 ~25 ~154 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~25 ~154 ~170 ~25 ~154 minecraft:redstone_wire replace
setblock ~211 ~25 ~157 minecraft:redstone_wire replace
setblock ~214 ~25 ~157 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~25 ~158 ~192 ~25 ~158 minecraft:redstone_wire replace
setblock ~194 ~25 ~158 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~25 ~158 ~209 ~25 ~158 minecraft:redstone_wire replace
setblock ~210 ~25 ~158 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~25 ~158 ~215 ~25 ~158 minecraft:redstone_wire replace
setblock ~190 ~25 ~161 minecraft:redstone_wire replace
fill ~153 ~25 ~162 ~165 ~25 ~162 minecraft:redstone_wire replace
setblock ~167 ~25 ~162 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~25 ~162 ~182 ~25 ~162 minecraft:redstone_wire replace
setblock ~184 ~25 ~162 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~25 ~162 ~191 ~25 ~162 minecraft:redstone_wire replace
setblock ~193 ~25 ~165 minecraft:redstone_wire replace
fill ~156 ~25 ~166 ~168 ~25 ~166 minecraft:redstone_wire replace
setblock ~170 ~25 ~166 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~25 ~166 ~185 ~25 ~166 minecraft:redstone_wire replace
setblock ~187 ~25 ~166 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~25 ~166 ~194 ~25 ~166 minecraft:redstone_wire replace
setblock ~196 ~25 ~169 minecraft:redstone_wire replace
fill ~159 ~25 ~170 ~171 ~25 ~170 minecraft:redstone_wire replace
setblock ~173 ~25 ~170 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~25 ~170 ~188 ~25 ~170 minecraft:redstone_wire replace
setblock ~190 ~25 ~170 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~25 ~170 ~197 ~25 ~170 minecraft:redstone_wire replace
setblock ~229 ~25 ~173 minecraft:redstone_wire replace
setblock ~232 ~25 ~173 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~25 ~174 ~213 ~25 ~174 minecraft:redstone_wire replace
setblock ~215 ~25 ~174 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~25 ~174 ~230 ~25 ~174 minecraft:redstone_wire replace
setblock ~231 ~25 ~174 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~25 ~174 ~233 ~25 ~174 minecraft:redstone_wire replace
setblock ~217 ~25 ~177 minecraft:redstone_wire replace
fill ~189 ~25 ~178 ~201 ~25 ~178 minecraft:redstone_wire replace
setblock ~203 ~25 ~178 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~25 ~178 ~218 ~25 ~178 minecraft:redstone_wire replace
setblock ~220 ~25 ~181 minecraft:redstone_wire replace
fill ~192 ~25 ~182 ~204 ~25 ~182 minecraft:redstone_wire replace
setblock ~206 ~25 ~182 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~25 ~182 ~221 ~25 ~182 minecraft:redstone_wire replace
setblock ~223 ~25 ~185 minecraft:redstone_wire replace
fill ~195 ~25 ~186 ~206 ~25 ~186 minecraft:redstone_wire replace
setblock ~208 ~25 ~186 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~25 ~186 ~223 ~25 ~186 minecraft:redstone_wire replace
setblock ~224 ~25 ~186 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~253 ~25 ~189 minecraft:redstone_wire replace
setblock ~256 ~25 ~189 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~25 ~190 ~227 ~25 ~190 minecraft:redstone_wire replace
setblock ~229 ~25 ~190 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~231 ~25 ~190 ~244 ~25 ~190 minecraft:redstone_wire replace
setblock ~246 ~25 ~190 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~248 ~25 ~190 ~257 ~25 ~190 minecraft:redstone_wire replace
setblock ~244 ~25 ~193 minecraft:redstone_wire replace
fill ~210 ~25 ~194 ~221 ~25 ~194 minecraft:redstone_wire replace
setblock ~223 ~25 ~194 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~25 ~194 ~238 ~25 ~194 minecraft:redstone_wire replace
setblock ~240 ~25 ~194 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~242 ~25 ~194 ~245 ~25 ~194 minecraft:redstone_wire replace
setblock ~247 ~25 ~197 minecraft:redstone_wire replace
fill ~213 ~25 ~198 ~224 ~25 ~198 minecraft:redstone_wire replace
setblock ~226 ~25 ~198 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~25 ~198 ~241 ~25 ~198 minecraft:redstone_wire replace
setblock ~243 ~25 ~198 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~25 ~198 ~248 ~25 ~198 minecraft:redstone_wire replace
setblock ~259 ~25 ~201 minecraft:redstone_wire replace
fill ~219 ~25 ~202 ~226 ~25 ~202 minecraft:redstone_wire replace
setblock ~228 ~25 ~202 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~25 ~202 ~243 ~25 ~202 minecraft:redstone_wire replace
setblock ~245 ~25 ~202 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~25 ~202 ~260 ~25 ~202 minecraft:redstone_wire replace
setblock ~286 ~25 ~205 minecraft:redstone_wire replace
setblock ~289 ~25 ~205 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~25 ~206 ~250 ~25 ~206 minecraft:redstone_wire replace
setblock ~252 ~25 ~206 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~254 ~25 ~206 ~267 ~25 ~206 minecraft:redstone_wire replace
setblock ~269 ~25 ~206 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~271 ~25 ~206 ~284 ~25 ~206 minecraft:redstone_wire replace
setblock ~285 ~25 ~206 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~25 ~206 ~290 ~25 ~206 minecraft:redstone_wire replace
setblock ~295 ~25 ~209 minecraft:redstone_wire replace
setblock ~298 ~25 ~209 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~25 ~210 ~253 ~25 ~210 minecraft:redstone_wire replace
setblock ~255 ~25 ~210 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~257 ~25 ~210 ~270 ~25 ~210 minecraft:redstone_wire replace
setblock ~272 ~25 ~210 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~274 ~25 ~210 ~287 ~25 ~210 minecraft:redstone_wire replace
setblock ~289 ~25 ~210 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~25 ~210 ~299 ~25 ~210 minecraft:redstone_wire replace
setblock ~319 ~25 ~213 minecraft:redstone_wire replace
fill ~258 ~25 ~214 ~265 ~25 ~214 minecraft:redstone_wire replace
setblock ~267 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~25 ~214 ~282 ~25 ~214 minecraft:redstone_wire replace
setblock ~284 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~25 ~214 ~299 ~25 ~214 minecraft:redstone_wire replace
setblock ~301 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~25 ~214 ~316 ~25 ~214 minecraft:redstone_wire replace
setblock ~317 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~25 ~214 ~320 ~25 ~214 minecraft:redstone_wire replace
setblock ~331 ~25 ~217 minecraft:redstone_wire replace
fill ~267 ~25 ~218 ~274 ~25 ~218 minecraft:redstone_wire replace
setblock ~276 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~278 ~25 ~218 ~291 ~25 ~218 minecraft:redstone_wire replace
setblock ~293 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~25 ~218 ~308 ~25 ~218 minecraft:redstone_wire replace
setblock ~310 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~25 ~218 ~325 ~25 ~218 minecraft:redstone_wire replace
setblock ~327 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~25 ~218 ~332 ~25 ~218 minecraft:redstone_wire replace
setblock ~334 ~25 ~221 minecraft:redstone_wire replace
fill ~270 ~25 ~222 ~281 ~25 ~222 minecraft:redstone_wire replace
setblock ~283 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~25 ~222 ~297 ~25 ~222 minecraft:redstone_wire replace
setblock ~299 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~25 ~222 ~313 ~25 ~222 minecraft:redstone_wire replace
setblock ~315 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~25 ~222 ~329 ~25 ~222 minecraft:redstone_wire replace
setblock ~331 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~333 ~25 ~222 ~335 ~25 ~222 minecraft:redstone_wire replace
setblock ~268 ~25 ~225 minecraft:redstone_wire replace
fill ~228 ~25 ~226 ~240 ~25 ~226 minecraft:redstone_wire replace
setblock ~242 ~25 ~226 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~25 ~226 ~257 ~25 ~226 minecraft:redstone_wire replace
setblock ~259 ~25 ~226 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~25 ~226 ~269 ~25 ~226 minecraft:redstone_wire replace
setblock ~274 ~25 ~229 minecraft:redstone_wire replace
fill ~234 ~25 ~230 ~246 ~25 ~230 minecraft:redstone_wire replace
setblock ~248 ~25 ~230 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~25 ~230 ~263 ~25 ~230 minecraft:redstone_wire replace
setblock ~265 ~25 ~230 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~25 ~230 ~275 ~25 ~230 minecraft:redstone_wire replace
setblock ~277 ~25 ~233 minecraft:redstone_wire replace
fill ~237 ~25 ~234 ~249 ~25 ~234 minecraft:redstone_wire replace
setblock ~251 ~25 ~234 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~25 ~234 ~266 ~25 ~234 minecraft:redstone_wire replace
setblock ~268 ~25 ~234 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~25 ~234 ~278 ~25 ~234 minecraft:redstone_wire replace
setblock ~304 ~25 ~237 minecraft:redstone_wire replace
setblock ~307 ~25 ~237 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~25 ~238 ~264 ~25 ~238 minecraft:redstone_wire replace
setblock ~266 ~25 ~238 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~25 ~238 ~281 ~25 ~238 minecraft:redstone_wire replace
setblock ~283 ~25 ~238 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~25 ~238 ~298 ~25 ~238 minecraft:redstone_wire replace
setblock ~300 ~25 ~238 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~25 ~238 ~308 ~25 ~238 minecraft:redstone_wire replace
setblock ~322 ~25 ~241 minecraft:redstone_wire replace
setblock ~325 ~25 ~241 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~25 ~242 ~276 ~25 ~242 minecraft:redstone_wire replace
setblock ~278 ~25 ~242 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~25 ~242 ~293 ~25 ~242 minecraft:redstone_wire replace
setblock ~295 ~25 ~242 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~25 ~242 ~310 ~25 ~242 minecraft:redstone_wire replace
setblock ~312 ~25 ~242 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~25 ~242 ~326 ~25 ~242 minecraft:redstone_wire replace
setblock ~346 ~25 ~245 minecraft:redstone_wire replace
fill ~276 ~25 ~246 ~288 ~25 ~246 minecraft:redstone_wire replace
setblock ~290 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~246 ~305 ~25 ~246 minecraft:redstone_wire replace
setblock ~307 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~25 ~246 ~322 ~25 ~246 minecraft:redstone_wire replace
setblock ~324 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~326 ~25 ~246 ~339 ~25 ~246 minecraft:redstone_wire replace
setblock ~341 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~343 ~25 ~246 ~347 ~25 ~246 minecraft:redstone_wire replace
setblock ~349 ~25 ~249 minecraft:redstone_wire replace
fill ~279 ~25 ~250 ~291 ~25 ~250 minecraft:redstone_wire replace
setblock ~293 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~25 ~250 ~308 ~25 ~250 minecraft:redstone_wire replace
setblock ~310 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~25 ~250 ~325 ~25 ~250 minecraft:redstone_wire replace
setblock ~327 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~25 ~250 ~342 ~25 ~250 minecraft:redstone_wire replace
setblock ~344 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~346 ~25 ~250 ~350 ~25 ~250 minecraft:redstone_wire replace
setblock ~352 ~25 ~253 minecraft:redstone_wire replace
fill ~282 ~25 ~254 ~293 ~25 ~254 minecraft:redstone_wire replace
setblock ~295 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~25 ~254 ~310 ~25 ~254 minecraft:redstone_wire replace
setblock ~312 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~25 ~254 ~327 ~25 ~254 minecraft:redstone_wire replace
setblock ~329 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~25 ~254 ~344 ~25 ~254 minecraft:redstone_wire replace
setblock ~346 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~25 ~254 ~353 ~25 ~254 minecraft:redstone_wire replace
setblock ~133 ~25 ~257 minecraft:redstone_wire replace
setblock ~136 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~25 ~257 minecraft:redstone_wire replace
setblock ~157 ~25 ~257 minecraft:redstone_wire replace
setblock ~160 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~25 ~257 minecraft:redstone_wire replace
setblock ~184 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~25 ~257 minecraft:redstone_wire replace
setblock ~214 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~229 ~25 ~257 minecraft:redstone_wire replace
setblock ~232 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~25 ~257 minecraft:redstone_wire replace
setblock ~256 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~25 ~257 minecraft:redstone_wire replace
setblock ~289 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~25 ~257 minecraft:redstone_wire replace
setblock ~298 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~25 ~257 minecraft:redstone_wire replace
setblock ~307 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~25 ~257 minecraft:redstone_wire replace
setblock ~325 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~25 ~258 ~142 ~25 ~258 minecraft:redstone_wire replace
setblock ~144 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~25 ~258 ~158 ~25 ~258 minecraft:redstone_wire replace
setblock ~159 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~25 ~258 ~173 ~25 ~258 minecraft:redstone_wire replace
setblock ~175 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~25 ~258 ~189 ~25 ~258 minecraft:redstone_wire replace
setblock ~191 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~25 ~258 ~216 ~25 ~258 minecraft:redstone_wire replace
setblock ~218 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~25 ~258 ~233 ~25 ~258 minecraft:redstone_wire replace
setblock ~235 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~25 ~258 ~250 ~25 ~258 minecraft:redstone_wire replace
setblock ~251 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~25 ~258 ~265 ~25 ~258 minecraft:redstone_wire replace
setblock ~267 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~25 ~258 ~282 ~25 ~258 minecraft:redstone_wire replace
setblock ~284 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~25 ~258 ~299 ~25 ~258 minecraft:redstone_wire replace
setblock ~301 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~25 ~258 ~316 ~25 ~258 minecraft:redstone_wire replace
setblock ~318 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~320 ~25 ~258 ~326 ~25 ~258 minecraft:redstone_wire replace
setblock ~91 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~172 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~199 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~235 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~280 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~25 ~262 ~92 ~25 ~262 minecraft:redstone_wire replace
setblock ~93 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~25 ~262 ~107 ~25 ~262 minecraft:redstone_wire replace
setblock ~109 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~25 ~262 ~124 ~25 ~262 minecraft:redstone_wire replace
setblock ~126 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~25 ~262 ~141 ~25 ~262 minecraft:redstone_wire replace
setblock ~143 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~25 ~262 ~158 ~25 ~262 minecraft:redstone_wire replace
setblock ~160 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~25 ~262 ~175 ~25 ~262 minecraft:redstone_wire replace
setblock ~177 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~25 ~262 ~192 ~25 ~262 minecraft:redstone_wire replace
setblock ~194 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~25 ~262 ~208 ~25 ~262 minecraft:redstone_wire replace
setblock ~210 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~25 ~262 ~224 ~25 ~262 minecraft:redstone_wire replace
setblock ~226 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~25 ~262 ~240 ~25 ~262 minecraft:redstone_wire replace
setblock ~242 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~25 ~262 ~256 ~25 ~262 minecraft:redstone_wire replace
setblock ~258 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~260 ~25 ~262 ~272 ~25 ~262 minecraft:redstone_wire replace
setblock ~274 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~25 ~262 ~288 ~25 ~262 minecraft:redstone_wire replace
setblock ~290 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~262 ~304 ~25 ~262 minecraft:redstone_wire replace
setblock ~306 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~308 ~25 ~262 ~320 ~25 ~262 minecraft:redstone_wire replace
setblock ~322 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~324 ~25 ~262 ~336 ~25 ~262 minecraft:redstone_wire replace
setblock ~338 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~340 ~25 ~262 ~341 ~25 ~262 minecraft:redstone_wire replace
setblock ~88 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~109 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~196 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~25 ~266 ~91 ~25 ~266 minecraft:redstone_wire replace
setblock ~93 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~25 ~266 ~107 ~25 ~266 minecraft:redstone_wire replace
setblock ~108 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~25 ~266 ~121 ~25 ~266 minecraft:redstone_wire replace
setblock ~123 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~25 ~266 ~137 ~25 ~266 minecraft:redstone_wire replace
setblock ~139 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~25 ~266 ~153 ~25 ~266 minecraft:redstone_wire replace
setblock ~155 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~25 ~266 ~169 ~25 ~266 minecraft:redstone_wire replace
setblock ~171 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~25 ~266 ~194 ~25 ~266 minecraft:redstone_wire replace
setblock ~195 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~25 ~266 ~209 ~25 ~266 minecraft:redstone_wire replace
setblock ~211 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~25 ~266 ~226 ~25 ~266 minecraft:redstone_wire replace
setblock ~228 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~25 ~266 ~243 ~25 ~266 minecraft:redstone_wire replace
setblock ~245 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~25 ~266 ~260 ~25 ~266 minecraft:redstone_wire replace
setblock ~262 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~25 ~266 ~277 ~25 ~266 minecraft:redstone_wire replace
setblock ~278 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~25 ~266 ~292 ~25 ~266 minecraft:redstone_wire replace
setblock ~294 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~25 ~266 ~309 ~25 ~266 minecraft:redstone_wire replace
setblock ~311 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~313 ~25 ~266 ~326 ~25 ~266 minecraft:redstone_wire replace
setblock ~328 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~25 ~266 ~343 ~25 ~266 minecraft:redstone_wire replace
setblock ~345 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~347 ~25 ~266 ~353 ~25 ~266 minecraft:redstone_wire replace
setblock ~85 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~106 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~124 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~166 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~193 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~247 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~274 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~25 ~270 ~93 ~25 ~270 minecraft:redstone_wire replace
setblock ~95 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~25 ~270 ~110 ~25 ~270 minecraft:redstone_wire replace
setblock ~112 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~25 ~270 ~127 ~25 ~270 minecraft:redstone_wire replace
setblock ~129 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~25 ~270 ~144 ~25 ~270 minecraft:redstone_wire replace
setblock ~146 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~25 ~270 ~161 ~25 ~270 minecraft:redstone_wire replace
setblock ~163 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~25 ~270 ~189 ~25 ~270 minecraft:redstone_wire replace
setblock ~191 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~25 ~270 ~206 ~25 ~270 minecraft:redstone_wire replace
setblock ~208 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~25 ~270 ~223 ~25 ~270 minecraft:redstone_wire replace
setblock ~225 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~227 ~25 ~270 ~240 ~25 ~270 minecraft:redstone_wire replace
setblock ~242 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~25 ~270 ~257 ~25 ~270 minecraft:redstone_wire replace
setblock ~259 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~25 ~270 ~274 ~25 ~270 minecraft:redstone_wire replace
setblock ~275 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~25 ~270 ~289 ~25 ~270 minecraft:redstone_wire replace
setblock ~291 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~293 ~25 ~270 ~306 ~25 ~270 minecraft:redstone_wire replace
setblock ~308 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~25 ~270 ~323 ~25 ~270 minecraft:redstone_wire replace
setblock ~325 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~25 ~270 ~340 ~25 ~270 minecraft:redstone_wire replace
setblock ~342 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~25 ~270 ~350 ~25 ~270 minecraft:redstone_wire replace
setblock ~82 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~103 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~121 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~151 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~268 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~319 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~346 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~25 ~274 ~87 ~25 ~274 minecraft:redstone_wire replace
setblock ~89 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~91 ~25 ~274 ~104 ~25 ~274 minecraft:redstone_wire replace
setblock ~106 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~25 ~274 ~121 ~25 ~274 minecraft:redstone_wire replace
setblock ~123 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~25 ~274 ~138 ~25 ~274 minecraft:redstone_wire replace
setblock ~140 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~25 ~274 ~155 ~25 ~274 minecraft:redstone_wire replace
setblock ~157 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~25 ~274 ~183 ~25 ~274 minecraft:redstone_wire replace
setblock ~185 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~25 ~274 ~200 ~25 ~274 minecraft:redstone_wire replace
setblock ~202 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~25 ~274 ~217 ~25 ~274 minecraft:redstone_wire replace
setblock ~218 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~219 ~25 ~274 ~232 ~25 ~274 minecraft:redstone_wire replace
setblock ~234 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~236 ~25 ~274 ~249 ~25 ~274 minecraft:redstone_wire replace
setblock ~251 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~25 ~274 ~266 ~25 ~274 minecraft:redstone_wire replace
setblock ~267 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~25 ~274 ~281 ~25 ~274 minecraft:redstone_wire replace
setblock ~283 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~25 ~274 ~298 ~25 ~274 minecraft:redstone_wire replace
setblock ~300 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~25 ~274 ~315 ~25 ~274 minecraft:redstone_wire replace
setblock ~317 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~319 ~25 ~274 ~332 ~25 ~274 minecraft:redstone_wire replace
setblock ~334 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~336 ~25 ~274 ~347 ~25 ~274 minecraft:redstone_wire replace
setblock ~79 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~100 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~118 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~145 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~205 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~241 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~265 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~343 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~25 ~278 ~86 ~25 ~278 minecraft:redstone_wire replace
setblock ~88 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~25 ~278 ~103 ~25 ~278 minecraft:redstone_wire replace
setblock ~105 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~25 ~278 ~120 ~25 ~278 minecraft:redstone_wire replace
setblock ~122 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~25 ~278 ~137 ~25 ~278 minecraft:redstone_wire replace
setblock ~139 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~25 ~278 ~154 ~25 ~278 minecraft:redstone_wire replace
setblock ~156 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~25 ~278 ~171 ~25 ~278 minecraft:redstone_wire replace
setblock ~173 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~25 ~278 ~187 ~25 ~278 minecraft:redstone_wire replace
setblock ~188 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~25 ~278 ~201 ~25 ~278 minecraft:redstone_wire replace
setblock ~203 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~25 ~278 ~217 ~25 ~278 minecraft:redstone_wire replace
setblock ~219 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~25 ~278 ~233 ~25 ~278 minecraft:redstone_wire replace
setblock ~235 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~25 ~278 ~249 ~25 ~278 minecraft:redstone_wire replace
setblock ~251 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~25 ~278 ~265 ~25 ~278 minecraft:redstone_wire replace
setblock ~266 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~25 ~278 ~279 ~25 ~278 minecraft:redstone_wire replace
setblock ~281 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~25 ~278 ~295 ~25 ~278 minecraft:redstone_wire replace
setblock ~297 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~299 ~25 ~278 ~311 ~25 ~278 minecraft:redstone_wire replace
setblock ~313 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~25 ~278 ~327 ~25 ~278 minecraft:redstone_wire replace
setblock ~329 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~25 ~278 ~343 ~25 ~278 minecraft:redstone_wire replace
setblock ~344 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~94 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~97 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~175 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~271 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~25 ~282 ~98 ~25 ~282 minecraft:redstone_wire replace
setblock ~100 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~25 ~282 ~115 ~25 ~282 minecraft:redstone_wire replace
setblock ~116 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~25 ~282 ~130 ~25 ~282 minecraft:redstone_wire replace
setblock ~132 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~25 ~282 ~147 ~25 ~282 minecraft:redstone_wire replace
setblock ~149 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~25 ~282 ~173 ~25 ~282 minecraft:redstone_wire replace
setblock ~174 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~25 ~282 ~188 ~25 ~282 minecraft:redstone_wire replace
setblock ~190 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~25 ~282 ~205 ~25 ~282 minecraft:redstone_wire replace
setblock ~207 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~209 ~25 ~282 ~222 ~25 ~282 minecraft:redstone_wire replace
setblock ~224 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~25 ~282 ~239 ~25 ~282 minecraft:redstone_wire replace
setblock ~241 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~243 ~25 ~282 ~256 ~25 ~282 minecraft:redstone_wire replace
setblock ~258 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~260 ~25 ~282 ~273 ~25 ~282 minecraft:redstone_wire replace
setblock ~275 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~277 ~25 ~282 ~290 ~25 ~282 minecraft:redstone_wire replace
setblock ~291 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~282 ~305 ~25 ~282 minecraft:redstone_wire replace
setblock ~307 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~25 ~282 ~322 ~25 ~282 minecraft:redstone_wire replace
setblock ~324 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~326 ~25 ~282 ~338 ~25 ~282 minecraft:redstone_wire replace
setblock ~163 ~25 ~285 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~25 ~286 ~147 ~25 ~286 minecraft:redstone_wire replace
setblock ~149 ~25 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~151 ~25 ~286 ~164 ~25 ~286 minecraft:redstone_wire replace
setblock ~358 ~25 ~297 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~25 ~298 ~291 ~25 ~298 minecraft:redstone_wire replace
setblock ~293 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~25 ~298 ~308 ~25 ~298 minecraft:redstone_wire replace
setblock ~310 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~25 ~298 ~325 ~25 ~298 minecraft:redstone_wire replace
setblock ~327 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~25 ~298 ~342 ~25 ~298 minecraft:redstone_wire replace
setblock ~344 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~346 ~25 ~298 ~359 ~25 ~298 minecraft:redstone_wire replace
setblock ~94 ~25 ~301 minecraft:redstone_wire replace
setblock ~340 ~25 ~301 minecraft:redstone_wire replace
setblock ~355 ~25 ~301 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~25 ~302 ~95 ~25 ~302 minecraft:redstone_wire replace
setblock ~96 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~25 ~302 ~110 ~25 ~302 minecraft:redstone_wire replace
setblock ~112 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~25 ~302 ~127 ~25 ~302 minecraft:redstone_wire replace
setblock ~129 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~25 ~302 ~144 ~25 ~302 minecraft:redstone_wire replace
setblock ~146 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~25 ~302 ~161 ~25 ~302 minecraft:redstone_wire replace
setblock ~163 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~25 ~302 ~178 ~25 ~302 minecraft:redstone_wire replace
setblock ~180 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~25 ~302 ~195 ~25 ~302 minecraft:redstone_wire replace
setblock ~197 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~25 ~302 ~212 ~25 ~302 minecraft:redstone_wire replace
setblock ~214 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~25 ~302 ~228 ~25 ~302 minecraft:redstone_wire replace
setblock ~230 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~25 ~302 ~245 ~25 ~302 minecraft:redstone_wire replace
setblock ~247 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~25 ~302 ~262 ~25 ~302 minecraft:redstone_wire replace
setblock ~264 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~266 ~25 ~302 ~279 ~25 ~302 minecraft:redstone_wire replace
setblock ~281 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~25 ~302 ~296 ~25 ~302 minecraft:redstone_wire replace
setblock ~298 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~25 ~302 ~313 ~25 ~302 minecraft:redstone_wire replace
setblock ~315 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~25 ~302 ~330 ~25 ~302 minecraft:redstone_wire replace
setblock ~332 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~25 ~302 ~347 ~25 ~302 minecraft:redstone_wire replace
setblock ~349 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~25 ~302 ~356 ~25 ~302 minecraft:redstone_wire replace
setblock ~79 ~26 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~26 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~26 ~8 minecraft:redstone_wire replace
setblock ~100 ~26 ~12 minecraft:redstone_torch[lit=true] replace
