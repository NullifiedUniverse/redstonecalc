fill ~348 ~27 ~360 ~348 ~27 ~372 minecraft:redstone_wire replace
setblock ~351 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~360 ~357 ~27 ~372 minecraft:redstone_wire replace
fill ~87 ~27 ~362 ~87 ~27 ~374 minecraft:redstone_wire replace
setblock ~99 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~362 ~270 ~27 ~374 minecraft:redstone_wire replace
setblock ~279 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~362 ~333 ~27 ~374 minecraft:redstone_wire replace
fill ~351 ~27 ~362 ~351 ~27 ~374 minecraft:redstone_wire replace
setblock ~354 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~364 ~99 ~27 ~376 minecraft:redstone_wire replace
fill ~105 ~27 ~364 ~105 ~27 ~376 minecraft:redstone_wire replace
fill ~120 ~27 ~364 ~120 ~27 ~376 minecraft:redstone_wire replace
setblock ~123 ~27 ~364 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~364 ~144 ~27 ~376 minecraft:redstone_wire replace
fill ~162 ~27 ~364 ~162 ~27 ~376 minecraft:redstone_wire replace
fill ~204 ~27 ~364 ~204 ~27 ~376 minecraft:redstone_wire replace
fill ~261 ~27 ~364 ~261 ~27 ~368 minecraft:redstone_wire replace
fill ~279 ~27 ~364 ~279 ~27 ~370 minecraft:redstone_wire replace
fill ~354 ~27 ~364 ~354 ~27 ~376 minecraft:redstone_wire replace
setblock ~108 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~366 ~123 ~27 ~378 minecraft:redstone_wire replace
setblock ~150 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~27 ~368 ~108 ~27 ~380 minecraft:redstone_wire replace
fill ~114 ~27 ~368 ~114 ~27 ~380 minecraft:redstone_wire replace
fill ~150 ~27 ~368 ~150 ~27 ~380 minecraft:redstone_wire replace
fill ~174 ~27 ~368 ~174 ~27 ~380 minecraft:redstone_wire replace
fill ~189 ~27 ~368 ~189 ~27 ~380 minecraft:redstone_wire replace
fill ~216 ~27 ~368 ~216 ~27 ~380 minecraft:redstone_wire replace
fill ~237 ~27 ~368 ~237 ~27 ~380 minecraft:redstone_wire replace
fill ~243 ~27 ~368 ~243 ~27 ~380 minecraft:redstone_wire replace
fill ~267 ~27 ~368 ~267 ~27 ~380 minecraft:redstone_wire replace
fill ~315 ~27 ~368 ~315 ~27 ~380 minecraft:redstone_wire replace
setblock ~318 ~27 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~368 ~342 ~27 ~380 minecraft:redstone_wire replace
setblock ~345 ~27 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~370 ~81 ~27 ~382 minecraft:redstone_wire replace
setblock ~117 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~370 ~318 ~27 ~382 minecraft:redstone_wire replace
setblock ~339 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~370 ~345 ~27 ~382 minecraft:redstone_wire replace
fill ~78 ~27 ~372 ~78 ~27 ~384 minecraft:redstone_wire replace
fill ~117 ~27 ~372 ~117 ~27 ~384 minecraft:redstone_wire replace
fill ~129 ~27 ~372 ~129 ~27 ~384 minecraft:redstone_wire replace
fill ~165 ~27 ~372 ~165 ~27 ~384 minecraft:redstone_wire replace
fill ~186 ~27 ~372 ~186 ~27 ~384 minecraft:redstone_wire replace
fill ~192 ~27 ~372 ~192 ~27 ~384 minecraft:redstone_wire replace
fill ~219 ~27 ~372 ~219 ~27 ~384 minecraft:redstone_wire replace
fill ~240 ~27 ~372 ~240 ~27 ~384 minecraft:redstone_wire replace
fill ~246 ~27 ~372 ~246 ~27 ~384 minecraft:redstone_wire replace
fill ~264 ~27 ~372 ~264 ~27 ~384 minecraft:redstone_wire replace
fill ~273 ~27 ~372 ~273 ~27 ~384 minecraft:redstone_wire replace
setblock ~279 ~27 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~372 ~339 ~27 ~384 minecraft:redstone_wire replace
setblock ~84 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~374 ~312 ~27 ~376 minecraft:redstone_wire replace
setblock ~330 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~376 ~84 ~27 ~388 minecraft:redstone_wire replace
setblock ~87 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~376 ~93 ~27 ~388 minecraft:redstone_wire replace
fill ~96 ~27 ~376 ~96 ~27 ~388 minecraft:redstone_wire replace
fill ~102 ~27 ~376 ~102 ~27 ~388 minecraft:redstone_wire replace
fill ~141 ~27 ~376 ~141 ~27 ~388 minecraft:redstone_wire replace
fill ~168 ~27 ~376 ~168 ~27 ~388 minecraft:redstone_wire replace
fill ~195 ~27 ~376 ~195 ~27 ~388 minecraft:redstone_wire replace
fill ~201 ~27 ~376 ~201 ~27 ~388 minecraft:redstone_wire replace
fill ~222 ~27 ~376 ~222 ~27 ~388 minecraft:redstone_wire replace
fill ~258 ~27 ~376 ~258 ~27 ~388 minecraft:redstone_wire replace
setblock ~270 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~376 ~276 ~27 ~388 minecraft:redstone_wire replace
fill ~291 ~27 ~376 ~291 ~27 ~388 minecraft:redstone_wire replace
fill ~330 ~27 ~376 ~330 ~27 ~388 minecraft:redstone_wire replace
setblock ~333 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~376 ~336 ~27 ~388 minecraft:redstone_wire replace
fill ~348 ~27 ~376 ~348 ~27 ~388 minecraft:redstone_wire replace
setblock ~351 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~376 ~357 ~27 ~388 minecraft:redstone_wire replace
fill ~87 ~27 ~378 ~87 ~27 ~380 minecraft:redstone_wire replace
setblock ~99 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~378 ~270 ~27 ~390 minecraft:redstone_wire replace
fill ~333 ~27 ~378 ~333 ~27 ~390 minecraft:redstone_wire replace
fill ~351 ~27 ~378 ~351 ~27 ~390 minecraft:redstone_wire replace
setblock ~354 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~380 ~99 ~27 ~392 minecraft:redstone_wire replace
fill ~105 ~27 ~380 ~105 ~27 ~392 minecraft:redstone_wire replace
fill ~120 ~27 ~380 ~120 ~27 ~392 minecraft:redstone_wire replace
setblock ~123 ~27 ~380 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~380 ~144 ~27 ~392 minecraft:redstone_wire replace
fill ~162 ~27 ~380 ~162 ~27 ~392 minecraft:redstone_wire replace
fill ~204 ~27 ~380 ~204 ~27 ~392 minecraft:redstone_wire replace
fill ~354 ~27 ~380 ~354 ~27 ~392 minecraft:redstone_wire replace
setblock ~108 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~382 ~123 ~27 ~394 minecraft:redstone_wire replace
setblock ~150 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~384 minecraft:redstone_wire replace
fill ~114 ~27 ~384 ~114 ~27 ~396 minecraft:redstone_wire replace
fill ~150 ~27 ~384 ~150 ~27 ~396 minecraft:redstone_wire replace
fill ~174 ~27 ~384 ~174 ~27 ~396 minecraft:redstone_wire replace
fill ~189 ~27 ~384 ~189 ~27 ~396 minecraft:redstone_wire replace
fill ~216 ~27 ~384 ~216 ~27 ~396 minecraft:redstone_wire replace
fill ~237 ~27 ~384 ~237 ~27 ~396 minecraft:redstone_wire replace
fill ~243 ~27 ~384 ~243 ~27 ~396 minecraft:redstone_wire replace
fill ~267 ~27 ~384 ~267 ~27 ~396 minecraft:redstone_wire replace
fill ~315 ~27 ~384 ~315 ~27 ~396 minecraft:redstone_wire replace
setblock ~318 ~27 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~384 ~342 ~27 ~396 minecraft:redstone_wire replace
setblock ~345 ~27 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~386 ~81 ~27 ~398 minecraft:redstone_wire replace
setblock ~117 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~386 ~318 ~27 ~398 minecraft:redstone_wire replace
setblock ~339 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~386 ~345 ~27 ~398 minecraft:redstone_wire replace
fill ~78 ~27 ~388 ~78 ~27 ~400 minecraft:redstone_wire replace
fill ~117 ~27 ~388 ~117 ~27 ~400 minecraft:redstone_wire replace
setblock ~129 ~27 ~388 minecraft:redstone_wire replace
fill ~165 ~27 ~388 ~165 ~27 ~400 minecraft:redstone_wire replace
fill ~186 ~27 ~388 ~186 ~27 ~400 minecraft:redstone_wire replace
fill ~192 ~27 ~388 ~192 ~27 ~400 minecraft:redstone_wire replace
fill ~219 ~27 ~388 ~219 ~27 ~400 minecraft:redstone_wire replace
fill ~240 ~27 ~388 ~240 ~27 ~400 minecraft:redstone_wire replace
fill ~246 ~27 ~388 ~246 ~27 ~400 minecraft:redstone_wire replace
fill ~264 ~27 ~388 ~264 ~27 ~400 minecraft:redstone_wire replace
fill ~273 ~27 ~388 ~273 ~27 ~400 minecraft:redstone_wire replace
fill ~339 ~27 ~388 ~339 ~27 ~400 minecraft:redstone_wire replace
setblock ~84 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~392 ~84 ~27 ~404 minecraft:redstone_wire replace
fill ~93 ~27 ~392 ~93 ~27 ~404 minecraft:redstone_wire replace
fill ~96 ~27 ~392 ~96 ~27 ~404 minecraft:redstone_wire replace
fill ~102 ~27 ~392 ~102 ~27 ~404 minecraft:redstone_wire replace
fill ~141 ~27 ~392 ~141 ~27 ~404 minecraft:redstone_wire replace
setblock ~168 ~27 ~392 minecraft:redstone_wire replace
fill ~195 ~27 ~392 ~195 ~27 ~396 minecraft:redstone_wire replace
fill ~201 ~27 ~392 ~201 ~27 ~404 minecraft:redstone_wire replace
fill ~222 ~27 ~392 ~222 ~27 ~398 minecraft:redstone_wire replace
fill ~258 ~27 ~392 ~258 ~27 ~402 minecraft:redstone_wire replace
setblock ~270 ~27 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~392 ~276 ~27 ~404 minecraft:redstone_wire replace
fill ~291 ~27 ~392 ~291 ~27 ~404 minecraft:redstone_wire replace
fill ~330 ~27 ~392 ~330 ~27 ~404 minecraft:redstone_wire replace
setblock ~333 ~27 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~392 ~336 ~27 ~404 minecraft:redstone_wire replace
fill ~348 ~27 ~392 ~348 ~27 ~404 minecraft:redstone_wire replace
setblock ~351 ~27 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~392 ~357 ~27 ~404 minecraft:redstone_wire replace
setblock ~99 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~394 ~270 ~27 ~406 minecraft:redstone_wire replace
fill ~333 ~27 ~394 ~333 ~27 ~406 minecraft:redstone_wire replace
fill ~351 ~27 ~394 ~351 ~27 ~406 minecraft:redstone_wire replace
setblock ~354 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~396 ~99 ~27 ~408 minecraft:redstone_wire replace
fill ~105 ~27 ~396 ~105 ~27 ~408 minecraft:redstone_wire replace
fill ~120 ~27 ~396 ~120 ~27 ~408 minecraft:redstone_wire replace
setblock ~123 ~27 ~396 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~396 ~144 ~27 ~408 minecraft:redstone_wire replace
fill ~162 ~27 ~396 ~162 ~27 ~408 minecraft:redstone_wire replace
fill ~204 ~27 ~396 ~204 ~27 ~408 minecraft:redstone_wire replace
fill ~354 ~27 ~396 ~354 ~27 ~408 minecraft:redstone_wire replace
setblock ~114 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~398 ~123 ~27 ~410 minecraft:redstone_wire replace
setblock ~150 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~400 ~114 ~27 ~412 minecraft:redstone_wire replace
fill ~150 ~27 ~400 ~150 ~27 ~412 minecraft:redstone_wire replace
fill ~174 ~27 ~400 ~174 ~27 ~412 minecraft:redstone_wire replace
fill ~189 ~27 ~400 ~189 ~27 ~412 minecraft:redstone_wire replace
fill ~216 ~27 ~400 ~216 ~27 ~412 minecraft:redstone_wire replace
setblock ~222 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~27 ~400 ~237 ~27 ~412 minecraft:redstone_wire replace
fill ~243 ~27 ~400 ~243 ~27 ~412 minecraft:redstone_wire replace
fill ~267 ~27 ~400 ~267 ~27 ~412 minecraft:redstone_wire replace
fill ~315 ~27 ~400 ~315 ~27 ~412 minecraft:redstone_wire replace
setblock ~318 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~400 ~342 ~27 ~412 minecraft:redstone_wire replace
setblock ~345 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~402 ~81 ~27 ~414 minecraft:redstone_wire replace
setblock ~117 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~402 ~318 ~27 ~414 minecraft:redstone_wire replace
setblock ~339 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~402 ~345 ~27 ~414 minecraft:redstone_wire replace
fill ~78 ~27 ~404 ~78 ~27 ~416 minecraft:redstone_wire replace
fill ~117 ~27 ~404 ~117 ~27 ~416 minecraft:redstone_wire replace
fill ~165 ~27 ~404 ~165 ~27 ~416 minecraft:redstone_wire replace
fill ~186 ~27 ~404 ~186 ~27 ~416 minecraft:redstone_wire replace
fill ~192 ~27 ~404 ~192 ~27 ~416 minecraft:redstone_wire replace
fill ~219 ~27 ~404 ~219 ~27 ~416 minecraft:redstone_wire replace
fill ~240 ~27 ~404 ~240 ~27 ~416 minecraft:redstone_wire replace
fill ~246 ~27 ~404 ~246 ~27 ~416 minecraft:redstone_wire replace
setblock ~258 ~27 ~404 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~27 ~404 ~264 ~27 ~416 minecraft:redstone_wire replace
fill ~273 ~27 ~404 ~273 ~27 ~416 minecraft:redstone_wire replace
fill ~339 ~27 ~404 ~339 ~27 ~416 minecraft:redstone_wire replace
setblock ~84 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~408 ~84 ~27 ~418 minecraft:redstone_wire replace
fill ~93 ~27 ~408 ~93 ~27 ~420 minecraft:redstone_wire replace
fill ~96 ~27 ~408 ~96 ~27 ~420 minecraft:redstone_wire replace
fill ~102 ~27 ~408 ~102 ~27 ~420 minecraft:redstone_wire replace
fill ~141 ~27 ~408 ~141 ~27 ~420 minecraft:redstone_wire replace
fill ~201 ~27 ~408 ~201 ~27 ~420 minecraft:redstone_wire replace
setblock ~270 ~27 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~408 minecraft:redstone_wire replace
fill ~291 ~27 ~408 ~291 ~27 ~420 minecraft:redstone_wire replace
fill ~330 ~27 ~408 ~330 ~27 ~420 minecraft:redstone_wire replace
setblock ~333 ~27 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~408 ~336 ~27 ~420 minecraft:redstone_wire replace
fill ~348 ~27 ~408 ~348 ~27 ~420 minecraft:redstone_wire replace
setblock ~351 ~27 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~408 ~357 ~27 ~420 minecraft:redstone_wire replace
setblock ~99 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~410 ~270 ~27 ~422 minecraft:redstone_wire replace
fill ~333 ~27 ~410 ~333 ~27 ~412 minecraft:redstone_wire replace
fill ~351 ~27 ~410 ~351 ~27 ~416 minecraft:redstone_wire replace
setblock ~354 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~412 ~99 ~27 ~424 minecraft:redstone_wire replace
fill ~105 ~27 ~412 ~105 ~27 ~422 minecraft:redstone_wire replace
fill ~120 ~27 ~412 ~120 ~27 ~424 minecraft:redstone_wire replace
setblock ~123 ~27 ~412 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~412 ~144 ~27 ~424 minecraft:redstone_wire replace
fill ~162 ~27 ~412 ~162 ~27 ~424 minecraft:redstone_wire replace
fill ~204 ~27 ~412 ~204 ~27 ~424 minecraft:redstone_wire replace
fill ~354 ~27 ~412 ~354 ~27 ~424 minecraft:redstone_wire replace
setblock ~114 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~414 ~123 ~27 ~426 minecraft:redstone_wire replace
setblock ~150 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~416 ~114 ~27 ~428 minecraft:redstone_wire replace
fill ~150 ~27 ~416 ~150 ~27 ~428 minecraft:redstone_wire replace
fill ~174 ~27 ~416 ~174 ~27 ~428 minecraft:redstone_wire replace
fill ~189 ~27 ~416 ~189 ~27 ~428 minecraft:redstone_wire replace
fill ~216 ~27 ~416 ~216 ~27 ~428 minecraft:redstone_wire replace
fill ~237 ~27 ~416 ~237 ~27 ~428 minecraft:redstone_wire replace
fill ~243 ~27 ~416 ~243 ~27 ~428 minecraft:redstone_wire replace
fill ~267 ~27 ~416 ~267 ~27 ~428 minecraft:redstone_wire replace
fill ~315 ~27 ~416 ~315 ~27 ~428 minecraft:redstone_wire replace
setblock ~318 ~27 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~416 ~342 ~27 ~428 minecraft:redstone_wire replace
setblock ~345 ~27 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~418 ~81 ~27 ~430 minecraft:redstone_wire replace
setblock ~117 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~418 ~318 ~27 ~430 minecraft:redstone_wire replace
setblock ~339 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~418 ~345 ~27 ~430 minecraft:redstone_wire replace
fill ~78 ~27 ~420 ~78 ~27 ~432 minecraft:redstone_wire replace
setblock ~84 ~27 ~420 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~420 ~117 ~27 ~432 minecraft:redstone_wire replace
fill ~165 ~27 ~420 ~165 ~27 ~430 minecraft:redstone_wire replace
fill ~186 ~27 ~420 ~186 ~27 ~432 minecraft:redstone_wire replace
fill ~192 ~27 ~420 ~192 ~27 ~432 minecraft:redstone_wire replace
fill ~219 ~27 ~420 ~219 ~27 ~432 minecraft:redstone_wire replace
fill ~240 ~27 ~420 ~240 ~27 ~432 minecraft:redstone_wire replace
fill ~246 ~27 ~420 ~246 ~27 ~432 minecraft:redstone_wire replace
fill ~264 ~27 ~420 ~264 ~27 ~432 minecraft:redstone_wire replace
fill ~273 ~27 ~420 ~273 ~27 ~432 minecraft:redstone_wire replace
fill ~339 ~27 ~420 ~339 ~27 ~432 minecraft:redstone_wire replace
setblock ~93 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~424 ~93 ~27 ~436 minecraft:redstone_wire replace
fill ~96 ~27 ~424 ~96 ~27 ~436 minecraft:redstone_wire replace
fill ~102 ~27 ~424 ~102 ~27 ~436 minecraft:redstone_wire replace
setblock ~105 ~27 ~424 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~27 ~424 ~141 ~27 ~436 minecraft:redstone_wire replace
fill ~201 ~27 ~424 ~201 ~27 ~436 minecraft:redstone_wire replace
setblock ~270 ~27 ~424 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~424 ~291 ~27 ~436 minecraft:redstone_wire replace
fill ~330 ~27 ~424 ~330 ~27 ~436 minecraft:redstone_wire replace
fill ~336 ~27 ~424 ~336 ~27 ~436 minecraft:redstone_wire replace
fill ~348 ~27 ~424 ~348 ~27 ~436 minecraft:redstone_wire replace
fill ~357 ~27 ~424 ~357 ~27 ~436 minecraft:redstone_wire replace
setblock ~99 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~426 ~270 ~27 ~438 minecraft:redstone_wire replace
setblock ~354 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~428 ~99 ~27 ~440 minecraft:redstone_wire replace
fill ~120 ~27 ~428 ~120 ~27 ~440 minecraft:redstone_wire replace
setblock ~123 ~27 ~428 minecraft:redstone_wire replace
fill ~144 ~27 ~428 ~144 ~27 ~440 minecraft:redstone_wire replace
fill ~162 ~27 ~428 ~162 ~27 ~440 minecraft:redstone_wire replace
fill ~204 ~27 ~428 ~204 ~27 ~440 minecraft:redstone_wire replace
fill ~354 ~27 ~428 ~354 ~27 ~440 minecraft:redstone_wire replace
setblock ~114 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~432 ~114 ~27 ~444 minecraft:redstone_wire replace
fill ~150 ~27 ~432 ~150 ~27 ~444 minecraft:redstone_wire replace
setblock ~165 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~27 ~432 ~174 ~27 ~444 minecraft:redstone_wire replace
fill ~189 ~27 ~432 ~189 ~27 ~444 minecraft:redstone_wire replace
fill ~216 ~27 ~432 ~216 ~27 ~444 minecraft:redstone_wire replace
fill ~237 ~27 ~432 ~237 ~27 ~444 minecraft:redstone_wire replace
fill ~243 ~27 ~432 ~243 ~27 ~444 minecraft:redstone_wire replace
fill ~267 ~27 ~432 ~267 ~27 ~444 minecraft:redstone_wire replace
fill ~315 ~27 ~432 ~315 ~27 ~444 minecraft:redstone_wire replace
setblock ~318 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~432 ~342 ~27 ~444 minecraft:redstone_wire replace
setblock ~345 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~434 ~81 ~27 ~446 minecraft:redstone_wire replace
setblock ~117 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~434 ~318 ~27 ~446 minecraft:redstone_wire replace
setblock ~339 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~434 ~345 ~27 ~446 minecraft:redstone_wire replace
fill ~78 ~27 ~436 ~78 ~27 ~448 minecraft:redstone_wire replace
fill ~117 ~27 ~436 ~117 ~27 ~448 minecraft:redstone_wire replace
fill ~186 ~27 ~436 ~186 ~27 ~448 minecraft:redstone_wire replace
setblock ~192 ~27 ~436 minecraft:redstone_wire replace
fill ~219 ~27 ~436 ~219 ~27 ~440 minecraft:redstone_wire replace
fill ~240 ~27 ~436 ~240 ~27 ~448 minecraft:redstone_wire replace
fill ~246 ~27 ~436 ~246 ~27 ~442 minecraft:redstone_wire replace
fill ~264 ~27 ~436 ~264 ~27 ~448 minecraft:redstone_wire replace
fill ~273 ~27 ~436 ~273 ~27 ~446 minecraft:redstone_wire replace
fill ~339 ~27 ~436 ~339 ~27 ~448 minecraft:redstone_wire replace
setblock ~93 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~440 ~93 ~27 ~452 minecraft:redstone_wire replace
fill ~96 ~27 ~440 ~96 ~27 ~452 minecraft:redstone_wire replace
fill ~102 ~27 ~440 ~102 ~27 ~452 minecraft:redstone_wire replace
fill ~141 ~27 ~440 ~141 ~27 ~452 minecraft:redstone_wire replace
fill ~201 ~27 ~440 ~201 ~27 ~452 minecraft:redstone_wire replace
setblock ~270 ~27 ~440 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~440 ~291 ~27 ~452 minecraft:redstone_wire replace
fill ~330 ~27 ~440 ~330 ~27 ~450 minecraft:redstone_wire replace
fill ~336 ~27 ~440 ~336 ~27 ~452 minecraft:redstone_wire replace
fill ~348 ~27 ~440 ~348 ~27 ~452 minecraft:redstone_wire replace
fill ~357 ~27 ~440 ~357 ~27 ~452 minecraft:redstone_wire replace
setblock ~99 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~442 ~270 ~27 ~454 minecraft:redstone_wire replace
setblock ~354 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~444 ~99 ~27 ~456 minecraft:redstone_wire replace
fill ~120 ~27 ~444 ~120 ~27 ~456 minecraft:redstone_wire replace
fill ~144 ~27 ~444 ~144 ~27 ~456 minecraft:redstone_wire replace
fill ~162 ~27 ~444 ~162 ~27 ~456 minecraft:redstone_wire replace
fill ~204 ~27 ~444 ~204 ~27 ~456 minecraft:redstone_wire replace
setblock ~246 ~27 ~444 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~444 ~354 ~27 ~456 minecraft:redstone_wire replace
setblock ~114 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~448 ~114 ~27 ~460 minecraft:redstone_wire replace
fill ~150 ~27 ~448 ~150 ~27 ~460 minecraft:redstone_wire replace
fill ~174 ~27 ~448 ~174 ~27 ~460 minecraft:redstone_wire replace
fill ~189 ~27 ~448 ~189 ~27 ~460 minecraft:redstone_wire replace
fill ~216 ~27 ~448 ~216 ~27 ~460 minecraft:redstone_wire replace
fill ~237 ~27 ~448 ~237 ~27 ~460 minecraft:redstone_wire replace
fill ~243 ~27 ~448 ~243 ~27 ~460 minecraft:redstone_wire replace
fill ~267 ~27 ~448 ~267 ~27 ~460 minecraft:redstone_wire replace
setblock ~273 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~27 ~448 ~315 ~27 ~460 minecraft:redstone_wire replace
setblock ~318 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~448 ~342 ~27 ~460 minecraft:redstone_wire replace
setblock ~345 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~450 ~81 ~27 ~458 minecraft:redstone_wire replace
setblock ~117 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~450 ~318 ~27 ~462 minecraft:redstone_wire replace
setblock ~339 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~450 ~345 ~27 ~462 minecraft:redstone_wire replace
fill ~78 ~27 ~452 ~78 ~27 ~464 minecraft:redstone_wire replace
fill ~117 ~27 ~452 ~117 ~27 ~464 minecraft:redstone_wire replace
fill ~186 ~27 ~452 ~186 ~27 ~464 minecraft:redstone_wire replace
fill ~240 ~27 ~452 ~240 ~27 ~464 minecraft:redstone_wire replace
fill ~264 ~27 ~452 ~264 ~27 ~464 minecraft:redstone_wire replace
setblock ~330 ~27 ~452 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~452 ~339 ~27 ~464 minecraft:redstone_wire replace
setblock ~93 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~456 ~93 ~27 ~468 minecraft:redstone_wire replace
fill ~96 ~27 ~456 ~96 ~27 ~468 minecraft:redstone_wire replace
fill ~102 ~27 ~456 ~102 ~27 ~462 minecraft:redstone_wire replace
fill ~141 ~27 ~456 ~141 ~27 ~468 minecraft:redstone_wire replace
fill ~201 ~27 ~456 ~201 ~27 ~468 minecraft:redstone_wire replace
setblock ~270 ~27 ~456 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~456 ~291 ~27 ~468 minecraft:redstone_wire replace
fill ~336 ~27 ~456 ~336 ~27 ~468 minecraft:redstone_wire replace
setblock ~348 ~27 ~456 minecraft:redstone_wire replace
fill ~357 ~27 ~456 ~357 ~27 ~468 minecraft:redstone_wire replace
setblock ~99 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~458 ~270 ~27 ~470 minecraft:redstone_wire replace
setblock ~354 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~460 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~460 ~99 ~27 ~472 minecraft:redstone_wire replace
fill ~120 ~27 ~460 ~120 ~27 ~466 minecraft:redstone_wire replace
fill ~144 ~27 ~460 ~144 ~27 ~472 minecraft:redstone_wire replace
fill ~162 ~27 ~460 ~162 ~27 ~472 minecraft:redstone_wire replace
fill ~204 ~27 ~460 ~204 ~27 ~472 minecraft:redstone_wire replace
fill ~354 ~27 ~460 ~354 ~27 ~472 minecraft:redstone_wire replace
setblock ~114 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~464 ~114 ~27 ~476 minecraft:redstone_wire replace
fill ~150 ~27 ~464 ~150 ~27 ~470 minecraft:redstone_wire replace
fill ~174 ~27 ~464 ~174 ~27 ~476 minecraft:redstone_wire replace
fill ~189 ~27 ~464 ~189 ~27 ~474 minecraft:redstone_wire replace
fill ~216 ~27 ~464 ~216 ~27 ~476 minecraft:redstone_wire replace
fill ~237 ~27 ~464 ~237 ~27 ~476 minecraft:redstone_wire replace
fill ~243 ~27 ~464 ~243 ~27 ~476 minecraft:redstone_wire replace
fill ~267 ~27 ~464 ~267 ~27 ~476 minecraft:redstone_wire replace
