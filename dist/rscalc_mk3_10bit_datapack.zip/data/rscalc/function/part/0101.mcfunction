fill ~375 ~155 ~552 ~375 ~155 ~564 minecraft:redstone_wire replace
fill ~378 ~155 ~552 ~378 ~155 ~564 minecraft:redstone_wire replace
fill ~381 ~155 ~552 ~381 ~155 ~564 minecraft:redstone_wire replace
fill ~384 ~155 ~552 ~384 ~155 ~564 minecraft:redstone_wire replace
fill ~387 ~155 ~552 ~387 ~155 ~564 minecraft:redstone_wire replace
fill ~390 ~155 ~552 ~390 ~155 ~564 minecraft:redstone_wire replace
fill ~393 ~155 ~552 ~393 ~155 ~564 minecraft:redstone_wire replace
fill ~396 ~155 ~552 ~396 ~155 ~564 minecraft:redstone_wire replace
fill ~399 ~155 ~552 ~399 ~155 ~564 minecraft:redstone_wire replace
setblock ~126 ~155 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~564 minecraft:redstone_wire replace
setblock ~132 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~155 ~566 ~132 ~155 ~568 minecraft:redstone_wire replace
fill ~135 ~155 ~566 ~135 ~155 ~572 minecraft:redstone_wire replace
fill ~138 ~155 ~566 ~138 ~155 ~574 minecraft:redstone_wire replace
fill ~141 ~155 ~566 ~141 ~155 ~578 minecraft:redstone_wire replace
fill ~144 ~155 ~566 ~144 ~155 ~578 minecraft:redstone_wire replace
fill ~147 ~155 ~566 ~147 ~155 ~578 minecraft:redstone_wire replace
fill ~150 ~155 ~566 ~150 ~155 ~578 minecraft:redstone_wire replace
fill ~153 ~155 ~566 ~153 ~155 ~578 minecraft:redstone_wire replace
fill ~156 ~155 ~566 ~156 ~155 ~578 minecraft:redstone_wire replace
fill ~159 ~155 ~566 ~159 ~155 ~578 minecraft:redstone_wire replace
fill ~162 ~155 ~566 ~162 ~155 ~578 minecraft:redstone_wire replace
fill ~165 ~155 ~566 ~165 ~155 ~578 minecraft:redstone_wire replace
fill ~168 ~155 ~566 ~168 ~155 ~578 minecraft:redstone_wire replace
fill ~171 ~155 ~566 ~171 ~155 ~578 minecraft:redstone_wire replace
fill ~174 ~155 ~566 ~174 ~155 ~578 minecraft:redstone_wire replace
fill ~177 ~155 ~566 ~177 ~155 ~578 minecraft:redstone_wire replace
fill ~180 ~155 ~566 ~180 ~155 ~578 minecraft:redstone_wire replace
fill ~183 ~155 ~566 ~183 ~155 ~578 minecraft:redstone_wire replace
fill ~186 ~155 ~566 ~186 ~155 ~578 minecraft:redstone_wire replace
fill ~189 ~155 ~566 ~189 ~155 ~578 minecraft:redstone_wire replace
fill ~192 ~155 ~566 ~192 ~155 ~578 minecraft:redstone_wire replace
fill ~195 ~155 ~566 ~195 ~155 ~578 minecraft:redstone_wire replace
fill ~198 ~155 ~566 ~198 ~155 ~578 minecraft:redstone_wire replace
fill ~201 ~155 ~566 ~201 ~155 ~578 minecraft:redstone_wire replace
fill ~204 ~155 ~566 ~204 ~155 ~578 minecraft:redstone_wire replace
fill ~207 ~155 ~566 ~207 ~155 ~578 minecraft:redstone_wire replace
fill ~210 ~155 ~566 ~210 ~155 ~578 minecraft:redstone_wire replace
fill ~213 ~155 ~566 ~213 ~155 ~578 minecraft:redstone_wire replace
fill ~216 ~155 ~566 ~216 ~155 ~578 minecraft:redstone_wire replace
fill ~219 ~155 ~566 ~219 ~155 ~578 minecraft:redstone_wire replace
fill ~222 ~155 ~566 ~222 ~155 ~578 minecraft:redstone_wire replace
fill ~225 ~155 ~566 ~225 ~155 ~578 minecraft:redstone_wire replace
fill ~228 ~155 ~566 ~228 ~155 ~578 minecraft:redstone_wire replace
fill ~231 ~155 ~566 ~231 ~155 ~578 minecraft:redstone_wire replace
fill ~234 ~155 ~566 ~234 ~155 ~578 minecraft:redstone_wire replace
fill ~237 ~155 ~566 ~237 ~155 ~578 minecraft:redstone_wire replace
fill ~240 ~155 ~566 ~240 ~155 ~578 minecraft:redstone_wire replace
fill ~243 ~155 ~566 ~243 ~155 ~578 minecraft:redstone_wire replace
fill ~246 ~155 ~566 ~246 ~155 ~578 minecraft:redstone_wire replace
fill ~249 ~155 ~566 ~249 ~155 ~578 minecraft:redstone_wire replace
fill ~252 ~155 ~566 ~252 ~155 ~578 minecraft:redstone_wire replace
fill ~255 ~155 ~566 ~255 ~155 ~578 minecraft:redstone_wire replace
fill ~258 ~155 ~566 ~258 ~155 ~578 minecraft:redstone_wire replace
fill ~261 ~155 ~566 ~261 ~155 ~578 minecraft:redstone_wire replace
fill ~264 ~155 ~566 ~264 ~155 ~578 minecraft:redstone_wire replace
fill ~267 ~155 ~566 ~267 ~155 ~578 minecraft:redstone_wire replace
fill ~270 ~155 ~566 ~270 ~155 ~578 minecraft:redstone_wire replace
fill ~273 ~155 ~566 ~273 ~155 ~578 minecraft:redstone_wire replace
fill ~276 ~155 ~566 ~276 ~155 ~578 minecraft:redstone_wire replace
fill ~279 ~155 ~566 ~279 ~155 ~578 minecraft:redstone_wire replace
fill ~282 ~155 ~566 ~282 ~155 ~578 minecraft:redstone_wire replace
fill ~285 ~155 ~566 ~285 ~155 ~578 minecraft:redstone_wire replace
fill ~288 ~155 ~566 ~288 ~155 ~578 minecraft:redstone_wire replace
fill ~291 ~155 ~566 ~291 ~155 ~578 minecraft:redstone_wire replace
fill ~294 ~155 ~566 ~294 ~155 ~578 minecraft:redstone_wire replace
fill ~297 ~155 ~566 ~297 ~155 ~578 minecraft:redstone_wire replace
fill ~300 ~155 ~566 ~300 ~155 ~578 minecraft:redstone_wire replace
fill ~303 ~155 ~566 ~303 ~155 ~578 minecraft:redstone_wire replace
fill ~306 ~155 ~566 ~306 ~155 ~578 minecraft:redstone_wire replace
fill ~309 ~155 ~566 ~309 ~155 ~578 minecraft:redstone_wire replace
fill ~312 ~155 ~566 ~312 ~155 ~578 minecraft:redstone_wire replace
fill ~315 ~155 ~566 ~315 ~155 ~578 minecraft:redstone_wire replace
fill ~318 ~155 ~566 ~318 ~155 ~578 minecraft:redstone_wire replace
fill ~321 ~155 ~566 ~321 ~155 ~578 minecraft:redstone_wire replace
fill ~324 ~155 ~566 ~324 ~155 ~578 minecraft:redstone_wire replace
fill ~327 ~155 ~566 ~327 ~155 ~578 minecraft:redstone_wire replace
fill ~330 ~155 ~566 ~330 ~155 ~578 minecraft:redstone_wire replace
fill ~333 ~155 ~566 ~333 ~155 ~578 minecraft:redstone_wire replace
fill ~336 ~155 ~566 ~336 ~155 ~578 minecraft:redstone_wire replace
fill ~339 ~155 ~566 ~339 ~155 ~578 minecraft:redstone_wire replace
fill ~342 ~155 ~566 ~342 ~155 ~578 minecraft:redstone_wire replace
fill ~345 ~155 ~566 ~345 ~155 ~578 minecraft:redstone_wire replace
fill ~348 ~155 ~566 ~348 ~155 ~578 minecraft:redstone_wire replace
fill ~351 ~155 ~566 ~351 ~155 ~578 minecraft:redstone_wire replace
fill ~354 ~155 ~566 ~354 ~155 ~578 minecraft:redstone_wire replace
fill ~357 ~155 ~566 ~357 ~155 ~578 minecraft:redstone_wire replace
fill ~360 ~155 ~566 ~360 ~155 ~578 minecraft:redstone_wire replace
fill ~363 ~155 ~566 ~363 ~155 ~578 minecraft:redstone_wire replace
fill ~366 ~155 ~566 ~366 ~155 ~578 minecraft:redstone_wire replace
fill ~369 ~155 ~566 ~369 ~155 ~578 minecraft:redstone_wire replace
fill ~372 ~155 ~566 ~372 ~155 ~578 minecraft:redstone_wire replace
fill ~375 ~155 ~566 ~375 ~155 ~578 minecraft:redstone_wire replace
fill ~378 ~155 ~566 ~378 ~155 ~578 minecraft:redstone_wire replace
fill ~381 ~155 ~566 ~381 ~155 ~578 minecraft:redstone_wire replace
fill ~384 ~155 ~566 ~384 ~155 ~578 minecraft:redstone_wire replace
fill ~387 ~155 ~566 ~387 ~155 ~578 minecraft:redstone_wire replace
fill ~390 ~155 ~566 ~390 ~155 ~578 minecraft:redstone_wire replace
fill ~393 ~155 ~566 ~393 ~155 ~578 minecraft:redstone_wire replace
fill ~396 ~155 ~566 ~396 ~155 ~578 minecraft:redstone_wire replace
fill ~399 ~155 ~566 ~399 ~155 ~578 minecraft:redstone_wire replace
setblock ~138 ~155 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~580 minecraft:redstone_wire replace
setblock ~144 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~155 ~582 ~144 ~155 ~584 minecraft:redstone_wire replace
fill ~147 ~155 ~582 ~147 ~155 ~588 minecraft:redstone_wire replace
fill ~150 ~155 ~582 ~150 ~155 ~590 minecraft:redstone_wire replace
fill ~153 ~155 ~582 ~153 ~155 ~594 minecraft:redstone_wire replace
fill ~156 ~155 ~582 ~156 ~155 ~594 minecraft:redstone_wire replace
fill ~159 ~155 ~582 ~159 ~155 ~594 minecraft:redstone_wire replace
fill ~162 ~155 ~582 ~162 ~155 ~594 minecraft:redstone_wire replace
fill ~165 ~155 ~582 ~165 ~155 ~594 minecraft:redstone_wire replace
fill ~168 ~155 ~582 ~168 ~155 ~594 minecraft:redstone_wire replace
fill ~171 ~155 ~582 ~171 ~155 ~594 minecraft:redstone_wire replace
fill ~174 ~155 ~582 ~174 ~155 ~594 minecraft:redstone_wire replace
fill ~177 ~155 ~582 ~177 ~155 ~594 minecraft:redstone_wire replace
fill ~180 ~155 ~582 ~180 ~155 ~594 minecraft:redstone_wire replace
fill ~183 ~155 ~582 ~183 ~155 ~594 minecraft:redstone_wire replace
fill ~186 ~155 ~582 ~186 ~155 ~594 minecraft:redstone_wire replace
fill ~189 ~155 ~582 ~189 ~155 ~594 minecraft:redstone_wire replace
fill ~192 ~155 ~582 ~192 ~155 ~594 minecraft:redstone_wire replace
fill ~195 ~155 ~582 ~195 ~155 ~594 minecraft:redstone_wire replace
fill ~198 ~155 ~582 ~198 ~155 ~594 minecraft:redstone_wire replace
fill ~201 ~155 ~582 ~201 ~155 ~594 minecraft:redstone_wire replace
fill ~204 ~155 ~582 ~204 ~155 ~594 minecraft:redstone_wire replace
fill ~207 ~155 ~582 ~207 ~155 ~594 minecraft:redstone_wire replace
fill ~210 ~155 ~582 ~210 ~155 ~594 minecraft:redstone_wire replace
fill ~213 ~155 ~582 ~213 ~155 ~594 minecraft:redstone_wire replace
fill ~216 ~155 ~582 ~216 ~155 ~594 minecraft:redstone_wire replace
fill ~219 ~155 ~582 ~219 ~155 ~594 minecraft:redstone_wire replace
fill ~222 ~155 ~582 ~222 ~155 ~594 minecraft:redstone_wire replace
fill ~225 ~155 ~582 ~225 ~155 ~594 minecraft:redstone_wire replace
fill ~228 ~155 ~582 ~228 ~155 ~594 minecraft:redstone_wire replace
fill ~231 ~155 ~582 ~231 ~155 ~594 minecraft:redstone_wire replace
fill ~234 ~155 ~582 ~234 ~155 ~594 minecraft:redstone_wire replace
fill ~237 ~155 ~582 ~237 ~155 ~594 minecraft:redstone_wire replace
fill ~240 ~155 ~582 ~240 ~155 ~594 minecraft:redstone_wire replace
fill ~243 ~155 ~582 ~243 ~155 ~594 minecraft:redstone_wire replace
fill ~246 ~155 ~582 ~246 ~155 ~594 minecraft:redstone_wire replace
fill ~249 ~155 ~582 ~249 ~155 ~594 minecraft:redstone_wire replace
fill ~252 ~155 ~582 ~252 ~155 ~594 minecraft:redstone_wire replace
fill ~255 ~155 ~582 ~255 ~155 ~594 minecraft:redstone_wire replace
fill ~258 ~155 ~582 ~258 ~155 ~594 minecraft:redstone_wire replace
fill ~261 ~155 ~582 ~261 ~155 ~594 minecraft:redstone_wire replace
fill ~264 ~155 ~582 ~264 ~155 ~594 minecraft:redstone_wire replace
fill ~267 ~155 ~582 ~267 ~155 ~594 minecraft:redstone_wire replace
fill ~270 ~155 ~582 ~270 ~155 ~594 minecraft:redstone_wire replace
fill ~273 ~155 ~582 ~273 ~155 ~594 minecraft:redstone_wire replace
fill ~276 ~155 ~582 ~276 ~155 ~594 minecraft:redstone_wire replace
fill ~279 ~155 ~582 ~279 ~155 ~594 minecraft:redstone_wire replace
fill ~282 ~155 ~582 ~282 ~155 ~594 minecraft:redstone_wire replace
fill ~285 ~155 ~582 ~285 ~155 ~594 minecraft:redstone_wire replace
fill ~288 ~155 ~582 ~288 ~155 ~594 minecraft:redstone_wire replace
fill ~291 ~155 ~582 ~291 ~155 ~594 minecraft:redstone_wire replace
fill ~294 ~155 ~582 ~294 ~155 ~594 minecraft:redstone_wire replace
fill ~297 ~155 ~582 ~297 ~155 ~594 minecraft:redstone_wire replace
fill ~300 ~155 ~582 ~300 ~155 ~594 minecraft:redstone_wire replace
fill ~303 ~155 ~582 ~303 ~155 ~594 minecraft:redstone_wire replace
fill ~306 ~155 ~582 ~306 ~155 ~594 minecraft:redstone_wire replace
fill ~309 ~155 ~582 ~309 ~155 ~594 minecraft:redstone_wire replace
fill ~312 ~155 ~582 ~312 ~155 ~594 minecraft:redstone_wire replace
fill ~315 ~155 ~582 ~315 ~155 ~594 minecraft:redstone_wire replace
fill ~318 ~155 ~582 ~318 ~155 ~594 minecraft:redstone_wire replace
fill ~321 ~155 ~582 ~321 ~155 ~594 minecraft:redstone_wire replace
fill ~324 ~155 ~582 ~324 ~155 ~594 minecraft:redstone_wire replace
fill ~327 ~155 ~582 ~327 ~155 ~594 minecraft:redstone_wire replace
fill ~330 ~155 ~582 ~330 ~155 ~594 minecraft:redstone_wire replace
fill ~333 ~155 ~582 ~333 ~155 ~594 minecraft:redstone_wire replace
fill ~336 ~155 ~582 ~336 ~155 ~594 minecraft:redstone_wire replace
fill ~339 ~155 ~582 ~339 ~155 ~594 minecraft:redstone_wire replace
fill ~342 ~155 ~582 ~342 ~155 ~594 minecraft:redstone_wire replace
fill ~345 ~155 ~582 ~345 ~155 ~594 minecraft:redstone_wire replace
fill ~348 ~155 ~582 ~348 ~155 ~594 minecraft:redstone_wire replace
fill ~351 ~155 ~582 ~351 ~155 ~594 minecraft:redstone_wire replace
fill ~354 ~155 ~582 ~354 ~155 ~594 minecraft:redstone_wire replace
fill ~357 ~155 ~582 ~357 ~155 ~594 minecraft:redstone_wire replace
fill ~360 ~155 ~582 ~360 ~155 ~594 minecraft:redstone_wire replace
fill ~363 ~155 ~582 ~363 ~155 ~594 minecraft:redstone_wire replace
fill ~366 ~155 ~582 ~366 ~155 ~594 minecraft:redstone_wire replace
fill ~369 ~155 ~582 ~369 ~155 ~594 minecraft:redstone_wire replace
fill ~372 ~155 ~582 ~372 ~155 ~594 minecraft:redstone_wire replace
fill ~375 ~155 ~582 ~375 ~155 ~594 minecraft:redstone_wire replace
fill ~378 ~155 ~582 ~378 ~155 ~594 minecraft:redstone_wire replace
fill ~381 ~155 ~582 ~381 ~155 ~594 minecraft:redstone_wire replace
fill ~384 ~155 ~582 ~384 ~155 ~594 minecraft:redstone_wire replace
fill ~387 ~155 ~582 ~387 ~155 ~594 minecraft:redstone_wire replace
fill ~390 ~155 ~582 ~390 ~155 ~594 minecraft:redstone_wire replace
fill ~393 ~155 ~582 ~393 ~155 ~594 minecraft:redstone_wire replace
fill ~396 ~155 ~582 ~396 ~155 ~594 minecraft:redstone_wire replace
fill ~399 ~155 ~582 ~399 ~155 ~594 minecraft:redstone_wire replace
setblock ~150 ~155 ~592 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~596 minecraft:redstone_wire replace
setblock ~156 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~596 ~402 ~155 ~608 minecraft:redstone_wire replace
fill ~405 ~155 ~596 ~405 ~155 ~608 minecraft:redstone_wire replace
fill ~408 ~155 ~596 ~408 ~155 ~608 minecraft:redstone_wire replace
fill ~411 ~155 ~596 ~411 ~155 ~608 minecraft:redstone_wire replace
fill ~414 ~155 ~596 ~414 ~155 ~608 minecraft:redstone_wire replace
fill ~417 ~155 ~596 ~417 ~155 ~608 minecraft:redstone_wire replace
fill ~420 ~155 ~596 ~420 ~155 ~608 minecraft:redstone_wire replace
fill ~423 ~155 ~596 ~423 ~155 ~608 minecraft:redstone_wire replace
fill ~156 ~155 ~598 ~156 ~155 ~600 minecraft:redstone_wire replace
fill ~159 ~155 ~598 ~159 ~155 ~604 minecraft:redstone_wire replace
fill ~162 ~155 ~598 ~162 ~155 ~606 minecraft:redstone_wire replace
fill ~165 ~155 ~598 ~165 ~155 ~610 minecraft:redstone_wire replace
fill ~168 ~155 ~598 ~168 ~155 ~610 minecraft:redstone_wire replace
fill ~171 ~155 ~598 ~171 ~155 ~610 minecraft:redstone_wire replace
fill ~174 ~155 ~598 ~174 ~155 ~610 minecraft:redstone_wire replace
fill ~177 ~155 ~598 ~177 ~155 ~610 minecraft:redstone_wire replace
fill ~180 ~155 ~598 ~180 ~155 ~610 minecraft:redstone_wire replace
fill ~183 ~155 ~598 ~183 ~155 ~610 minecraft:redstone_wire replace
fill ~186 ~155 ~598 ~186 ~155 ~610 minecraft:redstone_wire replace
fill ~189 ~155 ~598 ~189 ~155 ~610 minecraft:redstone_wire replace
fill ~192 ~155 ~598 ~192 ~155 ~610 minecraft:redstone_wire replace
fill ~195 ~155 ~598 ~195 ~155 ~610 minecraft:redstone_wire replace
fill ~198 ~155 ~598 ~198 ~155 ~610 minecraft:redstone_wire replace
fill ~201 ~155 ~598 ~201 ~155 ~610 minecraft:redstone_wire replace
fill ~204 ~155 ~598 ~204 ~155 ~610 minecraft:redstone_wire replace
fill ~207 ~155 ~598 ~207 ~155 ~610 minecraft:redstone_wire replace
fill ~210 ~155 ~598 ~210 ~155 ~610 minecraft:redstone_wire replace
fill ~213 ~155 ~598 ~213 ~155 ~610 minecraft:redstone_wire replace
fill ~216 ~155 ~598 ~216 ~155 ~610 minecraft:redstone_wire replace
fill ~219 ~155 ~598 ~219 ~155 ~610 minecraft:redstone_wire replace
fill ~222 ~155 ~598 ~222 ~155 ~610 minecraft:redstone_wire replace
fill ~225 ~155 ~598 ~225 ~155 ~610 minecraft:redstone_wire replace
fill ~228 ~155 ~598 ~228 ~155 ~610 minecraft:redstone_wire replace
fill ~231 ~155 ~598 ~231 ~155 ~610 minecraft:redstone_wire replace
fill ~234 ~155 ~598 ~234 ~155 ~610 minecraft:redstone_wire replace
fill ~237 ~155 ~598 ~237 ~155 ~610 minecraft:redstone_wire replace
fill ~240 ~155 ~598 ~240 ~155 ~610 minecraft:redstone_wire replace
fill ~243 ~155 ~598 ~243 ~155 ~610 minecraft:redstone_wire replace
fill ~246 ~155 ~598 ~246 ~155 ~610 minecraft:redstone_wire replace
fill ~249 ~155 ~598 ~249 ~155 ~610 minecraft:redstone_wire replace
fill ~252 ~155 ~598 ~252 ~155 ~610 minecraft:redstone_wire replace
fill ~255 ~155 ~598 ~255 ~155 ~610 minecraft:redstone_wire replace
fill ~258 ~155 ~598 ~258 ~155 ~610 minecraft:redstone_wire replace
fill ~261 ~155 ~598 ~261 ~155 ~610 minecraft:redstone_wire replace
fill ~264 ~155 ~598 ~264 ~155 ~610 minecraft:redstone_wire replace
fill ~267 ~155 ~598 ~267 ~155 ~610 minecraft:redstone_wire replace
fill ~270 ~155 ~598 ~270 ~155 ~610 minecraft:redstone_wire replace
fill ~273 ~155 ~598 ~273 ~155 ~610 minecraft:redstone_wire replace
fill ~276 ~155 ~598 ~276 ~155 ~610 minecraft:redstone_wire replace
fill ~279 ~155 ~598 ~279 ~155 ~610 minecraft:redstone_wire replace
fill ~282 ~155 ~598 ~282 ~155 ~610 minecraft:redstone_wire replace
fill ~285 ~155 ~598 ~285 ~155 ~610 minecraft:redstone_wire replace
fill ~288 ~155 ~598 ~288 ~155 ~610 minecraft:redstone_wire replace
fill ~291 ~155 ~598 ~291 ~155 ~610 minecraft:redstone_wire replace
fill ~294 ~155 ~598 ~294 ~155 ~610 minecraft:redstone_wire replace
fill ~297 ~155 ~598 ~297 ~155 ~610 minecraft:redstone_wire replace
fill ~300 ~155 ~598 ~300 ~155 ~610 minecraft:redstone_wire replace
fill ~303 ~155 ~598 ~303 ~155 ~610 minecraft:redstone_wire replace
fill ~306 ~155 ~598 ~306 ~155 ~610 minecraft:redstone_wire replace
fill ~309 ~155 ~598 ~309 ~155 ~610 minecraft:redstone_wire replace
fill ~312 ~155 ~598 ~312 ~155 ~610 minecraft:redstone_wire replace
fill ~315 ~155 ~598 ~315 ~155 ~610 minecraft:redstone_wire replace
fill ~318 ~155 ~598 ~318 ~155 ~610 minecraft:redstone_wire replace
fill ~321 ~155 ~598 ~321 ~155 ~610 minecraft:redstone_wire replace
fill ~324 ~155 ~598 ~324 ~155 ~610 minecraft:redstone_wire replace
fill ~327 ~155 ~598 ~327 ~155 ~610 minecraft:redstone_wire replace
fill ~330 ~155 ~598 ~330 ~155 ~610 minecraft:redstone_wire replace
fill ~333 ~155 ~598 ~333 ~155 ~610 minecraft:redstone_wire replace
fill ~336 ~155 ~598 ~336 ~155 ~610 minecraft:redstone_wire replace
fill ~339 ~155 ~598 ~339 ~155 ~610 minecraft:redstone_wire replace
fill ~342 ~155 ~598 ~342 ~155 ~610 minecraft:redstone_wire replace
fill ~345 ~155 ~598 ~345 ~155 ~610 minecraft:redstone_wire replace
fill ~348 ~155 ~598 ~348 ~155 ~610 minecraft:redstone_wire replace
fill ~351 ~155 ~598 ~351 ~155 ~610 minecraft:redstone_wire replace
fill ~354 ~155 ~598 ~354 ~155 ~610 minecraft:redstone_wire replace
fill ~357 ~155 ~598 ~357 ~155 ~610 minecraft:redstone_wire replace
fill ~360 ~155 ~598 ~360 ~155 ~610 minecraft:redstone_wire replace
fill ~363 ~155 ~598 ~363 ~155 ~610 minecraft:redstone_wire replace
fill ~366 ~155 ~598 ~366 ~155 ~610 minecraft:redstone_wire replace
fill ~369 ~155 ~598 ~369 ~155 ~610 minecraft:redstone_wire replace
fill ~372 ~155 ~598 ~372 ~155 ~610 minecraft:redstone_wire replace
fill ~375 ~155 ~598 ~375 ~155 ~610 minecraft:redstone_wire replace
fill ~378 ~155 ~598 ~378 ~155 ~610 minecraft:redstone_wire replace
fill ~381 ~155 ~598 ~381 ~155 ~610 minecraft:redstone_wire replace
fill ~384 ~155 ~598 ~384 ~155 ~610 minecraft:redstone_wire replace
fill ~387 ~155 ~598 ~387 ~155 ~610 minecraft:redstone_wire replace
fill ~390 ~155 ~598 ~390 ~155 ~610 minecraft:redstone_wire replace
fill ~393 ~155 ~598 ~393 ~155 ~610 minecraft:redstone_wire replace
fill ~396 ~155 ~598 ~396 ~155 ~610 minecraft:redstone_wire replace
fill ~399 ~155 ~598 ~399 ~155 ~610 minecraft:redstone_wire replace
setblock ~162 ~155 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~402 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~612 minecraft:redstone_wire replace
setblock ~168 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
