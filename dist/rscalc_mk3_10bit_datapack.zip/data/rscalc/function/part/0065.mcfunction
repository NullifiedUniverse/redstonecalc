fill ~78 ~27 ~292 ~78 ~27 ~304 minecraft:redstone_wire replace
setblock ~111 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~292 ~117 ~27 ~304 minecraft:redstone_wire replace
fill ~129 ~27 ~292 ~129 ~27 ~304 minecraft:redstone_wire replace
fill ~165 ~27 ~292 ~165 ~27 ~304 minecraft:redstone_wire replace
setblock ~171 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~292 ~186 ~27 ~304 minecraft:redstone_wire replace
fill ~192 ~27 ~292 ~192 ~27 ~304 minecraft:redstone_wire replace
setblock ~213 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~27 ~292 ~219 ~27 ~304 minecraft:redstone_wire replace
setblock ~234 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~292 ~240 ~27 ~304 minecraft:redstone_wire replace
fill ~246 ~27 ~292 ~246 ~27 ~304 minecraft:redstone_wire replace
fill ~264 ~27 ~292 ~264 ~27 ~304 minecraft:redstone_wire replace
fill ~273 ~27 ~292 ~273 ~27 ~304 minecraft:redstone_wire replace
setblock ~312 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~292 ~339 ~27 ~304 minecraft:redstone_wire replace
setblock ~84 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~294 ~111 ~27 ~306 minecraft:redstone_wire replace
setblock ~141 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~294 ~171 ~27 ~306 minecraft:redstone_wire replace
setblock ~195 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~294 ~234 ~27 ~306 minecraft:redstone_wire replace
setblock ~258 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~294 ~312 ~27 ~306 minecraft:redstone_wire replace
setblock ~330 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~296 ~84 ~27 ~308 minecraft:redstone_wire replace
setblock ~87 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~296 ~93 ~27 ~308 minecraft:redstone_wire replace
fill ~96 ~27 ~296 ~96 ~27 ~308 minecraft:redstone_wire replace
fill ~102 ~27 ~296 ~102 ~27 ~308 minecraft:redstone_wire replace
fill ~141 ~27 ~296 ~141 ~27 ~308 minecraft:redstone_wire replace
fill ~168 ~27 ~296 ~168 ~27 ~308 minecraft:redstone_wire replace
fill ~195 ~27 ~296 ~195 ~27 ~308 minecraft:redstone_wire replace
fill ~201 ~27 ~296 ~201 ~27 ~308 minecraft:redstone_wire replace
fill ~222 ~27 ~296 ~222 ~27 ~308 minecraft:redstone_wire replace
setblock ~228 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~27 ~296 ~258 ~27 ~308 minecraft:redstone_wire replace
setblock ~270 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~296 ~276 ~27 ~308 minecraft:redstone_wire replace
fill ~291 ~27 ~296 ~291 ~27 ~308 minecraft:redstone_wire replace
fill ~330 ~27 ~296 ~330 ~27 ~308 minecraft:redstone_wire replace
setblock ~333 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~296 ~336 ~27 ~308 minecraft:redstone_wire replace
fill ~348 ~27 ~296 ~348 ~27 ~308 minecraft:redstone_wire replace
setblock ~351 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~296 ~357 ~27 ~308 minecraft:redstone_wire replace
fill ~87 ~27 ~298 ~87 ~27 ~310 minecraft:redstone_wire replace
setblock ~99 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~298 ~270 ~27 ~310 minecraft:redstone_wire replace
setblock ~279 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~298 ~333 ~27 ~310 minecraft:redstone_wire replace
fill ~351 ~27 ~298 ~351 ~27 ~310 minecraft:redstone_wire replace
fill ~99 ~27 ~300 ~99 ~27 ~312 minecraft:redstone_wire replace
fill ~105 ~27 ~300 ~105 ~27 ~312 minecraft:redstone_wire replace
fill ~120 ~27 ~300 ~120 ~27 ~312 minecraft:redstone_wire replace
setblock ~123 ~27 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~300 ~144 ~27 ~312 minecraft:redstone_wire replace
fill ~162 ~27 ~300 ~162 ~27 ~312 minecraft:redstone_wire replace
fill ~204 ~27 ~300 ~204 ~27 ~312 minecraft:redstone_wire replace
setblock ~231 ~27 ~300 minecraft:redstone_wire replace
fill ~252 ~27 ~300 ~252 ~27 ~304 minecraft:redstone_wire replace
fill ~255 ~27 ~300 ~255 ~27 ~306 minecraft:redstone_wire replace
fill ~261 ~27 ~300 ~261 ~27 ~312 minecraft:redstone_wire replace
fill ~279 ~27 ~300 ~279 ~27 ~312 minecraft:redstone_wire replace
fill ~285 ~27 ~300 ~285 ~27 ~310 minecraft:redstone_wire replace
fill ~288 ~27 ~300 ~288 ~27 ~312 minecraft:redstone_wire replace
fill ~303 ~27 ~300 ~303 ~27 ~312 minecraft:redstone_wire replace
fill ~306 ~27 ~300 ~306 ~27 ~312 minecraft:redstone_wire replace
fill ~354 ~27 ~300 ~354 ~27 ~312 minecraft:redstone_wire replace
setblock ~90 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~302 ~123 ~27 ~314 minecraft:redstone_wire replace
setblock ~138 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~304 ~90 ~27 ~316 minecraft:redstone_wire replace
fill ~108 ~27 ~304 ~108 ~27 ~316 minecraft:redstone_wire replace
fill ~114 ~27 ~304 ~114 ~27 ~316 minecraft:redstone_wire replace
fill ~138 ~27 ~304 ~138 ~27 ~316 minecraft:redstone_wire replace
fill ~150 ~27 ~304 ~150 ~27 ~316 minecraft:redstone_wire replace
fill ~174 ~27 ~304 ~174 ~27 ~316 minecraft:redstone_wire replace
fill ~189 ~27 ~304 ~189 ~27 ~316 minecraft:redstone_wire replace
fill ~198 ~27 ~304 ~198 ~27 ~316 minecraft:redstone_wire replace
fill ~216 ~27 ~304 ~216 ~27 ~316 minecraft:redstone_wire replace
fill ~237 ~27 ~304 ~237 ~27 ~316 minecraft:redstone_wire replace
fill ~243 ~27 ~304 ~243 ~27 ~316 minecraft:redstone_wire replace
fill ~267 ~27 ~304 ~267 ~27 ~316 minecraft:redstone_wire replace
fill ~294 ~27 ~304 ~294 ~27 ~316 minecraft:redstone_wire replace
fill ~297 ~27 ~304 ~297 ~27 ~316 minecraft:redstone_wire replace
fill ~315 ~27 ~304 ~315 ~27 ~316 minecraft:redstone_wire replace
setblock ~318 ~27 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~27 ~304 ~321 ~27 ~316 minecraft:redstone_wire replace
fill ~324 ~27 ~304 ~324 ~27 ~316 minecraft:redstone_wire replace
fill ~342 ~27 ~304 ~342 ~27 ~316 minecraft:redstone_wire replace
setblock ~345 ~27 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~306 ~81 ~27 ~318 minecraft:redstone_wire replace
setblock ~117 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~306 ~318 ~27 ~318 minecraft:redstone_wire replace
setblock ~339 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~306 ~345 ~27 ~318 minecraft:redstone_wire replace
fill ~78 ~27 ~308 ~78 ~27 ~320 minecraft:redstone_wire replace
setblock ~111 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~308 ~117 ~27 ~320 minecraft:redstone_wire replace
fill ~129 ~27 ~308 ~129 ~27 ~320 minecraft:redstone_wire replace
fill ~165 ~27 ~308 ~165 ~27 ~320 minecraft:redstone_wire replace
setblock ~171 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~308 ~186 ~27 ~320 minecraft:redstone_wire replace
fill ~192 ~27 ~308 ~192 ~27 ~320 minecraft:redstone_wire replace
fill ~219 ~27 ~308 ~219 ~27 ~320 minecraft:redstone_wire replace
setblock ~234 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~308 ~240 ~27 ~320 minecraft:redstone_wire replace
fill ~246 ~27 ~308 ~246 ~27 ~320 minecraft:redstone_wire replace
setblock ~255 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~27 ~308 ~264 ~27 ~320 minecraft:redstone_wire replace
fill ~273 ~27 ~308 ~273 ~27 ~320 minecraft:redstone_wire replace
setblock ~312 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~308 ~339 ~27 ~320 minecraft:redstone_wire replace
setblock ~84 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~310 ~111 ~27 ~322 minecraft:redstone_wire replace
setblock ~141 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~310 ~171 ~27 ~322 minecraft:redstone_wire replace
setblock ~195 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~310 ~234 ~27 ~322 minecraft:redstone_wire replace
setblock ~258 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~310 ~312 ~27 ~322 minecraft:redstone_wire replace
setblock ~330 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~312 ~84 ~27 ~324 minecraft:redstone_wire replace
setblock ~87 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~312 ~93 ~27 ~324 minecraft:redstone_wire replace
fill ~96 ~27 ~312 ~96 ~27 ~324 minecraft:redstone_wire replace
fill ~102 ~27 ~312 ~102 ~27 ~324 minecraft:redstone_wire replace
fill ~141 ~27 ~312 ~141 ~27 ~324 minecraft:redstone_wire replace
fill ~168 ~27 ~312 ~168 ~27 ~324 minecraft:redstone_wire replace
fill ~195 ~27 ~312 ~195 ~27 ~324 minecraft:redstone_wire replace
fill ~201 ~27 ~312 ~201 ~27 ~324 minecraft:redstone_wire replace
fill ~222 ~27 ~312 ~222 ~27 ~324 minecraft:redstone_wire replace
fill ~258 ~27 ~312 ~258 ~27 ~324 minecraft:redstone_wire replace
setblock ~270 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~312 ~276 ~27 ~324 minecraft:redstone_wire replace
setblock ~285 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~312 ~291 ~27 ~324 minecraft:redstone_wire replace
fill ~330 ~27 ~312 ~330 ~27 ~324 minecraft:redstone_wire replace
setblock ~333 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~312 ~336 ~27 ~324 minecraft:redstone_wire replace
fill ~348 ~27 ~312 ~348 ~27 ~324 minecraft:redstone_wire replace
setblock ~351 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~312 ~357 ~27 ~324 minecraft:redstone_wire replace
fill ~87 ~27 ~314 ~87 ~27 ~326 minecraft:redstone_wire replace
setblock ~99 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~314 ~270 ~27 ~326 minecraft:redstone_wire replace
setblock ~279 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~314 ~333 ~27 ~326 minecraft:redstone_wire replace
fill ~351 ~27 ~314 ~351 ~27 ~326 minecraft:redstone_wire replace
setblock ~354 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~316 ~99 ~27 ~328 minecraft:redstone_wire replace
fill ~105 ~27 ~316 ~105 ~27 ~328 minecraft:redstone_wire replace
fill ~120 ~27 ~316 ~120 ~27 ~328 minecraft:redstone_wire replace
setblock ~123 ~27 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~316 ~144 ~27 ~328 minecraft:redstone_wire replace
fill ~162 ~27 ~316 ~162 ~27 ~328 minecraft:redstone_wire replace
fill ~204 ~27 ~316 ~204 ~27 ~328 minecraft:redstone_wire replace
fill ~261 ~27 ~316 ~261 ~27 ~328 minecraft:redstone_wire replace
fill ~279 ~27 ~316 ~279 ~27 ~328 minecraft:redstone_wire replace
setblock ~288 ~27 ~316 minecraft:redstone_wire replace
fill ~303 ~27 ~316 ~303 ~27 ~326 minecraft:redstone_wire replace
fill ~306 ~27 ~316 ~306 ~27 ~328 minecraft:redstone_wire replace
fill ~354 ~27 ~316 ~354 ~27 ~328 minecraft:redstone_wire replace
setblock ~90 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~318 ~123 ~27 ~330 minecraft:redstone_wire replace
setblock ~138 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~320 ~90 ~27 ~332 minecraft:redstone_wire replace
fill ~108 ~27 ~320 ~108 ~27 ~332 minecraft:redstone_wire replace
fill ~114 ~27 ~320 ~114 ~27 ~332 minecraft:redstone_wire replace
fill ~138 ~27 ~320 ~138 ~27 ~332 minecraft:redstone_wire replace
fill ~150 ~27 ~320 ~150 ~27 ~332 minecraft:redstone_wire replace
fill ~174 ~27 ~320 ~174 ~27 ~332 minecraft:redstone_wire replace
fill ~189 ~27 ~320 ~189 ~27 ~332 minecraft:redstone_wire replace
fill ~198 ~27 ~320 ~198 ~27 ~332 minecraft:redstone_wire replace
fill ~216 ~27 ~320 ~216 ~27 ~332 minecraft:redstone_wire replace
fill ~237 ~27 ~320 ~237 ~27 ~332 minecraft:redstone_wire replace
fill ~243 ~27 ~320 ~243 ~27 ~332 minecraft:redstone_wire replace
fill ~267 ~27 ~320 ~267 ~27 ~332 minecraft:redstone_wire replace
setblock ~294 ~27 ~320 minecraft:redstone_wire replace
fill ~297 ~27 ~320 ~297 ~27 ~324 minecraft:redstone_wire replace
fill ~315 ~27 ~320 ~315 ~27 ~332 minecraft:redstone_wire replace
setblock ~318 ~27 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~27 ~320 ~321 ~27 ~332 minecraft:redstone_wire replace
fill ~324 ~27 ~320 ~324 ~27 ~332 minecraft:redstone_wire replace
fill ~342 ~27 ~320 ~342 ~27 ~332 minecraft:redstone_wire replace
setblock ~345 ~27 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~322 ~81 ~27 ~334 minecraft:redstone_wire replace
setblock ~117 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~322 ~318 ~27 ~334 minecraft:redstone_wire replace
setblock ~339 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~322 ~345 ~27 ~334 minecraft:redstone_wire replace
fill ~78 ~27 ~324 ~78 ~27 ~336 minecraft:redstone_wire replace
setblock ~111 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~324 ~117 ~27 ~336 minecraft:redstone_wire replace
fill ~129 ~27 ~324 ~129 ~27 ~336 minecraft:redstone_wire replace
fill ~165 ~27 ~324 ~165 ~27 ~336 minecraft:redstone_wire replace
setblock ~171 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~324 ~186 ~27 ~336 minecraft:redstone_wire replace
fill ~192 ~27 ~324 ~192 ~27 ~336 minecraft:redstone_wire replace
fill ~219 ~27 ~324 ~219 ~27 ~336 minecraft:redstone_wire replace
setblock ~234 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~324 ~240 ~27 ~336 minecraft:redstone_wire replace
fill ~246 ~27 ~324 ~246 ~27 ~336 minecraft:redstone_wire replace
fill ~264 ~27 ~324 ~264 ~27 ~336 minecraft:redstone_wire replace
fill ~273 ~27 ~324 ~273 ~27 ~336 minecraft:redstone_wire replace
setblock ~312 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~324 ~339 ~27 ~336 minecraft:redstone_wire replace
setblock ~84 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~326 ~111 ~27 ~338 minecraft:redstone_wire replace
setblock ~141 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~326 ~171 ~27 ~338 minecraft:redstone_wire replace
setblock ~195 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~326 ~234 ~27 ~338 minecraft:redstone_wire replace
setblock ~258 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~326 ~312 ~27 ~338 minecraft:redstone_wire replace
setblock ~330 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~328 ~84 ~27 ~340 minecraft:redstone_wire replace
setblock ~87 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~328 ~93 ~27 ~340 minecraft:redstone_wire replace
fill ~96 ~27 ~328 ~96 ~27 ~340 minecraft:redstone_wire replace
fill ~102 ~27 ~328 ~102 ~27 ~340 minecraft:redstone_wire replace
fill ~141 ~27 ~328 ~141 ~27 ~340 minecraft:redstone_wire replace
fill ~168 ~27 ~328 ~168 ~27 ~340 minecraft:redstone_wire replace
fill ~195 ~27 ~328 ~195 ~27 ~340 minecraft:redstone_wire replace
fill ~201 ~27 ~328 ~201 ~27 ~340 minecraft:redstone_wire replace
fill ~222 ~27 ~328 ~222 ~27 ~340 minecraft:redstone_wire replace
fill ~258 ~27 ~328 ~258 ~27 ~340 minecraft:redstone_wire replace
setblock ~270 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~328 ~276 ~27 ~340 minecraft:redstone_wire replace
fill ~291 ~27 ~328 ~291 ~27 ~340 minecraft:redstone_wire replace
setblock ~303 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~330 ~27 ~328 ~330 ~27 ~340 minecraft:redstone_wire replace
setblock ~333 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~328 ~336 ~27 ~340 minecraft:redstone_wire replace
fill ~348 ~27 ~328 ~348 ~27 ~340 minecraft:redstone_wire replace
setblock ~351 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~328 ~357 ~27 ~340 minecraft:redstone_wire replace
fill ~87 ~27 ~330 ~87 ~27 ~342 minecraft:redstone_wire replace
setblock ~99 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~330 ~270 ~27 ~342 minecraft:redstone_wire replace
setblock ~279 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~330 ~333 ~27 ~342 minecraft:redstone_wire replace
fill ~351 ~27 ~330 ~351 ~27 ~342 minecraft:redstone_wire replace
setblock ~354 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~332 ~99 ~27 ~344 minecraft:redstone_wire replace
fill ~105 ~27 ~332 ~105 ~27 ~344 minecraft:redstone_wire replace
fill ~120 ~27 ~332 ~120 ~27 ~344 minecraft:redstone_wire replace
setblock ~123 ~27 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~332 ~144 ~27 ~344 minecraft:redstone_wire replace
fill ~162 ~27 ~332 ~162 ~27 ~344 minecraft:redstone_wire replace
fill ~204 ~27 ~332 ~204 ~27 ~344 minecraft:redstone_wire replace
fill ~261 ~27 ~332 ~261 ~27 ~344 minecraft:redstone_wire replace
fill ~279 ~27 ~332 ~279 ~27 ~344 minecraft:redstone_wire replace
setblock ~306 ~27 ~332 minecraft:redstone_wire replace
fill ~354 ~27 ~332 ~354 ~27 ~344 minecraft:redstone_wire replace
setblock ~90 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~334 ~123 ~27 ~346 minecraft:redstone_wire replace
setblock ~138 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~336 ~90 ~27 ~342 minecraft:redstone_wire replace
fill ~108 ~27 ~336 ~108 ~27 ~348 minecraft:redstone_wire replace
fill ~114 ~27 ~336 ~114 ~27 ~348 minecraft:redstone_wire replace
fill ~138 ~27 ~336 ~138 ~27 ~348 minecraft:redstone_wire replace
fill ~150 ~27 ~336 ~150 ~27 ~348 minecraft:redstone_wire replace
fill ~174 ~27 ~336 ~174 ~27 ~348 minecraft:redstone_wire replace
fill ~189 ~27 ~336 ~189 ~27 ~348 minecraft:redstone_wire replace
fill ~198 ~27 ~336 ~198 ~27 ~348 minecraft:redstone_wire replace
fill ~216 ~27 ~336 ~216 ~27 ~348 minecraft:redstone_wire replace
fill ~237 ~27 ~336 ~237 ~27 ~348 minecraft:redstone_wire replace
fill ~243 ~27 ~336 ~243 ~27 ~348 minecraft:redstone_wire replace
fill ~267 ~27 ~336 ~267 ~27 ~348 minecraft:redstone_wire replace
fill ~315 ~27 ~336 ~315 ~27 ~348 minecraft:redstone_wire replace
setblock ~318 ~27 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~336 minecraft:redstone_wire replace
fill ~324 ~27 ~336 ~324 ~27 ~340 minecraft:redstone_wire replace
fill ~342 ~27 ~336 ~342 ~27 ~348 minecraft:redstone_wire replace
setblock ~345 ~27 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~338 ~81 ~27 ~350 minecraft:redstone_wire replace
setblock ~117 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~338 ~318 ~27 ~350 minecraft:redstone_wire replace
setblock ~339 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~338 ~345 ~27 ~350 minecraft:redstone_wire replace
fill ~78 ~27 ~340 ~78 ~27 ~352 minecraft:redstone_wire replace
setblock ~111 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~340 ~117 ~27 ~352 minecraft:redstone_wire replace
fill ~129 ~27 ~340 ~129 ~27 ~352 minecraft:redstone_wire replace
fill ~165 ~27 ~340 ~165 ~27 ~352 minecraft:redstone_wire replace
setblock ~171 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~340 ~186 ~27 ~352 minecraft:redstone_wire replace
fill ~192 ~27 ~340 ~192 ~27 ~352 minecraft:redstone_wire replace
fill ~219 ~27 ~340 ~219 ~27 ~352 minecraft:redstone_wire replace
setblock ~234 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~340 ~240 ~27 ~352 minecraft:redstone_wire replace
fill ~246 ~27 ~340 ~246 ~27 ~352 minecraft:redstone_wire replace
fill ~264 ~27 ~340 ~264 ~27 ~352 minecraft:redstone_wire replace
fill ~273 ~27 ~340 ~273 ~27 ~352 minecraft:redstone_wire replace
setblock ~312 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~340 ~339 ~27 ~352 minecraft:redstone_wire replace
setblock ~84 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~342 ~111 ~27 ~348 minecraft:redstone_wire replace
setblock ~141 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~342 ~171 ~27 ~354 minecraft:redstone_wire replace
setblock ~195 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~342 ~234 ~27 ~354 minecraft:redstone_wire replace
setblock ~258 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~342 ~312 ~27 ~354 minecraft:redstone_wire replace
setblock ~330 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~344 ~84 ~27 ~356 minecraft:redstone_wire replace
setblock ~87 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~344 ~93 ~27 ~356 minecraft:redstone_wire replace
fill ~96 ~27 ~344 ~96 ~27 ~356 minecraft:redstone_wire replace
fill ~102 ~27 ~344 ~102 ~27 ~356 minecraft:redstone_wire replace
fill ~141 ~27 ~344 ~141 ~27 ~356 minecraft:redstone_wire replace
fill ~168 ~27 ~344 ~168 ~27 ~356 minecraft:redstone_wire replace
fill ~195 ~27 ~344 ~195 ~27 ~356 minecraft:redstone_wire replace
fill ~201 ~27 ~344 ~201 ~27 ~356 minecraft:redstone_wire replace
fill ~222 ~27 ~344 ~222 ~27 ~356 minecraft:redstone_wire replace
fill ~258 ~27 ~344 ~258 ~27 ~356 minecraft:redstone_wire replace
setblock ~270 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~344 ~276 ~27 ~356 minecraft:redstone_wire replace
fill ~291 ~27 ~344 ~291 ~27 ~356 minecraft:redstone_wire replace
fill ~330 ~27 ~344 ~330 ~27 ~356 minecraft:redstone_wire replace
setblock ~333 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~344 ~336 ~27 ~356 minecraft:redstone_wire replace
fill ~348 ~27 ~344 ~348 ~27 ~356 minecraft:redstone_wire replace
setblock ~351 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~344 ~357 ~27 ~356 minecraft:redstone_wire replace
fill ~87 ~27 ~346 ~87 ~27 ~358 minecraft:redstone_wire replace
setblock ~99 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~346 ~270 ~27 ~358 minecraft:redstone_wire replace
setblock ~279 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~346 ~333 ~27 ~358 minecraft:redstone_wire replace
fill ~351 ~27 ~346 ~351 ~27 ~358 minecraft:redstone_wire replace
setblock ~354 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~348 ~99 ~27 ~360 minecraft:redstone_wire replace
fill ~105 ~27 ~348 ~105 ~27 ~360 minecraft:redstone_wire replace
fill ~120 ~27 ~348 ~120 ~27 ~360 minecraft:redstone_wire replace
setblock ~123 ~27 ~348 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~348 ~144 ~27 ~360 minecraft:redstone_wire replace
fill ~162 ~27 ~348 ~162 ~27 ~360 minecraft:redstone_wire replace
fill ~204 ~27 ~348 ~204 ~27 ~360 minecraft:redstone_wire replace
fill ~261 ~27 ~348 ~261 ~27 ~360 minecraft:redstone_wire replace
fill ~279 ~27 ~348 ~279 ~27 ~360 minecraft:redstone_wire replace
fill ~354 ~27 ~348 ~354 ~27 ~360 minecraft:redstone_wire replace
setblock ~108 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~350 ~123 ~27 ~362 minecraft:redstone_wire replace
setblock ~138 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~27 ~352 ~108 ~27 ~364 minecraft:redstone_wire replace
fill ~114 ~27 ~352 ~114 ~27 ~364 minecraft:redstone_wire replace
setblock ~138 ~27 ~352 minecraft:redstone_wire replace
fill ~150 ~27 ~352 ~150 ~27 ~364 minecraft:redstone_wire replace
fill ~174 ~27 ~352 ~174 ~27 ~364 minecraft:redstone_wire replace
fill ~189 ~27 ~352 ~189 ~27 ~364 minecraft:redstone_wire replace
fill ~198 ~27 ~352 ~198 ~27 ~358 minecraft:redstone_wire replace
fill ~216 ~27 ~352 ~216 ~27 ~364 minecraft:redstone_wire replace
fill ~237 ~27 ~352 ~237 ~27 ~364 minecraft:redstone_wire replace
fill ~243 ~27 ~352 ~243 ~27 ~364 minecraft:redstone_wire replace
fill ~267 ~27 ~352 ~267 ~27 ~364 minecraft:redstone_wire replace
fill ~315 ~27 ~352 ~315 ~27 ~364 minecraft:redstone_wire replace
setblock ~318 ~27 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~352 ~342 ~27 ~364 minecraft:redstone_wire replace
setblock ~345 ~27 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~354 ~81 ~27 ~366 minecraft:redstone_wire replace
setblock ~117 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~354 ~318 ~27 ~366 minecraft:redstone_wire replace
setblock ~339 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~354 ~345 ~27 ~366 minecraft:redstone_wire replace
setblock ~171 ~27 ~355 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~356 ~78 ~27 ~368 minecraft:redstone_wire replace
fill ~117 ~27 ~356 ~117 ~27 ~368 minecraft:redstone_wire replace
fill ~129 ~27 ~356 ~129 ~27 ~368 minecraft:redstone_wire replace
fill ~165 ~27 ~356 ~165 ~27 ~368 minecraft:redstone_wire replace
setblock ~171 ~27 ~356 minecraft:redstone_wire replace
fill ~186 ~27 ~356 ~186 ~27 ~368 minecraft:redstone_wire replace
fill ~192 ~27 ~356 ~192 ~27 ~368 minecraft:redstone_wire replace
fill ~219 ~27 ~356 ~219 ~27 ~368 minecraft:redstone_wire replace
setblock ~234 ~27 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~356 ~240 ~27 ~368 minecraft:redstone_wire replace
fill ~246 ~27 ~356 ~246 ~27 ~368 minecraft:redstone_wire replace
fill ~264 ~27 ~356 ~264 ~27 ~368 minecraft:redstone_wire replace
fill ~273 ~27 ~356 ~273 ~27 ~368 minecraft:redstone_wire replace
setblock ~312 ~27 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~356 ~339 ~27 ~368 minecraft:redstone_wire replace
setblock ~84 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~358 ~234 ~27 ~364 minecraft:redstone_wire replace
setblock ~258 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~358 ~312 ~27 ~370 minecraft:redstone_wire replace
setblock ~330 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~360 ~84 ~27 ~372 minecraft:redstone_wire replace
setblock ~87 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~360 ~93 ~27 ~372 minecraft:redstone_wire replace
fill ~96 ~27 ~360 ~96 ~27 ~372 minecraft:redstone_wire replace
fill ~102 ~27 ~360 ~102 ~27 ~372 minecraft:redstone_wire replace
fill ~141 ~27 ~360 ~141 ~27 ~372 minecraft:redstone_wire replace
fill ~168 ~27 ~360 ~168 ~27 ~372 minecraft:redstone_wire replace
fill ~195 ~27 ~360 ~195 ~27 ~372 minecraft:redstone_wire replace
setblock ~198 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~27 ~360 ~201 ~27 ~372 minecraft:redstone_wire replace
fill ~222 ~27 ~360 ~222 ~27 ~372 minecraft:redstone_wire replace
fill ~258 ~27 ~360 ~258 ~27 ~372 minecraft:redstone_wire replace
setblock ~270 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~360 ~276 ~27 ~372 minecraft:redstone_wire replace
fill ~291 ~27 ~360 ~291 ~27 ~372 minecraft:redstone_wire replace
fill ~330 ~27 ~360 ~330 ~27 ~372 minecraft:redstone_wire replace
setblock ~333 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~360 ~336 ~27 ~372 minecraft:redstone_wire replace
