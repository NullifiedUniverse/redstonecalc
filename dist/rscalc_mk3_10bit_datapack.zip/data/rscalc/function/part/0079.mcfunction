fill ~261 ~51 ~222 ~261 ~51 ~234 minecraft:redstone_wire replace
setblock ~258 ~51 ~224 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~226 ~258 ~51 ~238 minecraft:redstone_wire replace
setblock ~213 ~51 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~232 ~213 ~51 ~244 minecraft:redstone_wire replace
setblock ~261 ~51 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~238 ~261 ~51 ~250 minecraft:redstone_wire replace
fill ~93 ~51 ~240 ~93 ~51 ~246 minecraft:redstone_wire replace
setblock ~258 ~51 ~240 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~242 ~258 ~51 ~254 minecraft:redstone_wire replace
setblock ~213 ~51 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~51 ~248 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~248 ~213 ~51 ~260 minecraft:redstone_wire replace
setblock ~261 ~51 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~254 ~261 ~51 ~266 minecraft:redstone_wire replace
setblock ~258 ~51 ~256 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~258 ~258 ~51 ~270 minecraft:redstone_wire replace
fill ~117 ~51 ~260 ~117 ~51 ~266 minecraft:redstone_wire replace
setblock ~213 ~51 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~264 ~213 ~51 ~276 minecraft:redstone_wire replace
setblock ~117 ~51 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~51 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~270 ~261 ~51 ~282 minecraft:redstone_wire replace
setblock ~258 ~51 ~272 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~274 ~258 ~51 ~286 minecraft:redstone_wire replace
fill ~138 ~51 ~276 ~138 ~51 ~282 minecraft:redstone_wire replace
setblock ~213 ~51 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~280 ~213 ~51 ~292 minecraft:redstone_wire replace
setblock ~138 ~51 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~51 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~286 ~261 ~51 ~298 minecraft:redstone_wire replace
fill ~156 ~51 ~288 ~156 ~51 ~294 minecraft:redstone_wire replace
setblock ~258 ~51 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~290 ~258 ~51 ~302 minecraft:redstone_wire replace
setblock ~213 ~51 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~51 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~296 ~213 ~51 ~308 minecraft:redstone_wire replace
setblock ~261 ~51 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~302 ~261 ~51 ~314 minecraft:redstone_wire replace
setblock ~258 ~51 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~306 ~258 ~51 ~318 minecraft:redstone_wire replace
fill ~192 ~51 ~308 ~192 ~51 ~320 minecraft:redstone_wire replace
setblock ~213 ~51 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~51 ~312 ~171 ~51 ~318 minecraft:redstone_wire replace
fill ~213 ~51 ~312 ~213 ~51 ~324 minecraft:redstone_wire replace
setblock ~261 ~51 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~318 ~261 ~51 ~330 minecraft:redstone_wire replace
setblock ~171 ~51 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~51 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~51 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~322 ~258 ~51 ~334 minecraft:redstone_wire replace
fill ~192 ~51 ~324 ~192 ~51 ~328 minecraft:redstone_wire replace
setblock ~213 ~51 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~328 ~213 ~51 ~340 minecraft:redstone_wire replace
setblock ~261 ~51 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~334 ~261 ~51 ~346 minecraft:redstone_wire replace
fill ~195 ~51 ~336 ~195 ~51 ~340 minecraft:redstone_wire replace
setblock ~258 ~51 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~338 ~258 ~51 ~350 minecraft:redstone_wire replace
setblock ~213 ~51 ~341 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~342 ~213 ~51 ~344 minecraft:redstone_wire replace
setblock ~261 ~51 ~348 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~350 ~261 ~51 ~362 minecraft:redstone_wire replace
fill ~216 ~51 ~352 ~216 ~51 ~356 minecraft:redstone_wire replace
setblock ~258 ~51 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~354 ~258 ~51 ~366 minecraft:redstone_wire replace
setblock ~261 ~51 ~363 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~51 ~364 minecraft:redstone_wire replace
fill ~264 ~51 ~364 ~264 ~51 ~368 minecraft:redstone_wire replace
setblock ~258 ~51 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~370 ~258 ~51 ~376 minecraft:redstone_wire replace
fill ~234 ~51 ~380 ~234 ~51 ~384 minecraft:redstone_wire replace
fill ~288 ~51 ~384 ~288 ~51 ~388 minecraft:redstone_wire replace
fill ~309 ~51 ~388 ~309 ~51 ~392 minecraft:redstone_wire replace
fill ~276 ~51 ~392 ~276 ~51 ~396 minecraft:redstone_wire replace
fill ~300 ~51 ~396 ~300 ~51 ~400 minecraft:redstone_wire replace
fill ~270 ~51 ~400 ~270 ~51 ~404 minecraft:redstone_wire replace
fill ~90 ~51 ~408 ~90 ~51 ~412 minecraft:redstone_wire replace
fill ~114 ~51 ~412 ~114 ~51 ~416 minecraft:redstone_wire replace
fill ~135 ~51 ~416 ~135 ~51 ~420 minecraft:redstone_wire replace
fill ~162 ~51 ~420 ~162 ~51 ~424 minecraft:redstone_wire replace
fill ~183 ~51 ~424 ~183 ~51 ~428 minecraft:redstone_wire replace
fill ~207 ~51 ~428 ~207 ~51 ~432 minecraft:redstone_wire replace
fill ~231 ~51 ~432 ~231 ~51 ~436 minecraft:redstone_wire replace
fill ~252 ~51 ~436 ~252 ~51 ~440 minecraft:redstone_wire replace
fill ~267 ~51 ~440 ~267 ~51 ~444 minecraft:redstone_wire replace
fill ~87 ~51 ~444 ~87 ~51 ~448 minecraft:redstone_wire replace
fill ~111 ~51 ~448 ~111 ~51 ~452 minecraft:redstone_wire replace
fill ~132 ~51 ~452 ~132 ~51 ~456 minecraft:redstone_wire replace
fill ~159 ~51 ~456 ~159 ~51 ~460 minecraft:redstone_wire replace
fill ~180 ~51 ~460 ~180 ~51 ~464 minecraft:redstone_wire replace
fill ~204 ~51 ~464 ~204 ~51 ~468 minecraft:redstone_wire replace
fill ~228 ~51 ~468 ~228 ~51 ~472 minecraft:redstone_wire replace
fill ~249 ~51 ~472 ~249 ~51 ~476 minecraft:redstone_wire replace
fill ~291 ~51 ~476 ~291 ~51 ~480 minecraft:redstone_wire replace
fill ~315 ~51 ~480 ~315 ~51 ~484 minecraft:redstone_wire replace
fill ~84 ~51 ~484 ~84 ~51 ~488 minecraft:redstone_wire replace
fill ~108 ~51 ~488 ~108 ~51 ~492 minecraft:redstone_wire replace
fill ~129 ~51 ~492 ~129 ~51 ~496 minecraft:redstone_wire replace
fill ~153 ~51 ~496 ~153 ~51 ~500 minecraft:redstone_wire replace
fill ~177 ~51 ~500 ~177 ~51 ~504 minecraft:redstone_wire replace
fill ~201 ~51 ~504 ~201 ~51 ~508 minecraft:redstone_wire replace
fill ~225 ~51 ~508 ~225 ~51 ~512 minecraft:redstone_wire replace
fill ~246 ~51 ~512 ~246 ~51 ~516 minecraft:redstone_wire replace
fill ~285 ~51 ~516 ~285 ~51 ~520 minecraft:redstone_wire replace
fill ~312 ~51 ~520 ~312 ~51 ~524 minecraft:redstone_wire replace
fill ~81 ~51 ~524 ~81 ~51 ~528 minecraft:redstone_wire replace
fill ~105 ~51 ~528 ~105 ~51 ~532 minecraft:redstone_wire replace
fill ~126 ~51 ~532 ~126 ~51 ~536 minecraft:redstone_wire replace
fill ~147 ~51 ~536 ~147 ~51 ~540 minecraft:redstone_wire replace
fill ~174 ~51 ~540 ~174 ~51 ~544 minecraft:redstone_wire replace
fill ~198 ~51 ~544 ~198 ~51 ~548 minecraft:redstone_wire replace
fill ~222 ~51 ~548 ~222 ~51 ~552 minecraft:redstone_wire replace
fill ~240 ~51 ~552 ~240 ~51 ~556 minecraft:redstone_wire replace
fill ~282 ~51 ~556 ~282 ~51 ~560 minecraft:redstone_wire replace
fill ~306 ~51 ~560 ~306 ~51 ~564 minecraft:redstone_wire replace
fill ~78 ~51 ~564 ~78 ~51 ~568 minecraft:redstone_wire replace
fill ~102 ~51 ~568 ~102 ~51 ~572 minecraft:redstone_wire replace
fill ~123 ~51 ~572 ~123 ~51 ~576 minecraft:redstone_wire replace
fill ~144 ~51 ~576 ~144 ~51 ~580 minecraft:redstone_wire replace
fill ~168 ~51 ~580 ~168 ~51 ~584 minecraft:redstone_wire replace
fill ~189 ~51 ~584 ~189 ~51 ~588 minecraft:redstone_wire replace
fill ~219 ~51 ~588 ~219 ~51 ~592 minecraft:redstone_wire replace
fill ~237 ~51 ~592 ~237 ~51 ~596 minecraft:redstone_wire replace
fill ~279 ~51 ~596 ~279 ~51 ~600 minecraft:redstone_wire replace
fill ~303 ~51 ~600 ~303 ~51 ~604 minecraft:redstone_wire replace
fill ~99 ~51 ~604 ~99 ~51 ~608 minecraft:redstone_wire replace
fill ~120 ~51 ~608 ~120 ~51 ~612 minecraft:redstone_wire replace
fill ~141 ~51 ~612 ~141 ~51 ~616 minecraft:redstone_wire replace
fill ~165 ~51 ~616 ~165 ~51 ~620 minecraft:redstone_wire replace
fill ~186 ~51 ~620 ~186 ~51 ~624 minecraft:redstone_wire replace
fill ~210 ~51 ~624 ~210 ~51 ~628 minecraft:redstone_wire replace
fill ~243 ~51 ~628 ~243 ~51 ~632 minecraft:redstone_wire replace
fill ~255 ~51 ~632 ~255 ~51 ~636 minecraft:redstone_wire replace
fill ~294 ~51 ~636 ~294 ~51 ~640 minecraft:redstone_wire replace
fill ~150 ~51 ~640 ~150 ~51 ~644 minecraft:redstone_wire replace
fill ~321 ~51 ~644 ~321 ~51 ~648 minecraft:redstone_wire replace
fill ~96 ~51 ~648 ~96 ~51 ~652 minecraft:redstone_wire replace
fill ~297 ~51 ~652 ~297 ~51 ~656 minecraft:redstone_wire replace
fill ~318 ~51 ~656 ~318 ~51 ~660 minecraft:redstone_wire replace
setblock ~273 ~52 ~77 minecraft:redstone_wire replace
setblock ~93 ~52 ~249 minecraft:redstone_wire replace
setblock ~117 ~52 ~269 minecraft:redstone_wire replace
setblock ~138 ~52 ~285 minecraft:redstone_wire replace
setblock ~156 ~52 ~297 minecraft:redstone_wire replace
setblock ~171 ~52 ~321 minecraft:redstone_wire replace
setblock ~192 ~52 ~329 minecraft:redstone_wire replace
setblock ~195 ~52 ~341 minecraft:redstone_wire replace
setblock ~213 ~52 ~345 minecraft:redstone_wire replace
setblock ~216 ~52 ~357 minecraft:redstone_wire replace
setblock ~261 ~52 ~365 minecraft:redstone_wire replace
setblock ~264 ~52 ~369 minecraft:redstone_wire replace
setblock ~258 ~52 ~377 minecraft:redstone_wire replace
setblock ~234 ~52 ~385 minecraft:redstone_wire replace
setblock ~288 ~52 ~389 minecraft:redstone_wire replace
setblock ~309 ~52 ~393 minecraft:redstone_wire replace
setblock ~276 ~52 ~397 minecraft:redstone_wire replace
setblock ~300 ~52 ~401 minecraft:redstone_wire replace
setblock ~270 ~52 ~405 minecraft:redstone_wire replace
setblock ~90 ~52 ~413 minecraft:redstone_wire replace
setblock ~114 ~52 ~417 minecraft:redstone_wire replace
setblock ~135 ~52 ~421 minecraft:redstone_wire replace
setblock ~162 ~52 ~425 minecraft:redstone_wire replace
setblock ~183 ~52 ~429 minecraft:redstone_wire replace
setblock ~207 ~52 ~433 minecraft:redstone_wire replace
setblock ~231 ~52 ~437 minecraft:redstone_wire replace
setblock ~252 ~52 ~441 minecraft:redstone_wire replace
setblock ~267 ~52 ~445 minecraft:redstone_wire replace
setblock ~87 ~52 ~449 minecraft:redstone_wire replace
setblock ~111 ~52 ~453 minecraft:redstone_wire replace
setblock ~132 ~52 ~457 minecraft:redstone_wire replace
setblock ~159 ~52 ~461 minecraft:redstone_wire replace
setblock ~180 ~52 ~465 minecraft:redstone_wire replace
setblock ~204 ~52 ~469 minecraft:redstone_wire replace
setblock ~228 ~52 ~473 minecraft:redstone_wire replace
setblock ~249 ~52 ~477 minecraft:redstone_wire replace
setblock ~291 ~52 ~481 minecraft:redstone_wire replace
setblock ~315 ~52 ~485 minecraft:redstone_wire replace
setblock ~84 ~52 ~489 minecraft:redstone_wire replace
setblock ~108 ~52 ~493 minecraft:redstone_wire replace
setblock ~129 ~52 ~497 minecraft:redstone_wire replace
setblock ~153 ~52 ~501 minecraft:redstone_wire replace
setblock ~177 ~52 ~505 minecraft:redstone_wire replace
setblock ~201 ~52 ~509 minecraft:redstone_wire replace
setblock ~225 ~52 ~513 minecraft:redstone_wire replace
setblock ~246 ~52 ~517 minecraft:redstone_wire replace
setblock ~285 ~52 ~521 minecraft:redstone_wire replace
setblock ~312 ~52 ~525 minecraft:redstone_wire replace
setblock ~81 ~52 ~529 minecraft:redstone_wire replace
setblock ~105 ~52 ~533 minecraft:redstone_wire replace
setblock ~126 ~52 ~537 minecraft:redstone_wire replace
setblock ~147 ~52 ~541 minecraft:redstone_wire replace
setblock ~174 ~52 ~545 minecraft:redstone_wire replace
setblock ~198 ~52 ~549 minecraft:redstone_wire replace
setblock ~222 ~52 ~553 minecraft:redstone_wire replace
setblock ~240 ~52 ~557 minecraft:redstone_wire replace
setblock ~282 ~52 ~561 minecraft:redstone_wire replace
setblock ~306 ~52 ~565 minecraft:redstone_wire replace
setblock ~78 ~52 ~569 minecraft:redstone_wire replace
setblock ~102 ~52 ~573 minecraft:redstone_wire replace
setblock ~123 ~52 ~577 minecraft:redstone_wire replace
setblock ~144 ~52 ~581 minecraft:redstone_wire replace
setblock ~168 ~52 ~585 minecraft:redstone_wire replace
setblock ~189 ~52 ~589 minecraft:redstone_wire replace
setblock ~219 ~52 ~593 minecraft:redstone_wire replace
setblock ~237 ~52 ~597 minecraft:redstone_wire replace
setblock ~279 ~52 ~601 minecraft:redstone_wire replace
setblock ~303 ~52 ~605 minecraft:redstone_wire replace
setblock ~99 ~52 ~609 minecraft:redstone_wire replace
setblock ~120 ~52 ~613 minecraft:redstone_wire replace
setblock ~141 ~52 ~617 minecraft:redstone_wire replace
setblock ~165 ~52 ~621 minecraft:redstone_wire replace
setblock ~186 ~52 ~625 minecraft:redstone_wire replace
setblock ~210 ~52 ~629 minecraft:redstone_wire replace
setblock ~243 ~52 ~633 minecraft:redstone_wire replace
setblock ~255 ~52 ~637 minecraft:redstone_wire replace
setblock ~294 ~52 ~641 minecraft:redstone_wire replace
setblock ~150 ~52 ~645 minecraft:redstone_wire replace
setblock ~321 ~52 ~649 minecraft:redstone_wire replace
setblock ~96 ~52 ~653 minecraft:redstone_wire replace
setblock ~297 ~52 ~657 minecraft:redstone_wire replace
setblock ~318 ~52 ~661 minecraft:redstone_wire replace
fill ~273 ~53 ~78 ~275 ~53 ~78 minecraft:redstone_wire replace
setblock ~274 ~53 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~53 ~250 ~95 ~53 ~250 minecraft:redstone_wire replace
setblock ~94 ~53 ~251 minecraft:redstone_wire replace
fill ~117 ~53 ~270 ~119 ~53 ~270 minecraft:redstone_wire replace
setblock ~118 ~53 ~271 minecraft:redstone_wire replace
fill ~138 ~53 ~286 ~140 ~53 ~286 minecraft:redstone_wire replace
setblock ~139 ~53 ~287 minecraft:redstone_wire replace
fill ~153 ~53 ~298 ~156 ~53 ~298 minecraft:redstone_wire replace
setblock ~154 ~53 ~299 minecraft:redstone_wire replace
fill ~168 ~53 ~322 ~171 ~53 ~322 minecraft:redstone_wire replace
setblock ~169 ~53 ~323 minecraft:redstone_wire replace
fill ~189 ~53 ~330 ~194 ~53 ~330 minecraft:redstone_wire replace
setblock ~190 ~53 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~53 ~331 minecraft:redstone_wire replace
fill ~189 ~53 ~342 ~195 ~53 ~342 minecraft:redstone_wire replace
setblock ~190 ~53 ~343 minecraft:redstone_wire replace
setblock ~193 ~53 ~343 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~53 ~346 ~215 ~53 ~346 minecraft:redstone_wire replace
setblock ~211 ~53 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~53 ~347 minecraft:redstone_wire replace
fill ~210 ~53 ~358 ~216 ~53 ~358 minecraft:redstone_wire replace
setblock ~211 ~53 ~359 minecraft:redstone_wire replace
setblock ~214 ~53 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~53 ~366 ~266 ~53 ~366 minecraft:redstone_wire replace
setblock ~262 ~53 ~367 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~265 ~53 ~367 minecraft:redstone_wire replace
fill ~261 ~53 ~370 ~266 ~53 ~370 minecraft:redstone_wire replace
setblock ~262 ~53 ~371 minecraft:redstone_wire replace
setblock ~265 ~53 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~53 ~378 ~236 ~53 ~378 minecraft:redstone_wire replace
setblock ~237 ~53 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~53 ~378 ~250 ~53 ~378 minecraft:redstone_wire replace
setblock ~252 ~53 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~53 ~378 ~263 ~53 ~378 minecraft:redstone_wire replace
setblock ~265 ~53 ~378 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~53 ~378 ~280 ~53 ~378 minecraft:redstone_wire replace
setblock ~282 ~53 ~378 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~284 ~53 ~378 ~297 ~53 ~378 minecraft:redstone_wire replace
setblock ~299 ~53 ~378 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~53 ~378 ~308 ~53 ~378 minecraft:redstone_wire replace
setblock ~235 ~53 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~238 ~53 ~379 minecraft:redstone_wire replace
setblock ~271 ~53 ~379 minecraft:redstone_wire replace
setblock ~307 ~53 ~379 minecraft:redstone_wire replace
fill ~234 ~53 ~386 ~239 ~53 ~386 minecraft:redstone_wire replace
setblock ~235 ~53 ~387 minecraft:redstone_wire replace
setblock ~238 ~53 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~53 ~390 ~278 ~53 ~390 minecraft:redstone_wire replace
setblock ~280 ~53 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~53 ~390 ~294 ~53 ~390 minecraft:redstone_wire replace
setblock ~296 ~53 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~53 ~390 ~308 ~53 ~390 minecraft:redstone_wire replace
setblock ~271 ~53 ~391 minecraft:redstone_wire replace
setblock ~307 ~53 ~391 minecraft:redstone_wire replace
fill ~309 ~53 ~394 ~311 ~53 ~394 minecraft:redstone_wire replace
setblock ~310 ~53 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~53 ~398 ~278 ~53 ~398 minecraft:redstone_wire replace
setblock ~277 ~53 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~53 ~402 ~300 ~53 ~402 minecraft:redstone_wire replace
setblock ~298 ~53 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~53 ~406 ~272 ~53 ~406 minecraft:redstone_wire replace
setblock ~271 ~53 ~407 minecraft:redstone_wire replace
fill ~90 ~53 ~414 ~92 ~53 ~414 minecraft:redstone_wire replace
setblock ~91 ~53 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~53 ~418 ~116 ~53 ~418 minecraft:redstone_wire replace
setblock ~115 ~53 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~53 ~422 ~137 ~53 ~422 minecraft:redstone_wire replace
setblock ~136 ~53 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~53 ~426 ~162 ~53 ~426 minecraft:redstone_wire replace
setblock ~160 ~53 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~53 ~430 ~183 ~53 ~430 minecraft:redstone_wire replace
setblock ~181 ~53 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~53 ~434 ~207 ~53 ~434 minecraft:redstone_wire replace
setblock ~205 ~53 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~53 ~438 ~233 ~53 ~438 minecraft:redstone_wire replace
setblock ~232 ~53 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~252 ~53 ~442 ~257 ~53 ~442 minecraft:redstone_wire replace
setblock ~256 ~53 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~53 ~446 ~269 ~53 ~446 minecraft:redstone_wire replace
setblock ~268 ~53 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~53 ~450 ~89 ~53 ~450 minecraft:redstone_wire replace
setblock ~88 ~53 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~53 ~454 ~113 ~53 ~454 minecraft:redstone_wire replace
setblock ~112 ~53 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~53 ~458 ~134 ~53 ~458 minecraft:redstone_wire replace
setblock ~133 ~53 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~53 ~462 ~159 ~53 ~462 minecraft:redstone_wire replace
setblock ~157 ~53 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~53 ~466 ~180 ~53 ~466 minecraft:redstone_wire replace
setblock ~178 ~53 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~53 ~470 ~204 ~53 ~470 minecraft:redstone_wire replace
setblock ~202 ~53 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~53 ~474 ~228 ~53 ~474 minecraft:redstone_wire replace
setblock ~226 ~53 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~53 ~478 ~254 ~53 ~478 minecraft:redstone_wire replace
setblock ~253 ~53 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~53 ~482 ~291 ~53 ~482 minecraft:redstone_wire replace
setblock ~289 ~53 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~53 ~486 ~317 ~53 ~486 minecraft:redstone_wire replace
setblock ~316 ~53 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~53 ~490 ~86 ~53 ~490 minecraft:redstone_wire replace
setblock ~85 ~53 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~53 ~494 ~110 ~53 ~494 minecraft:redstone_wire replace
setblock ~109 ~53 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~53 ~498 ~131 ~53 ~498 minecraft:redstone_wire replace
setblock ~130 ~53 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~53 ~502 ~153 ~53 ~502 minecraft:redstone_wire replace
setblock ~151 ~53 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~53 ~506 ~177 ~53 ~506 minecraft:redstone_wire replace
setblock ~175 ~53 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~53 ~510 ~201 ~53 ~510 minecraft:redstone_wire replace
setblock ~199 ~53 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~53 ~514 ~225 ~53 ~514 minecraft:redstone_wire replace
setblock ~223 ~53 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~53 ~518 ~251 ~53 ~518 minecraft:redstone_wire replace
setblock ~250 ~53 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~53 ~522 ~287 ~53 ~522 minecraft:redstone_wire replace
setblock ~286 ~53 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~53 ~526 ~314 ~53 ~526 minecraft:redstone_wire replace
setblock ~313 ~53 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~53 ~530 ~83 ~53 ~530 minecraft:redstone_wire replace
setblock ~82 ~53 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~53 ~534 ~107 ~53 ~534 minecraft:redstone_wire replace
setblock ~106 ~53 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~53 ~538 ~128 ~53 ~538 minecraft:redstone_wire replace
setblock ~127 ~53 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~53 ~542 ~149 ~53 ~542 minecraft:redstone_wire replace
setblock ~148 ~53 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~53 ~546 ~174 ~53 ~546 minecraft:redstone_wire replace
setblock ~172 ~53 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~53 ~550 ~198 ~53 ~550 minecraft:redstone_wire replace
setblock ~196 ~53 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~53 ~554 ~222 ~53 ~554 minecraft:redstone_wire replace
setblock ~220 ~53 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~53 ~558 ~245 ~53 ~558 minecraft:redstone_wire replace
setblock ~244 ~53 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~53 ~562 ~284 ~53 ~562 minecraft:redstone_wire replace
setblock ~283 ~53 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~53 ~566 ~306 ~53 ~566 minecraft:redstone_wire replace
setblock ~304 ~53 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~53 ~570 ~80 ~53 ~570 minecraft:redstone_wire replace
setblock ~79 ~53 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~53 ~574 ~104 ~53 ~574 minecraft:redstone_wire replace
setblock ~103 ~53 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~53 ~578 ~125 ~53 ~578 minecraft:redstone_wire replace
setblock ~124 ~53 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~53 ~582 ~146 ~53 ~582 minecraft:redstone_wire replace
setblock ~145 ~53 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~53 ~586 ~168 ~53 ~586 minecraft:redstone_wire replace
setblock ~166 ~53 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~53 ~590 ~189 ~53 ~590 minecraft:redstone_wire replace
setblock ~187 ~53 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~216 ~53 ~594 ~219 ~53 ~594 minecraft:redstone_wire replace
setblock ~217 ~53 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~53 ~598 ~242 ~53 ~598 minecraft:redstone_wire replace
setblock ~241 ~53 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~279 ~53 ~602 ~281 ~53 ~602 minecraft:redstone_wire replace
setblock ~280 ~53 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~53 ~606 ~303 ~53 ~606 minecraft:redstone_wire replace
setblock ~301 ~53 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~53 ~610 ~101 ~53 ~610 minecraft:redstone_wire replace
setblock ~100 ~53 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~53 ~614 ~122 ~53 ~614 minecraft:redstone_wire replace
setblock ~121 ~53 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~53 ~618 ~143 ~53 ~618 minecraft:redstone_wire replace
setblock ~142 ~53 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~53 ~622 ~165 ~53 ~622 minecraft:redstone_wire replace
setblock ~163 ~53 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~53 ~626 ~186 ~53 ~626 minecraft:redstone_wire replace
setblock ~184 ~53 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~53 ~630 ~210 ~53 ~630 minecraft:redstone_wire replace
setblock ~208 ~53 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~243 ~53 ~634 ~248 ~53 ~634 minecraft:redstone_wire replace
setblock ~247 ~53 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~53 ~638 ~260 ~53 ~638 minecraft:redstone_wire replace
setblock ~259 ~53 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~53 ~642 ~294 ~53 ~642 minecraft:redstone_wire replace
setblock ~292 ~53 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~53 ~646 ~106 ~53 ~646 minecraft:redstone_wire replace
setblock ~108 ~53 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~53 ~646 ~123 ~53 ~646 minecraft:redstone_wire replace
setblock ~125 ~53 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~53 ~646 ~140 ~53 ~646 minecraft:redstone_wire replace
setblock ~142 ~53 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~53 ~646 ~156 ~53 ~646 minecraft:redstone_wire replace
setblock ~158 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~53 ~646 ~173 ~53 ~646 minecraft:redstone_wire replace
setblock ~175 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~53 ~646 ~190 ~53 ~646 minecraft:redstone_wire replace
setblock ~192 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~53 ~646 ~207 ~53 ~646 minecraft:redstone_wire replace
setblock ~209 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~53 ~646 ~224 ~53 ~646 minecraft:redstone_wire replace
setblock ~226 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~53 ~646 ~230 ~53 ~646 minecraft:redstone_wire replace
setblock ~94 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~53 ~650 ~323 ~53 ~650 minecraft:redstone_wire replace
setblock ~322 ~53 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~53 ~654 ~98 ~53 ~654 minecraft:redstone_wire replace
setblock ~97 ~53 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~53 ~658 ~297 ~53 ~658 minecraft:redstone_wire replace
setblock ~295 ~53 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~53 ~662 ~320 ~53 ~662 minecraft:redstone_wire replace
setblock ~319 ~53 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~274 ~54 ~80 minecraft:redstone_wire replace
setblock ~94 ~54 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~54 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~54 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~54 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~54 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~54 ~332 minecraft:redstone_wire replace
setblock ~193 ~54 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~54 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~54 ~344 minecraft:redstone_wire replace
setblock ~211 ~54 ~348 minecraft:redstone_wire replace
setblock ~214 ~54 ~348 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~54 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~54 ~360 minecraft:redstone_wire replace
setblock ~262 ~54 ~368 minecraft:redstone_wire replace
setblock ~265 ~54 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~54 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~54 ~372 minecraft:redstone_wire replace
setblock ~235 ~54 ~380 minecraft:redstone_wire replace
setblock ~238 ~54 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~54 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~54 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~54 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~54 ~388 minecraft:redstone_wire replace
setblock ~271 ~54 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~54 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~54 ~396 minecraft:redstone_wire replace
setblock ~277 ~54 ~400 minecraft:redstone_wire replace
setblock ~298 ~54 ~404 minecraft:redstone_wire replace
setblock ~271 ~54 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~54 ~416 minecraft:redstone_wire replace
setblock ~115 ~54 ~420 minecraft:redstone_wire replace
setblock ~136 ~54 ~424 minecraft:redstone_wire replace
setblock ~160 ~54 ~428 minecraft:redstone_wire replace
setblock ~181 ~54 ~432 minecraft:redstone_wire replace
setblock ~205 ~54 ~436 minecraft:redstone_wire replace
setblock ~232 ~54 ~440 minecraft:redstone_wire replace
setblock ~256 ~54 ~444 minecraft:redstone_wire replace
setblock ~268 ~54 ~448 minecraft:redstone_wire replace
setblock ~88 ~54 ~452 minecraft:redstone_wire replace
setblock ~112 ~54 ~456 minecraft:redstone_wire replace
setblock ~133 ~54 ~460 minecraft:redstone_wire replace
setblock ~157 ~54 ~464 minecraft:redstone_wire replace
setblock ~178 ~54 ~468 minecraft:redstone_wire replace
setblock ~202 ~54 ~472 minecraft:redstone_wire replace
setblock ~226 ~54 ~476 minecraft:redstone_wire replace
setblock ~253 ~54 ~480 minecraft:redstone_wire replace
setblock ~289 ~54 ~484 minecraft:redstone_wire replace
setblock ~316 ~54 ~488 minecraft:redstone_wire replace
setblock ~85 ~54 ~492 minecraft:redstone_wire replace
setblock ~109 ~54 ~496 minecraft:redstone_wire replace
setblock ~130 ~54 ~500 minecraft:redstone_wire replace
setblock ~151 ~54 ~504 minecraft:redstone_wire replace
setblock ~175 ~54 ~508 minecraft:redstone_wire replace
setblock ~199 ~54 ~512 minecraft:redstone_wire replace
setblock ~223 ~54 ~516 minecraft:redstone_wire replace
setblock ~250 ~54 ~520 minecraft:redstone_wire replace
setblock ~286 ~54 ~524 minecraft:redstone_wire replace
setblock ~313 ~54 ~528 minecraft:redstone_wire replace
setblock ~82 ~54 ~532 minecraft:redstone_wire replace
setblock ~106 ~54 ~536 minecraft:redstone_wire replace
setblock ~127 ~54 ~540 minecraft:redstone_wire replace
setblock ~148 ~54 ~544 minecraft:redstone_wire replace
setblock ~172 ~54 ~548 minecraft:redstone_wire replace
setblock ~196 ~54 ~552 minecraft:redstone_wire replace
setblock ~220 ~54 ~556 minecraft:redstone_wire replace
setblock ~244 ~54 ~560 minecraft:redstone_wire replace
setblock ~283 ~54 ~564 minecraft:redstone_wire replace
setblock ~304 ~54 ~568 minecraft:redstone_wire replace
setblock ~79 ~54 ~572 minecraft:redstone_wire replace
setblock ~103 ~54 ~576 minecraft:redstone_wire replace
setblock ~124 ~54 ~580 minecraft:redstone_wire replace
setblock ~145 ~54 ~584 minecraft:redstone_wire replace
setblock ~166 ~54 ~588 minecraft:redstone_wire replace
setblock ~187 ~54 ~592 minecraft:redstone_wire replace
setblock ~217 ~54 ~596 minecraft:redstone_wire replace
setblock ~241 ~54 ~600 minecraft:redstone_wire replace
setblock ~280 ~54 ~604 minecraft:redstone_wire replace
setblock ~301 ~54 ~608 minecraft:redstone_wire replace
setblock ~100 ~54 ~612 minecraft:redstone_wire replace
setblock ~121 ~54 ~616 minecraft:redstone_wire replace
setblock ~142 ~54 ~620 minecraft:redstone_wire replace
setblock ~163 ~54 ~624 minecraft:redstone_wire replace
setblock ~184 ~54 ~628 minecraft:redstone_wire replace
setblock ~208 ~54 ~632 minecraft:redstone_wire replace
setblock ~247 ~54 ~636 minecraft:redstone_wire replace
setblock ~259 ~54 ~640 minecraft:redstone_wire replace
setblock ~292 ~54 ~644 minecraft:redstone_wire replace
setblock ~94 ~54 ~648 minecraft:redstone_wire replace
setblock ~118 ~54 ~648 minecraft:redstone_wire replace
setblock ~139 ~54 ~648 minecraft:redstone_wire replace
setblock ~154 ~54 ~648 minecraft:redstone_wire replace
setblock ~169 ~54 ~648 minecraft:redstone_wire replace
setblock ~229 ~54 ~648 minecraft:redstone_wire replace
setblock ~322 ~54 ~652 minecraft:redstone_wire replace
setblock ~97 ~54 ~656 minecraft:redstone_wire replace
setblock ~295 ~54 ~660 minecraft:redstone_wire replace
setblock ~319 ~54 ~664 minecraft:redstone_wire replace
fill ~273 ~55 ~76 ~273 ~55 ~80 minecraft:redstone_wire replace
fill ~93 ~55 ~248 ~93 ~55 ~250 minecraft:redstone_wire replace
setblock ~93 ~55 ~251 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~252 ~93 ~55 ~264 minecraft:redstone_wire replace
setblock ~93 ~55 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~268 ~93 ~55 ~280 minecraft:redstone_wire replace
setblock ~117 ~55 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~55 ~270 ~117 ~55 ~280 minecraft:redstone_wire replace
setblock ~93 ~55 ~282 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~282 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~284 ~93 ~55 ~296 minecraft:redstone_wire replace
fill ~117 ~55 ~284 ~117 ~55 ~296 minecraft:redstone_wire replace
setblock ~138 ~55 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~55 ~286 ~138 ~55 ~296 minecraft:redstone_wire replace
fill ~153 ~55 ~296 ~153 ~55 ~298 minecraft:redstone_wire replace
setblock ~93 ~55 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~299 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~300 ~93 ~55 ~312 minecraft:redstone_wire replace
fill ~117 ~55 ~300 ~117 ~55 ~312 minecraft:redstone_wire replace
fill ~138 ~55 ~300 ~138 ~55 ~312 minecraft:redstone_wire replace
fill ~153 ~55 ~300 ~153 ~55 ~312 minecraft:redstone_wire replace
setblock ~93 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~316 ~93 ~55 ~328 minecraft:redstone_wire replace
fill ~117 ~55 ~316 ~117 ~55 ~328 minecraft:redstone_wire replace
fill ~138 ~55 ~316 ~138 ~55 ~328 minecraft:redstone_wire replace
fill ~153 ~55 ~316 ~153 ~55 ~328 minecraft:redstone_wire replace
setblock ~168 ~55 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~55 ~322 ~168 ~55 ~328 minecraft:redstone_wire replace
fill ~192 ~55 ~324 ~192 ~55 ~330 minecraft:redstone_wire replace
fill ~189 ~55 ~328 ~189 ~55 ~330 minecraft:redstone_wire replace
setblock ~93 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~55 ~331 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~55 ~331 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~332 ~93 ~55 ~344 minecraft:redstone_wire replace
fill ~117 ~55 ~332 ~117 ~55 ~344 minecraft:redstone_wire replace
fill ~138 ~55 ~332 ~138 ~55 ~344 minecraft:redstone_wire replace
fill ~153 ~55 ~332 ~153 ~55 ~344 minecraft:redstone_wire replace
fill ~168 ~55 ~332 ~168 ~55 ~344 minecraft:redstone_wire replace
fill ~189 ~55 ~332 ~189 ~55 ~344 minecraft:redstone_wire replace
fill ~192 ~55 ~332 ~192 ~55 ~344 minecraft:redstone_wire replace
fill ~213 ~55 ~340 ~213 ~55 ~346 minecraft:redstone_wire replace
fill ~210 ~55 ~344 ~210 ~55 ~346 minecraft:redstone_wire replace
setblock ~93 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~55 ~347 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~55 ~347 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~348 ~93 ~55 ~360 minecraft:redstone_wire replace
fill ~117 ~55 ~348 ~117 ~55 ~360 minecraft:redstone_wire replace
fill ~138 ~55 ~348 ~138 ~55 ~360 minecraft:redstone_wire replace
fill ~153 ~55 ~348 ~153 ~55 ~360 minecraft:redstone_wire replace
fill ~168 ~55 ~348 ~168 ~55 ~360 minecraft:redstone_wire replace
fill ~210 ~55 ~348 ~210 ~55 ~360 minecraft:redstone_wire replace
fill ~213 ~55 ~348 ~213 ~55 ~360 minecraft:redstone_wire replace
setblock ~264 ~55 ~356 minecraft:redstone_wire replace
setblock ~264 ~55 ~358 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~261 ~55 ~360 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~55 ~360 ~264 ~55 ~372 minecraft:redstone_wire replace
setblock ~93 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
