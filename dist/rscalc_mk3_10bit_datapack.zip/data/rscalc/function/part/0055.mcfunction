setblock ~34 ~9 ~19 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~34 ~9 ~20 ~34 ~9 ~30 minecraft:redstone_wire replace
setblock ~30 ~9 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~30 ~9 ~22 ~30 ~9 ~32 minecraft:redstone_wire replace
fill ~18 ~9 ~23 ~18 ~9 ~26 minecraft:redstone_wire replace
setblock ~26 ~9 ~23 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~26 ~9 ~24 ~26 ~9 ~34 minecraft:redstone_wire replace
setblock ~22 ~9 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~22 ~9 ~26 ~22 ~9 ~36 minecraft:redstone_wire replace
fill ~14 ~9 ~27 ~14 ~9 ~28 minecraft:redstone_wire replace
setblock ~18 ~9 ~27 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~18 ~9 ~28 ~18 ~9 ~38 minecraft:redstone_wire replace
setblock ~14 ~9 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~30 ~14 ~9 ~40 minecraft:redstone_wire replace
fill ~38 ~9 ~30 ~38 ~9 ~40 minecraft:redstone_wire replace
setblock ~10 ~9 ~31 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~31 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~10 ~9 ~32 ~10 ~9 ~42 minecraft:redstone_wire replace
fill ~34 ~9 ~32 ~34 ~9 ~42 minecraft:redstone_wire replace
setblock ~30 ~9 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~30 ~9 ~34 ~30 ~9 ~44 minecraft:redstone_wire replace
fill ~6 ~9 ~35 ~6 ~9 ~44 minecraft:redstone_wire replace
setblock ~26 ~9 ~35 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~26 ~9 ~36 ~26 ~9 ~46 minecraft:redstone_wire replace
setblock ~22 ~9 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~22 ~9 ~38 ~22 ~9 ~48 minecraft:redstone_wire replace
fill ~2 ~9 ~39 ~2 ~9 ~46 minecraft:redstone_wire replace
setblock ~18 ~9 ~39 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~18 ~9 ~40 ~18 ~9 ~50 minecraft:redstone_wire replace
setblock ~14 ~9 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~42 ~14 ~9 ~52 minecraft:redstone_wire replace
fill ~38 ~9 ~42 ~38 ~9 ~52 minecraft:redstone_wire replace
setblock ~10 ~9 ~43 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~43 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~36 ~9 ~43 ~36 ~9 ~52 minecraft:redstone_wire replace
fill ~10 ~9 ~44 ~10 ~9 ~54 minecraft:redstone_wire replace
fill ~34 ~9 ~44 ~34 ~9 ~54 minecraft:redstone_wire replace
setblock ~6 ~9 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~6 ~9 ~46 ~6 ~9 ~56 minecraft:redstone_wire replace
fill ~30 ~9 ~46 ~30 ~9 ~56 minecraft:redstone_wire replace
setblock ~2 ~9 ~47 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~47 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~32 ~9 ~47 ~32 ~9 ~54 minecraft:redstone_wire replace
fill ~2 ~9 ~48 ~2 ~9 ~58 minecraft:redstone_wire replace
fill ~26 ~9 ~48 ~26 ~9 ~58 minecraft:redstone_wire replace
setblock ~22 ~9 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~22 ~9 ~50 ~22 ~9 ~60 minecraft:redstone_wire replace
setblock ~18 ~9 ~51 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~28 ~9 ~51 ~28 ~9 ~56 minecraft:redstone_wire replace
fill ~18 ~9 ~52 ~18 ~9 ~62 minecraft:redstone_wire replace
setblock ~14 ~9 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~54 ~14 ~9 ~64 minecraft:redstone_wire replace
fill ~36 ~9 ~54 ~36 ~9 ~64 minecraft:redstone_wire replace
fill ~38 ~9 ~54 ~38 ~9 ~64 minecraft:redstone_wire replace
setblock ~10 ~9 ~55 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~24 ~9 ~55 ~24 ~9 ~58 minecraft:redstone_wire replace
setblock ~32 ~9 ~55 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~55 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~10 ~9 ~56 ~10 ~9 ~66 minecraft:redstone_wire replace
fill ~32 ~9 ~56 ~32 ~9 ~66 minecraft:redstone_wire replace
fill ~34 ~9 ~56 ~34 ~9 ~66 minecraft:redstone_wire replace
setblock ~6 ~9 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~6 ~9 ~58 ~6 ~9 ~68 minecraft:redstone_wire replace
fill ~28 ~9 ~58 ~28 ~9 ~68 minecraft:redstone_wire replace
fill ~30 ~9 ~58 ~30 ~9 ~68 minecraft:redstone_wire replace
setblock ~2 ~9 ~59 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~59 ~20 ~9 ~60 minecraft:redstone_wire replace
setblock ~24 ~9 ~59 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~59 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~2 ~9 ~60 ~2 ~9 ~70 minecraft:redstone_wire replace
fill ~24 ~9 ~60 ~24 ~9 ~70 minecraft:redstone_wire replace
fill ~26 ~9 ~60 ~26 ~9 ~70 minecraft:redstone_wire replace
setblock ~20 ~9 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~62 ~20 ~9 ~72 minecraft:redstone_wire replace
fill ~22 ~9 ~62 ~22 ~9 ~72 minecraft:redstone_wire replace
setblock ~16 ~9 ~63 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~63 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~16 ~9 ~64 ~16 ~9 ~74 minecraft:redstone_wire replace
fill ~18 ~9 ~64 ~18 ~9 ~74 minecraft:redstone_wire replace
setblock ~14 ~9 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~66 ~14 ~9 ~76 minecraft:redstone_wire replace
fill ~36 ~9 ~66 ~36 ~9 ~76 minecraft:redstone_wire replace
fill ~38 ~9 ~66 ~38 ~9 ~76 minecraft:redstone_wire replace
setblock ~10 ~9 ~67 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~12 ~9 ~67 ~12 ~9 ~76 minecraft:redstone_wire replace
setblock ~32 ~9 ~67 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~67 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~10 ~9 ~68 ~10 ~9 ~78 minecraft:redstone_wire replace
fill ~32 ~9 ~68 ~32 ~9 ~78 minecraft:redstone_wire replace
fill ~34 ~9 ~68 ~34 ~9 ~78 minecraft:redstone_wire replace
setblock ~6 ~9 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~6 ~9 ~70 ~6 ~9 ~80 minecraft:redstone_wire replace
fill ~28 ~9 ~70 ~28 ~9 ~80 minecraft:redstone_wire replace
fill ~30 ~9 ~70 ~30 ~9 ~80 minecraft:redstone_wire replace
setblock ~2 ~9 ~71 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~71 ~8 ~9 ~78 minecraft:redstone_wire replace
setblock ~24 ~9 ~71 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~71 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~2 ~9 ~72 ~2 ~9 ~82 minecraft:redstone_wire replace
fill ~24 ~9 ~72 ~24 ~9 ~82 minecraft:redstone_wire replace
fill ~26 ~9 ~72 ~26 ~9 ~82 minecraft:redstone_wire replace
setblock ~20 ~9 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~74 ~20 ~9 ~84 minecraft:redstone_wire replace
fill ~22 ~9 ~74 ~22 ~9 ~84 minecraft:redstone_wire replace
fill ~4 ~9 ~75 ~4 ~9 ~80 minecraft:redstone_wire replace
setblock ~16 ~9 ~75 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~75 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~16 ~9 ~76 ~16 ~9 ~86 minecraft:redstone_wire replace
fill ~18 ~9 ~76 ~18 ~9 ~86 minecraft:redstone_wire replace
setblock ~12 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~12 ~9 ~78 ~12 ~9 ~88 minecraft:redstone_wire replace
fill ~14 ~9 ~78 ~14 ~9 ~88 minecraft:redstone_wire replace
fill ~36 ~9 ~78 ~36 ~9 ~88 minecraft:redstone_wire replace
fill ~38 ~9 ~78 ~38 ~9 ~88 minecraft:redstone_wire replace
fill ~0 ~9 ~79 ~0 ~9 ~82 minecraft:redstone_wire replace
setblock ~8 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~32 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~80 ~8 ~9 ~90 minecraft:redstone_wire replace
fill ~10 ~9 ~80 ~10 ~9 ~90 minecraft:redstone_wire replace
fill ~32 ~9 ~80 ~32 ~9 ~90 minecraft:redstone_wire replace
fill ~34 ~9 ~80 ~34 ~9 ~90 minecraft:redstone_wire replace
setblock ~4 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~4 ~9 ~82 ~4 ~9 ~92 minecraft:redstone_wire replace
fill ~6 ~9 ~82 ~6 ~9 ~92 minecraft:redstone_wire replace
fill ~28 ~9 ~82 ~28 ~9 ~92 minecraft:redstone_wire replace
fill ~30 ~9 ~82 ~30 ~9 ~92 minecraft:redstone_wire replace
setblock ~0 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~24 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~0 ~9 ~84 ~0 ~9 ~94 minecraft:redstone_wire replace
fill ~2 ~9 ~84 ~2 ~9 ~94 minecraft:redstone_wire replace
fill ~24 ~9 ~84 ~24 ~9 ~94 minecraft:redstone_wire replace
fill ~26 ~9 ~84 ~26 ~9 ~94 minecraft:redstone_wire replace
setblock ~20 ~9 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~86 ~20 ~9 ~96 minecraft:redstone_wire replace
fill ~22 ~9 ~86 ~22 ~9 ~96 minecraft:redstone_wire replace
setblock ~16 ~9 ~87 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~87 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~16 ~9 ~88 ~16 ~9 ~98 minecraft:redstone_wire replace
fill ~18 ~9 ~88 ~18 ~9 ~98 minecraft:redstone_wire replace
setblock ~12 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~12 ~9 ~90 ~12 ~9 ~100 minecraft:redstone_wire replace
fill ~14 ~9 ~90 ~14 ~9 ~100 minecraft:redstone_wire replace
fill ~36 ~9 ~90 ~36 ~9 ~100 minecraft:redstone_wire replace
fill ~38 ~9 ~90 ~38 ~9 ~100 minecraft:redstone_wire replace
setblock ~8 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~32 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~92 ~8 ~9 ~102 minecraft:redstone_wire replace
fill ~10 ~9 ~92 ~10 ~9 ~102 minecraft:redstone_wire replace
fill ~32 ~9 ~92 ~32 ~9 ~102 minecraft:redstone_wire replace
fill ~34 ~9 ~92 ~34 ~9 ~102 minecraft:redstone_wire replace
setblock ~4 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~4 ~9 ~94 ~4 ~9 ~104 minecraft:redstone_wire replace
fill ~6 ~9 ~94 ~6 ~9 ~104 minecraft:redstone_wire replace
fill ~28 ~9 ~94 ~28 ~9 ~104 minecraft:redstone_wire replace
fill ~30 ~9 ~94 ~30 ~9 ~104 minecraft:redstone_wire replace
setblock ~0 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~24 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~52 ~9 ~95 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~0 ~9 ~96 ~0 ~9 ~106 minecraft:redstone_wire replace
fill ~2 ~9 ~96 ~2 ~9 ~106 minecraft:redstone_wire replace
fill ~24 ~9 ~96 ~24 ~9 ~106 minecraft:redstone_wire replace
fill ~26 ~9 ~96 ~26 ~9 ~106 minecraft:redstone_wire replace
fill ~52 ~9 ~96 ~52 ~9 ~97 minecraft:redstone_wire replace
setblock ~20 ~9 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~48 ~9 ~97 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~50 ~9 ~97 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~20 ~9 ~98 ~20 ~9 ~108 minecraft:redstone_wire replace
fill ~22 ~9 ~98 ~22 ~9 ~108 minecraft:redstone_wire replace
fill ~48 ~9 ~98 ~48 ~9 ~105 minecraft:redstone_wire replace
fill ~50 ~9 ~98 ~50 ~9 ~101 minecraft:redstone_wire replace
setblock ~16 ~9 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~44 ~9 ~99 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~46 ~9 ~99 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~16 ~9 ~100 ~16 ~9 ~110 minecraft:redstone_wire replace
fill ~18 ~9 ~100 ~18 ~9 ~110 minecraft:redstone_wire replace
fill ~44 ~9 ~100 ~44 ~9 ~110 minecraft:redstone_wire replace
fill ~46 ~9 ~100 ~46 ~9 ~109 minecraft:redstone_wire replace
setblock ~12 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~40 ~9 ~101 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~42 ~9 ~101 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~12 ~9 ~102 ~12 ~9 ~112 minecraft:redstone_wire replace
fill ~14 ~9 ~102 ~14 ~9 ~112 minecraft:redstone_wire replace
fill ~40 ~9 ~102 ~40 ~9 ~112 minecraft:redstone_wire replace
fill ~42 ~9 ~102 ~42 ~9 ~112 minecraft:redstone_wire replace
setblock ~8 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~32 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~104 ~8 ~9 ~114 minecraft:redstone_wire replace
fill ~10 ~9 ~104 ~10 ~9 ~114 minecraft:redstone_wire replace
setblock ~4 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~4 ~9 ~106 ~4 ~9 ~116 minecraft:redstone_wire replace
fill ~6 ~9 ~106 ~6 ~9 ~116 minecraft:redstone_wire replace
setblock ~0 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~24 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~0 ~9 ~108 ~0 ~9 ~118 minecraft:redstone_wire replace
fill ~2 ~9 ~108 ~2 ~9 ~118 minecraft:redstone_wire replace
setblock ~20 ~9 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~16 ~9 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~44 ~9 ~111 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~44 ~9 ~112 ~44 ~9 ~113 minecraft:redstone_wire replace
setblock ~12 ~9 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~40 ~9 ~113 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~42 ~9 ~113 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~40 ~9 ~114 ~40 ~9 ~121 minecraft:redstone_wire replace
fill ~42 ~9 ~114 ~42 ~9 ~117 minecraft:redstone_wire replace
setblock ~8 ~9 ~115 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~115 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~4 ~9 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~0 ~9 ~119 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~119 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~10 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~10 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~10 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~10 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~10 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~10 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~10 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~10 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~10 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~10 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~10 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~10 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~10 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~10 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~10 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~10 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~10 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~10 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~10 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~10 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~10 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~10 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~10 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~10 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~10 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~10 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~10 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~10 ~122 minecraft:redstone_torch[lit=true] replace
setblock ~38 ~12 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~12 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~12 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~12 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~12 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~12 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~12 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~12 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~12 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~12 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~12 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~12 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~12 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~12 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~12 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~12 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~12 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~12 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~12 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~12 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~12 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~12 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~12 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~12 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~12 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~12 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~12 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~12 ~122 minecraft:redstone_torch[lit=true] replace
setblock ~39 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~2 ~50 ~13 ~2 minecraft:redstone_wire replace
setblock ~51 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~2 ~62 ~13 ~2 minecraft:redstone_wire replace
setblock ~63 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~2 ~74 ~13 ~2 minecraft:redstone_wire replace
setblock ~75 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~35 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~36 ~13 ~6 ~46 ~13 ~6 minecraft:redstone_wire replace
setblock ~47 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~6 ~58 ~13 ~6 minecraft:redstone_wire replace
setblock ~59 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~6 ~70 ~13 ~6 minecraft:redstone_wire replace
setblock ~71 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~72 ~13 ~6 ~75 ~13 ~6 minecraft:redstone_wire replace
setblock ~31 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~32 ~13 ~10 ~42 ~13 ~10 minecraft:redstone_wire replace
setblock ~43 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~10 ~54 ~13 ~10 minecraft:redstone_wire replace
setblock ~55 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~10 ~66 ~13 ~10 minecraft:redstone_wire replace
setblock ~67 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~68 ~13 ~10 ~75 ~13 ~10 minecraft:redstone_wire replace
setblock ~27 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~28 ~13 ~14 ~38 ~13 ~14 minecraft:redstone_wire replace
setblock ~39 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~14 ~50 ~13 ~14 minecraft:redstone_wire replace
setblock ~51 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~14 ~62 ~13 ~14 minecraft:redstone_wire replace
setblock ~63 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~14 ~74 ~13 ~14 minecraft:redstone_wire replace
setblock ~75 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~23 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~24 ~13 ~18 ~34 ~13 ~18 minecraft:redstone_wire replace
setblock ~35 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~36 ~13 ~18 ~46 ~13 ~18 minecraft:redstone_wire replace
setblock ~47 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~18 ~58 ~13 ~18 minecraft:redstone_wire replace
setblock ~59 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~18 ~70 ~13 ~18 minecraft:redstone_wire replace
setblock ~71 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~72 ~13 ~18 ~75 ~13 ~18 minecraft:redstone_wire replace
setblock ~19 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~20 ~13 ~22 ~30 ~13 ~22 minecraft:redstone_wire replace
setblock ~31 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~32 ~13 ~22 ~42 ~13 ~22 minecraft:redstone_wire replace
setblock ~43 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~22 ~54 ~13 ~22 minecraft:redstone_wire replace
setblock ~55 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~22 ~66 ~13 ~22 minecraft:redstone_wire replace
setblock ~67 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~68 ~13 ~22 ~75 ~13 ~22 minecraft:redstone_wire replace
setblock ~15 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~16 ~13 ~26 ~26 ~13 ~26 minecraft:redstone_wire replace
setblock ~27 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~28 ~13 ~26 ~38 ~13 ~26 minecraft:redstone_wire replace
setblock ~39 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~26 ~50 ~13 ~26 minecraft:redstone_wire replace
setblock ~51 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~26 ~62 ~13 ~26 minecraft:redstone_wire replace
setblock ~63 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~26 ~74 ~13 ~26 minecraft:redstone_wire replace
setblock ~75 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~11 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~12 ~13 ~30 ~22 ~13 ~30 minecraft:redstone_wire replace
setblock ~23 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~24 ~13 ~30 ~34 ~13 ~30 minecraft:redstone_wire replace
setblock ~35 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~36 ~13 ~30 ~46 ~13 ~30 minecraft:redstone_wire replace
setblock ~47 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~30 ~58 ~13 ~30 minecraft:redstone_wire replace
setblock ~59 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~30 ~70 ~13 ~30 minecraft:redstone_wire replace
setblock ~71 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~72 ~13 ~30 ~75 ~13 ~30 minecraft:redstone_wire replace
setblock ~7 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~8 ~13 ~34 ~18 ~13 ~34 minecraft:redstone_wire replace
setblock ~19 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~20 ~13 ~34 ~30 ~13 ~34 minecraft:redstone_wire replace
setblock ~31 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~32 ~13 ~34 ~42 ~13 ~34 minecraft:redstone_wire replace
setblock ~43 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~34 ~54 ~13 ~34 minecraft:redstone_wire replace
setblock ~55 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~34 ~66 ~13 ~34 minecraft:redstone_wire replace
setblock ~67 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~68 ~13 ~34 ~75 ~13 ~34 minecraft:redstone_wire replace
setblock ~3 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~4 ~13 ~38 ~14 ~13 ~38 minecraft:redstone_wire replace
setblock ~15 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~16 ~13 ~38 ~26 ~13 ~38 minecraft:redstone_wire replace
setblock ~27 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~28 ~13 ~38 ~38 ~13 ~38 minecraft:redstone_wire replace
setblock ~39 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~38 ~50 ~13 ~38 minecraft:redstone_wire replace
setblock ~51 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~38 ~62 ~13 ~38 minecraft:redstone_wire replace
setblock ~63 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~38 ~74 ~13 ~38 minecraft:redstone_wire replace
setblock ~75 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~37 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~42 ~48 ~13 ~42 minecraft:redstone_wire replace
setblock ~49 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~42 ~60 ~13 ~42 minecraft:redstone_wire replace
setblock ~61 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~42 ~72 ~13 ~42 minecraft:redstone_wire replace
setblock ~73 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~42 ~75 ~13 ~42 minecraft:redstone_wire replace
setblock ~33 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~34 ~13 ~46 ~44 ~13 ~46 minecraft:redstone_wire replace
setblock ~45 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~46 ~56 ~13 ~46 minecraft:redstone_wire replace
setblock ~57 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~46 ~68 ~13 ~46 minecraft:redstone_wire replace
setblock ~69 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~70 ~13 ~46 ~75 ~13 ~46 minecraft:redstone_wire replace
setblock ~29 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~30 ~13 ~50 ~40 ~13 ~50 minecraft:redstone_wire replace
setblock ~41 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~50 ~52 ~13 ~50 minecraft:redstone_wire replace
setblock ~53 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~50 ~64 ~13 ~50 minecraft:redstone_wire replace
setblock ~65 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~66 ~13 ~50 ~75 ~13 ~50 minecraft:redstone_wire replace
setblock ~25 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~26 ~13 ~54 ~36 ~13 ~54 minecraft:redstone_wire replace
setblock ~37 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~54 ~48 ~13 ~54 minecraft:redstone_wire replace
setblock ~49 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~54 ~60 ~13 ~54 minecraft:redstone_wire replace
setblock ~61 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~54 ~72 ~13 ~54 minecraft:redstone_wire replace
setblock ~73 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~54 ~75 ~13 ~54 minecraft:redstone_wire replace
setblock ~21 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~22 ~13 ~58 ~32 ~13 ~58 minecraft:redstone_wire replace
setblock ~33 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~34 ~13 ~58 ~44 ~13 ~58 minecraft:redstone_wire replace
setblock ~45 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~58 ~56 ~13 ~58 minecraft:redstone_wire replace
setblock ~57 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~58 ~68 ~13 ~58 minecraft:redstone_wire replace
setblock ~69 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~70 ~13 ~58 ~75 ~13 ~58 minecraft:redstone_wire replace
setblock ~17 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~18 ~13 ~62 ~28 ~13 ~62 minecraft:redstone_wire replace
setblock ~29 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~30 ~13 ~62 ~40 ~13 ~62 minecraft:redstone_wire replace
setblock ~41 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~62 ~52 ~13 ~62 minecraft:redstone_wire replace
setblock ~53 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~62 ~64 ~13 ~62 minecraft:redstone_wire replace
setblock ~65 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~66 ~13 ~62 ~75 ~13 ~62 minecraft:redstone_wire replace
setblock ~13 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~14 ~13 ~66 ~24 ~13 ~66 minecraft:redstone_wire replace
setblock ~25 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~26 ~13 ~66 ~36 ~13 ~66 minecraft:redstone_wire replace
setblock ~37 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~66 ~48 ~13 ~66 minecraft:redstone_wire replace
setblock ~49 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~66 ~60 ~13 ~66 minecraft:redstone_wire replace
setblock ~61 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~66 ~72 ~13 ~66 minecraft:redstone_wire replace
setblock ~73 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~66 ~75 ~13 ~66 minecraft:redstone_wire replace
setblock ~9 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~10 ~13 ~70 ~20 ~13 ~70 minecraft:redstone_wire replace
setblock ~21 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~22 ~13 ~70 ~32 ~13 ~70 minecraft:redstone_wire replace
setblock ~33 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~34 ~13 ~70 ~44 ~13 ~70 minecraft:redstone_wire replace
setblock ~45 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~70 ~56 ~13 ~70 minecraft:redstone_wire replace
setblock ~57 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~70 ~68 ~13 ~70 minecraft:redstone_wire replace
setblock ~69 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~70 ~13 ~70 ~75 ~13 ~70 minecraft:redstone_wire replace
setblock ~5 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~6 ~13 ~74 ~16 ~13 ~74 minecraft:redstone_wire replace
setblock ~17 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~18 ~13 ~74 ~28 ~13 ~74 minecraft:redstone_wire replace
setblock ~29 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~30 ~13 ~74 ~40 ~13 ~74 minecraft:redstone_wire replace
setblock ~41 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~74 ~52 ~13 ~74 minecraft:redstone_wire replace
setblock ~53 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~74 ~64 ~13 ~74 minecraft:redstone_wire replace
setblock ~65 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~66 ~13 ~74 ~75 ~13 ~74 minecraft:redstone_wire replace
setblock ~1 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~2 ~13 ~78 ~12 ~13 ~78 minecraft:redstone_wire replace
setblock ~13 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~14 ~13 ~78 ~24 ~13 ~78 minecraft:redstone_wire replace
setblock ~25 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~26 ~13 ~78 ~36 ~13 ~78 minecraft:redstone_wire replace
setblock ~37 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~78 ~48 ~13 ~78 minecraft:redstone_wire replace
setblock ~49 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~78 ~60 ~13 ~78 minecraft:redstone_wire replace
setblock ~61 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~78 ~72 ~13 ~78 minecraft:redstone_wire replace
setblock ~73 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~78 ~75 ~13 ~78 minecraft:redstone_wire replace
setblock ~55 ~13 ~94 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~94 ~63 ~13 ~94 minecraft:redstone_wire replace
setblock ~53 ~13 ~98 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~98 ~63 ~13 ~98 minecraft:redstone_wire replace
setblock ~51 ~13 ~102 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~102 ~62 ~13 ~102 minecraft:redstone_wire replace
setblock ~63 ~13 ~102 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~49 ~13 ~106 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~106 ~60 ~13 ~106 minecraft:redstone_wire replace
setblock ~61 ~13 ~106 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~106 ~63 ~13 ~106 minecraft:redstone_wire replace
setblock ~47 ~13 ~110 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~110 ~58 ~13 ~110 minecraft:redstone_wire replace
setblock ~59 ~13 ~110 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~110 ~63 ~13 ~110 minecraft:redstone_wire replace
setblock ~45 ~13 ~114 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~114 ~56 ~13 ~114 minecraft:redstone_wire replace
setblock ~57 ~13 ~114 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~114 ~63 ~13 ~114 minecraft:redstone_wire replace
setblock ~43 ~13 ~118 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~118 ~54 ~13 ~118 minecraft:redstone_wire replace
setblock ~55 ~13 ~118 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~118 ~63 ~13 ~118 minecraft:redstone_wire replace
setblock ~41 ~13 ~122 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~122 ~52 ~13 ~122 minecraft:redstone_wire replace
setblock ~53 ~13 ~122 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~122 ~63 ~13 ~122 minecraft:redstone_wire replace
setblock ~76 ~14 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~122 minecraft:redstone_torch[lit=true] replace
fill ~74 ~15 ~90 ~74 ~15 ~95 minecraft:redstone_wire replace
fill ~74 ~15 ~96 ~75 ~15 ~96 minecraft:redstone_wire replace
fill ~74 ~15 ~97 ~74 ~15 ~98 minecraft:redstone_wire replace
setblock ~74 ~15 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~74 ~15 ~100 ~75 ~15 ~100 minecraft:redstone_wire replace
fill ~74 ~15 ~101 ~74 ~15 ~103 minecraft:redstone_wire replace
fill ~74 ~15 ~104 ~75 ~15 ~104 minecraft:redstone_wire replace
fill ~74 ~15 ~105 ~74 ~15 ~107 minecraft:redstone_wire replace
fill ~74 ~15 ~108 ~75 ~15 ~108 minecraft:redstone_wire replace
fill ~74 ~15 ~109 ~74 ~15 ~110 minecraft:redstone_wire replace
setblock ~74 ~15 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~74 ~15 ~112 ~75 ~15 ~112 minecraft:redstone_wire replace
fill ~74 ~15 ~113 ~74 ~15 ~115 minecraft:redstone_wire replace
fill ~74 ~15 ~116 ~75 ~15 ~116 minecraft:redstone_wire replace
fill ~74 ~15 ~117 ~74 ~15 ~119 minecraft:redstone_wire replace
fill ~74 ~15 ~120 ~75 ~15 ~120 minecraft:redstone_wire replace
fill ~74 ~15 ~121 ~74 ~15 ~122 minecraft:redstone_wire replace
setblock ~74 ~15 ~123 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~74 ~15 ~124 ~75 ~15 ~124 minecraft:redstone_wire replace
setblock ~65 ~15 ~125 minecraft:redstone_wire replace
setblock ~66 ~15 ~125 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~67 ~15 ~125 ~74 ~15 ~125 minecraft:redstone_wire replace
setblock ~76 ~16 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~14 minecraft:redstone_torch[lit=true] replace
