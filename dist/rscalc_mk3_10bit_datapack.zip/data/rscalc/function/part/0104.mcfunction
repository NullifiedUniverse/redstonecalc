setblock ~372 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~740 minecraft:redstone_wire replace
fill ~411 ~155 ~740 ~411 ~155 ~744 minecraft:redstone_wire replace
fill ~414 ~155 ~740 ~414 ~155 ~746 minecraft:redstone_wire replace
fill ~417 ~155 ~740 ~417 ~155 ~750 minecraft:redstone_wire replace
fill ~420 ~155 ~740 ~420 ~155 ~752 minecraft:redstone_wire replace
fill ~423 ~155 ~740 ~423 ~155 ~752 minecraft:redstone_wire replace
fill ~255 ~155 ~742 ~255 ~155 ~754 minecraft:redstone_wire replace
fill ~258 ~155 ~742 ~258 ~155 ~754 minecraft:redstone_wire replace
fill ~261 ~155 ~742 ~261 ~155 ~754 minecraft:redstone_wire replace
fill ~264 ~155 ~742 ~264 ~155 ~754 minecraft:redstone_wire replace
fill ~267 ~155 ~742 ~267 ~155 ~754 minecraft:redstone_wire replace
fill ~270 ~155 ~742 ~270 ~155 ~754 minecraft:redstone_wire replace
fill ~273 ~155 ~742 ~273 ~155 ~754 minecraft:redstone_wire replace
fill ~276 ~155 ~742 ~276 ~155 ~754 minecraft:redstone_wire replace
fill ~279 ~155 ~742 ~279 ~155 ~754 minecraft:redstone_wire replace
fill ~282 ~155 ~742 ~282 ~155 ~754 minecraft:redstone_wire replace
fill ~285 ~155 ~742 ~285 ~155 ~754 minecraft:redstone_wire replace
fill ~288 ~155 ~742 ~288 ~155 ~754 minecraft:redstone_wire replace
fill ~291 ~155 ~742 ~291 ~155 ~754 minecraft:redstone_wire replace
fill ~294 ~155 ~742 ~294 ~155 ~754 minecraft:redstone_wire replace
fill ~297 ~155 ~742 ~297 ~155 ~754 minecraft:redstone_wire replace
fill ~300 ~155 ~742 ~300 ~155 ~754 minecraft:redstone_wire replace
fill ~303 ~155 ~742 ~303 ~155 ~754 minecraft:redstone_wire replace
fill ~306 ~155 ~742 ~306 ~155 ~754 minecraft:redstone_wire replace
fill ~309 ~155 ~742 ~309 ~155 ~754 minecraft:redstone_wire replace
fill ~312 ~155 ~742 ~312 ~155 ~754 minecraft:redstone_wire replace
fill ~315 ~155 ~742 ~315 ~155 ~754 minecraft:redstone_wire replace
fill ~318 ~155 ~742 ~318 ~155 ~754 minecraft:redstone_wire replace
fill ~321 ~155 ~742 ~321 ~155 ~754 minecraft:redstone_wire replace
fill ~324 ~155 ~742 ~324 ~155 ~754 minecraft:redstone_wire replace
fill ~327 ~155 ~742 ~327 ~155 ~754 minecraft:redstone_wire replace
fill ~330 ~155 ~742 ~330 ~155 ~754 minecraft:redstone_wire replace
fill ~333 ~155 ~742 ~333 ~155 ~754 minecraft:redstone_wire replace
fill ~336 ~155 ~742 ~336 ~155 ~754 minecraft:redstone_wire replace
fill ~339 ~155 ~742 ~339 ~155 ~754 minecraft:redstone_wire replace
fill ~342 ~155 ~742 ~342 ~155 ~754 minecraft:redstone_wire replace
fill ~345 ~155 ~742 ~345 ~155 ~754 minecraft:redstone_wire replace
fill ~348 ~155 ~742 ~348 ~155 ~754 minecraft:redstone_wire replace
fill ~351 ~155 ~742 ~351 ~155 ~754 minecraft:redstone_wire replace
fill ~354 ~155 ~742 ~354 ~155 ~754 minecraft:redstone_wire replace
fill ~357 ~155 ~742 ~357 ~155 ~754 minecraft:redstone_wire replace
fill ~360 ~155 ~742 ~360 ~155 ~754 minecraft:redstone_wire replace
fill ~363 ~155 ~742 ~363 ~155 ~754 minecraft:redstone_wire replace
fill ~366 ~155 ~742 ~366 ~155 ~754 minecraft:redstone_wire replace
fill ~369 ~155 ~742 ~369 ~155 ~754 minecraft:redstone_wire replace
fill ~372 ~155 ~742 ~372 ~155 ~754 minecraft:redstone_wire replace
fill ~375 ~155 ~742 ~375 ~155 ~754 minecraft:redstone_wire replace
fill ~378 ~155 ~742 ~378 ~155 ~754 minecraft:redstone_wire replace
fill ~381 ~155 ~742 ~381 ~155 ~754 minecraft:redstone_wire replace
fill ~384 ~155 ~742 ~384 ~155 ~754 minecraft:redstone_wire replace
fill ~387 ~155 ~742 ~387 ~155 ~754 minecraft:redstone_wire replace
fill ~390 ~155 ~742 ~390 ~155 ~754 minecraft:redstone_wire replace
fill ~393 ~155 ~742 ~393 ~155 ~754 minecraft:redstone_wire replace
fill ~396 ~155 ~742 ~396 ~155 ~754 minecraft:redstone_wire replace
fill ~399 ~155 ~742 ~399 ~155 ~754 minecraft:redstone_wire replace
setblock ~426 ~155 ~742 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~744 ~426 ~155 ~756 minecraft:redstone_wire replace
setblock ~414 ~155 ~748 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~429 ~155 ~750 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~750 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~752 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~752 ~429 ~155 ~764 minecraft:redstone_wire replace
fill ~432 ~155 ~752 ~432 ~155 ~764 minecraft:redstone_wire replace
setblock ~420 ~155 ~754 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~754 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~756 minecraft:redstone_wire replace
fill ~423 ~155 ~756 ~423 ~155 ~760 minecraft:redstone_wire replace
fill ~255 ~155 ~758 ~255 ~155 ~764 minecraft:redstone_wire replace
fill ~258 ~155 ~758 ~258 ~155 ~766 minecraft:redstone_wire replace
fill ~261 ~155 ~758 ~261 ~155 ~770 minecraft:redstone_wire replace
fill ~264 ~155 ~758 ~264 ~155 ~770 minecraft:redstone_wire replace
fill ~267 ~155 ~758 ~267 ~155 ~770 minecraft:redstone_wire replace
fill ~270 ~155 ~758 ~270 ~155 ~770 minecraft:redstone_wire replace
fill ~273 ~155 ~758 ~273 ~155 ~770 minecraft:redstone_wire replace
fill ~276 ~155 ~758 ~276 ~155 ~770 minecraft:redstone_wire replace
fill ~279 ~155 ~758 ~279 ~155 ~770 minecraft:redstone_wire replace
fill ~282 ~155 ~758 ~282 ~155 ~770 minecraft:redstone_wire replace
fill ~285 ~155 ~758 ~285 ~155 ~770 minecraft:redstone_wire replace
fill ~288 ~155 ~758 ~288 ~155 ~770 minecraft:redstone_wire replace
fill ~291 ~155 ~758 ~291 ~155 ~770 minecraft:redstone_wire replace
fill ~294 ~155 ~758 ~294 ~155 ~770 minecraft:redstone_wire replace
fill ~297 ~155 ~758 ~297 ~155 ~770 minecraft:redstone_wire replace
fill ~300 ~155 ~758 ~300 ~155 ~770 minecraft:redstone_wire replace
fill ~303 ~155 ~758 ~303 ~155 ~770 minecraft:redstone_wire replace
fill ~306 ~155 ~758 ~306 ~155 ~770 minecraft:redstone_wire replace
fill ~309 ~155 ~758 ~309 ~155 ~770 minecraft:redstone_wire replace
fill ~312 ~155 ~758 ~312 ~155 ~770 minecraft:redstone_wire replace
fill ~315 ~155 ~758 ~315 ~155 ~770 minecraft:redstone_wire replace
fill ~318 ~155 ~758 ~318 ~155 ~770 minecraft:redstone_wire replace
fill ~321 ~155 ~758 ~321 ~155 ~770 minecraft:redstone_wire replace
fill ~324 ~155 ~758 ~324 ~155 ~770 minecraft:redstone_wire replace
fill ~327 ~155 ~758 ~327 ~155 ~770 minecraft:redstone_wire replace
fill ~330 ~155 ~758 ~330 ~155 ~770 minecraft:redstone_wire replace
fill ~333 ~155 ~758 ~333 ~155 ~770 minecraft:redstone_wire replace
fill ~336 ~155 ~758 ~336 ~155 ~770 minecraft:redstone_wire replace
fill ~339 ~155 ~758 ~339 ~155 ~770 minecraft:redstone_wire replace
fill ~342 ~155 ~758 ~342 ~155 ~770 minecraft:redstone_wire replace
fill ~345 ~155 ~758 ~345 ~155 ~770 minecraft:redstone_wire replace
fill ~348 ~155 ~758 ~348 ~155 ~770 minecraft:redstone_wire replace
fill ~351 ~155 ~758 ~351 ~155 ~770 minecraft:redstone_wire replace
fill ~354 ~155 ~758 ~354 ~155 ~770 minecraft:redstone_wire replace
fill ~357 ~155 ~758 ~357 ~155 ~770 minecraft:redstone_wire replace
fill ~360 ~155 ~758 ~360 ~155 ~770 minecraft:redstone_wire replace
fill ~363 ~155 ~758 ~363 ~155 ~770 minecraft:redstone_wire replace
fill ~366 ~155 ~758 ~366 ~155 ~770 minecraft:redstone_wire replace
fill ~369 ~155 ~758 ~369 ~155 ~770 minecraft:redstone_wire replace
fill ~372 ~155 ~758 ~372 ~155 ~770 minecraft:redstone_wire replace
fill ~375 ~155 ~758 ~375 ~155 ~770 minecraft:redstone_wire replace
fill ~378 ~155 ~758 ~378 ~155 ~770 minecraft:redstone_wire replace
fill ~381 ~155 ~758 ~381 ~155 ~770 minecraft:redstone_wire replace
fill ~384 ~155 ~758 ~384 ~155 ~770 minecraft:redstone_wire replace
fill ~387 ~155 ~758 ~387 ~155 ~770 minecraft:redstone_wire replace
fill ~390 ~155 ~758 ~390 ~155 ~770 minecraft:redstone_wire replace
fill ~393 ~155 ~758 ~393 ~155 ~770 minecraft:redstone_wire replace
fill ~396 ~155 ~758 ~396 ~155 ~770 minecraft:redstone_wire replace
fill ~399 ~155 ~758 ~399 ~155 ~770 minecraft:redstone_wire replace
setblock ~426 ~155 ~758 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~760 ~426 ~155 ~772 minecraft:redstone_wire replace
setblock ~429 ~155 ~766 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~766 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~768 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~768 ~429 ~155 ~780 minecraft:redstone_wire replace
fill ~432 ~155 ~768 ~432 ~155 ~780 minecraft:redstone_wire replace
setblock ~261 ~155 ~771 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~772 minecraft:redstone_wire replace
setblock ~264 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~155 ~774 ~264 ~155 ~776 minecraft:redstone_wire replace
fill ~267 ~155 ~774 ~267 ~155 ~780 minecraft:redstone_wire replace
fill ~270 ~155 ~774 ~270 ~155 ~782 minecraft:redstone_wire replace
fill ~273 ~155 ~774 ~273 ~155 ~786 minecraft:redstone_wire replace
fill ~276 ~155 ~774 ~276 ~155 ~786 minecraft:redstone_wire replace
fill ~279 ~155 ~774 ~279 ~155 ~786 minecraft:redstone_wire replace
fill ~282 ~155 ~774 ~282 ~155 ~786 minecraft:redstone_wire replace
fill ~285 ~155 ~774 ~285 ~155 ~786 minecraft:redstone_wire replace
fill ~288 ~155 ~774 ~288 ~155 ~786 minecraft:redstone_wire replace
fill ~291 ~155 ~774 ~291 ~155 ~786 minecraft:redstone_wire replace
fill ~294 ~155 ~774 ~294 ~155 ~786 minecraft:redstone_wire replace
fill ~297 ~155 ~774 ~297 ~155 ~786 minecraft:redstone_wire replace
fill ~300 ~155 ~774 ~300 ~155 ~786 minecraft:redstone_wire replace
fill ~303 ~155 ~774 ~303 ~155 ~786 minecraft:redstone_wire replace
fill ~306 ~155 ~774 ~306 ~155 ~786 minecraft:redstone_wire replace
fill ~309 ~155 ~774 ~309 ~155 ~786 minecraft:redstone_wire replace
fill ~312 ~155 ~774 ~312 ~155 ~786 minecraft:redstone_wire replace
fill ~315 ~155 ~774 ~315 ~155 ~786 minecraft:redstone_wire replace
fill ~318 ~155 ~774 ~318 ~155 ~786 minecraft:redstone_wire replace
fill ~321 ~155 ~774 ~321 ~155 ~786 minecraft:redstone_wire replace
fill ~324 ~155 ~774 ~324 ~155 ~786 minecraft:redstone_wire replace
fill ~327 ~155 ~774 ~327 ~155 ~786 minecraft:redstone_wire replace
fill ~330 ~155 ~774 ~330 ~155 ~786 minecraft:redstone_wire replace
fill ~333 ~155 ~774 ~333 ~155 ~786 minecraft:redstone_wire replace
fill ~336 ~155 ~774 ~336 ~155 ~786 minecraft:redstone_wire replace
fill ~339 ~155 ~774 ~339 ~155 ~786 minecraft:redstone_wire replace
fill ~342 ~155 ~774 ~342 ~155 ~786 minecraft:redstone_wire replace
fill ~345 ~155 ~774 ~345 ~155 ~786 minecraft:redstone_wire replace
fill ~348 ~155 ~774 ~348 ~155 ~786 minecraft:redstone_wire replace
fill ~351 ~155 ~774 ~351 ~155 ~786 minecraft:redstone_wire replace
fill ~354 ~155 ~774 ~354 ~155 ~786 minecraft:redstone_wire replace
fill ~357 ~155 ~774 ~357 ~155 ~786 minecraft:redstone_wire replace
fill ~360 ~155 ~774 ~360 ~155 ~786 minecraft:redstone_wire replace
fill ~363 ~155 ~774 ~363 ~155 ~786 minecraft:redstone_wire replace
fill ~366 ~155 ~774 ~366 ~155 ~786 minecraft:redstone_wire replace
fill ~369 ~155 ~774 ~369 ~155 ~786 minecraft:redstone_wire replace
fill ~372 ~155 ~774 ~372 ~155 ~786 minecraft:redstone_wire replace
fill ~375 ~155 ~774 ~375 ~155 ~786 minecraft:redstone_wire replace
fill ~378 ~155 ~774 ~378 ~155 ~786 minecraft:redstone_wire replace
fill ~381 ~155 ~774 ~381 ~155 ~786 minecraft:redstone_wire replace
fill ~384 ~155 ~774 ~384 ~155 ~786 minecraft:redstone_wire replace
fill ~387 ~155 ~774 ~387 ~155 ~786 minecraft:redstone_wire replace
fill ~390 ~155 ~774 ~390 ~155 ~786 minecraft:redstone_wire replace
fill ~393 ~155 ~774 ~393 ~155 ~786 minecraft:redstone_wire replace
fill ~396 ~155 ~774 ~396 ~155 ~786 minecraft:redstone_wire replace
fill ~399 ~155 ~774 ~399 ~155 ~786 minecraft:redstone_wire replace
setblock ~426 ~155 ~774 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~776 ~426 ~155 ~788 minecraft:redstone_wire replace
setblock ~429 ~155 ~782 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~782 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~784 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~784 ~429 ~155 ~796 minecraft:redstone_wire replace
fill ~432 ~155 ~784 ~432 ~155 ~796 minecraft:redstone_wire replace
setblock ~273 ~155 ~787 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~788 minecraft:redstone_wire replace
setblock ~276 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~155 ~790 ~276 ~155 ~792 minecraft:redstone_wire replace
fill ~279 ~155 ~790 ~279 ~155 ~796 minecraft:redstone_wire replace
fill ~282 ~155 ~790 ~282 ~155 ~798 minecraft:redstone_wire replace
fill ~285 ~155 ~790 ~285 ~155 ~802 minecraft:redstone_wire replace
fill ~288 ~155 ~790 ~288 ~155 ~802 minecraft:redstone_wire replace
fill ~291 ~155 ~790 ~291 ~155 ~802 minecraft:redstone_wire replace
fill ~294 ~155 ~790 ~294 ~155 ~802 minecraft:redstone_wire replace
fill ~297 ~155 ~790 ~297 ~155 ~802 minecraft:redstone_wire replace
fill ~300 ~155 ~790 ~300 ~155 ~802 minecraft:redstone_wire replace
fill ~303 ~155 ~790 ~303 ~155 ~802 minecraft:redstone_wire replace
fill ~306 ~155 ~790 ~306 ~155 ~802 minecraft:redstone_wire replace
fill ~309 ~155 ~790 ~309 ~155 ~802 minecraft:redstone_wire replace
fill ~312 ~155 ~790 ~312 ~155 ~802 minecraft:redstone_wire replace
fill ~315 ~155 ~790 ~315 ~155 ~802 minecraft:redstone_wire replace
fill ~318 ~155 ~790 ~318 ~155 ~802 minecraft:redstone_wire replace
fill ~321 ~155 ~790 ~321 ~155 ~802 minecraft:redstone_wire replace
fill ~324 ~155 ~790 ~324 ~155 ~802 minecraft:redstone_wire replace
fill ~327 ~155 ~790 ~327 ~155 ~802 minecraft:redstone_wire replace
fill ~330 ~155 ~790 ~330 ~155 ~802 minecraft:redstone_wire replace
fill ~333 ~155 ~790 ~333 ~155 ~802 minecraft:redstone_wire replace
fill ~336 ~155 ~790 ~336 ~155 ~802 minecraft:redstone_wire replace
fill ~339 ~155 ~790 ~339 ~155 ~802 minecraft:redstone_wire replace
fill ~342 ~155 ~790 ~342 ~155 ~802 minecraft:redstone_wire replace
fill ~345 ~155 ~790 ~345 ~155 ~802 minecraft:redstone_wire replace
fill ~348 ~155 ~790 ~348 ~155 ~802 minecraft:redstone_wire replace
fill ~351 ~155 ~790 ~351 ~155 ~802 minecraft:redstone_wire replace
fill ~354 ~155 ~790 ~354 ~155 ~802 minecraft:redstone_wire replace
fill ~357 ~155 ~790 ~357 ~155 ~802 minecraft:redstone_wire replace
fill ~360 ~155 ~790 ~360 ~155 ~802 minecraft:redstone_wire replace
fill ~363 ~155 ~790 ~363 ~155 ~802 minecraft:redstone_wire replace
fill ~366 ~155 ~790 ~366 ~155 ~802 minecraft:redstone_wire replace
fill ~369 ~155 ~790 ~369 ~155 ~802 minecraft:redstone_wire replace
fill ~372 ~155 ~790 ~372 ~155 ~802 minecraft:redstone_wire replace
fill ~375 ~155 ~790 ~375 ~155 ~802 minecraft:redstone_wire replace
fill ~378 ~155 ~790 ~378 ~155 ~802 minecraft:redstone_wire replace
fill ~381 ~155 ~790 ~381 ~155 ~802 minecraft:redstone_wire replace
fill ~384 ~155 ~790 ~384 ~155 ~802 minecraft:redstone_wire replace
fill ~387 ~155 ~790 ~387 ~155 ~802 minecraft:redstone_wire replace
fill ~390 ~155 ~790 ~390 ~155 ~802 minecraft:redstone_wire replace
fill ~393 ~155 ~790 ~393 ~155 ~802 minecraft:redstone_wire replace
fill ~396 ~155 ~790 ~396 ~155 ~802 minecraft:redstone_wire replace
fill ~399 ~155 ~790 ~399 ~155 ~802 minecraft:redstone_wire replace
setblock ~426 ~155 ~790 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~792 ~426 ~155 ~804 minecraft:redstone_wire replace
setblock ~429 ~155 ~798 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~798 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~800 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~800 ~429 ~155 ~812 minecraft:redstone_wire replace
fill ~432 ~155 ~800 ~432 ~155 ~812 minecraft:redstone_wire replace
setblock ~285 ~155 ~803 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~804 minecraft:redstone_wire replace
setblock ~288 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~155 ~806 ~288 ~155 ~808 minecraft:redstone_wire replace
fill ~291 ~155 ~806 ~291 ~155 ~812 minecraft:redstone_wire replace
fill ~294 ~155 ~806 ~294 ~155 ~814 minecraft:redstone_wire replace
fill ~297 ~155 ~806 ~297 ~155 ~818 minecraft:redstone_wire replace
fill ~300 ~155 ~806 ~300 ~155 ~818 minecraft:redstone_wire replace
fill ~303 ~155 ~806 ~303 ~155 ~818 minecraft:redstone_wire replace
fill ~306 ~155 ~806 ~306 ~155 ~818 minecraft:redstone_wire replace
fill ~309 ~155 ~806 ~309 ~155 ~818 minecraft:redstone_wire replace
fill ~312 ~155 ~806 ~312 ~155 ~818 minecraft:redstone_wire replace
fill ~315 ~155 ~806 ~315 ~155 ~818 minecraft:redstone_wire replace
fill ~318 ~155 ~806 ~318 ~155 ~818 minecraft:redstone_wire replace
fill ~321 ~155 ~806 ~321 ~155 ~818 minecraft:redstone_wire replace
fill ~324 ~155 ~806 ~324 ~155 ~818 minecraft:redstone_wire replace
fill ~327 ~155 ~806 ~327 ~155 ~818 minecraft:redstone_wire replace
fill ~330 ~155 ~806 ~330 ~155 ~818 minecraft:redstone_wire replace
fill ~333 ~155 ~806 ~333 ~155 ~818 minecraft:redstone_wire replace
fill ~336 ~155 ~806 ~336 ~155 ~818 minecraft:redstone_wire replace
fill ~339 ~155 ~806 ~339 ~155 ~818 minecraft:redstone_wire replace
fill ~342 ~155 ~806 ~342 ~155 ~818 minecraft:redstone_wire replace
fill ~345 ~155 ~806 ~345 ~155 ~818 minecraft:redstone_wire replace
fill ~348 ~155 ~806 ~348 ~155 ~818 minecraft:redstone_wire replace
fill ~351 ~155 ~806 ~351 ~155 ~818 minecraft:redstone_wire replace
fill ~354 ~155 ~806 ~354 ~155 ~818 minecraft:redstone_wire replace
fill ~357 ~155 ~806 ~357 ~155 ~818 minecraft:redstone_wire replace
fill ~360 ~155 ~806 ~360 ~155 ~818 minecraft:redstone_wire replace
fill ~363 ~155 ~806 ~363 ~155 ~818 minecraft:redstone_wire replace
fill ~366 ~155 ~806 ~366 ~155 ~818 minecraft:redstone_wire replace
fill ~369 ~155 ~806 ~369 ~155 ~818 minecraft:redstone_wire replace
fill ~372 ~155 ~806 ~372 ~155 ~818 minecraft:redstone_wire replace
fill ~375 ~155 ~806 ~375 ~155 ~818 minecraft:redstone_wire replace
fill ~378 ~155 ~806 ~378 ~155 ~818 minecraft:redstone_wire replace
fill ~381 ~155 ~806 ~381 ~155 ~818 minecraft:redstone_wire replace
fill ~384 ~155 ~806 ~384 ~155 ~818 minecraft:redstone_wire replace
fill ~387 ~155 ~806 ~387 ~155 ~818 minecraft:redstone_wire replace
fill ~390 ~155 ~806 ~390 ~155 ~818 minecraft:redstone_wire replace
fill ~393 ~155 ~806 ~393 ~155 ~818 minecraft:redstone_wire replace
fill ~396 ~155 ~806 ~396 ~155 ~818 minecraft:redstone_wire replace
fill ~399 ~155 ~806 ~399 ~155 ~818 minecraft:redstone_wire replace
setblock ~426 ~155 ~806 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~808 ~426 ~155 ~820 minecraft:redstone_wire replace
setblock ~429 ~155 ~814 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~814 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~816 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~816 ~429 ~155 ~828 minecraft:redstone_wire replace
fill ~432 ~155 ~816 ~432 ~155 ~828 minecraft:redstone_wire replace
setblock ~297 ~155 ~819 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~820 minecraft:redstone_wire replace
setblock ~300 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~155 ~822 ~300 ~155 ~824 minecraft:redstone_wire replace
fill ~303 ~155 ~822 ~303 ~155 ~828 minecraft:redstone_wire replace
fill ~306 ~155 ~822 ~306 ~155 ~830 minecraft:redstone_wire replace
fill ~309 ~155 ~822 ~309 ~155 ~834 minecraft:redstone_wire replace
fill ~312 ~155 ~822 ~312 ~155 ~834 minecraft:redstone_wire replace
fill ~315 ~155 ~822 ~315 ~155 ~834 minecraft:redstone_wire replace
fill ~318 ~155 ~822 ~318 ~155 ~834 minecraft:redstone_wire replace
fill ~321 ~155 ~822 ~321 ~155 ~834 minecraft:redstone_wire replace
fill ~324 ~155 ~822 ~324 ~155 ~834 minecraft:redstone_wire replace
fill ~327 ~155 ~822 ~327 ~155 ~834 minecraft:redstone_wire replace
fill ~330 ~155 ~822 ~330 ~155 ~834 minecraft:redstone_wire replace
fill ~333 ~155 ~822 ~333 ~155 ~834 minecraft:redstone_wire replace
fill ~336 ~155 ~822 ~336 ~155 ~834 minecraft:redstone_wire replace
fill ~339 ~155 ~822 ~339 ~155 ~834 minecraft:redstone_wire replace
fill ~342 ~155 ~822 ~342 ~155 ~834 minecraft:redstone_wire replace
fill ~345 ~155 ~822 ~345 ~155 ~834 minecraft:redstone_wire replace
fill ~348 ~155 ~822 ~348 ~155 ~834 minecraft:redstone_wire replace
fill ~351 ~155 ~822 ~351 ~155 ~834 minecraft:redstone_wire replace
fill ~354 ~155 ~822 ~354 ~155 ~834 minecraft:redstone_wire replace
fill ~357 ~155 ~822 ~357 ~155 ~834 minecraft:redstone_wire replace
fill ~360 ~155 ~822 ~360 ~155 ~834 minecraft:redstone_wire replace
fill ~363 ~155 ~822 ~363 ~155 ~834 minecraft:redstone_wire replace
fill ~366 ~155 ~822 ~366 ~155 ~834 minecraft:redstone_wire replace
fill ~369 ~155 ~822 ~369 ~155 ~834 minecraft:redstone_wire replace
fill ~372 ~155 ~822 ~372 ~155 ~834 minecraft:redstone_wire replace
fill ~375 ~155 ~822 ~375 ~155 ~834 minecraft:redstone_wire replace
fill ~378 ~155 ~822 ~378 ~155 ~834 minecraft:redstone_wire replace
fill ~381 ~155 ~822 ~381 ~155 ~834 minecraft:redstone_wire replace
fill ~384 ~155 ~822 ~384 ~155 ~834 minecraft:redstone_wire replace
fill ~387 ~155 ~822 ~387 ~155 ~834 minecraft:redstone_wire replace
fill ~390 ~155 ~822 ~390 ~155 ~834 minecraft:redstone_wire replace
fill ~393 ~155 ~822 ~393 ~155 ~834 minecraft:redstone_wire replace
fill ~396 ~155 ~822 ~396 ~155 ~834 minecraft:redstone_wire replace
fill ~399 ~155 ~822 ~399 ~155 ~834 minecraft:redstone_wire replace
setblock ~426 ~155 ~822 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~824 ~426 ~155 ~836 minecraft:redstone_wire replace
setblock ~429 ~155 ~830 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~830 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~832 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~832 ~429 ~155 ~844 minecraft:redstone_wire replace
fill ~432 ~155 ~832 ~432 ~155 ~844 minecraft:redstone_wire replace
setblock ~309 ~155 ~835 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~836 minecraft:redstone_wire replace
setblock ~312 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~155 ~838 ~312 ~155 ~840 minecraft:redstone_wire replace
fill ~315 ~155 ~838 ~315 ~155 ~844 minecraft:redstone_wire replace
fill ~318 ~155 ~838 ~318 ~155 ~846 minecraft:redstone_wire replace
fill ~321 ~155 ~838 ~321 ~155 ~850 minecraft:redstone_wire replace
fill ~324 ~155 ~838 ~324 ~155 ~850 minecraft:redstone_wire replace
fill ~327 ~155 ~838 ~327 ~155 ~850 minecraft:redstone_wire replace
fill ~330 ~155 ~838 ~330 ~155 ~850 minecraft:redstone_wire replace
fill ~333 ~155 ~838 ~333 ~155 ~850 minecraft:redstone_wire replace
fill ~336 ~155 ~838 ~336 ~155 ~850 minecraft:redstone_wire replace
fill ~339 ~155 ~838 ~339 ~155 ~850 minecraft:redstone_wire replace
fill ~342 ~155 ~838 ~342 ~155 ~850 minecraft:redstone_wire replace
fill ~345 ~155 ~838 ~345 ~155 ~850 minecraft:redstone_wire replace
fill ~348 ~155 ~838 ~348 ~155 ~850 minecraft:redstone_wire replace
fill ~351 ~155 ~838 ~351 ~155 ~850 minecraft:redstone_wire replace
fill ~354 ~155 ~838 ~354 ~155 ~850 minecraft:redstone_wire replace
fill ~357 ~155 ~838 ~357 ~155 ~850 minecraft:redstone_wire replace
fill ~360 ~155 ~838 ~360 ~155 ~850 minecraft:redstone_wire replace
fill ~363 ~155 ~838 ~363 ~155 ~850 minecraft:redstone_wire replace
fill ~366 ~155 ~838 ~366 ~155 ~850 minecraft:redstone_wire replace
fill ~369 ~155 ~838 ~369 ~155 ~850 minecraft:redstone_wire replace
fill ~372 ~155 ~838 ~372 ~155 ~850 minecraft:redstone_wire replace
fill ~375 ~155 ~838 ~375 ~155 ~850 minecraft:redstone_wire replace
fill ~378 ~155 ~838 ~378 ~155 ~850 minecraft:redstone_wire replace
fill ~381 ~155 ~838 ~381 ~155 ~850 minecraft:redstone_wire replace
fill ~384 ~155 ~838 ~384 ~155 ~850 minecraft:redstone_wire replace
fill ~387 ~155 ~838 ~387 ~155 ~850 minecraft:redstone_wire replace
fill ~390 ~155 ~838 ~390 ~155 ~850 minecraft:redstone_wire replace
fill ~393 ~155 ~838 ~393 ~155 ~850 minecraft:redstone_wire replace
fill ~396 ~155 ~838 ~396 ~155 ~850 minecraft:redstone_wire replace
fill ~399 ~155 ~838 ~399 ~155 ~850 minecraft:redstone_wire replace
