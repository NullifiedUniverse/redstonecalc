fill ~502 ~169 ~254 ~502 ~169 ~264 minecraft:redstone_wire replace
setblock ~446 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~258 ~446 ~169 ~268 minecraft:redstone_wire replace
fill ~452 ~169 ~258 ~452 ~169 ~268 minecraft:redstone_wire replace
fill ~454 ~169 ~258 ~454 ~169 ~268 minecraft:redstone_wire replace
fill ~464 ~169 ~258 ~464 ~169 ~268 minecraft:redstone_wire replace
fill ~466 ~169 ~258 ~466 ~169 ~268 minecraft:redstone_wire replace
fill ~468 ~169 ~258 ~468 ~169 ~268 minecraft:redstone_wire replace
fill ~478 ~169 ~258 ~478 ~169 ~268 minecraft:redstone_wire replace
fill ~480 ~169 ~258 ~480 ~169 ~268 minecraft:redstone_wire replace
fill ~488 ~169 ~258 ~488 ~169 ~268 minecraft:redstone_wire replace
fill ~490 ~169 ~258 ~490 ~169 ~268 minecraft:redstone_wire replace
setblock ~440 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~262 ~440 ~169 ~272 minecraft:redstone_wire replace
fill ~444 ~169 ~262 ~444 ~169 ~272 minecraft:redstone_wire replace
fill ~448 ~169 ~262 ~448 ~169 ~272 minecraft:redstone_wire replace
fill ~458 ~169 ~262 ~458 ~169 ~272 minecraft:redstone_wire replace
fill ~460 ~169 ~262 ~460 ~169 ~272 minecraft:redstone_wire replace
fill ~472 ~169 ~262 ~472 ~169 ~272 minecraft:redstone_wire replace
fill ~474 ~169 ~262 ~474 ~169 ~272 minecraft:redstone_wire replace
fill ~484 ~169 ~262 ~484 ~169 ~272 minecraft:redstone_wire replace
fill ~494 ~169 ~262 ~494 ~169 ~272 minecraft:redstone_wire replace
setblock ~442 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~266 ~442 ~169 ~276 minecraft:redstone_wire replace
fill ~450 ~169 ~266 ~450 ~169 ~276 minecraft:redstone_wire replace
fill ~456 ~169 ~266 ~456 ~169 ~276 minecraft:redstone_wire replace
fill ~462 ~169 ~266 ~462 ~169 ~276 minecraft:redstone_wire replace
fill ~470 ~169 ~266 ~470 ~169 ~276 minecraft:redstone_wire replace
fill ~476 ~169 ~266 ~476 ~169 ~276 minecraft:redstone_wire replace
fill ~486 ~169 ~266 ~486 ~169 ~276 minecraft:redstone_wire replace
fill ~492 ~169 ~266 ~492 ~169 ~276 minecraft:redstone_wire replace
fill ~500 ~169 ~266 ~500 ~169 ~276 minecraft:redstone_wire replace
fill ~502 ~169 ~266 ~502 ~169 ~276 minecraft:redstone_wire replace
setblock ~446 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~270 ~446 ~169 ~280 minecraft:redstone_wire replace
fill ~452 ~169 ~270 ~452 ~169 ~280 minecraft:redstone_wire replace
fill ~454 ~169 ~270 ~454 ~169 ~280 minecraft:redstone_wire replace
fill ~464 ~169 ~270 ~464 ~169 ~280 minecraft:redstone_wire replace
fill ~466 ~169 ~270 ~466 ~169 ~280 minecraft:redstone_wire replace
fill ~468 ~169 ~270 ~468 ~169 ~280 minecraft:redstone_wire replace
fill ~478 ~169 ~270 ~478 ~169 ~280 minecraft:redstone_wire replace
fill ~480 ~169 ~270 ~480 ~169 ~280 minecraft:redstone_wire replace
fill ~488 ~169 ~270 ~488 ~169 ~280 minecraft:redstone_wire replace
fill ~490 ~169 ~270 ~490 ~169 ~280 minecraft:redstone_wire replace
setblock ~440 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~274 ~440 ~169 ~284 minecraft:redstone_wire replace
fill ~444 ~169 ~274 ~444 ~169 ~284 minecraft:redstone_wire replace
fill ~448 ~169 ~274 ~448 ~169 ~284 minecraft:redstone_wire replace
fill ~458 ~169 ~274 ~458 ~169 ~284 minecraft:redstone_wire replace
fill ~460 ~169 ~274 ~460 ~169 ~284 minecraft:redstone_wire replace
fill ~472 ~169 ~274 ~472 ~169 ~284 minecraft:redstone_wire replace
fill ~474 ~169 ~274 ~474 ~169 ~284 minecraft:redstone_wire replace
fill ~484 ~169 ~274 ~484 ~169 ~284 minecraft:redstone_wire replace
fill ~494 ~169 ~274 ~494 ~169 ~284 minecraft:redstone_wire replace
setblock ~442 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~278 ~442 ~169 ~288 minecraft:redstone_wire replace
fill ~450 ~169 ~278 ~450 ~169 ~288 minecraft:redstone_wire replace
fill ~456 ~169 ~278 ~456 ~169 ~288 minecraft:redstone_wire replace
fill ~462 ~169 ~278 ~462 ~169 ~288 minecraft:redstone_wire replace
fill ~470 ~169 ~278 ~470 ~169 ~288 minecraft:redstone_wire replace
fill ~476 ~169 ~278 ~476 ~169 ~288 minecraft:redstone_wire replace
fill ~486 ~169 ~278 ~486 ~169 ~288 minecraft:redstone_wire replace
fill ~492 ~169 ~278 ~492 ~169 ~288 minecraft:redstone_wire replace
fill ~500 ~169 ~278 ~500 ~169 ~288 minecraft:redstone_wire replace
fill ~502 ~169 ~278 ~502 ~169 ~288 minecraft:redstone_wire replace
setblock ~446 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~282 ~446 ~169 ~292 minecraft:redstone_wire replace
fill ~452 ~169 ~282 ~452 ~169 ~292 minecraft:redstone_wire replace
fill ~454 ~169 ~282 ~454 ~169 ~292 minecraft:redstone_wire replace
fill ~464 ~169 ~282 ~464 ~169 ~292 minecraft:redstone_wire replace
fill ~466 ~169 ~282 ~466 ~169 ~292 minecraft:redstone_wire replace
fill ~468 ~169 ~282 ~468 ~169 ~292 minecraft:redstone_wire replace
fill ~478 ~169 ~282 ~478 ~169 ~292 minecraft:redstone_wire replace
fill ~480 ~169 ~282 ~480 ~169 ~292 minecraft:redstone_wire replace
fill ~488 ~169 ~282 ~488 ~169 ~292 minecraft:redstone_wire replace
fill ~490 ~169 ~282 ~490 ~169 ~292 minecraft:redstone_wire replace
setblock ~440 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~286 ~440 ~169 ~296 minecraft:redstone_wire replace
fill ~444 ~169 ~286 ~444 ~169 ~296 minecraft:redstone_wire replace
fill ~448 ~169 ~286 ~448 ~169 ~296 minecraft:redstone_wire replace
fill ~458 ~169 ~286 ~458 ~169 ~296 minecraft:redstone_wire replace
fill ~460 ~169 ~286 ~460 ~169 ~296 minecraft:redstone_wire replace
fill ~472 ~169 ~286 ~472 ~169 ~296 minecraft:redstone_wire replace
fill ~474 ~169 ~286 ~474 ~169 ~296 minecraft:redstone_wire replace
fill ~494 ~169 ~286 ~494 ~169 ~296 minecraft:redstone_wire replace
setblock ~442 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~290 ~442 ~169 ~300 minecraft:redstone_wire replace
fill ~450 ~169 ~290 ~450 ~169 ~300 minecraft:redstone_wire replace
fill ~456 ~169 ~290 ~456 ~169 ~300 minecraft:redstone_wire replace
fill ~462 ~169 ~290 ~462 ~169 ~300 minecraft:redstone_wire replace
fill ~470 ~169 ~290 ~470 ~169 ~300 minecraft:redstone_wire replace
fill ~476 ~169 ~290 ~476 ~169 ~300 minecraft:redstone_wire replace
fill ~486 ~169 ~290 ~486 ~169 ~300 minecraft:redstone_wire replace
fill ~492 ~169 ~290 ~492 ~169 ~300 minecraft:redstone_wire replace
fill ~500 ~169 ~290 ~500 ~169 ~300 minecraft:redstone_wire replace
fill ~502 ~169 ~290 ~502 ~169 ~300 minecraft:redstone_wire replace
setblock ~446 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~294 ~446 ~169 ~304 minecraft:redstone_wire replace
fill ~452 ~169 ~294 ~452 ~169 ~304 minecraft:redstone_wire replace
fill ~454 ~169 ~294 ~454 ~169 ~304 minecraft:redstone_wire replace
fill ~464 ~169 ~294 ~464 ~169 ~304 minecraft:redstone_wire replace
fill ~466 ~169 ~294 ~466 ~169 ~304 minecraft:redstone_wire replace
fill ~468 ~169 ~294 ~468 ~169 ~304 minecraft:redstone_wire replace
fill ~478 ~169 ~294 ~478 ~169 ~304 minecraft:redstone_wire replace
fill ~480 ~169 ~294 ~480 ~169 ~304 minecraft:redstone_wire replace
fill ~488 ~169 ~294 ~488 ~169 ~304 minecraft:redstone_wire replace
fill ~490 ~169 ~294 ~490 ~169 ~304 minecraft:redstone_wire replace
setblock ~440 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~298 ~440 ~169 ~308 minecraft:redstone_wire replace
fill ~444 ~169 ~298 ~444 ~169 ~308 minecraft:redstone_wire replace
fill ~448 ~169 ~298 ~448 ~169 ~308 minecraft:redstone_wire replace
fill ~458 ~169 ~298 ~458 ~169 ~308 minecraft:redstone_wire replace
fill ~460 ~169 ~298 ~460 ~169 ~308 minecraft:redstone_wire replace
fill ~472 ~169 ~298 ~472 ~169 ~308 minecraft:redstone_wire replace
fill ~474 ~169 ~298 ~474 ~169 ~308 minecraft:redstone_wire replace
fill ~494 ~169 ~298 ~494 ~169 ~308 minecraft:redstone_wire replace
setblock ~442 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~302 ~442 ~169 ~312 minecraft:redstone_wire replace
fill ~450 ~169 ~302 ~450 ~169 ~312 minecraft:redstone_wire replace
fill ~456 ~169 ~302 ~456 ~169 ~312 minecraft:redstone_wire replace
fill ~462 ~169 ~302 ~462 ~169 ~312 minecraft:redstone_wire replace
fill ~470 ~169 ~302 ~470 ~169 ~312 minecraft:redstone_wire replace
fill ~476 ~169 ~302 ~476 ~169 ~312 minecraft:redstone_wire replace
fill ~492 ~169 ~302 ~492 ~169 ~312 minecraft:redstone_wire replace
fill ~500 ~169 ~302 ~500 ~169 ~312 minecraft:redstone_wire replace
fill ~502 ~169 ~302 ~502 ~169 ~312 minecraft:redstone_wire replace
setblock ~446 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~306 ~446 ~169 ~316 minecraft:redstone_wire replace
fill ~452 ~169 ~306 ~452 ~169 ~316 minecraft:redstone_wire replace
fill ~454 ~169 ~306 ~454 ~169 ~316 minecraft:redstone_wire replace
fill ~464 ~169 ~306 ~464 ~169 ~316 minecraft:redstone_wire replace
fill ~466 ~169 ~306 ~466 ~169 ~316 minecraft:redstone_wire replace
fill ~468 ~169 ~306 ~468 ~169 ~316 minecraft:redstone_wire replace
fill ~478 ~169 ~306 ~478 ~169 ~316 minecraft:redstone_wire replace
fill ~480 ~169 ~306 ~480 ~169 ~316 minecraft:redstone_wire replace
fill ~488 ~169 ~306 ~488 ~169 ~316 minecraft:redstone_wire replace
fill ~490 ~169 ~306 ~490 ~169 ~316 minecraft:redstone_wire replace
setblock ~440 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~310 ~440 ~169 ~320 minecraft:redstone_wire replace
fill ~444 ~169 ~310 ~444 ~169 ~320 minecraft:redstone_wire replace
fill ~448 ~169 ~310 ~448 ~169 ~320 minecraft:redstone_wire replace
fill ~458 ~169 ~310 ~458 ~169 ~320 minecraft:redstone_wire replace
fill ~460 ~169 ~310 ~460 ~169 ~320 minecraft:redstone_wire replace
fill ~472 ~169 ~310 ~472 ~169 ~320 minecraft:redstone_wire replace
fill ~474 ~169 ~310 ~474 ~169 ~320 minecraft:redstone_wire replace
fill ~494 ~169 ~310 ~494 ~169 ~320 minecraft:redstone_wire replace
setblock ~442 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~314 ~442 ~169 ~324 minecraft:redstone_wire replace
fill ~450 ~169 ~314 ~450 ~169 ~324 minecraft:redstone_wire replace
fill ~456 ~169 ~314 ~456 ~169 ~324 minecraft:redstone_wire replace
fill ~462 ~169 ~314 ~462 ~169 ~324 minecraft:redstone_wire replace
fill ~470 ~169 ~314 ~470 ~169 ~324 minecraft:redstone_wire replace
fill ~476 ~169 ~314 ~476 ~169 ~324 minecraft:redstone_wire replace
fill ~492 ~169 ~314 ~492 ~169 ~324 minecraft:redstone_wire replace
fill ~500 ~169 ~314 ~500 ~169 ~324 minecraft:redstone_wire replace
fill ~502 ~169 ~314 ~502 ~169 ~324 minecraft:redstone_wire replace
setblock ~446 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~318 ~446 ~169 ~328 minecraft:redstone_wire replace
fill ~452 ~169 ~318 ~452 ~169 ~328 minecraft:redstone_wire replace
fill ~454 ~169 ~318 ~454 ~169 ~328 minecraft:redstone_wire replace
fill ~464 ~169 ~318 ~464 ~169 ~328 minecraft:redstone_wire replace
fill ~466 ~169 ~318 ~466 ~169 ~328 minecraft:redstone_wire replace
fill ~468 ~169 ~318 ~468 ~169 ~328 minecraft:redstone_wire replace
fill ~478 ~169 ~318 ~478 ~169 ~328 minecraft:redstone_wire replace
fill ~480 ~169 ~318 ~480 ~169 ~328 minecraft:redstone_wire replace
fill ~488 ~169 ~318 ~488 ~169 ~328 minecraft:redstone_wire replace
fill ~490 ~169 ~318 ~490 ~169 ~328 minecraft:redstone_wire replace
setblock ~440 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~322 ~440 ~169 ~332 minecraft:redstone_wire replace
fill ~444 ~169 ~322 ~444 ~169 ~332 minecraft:redstone_wire replace
fill ~448 ~169 ~322 ~448 ~169 ~332 minecraft:redstone_wire replace
fill ~458 ~169 ~322 ~458 ~169 ~332 minecraft:redstone_wire replace
fill ~460 ~169 ~322 ~460 ~169 ~332 minecraft:redstone_wire replace
fill ~472 ~169 ~322 ~472 ~169 ~332 minecraft:redstone_wire replace
fill ~474 ~169 ~322 ~474 ~169 ~332 minecraft:redstone_wire replace
fill ~494 ~169 ~322 ~494 ~169 ~332 minecraft:redstone_wire replace
setblock ~442 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~326 ~442 ~169 ~336 minecraft:redstone_wire replace
fill ~450 ~169 ~326 ~450 ~169 ~336 minecraft:redstone_wire replace
fill ~456 ~169 ~326 ~456 ~169 ~336 minecraft:redstone_wire replace
fill ~462 ~169 ~326 ~462 ~169 ~336 minecraft:redstone_wire replace
fill ~470 ~169 ~326 ~470 ~169 ~336 minecraft:redstone_wire replace
fill ~476 ~169 ~326 ~476 ~169 ~336 minecraft:redstone_wire replace
fill ~492 ~169 ~326 ~492 ~169 ~336 minecraft:redstone_wire replace
fill ~500 ~169 ~326 ~500 ~169 ~336 minecraft:redstone_wire replace
fill ~502 ~169 ~326 ~502 ~169 ~336 minecraft:redstone_wire replace
setblock ~446 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~330 ~446 ~169 ~340 minecraft:redstone_wire replace
fill ~452 ~169 ~330 ~452 ~169 ~340 minecraft:redstone_wire replace
fill ~454 ~169 ~330 ~454 ~169 ~340 minecraft:redstone_wire replace
fill ~464 ~169 ~330 ~464 ~169 ~340 minecraft:redstone_wire replace
fill ~466 ~169 ~330 ~466 ~169 ~340 minecraft:redstone_wire replace
fill ~468 ~169 ~330 ~468 ~169 ~340 minecraft:redstone_wire replace
fill ~478 ~169 ~330 ~478 ~169 ~340 minecraft:redstone_wire replace
fill ~480 ~169 ~330 ~480 ~169 ~340 minecraft:redstone_wire replace
fill ~490 ~169 ~330 ~490 ~169 ~340 minecraft:redstone_wire replace
setblock ~440 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~334 ~440 ~169 ~344 minecraft:redstone_wire replace
fill ~444 ~169 ~334 ~444 ~169 ~344 minecraft:redstone_wire replace
fill ~448 ~169 ~334 ~448 ~169 ~344 minecraft:redstone_wire replace
fill ~458 ~169 ~334 ~458 ~169 ~344 minecraft:redstone_wire replace
fill ~460 ~169 ~334 ~460 ~169 ~344 minecraft:redstone_wire replace
fill ~472 ~169 ~334 ~472 ~169 ~344 minecraft:redstone_wire replace
fill ~474 ~169 ~334 ~474 ~169 ~344 minecraft:redstone_wire replace
fill ~494 ~169 ~334 ~494 ~169 ~344 minecraft:redstone_wire replace
setblock ~442 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~338 ~442 ~169 ~348 minecraft:redstone_wire replace
fill ~450 ~169 ~338 ~450 ~169 ~348 minecraft:redstone_wire replace
fill ~456 ~169 ~338 ~456 ~169 ~348 minecraft:redstone_wire replace
fill ~462 ~169 ~338 ~462 ~169 ~348 minecraft:redstone_wire replace
fill ~470 ~169 ~338 ~470 ~169 ~348 minecraft:redstone_wire replace
fill ~476 ~169 ~338 ~476 ~169 ~348 minecraft:redstone_wire replace
fill ~492 ~169 ~338 ~492 ~169 ~348 minecraft:redstone_wire replace
fill ~500 ~169 ~338 ~500 ~169 ~348 minecraft:redstone_wire replace
fill ~502 ~169 ~338 ~502 ~169 ~348 minecraft:redstone_wire replace
setblock ~446 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~342 ~446 ~169 ~352 minecraft:redstone_wire replace
fill ~452 ~169 ~342 ~452 ~169 ~352 minecraft:redstone_wire replace
fill ~454 ~169 ~342 ~454 ~169 ~352 minecraft:redstone_wire replace
fill ~464 ~169 ~342 ~464 ~169 ~352 minecraft:redstone_wire replace
fill ~466 ~169 ~342 ~466 ~169 ~352 minecraft:redstone_wire replace
fill ~468 ~169 ~342 ~468 ~169 ~352 minecraft:redstone_wire replace
fill ~478 ~169 ~342 ~478 ~169 ~352 minecraft:redstone_wire replace
fill ~480 ~169 ~342 ~480 ~169 ~352 minecraft:redstone_wire replace
fill ~490 ~169 ~342 ~490 ~169 ~352 minecraft:redstone_wire replace
setblock ~440 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~346 ~440 ~169 ~356 minecraft:redstone_wire replace
fill ~444 ~169 ~346 ~444 ~169 ~356 minecraft:redstone_wire replace
fill ~448 ~169 ~346 ~448 ~169 ~356 minecraft:redstone_wire replace
fill ~458 ~169 ~346 ~458 ~169 ~356 minecraft:redstone_wire replace
fill ~460 ~169 ~346 ~460 ~169 ~356 minecraft:redstone_wire replace
fill ~472 ~169 ~346 ~472 ~169 ~356 minecraft:redstone_wire replace
fill ~474 ~169 ~346 ~474 ~169 ~356 minecraft:redstone_wire replace
fill ~494 ~169 ~346 ~494 ~169 ~356 minecraft:redstone_wire replace
setblock ~442 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~350 ~442 ~169 ~360 minecraft:redstone_wire replace
fill ~450 ~169 ~350 ~450 ~169 ~360 minecraft:redstone_wire replace
fill ~456 ~169 ~350 ~456 ~169 ~360 minecraft:redstone_wire replace
fill ~462 ~169 ~350 ~462 ~169 ~360 minecraft:redstone_wire replace
fill ~470 ~169 ~350 ~470 ~169 ~360 minecraft:redstone_wire replace
fill ~476 ~169 ~350 ~476 ~169 ~360 minecraft:redstone_wire replace
fill ~492 ~169 ~350 ~492 ~169 ~360 minecraft:redstone_wire replace
fill ~500 ~169 ~350 ~500 ~169 ~360 minecraft:redstone_wire replace
fill ~502 ~169 ~350 ~502 ~169 ~360 minecraft:redstone_wire replace
setblock ~446 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~354 ~446 ~169 ~364 minecraft:redstone_wire replace
fill ~452 ~169 ~354 ~452 ~169 ~364 minecraft:redstone_wire replace
fill ~454 ~169 ~354 ~454 ~169 ~364 minecraft:redstone_wire replace
fill ~464 ~169 ~354 ~464 ~169 ~364 minecraft:redstone_wire replace
fill ~466 ~169 ~354 ~466 ~169 ~364 minecraft:redstone_wire replace
fill ~468 ~169 ~354 ~468 ~169 ~364 minecraft:redstone_wire replace
fill ~478 ~169 ~354 ~478 ~169 ~364 minecraft:redstone_wire replace
fill ~480 ~169 ~354 ~480 ~169 ~364 minecraft:redstone_wire replace
fill ~490 ~169 ~354 ~490 ~169 ~364 minecraft:redstone_wire replace
setblock ~440 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~358 ~440 ~169 ~368 minecraft:redstone_wire replace
fill ~444 ~169 ~358 ~444 ~169 ~368 minecraft:redstone_wire replace
fill ~448 ~169 ~358 ~448 ~169 ~368 minecraft:redstone_wire replace
fill ~458 ~169 ~358 ~458 ~169 ~368 minecraft:redstone_wire replace
fill ~460 ~169 ~358 ~460 ~169 ~368 minecraft:redstone_wire replace
fill ~472 ~169 ~358 ~472 ~169 ~368 minecraft:redstone_wire replace
fill ~474 ~169 ~358 ~474 ~169 ~368 minecraft:redstone_wire replace
fill ~494 ~169 ~358 ~494 ~169 ~368 minecraft:redstone_wire replace
setblock ~442 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~362 ~442 ~169 ~372 minecraft:redstone_wire replace
fill ~450 ~169 ~362 ~450 ~169 ~372 minecraft:redstone_wire replace
fill ~456 ~169 ~362 ~456 ~169 ~372 minecraft:redstone_wire replace
fill ~462 ~169 ~362 ~462 ~169 ~372 minecraft:redstone_wire replace
fill ~470 ~169 ~362 ~470 ~169 ~372 minecraft:redstone_wire replace
fill ~476 ~169 ~362 ~476 ~169 ~372 minecraft:redstone_wire replace
fill ~492 ~169 ~362 ~492 ~169 ~372 minecraft:redstone_wire replace
fill ~500 ~169 ~362 ~500 ~169 ~372 minecraft:redstone_wire replace
fill ~502 ~169 ~362 ~502 ~169 ~372 minecraft:redstone_wire replace
setblock ~446 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~366 ~446 ~169 ~376 minecraft:redstone_wire replace
fill ~452 ~169 ~366 ~452 ~169 ~376 minecraft:redstone_wire replace
fill ~454 ~169 ~366 ~454 ~169 ~376 minecraft:redstone_wire replace
fill ~464 ~169 ~366 ~464 ~169 ~376 minecraft:redstone_wire replace
fill ~466 ~169 ~366 ~466 ~169 ~376 minecraft:redstone_wire replace
fill ~468 ~169 ~366 ~468 ~169 ~376 minecraft:redstone_wire replace
fill ~478 ~169 ~366 ~478 ~169 ~376 minecraft:redstone_wire replace
fill ~480 ~169 ~366 ~480 ~169 ~376 minecraft:redstone_wire replace
setblock ~440 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~370 ~440 ~169 ~380 minecraft:redstone_wire replace
fill ~444 ~169 ~370 ~444 ~169 ~380 minecraft:redstone_wire replace
fill ~448 ~169 ~370 ~448 ~169 ~380 minecraft:redstone_wire replace
fill ~458 ~169 ~370 ~458 ~169 ~380 minecraft:redstone_wire replace
fill ~460 ~169 ~370 ~460 ~169 ~380 minecraft:redstone_wire replace
fill ~472 ~169 ~370 ~472 ~169 ~380 minecraft:redstone_wire replace
fill ~474 ~169 ~370 ~474 ~169 ~380 minecraft:redstone_wire replace
fill ~494 ~169 ~370 ~494 ~169 ~380 minecraft:redstone_wire replace
setblock ~442 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~374 ~442 ~169 ~384 minecraft:redstone_wire replace
fill ~450 ~169 ~374 ~450 ~169 ~384 minecraft:redstone_wire replace
fill ~456 ~169 ~374 ~456 ~169 ~384 minecraft:redstone_wire replace
fill ~462 ~169 ~374 ~462 ~169 ~384 minecraft:redstone_wire replace
fill ~470 ~169 ~374 ~470 ~169 ~384 minecraft:redstone_wire replace
fill ~476 ~169 ~374 ~476 ~169 ~384 minecraft:redstone_wire replace
fill ~492 ~169 ~374 ~492 ~169 ~384 minecraft:redstone_wire replace
fill ~500 ~169 ~374 ~500 ~169 ~384 minecraft:redstone_wire replace
fill ~502 ~169 ~374 ~502 ~169 ~384 minecraft:redstone_wire replace
setblock ~446 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~378 ~446 ~169 ~388 minecraft:redstone_wire replace
fill ~452 ~169 ~378 ~452 ~169 ~388 minecraft:redstone_wire replace
fill ~454 ~169 ~378 ~454 ~169 ~388 minecraft:redstone_wire replace
fill ~464 ~169 ~378 ~464 ~169 ~388 minecraft:redstone_wire replace
fill ~466 ~169 ~378 ~466 ~169 ~388 minecraft:redstone_wire replace
fill ~468 ~169 ~378 ~468 ~169 ~388 minecraft:redstone_wire replace
fill ~478 ~169 ~378 ~478 ~169 ~388 minecraft:redstone_wire replace
fill ~480 ~169 ~378 ~480 ~169 ~388 minecraft:redstone_wire replace
setblock ~440 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~382 ~440 ~169 ~392 minecraft:redstone_wire replace
fill ~444 ~169 ~382 ~444 ~169 ~392 minecraft:redstone_wire replace
fill ~448 ~169 ~382 ~448 ~169 ~392 minecraft:redstone_wire replace
fill ~458 ~169 ~382 ~458 ~169 ~392 minecraft:redstone_wire replace
fill ~460 ~169 ~382 ~460 ~169 ~392 minecraft:redstone_wire replace
fill ~472 ~169 ~382 ~472 ~169 ~392 minecraft:redstone_wire replace
fill ~474 ~169 ~382 ~474 ~169 ~392 minecraft:redstone_wire replace
fill ~494 ~169 ~382 ~494 ~169 ~392 minecraft:redstone_wire replace
setblock ~442 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~386 ~442 ~169 ~396 minecraft:redstone_wire replace
fill ~450 ~169 ~386 ~450 ~169 ~396 minecraft:redstone_wire replace
fill ~456 ~169 ~386 ~456 ~169 ~396 minecraft:redstone_wire replace
fill ~462 ~169 ~386 ~462 ~169 ~396 minecraft:redstone_wire replace
fill ~470 ~169 ~386 ~470 ~169 ~396 minecraft:redstone_wire replace
fill ~476 ~169 ~386 ~476 ~169 ~396 minecraft:redstone_wire replace
fill ~492 ~169 ~386 ~492 ~169 ~396 minecraft:redstone_wire replace
fill ~500 ~169 ~386 ~500 ~169 ~396 minecraft:redstone_wire replace
fill ~502 ~169 ~386 ~502 ~169 ~396 minecraft:redstone_wire replace
setblock ~446 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
