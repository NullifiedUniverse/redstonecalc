fill ~168 ~127 ~660 ~168 ~127 ~664 minecraft:redstone_wire replace
setblock ~117 ~128 ~383 minecraft:redstone_wire replace
setblock ~81 ~128 ~395 minecraft:redstone_wire replace
setblock ~87 ~128 ~471 minecraft:redstone_wire replace
setblock ~78 ~128 ~475 minecraft:redstone_wire replace
setblock ~90 ~128 ~479 minecraft:redstone_wire replace
setblock ~120 ~128 ~483 minecraft:redstone_wire replace
setblock ~111 ~128 ~487 minecraft:redstone_wire replace
setblock ~108 ~128 ~491 minecraft:redstone_wire replace
setblock ~105 ~128 ~495 minecraft:redstone_wire replace
setblock ~102 ~128 ~499 minecraft:redstone_wire replace
setblock ~99 ~128 ~503 minecraft:redstone_wire replace
setblock ~96 ~128 ~507 minecraft:redstone_wire replace
setblock ~93 ~128 ~511 minecraft:redstone_wire replace
setblock ~126 ~128 ~531 minecraft:redstone_wire replace
setblock ~114 ~128 ~535 minecraft:redstone_wire replace
setblock ~123 ~128 ~543 minecraft:redstone_wire replace
setblock ~159 ~128 ~547 minecraft:redstone_wire replace
setblock ~147 ~128 ~551 minecraft:redstone_wire replace
setblock ~144 ~128 ~555 minecraft:redstone_wire replace
setblock ~141 ~128 ~559 minecraft:redstone_wire replace
setblock ~138 ~128 ~563 minecraft:redstone_wire replace
setblock ~135 ~128 ~567 minecraft:redstone_wire replace
setblock ~132 ~128 ~571 minecraft:redstone_wire replace
setblock ~129 ~128 ~575 minecraft:redstone_wire replace
setblock ~162 ~128 ~599 minecraft:redstone_wire replace
setblock ~150 ~128 ~603 minecraft:redstone_wire replace
setblock ~156 ~128 ~607 minecraft:redstone_wire replace
setblock ~153 ~128 ~619 minecraft:redstone_wire replace
setblock ~171 ~128 ~643 minecraft:redstone_wire replace
setblock ~84 ~128 ~647 minecraft:redstone_wire replace
setblock ~165 ~128 ~651 minecraft:redstone_wire replace
setblock ~168 ~128 ~659 minecraft:redstone_wire replace
setblock ~103 ~129 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~129 ~382 ~107 ~129 ~382 minecraft:redstone_wire replace
setblock ~109 ~129 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~129 ~382 ~117 ~129 ~382 minecraft:redstone_wire replace
setblock ~82 ~129 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~129 ~394 ~83 ~129 ~394 minecraft:redstone_wire replace
setblock ~88 ~129 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~129 ~470 ~89 ~129 ~470 minecraft:redstone_wire replace
setblock ~79 ~129 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~129 ~474 ~80 ~129 ~474 minecraft:redstone_wire replace
setblock ~91 ~129 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~129 ~478 ~92 ~129 ~478 minecraft:redstone_wire replace
setblock ~106 ~129 ~481 minecraft:redstone_wire replace
fill ~105 ~129 ~482 ~109 ~129 ~482 minecraft:redstone_wire replace
setblock ~111 ~129 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~129 ~482 ~120 ~129 ~482 minecraft:redstone_wire replace
setblock ~100 ~129 ~485 minecraft:redstone_wire replace
fill ~99 ~129 ~486 ~100 ~129 ~486 minecraft:redstone_wire replace
setblock ~101 ~129 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~129 ~486 ~111 ~129 ~486 minecraft:redstone_wire replace
setblock ~100 ~129 ~489 minecraft:redstone_wire replace
fill ~99 ~129 ~490 ~108 ~129 ~490 minecraft:redstone_wire replace
setblock ~97 ~129 ~493 minecraft:redstone_wire replace
fill ~96 ~129 ~494 ~105 ~129 ~494 minecraft:redstone_wire replace
setblock ~97 ~129 ~497 minecraft:redstone_wire replace
fill ~96 ~129 ~498 ~102 ~129 ~498 minecraft:redstone_wire replace
setblock ~94 ~129 ~501 minecraft:redstone_wire replace
fill ~93 ~129 ~502 ~99 ~129 ~502 minecraft:redstone_wire replace
setblock ~94 ~129 ~505 minecraft:redstone_wire replace
fill ~93 ~129 ~506 ~96 ~129 ~506 minecraft:redstone_wire replace
setblock ~94 ~129 ~509 minecraft:redstone_wire replace
fill ~93 ~129 ~510 ~95 ~129 ~510 minecraft:redstone_wire replace
setblock ~106 ~129 ~529 minecraft:redstone_wire replace
fill ~105 ~129 ~530 ~117 ~129 ~530 minecraft:redstone_wire replace
setblock ~119 ~129 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~129 ~530 ~126 ~129 ~530 minecraft:redstone_wire replace
setblock ~100 ~129 ~533 minecraft:redstone_wire replace
fill ~99 ~129 ~534 ~101 ~129 ~534 minecraft:redstone_wire replace
setblock ~103 ~129 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~129 ~534 ~114 ~129 ~534 minecraft:redstone_wire replace
setblock ~106 ~129 ~541 minecraft:redstone_wire replace
fill ~105 ~129 ~542 ~113 ~129 ~542 minecraft:redstone_wire replace
setblock ~115 ~129 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~129 ~542 ~123 ~129 ~542 minecraft:redstone_wire replace
setblock ~121 ~129 ~545 minecraft:redstone_wire replace
fill ~120 ~129 ~546 ~127 ~129 ~546 minecraft:redstone_wire replace
setblock ~129 ~129 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~129 ~546 ~144 ~129 ~546 minecraft:redstone_wire replace
setblock ~146 ~129 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~129 ~546 ~159 ~129 ~546 minecraft:redstone_wire replace
setblock ~115 ~129 ~549 minecraft:redstone_wire replace
fill ~114 ~129 ~550 ~116 ~129 ~550 minecraft:redstone_wire replace
setblock ~117 ~129 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~129 ~550 ~131 ~129 ~550 minecraft:redstone_wire replace
setblock ~133 ~129 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~129 ~550 ~147 ~129 ~550 minecraft:redstone_wire replace
setblock ~115 ~129 ~553 minecraft:redstone_wire replace
setblock ~114 ~129 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~129 ~554 ~128 ~129 ~554 minecraft:redstone_wire replace
setblock ~130 ~129 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~129 ~554 ~144 ~129 ~554 minecraft:redstone_wire replace
setblock ~112 ~129 ~557 minecraft:redstone_wire replace
fill ~111 ~129 ~558 ~113 ~129 ~558 minecraft:redstone_wire replace
setblock ~115 ~129 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~129 ~558 ~130 ~129 ~558 minecraft:redstone_wire replace
setblock ~132 ~129 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~129 ~558 ~141 ~129 ~558 minecraft:redstone_wire replace
setblock ~112 ~129 ~561 minecraft:redstone_wire replace
fill ~111 ~129 ~562 ~123 ~129 ~562 minecraft:redstone_wire replace
setblock ~125 ~129 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~129 ~562 ~138 ~129 ~562 minecraft:redstone_wire replace
setblock ~109 ~129 ~565 minecraft:redstone_wire replace
fill ~108 ~129 ~566 ~119 ~129 ~566 minecraft:redstone_wire replace
setblock ~121 ~129 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~129 ~566 ~135 ~129 ~566 minecraft:redstone_wire replace
setblock ~109 ~129 ~569 minecraft:redstone_wire replace
fill ~108 ~129 ~570 ~116 ~129 ~570 minecraft:redstone_wire replace
setblock ~118 ~129 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~129 ~570 ~132 ~129 ~570 minecraft:redstone_wire replace
setblock ~109 ~129 ~573 minecraft:redstone_wire replace
fill ~108 ~129 ~574 ~119 ~129 ~574 minecraft:redstone_wire replace
setblock ~121 ~129 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~129 ~574 ~129 ~129 ~574 minecraft:redstone_wire replace
setblock ~121 ~129 ~597 minecraft:redstone_wire replace
fill ~120 ~129 ~598 ~129 ~129 ~598 minecraft:redstone_wire replace
setblock ~131 ~129 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~129 ~598 ~146 ~129 ~598 minecraft:redstone_wire replace
setblock ~148 ~129 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~129 ~598 ~162 ~129 ~598 minecraft:redstone_wire replace
setblock ~115 ~129 ~601 minecraft:redstone_wire replace
fill ~114 ~129 ~602 ~117 ~129 ~602 minecraft:redstone_wire replace
setblock ~119 ~129 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~129 ~602 ~134 ~129 ~602 minecraft:redstone_wire replace
setblock ~136 ~129 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~129 ~602 ~150 ~129 ~602 minecraft:redstone_wire replace
setblock ~121 ~129 ~605 minecraft:redstone_wire replace
fill ~120 ~129 ~606 ~129 ~129 ~606 minecraft:redstone_wire replace
setblock ~131 ~129 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~129 ~606 ~146 ~129 ~606 minecraft:redstone_wire replace
setblock ~148 ~129 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~129 ~606 ~156 ~129 ~606 minecraft:redstone_wire replace
setblock ~118 ~129 ~617 minecraft:redstone_wire replace
fill ~117 ~129 ~618 ~126 ~129 ~618 minecraft:redstone_wire replace
setblock ~128 ~129 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~129 ~618 ~143 ~129 ~618 minecraft:redstone_wire replace
setblock ~145 ~129 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~129 ~618 ~153 ~129 ~618 minecraft:redstone_wire replace
setblock ~130 ~129 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~129 ~642 ~130 ~129 ~642 minecraft:redstone_wire replace
setblock ~132 ~129 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~129 ~642 ~146 ~129 ~642 minecraft:redstone_wire replace
setblock ~148 ~129 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~129 ~642 ~162 ~129 ~642 minecraft:redstone_wire replace
setblock ~164 ~129 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~129 ~642 ~171 ~129 ~642 minecraft:redstone_wire replace
setblock ~85 ~129 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~129 ~646 ~86 ~129 ~646 minecraft:redstone_wire replace
setblock ~124 ~129 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~129 ~650 ~124 ~129 ~650 minecraft:redstone_wire replace
setblock ~126 ~129 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~129 ~650 ~140 ~129 ~650 minecraft:redstone_wire replace
setblock ~142 ~129 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~129 ~650 ~156 ~129 ~650 minecraft:redstone_wire replace
setblock ~158 ~129 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~129 ~650 ~165 ~129 ~650 minecraft:redstone_wire replace
setblock ~127 ~129 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~129 ~658 ~127 ~129 ~658 minecraft:redstone_wire replace
setblock ~129 ~129 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~129 ~658 ~143 ~129 ~658 minecraft:redstone_wire replace
setblock ~145 ~129 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~129 ~658 ~159 ~129 ~658 minecraft:redstone_wire replace
setblock ~161 ~129 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~129 ~658 ~168 ~129 ~658 minecraft:redstone_wire replace
setblock ~103 ~130 ~380 minecraft:redstone_wire replace
setblock ~82 ~130 ~392 minecraft:redstone_wire replace
setblock ~88 ~130 ~468 minecraft:redstone_wire replace
setblock ~79 ~130 ~472 minecraft:redstone_wire replace
setblock ~91 ~130 ~476 minecraft:redstone_wire replace
setblock ~106 ~130 ~480 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~130 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~130 ~488 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~130 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~130 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~130 ~500 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~130 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~130 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~130 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~130 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~130 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~130 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~130 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~130 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~130 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~130 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~130 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~130 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~130 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~130 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~130 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~130 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~130 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~130 ~640 minecraft:redstone_wire replace
setblock ~85 ~130 ~644 minecraft:redstone_wire replace
setblock ~124 ~130 ~648 minecraft:redstone_wire replace
setblock ~127 ~130 ~656 minecraft:redstone_wire replace
fill ~102 ~131 ~380 ~102 ~131 ~384 minecraft:redstone_wire replace
fill ~81 ~131 ~392 ~81 ~131 ~396 minecraft:redstone_wire replace
fill ~87 ~131 ~468 ~87 ~131 ~472 minecraft:redstone_wire replace
fill ~78 ~131 ~472 ~78 ~131 ~476 minecraft:redstone_wire replace
fill ~90 ~131 ~476 ~90 ~131 ~480 minecraft:redstone_wire replace
fill ~105 ~131 ~480 ~105 ~131 ~492 minecraft:redstone_wire replace
fill ~99 ~131 ~484 ~99 ~131 ~496 minecraft:redstone_wire replace
fill ~96 ~131 ~492 ~96 ~131 ~498 minecraft:redstone_wire replace
setblock ~105 ~131 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~496 ~105 ~131 ~508 minecraft:redstone_wire replace
setblock ~99 ~131 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~131 ~500 ~93 ~131 ~510 minecraft:redstone_wire replace
setblock ~96 ~131 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~131 ~500 ~99 ~131 ~512 minecraft:redstone_wire replace
setblock ~105 ~131 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~131 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~512 ~105 ~131 ~524 minecraft:redstone_wire replace
setblock ~99 ~131 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~131 ~516 ~99 ~131 ~528 minecraft:redstone_wire replace
setblock ~105 ~131 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~528 ~105 ~131 ~540 minecraft:redstone_wire replace
setblock ~99 ~131 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~131 ~532 ~99 ~131 ~536 minecraft:redstone_wire replace
setblock ~105 ~131 ~541 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~542 ~105 ~131 ~544 minecraft:redstone_wire replace
fill ~120 ~131 ~544 ~120 ~131 ~556 minecraft:redstone_wire replace
fill ~114 ~131 ~548 ~114 ~131 ~560 minecraft:redstone_wire replace
fill ~111 ~131 ~556 ~111 ~131 ~562 minecraft:redstone_wire replace
setblock ~120 ~131 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~560 ~120 ~131 ~572 minecraft:redstone_wire replace
setblock ~114 ~131 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~131 ~564 ~108 ~131 ~574 minecraft:redstone_wire replace
setblock ~111 ~131 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~131 ~564 ~114 ~131 ~576 minecraft:redstone_wire replace
setblock ~120 ~131 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~131 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~576 ~120 ~131 ~588 minecraft:redstone_wire replace
setblock ~114 ~131 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~131 ~580 ~114 ~131 ~592 minecraft:redstone_wire replace
setblock ~120 ~131 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~592 ~120 ~131 ~604 minecraft:redstone_wire replace
setblock ~114 ~131 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~131 ~596 ~114 ~131 ~602 minecraft:redstone_wire replace
setblock ~114 ~131 ~604 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~131 ~605 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~606 ~120 ~131 ~608 minecraft:redstone_wire replace
fill ~117 ~131 ~616 ~117 ~131 ~620 minecraft:redstone_wire replace
fill ~129 ~131 ~640 ~129 ~131 ~644 minecraft:redstone_wire replace
fill ~84 ~131 ~644 ~84 ~131 ~648 minecraft:redstone_wire replace
fill ~123 ~131 ~648 ~123 ~131 ~652 minecraft:redstone_wire replace
fill ~126 ~131 ~656 ~126 ~131 ~660 minecraft:redstone_wire replace
setblock ~102 ~132 ~385 minecraft:redstone_wire replace
setblock ~81 ~132 ~397 minecraft:redstone_wire replace
setblock ~87 ~132 ~473 minecraft:redstone_wire replace
setblock ~78 ~132 ~477 minecraft:redstone_wire replace
setblock ~90 ~132 ~481 minecraft:redstone_wire replace
setblock ~96 ~132 ~501 minecraft:redstone_wire replace
setblock ~93 ~132 ~513 minecraft:redstone_wire replace
setblock ~99 ~132 ~537 minecraft:redstone_wire replace
setblock ~105 ~132 ~545 minecraft:redstone_wire replace
setblock ~111 ~132 ~565 minecraft:redstone_wire replace
setblock ~108 ~132 ~577 minecraft:redstone_wire replace
setblock ~114 ~132 ~605 minecraft:redstone_wire replace
setblock ~120 ~132 ~609 minecraft:redstone_wire replace
setblock ~117 ~132 ~621 minecraft:redstone_wire replace
setblock ~129 ~132 ~645 minecraft:redstone_wire replace
setblock ~84 ~132 ~649 minecraft:redstone_wire replace
setblock ~123 ~132 ~653 minecraft:redstone_wire replace
setblock ~126 ~132 ~661 minecraft:redstone_wire replace
fill ~102 ~133 ~386 ~108 ~133 ~386 minecraft:redstone_wire replace
setblock ~110 ~133 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~133 ~386 ~116 ~133 ~386 minecraft:redstone_wire replace
setblock ~115 ~133 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~133 ~398 ~83 ~133 ~398 minecraft:redstone_wire replace
setblock ~82 ~133 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~133 ~474 ~89 ~133 ~474 minecraft:redstone_wire replace
setblock ~88 ~133 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~133 ~478 ~80 ~133 ~478 minecraft:redstone_wire replace
setblock ~79 ~133 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~133 ~482 ~95 ~133 ~482 minecraft:redstone_wire replace
setblock ~96 ~133 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~97 ~133 ~482 ~109 ~133 ~482 minecraft:redstone_wire replace
setblock ~110 ~133 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~133 ~482 ~119 ~133 ~482 minecraft:redstone_wire replace
setblock ~91 ~133 ~483 minecraft:redstone_wire replace
setblock ~94 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~133 ~483 minecraft:redstone_wire replace
setblock ~106 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~133 ~483 minecraft:redstone_wire replace
setblock ~118 ~133 ~483 minecraft:redstone_wire replace
fill ~90 ~133 ~502 ~108 ~133 ~502 minecraft:redstone_wire replace
setblock ~110 ~133 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~133 ~502 ~125 ~133 ~502 minecraft:redstone_wire replace
setblock ~91 ~133 ~503 minecraft:redstone_wire replace
setblock ~97 ~133 ~503 minecraft:redstone_wire replace
setblock ~103 ~133 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~133 ~503 minecraft:redstone_wire replace
setblock ~112 ~133 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~133 ~503 minecraft:redstone_wire replace
fill ~90 ~133 ~514 ~105 ~133 ~514 minecraft:redstone_wire replace
setblock ~107 ~133 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~133 ~514 ~122 ~133 ~514 minecraft:redstone_wire replace
setblock ~91 ~133 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~133 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~133 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~133 ~515 minecraft:redstone_wire replace
setblock ~109 ~133 ~515 minecraft:redstone_wire replace
setblock ~112 ~133 ~515 minecraft:redstone_wire replace
setblock ~121 ~133 ~515 minecraft:redstone_wire replace
fill ~93 ~133 ~538 ~105 ~133 ~538 minecraft:redstone_wire replace
setblock ~107 ~133 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~133 ~538 ~122 ~133 ~538 minecraft:redstone_wire replace
setblock ~94 ~133 ~539 minecraft:redstone_wire replace
setblock ~100 ~133 ~539 minecraft:redstone_wire replace
setblock ~103 ~133 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~133 ~539 minecraft:redstone_wire replace
setblock ~112 ~133 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~133 ~539 minecraft:redstone_wire replace
setblock ~121 ~133 ~539 minecraft:redstone_wire replace
fill ~105 ~133 ~546 ~114 ~133 ~546 minecraft:redstone_wire replace
setblock ~116 ~133 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~133 ~546 ~131 ~133 ~546 minecraft:redstone_wire replace
setblock ~132 ~133 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~133 ~546 ~146 ~133 ~546 minecraft:redstone_wire replace
setblock ~148 ~133 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~133 ~546 ~152 ~133 ~546 minecraft:redstone_wire replace
setblock ~127 ~133 ~547 minecraft:redstone_wire replace
setblock ~130 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~133 ~547 minecraft:redstone_wire replace
setblock ~142 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~133 ~547 minecraft:redstone_wire replace
setblock ~151 ~133 ~547 minecraft:redstone_wire replace
fill ~111 ~133 ~566 ~123 ~133 ~566 minecraft:redstone_wire replace
setblock ~125 ~133 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~133 ~566 ~140 ~133 ~566 minecraft:redstone_wire replace
setblock ~141 ~133 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~133 ~566 ~155 ~133 ~566 minecraft:redstone_wire replace
setblock ~127 ~133 ~567 minecraft:redstone_wire replace
setblock ~133 ~133 ~567 minecraft:redstone_wire replace
setblock ~139 ~133 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~133 ~567 minecraft:redstone_wire replace
setblock ~148 ~133 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~133 ~567 minecraft:redstone_wire replace
fill ~108 ~133 ~578 ~120 ~133 ~578 minecraft:redstone_wire replace
setblock ~122 ~133 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~133 ~578 ~137 ~133 ~578 minecraft:redstone_wire replace
setblock ~139 ~133 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~133 ~578 ~154 ~133 ~578 minecraft:redstone_wire replace
setblock ~155 ~133 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~133 ~578 ~158 ~133 ~578 minecraft:redstone_wire replace
setblock ~127 ~133 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~133 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~133 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~133 ~579 minecraft:redstone_wire replace
setblock ~145 ~133 ~579 minecraft:redstone_wire replace
setblock ~148 ~133 ~579 minecraft:redstone_wire replace
setblock ~157 ~133 ~579 minecraft:redstone_wire replace
fill ~114 ~133 ~606 ~126 ~133 ~606 minecraft:redstone_wire replace
setblock ~128 ~133 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~133 ~606 ~143 ~133 ~606 minecraft:redstone_wire replace
setblock ~144 ~133 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~133 ~606 ~158 ~133 ~606 minecraft:redstone_wire replace
setblock ~130 ~133 ~607 minecraft:redstone_wire replace
setblock ~136 ~133 ~607 minecraft:redstone_wire replace
setblock ~139 ~133 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~133 ~607 minecraft:redstone_wire replace
setblock ~148 ~133 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~133 ~607 minecraft:redstone_wire replace
setblock ~157 ~133 ~607 minecraft:redstone_wire replace
fill ~120 ~133 ~610 ~129 ~133 ~610 minecraft:redstone_wire replace
setblock ~131 ~133 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~133 ~610 ~146 ~133 ~610 minecraft:redstone_wire replace
setblock ~148 ~133 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~133 ~610 ~163 ~133 ~610 minecraft:redstone_wire replace
setblock ~164 ~133 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~163 ~133 ~611 minecraft:redstone_wire replace
fill ~117 ~133 ~622 ~123 ~133 ~622 minecraft:redstone_wire replace
setblock ~125 ~133 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~133 ~622 ~140 ~133 ~622 minecraft:redstone_wire replace
setblock ~142 ~133 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~133 ~622 ~157 ~133 ~622 minecraft:redstone_wire replace
setblock ~158 ~133 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~133 ~622 ~161 ~133 ~622 minecraft:redstone_wire replace
setblock ~160 ~133 ~623 minecraft:redstone_wire replace
fill ~129 ~133 ~646 ~135 ~133 ~646 minecraft:redstone_wire replace
setblock ~137 ~133 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~133 ~646 ~152 ~133 ~646 minecraft:redstone_wire replace
setblock ~154 ~133 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~133 ~646 ~169 ~133 ~646 minecraft:redstone_wire replace
setblock ~170 ~133 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~133 ~646 ~173 ~133 ~646 minecraft:redstone_wire replace
setblock ~172 ~133 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~133 ~650 ~86 ~133 ~650 minecraft:redstone_wire replace
setblock ~85 ~133 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~133 ~654 ~129 ~133 ~654 minecraft:redstone_wire replace
setblock ~131 ~133 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~133 ~654 ~146 ~133 ~654 minecraft:redstone_wire replace
setblock ~148 ~133 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~133 ~654 ~163 ~133 ~654 minecraft:redstone_wire replace
setblock ~164 ~133 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~133 ~654 ~167 ~133 ~654 minecraft:redstone_wire replace
setblock ~166 ~133 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~133 ~662 ~132 ~133 ~662 minecraft:redstone_wire replace
setblock ~134 ~133 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~133 ~662 ~149 ~133 ~662 minecraft:redstone_wire replace
setblock ~151 ~133 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~133 ~662 ~166 ~133 ~662 minecraft:redstone_wire replace
setblock ~167 ~133 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~168 ~133 ~662 ~170 ~133 ~662 minecraft:redstone_wire replace
setblock ~169 ~133 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~134 ~388 minecraft:redstone_wire replace
setblock ~82 ~134 ~400 minecraft:redstone_wire replace
setblock ~88 ~134 ~476 minecraft:redstone_wire replace
setblock ~79 ~134 ~480 minecraft:redstone_wire replace
setblock ~91 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~134 ~484 minecraft:redstone_wire replace
setblock ~97 ~134 ~484 minecraft:redstone_wire replace
setblock ~100 ~134 ~484 minecraft:redstone_wire replace
setblock ~103 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~134 ~484 minecraft:redstone_wire replace
setblock ~109 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~134 ~504 minecraft:redstone_wire replace
setblock ~106 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~134 ~504 minecraft:redstone_wire replace
setblock ~124 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~134 ~516 minecraft:redstone_wire replace
setblock ~94 ~134 ~516 minecraft:redstone_wire replace
setblock ~97 ~134 ~516 minecraft:redstone_wire replace
setblock ~100 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~134 ~540 minecraft:redstone_wire replace
setblock ~109 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~134 ~540 minecraft:redstone_wire replace
setblock ~118 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~134 ~548 minecraft:redstone_wire replace
setblock ~133 ~134 ~548 minecraft:redstone_wire replace
setblock ~136 ~134 ~548 minecraft:redstone_wire replace
setblock ~139 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~134 ~548 minecraft:redstone_wire replace
setblock ~145 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~134 ~568 minecraft:redstone_wire replace
setblock ~142 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~134 ~568 minecraft:redstone_wire replace
setblock ~154 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~134 ~580 minecraft:redstone_wire replace
setblock ~130 ~134 ~580 minecraft:redstone_wire replace
setblock ~133 ~134 ~580 minecraft:redstone_wire replace
setblock ~136 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~134 ~608 minecraft:redstone_wire replace
setblock ~145 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~134 ~608 minecraft:redstone_wire replace
setblock ~151 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~134 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~134 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~134 ~648 minecraft:redstone_wire replace
setblock ~85 ~134 ~652 minecraft:redstone_wire replace
setblock ~166 ~134 ~656 minecraft:redstone_wire replace
setblock ~169 ~134 ~664 minecraft:redstone_wire replace
fill ~114 ~135 ~384 ~114 ~135 ~388 minecraft:redstone_wire replace
fill ~81 ~135 ~396 ~81 ~135 ~400 minecraft:redstone_wire replace
setblock ~87 ~135 ~444 minecraft:redstone_wire replace
setblock ~87 ~135 ~446 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~135 ~448 minecraft:redstone_wire replace
fill ~87 ~135 ~448 ~87 ~135 ~460 minecraft:redstone_wire replace
setblock ~78 ~135 ~450 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~135 ~452 ~78 ~135 ~464 minecraft:redstone_wire replace
setblock ~117 ~135 ~452 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~135 ~454 ~117 ~135 ~460 minecraft:redstone_wire replace
fill ~108 ~135 ~456 ~108 ~135 ~460 minecraft:redstone_wire replace
setblock ~105 ~135 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~135 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~135 ~462 ~105 ~135 ~472 minecraft:redstone_wire replace
setblock ~108 ~135 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~135 ~464 ~87 ~135 ~476 minecraft:redstone_wire replace
setblock ~102 ~135 ~464 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~135 ~464 ~108 ~135 ~476 minecraft:redstone_wire replace
fill ~117 ~135 ~464 ~117 ~135 ~476 minecraft:redstone_wire replace
setblock ~78 ~135 ~466 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~135 ~466 ~102 ~135 ~476 minecraft:redstone_wire replace
fill ~78 ~135 ~468 ~78 ~135 ~480 minecraft:redstone_wire replace
setblock ~99 ~135 ~468 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~135 ~470 ~99 ~135 ~476 minecraft:redstone_wire replace
setblock ~96 ~135 ~472 minecraft:redstone_wire replace
setblock ~96 ~135 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~135 ~474 ~96 ~135 ~486 minecraft:redstone_wire replace
setblock ~105 ~135 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~135 ~476 minecraft:redstone_wire replace
fill ~105 ~135 ~476 ~105 ~135 ~488 minecraft:redstone_wire replace
setblock ~93 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~135 ~480 ~90 ~135 ~486 minecraft:redstone_wire replace
fill ~93 ~135 ~480 ~93 ~135 ~492 minecraft:redstone_wire replace
fill ~99 ~135 ~480 ~99 ~135 ~492 minecraft:redstone_wire replace
fill ~102 ~135 ~480 ~102 ~135 ~492 minecraft:redstone_wire replace
fill ~108 ~135 ~480 ~108 ~135 ~492 minecraft:redstone_wire replace
fill ~117 ~135 ~480 ~117 ~135 ~492 minecraft:redstone_wire replace
setblock ~90 ~135 ~488 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~135 ~488 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~135 ~490 ~90 ~135 ~502 minecraft:redstone_wire replace
fill ~96 ~135 ~490 ~96 ~135 ~502 minecraft:redstone_wire replace
setblock ~105 ~135 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~135 ~492 ~105 ~135 ~504 minecraft:redstone_wire replace
setblock ~93 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~135 ~496 ~93 ~135 ~508 minecraft:redstone_wire replace
fill ~99 ~135 ~496 ~99 ~135 ~508 minecraft:redstone_wire replace
fill ~102 ~135 ~496 ~102 ~135 ~508 minecraft:redstone_wire replace
fill ~108 ~135 ~496 ~108 ~135 ~508 minecraft:redstone_wire replace
fill ~117 ~135 ~496 ~117 ~135 ~508 minecraft:redstone_wire replace
setblock ~123 ~135 ~496 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~135 ~498 ~123 ~135 ~504 minecraft:redstone_wire replace
setblock ~111 ~135 ~500 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~135 ~502 ~111 ~135 ~508 minecraft:redstone_wire replace
setblock ~90 ~135 ~503 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~135 ~503 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~135 ~504 ~90 ~135 ~516 minecraft:redstone_wire replace
fill ~96 ~135 ~504 ~96 ~135 ~516 minecraft:redstone_wire replace
setblock ~93 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~135 ~512 ~93 ~135 ~524 minecraft:redstone_wire replace
fill ~99 ~135 ~512 ~99 ~135 ~524 minecraft:redstone_wire replace
fill ~102 ~135 ~512 ~102 ~135 ~524 minecraft:redstone_wire replace
fill ~108 ~135 ~512 ~108 ~135 ~524 minecraft:redstone_wire replace
fill ~111 ~135 ~512 ~111 ~135 ~524 minecraft:redstone_wire replace
fill ~117 ~135 ~512 ~117 ~135 ~524 minecraft:redstone_wire replace
setblock ~120 ~135 ~512 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~135 ~514 ~120 ~135 ~524 minecraft:redstone_wire replace
setblock ~150 ~135 ~516 minecraft:redstone_wire replace
setblock ~150 ~135 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~135 ~518 ~150 ~135 ~530 minecraft:redstone_wire replace
setblock ~144 ~135 ~520 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~135 ~522 ~144 ~135 ~532 minecraft:redstone_wire replace
setblock ~141 ~135 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~135 ~526 ~141 ~135 ~536 minecraft:redstone_wire replace
fill ~93 ~135 ~528 ~93 ~135 ~540 minecraft:redstone_wire replace
fill ~99 ~135 ~528 ~99 ~135 ~540 minecraft:redstone_wire replace
fill ~102 ~135 ~528 ~102 ~135 ~540 minecraft:redstone_wire replace
fill ~108 ~135 ~528 ~108 ~135 ~540 minecraft:redstone_wire replace
fill ~111 ~135 ~528 ~111 ~135 ~540 minecraft:redstone_wire replace
fill ~117 ~135 ~528 ~117 ~135 ~540 minecraft:redstone_wire replace
fill ~120 ~135 ~528 ~120 ~135 ~540 minecraft:redstone_wire replace
fill ~138 ~135 ~528 ~138 ~135 ~530 minecraft:redstone_wire replace
setblock ~135 ~135 ~532 minecraft:redstone_wire replace
setblock ~138 ~135 ~532 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~532 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~135 ~534 ~138 ~135 ~546 minecraft:redstone_wire replace
setblock ~144 ~135 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~135 ~534 ~150 ~135 ~546 minecraft:redstone_wire replace
setblock ~132 ~135 ~536 minecraft:redstone_wire replace
fill ~135 ~135 ~536 ~135 ~135 ~548 minecraft:redstone_wire replace
fill ~144 ~135 ~536 ~144 ~135 ~548 minecraft:redstone_wire replace
setblock ~132 ~135 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~135 ~538 ~132 ~135 ~550 minecraft:redstone_wire replace
setblock ~141 ~135 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~135 ~540 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~135 ~540 ~141 ~135 ~552 minecraft:redstone_wire replace
fill ~129 ~135 ~542 ~129 ~135 ~548 minecraft:redstone_wire replace
fill ~126 ~135 ~544 ~126 ~135 ~550 minecraft:redstone_wire replace
setblock ~138 ~135 ~547 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~547 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~135 ~548 ~138 ~135 ~560 minecraft:redstone_wire replace
