setblock ~126 ~133 ~566 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~139 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~148 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~123 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~138 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~140 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~157 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~606 minecraft:light_gray_concrete replace
setblock ~129 ~133 ~606 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~139 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~145 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~148 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~157 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~132 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~147 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~149 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~163 ~133 ~612 minecraft:light_gray_concrete replace
setblock ~124 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~126 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~141 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~143 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~160 ~133 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~138 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~153 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~155 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~172 ~133 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~133 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~132 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~147 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~149 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~166 ~133 ~656 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~135 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~150 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~152 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~169 ~133 ~664 minecraft:light_gray_concrete replace
fill ~114 ~134 ~384 ~114 ~134 ~388 minecraft:light_gray_concrete replace
fill ~81 ~134 ~396 ~81 ~134 ~400 minecraft:light_gray_concrete replace
fill ~87 ~134 ~444 ~87 ~134 ~476 minecraft:light_gray_concrete replace
fill ~78 ~134 ~448 ~78 ~134 ~480 minecraft:light_gray_concrete replace
fill ~117 ~134 ~452 ~117 ~134 ~540 minecraft:light_gray_concrete replace
fill ~108 ~134 ~456 ~108 ~134 ~540 minecraft:light_gray_concrete replace
fill ~105 ~134 ~460 ~105 ~134 ~504 minecraft:light_gray_concrete replace
fill ~102 ~134 ~464 ~102 ~134 ~540 minecraft:light_gray_concrete replace
fill ~99 ~134 ~468 ~99 ~134 ~540 minecraft:light_gray_concrete replace
fill ~96 ~134 ~472 ~96 ~134 ~516 minecraft:light_gray_concrete replace
fill ~93 ~134 ~476 ~93 ~134 ~540 minecraft:light_gray_concrete replace
fill ~90 ~134 ~480 ~90 ~134 ~516 minecraft:light_gray_concrete replace
fill ~123 ~134 ~496 ~123 ~134 ~504 minecraft:light_gray_concrete replace
fill ~111 ~134 ~500 ~111 ~134 ~540 minecraft:light_gray_concrete replace
fill ~120 ~134 ~512 ~120 ~134 ~540 minecraft:light_gray_concrete replace
fill ~150 ~134 ~516 ~150 ~134 ~608 minecraft:light_gray_concrete replace
fill ~144 ~134 ~520 ~144 ~134 ~608 minecraft:light_gray_concrete replace
fill ~141 ~134 ~524 ~141 ~134 ~568 minecraft:light_gray_concrete replace
fill ~138 ~134 ~528 ~138 ~134 ~608 minecraft:light_gray_concrete replace
fill ~135 ~134 ~532 ~135 ~134 ~608 minecraft:light_gray_concrete replace
fill ~132 ~134 ~536 ~132 ~134 ~580 minecraft:light_gray_concrete replace
fill ~129 ~134 ~540 ~129 ~134 ~608 minecraft:light_gray_concrete replace
fill ~126 ~134 ~544 ~126 ~134 ~580 minecraft:light_gray_concrete replace
fill ~153 ~134 ~560 ~153 ~134 ~568 minecraft:light_gray_concrete replace
fill ~147 ~134 ~564 ~147 ~134 ~608 minecraft:light_gray_concrete replace
fill ~156 ~134 ~576 ~156 ~134 ~608 minecraft:light_gray_concrete replace
fill ~162 ~134 ~608 ~162 ~134 ~612 minecraft:light_gray_concrete replace
fill ~159 ~134 ~620 ~159 ~134 ~624 minecraft:light_gray_concrete replace
fill ~171 ~134 ~644 ~171 ~134 ~648 minecraft:light_gray_concrete replace
fill ~84 ~134 ~648 ~84 ~134 ~652 minecraft:light_gray_concrete replace
fill ~165 ~134 ~652 ~165 ~134 ~656 minecraft:light_gray_concrete replace
fill ~168 ~134 ~660 ~168 ~134 ~664 minecraft:light_gray_concrete replace
setblock ~114 ~135 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~135 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~445 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~447 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~447 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~449 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~451 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~451 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~453 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~455 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~459 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~465 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~467 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~467 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~469 minecraft:light_gray_concrete replace
setblock ~96 ~135 ~471 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~473 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~475 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~475 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~90 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~91 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~90 ~135 ~487 minecraft:light_gray_concrete replace
setblock ~96 ~135 ~487 minecraft:light_gray_concrete replace
setblock ~90 ~135 ~489 minecraft:light_gray_concrete replace
setblock ~96 ~135 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~491 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~123 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~123 ~135 ~497 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~499 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~501 minecraft:light_gray_concrete replace
setblock ~91 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~97 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~124 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~513 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~515 minecraft:light_gray_concrete replace
setblock ~100 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~109 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~519 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~521 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~523 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~531 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~531 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~531 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~132 ~135 ~535 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~535 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~535 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~537 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~539 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~539 minecraft:light_gray_concrete replace
setblock ~94 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~100 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~541 minecraft:light_gray_concrete replace
setblock ~126 ~135 ~543 minecraft:light_gray_concrete replace
setblock ~127 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~145 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~126 ~135 ~551 minecraft:light_gray_concrete replace
setblock ~132 ~135 ~551 minecraft:light_gray_concrete replace
setblock ~126 ~135 ~553 minecraft:light_gray_concrete replace
setblock ~132 ~135 ~553 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~553 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~135 ~559 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~561 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~561 minecraft:light_gray_concrete replace
setblock ~153 ~135 ~561 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~147 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~565 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~565 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~565 minecraft:light_gray_concrete replace
setblock ~127 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~133 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~156 ~135 ~575 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~577 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~577 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~579 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~579 minecraft:light_gray_concrete replace
setblock ~136 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~157 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~147 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~156 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~147 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~156 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~162 ~135 ~607 minecraft:light_gray_concrete replace
setblock ~130 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~136 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~145 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~157 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~163 ~135 ~612 minecraft:light_gray_concrete replace
setblock ~159 ~135 ~619 minecraft:light_gray_concrete replace
setblock ~160 ~135 ~624 minecraft:light_gray_concrete replace
setblock ~171 ~135 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~135 ~647 minecraft:light_gray_concrete replace
setblock ~165 ~135 ~651 minecraft:light_gray_concrete replace
setblock ~168 ~135 ~659 minecraft:light_gray_concrete replace
fill ~100 ~136 ~380 ~100 ~136 ~381 minecraft:light_gray_concrete replace
fill ~99 ~136 ~382 ~114 ~136 ~382 minecraft:light_gray_concrete replace
fill ~82 ~136 ~392 ~82 ~136 ~393 minecraft:light_gray_concrete replace
fill ~81 ~136 ~394 ~83 ~136 ~394 minecraft:light_gray_concrete replace
fill ~88 ~136 ~440 ~88 ~136 ~441 minecraft:light_gray_concrete replace
fill ~87 ~136 ~442 ~89 ~136 ~442 minecraft:light_gray_concrete replace
fill ~79 ~136 ~444 ~79 ~136 ~445 minecraft:light_gray_concrete replace
fill ~78 ~136 ~446 ~80 ~136 ~446 minecraft:light_gray_concrete replace
fill ~103 ~136 ~448 ~103 ~136 ~449 minecraft:light_gray_concrete replace
fill ~102 ~136 ~450 ~117 ~136 ~450 minecraft:light_gray_concrete replace
fill ~97 ~136 ~452 ~97 ~136 ~453 minecraft:light_gray_concrete replace
fill ~96 ~136 ~454 ~108 ~136 ~454 minecraft:light_gray_concrete replace
fill ~97 ~136 ~456 ~97 ~136 ~457 minecraft:light_gray_concrete replace
fill ~96 ~136 ~458 ~105 ~136 ~458 minecraft:light_gray_concrete replace
fill ~94 ~136 ~460 ~94 ~136 ~461 minecraft:light_gray_concrete replace
fill ~93 ~136 ~462 ~102 ~136 ~462 minecraft:light_gray_concrete replace
fill ~94 ~136 ~464 ~94 ~136 ~465 minecraft:light_gray_concrete replace
fill ~93 ~136 ~466 ~99 ~136 ~466 minecraft:light_gray_concrete replace
fill ~94 ~136 ~468 ~94 ~136 ~469 minecraft:light_gray_concrete replace
fill ~93 ~136 ~470 ~96 ~136 ~470 minecraft:light_gray_concrete replace
fill ~91 ~136 ~472 ~91 ~136 ~473 minecraft:light_gray_concrete replace
fill ~90 ~136 ~474 ~93 ~136 ~474 minecraft:light_gray_concrete replace
fill ~91 ~136 ~476 ~91 ~136 ~477 minecraft:light_gray_concrete replace
fill ~90 ~136 ~478 ~92 ~136 ~478 minecraft:light_gray_concrete replace
fill ~103 ~136 ~492 ~103 ~136 ~493 minecraft:light_gray_concrete replace
fill ~102 ~136 ~494 ~123 ~136 ~494 minecraft:light_gray_concrete replace
fill ~97 ~136 ~496 ~97 ~136 ~497 minecraft:light_gray_concrete replace
fill ~96 ~136 ~498 ~111 ~136 ~498 minecraft:light_gray_concrete replace
fill ~103 ~136 ~508 ~103 ~136 ~509 minecraft:light_gray_concrete replace
fill ~102 ~136 ~510 ~120 ~136 ~510 minecraft:light_gray_concrete replace
fill ~115 ~136 ~512 ~115 ~136 ~513 minecraft:light_gray_concrete replace
fill ~114 ~136 ~514 ~150 ~136 ~514 minecraft:light_gray_concrete replace
fill ~112 ~136 ~516 ~112 ~136 ~517 minecraft:light_gray_concrete replace
fill ~111 ~136 ~518 ~144 ~136 ~518 minecraft:light_gray_concrete replace
fill ~112 ~136 ~520 ~112 ~136 ~521 minecraft:light_gray_concrete replace
fill ~111 ~136 ~522 ~141 ~136 ~522 minecraft:light_gray_concrete replace
fill ~109 ~136 ~524 ~109 ~136 ~525 minecraft:light_gray_concrete replace
fill ~108 ~136 ~526 ~138 ~136 ~526 minecraft:light_gray_concrete replace
fill ~109 ~136 ~528 ~109 ~136 ~529 minecraft:light_gray_concrete replace
fill ~108 ~136 ~530 ~135 ~136 ~530 minecraft:light_gray_concrete replace
fill ~109 ~136 ~532 ~109 ~136 ~533 minecraft:light_gray_concrete replace
fill ~108 ~136 ~534 ~132 ~136 ~534 minecraft:light_gray_concrete replace
fill ~106 ~136 ~536 ~106 ~136 ~537 minecraft:light_gray_concrete replace
fill ~105 ~136 ~538 ~129 ~136 ~538 minecraft:light_gray_concrete replace
fill ~106 ~136 ~540 ~106 ~136 ~541 minecraft:light_gray_concrete replace
fill ~105 ~136 ~542 ~126 ~136 ~542 minecraft:light_gray_concrete replace
fill ~115 ~136 ~556 ~115 ~136 ~557 minecraft:light_gray_concrete replace
fill ~114 ~136 ~558 ~153 ~136 ~558 minecraft:light_gray_concrete replace
fill ~112 ~136 ~560 ~112 ~136 ~561 minecraft:light_gray_concrete replace
fill ~111 ~136 ~562 ~147 ~136 ~562 minecraft:light_gray_concrete replace
fill ~115 ~136 ~572 ~115 ~136 ~573 minecraft:light_gray_concrete replace
fill ~114 ~136 ~574 ~156 ~136 ~574 minecraft:light_gray_concrete replace
fill ~121 ~136 ~604 ~121 ~136 ~605 minecraft:light_gray_concrete replace
fill ~120 ~136 ~606 ~162 ~136 ~606 minecraft:light_gray_concrete replace
fill ~118 ~136 ~616 ~118 ~136 ~617 minecraft:light_gray_concrete replace
fill ~117 ~136 ~618 ~159 ~136 ~618 minecraft:light_gray_concrete replace
fill ~130 ~136 ~640 ~130 ~136 ~641 minecraft:light_gray_concrete replace
fill ~129 ~136 ~642 ~171 ~136 ~642 minecraft:light_gray_concrete replace
fill ~85 ~136 ~644 ~85 ~136 ~645 minecraft:light_gray_concrete replace
fill ~84 ~136 ~646 ~86 ~136 ~646 minecraft:light_gray_concrete replace
fill ~124 ~136 ~648 ~124 ~136 ~649 minecraft:light_gray_concrete replace
fill ~123 ~136 ~650 ~165 ~136 ~650 minecraft:light_gray_concrete replace
fill ~127 ~136 ~656 ~127 ~136 ~657 minecraft:light_gray_concrete replace
fill ~126 ~136 ~658 ~168 ~136 ~658 minecraft:light_gray_concrete replace
setblock ~100 ~137 ~380 minecraft:light_gray_concrete replace
setblock ~105 ~137 ~382 minecraft:light_gray_concrete replace
setblock ~107 ~137 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~137 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~137 ~440 minecraft:light_gray_concrete replace
setblock ~79 ~137 ~444 minecraft:light_gray_concrete replace
setblock ~103 ~137 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~137 ~452 minecraft:light_gray_concrete replace
setblock ~98 ~137 ~454 minecraft:light_gray_concrete replace
setblock ~100 ~137 ~454 minecraft:light_gray_concrete replace
setblock ~97 ~137 ~456 minecraft:light_gray_concrete replace
setblock ~94 ~137 ~460 minecraft:light_gray_concrete replace
setblock ~94 ~137 ~464 minecraft:light_gray_concrete replace
setblock ~94 ~137 ~468 minecraft:light_gray_concrete replace
setblock ~91 ~137 ~472 minecraft:light_gray_concrete replace
setblock ~91 ~137 ~476 minecraft:light_gray_concrete replace
setblock ~103 ~137 ~492 minecraft:light_gray_concrete replace
setblock ~108 ~137 ~494 minecraft:light_gray_concrete replace
setblock ~110 ~137 ~494 minecraft:light_gray_concrete replace
setblock ~97 ~137 ~496 minecraft:light_gray_concrete replace
setblock ~103 ~137 ~508 minecraft:light_gray_concrete replace
setblock ~105 ~137 ~510 minecraft:light_gray_concrete replace
setblock ~107 ~137 ~510 minecraft:light_gray_concrete replace
setblock ~115 ~137 ~512 minecraft:light_gray_concrete replace
setblock ~119 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~136 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~138 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~112 ~137 ~516 minecraft:light_gray_concrete replace
setblock ~129 ~137 ~518 minecraft:light_gray_concrete replace
setblock ~131 ~137 ~518 minecraft:light_gray_concrete replace
setblock ~112 ~137 ~520 minecraft:light_gray_concrete replace
setblock ~126 ~137 ~522 minecraft:light_gray_concrete replace
setblock ~128 ~137 ~522 minecraft:light_gray_concrete replace
setblock ~109 ~137 ~524 minecraft:light_gray_concrete replace
setblock ~126 ~137 ~526 minecraft:light_gray_concrete replace
setblock ~128 ~137 ~526 minecraft:light_gray_concrete replace
setblock ~109 ~137 ~528 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~530 minecraft:light_gray_concrete replace
setblock ~123 ~137 ~530 minecraft:light_gray_concrete replace
setblock ~109 ~137 ~532 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~534 minecraft:light_gray_concrete replace
setblock ~120 ~137 ~534 minecraft:light_gray_concrete replace
setblock ~106 ~137 ~536 minecraft:light_gray_concrete replace
setblock ~114 ~137 ~538 minecraft:light_gray_concrete replace
setblock ~116 ~137 ~538 minecraft:light_gray_concrete replace
setblock ~106 ~137 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~542 minecraft:light_gray_concrete replace
setblock ~120 ~137 ~542 minecraft:light_gray_concrete replace
setblock ~115 ~137 ~556 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~123 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~138 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~140 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~112 ~137 ~560 minecraft:light_gray_concrete replace
setblock ~116 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~133 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~135 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~115 ~137 ~572 minecraft:light_gray_concrete replace
setblock ~127 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~129 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~144 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~146 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~604 minecraft:light_gray_concrete replace
setblock ~122 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~124 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~138 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~140 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~154 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~156 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~616 minecraft:light_gray_concrete replace
setblock ~119 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~135 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~137 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~151 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~153 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~130 ~137 ~640 minecraft:light_gray_concrete replace
setblock ~131 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~133 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~147 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~149 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~163 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~165 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~137 ~644 minecraft:light_gray_concrete replace
setblock ~124 ~137 ~648 minecraft:light_gray_concrete replace
setblock ~125 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~141 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~143 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~157 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~159 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~137 ~656 minecraft:light_gray_concrete replace
setblock ~128 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~130 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~144 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~146 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~160 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~162 ~137 ~658 minecraft:light_gray_concrete replace
fill ~99 ~138 ~380 ~99 ~138 ~384 minecraft:light_gray_concrete replace
fill ~81 ~138 ~392 ~81 ~138 ~396 minecraft:light_gray_concrete replace
fill ~87 ~138 ~440 ~87 ~138 ~444 minecraft:light_gray_concrete replace
fill ~78 ~138 ~444 ~78 ~138 ~448 minecraft:light_gray_concrete replace
fill ~102 ~138 ~448 ~102 ~138 ~512 minecraft:light_gray_concrete replace
fill ~96 ~138 ~452 ~96 ~138 ~500 minecraft:light_gray_concrete replace
fill ~93 ~138 ~460 ~93 ~138 ~472 minecraft:light_gray_concrete replace
fill ~90 ~138 ~472 ~90 ~138 ~480 minecraft:light_gray_concrete replace
fill ~114 ~138 ~512 ~114 ~138 ~576 minecraft:light_gray_concrete replace
fill ~111 ~138 ~516 ~111 ~138 ~564 minecraft:light_gray_concrete replace
fill ~108 ~138 ~524 ~108 ~138 ~536 minecraft:light_gray_concrete replace
fill ~105 ~138 ~536 ~105 ~138 ~544 minecraft:light_gray_concrete replace
fill ~120 ~138 ~604 ~120 ~138 ~608 minecraft:light_gray_concrete replace
fill ~117 ~138 ~616 ~117 ~138 ~620 minecraft:light_gray_concrete replace
fill ~129 ~138 ~640 ~129 ~138 ~644 minecraft:light_gray_concrete replace
fill ~84 ~138 ~644 ~84 ~138 ~648 minecraft:light_gray_concrete replace
fill ~123 ~138 ~648 ~123 ~138 ~652 minecraft:light_gray_concrete replace
fill ~126 ~138 ~656 ~126 ~138 ~660 minecraft:light_gray_concrete replace
setblock ~99 ~139 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~139 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~139 ~445 minecraft:light_gray_concrete replace
setblock ~103 ~139 ~448 minecraft:light_gray_concrete replace
setblock ~78 ~139 ~449 minecraft:light_gray_concrete replace
setblock ~97 ~139 ~452 minecraft:light_gray_concrete replace
setblock ~97 ~139 ~456 minecraft:light_gray_concrete replace
setblock ~94 ~139 ~460 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~461 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~463 minecraft:light_gray_concrete replace
setblock ~94 ~139 ~464 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~465 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~467 minecraft:light_gray_concrete replace
setblock ~94 ~139 ~468 minecraft:light_gray_concrete replace
setblock ~93 ~139 ~471 minecraft:light_gray_concrete replace
setblock ~91 ~139 ~472 minecraft:light_gray_concrete replace
setblock ~93 ~139 ~473 minecraft:light_gray_concrete replace
setblock ~91 ~139 ~476 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~477 minecraft:light_gray_concrete replace
setblock ~90 ~139 ~479 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~479 minecraft:light_gray_concrete replace
setblock ~90 ~139 ~481 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~481 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~483 minecraft:light_gray_concrete replace
setblock ~103 ~139 ~492 minecraft:light_gray_concrete replace
setblock ~97 ~139 ~496 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~501 minecraft:light_gray_concrete replace
setblock ~103 ~139 ~508 minecraft:light_gray_concrete replace
setblock ~115 ~139 ~512 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~513 minecraft:light_gray_concrete replace
setblock ~112 ~139 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~139 ~520 minecraft:light_gray_concrete replace
setblock ~109 ~139 ~524 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~525 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~527 minecraft:light_gray_concrete replace
setblock ~109 ~139 ~528 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~529 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~531 minecraft:light_gray_concrete replace
setblock ~109 ~139 ~532 minecraft:light_gray_concrete replace
setblock ~108 ~139 ~535 minecraft:light_gray_concrete replace
setblock ~106 ~139 ~536 minecraft:light_gray_concrete replace
setblock ~108 ~139 ~537 minecraft:light_gray_concrete replace
setblock ~106 ~139 ~540 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~541 minecraft:light_gray_concrete replace
setblock ~105 ~139 ~543 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~543 minecraft:light_gray_concrete replace
setblock ~105 ~139 ~545 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~545 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~547 minecraft:light_gray_concrete replace
setblock ~115 ~139 ~556 minecraft:light_gray_concrete replace
setblock ~112 ~139 ~560 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~565 minecraft:light_gray_concrete replace
setblock ~115 ~139 ~572 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~577 minecraft:light_gray_concrete replace
setblock ~121 ~139 ~604 minecraft:light_gray_concrete replace
setblock ~120 ~139 ~609 minecraft:light_gray_concrete replace
setblock ~118 ~139 ~616 minecraft:light_gray_concrete replace
setblock ~117 ~139 ~621 minecraft:light_gray_concrete replace
setblock ~129 ~139 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~139 ~649 minecraft:light_gray_concrete replace
setblock ~123 ~139 ~653 minecraft:light_gray_concrete replace
setblock ~126 ~139 ~661 minecraft:light_gray_concrete replace
fill ~99 ~140 ~386 ~113 ~140 ~386 minecraft:light_gray_concrete replace
fill ~112 ~140 ~387 ~112 ~140 ~388 minecraft:light_gray_concrete replace
fill ~81 ~140 ~398 ~83 ~140 ~398 minecraft:light_gray_concrete replace
fill ~82 ~140 ~399 ~82 ~140 ~400 minecraft:light_gray_concrete replace
fill ~87 ~140 ~446 ~116 ~140 ~446 minecraft:light_gray_concrete replace
fill ~88 ~140 ~447 ~88 ~140 ~448 minecraft:light_gray_concrete replace
fill ~91 ~140 ~447 ~91 ~140 ~448 minecraft:light_gray_concrete replace
fill ~94 ~140 ~447 ~94 ~140 ~448 minecraft:light_gray_concrete replace
fill ~97 ~140 ~447 ~97 ~140 ~448 minecraft:light_gray_concrete replace
fill ~100 ~140 ~447 ~100 ~140 ~448 minecraft:light_gray_concrete replace
fill ~103 ~140 ~447 ~103 ~140 ~448 minecraft:light_gray_concrete replace
fill ~106 ~140 ~447 ~106 ~140 ~448 minecraft:light_gray_concrete replace
fill ~115 ~140 ~447 ~115 ~140 ~448 minecraft:light_gray_concrete replace
fill ~78 ~140 ~450 ~80 ~140 ~450 minecraft:light_gray_concrete replace
fill ~79 ~140 ~451 ~79 ~140 ~452 minecraft:light_gray_concrete replace
fill ~87 ~140 ~474 ~122 ~140 ~474 minecraft:light_gray_concrete replace
fill ~88 ~140 ~475 ~88 ~140 ~476 minecraft:light_gray_concrete replace
fill ~94 ~140 ~475 ~94 ~140 ~476 minecraft:light_gray_concrete replace
fill ~97 ~140 ~475 ~97 ~140 ~476 minecraft:light_gray_concrete replace
fill ~100 ~140 ~475 ~100 ~140 ~476 minecraft:light_gray_concrete replace
fill ~106 ~140 ~475 ~106 ~140 ~476 minecraft:light_gray_concrete replace
fill ~109 ~140 ~475 ~109 ~140 ~476 minecraft:light_gray_concrete replace
fill ~121 ~140 ~475 ~121 ~140 ~476 minecraft:light_gray_concrete replace
fill ~87 ~140 ~482 ~119 ~140 ~482 minecraft:light_gray_concrete replace
fill ~88 ~140 ~483 ~88 ~140 ~484 minecraft:light_gray_concrete replace
fill ~91 ~140 ~483 ~91 ~140 ~484 minecraft:light_gray_concrete replace
fill ~97 ~140 ~483 ~97 ~140 ~484 minecraft:light_gray_concrete replace
fill ~103 ~140 ~483 ~103 ~140 ~484 minecraft:light_gray_concrete replace
fill ~109 ~140 ~483 ~109 ~140 ~484 minecraft:light_gray_concrete replace
fill ~118 ~140 ~483 ~118 ~140 ~484 minecraft:light_gray_concrete replace
fill ~90 ~140 ~502 ~122 ~140 ~502 minecraft:light_gray_concrete replace
fill ~91 ~140 ~503 ~91 ~140 ~504 minecraft:light_gray_concrete replace
fill ~94 ~140 ~503 ~94 ~140 ~504 minecraft:light_gray_concrete replace
fill ~100 ~140 ~503 ~100 ~140 ~504 minecraft:light_gray_concrete replace
fill ~106 ~140 ~503 ~106 ~140 ~504 minecraft:light_gray_concrete replace
fill ~109 ~140 ~503 ~109 ~140 ~504 minecraft:light_gray_concrete replace
fill ~115 ~140 ~503 ~115 ~140 ~504 minecraft:light_gray_concrete replace
fill ~121 ~140 ~503 ~121 ~140 ~504 minecraft:light_gray_concrete replace
fill ~102 ~140 ~514 ~149 ~140 ~514 minecraft:light_gray_concrete replace
fill ~124 ~140 ~515 ~124 ~140 ~516 minecraft:light_gray_concrete replace
fill ~127 ~140 ~515 ~127 ~140 ~516 minecraft:light_gray_concrete replace
fill ~130 ~140 ~515 ~130 ~140 ~516 minecraft:light_gray_concrete replace
fill ~133 ~140 ~515 ~133 ~140 ~516 minecraft:light_gray_concrete replace
fill ~136 ~140 ~515 ~136 ~140 ~516 minecraft:light_gray_concrete replace
fill ~139 ~140 ~515 ~139 ~140 ~516 minecraft:light_gray_concrete replace
fill ~142 ~140 ~515 ~142 ~140 ~516 minecraft:light_gray_concrete replace
fill ~148 ~140 ~515 ~148 ~140 ~516 minecraft:light_gray_concrete replace
fill ~108 ~140 ~538 ~155 ~140 ~538 minecraft:light_gray_concrete replace
fill ~124 ~140 ~539 ~124 ~140 ~540 minecraft:light_gray_concrete replace
fill ~130 ~140 ~539 ~130 ~140 ~540 minecraft:light_gray_concrete replace
fill ~133 ~140 ~539 ~133 ~140 ~540 minecraft:light_gray_concrete replace
fill ~136 ~140 ~539 ~136 ~140 ~540 minecraft:light_gray_concrete replace
fill ~142 ~140 ~539 ~142 ~140 ~540 minecraft:light_gray_concrete replace
fill ~145 ~140 ~539 ~145 ~140 ~540 minecraft:light_gray_concrete replace
fill ~154 ~140 ~539 ~154 ~140 ~540 minecraft:light_gray_concrete replace
fill ~105 ~140 ~546 ~152 ~140 ~546 minecraft:light_gray_concrete replace
fill ~124 ~140 ~547 ~124 ~140 ~548 minecraft:light_gray_concrete replace
fill ~127 ~140 ~547 ~127 ~140 ~548 minecraft:light_gray_concrete replace
fill ~133 ~140 ~547 ~133 ~140 ~548 minecraft:light_gray_concrete replace
fill ~139 ~140 ~547 ~139 ~140 ~548 minecraft:light_gray_concrete replace
fill ~145 ~140 ~547 ~145 ~140 ~548 minecraft:light_gray_concrete replace
fill ~151 ~140 ~547 ~151 ~140 ~548 minecraft:light_gray_concrete replace
fill ~111 ~140 ~566 ~155 ~140 ~566 minecraft:light_gray_concrete replace
fill ~127 ~140 ~567 ~127 ~140 ~568 minecraft:light_gray_concrete replace
fill ~130 ~140 ~567 ~130 ~140 ~568 minecraft:light_gray_concrete replace
fill ~136 ~140 ~567 ~136 ~140 ~568 minecraft:light_gray_concrete replace
fill ~142 ~140 ~567 ~142 ~140 ~568 minecraft:light_gray_concrete replace
fill ~145 ~140 ~567 ~145 ~140 ~568 minecraft:light_gray_concrete replace
fill ~148 ~140 ~567 ~148 ~140 ~568 minecraft:light_gray_concrete replace
fill ~154 ~140 ~567 ~154 ~140 ~568 minecraft:light_gray_concrete replace
fill ~114 ~140 ~578 ~173 ~140 ~578 minecraft:light_gray_concrete replace
fill ~157 ~140 ~579 ~157 ~140 ~580 minecraft:light_gray_concrete replace
fill ~160 ~140 ~579 ~160 ~140 ~580 minecraft:light_gray_concrete replace
fill ~163 ~140 ~579 ~163 ~140 ~580 minecraft:light_gray_concrete replace
fill ~166 ~140 ~579 ~166 ~140 ~580 minecraft:light_gray_concrete replace
fill ~172 ~140 ~579 ~172 ~140 ~580 minecraft:light_gray_concrete replace
fill ~120 ~140 ~610 ~176 ~140 ~610 minecraft:light_gray_concrete replace
fill ~160 ~140 ~611 ~160 ~140 ~612 minecraft:light_gray_concrete replace
fill ~163 ~140 ~611 ~163 ~140 ~612 minecraft:light_gray_concrete replace
fill ~166 ~140 ~611 ~166 ~140 ~612 minecraft:light_gray_concrete replace
fill ~169 ~140 ~611 ~169 ~140 ~612 minecraft:light_gray_concrete replace
fill ~175 ~140 ~611 ~175 ~140 ~612 minecraft:light_gray_concrete replace
