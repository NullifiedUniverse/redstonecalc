fill ~466 ~169 ~66 ~466 ~169 ~76 minecraft:redstone_wire replace
fill ~468 ~169 ~66 ~468 ~169 ~76 minecraft:redstone_wire replace
fill ~478 ~169 ~66 ~478 ~169 ~76 minecraft:redstone_wire replace
fill ~480 ~169 ~66 ~480 ~169 ~76 minecraft:redstone_wire replace
fill ~488 ~169 ~66 ~488 ~169 ~76 minecraft:redstone_wire replace
fill ~490 ~169 ~66 ~490 ~169 ~76 minecraft:redstone_wire replace
fill ~498 ~169 ~66 ~498 ~169 ~76 minecraft:redstone_wire replace
setblock ~440 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~70 ~440 ~169 ~80 minecraft:redstone_wire replace
fill ~444 ~169 ~70 ~444 ~169 ~80 minecraft:redstone_wire replace
fill ~448 ~169 ~70 ~448 ~169 ~80 minecraft:redstone_wire replace
fill ~458 ~169 ~70 ~458 ~169 ~80 minecraft:redstone_wire replace
fill ~460 ~169 ~70 ~460 ~169 ~80 minecraft:redstone_wire replace
fill ~472 ~169 ~70 ~472 ~169 ~80 minecraft:redstone_wire replace
fill ~474 ~169 ~70 ~474 ~169 ~80 minecraft:redstone_wire replace
fill ~482 ~169 ~70 ~482 ~169 ~80 minecraft:redstone_wire replace
fill ~484 ~169 ~70 ~484 ~169 ~80 minecraft:redstone_wire replace
fill ~494 ~169 ~70 ~494 ~169 ~80 minecraft:redstone_wire replace
setblock ~442 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~74 ~442 ~169 ~84 minecraft:redstone_wire replace
fill ~450 ~169 ~74 ~450 ~169 ~84 minecraft:redstone_wire replace
fill ~456 ~169 ~74 ~456 ~169 ~84 minecraft:redstone_wire replace
fill ~462 ~169 ~74 ~462 ~169 ~84 minecraft:redstone_wire replace
fill ~470 ~169 ~74 ~470 ~169 ~84 minecraft:redstone_wire replace
fill ~476 ~169 ~74 ~476 ~169 ~84 minecraft:redstone_wire replace
fill ~486 ~169 ~74 ~486 ~169 ~84 minecraft:redstone_wire replace
fill ~492 ~169 ~74 ~492 ~169 ~84 minecraft:redstone_wire replace
fill ~496 ~169 ~74 ~496 ~169 ~84 minecraft:redstone_wire replace
fill ~500 ~169 ~74 ~500 ~169 ~84 minecraft:redstone_wire replace
fill ~502 ~169 ~74 ~502 ~169 ~84 minecraft:redstone_wire replace
setblock ~446 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~78 ~446 ~169 ~88 minecraft:redstone_wire replace
fill ~452 ~169 ~78 ~452 ~169 ~88 minecraft:redstone_wire replace
fill ~454 ~169 ~78 ~454 ~169 ~88 minecraft:redstone_wire replace
fill ~464 ~169 ~78 ~464 ~169 ~88 minecraft:redstone_wire replace
fill ~466 ~169 ~78 ~466 ~169 ~88 minecraft:redstone_wire replace
fill ~468 ~169 ~78 ~468 ~169 ~88 minecraft:redstone_wire replace
fill ~478 ~169 ~78 ~478 ~169 ~88 minecraft:redstone_wire replace
fill ~480 ~169 ~78 ~480 ~169 ~88 minecraft:redstone_wire replace
fill ~488 ~169 ~78 ~488 ~169 ~88 minecraft:redstone_wire replace
fill ~490 ~169 ~78 ~490 ~169 ~88 minecraft:redstone_wire replace
fill ~498 ~169 ~78 ~498 ~169 ~88 minecraft:redstone_wire replace
setblock ~440 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~82 ~440 ~169 ~92 minecraft:redstone_wire replace
fill ~444 ~169 ~82 ~444 ~169 ~92 minecraft:redstone_wire replace
fill ~448 ~169 ~82 ~448 ~169 ~92 minecraft:redstone_wire replace
fill ~458 ~169 ~82 ~458 ~169 ~92 minecraft:redstone_wire replace
fill ~460 ~169 ~82 ~460 ~169 ~92 minecraft:redstone_wire replace
fill ~472 ~169 ~82 ~472 ~169 ~92 minecraft:redstone_wire replace
fill ~474 ~169 ~82 ~474 ~169 ~92 minecraft:redstone_wire replace
fill ~482 ~169 ~82 ~482 ~169 ~92 minecraft:redstone_wire replace
fill ~484 ~169 ~82 ~484 ~169 ~92 minecraft:redstone_wire replace
fill ~494 ~169 ~82 ~494 ~169 ~92 minecraft:redstone_wire replace
setblock ~442 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~86 ~442 ~169 ~96 minecraft:redstone_wire replace
fill ~450 ~169 ~86 ~450 ~169 ~96 minecraft:redstone_wire replace
fill ~456 ~169 ~86 ~456 ~169 ~96 minecraft:redstone_wire replace
fill ~462 ~169 ~86 ~462 ~169 ~96 minecraft:redstone_wire replace
fill ~470 ~169 ~86 ~470 ~169 ~96 minecraft:redstone_wire replace
fill ~476 ~169 ~86 ~476 ~169 ~96 minecraft:redstone_wire replace
fill ~486 ~169 ~86 ~486 ~169 ~96 minecraft:redstone_wire replace
fill ~492 ~169 ~86 ~492 ~169 ~96 minecraft:redstone_wire replace
fill ~496 ~169 ~86 ~496 ~169 ~96 minecraft:redstone_wire replace
fill ~500 ~169 ~86 ~500 ~169 ~96 minecraft:redstone_wire replace
fill ~502 ~169 ~86 ~502 ~169 ~96 minecraft:redstone_wire replace
setblock ~446 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~90 ~446 ~169 ~100 minecraft:redstone_wire replace
fill ~452 ~169 ~90 ~452 ~169 ~100 minecraft:redstone_wire replace
fill ~454 ~169 ~90 ~454 ~169 ~100 minecraft:redstone_wire replace
fill ~464 ~169 ~90 ~464 ~169 ~100 minecraft:redstone_wire replace
fill ~466 ~169 ~90 ~466 ~169 ~100 minecraft:redstone_wire replace
fill ~468 ~169 ~90 ~468 ~169 ~100 minecraft:redstone_wire replace
fill ~478 ~169 ~90 ~478 ~169 ~100 minecraft:redstone_wire replace
fill ~480 ~169 ~90 ~480 ~169 ~100 minecraft:redstone_wire replace
fill ~488 ~169 ~90 ~488 ~169 ~100 minecraft:redstone_wire replace
fill ~490 ~169 ~90 ~490 ~169 ~100 minecraft:redstone_wire replace
fill ~498 ~169 ~90 ~498 ~169 ~100 minecraft:redstone_wire replace
setblock ~440 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~94 ~440 ~169 ~104 minecraft:redstone_wire replace
fill ~444 ~169 ~94 ~444 ~169 ~104 minecraft:redstone_wire replace
fill ~448 ~169 ~94 ~448 ~169 ~104 minecraft:redstone_wire replace
fill ~458 ~169 ~94 ~458 ~169 ~104 minecraft:redstone_wire replace
fill ~460 ~169 ~94 ~460 ~169 ~104 minecraft:redstone_wire replace
fill ~472 ~169 ~94 ~472 ~169 ~104 minecraft:redstone_wire replace
fill ~474 ~169 ~94 ~474 ~169 ~104 minecraft:redstone_wire replace
fill ~482 ~169 ~94 ~482 ~169 ~104 minecraft:redstone_wire replace
fill ~484 ~169 ~94 ~484 ~169 ~104 minecraft:redstone_wire replace
fill ~494 ~169 ~94 ~494 ~169 ~104 minecraft:redstone_wire replace
setblock ~442 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~98 ~442 ~169 ~108 minecraft:redstone_wire replace
fill ~450 ~169 ~98 ~450 ~169 ~108 minecraft:redstone_wire replace
fill ~456 ~169 ~98 ~456 ~169 ~108 minecraft:redstone_wire replace
fill ~462 ~169 ~98 ~462 ~169 ~108 minecraft:redstone_wire replace
fill ~470 ~169 ~98 ~470 ~169 ~108 minecraft:redstone_wire replace
fill ~476 ~169 ~98 ~476 ~169 ~108 minecraft:redstone_wire replace
fill ~486 ~169 ~98 ~486 ~169 ~108 minecraft:redstone_wire replace
fill ~492 ~169 ~98 ~492 ~169 ~108 minecraft:redstone_wire replace
fill ~496 ~169 ~98 ~496 ~169 ~108 minecraft:redstone_wire replace
fill ~500 ~169 ~98 ~500 ~169 ~108 minecraft:redstone_wire replace
fill ~502 ~169 ~98 ~502 ~169 ~108 minecraft:redstone_wire replace
setblock ~446 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~102 ~446 ~169 ~112 minecraft:redstone_wire replace
fill ~452 ~169 ~102 ~452 ~169 ~112 minecraft:redstone_wire replace
fill ~454 ~169 ~102 ~454 ~169 ~112 minecraft:redstone_wire replace
fill ~464 ~169 ~102 ~464 ~169 ~112 minecraft:redstone_wire replace
fill ~466 ~169 ~102 ~466 ~169 ~112 minecraft:redstone_wire replace
fill ~468 ~169 ~102 ~468 ~169 ~112 minecraft:redstone_wire replace
fill ~478 ~169 ~102 ~478 ~169 ~112 minecraft:redstone_wire replace
fill ~480 ~169 ~102 ~480 ~169 ~112 minecraft:redstone_wire replace
fill ~488 ~169 ~102 ~488 ~169 ~112 minecraft:redstone_wire replace
fill ~490 ~169 ~102 ~490 ~169 ~112 minecraft:redstone_wire replace
fill ~498 ~169 ~102 ~498 ~169 ~112 minecraft:redstone_wire replace
setblock ~440 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~106 ~440 ~169 ~116 minecraft:redstone_wire replace
fill ~444 ~169 ~106 ~444 ~169 ~116 minecraft:redstone_wire replace
fill ~448 ~169 ~106 ~448 ~169 ~116 minecraft:redstone_wire replace
fill ~458 ~169 ~106 ~458 ~169 ~116 minecraft:redstone_wire replace
fill ~460 ~169 ~106 ~460 ~169 ~116 minecraft:redstone_wire replace
fill ~472 ~169 ~106 ~472 ~169 ~116 minecraft:redstone_wire replace
fill ~474 ~169 ~106 ~474 ~169 ~116 minecraft:redstone_wire replace
fill ~482 ~169 ~106 ~482 ~169 ~116 minecraft:redstone_wire replace
fill ~484 ~169 ~106 ~484 ~169 ~116 minecraft:redstone_wire replace
fill ~494 ~169 ~106 ~494 ~169 ~116 minecraft:redstone_wire replace
setblock ~442 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~110 ~442 ~169 ~120 minecraft:redstone_wire replace
fill ~450 ~169 ~110 ~450 ~169 ~120 minecraft:redstone_wire replace
fill ~456 ~169 ~110 ~456 ~169 ~120 minecraft:redstone_wire replace
fill ~462 ~169 ~110 ~462 ~169 ~120 minecraft:redstone_wire replace
fill ~470 ~169 ~110 ~470 ~169 ~120 minecraft:redstone_wire replace
fill ~476 ~169 ~110 ~476 ~169 ~120 minecraft:redstone_wire replace
fill ~486 ~169 ~110 ~486 ~169 ~120 minecraft:redstone_wire replace
fill ~492 ~169 ~110 ~492 ~169 ~120 minecraft:redstone_wire replace
fill ~496 ~169 ~110 ~496 ~169 ~120 minecraft:redstone_wire replace
fill ~500 ~169 ~110 ~500 ~169 ~120 minecraft:redstone_wire replace
fill ~502 ~169 ~110 ~502 ~169 ~120 minecraft:redstone_wire replace
setblock ~446 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~114 ~446 ~169 ~124 minecraft:redstone_wire replace
fill ~452 ~169 ~114 ~452 ~169 ~124 minecraft:redstone_wire replace
fill ~454 ~169 ~114 ~454 ~169 ~124 minecraft:redstone_wire replace
fill ~464 ~169 ~114 ~464 ~169 ~124 minecraft:redstone_wire replace
fill ~466 ~169 ~114 ~466 ~169 ~124 minecraft:redstone_wire replace
fill ~468 ~169 ~114 ~468 ~169 ~124 minecraft:redstone_wire replace
fill ~478 ~169 ~114 ~478 ~169 ~124 minecraft:redstone_wire replace
fill ~480 ~169 ~114 ~480 ~169 ~124 minecraft:redstone_wire replace
fill ~488 ~169 ~114 ~488 ~169 ~124 minecraft:redstone_wire replace
fill ~490 ~169 ~114 ~490 ~169 ~124 minecraft:redstone_wire replace
fill ~498 ~169 ~114 ~498 ~169 ~124 minecraft:redstone_wire replace
setblock ~440 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~118 ~440 ~169 ~128 minecraft:redstone_wire replace
fill ~444 ~169 ~118 ~444 ~169 ~128 minecraft:redstone_wire replace
fill ~448 ~169 ~118 ~448 ~169 ~128 minecraft:redstone_wire replace
fill ~458 ~169 ~118 ~458 ~169 ~128 minecraft:redstone_wire replace
fill ~460 ~169 ~118 ~460 ~169 ~128 minecraft:redstone_wire replace
fill ~472 ~169 ~118 ~472 ~169 ~128 minecraft:redstone_wire replace
fill ~474 ~169 ~118 ~474 ~169 ~128 minecraft:redstone_wire replace
fill ~482 ~169 ~118 ~482 ~169 ~128 minecraft:redstone_wire replace
fill ~484 ~169 ~118 ~484 ~169 ~128 minecraft:redstone_wire replace
fill ~494 ~169 ~118 ~494 ~169 ~128 minecraft:redstone_wire replace
setblock ~442 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~122 ~442 ~169 ~132 minecraft:redstone_wire replace
fill ~450 ~169 ~122 ~450 ~169 ~132 minecraft:redstone_wire replace
fill ~456 ~169 ~122 ~456 ~169 ~132 minecraft:redstone_wire replace
fill ~462 ~169 ~122 ~462 ~169 ~132 minecraft:redstone_wire replace
fill ~470 ~169 ~122 ~470 ~169 ~132 minecraft:redstone_wire replace
fill ~476 ~169 ~122 ~476 ~169 ~132 minecraft:redstone_wire replace
fill ~486 ~169 ~122 ~486 ~169 ~132 minecraft:redstone_wire replace
fill ~492 ~169 ~122 ~492 ~169 ~132 minecraft:redstone_wire replace
fill ~496 ~169 ~122 ~496 ~169 ~132 minecraft:redstone_wire replace
fill ~500 ~169 ~122 ~500 ~169 ~132 minecraft:redstone_wire replace
fill ~502 ~169 ~122 ~502 ~169 ~132 minecraft:redstone_wire replace
setblock ~446 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~126 ~446 ~169 ~136 minecraft:redstone_wire replace
fill ~452 ~169 ~126 ~452 ~169 ~136 minecraft:redstone_wire replace
fill ~454 ~169 ~126 ~454 ~169 ~136 minecraft:redstone_wire replace
fill ~464 ~169 ~126 ~464 ~169 ~136 minecraft:redstone_wire replace
fill ~466 ~169 ~126 ~466 ~169 ~136 minecraft:redstone_wire replace
fill ~468 ~169 ~126 ~468 ~169 ~136 minecraft:redstone_wire replace
fill ~478 ~169 ~126 ~478 ~169 ~136 minecraft:redstone_wire replace
fill ~480 ~169 ~126 ~480 ~169 ~136 minecraft:redstone_wire replace
fill ~488 ~169 ~126 ~488 ~169 ~136 minecraft:redstone_wire replace
fill ~490 ~169 ~126 ~490 ~169 ~136 minecraft:redstone_wire replace
fill ~498 ~169 ~126 ~498 ~169 ~136 minecraft:redstone_wire replace
setblock ~440 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~130 ~440 ~169 ~140 minecraft:redstone_wire replace
fill ~444 ~169 ~130 ~444 ~169 ~140 minecraft:redstone_wire replace
fill ~448 ~169 ~130 ~448 ~169 ~140 minecraft:redstone_wire replace
fill ~458 ~169 ~130 ~458 ~169 ~140 minecraft:redstone_wire replace
fill ~460 ~169 ~130 ~460 ~169 ~140 minecraft:redstone_wire replace
fill ~472 ~169 ~130 ~472 ~169 ~140 minecraft:redstone_wire replace
fill ~474 ~169 ~130 ~474 ~169 ~140 minecraft:redstone_wire replace
fill ~482 ~169 ~130 ~482 ~169 ~140 minecraft:redstone_wire replace
fill ~484 ~169 ~130 ~484 ~169 ~140 minecraft:redstone_wire replace
fill ~494 ~169 ~130 ~494 ~169 ~140 minecraft:redstone_wire replace
setblock ~442 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~134 ~442 ~169 ~144 minecraft:redstone_wire replace
fill ~450 ~169 ~134 ~450 ~169 ~144 minecraft:redstone_wire replace
fill ~456 ~169 ~134 ~456 ~169 ~144 minecraft:redstone_wire replace
fill ~462 ~169 ~134 ~462 ~169 ~144 minecraft:redstone_wire replace
fill ~470 ~169 ~134 ~470 ~169 ~144 minecraft:redstone_wire replace
fill ~476 ~169 ~134 ~476 ~169 ~144 minecraft:redstone_wire replace
fill ~486 ~169 ~134 ~486 ~169 ~144 minecraft:redstone_wire replace
fill ~492 ~169 ~134 ~492 ~169 ~144 minecraft:redstone_wire replace
fill ~496 ~169 ~134 ~496 ~169 ~144 minecraft:redstone_wire replace
fill ~500 ~169 ~134 ~500 ~169 ~144 minecraft:redstone_wire replace
fill ~502 ~169 ~134 ~502 ~169 ~144 minecraft:redstone_wire replace
setblock ~446 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~138 ~446 ~169 ~148 minecraft:redstone_wire replace
fill ~452 ~169 ~138 ~452 ~169 ~148 minecraft:redstone_wire replace
fill ~454 ~169 ~138 ~454 ~169 ~148 minecraft:redstone_wire replace
fill ~464 ~169 ~138 ~464 ~169 ~148 minecraft:redstone_wire replace
fill ~466 ~169 ~138 ~466 ~169 ~148 minecraft:redstone_wire replace
fill ~468 ~169 ~138 ~468 ~169 ~148 minecraft:redstone_wire replace
fill ~478 ~169 ~138 ~478 ~169 ~148 minecraft:redstone_wire replace
fill ~480 ~169 ~138 ~480 ~169 ~148 minecraft:redstone_wire replace
fill ~488 ~169 ~138 ~488 ~169 ~148 minecraft:redstone_wire replace
fill ~490 ~169 ~138 ~490 ~169 ~148 minecraft:redstone_wire replace
fill ~498 ~169 ~138 ~498 ~169 ~148 minecraft:redstone_wire replace
setblock ~440 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~142 ~440 ~169 ~152 minecraft:redstone_wire replace
fill ~444 ~169 ~142 ~444 ~169 ~152 minecraft:redstone_wire replace
fill ~448 ~169 ~142 ~448 ~169 ~152 minecraft:redstone_wire replace
fill ~458 ~169 ~142 ~458 ~169 ~152 minecraft:redstone_wire replace
fill ~460 ~169 ~142 ~460 ~169 ~152 minecraft:redstone_wire replace
fill ~472 ~169 ~142 ~472 ~169 ~152 minecraft:redstone_wire replace
fill ~474 ~169 ~142 ~474 ~169 ~152 minecraft:redstone_wire replace
fill ~482 ~169 ~142 ~482 ~169 ~152 minecraft:redstone_wire replace
fill ~484 ~169 ~142 ~484 ~169 ~152 minecraft:redstone_wire replace
fill ~494 ~169 ~142 ~494 ~169 ~152 minecraft:redstone_wire replace
setblock ~442 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~145 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~146 ~442 ~169 ~156 minecraft:redstone_wire replace
fill ~450 ~169 ~146 ~450 ~169 ~156 minecraft:redstone_wire replace
fill ~456 ~169 ~146 ~456 ~169 ~156 minecraft:redstone_wire replace
fill ~462 ~169 ~146 ~462 ~169 ~156 minecraft:redstone_wire replace
fill ~470 ~169 ~146 ~470 ~169 ~156 minecraft:redstone_wire replace
fill ~476 ~169 ~146 ~476 ~169 ~156 minecraft:redstone_wire replace
fill ~486 ~169 ~146 ~486 ~169 ~156 minecraft:redstone_wire replace
fill ~492 ~169 ~146 ~492 ~169 ~156 minecraft:redstone_wire replace
fill ~496 ~169 ~146 ~496 ~169 ~156 minecraft:redstone_wire replace
fill ~500 ~169 ~146 ~500 ~169 ~156 minecraft:redstone_wire replace
fill ~502 ~169 ~146 ~502 ~169 ~156 minecraft:redstone_wire replace
setblock ~446 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~149 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~150 ~446 ~169 ~160 minecraft:redstone_wire replace
fill ~452 ~169 ~150 ~452 ~169 ~160 minecraft:redstone_wire replace
fill ~454 ~169 ~150 ~454 ~169 ~160 minecraft:redstone_wire replace
fill ~464 ~169 ~150 ~464 ~169 ~160 minecraft:redstone_wire replace
fill ~466 ~169 ~150 ~466 ~169 ~160 minecraft:redstone_wire replace
fill ~468 ~169 ~150 ~468 ~169 ~160 minecraft:redstone_wire replace
fill ~478 ~169 ~150 ~478 ~169 ~160 minecraft:redstone_wire replace
fill ~480 ~169 ~150 ~480 ~169 ~160 minecraft:redstone_wire replace
fill ~488 ~169 ~150 ~488 ~169 ~160 minecraft:redstone_wire replace
fill ~490 ~169 ~150 ~490 ~169 ~160 minecraft:redstone_wire replace
fill ~498 ~169 ~150 ~498 ~169 ~160 minecraft:redstone_wire replace
setblock ~440 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~153 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~154 ~440 ~169 ~164 minecraft:redstone_wire replace
fill ~444 ~169 ~154 ~444 ~169 ~164 minecraft:redstone_wire replace
fill ~448 ~169 ~154 ~448 ~169 ~164 minecraft:redstone_wire replace
fill ~458 ~169 ~154 ~458 ~169 ~164 minecraft:redstone_wire replace
fill ~460 ~169 ~154 ~460 ~169 ~164 minecraft:redstone_wire replace
fill ~472 ~169 ~154 ~472 ~169 ~164 minecraft:redstone_wire replace
fill ~474 ~169 ~154 ~474 ~169 ~164 minecraft:redstone_wire replace
fill ~482 ~169 ~154 ~482 ~169 ~164 minecraft:redstone_wire replace
fill ~484 ~169 ~154 ~484 ~169 ~164 minecraft:redstone_wire replace
fill ~494 ~169 ~154 ~494 ~169 ~164 minecraft:redstone_wire replace
setblock ~442 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~157 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~158 ~442 ~169 ~168 minecraft:redstone_wire replace
fill ~450 ~169 ~158 ~450 ~169 ~168 minecraft:redstone_wire replace
fill ~456 ~169 ~158 ~456 ~169 ~168 minecraft:redstone_wire replace
fill ~462 ~169 ~158 ~462 ~169 ~168 minecraft:redstone_wire replace
fill ~470 ~169 ~158 ~470 ~169 ~168 minecraft:redstone_wire replace
fill ~476 ~169 ~158 ~476 ~169 ~168 minecraft:redstone_wire replace
fill ~486 ~169 ~158 ~486 ~169 ~168 minecraft:redstone_wire replace
fill ~492 ~169 ~158 ~492 ~169 ~168 minecraft:redstone_wire replace
fill ~496 ~169 ~158 ~496 ~169 ~168 minecraft:redstone_wire replace
fill ~500 ~169 ~158 ~500 ~169 ~168 minecraft:redstone_wire replace
fill ~502 ~169 ~158 ~502 ~169 ~168 minecraft:redstone_wire replace
setblock ~446 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~161 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~162 ~446 ~169 ~172 minecraft:redstone_wire replace
fill ~452 ~169 ~162 ~452 ~169 ~172 minecraft:redstone_wire replace
fill ~454 ~169 ~162 ~454 ~169 ~172 minecraft:redstone_wire replace
fill ~464 ~169 ~162 ~464 ~169 ~172 minecraft:redstone_wire replace
fill ~466 ~169 ~162 ~466 ~169 ~172 minecraft:redstone_wire replace
fill ~468 ~169 ~162 ~468 ~169 ~172 minecraft:redstone_wire replace
fill ~478 ~169 ~162 ~478 ~169 ~172 minecraft:redstone_wire replace
fill ~480 ~169 ~162 ~480 ~169 ~172 minecraft:redstone_wire replace
fill ~488 ~169 ~162 ~488 ~169 ~172 minecraft:redstone_wire replace
fill ~490 ~169 ~162 ~490 ~169 ~172 minecraft:redstone_wire replace
fill ~498 ~169 ~162 ~498 ~169 ~172 minecraft:redstone_wire replace
setblock ~440 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~165 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~166 ~440 ~169 ~176 minecraft:redstone_wire replace
fill ~444 ~169 ~166 ~444 ~169 ~176 minecraft:redstone_wire replace
fill ~448 ~169 ~166 ~448 ~169 ~176 minecraft:redstone_wire replace
fill ~458 ~169 ~166 ~458 ~169 ~176 minecraft:redstone_wire replace
fill ~460 ~169 ~166 ~460 ~169 ~176 minecraft:redstone_wire replace
fill ~472 ~169 ~166 ~472 ~169 ~176 minecraft:redstone_wire replace
fill ~474 ~169 ~166 ~474 ~169 ~176 minecraft:redstone_wire replace
fill ~482 ~169 ~166 ~482 ~169 ~176 minecraft:redstone_wire replace
fill ~484 ~169 ~166 ~484 ~169 ~176 minecraft:redstone_wire replace
fill ~494 ~169 ~166 ~494 ~169 ~176 minecraft:redstone_wire replace
setblock ~442 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~169 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~170 ~442 ~169 ~180 minecraft:redstone_wire replace
fill ~450 ~169 ~170 ~450 ~169 ~180 minecraft:redstone_wire replace
fill ~456 ~169 ~170 ~456 ~169 ~180 minecraft:redstone_wire replace
fill ~462 ~169 ~170 ~462 ~169 ~180 minecraft:redstone_wire replace
fill ~470 ~169 ~170 ~470 ~169 ~180 minecraft:redstone_wire replace
fill ~476 ~169 ~170 ~476 ~169 ~180 minecraft:redstone_wire replace
fill ~486 ~169 ~170 ~486 ~169 ~180 minecraft:redstone_wire replace
fill ~492 ~169 ~170 ~492 ~169 ~180 minecraft:redstone_wire replace
fill ~496 ~169 ~170 ~496 ~169 ~180 minecraft:redstone_wire replace
fill ~500 ~169 ~170 ~500 ~169 ~180 minecraft:redstone_wire replace
fill ~502 ~169 ~170 ~502 ~169 ~180 minecraft:redstone_wire replace
setblock ~446 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~173 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~174 ~446 ~169 ~184 minecraft:redstone_wire replace
fill ~452 ~169 ~174 ~452 ~169 ~184 minecraft:redstone_wire replace
fill ~454 ~169 ~174 ~454 ~169 ~184 minecraft:redstone_wire replace
fill ~464 ~169 ~174 ~464 ~169 ~184 minecraft:redstone_wire replace
fill ~466 ~169 ~174 ~466 ~169 ~184 minecraft:redstone_wire replace
fill ~468 ~169 ~174 ~468 ~169 ~184 minecraft:redstone_wire replace
fill ~478 ~169 ~174 ~478 ~169 ~184 minecraft:redstone_wire replace
fill ~480 ~169 ~174 ~480 ~169 ~184 minecraft:redstone_wire replace
fill ~488 ~169 ~174 ~488 ~169 ~184 minecraft:redstone_wire replace
fill ~490 ~169 ~174 ~490 ~169 ~184 minecraft:redstone_wire replace
fill ~498 ~169 ~174 ~498 ~169 ~184 minecraft:redstone_wire replace
setblock ~440 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~177 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~178 ~440 ~169 ~188 minecraft:redstone_wire replace
fill ~444 ~169 ~178 ~444 ~169 ~188 minecraft:redstone_wire replace
fill ~448 ~169 ~178 ~448 ~169 ~188 minecraft:redstone_wire replace
fill ~458 ~169 ~178 ~458 ~169 ~188 minecraft:redstone_wire replace
fill ~460 ~169 ~178 ~460 ~169 ~188 minecraft:redstone_wire replace
fill ~472 ~169 ~178 ~472 ~169 ~188 minecraft:redstone_wire replace
fill ~474 ~169 ~178 ~474 ~169 ~188 minecraft:redstone_wire replace
fill ~482 ~169 ~178 ~482 ~169 ~188 minecraft:redstone_wire replace
fill ~484 ~169 ~178 ~484 ~169 ~188 minecraft:redstone_wire replace
fill ~494 ~169 ~178 ~494 ~169 ~188 minecraft:redstone_wire replace
setblock ~442 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~181 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~182 ~442 ~169 ~192 minecraft:redstone_wire replace
fill ~450 ~169 ~182 ~450 ~169 ~192 minecraft:redstone_wire replace
fill ~456 ~169 ~182 ~456 ~169 ~192 minecraft:redstone_wire replace
fill ~462 ~169 ~182 ~462 ~169 ~192 minecraft:redstone_wire replace
fill ~470 ~169 ~182 ~470 ~169 ~192 minecraft:redstone_wire replace
fill ~476 ~169 ~182 ~476 ~169 ~192 minecraft:redstone_wire replace
fill ~486 ~169 ~182 ~486 ~169 ~192 minecraft:redstone_wire replace
fill ~492 ~169 ~182 ~492 ~169 ~192 minecraft:redstone_wire replace
fill ~496 ~169 ~182 ~496 ~169 ~192 minecraft:redstone_wire replace
fill ~500 ~169 ~182 ~500 ~169 ~192 minecraft:redstone_wire replace
fill ~502 ~169 ~182 ~502 ~169 ~192 minecraft:redstone_wire replace
setblock ~446 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~185 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~186 ~446 ~169 ~196 minecraft:redstone_wire replace
fill ~452 ~169 ~186 ~452 ~169 ~196 minecraft:redstone_wire replace
fill ~454 ~169 ~186 ~454 ~169 ~196 minecraft:redstone_wire replace
fill ~464 ~169 ~186 ~464 ~169 ~196 minecraft:redstone_wire replace
fill ~466 ~169 ~186 ~466 ~169 ~196 minecraft:redstone_wire replace
fill ~468 ~169 ~186 ~468 ~169 ~196 minecraft:redstone_wire replace
fill ~478 ~169 ~186 ~478 ~169 ~196 minecraft:redstone_wire replace
fill ~480 ~169 ~186 ~480 ~169 ~196 minecraft:redstone_wire replace
fill ~488 ~169 ~186 ~488 ~169 ~196 minecraft:redstone_wire replace
fill ~490 ~169 ~186 ~490 ~169 ~196 minecraft:redstone_wire replace
fill ~498 ~169 ~186 ~498 ~169 ~196 minecraft:redstone_wire replace
setblock ~440 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~189 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~190 ~440 ~169 ~200 minecraft:redstone_wire replace
fill ~444 ~169 ~190 ~444 ~169 ~200 minecraft:redstone_wire replace
fill ~448 ~169 ~190 ~448 ~169 ~200 minecraft:redstone_wire replace
fill ~458 ~169 ~190 ~458 ~169 ~200 minecraft:redstone_wire replace
fill ~460 ~169 ~190 ~460 ~169 ~200 minecraft:redstone_wire replace
fill ~472 ~169 ~190 ~472 ~169 ~200 minecraft:redstone_wire replace
fill ~474 ~169 ~190 ~474 ~169 ~200 minecraft:redstone_wire replace
fill ~482 ~169 ~190 ~482 ~169 ~200 minecraft:redstone_wire replace
fill ~484 ~169 ~190 ~484 ~169 ~200 minecraft:redstone_wire replace
fill ~494 ~169 ~190 ~494 ~169 ~200 minecraft:redstone_wire replace
setblock ~442 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~193 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~194 ~442 ~169 ~204 minecraft:redstone_wire replace
fill ~450 ~169 ~194 ~450 ~169 ~204 minecraft:redstone_wire replace
fill ~456 ~169 ~194 ~456 ~169 ~204 minecraft:redstone_wire replace
fill ~462 ~169 ~194 ~462 ~169 ~204 minecraft:redstone_wire replace
fill ~470 ~169 ~194 ~470 ~169 ~204 minecraft:redstone_wire replace
fill ~476 ~169 ~194 ~476 ~169 ~204 minecraft:redstone_wire replace
fill ~486 ~169 ~194 ~486 ~169 ~204 minecraft:redstone_wire replace
fill ~492 ~169 ~194 ~492 ~169 ~204 minecraft:redstone_wire replace
fill ~496 ~169 ~194 ~496 ~169 ~204 minecraft:redstone_wire replace
fill ~500 ~169 ~194 ~500 ~169 ~204 minecraft:redstone_wire replace
fill ~502 ~169 ~194 ~502 ~169 ~204 minecraft:redstone_wire replace
setblock ~446 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~197 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~198 ~446 ~169 ~208 minecraft:redstone_wire replace
fill ~452 ~169 ~198 ~452 ~169 ~208 minecraft:redstone_wire replace
fill ~454 ~169 ~198 ~454 ~169 ~208 minecraft:redstone_wire replace
fill ~464 ~169 ~198 ~464 ~169 ~208 minecraft:redstone_wire replace
fill ~466 ~169 ~198 ~466 ~169 ~208 minecraft:redstone_wire replace
fill ~468 ~169 ~198 ~468 ~169 ~208 minecraft:redstone_wire replace
fill ~478 ~169 ~198 ~478 ~169 ~208 minecraft:redstone_wire replace
fill ~480 ~169 ~198 ~480 ~169 ~208 minecraft:redstone_wire replace
fill ~488 ~169 ~198 ~488 ~169 ~208 minecraft:redstone_wire replace
fill ~490 ~169 ~198 ~490 ~169 ~208 minecraft:redstone_wire replace
fill ~498 ~169 ~198 ~498 ~169 ~208 minecraft:redstone_wire replace
setblock ~440 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~201 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~202 ~440 ~169 ~212 minecraft:redstone_wire replace
fill ~444 ~169 ~202 ~444 ~169 ~212 minecraft:redstone_wire replace
fill ~448 ~169 ~202 ~448 ~169 ~212 minecraft:redstone_wire replace
fill ~458 ~169 ~202 ~458 ~169 ~212 minecraft:redstone_wire replace
fill ~460 ~169 ~202 ~460 ~169 ~212 minecraft:redstone_wire replace
fill ~472 ~169 ~202 ~472 ~169 ~212 minecraft:redstone_wire replace
fill ~474 ~169 ~202 ~474 ~169 ~212 minecraft:redstone_wire replace
fill ~482 ~169 ~202 ~482 ~169 ~212 minecraft:redstone_wire replace
fill ~484 ~169 ~202 ~484 ~169 ~212 minecraft:redstone_wire replace
fill ~494 ~169 ~202 ~494 ~169 ~212 minecraft:redstone_wire replace
setblock ~442 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~205 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~206 ~442 ~169 ~216 minecraft:redstone_wire replace
fill ~450 ~169 ~206 ~450 ~169 ~216 minecraft:redstone_wire replace
fill ~456 ~169 ~206 ~456 ~169 ~216 minecraft:redstone_wire replace
fill ~462 ~169 ~206 ~462 ~169 ~216 minecraft:redstone_wire replace
fill ~470 ~169 ~206 ~470 ~169 ~216 minecraft:redstone_wire replace
fill ~476 ~169 ~206 ~476 ~169 ~216 minecraft:redstone_wire replace
fill ~486 ~169 ~206 ~486 ~169 ~216 minecraft:redstone_wire replace
fill ~492 ~169 ~206 ~492 ~169 ~216 minecraft:redstone_wire replace
fill ~496 ~169 ~206 ~496 ~169 ~216 minecraft:redstone_wire replace
fill ~500 ~169 ~206 ~500 ~169 ~216 minecraft:redstone_wire replace
fill ~502 ~169 ~206 ~502 ~169 ~216 minecraft:redstone_wire replace
setblock ~446 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~209 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~210 ~446 ~169 ~220 minecraft:redstone_wire replace
fill ~452 ~169 ~210 ~452 ~169 ~220 minecraft:redstone_wire replace
fill ~454 ~169 ~210 ~454 ~169 ~220 minecraft:redstone_wire replace
fill ~464 ~169 ~210 ~464 ~169 ~220 minecraft:redstone_wire replace
fill ~466 ~169 ~210 ~466 ~169 ~220 minecraft:redstone_wire replace
fill ~468 ~169 ~210 ~468 ~169 ~220 minecraft:redstone_wire replace
fill ~478 ~169 ~210 ~478 ~169 ~220 minecraft:redstone_wire replace
fill ~480 ~169 ~210 ~480 ~169 ~220 minecraft:redstone_wire replace
fill ~488 ~169 ~210 ~488 ~169 ~220 minecraft:redstone_wire replace
fill ~490 ~169 ~210 ~490 ~169 ~220 minecraft:redstone_wire replace
fill ~498 ~169 ~210 ~498 ~169 ~220 minecraft:redstone_wire replace
setblock ~440 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~213 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~214 ~440 ~169 ~224 minecraft:redstone_wire replace
fill ~444 ~169 ~214 ~444 ~169 ~224 minecraft:redstone_wire replace
fill ~448 ~169 ~214 ~448 ~169 ~224 minecraft:redstone_wire replace
fill ~458 ~169 ~214 ~458 ~169 ~224 minecraft:redstone_wire replace
fill ~460 ~169 ~214 ~460 ~169 ~224 minecraft:redstone_wire replace
fill ~472 ~169 ~214 ~472 ~169 ~224 minecraft:redstone_wire replace
fill ~474 ~169 ~214 ~474 ~169 ~224 minecraft:redstone_wire replace
fill ~482 ~169 ~214 ~482 ~169 ~224 minecraft:redstone_wire replace
fill ~484 ~169 ~214 ~484 ~169 ~224 minecraft:redstone_wire replace
fill ~494 ~169 ~214 ~494 ~169 ~224 minecraft:redstone_wire replace
setblock ~442 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~217 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~218 ~442 ~169 ~228 minecraft:redstone_wire replace
fill ~450 ~169 ~218 ~450 ~169 ~228 minecraft:redstone_wire replace
fill ~456 ~169 ~218 ~456 ~169 ~228 minecraft:redstone_wire replace
fill ~462 ~169 ~218 ~462 ~169 ~228 minecraft:redstone_wire replace
fill ~470 ~169 ~218 ~470 ~169 ~228 minecraft:redstone_wire replace
fill ~476 ~169 ~218 ~476 ~169 ~228 minecraft:redstone_wire replace
fill ~486 ~169 ~218 ~486 ~169 ~228 minecraft:redstone_wire replace
fill ~492 ~169 ~218 ~492 ~169 ~228 minecraft:redstone_wire replace
fill ~496 ~169 ~218 ~496 ~169 ~228 minecraft:redstone_wire replace
fill ~500 ~169 ~218 ~500 ~169 ~228 minecraft:redstone_wire replace
fill ~502 ~169 ~218 ~502 ~169 ~228 minecraft:redstone_wire replace
setblock ~446 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~221 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~222 ~446 ~169 ~232 minecraft:redstone_wire replace
fill ~452 ~169 ~222 ~452 ~169 ~232 minecraft:redstone_wire replace
fill ~454 ~169 ~222 ~454 ~169 ~232 minecraft:redstone_wire replace
fill ~464 ~169 ~222 ~464 ~169 ~232 minecraft:redstone_wire replace
fill ~466 ~169 ~222 ~466 ~169 ~232 minecraft:redstone_wire replace
fill ~468 ~169 ~222 ~468 ~169 ~232 minecraft:redstone_wire replace
fill ~478 ~169 ~222 ~478 ~169 ~232 minecraft:redstone_wire replace
fill ~480 ~169 ~222 ~480 ~169 ~232 minecraft:redstone_wire replace
fill ~488 ~169 ~222 ~488 ~169 ~232 minecraft:redstone_wire replace
fill ~490 ~169 ~222 ~490 ~169 ~232 minecraft:redstone_wire replace
fill ~498 ~169 ~222 ~498 ~169 ~232 minecraft:redstone_wire replace
setblock ~440 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~225 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~226 ~440 ~169 ~236 minecraft:redstone_wire replace
fill ~444 ~169 ~226 ~444 ~169 ~236 minecraft:redstone_wire replace
fill ~448 ~169 ~226 ~448 ~169 ~236 minecraft:redstone_wire replace
fill ~458 ~169 ~226 ~458 ~169 ~236 minecraft:redstone_wire replace
fill ~460 ~169 ~226 ~460 ~169 ~236 minecraft:redstone_wire replace
fill ~472 ~169 ~226 ~472 ~169 ~236 minecraft:redstone_wire replace
fill ~474 ~169 ~226 ~474 ~169 ~236 minecraft:redstone_wire replace
fill ~482 ~169 ~226 ~482 ~169 ~236 minecraft:redstone_wire replace
fill ~484 ~169 ~226 ~484 ~169 ~236 minecraft:redstone_wire replace
fill ~494 ~169 ~226 ~494 ~169 ~236 minecraft:redstone_wire replace
setblock ~442 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~229 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~230 ~442 ~169 ~240 minecraft:redstone_wire replace
fill ~450 ~169 ~230 ~450 ~169 ~240 minecraft:redstone_wire replace
fill ~456 ~169 ~230 ~456 ~169 ~240 minecraft:redstone_wire replace
fill ~462 ~169 ~230 ~462 ~169 ~240 minecraft:redstone_wire replace
fill ~470 ~169 ~230 ~470 ~169 ~240 minecraft:redstone_wire replace
fill ~476 ~169 ~230 ~476 ~169 ~240 minecraft:redstone_wire replace
fill ~486 ~169 ~230 ~486 ~169 ~240 minecraft:redstone_wire replace
fill ~492 ~169 ~230 ~492 ~169 ~240 minecraft:redstone_wire replace
fill ~500 ~169 ~230 ~500 ~169 ~240 minecraft:redstone_wire replace
fill ~502 ~169 ~230 ~502 ~169 ~240 minecraft:redstone_wire replace
setblock ~446 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~233 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~234 ~446 ~169 ~244 minecraft:redstone_wire replace
fill ~452 ~169 ~234 ~452 ~169 ~244 minecraft:redstone_wire replace
fill ~454 ~169 ~234 ~454 ~169 ~244 minecraft:redstone_wire replace
fill ~464 ~169 ~234 ~464 ~169 ~244 minecraft:redstone_wire replace
fill ~466 ~169 ~234 ~466 ~169 ~244 minecraft:redstone_wire replace
fill ~468 ~169 ~234 ~468 ~169 ~244 minecraft:redstone_wire replace
fill ~478 ~169 ~234 ~478 ~169 ~244 minecraft:redstone_wire replace
fill ~480 ~169 ~234 ~480 ~169 ~244 minecraft:redstone_wire replace
fill ~488 ~169 ~234 ~488 ~169 ~244 minecraft:redstone_wire replace
fill ~490 ~169 ~234 ~490 ~169 ~244 minecraft:redstone_wire replace
setblock ~440 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~237 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~238 ~440 ~169 ~248 minecraft:redstone_wire replace
fill ~444 ~169 ~238 ~444 ~169 ~248 minecraft:redstone_wire replace
fill ~448 ~169 ~238 ~448 ~169 ~248 minecraft:redstone_wire replace
fill ~458 ~169 ~238 ~458 ~169 ~248 minecraft:redstone_wire replace
fill ~460 ~169 ~238 ~460 ~169 ~248 minecraft:redstone_wire replace
fill ~472 ~169 ~238 ~472 ~169 ~248 minecraft:redstone_wire replace
fill ~474 ~169 ~238 ~474 ~169 ~248 minecraft:redstone_wire replace
fill ~482 ~169 ~238 ~482 ~169 ~248 minecraft:redstone_wire replace
fill ~484 ~169 ~238 ~484 ~169 ~248 minecraft:redstone_wire replace
fill ~494 ~169 ~238 ~494 ~169 ~248 minecraft:redstone_wire replace
setblock ~442 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~241 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~242 ~442 ~169 ~252 minecraft:redstone_wire replace
fill ~450 ~169 ~242 ~450 ~169 ~252 minecraft:redstone_wire replace
fill ~456 ~169 ~242 ~456 ~169 ~252 minecraft:redstone_wire replace
fill ~462 ~169 ~242 ~462 ~169 ~252 minecraft:redstone_wire replace
fill ~470 ~169 ~242 ~470 ~169 ~252 minecraft:redstone_wire replace
fill ~476 ~169 ~242 ~476 ~169 ~252 minecraft:redstone_wire replace
fill ~486 ~169 ~242 ~486 ~169 ~252 minecraft:redstone_wire replace
fill ~492 ~169 ~242 ~492 ~169 ~252 minecraft:redstone_wire replace
fill ~500 ~169 ~242 ~500 ~169 ~252 minecraft:redstone_wire replace
fill ~502 ~169 ~242 ~502 ~169 ~252 minecraft:redstone_wire replace
setblock ~446 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~245 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~246 ~446 ~169 ~256 minecraft:redstone_wire replace
fill ~452 ~169 ~246 ~452 ~169 ~256 minecraft:redstone_wire replace
fill ~454 ~169 ~246 ~454 ~169 ~256 minecraft:redstone_wire replace
fill ~464 ~169 ~246 ~464 ~169 ~256 minecraft:redstone_wire replace
fill ~466 ~169 ~246 ~466 ~169 ~256 minecraft:redstone_wire replace
fill ~468 ~169 ~246 ~468 ~169 ~256 minecraft:redstone_wire replace
fill ~478 ~169 ~246 ~478 ~169 ~256 minecraft:redstone_wire replace
fill ~480 ~169 ~246 ~480 ~169 ~256 minecraft:redstone_wire replace
fill ~488 ~169 ~246 ~488 ~169 ~256 minecraft:redstone_wire replace
fill ~490 ~169 ~246 ~490 ~169 ~256 minecraft:redstone_wire replace
setblock ~440 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~249 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~250 ~440 ~169 ~260 minecraft:redstone_wire replace
fill ~444 ~169 ~250 ~444 ~169 ~260 minecraft:redstone_wire replace
fill ~448 ~169 ~250 ~448 ~169 ~260 minecraft:redstone_wire replace
fill ~458 ~169 ~250 ~458 ~169 ~260 minecraft:redstone_wire replace
fill ~460 ~169 ~250 ~460 ~169 ~260 minecraft:redstone_wire replace
fill ~472 ~169 ~250 ~472 ~169 ~260 minecraft:redstone_wire replace
fill ~474 ~169 ~250 ~474 ~169 ~260 minecraft:redstone_wire replace
fill ~482 ~169 ~250 ~482 ~169 ~260 minecraft:redstone_wire replace
fill ~484 ~169 ~250 ~484 ~169 ~260 minecraft:redstone_wire replace
fill ~494 ~169 ~250 ~494 ~169 ~260 minecraft:redstone_wire replace
setblock ~442 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~253 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~254 ~442 ~169 ~264 minecraft:redstone_wire replace
fill ~450 ~169 ~254 ~450 ~169 ~264 minecraft:redstone_wire replace
fill ~456 ~169 ~254 ~456 ~169 ~264 minecraft:redstone_wire replace
fill ~462 ~169 ~254 ~462 ~169 ~264 minecraft:redstone_wire replace
fill ~470 ~169 ~254 ~470 ~169 ~264 minecraft:redstone_wire replace
fill ~476 ~169 ~254 ~476 ~169 ~264 minecraft:redstone_wire replace
fill ~486 ~169 ~254 ~486 ~169 ~264 minecraft:redstone_wire replace
fill ~492 ~169 ~254 ~492 ~169 ~264 minecraft:redstone_wire replace
fill ~500 ~169 ~254 ~500 ~169 ~264 minecraft:redstone_wire replace
fill ~502 ~169 ~254 ~502 ~169 ~264 minecraft:redstone_wire replace
setblock ~446 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~257 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~258 ~446 ~169 ~268 minecraft:redstone_wire replace
fill ~452 ~169 ~258 ~452 ~169 ~268 minecraft:redstone_wire replace
fill ~454 ~169 ~258 ~454 ~169 ~268 minecraft:redstone_wire replace
fill ~464 ~169 ~258 ~464 ~169 ~268 minecraft:redstone_wire replace
fill ~466 ~169 ~258 ~466 ~169 ~268 minecraft:redstone_wire replace
fill ~468 ~169 ~258 ~468 ~169 ~268 minecraft:redstone_wire replace
fill ~478 ~169 ~258 ~478 ~169 ~268 minecraft:redstone_wire replace
fill ~480 ~169 ~258 ~480 ~169 ~268 minecraft:redstone_wire replace
fill ~488 ~169 ~258 ~488 ~169 ~268 minecraft:redstone_wire replace
fill ~490 ~169 ~258 ~490 ~169 ~268 minecraft:redstone_wire replace
setblock ~440 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~261 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~262 ~440 ~169 ~272 minecraft:redstone_wire replace
fill ~444 ~169 ~262 ~444 ~169 ~272 minecraft:redstone_wire replace
fill ~448 ~169 ~262 ~448 ~169 ~272 minecraft:redstone_wire replace
fill ~458 ~169 ~262 ~458 ~169 ~272 minecraft:redstone_wire replace
fill ~460 ~169 ~262 ~460 ~169 ~272 minecraft:redstone_wire replace
fill ~472 ~169 ~262 ~472 ~169 ~272 minecraft:redstone_wire replace
fill ~474 ~169 ~262 ~474 ~169 ~272 minecraft:redstone_wire replace
fill ~484 ~169 ~262 ~484 ~169 ~272 minecraft:redstone_wire replace
fill ~494 ~169 ~262 ~494 ~169 ~272 minecraft:redstone_wire replace
setblock ~442 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~265 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~266 ~442 ~169 ~276 minecraft:redstone_wire replace
fill ~450 ~169 ~266 ~450 ~169 ~276 minecraft:redstone_wire replace
fill ~456 ~169 ~266 ~456 ~169 ~276 minecraft:redstone_wire replace
fill ~462 ~169 ~266 ~462 ~169 ~276 minecraft:redstone_wire replace
fill ~470 ~169 ~266 ~470 ~169 ~276 minecraft:redstone_wire replace
fill ~476 ~169 ~266 ~476 ~169 ~276 minecraft:redstone_wire replace
fill ~486 ~169 ~266 ~486 ~169 ~276 minecraft:redstone_wire replace
fill ~492 ~169 ~266 ~492 ~169 ~276 minecraft:redstone_wire replace
fill ~500 ~169 ~266 ~500 ~169 ~276 minecraft:redstone_wire replace
fill ~502 ~169 ~266 ~502 ~169 ~276 minecraft:redstone_wire replace
setblock ~446 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~269 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~270 ~446 ~169 ~280 minecraft:redstone_wire replace
fill ~452 ~169 ~270 ~452 ~169 ~280 minecraft:redstone_wire replace
fill ~454 ~169 ~270 ~454 ~169 ~280 minecraft:redstone_wire replace
fill ~464 ~169 ~270 ~464 ~169 ~280 minecraft:redstone_wire replace
fill ~466 ~169 ~270 ~466 ~169 ~280 minecraft:redstone_wire replace
fill ~468 ~169 ~270 ~468 ~169 ~280 minecraft:redstone_wire replace
fill ~478 ~169 ~270 ~478 ~169 ~280 minecraft:redstone_wire replace
fill ~480 ~169 ~270 ~480 ~169 ~280 minecraft:redstone_wire replace
fill ~488 ~169 ~270 ~488 ~169 ~280 minecraft:redstone_wire replace
fill ~490 ~169 ~270 ~490 ~169 ~280 minecraft:redstone_wire replace
setblock ~440 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~273 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~274 ~440 ~169 ~284 minecraft:redstone_wire replace
fill ~444 ~169 ~274 ~444 ~169 ~284 minecraft:redstone_wire replace
fill ~448 ~169 ~274 ~448 ~169 ~284 minecraft:redstone_wire replace
fill ~458 ~169 ~274 ~458 ~169 ~284 minecraft:redstone_wire replace
fill ~460 ~169 ~274 ~460 ~169 ~284 minecraft:redstone_wire replace
fill ~472 ~169 ~274 ~472 ~169 ~284 minecraft:redstone_wire replace
fill ~474 ~169 ~274 ~474 ~169 ~284 minecraft:redstone_wire replace
fill ~484 ~169 ~274 ~484 ~169 ~284 minecraft:redstone_wire replace
fill ~494 ~169 ~274 ~494 ~169 ~284 minecraft:redstone_wire replace
setblock ~442 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~277 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~278 ~442 ~169 ~288 minecraft:redstone_wire replace
fill ~450 ~169 ~278 ~450 ~169 ~288 minecraft:redstone_wire replace
fill ~456 ~169 ~278 ~456 ~169 ~288 minecraft:redstone_wire replace
fill ~462 ~169 ~278 ~462 ~169 ~288 minecraft:redstone_wire replace
fill ~470 ~169 ~278 ~470 ~169 ~288 minecraft:redstone_wire replace
fill ~476 ~169 ~278 ~476 ~169 ~288 minecraft:redstone_wire replace
fill ~486 ~169 ~278 ~486 ~169 ~288 minecraft:redstone_wire replace
fill ~492 ~169 ~278 ~492 ~169 ~288 minecraft:redstone_wire replace
fill ~500 ~169 ~278 ~500 ~169 ~288 minecraft:redstone_wire replace
fill ~502 ~169 ~278 ~502 ~169 ~288 minecraft:redstone_wire replace
setblock ~446 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~281 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~282 ~446 ~169 ~292 minecraft:redstone_wire replace
fill ~452 ~169 ~282 ~452 ~169 ~292 minecraft:redstone_wire replace
fill ~454 ~169 ~282 ~454 ~169 ~292 minecraft:redstone_wire replace
fill ~464 ~169 ~282 ~464 ~169 ~292 minecraft:redstone_wire replace
fill ~466 ~169 ~282 ~466 ~169 ~292 minecraft:redstone_wire replace
fill ~468 ~169 ~282 ~468 ~169 ~292 minecraft:redstone_wire replace
fill ~478 ~169 ~282 ~478 ~169 ~292 minecraft:redstone_wire replace
fill ~480 ~169 ~282 ~480 ~169 ~292 minecraft:redstone_wire replace
fill ~488 ~169 ~282 ~488 ~169 ~292 minecraft:redstone_wire replace
fill ~490 ~169 ~282 ~490 ~169 ~292 minecraft:redstone_wire replace
setblock ~440 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~285 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~286 ~440 ~169 ~296 minecraft:redstone_wire replace
fill ~444 ~169 ~286 ~444 ~169 ~296 minecraft:redstone_wire replace
fill ~448 ~169 ~286 ~448 ~169 ~296 minecraft:redstone_wire replace
fill ~458 ~169 ~286 ~458 ~169 ~296 minecraft:redstone_wire replace
fill ~460 ~169 ~286 ~460 ~169 ~296 minecraft:redstone_wire replace
fill ~472 ~169 ~286 ~472 ~169 ~296 minecraft:redstone_wire replace
fill ~474 ~169 ~286 ~474 ~169 ~296 minecraft:redstone_wire replace
fill ~494 ~169 ~286 ~494 ~169 ~296 minecraft:redstone_wire replace
setblock ~442 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~289 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~290 ~442 ~169 ~300 minecraft:redstone_wire replace
fill ~450 ~169 ~290 ~450 ~169 ~300 minecraft:redstone_wire replace
fill ~456 ~169 ~290 ~456 ~169 ~300 minecraft:redstone_wire replace
fill ~462 ~169 ~290 ~462 ~169 ~300 minecraft:redstone_wire replace
fill ~470 ~169 ~290 ~470 ~169 ~300 minecraft:redstone_wire replace
fill ~476 ~169 ~290 ~476 ~169 ~300 minecraft:redstone_wire replace
fill ~486 ~169 ~290 ~486 ~169 ~300 minecraft:redstone_wire replace
fill ~492 ~169 ~290 ~492 ~169 ~300 minecraft:redstone_wire replace
fill ~500 ~169 ~290 ~500 ~169 ~300 minecraft:redstone_wire replace
fill ~502 ~169 ~290 ~502 ~169 ~300 minecraft:redstone_wire replace
setblock ~446 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~293 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~294 ~446 ~169 ~304 minecraft:redstone_wire replace
fill ~452 ~169 ~294 ~452 ~169 ~304 minecraft:redstone_wire replace
fill ~454 ~169 ~294 ~454 ~169 ~304 minecraft:redstone_wire replace
fill ~464 ~169 ~294 ~464 ~169 ~304 minecraft:redstone_wire replace
fill ~466 ~169 ~294 ~466 ~169 ~304 minecraft:redstone_wire replace
fill ~468 ~169 ~294 ~468 ~169 ~304 minecraft:redstone_wire replace
fill ~478 ~169 ~294 ~478 ~169 ~304 minecraft:redstone_wire replace
fill ~480 ~169 ~294 ~480 ~169 ~304 minecraft:redstone_wire replace
fill ~488 ~169 ~294 ~488 ~169 ~304 minecraft:redstone_wire replace
fill ~490 ~169 ~294 ~490 ~169 ~304 minecraft:redstone_wire replace
setblock ~440 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~297 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~298 ~440 ~169 ~308 minecraft:redstone_wire replace
fill ~444 ~169 ~298 ~444 ~169 ~308 minecraft:redstone_wire replace
fill ~448 ~169 ~298 ~448 ~169 ~308 minecraft:redstone_wire replace
fill ~458 ~169 ~298 ~458 ~169 ~308 minecraft:redstone_wire replace
fill ~460 ~169 ~298 ~460 ~169 ~308 minecraft:redstone_wire replace
fill ~472 ~169 ~298 ~472 ~169 ~308 minecraft:redstone_wire replace
fill ~474 ~169 ~298 ~474 ~169 ~308 minecraft:redstone_wire replace
fill ~494 ~169 ~298 ~494 ~169 ~308 minecraft:redstone_wire replace
setblock ~442 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~301 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~302 ~442 ~169 ~312 minecraft:redstone_wire replace
fill ~450 ~169 ~302 ~450 ~169 ~312 minecraft:redstone_wire replace
fill ~456 ~169 ~302 ~456 ~169 ~312 minecraft:redstone_wire replace
fill ~462 ~169 ~302 ~462 ~169 ~312 minecraft:redstone_wire replace
fill ~470 ~169 ~302 ~470 ~169 ~312 minecraft:redstone_wire replace
fill ~476 ~169 ~302 ~476 ~169 ~312 minecraft:redstone_wire replace
fill ~492 ~169 ~302 ~492 ~169 ~312 minecraft:redstone_wire replace
fill ~500 ~169 ~302 ~500 ~169 ~312 minecraft:redstone_wire replace
fill ~502 ~169 ~302 ~502 ~169 ~312 minecraft:redstone_wire replace
setblock ~446 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~305 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~306 ~446 ~169 ~316 minecraft:redstone_wire replace
fill ~452 ~169 ~306 ~452 ~169 ~316 minecraft:redstone_wire replace
fill ~454 ~169 ~306 ~454 ~169 ~316 minecraft:redstone_wire replace
fill ~464 ~169 ~306 ~464 ~169 ~316 minecraft:redstone_wire replace
fill ~466 ~169 ~306 ~466 ~169 ~316 minecraft:redstone_wire replace
fill ~468 ~169 ~306 ~468 ~169 ~316 minecraft:redstone_wire replace
fill ~478 ~169 ~306 ~478 ~169 ~316 minecraft:redstone_wire replace
fill ~480 ~169 ~306 ~480 ~169 ~316 minecraft:redstone_wire replace
fill ~488 ~169 ~306 ~488 ~169 ~316 minecraft:redstone_wire replace
fill ~490 ~169 ~306 ~490 ~169 ~316 minecraft:redstone_wire replace
setblock ~440 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~309 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~310 ~440 ~169 ~320 minecraft:redstone_wire replace
fill ~444 ~169 ~310 ~444 ~169 ~320 minecraft:redstone_wire replace
fill ~448 ~169 ~310 ~448 ~169 ~320 minecraft:redstone_wire replace
fill ~458 ~169 ~310 ~458 ~169 ~320 minecraft:redstone_wire replace
fill ~460 ~169 ~310 ~460 ~169 ~320 minecraft:redstone_wire replace
fill ~472 ~169 ~310 ~472 ~169 ~320 minecraft:redstone_wire replace
fill ~474 ~169 ~310 ~474 ~169 ~320 minecraft:redstone_wire replace
fill ~494 ~169 ~310 ~494 ~169 ~320 minecraft:redstone_wire replace
setblock ~442 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~313 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~314 ~442 ~169 ~324 minecraft:redstone_wire replace
fill ~450 ~169 ~314 ~450 ~169 ~324 minecraft:redstone_wire replace
fill ~456 ~169 ~314 ~456 ~169 ~324 minecraft:redstone_wire replace
fill ~462 ~169 ~314 ~462 ~169 ~324 minecraft:redstone_wire replace
fill ~470 ~169 ~314 ~470 ~169 ~324 minecraft:redstone_wire replace
fill ~476 ~169 ~314 ~476 ~169 ~324 minecraft:redstone_wire replace
fill ~492 ~169 ~314 ~492 ~169 ~324 minecraft:redstone_wire replace
fill ~500 ~169 ~314 ~500 ~169 ~324 minecraft:redstone_wire replace
fill ~502 ~169 ~314 ~502 ~169 ~324 minecraft:redstone_wire replace
setblock ~446 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~317 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~318 ~446 ~169 ~328 minecraft:redstone_wire replace
fill ~452 ~169 ~318 ~452 ~169 ~328 minecraft:redstone_wire replace
fill ~454 ~169 ~318 ~454 ~169 ~328 minecraft:redstone_wire replace
fill ~464 ~169 ~318 ~464 ~169 ~328 minecraft:redstone_wire replace
fill ~466 ~169 ~318 ~466 ~169 ~328 minecraft:redstone_wire replace
fill ~468 ~169 ~318 ~468 ~169 ~328 minecraft:redstone_wire replace
fill ~478 ~169 ~318 ~478 ~169 ~328 minecraft:redstone_wire replace
fill ~480 ~169 ~318 ~480 ~169 ~328 minecraft:redstone_wire replace
fill ~488 ~169 ~318 ~488 ~169 ~328 minecraft:redstone_wire replace
fill ~490 ~169 ~318 ~490 ~169 ~328 minecraft:redstone_wire replace
setblock ~440 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~321 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~322 ~440 ~169 ~332 minecraft:redstone_wire replace
fill ~444 ~169 ~322 ~444 ~169 ~332 minecraft:redstone_wire replace
fill ~448 ~169 ~322 ~448 ~169 ~332 minecraft:redstone_wire replace
fill ~458 ~169 ~322 ~458 ~169 ~332 minecraft:redstone_wire replace
fill ~460 ~169 ~322 ~460 ~169 ~332 minecraft:redstone_wire replace
fill ~472 ~169 ~322 ~472 ~169 ~332 minecraft:redstone_wire replace
fill ~474 ~169 ~322 ~474 ~169 ~332 minecraft:redstone_wire replace
fill ~494 ~169 ~322 ~494 ~169 ~332 minecraft:redstone_wire replace
setblock ~442 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~325 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~326 ~442 ~169 ~336 minecraft:redstone_wire replace
fill ~450 ~169 ~326 ~450 ~169 ~336 minecraft:redstone_wire replace
fill ~456 ~169 ~326 ~456 ~169 ~336 minecraft:redstone_wire replace
fill ~462 ~169 ~326 ~462 ~169 ~336 minecraft:redstone_wire replace
fill ~470 ~169 ~326 ~470 ~169 ~336 minecraft:redstone_wire replace
fill ~476 ~169 ~326 ~476 ~169 ~336 minecraft:redstone_wire replace
fill ~492 ~169 ~326 ~492 ~169 ~336 minecraft:redstone_wire replace
fill ~500 ~169 ~326 ~500 ~169 ~336 minecraft:redstone_wire replace
fill ~502 ~169 ~326 ~502 ~169 ~336 minecraft:redstone_wire replace
setblock ~446 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~329 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~330 ~446 ~169 ~340 minecraft:redstone_wire replace
fill ~452 ~169 ~330 ~452 ~169 ~340 minecraft:redstone_wire replace
fill ~454 ~169 ~330 ~454 ~169 ~340 minecraft:redstone_wire replace
fill ~464 ~169 ~330 ~464 ~169 ~340 minecraft:redstone_wire replace
fill ~466 ~169 ~330 ~466 ~169 ~340 minecraft:redstone_wire replace
fill ~468 ~169 ~330 ~468 ~169 ~340 minecraft:redstone_wire replace
fill ~478 ~169 ~330 ~478 ~169 ~340 minecraft:redstone_wire replace
fill ~480 ~169 ~330 ~480 ~169 ~340 minecraft:redstone_wire replace
fill ~490 ~169 ~330 ~490 ~169 ~340 minecraft:redstone_wire replace
setblock ~440 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~333 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~334 ~440 ~169 ~344 minecraft:redstone_wire replace
fill ~444 ~169 ~334 ~444 ~169 ~344 minecraft:redstone_wire replace
fill ~448 ~169 ~334 ~448 ~169 ~344 minecraft:redstone_wire replace
fill ~458 ~169 ~334 ~458 ~169 ~344 minecraft:redstone_wire replace
fill ~460 ~169 ~334 ~460 ~169 ~344 minecraft:redstone_wire replace
fill ~472 ~169 ~334 ~472 ~169 ~344 minecraft:redstone_wire replace
fill ~474 ~169 ~334 ~474 ~169 ~344 minecraft:redstone_wire replace
fill ~494 ~169 ~334 ~494 ~169 ~344 minecraft:redstone_wire replace
setblock ~442 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~337 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~338 ~442 ~169 ~348 minecraft:redstone_wire replace
fill ~450 ~169 ~338 ~450 ~169 ~348 minecraft:redstone_wire replace
fill ~456 ~169 ~338 ~456 ~169 ~348 minecraft:redstone_wire replace
fill ~462 ~169 ~338 ~462 ~169 ~348 minecraft:redstone_wire replace
fill ~470 ~169 ~338 ~470 ~169 ~348 minecraft:redstone_wire replace
fill ~476 ~169 ~338 ~476 ~169 ~348 minecraft:redstone_wire replace
fill ~492 ~169 ~338 ~492 ~169 ~348 minecraft:redstone_wire replace
fill ~500 ~169 ~338 ~500 ~169 ~348 minecraft:redstone_wire replace
fill ~502 ~169 ~338 ~502 ~169 ~348 minecraft:redstone_wire replace
setblock ~446 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~341 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~342 ~446 ~169 ~352 minecraft:redstone_wire replace
fill ~452 ~169 ~342 ~452 ~169 ~352 minecraft:redstone_wire replace
fill ~454 ~169 ~342 ~454 ~169 ~352 minecraft:redstone_wire replace
fill ~464 ~169 ~342 ~464 ~169 ~352 minecraft:redstone_wire replace
fill ~466 ~169 ~342 ~466 ~169 ~352 minecraft:redstone_wire replace
fill ~468 ~169 ~342 ~468 ~169 ~352 minecraft:redstone_wire replace
fill ~478 ~169 ~342 ~478 ~169 ~352 minecraft:redstone_wire replace
fill ~480 ~169 ~342 ~480 ~169 ~352 minecraft:redstone_wire replace
fill ~490 ~169 ~342 ~490 ~169 ~352 minecraft:redstone_wire replace
setblock ~440 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~345 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~346 ~440 ~169 ~356 minecraft:redstone_wire replace
fill ~444 ~169 ~346 ~444 ~169 ~356 minecraft:redstone_wire replace
fill ~448 ~169 ~346 ~448 ~169 ~356 minecraft:redstone_wire replace
fill ~458 ~169 ~346 ~458 ~169 ~356 minecraft:redstone_wire replace
fill ~460 ~169 ~346 ~460 ~169 ~356 minecraft:redstone_wire replace
fill ~472 ~169 ~346 ~472 ~169 ~356 minecraft:redstone_wire replace
fill ~474 ~169 ~346 ~474 ~169 ~356 minecraft:redstone_wire replace
fill ~494 ~169 ~346 ~494 ~169 ~356 minecraft:redstone_wire replace
setblock ~442 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~349 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~350 ~442 ~169 ~360 minecraft:redstone_wire replace
fill ~450 ~169 ~350 ~450 ~169 ~360 minecraft:redstone_wire replace
fill ~456 ~169 ~350 ~456 ~169 ~360 minecraft:redstone_wire replace
fill ~462 ~169 ~350 ~462 ~169 ~360 minecraft:redstone_wire replace
fill ~470 ~169 ~350 ~470 ~169 ~360 minecraft:redstone_wire replace
fill ~476 ~169 ~350 ~476 ~169 ~360 minecraft:redstone_wire replace
fill ~492 ~169 ~350 ~492 ~169 ~360 minecraft:redstone_wire replace
fill ~500 ~169 ~350 ~500 ~169 ~360 minecraft:redstone_wire replace
fill ~502 ~169 ~350 ~502 ~169 ~360 minecraft:redstone_wire replace
setblock ~446 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~353 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~354 ~446 ~169 ~364 minecraft:redstone_wire replace
fill ~452 ~169 ~354 ~452 ~169 ~364 minecraft:redstone_wire replace
fill ~454 ~169 ~354 ~454 ~169 ~364 minecraft:redstone_wire replace
fill ~464 ~169 ~354 ~464 ~169 ~364 minecraft:redstone_wire replace
fill ~466 ~169 ~354 ~466 ~169 ~364 minecraft:redstone_wire replace
fill ~468 ~169 ~354 ~468 ~169 ~364 minecraft:redstone_wire replace
fill ~478 ~169 ~354 ~478 ~169 ~364 minecraft:redstone_wire replace
fill ~480 ~169 ~354 ~480 ~169 ~364 minecraft:redstone_wire replace
fill ~490 ~169 ~354 ~490 ~169 ~364 minecraft:redstone_wire replace
setblock ~440 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~357 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~358 ~440 ~169 ~368 minecraft:redstone_wire replace
fill ~444 ~169 ~358 ~444 ~169 ~368 minecraft:redstone_wire replace
fill ~448 ~169 ~358 ~448 ~169 ~368 minecraft:redstone_wire replace
fill ~458 ~169 ~358 ~458 ~169 ~368 minecraft:redstone_wire replace
fill ~460 ~169 ~358 ~460 ~169 ~368 minecraft:redstone_wire replace
fill ~472 ~169 ~358 ~472 ~169 ~368 minecraft:redstone_wire replace
fill ~474 ~169 ~358 ~474 ~169 ~368 minecraft:redstone_wire replace
fill ~494 ~169 ~358 ~494 ~169 ~368 minecraft:redstone_wire replace
setblock ~442 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~361 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~362 ~442 ~169 ~372 minecraft:redstone_wire replace
fill ~450 ~169 ~362 ~450 ~169 ~372 minecraft:redstone_wire replace
fill ~456 ~169 ~362 ~456 ~169 ~372 minecraft:redstone_wire replace
fill ~462 ~169 ~362 ~462 ~169 ~372 minecraft:redstone_wire replace
fill ~470 ~169 ~362 ~470 ~169 ~372 minecraft:redstone_wire replace
fill ~476 ~169 ~362 ~476 ~169 ~372 minecraft:redstone_wire replace
fill ~492 ~169 ~362 ~492 ~169 ~372 minecraft:redstone_wire replace
fill ~500 ~169 ~362 ~500 ~169 ~372 minecraft:redstone_wire replace
fill ~502 ~169 ~362 ~502 ~169 ~372 minecraft:redstone_wire replace
setblock ~446 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~365 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~366 ~446 ~169 ~376 minecraft:redstone_wire replace
fill ~452 ~169 ~366 ~452 ~169 ~376 minecraft:redstone_wire replace
fill ~454 ~169 ~366 ~454 ~169 ~376 minecraft:redstone_wire replace
fill ~464 ~169 ~366 ~464 ~169 ~376 minecraft:redstone_wire replace
fill ~466 ~169 ~366 ~466 ~169 ~376 minecraft:redstone_wire replace
fill ~468 ~169 ~366 ~468 ~169 ~376 minecraft:redstone_wire replace
fill ~478 ~169 ~366 ~478 ~169 ~376 minecraft:redstone_wire replace
fill ~480 ~169 ~366 ~480 ~169 ~376 minecraft:redstone_wire replace
setblock ~440 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~369 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~370 ~440 ~169 ~380 minecraft:redstone_wire replace
fill ~444 ~169 ~370 ~444 ~169 ~380 minecraft:redstone_wire replace
fill ~448 ~169 ~370 ~448 ~169 ~380 minecraft:redstone_wire replace
fill ~458 ~169 ~370 ~458 ~169 ~380 minecraft:redstone_wire replace
fill ~460 ~169 ~370 ~460 ~169 ~380 minecraft:redstone_wire replace
fill ~472 ~169 ~370 ~472 ~169 ~380 minecraft:redstone_wire replace
fill ~474 ~169 ~370 ~474 ~169 ~380 minecraft:redstone_wire replace
fill ~494 ~169 ~370 ~494 ~169 ~380 minecraft:redstone_wire replace
setblock ~442 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~373 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~374 ~442 ~169 ~384 minecraft:redstone_wire replace
fill ~450 ~169 ~374 ~450 ~169 ~384 minecraft:redstone_wire replace
fill ~456 ~169 ~374 ~456 ~169 ~384 minecraft:redstone_wire replace
fill ~462 ~169 ~374 ~462 ~169 ~384 minecraft:redstone_wire replace
fill ~470 ~169 ~374 ~470 ~169 ~384 minecraft:redstone_wire replace
fill ~476 ~169 ~374 ~476 ~169 ~384 minecraft:redstone_wire replace
fill ~492 ~169 ~374 ~492 ~169 ~384 minecraft:redstone_wire replace
fill ~500 ~169 ~374 ~500 ~169 ~384 minecraft:redstone_wire replace
fill ~502 ~169 ~374 ~502 ~169 ~384 minecraft:redstone_wire replace
setblock ~446 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~377 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~378 ~446 ~169 ~388 minecraft:redstone_wire replace
fill ~452 ~169 ~378 ~452 ~169 ~388 minecraft:redstone_wire replace
fill ~454 ~169 ~378 ~454 ~169 ~388 minecraft:redstone_wire replace
fill ~464 ~169 ~378 ~464 ~169 ~388 minecraft:redstone_wire replace
fill ~466 ~169 ~378 ~466 ~169 ~388 minecraft:redstone_wire replace
fill ~468 ~169 ~378 ~468 ~169 ~388 minecraft:redstone_wire replace
fill ~478 ~169 ~378 ~478 ~169 ~388 minecraft:redstone_wire replace
fill ~480 ~169 ~378 ~480 ~169 ~388 minecraft:redstone_wire replace
setblock ~440 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~381 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~382 ~440 ~169 ~392 minecraft:redstone_wire replace
fill ~444 ~169 ~382 ~444 ~169 ~392 minecraft:redstone_wire replace
fill ~448 ~169 ~382 ~448 ~169 ~392 minecraft:redstone_wire replace
fill ~458 ~169 ~382 ~458 ~169 ~392 minecraft:redstone_wire replace
fill ~460 ~169 ~382 ~460 ~169 ~392 minecraft:redstone_wire replace
fill ~472 ~169 ~382 ~472 ~169 ~392 minecraft:redstone_wire replace
fill ~474 ~169 ~382 ~474 ~169 ~392 minecraft:redstone_wire replace
fill ~494 ~169 ~382 ~494 ~169 ~392 minecraft:redstone_wire replace
setblock ~442 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~385 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~386 ~442 ~169 ~396 minecraft:redstone_wire replace
fill ~450 ~169 ~386 ~450 ~169 ~396 minecraft:redstone_wire replace
fill ~456 ~169 ~386 ~456 ~169 ~396 minecraft:redstone_wire replace
fill ~462 ~169 ~386 ~462 ~169 ~396 minecraft:redstone_wire replace
fill ~470 ~169 ~386 ~470 ~169 ~396 minecraft:redstone_wire replace
fill ~476 ~169 ~386 ~476 ~169 ~396 minecraft:redstone_wire replace
fill ~492 ~169 ~386 ~492 ~169 ~396 minecraft:redstone_wire replace
fill ~500 ~169 ~386 ~500 ~169 ~396 minecraft:redstone_wire replace
fill ~502 ~169 ~386 ~502 ~169 ~396 minecraft:redstone_wire replace
setblock ~446 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~390 ~446 ~169 ~400 minecraft:redstone_wire replace
fill ~452 ~169 ~390 ~452 ~169 ~400 minecraft:redstone_wire replace
fill ~454 ~169 ~390 ~454 ~169 ~400 minecraft:redstone_wire replace
fill ~464 ~169 ~390 ~464 ~169 ~400 minecraft:redstone_wire replace
fill ~466 ~169 ~390 ~466 ~169 ~400 minecraft:redstone_wire replace
fill ~468 ~169 ~390 ~468 ~169 ~400 minecraft:redstone_wire replace
fill ~478 ~169 ~390 ~478 ~169 ~400 minecraft:redstone_wire replace
fill ~480 ~169 ~390 ~480 ~169 ~400 minecraft:redstone_wire replace
setblock ~440 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~394 ~440 ~169 ~404 minecraft:redstone_wire replace
fill ~444 ~169 ~394 ~444 ~169 ~404 minecraft:redstone_wire replace
fill ~448 ~169 ~394 ~448 ~169 ~404 minecraft:redstone_wire replace
fill ~458 ~169 ~394 ~458 ~169 ~404 minecraft:redstone_wire replace
fill ~460 ~169 ~394 ~460 ~169 ~404 minecraft:redstone_wire replace
fill ~472 ~169 ~394 ~472 ~169 ~404 minecraft:redstone_wire replace
fill ~474 ~169 ~394 ~474 ~169 ~404 minecraft:redstone_wire replace
fill ~494 ~169 ~394 ~494 ~169 ~404 minecraft:redstone_wire replace
setblock ~442 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~398 ~442 ~169 ~408 minecraft:redstone_wire replace
fill ~450 ~169 ~398 ~450 ~169 ~408 minecraft:redstone_wire replace
fill ~456 ~169 ~398 ~456 ~169 ~408 minecraft:redstone_wire replace
fill ~462 ~169 ~398 ~462 ~169 ~408 minecraft:redstone_wire replace
fill ~470 ~169 ~398 ~470 ~169 ~408 minecraft:redstone_wire replace
fill ~476 ~169 ~398 ~476 ~169 ~408 minecraft:redstone_wire replace
fill ~500 ~169 ~398 ~500 ~169 ~408 minecraft:redstone_wire replace
fill ~502 ~169 ~398 ~502 ~169 ~408 minecraft:redstone_wire replace
setblock ~446 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~402 ~446 ~169 ~412 minecraft:redstone_wire replace
fill ~452 ~169 ~402 ~452 ~169 ~412 minecraft:redstone_wire replace
fill ~454 ~169 ~402 ~454 ~169 ~412 minecraft:redstone_wire replace
fill ~464 ~169 ~402 ~464 ~169 ~412 minecraft:redstone_wire replace
fill ~466 ~169 ~402 ~466 ~169 ~412 minecraft:redstone_wire replace
fill ~468 ~169 ~402 ~468 ~169 ~412 minecraft:redstone_wire replace
fill ~478 ~169 ~402 ~478 ~169 ~412 minecraft:redstone_wire replace
fill ~480 ~169 ~402 ~480 ~169 ~412 minecraft:redstone_wire replace
setblock ~440 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~406 ~440 ~169 ~416 minecraft:redstone_wire replace
fill ~444 ~169 ~406 ~444 ~169 ~416 minecraft:redstone_wire replace
fill ~448 ~169 ~406 ~448 ~169 ~416 minecraft:redstone_wire replace
fill ~458 ~169 ~406 ~458 ~169 ~416 minecraft:redstone_wire replace
fill ~460 ~169 ~406 ~460 ~169 ~416 minecraft:redstone_wire replace
fill ~472 ~169 ~406 ~472 ~169 ~416 minecraft:redstone_wire replace
fill ~474 ~169 ~406 ~474 ~169 ~416 minecraft:redstone_wire replace
fill ~494 ~169 ~406 ~494 ~169 ~416 minecraft:redstone_wire replace
setblock ~442 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~410 ~442 ~169 ~420 minecraft:redstone_wire replace
fill ~450 ~169 ~410 ~450 ~169 ~420 minecraft:redstone_wire replace
fill ~456 ~169 ~410 ~456 ~169 ~420 minecraft:redstone_wire replace
fill ~462 ~169 ~410 ~462 ~169 ~420 minecraft:redstone_wire replace
fill ~470 ~169 ~410 ~470 ~169 ~420 minecraft:redstone_wire replace
fill ~476 ~169 ~410 ~476 ~169 ~420 minecraft:redstone_wire replace
fill ~500 ~169 ~410 ~500 ~169 ~420 minecraft:redstone_wire replace
fill ~502 ~169 ~410 ~502 ~169 ~420 minecraft:redstone_wire replace
setblock ~446 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~414 ~446 ~169 ~424 minecraft:redstone_wire replace
fill ~452 ~169 ~414 ~452 ~169 ~424 minecraft:redstone_wire replace
fill ~454 ~169 ~414 ~454 ~169 ~424 minecraft:redstone_wire replace
fill ~464 ~169 ~414 ~464 ~169 ~424 minecraft:redstone_wire replace
fill ~466 ~169 ~414 ~466 ~169 ~424 minecraft:redstone_wire replace
fill ~468 ~169 ~414 ~468 ~169 ~424 minecraft:redstone_wire replace
fill ~478 ~169 ~414 ~478 ~169 ~424 minecraft:redstone_wire replace
fill ~480 ~169 ~414 ~480 ~169 ~424 minecraft:redstone_wire replace
setblock ~440 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~418 ~440 ~169 ~428 minecraft:redstone_wire replace
fill ~444 ~169 ~418 ~444 ~169 ~428 minecraft:redstone_wire replace
fill ~448 ~169 ~418 ~448 ~169 ~428 minecraft:redstone_wire replace
fill ~458 ~169 ~418 ~458 ~169 ~428 minecraft:redstone_wire replace
fill ~460 ~169 ~418 ~460 ~169 ~428 minecraft:redstone_wire replace
fill ~472 ~169 ~418 ~472 ~169 ~428 minecraft:redstone_wire replace
fill ~474 ~169 ~418 ~474 ~169 ~428 minecraft:redstone_wire replace
fill ~494 ~169 ~418 ~494 ~169 ~428 minecraft:redstone_wire replace
setblock ~442 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~422 ~442 ~169 ~432 minecraft:redstone_wire replace
fill ~450 ~169 ~422 ~450 ~169 ~432 minecraft:redstone_wire replace
fill ~456 ~169 ~422 ~456 ~169 ~432 minecraft:redstone_wire replace
fill ~462 ~169 ~422 ~462 ~169 ~432 minecraft:redstone_wire replace
fill ~470 ~169 ~422 ~470 ~169 ~432 minecraft:redstone_wire replace
fill ~476 ~169 ~422 ~476 ~169 ~432 minecraft:redstone_wire replace
fill ~500 ~169 ~422 ~500 ~169 ~432 minecraft:redstone_wire replace
fill ~502 ~169 ~422 ~502 ~169 ~432 minecraft:redstone_wire replace
setblock ~446 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~426 ~446 ~169 ~436 minecraft:redstone_wire replace
fill ~452 ~169 ~426 ~452 ~169 ~436 minecraft:redstone_wire replace
fill ~454 ~169 ~426 ~454 ~169 ~436 minecraft:redstone_wire replace
fill ~464 ~169 ~426 ~464 ~169 ~436 minecraft:redstone_wire replace
fill ~466 ~169 ~426 ~466 ~169 ~436 minecraft:redstone_wire replace
fill ~468 ~169 ~426 ~468 ~169 ~436 minecraft:redstone_wire replace
fill ~478 ~169 ~426 ~478 ~169 ~436 minecraft:redstone_wire replace
fill ~480 ~169 ~426 ~480 ~169 ~436 minecraft:redstone_wire replace
setblock ~440 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~430 ~440 ~169 ~440 minecraft:redstone_wire replace
fill ~444 ~169 ~430 ~444 ~169 ~440 minecraft:redstone_wire replace
fill ~448 ~169 ~430 ~448 ~169 ~440 minecraft:redstone_wire replace
fill ~458 ~169 ~430 ~458 ~169 ~440 minecraft:redstone_wire replace
fill ~460 ~169 ~430 ~460 ~169 ~440 minecraft:redstone_wire replace
fill ~472 ~169 ~430 ~472 ~169 ~440 minecraft:redstone_wire replace
fill ~474 ~169 ~430 ~474 ~169 ~440 minecraft:redstone_wire replace
setblock ~442 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~434 ~442 ~169 ~444 minecraft:redstone_wire replace
fill ~450 ~169 ~434 ~450 ~169 ~444 minecraft:redstone_wire replace
fill ~456 ~169 ~434 ~456 ~169 ~444 minecraft:redstone_wire replace
fill ~462 ~169 ~434 ~462 ~169 ~444 minecraft:redstone_wire replace
fill ~470 ~169 ~434 ~470 ~169 ~444 minecraft:redstone_wire replace
fill ~476 ~169 ~434 ~476 ~169 ~444 minecraft:redstone_wire replace
fill ~500 ~169 ~434 ~500 ~169 ~444 minecraft:redstone_wire replace
fill ~502 ~169 ~434 ~502 ~169 ~444 minecraft:redstone_wire replace
setblock ~446 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~438 ~446 ~169 ~448 minecraft:redstone_wire replace
fill ~452 ~169 ~438 ~452 ~169 ~448 minecraft:redstone_wire replace
fill ~454 ~169 ~438 ~454 ~169 ~448 minecraft:redstone_wire replace
fill ~464 ~169 ~438 ~464 ~169 ~448 minecraft:redstone_wire replace
fill ~466 ~169 ~438 ~466 ~169 ~448 minecraft:redstone_wire replace
fill ~468 ~169 ~438 ~468 ~169 ~448 minecraft:redstone_wire replace
fill ~478 ~169 ~438 ~478 ~169 ~448 minecraft:redstone_wire replace
fill ~480 ~169 ~438 ~480 ~169 ~448 minecraft:redstone_wire replace
setblock ~440 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~442 ~440 ~169 ~452 minecraft:redstone_wire replace
fill ~444 ~169 ~442 ~444 ~169 ~452 minecraft:redstone_wire replace
fill ~448 ~169 ~442 ~448 ~169 ~452 minecraft:redstone_wire replace
fill ~458 ~169 ~442 ~458 ~169 ~452 minecraft:redstone_wire replace
fill ~460 ~169 ~442 ~460 ~169 ~452 minecraft:redstone_wire replace
fill ~472 ~169 ~442 ~472 ~169 ~452 minecraft:redstone_wire replace
fill ~474 ~169 ~442 ~474 ~169 ~452 minecraft:redstone_wire replace
setblock ~442 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~446 ~442 ~169 ~456 minecraft:redstone_wire replace
fill ~450 ~169 ~446 ~450 ~169 ~456 minecraft:redstone_wire replace
fill ~456 ~169 ~446 ~456 ~169 ~456 minecraft:redstone_wire replace
fill ~462 ~169 ~446 ~462 ~169 ~456 minecraft:redstone_wire replace
fill ~470 ~169 ~446 ~470 ~169 ~456 minecraft:redstone_wire replace
fill ~476 ~169 ~446 ~476 ~169 ~456 minecraft:redstone_wire replace
fill ~502 ~169 ~446 ~502 ~169 ~456 minecraft:redstone_wire replace
setblock ~446 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~450 ~446 ~169 ~460 minecraft:redstone_wire replace
fill ~452 ~169 ~450 ~452 ~169 ~460 minecraft:redstone_wire replace
fill ~454 ~169 ~450 ~454 ~169 ~460 minecraft:redstone_wire replace
fill ~464 ~169 ~450 ~464 ~169 ~460 minecraft:redstone_wire replace
fill ~466 ~169 ~450 ~466 ~169 ~460 minecraft:redstone_wire replace
fill ~468 ~169 ~450 ~468 ~169 ~460 minecraft:redstone_wire replace
fill ~478 ~169 ~450 ~478 ~169 ~460 minecraft:redstone_wire replace
fill ~480 ~169 ~450 ~480 ~169 ~460 minecraft:redstone_wire replace
setblock ~440 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~454 ~440 ~169 ~464 minecraft:redstone_wire replace
fill ~444 ~169 ~454 ~444 ~169 ~464 minecraft:redstone_wire replace
fill ~448 ~169 ~454 ~448 ~169 ~464 minecraft:redstone_wire replace
fill ~458 ~169 ~454 ~458 ~169 ~464 minecraft:redstone_wire replace
fill ~460 ~169 ~454 ~460 ~169 ~464 minecraft:redstone_wire replace
fill ~472 ~169 ~454 ~472 ~169 ~464 minecraft:redstone_wire replace
fill ~474 ~169 ~454 ~474 ~169 ~464 minecraft:redstone_wire replace
setblock ~442 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~458 ~442 ~169 ~468 minecraft:redstone_wire replace
fill ~450 ~169 ~458 ~450 ~169 ~468 minecraft:redstone_wire replace
fill ~456 ~169 ~458 ~456 ~169 ~468 minecraft:redstone_wire replace
fill ~462 ~169 ~458 ~462 ~169 ~468 minecraft:redstone_wire replace
fill ~470 ~169 ~458 ~470 ~169 ~468 minecraft:redstone_wire replace
fill ~476 ~169 ~458 ~476 ~169 ~468 minecraft:redstone_wire replace
fill ~502 ~169 ~458 ~502 ~169 ~468 minecraft:redstone_wire replace
setblock ~446 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~462 ~446 ~169 ~472 minecraft:redstone_wire replace
fill ~452 ~169 ~462 ~452 ~169 ~472 minecraft:redstone_wire replace
fill ~454 ~169 ~462 ~454 ~169 ~472 minecraft:redstone_wire replace
fill ~464 ~169 ~462 ~464 ~169 ~472 minecraft:redstone_wire replace
fill ~466 ~169 ~462 ~466 ~169 ~472 minecraft:redstone_wire replace
fill ~468 ~169 ~462 ~468 ~169 ~472 minecraft:redstone_wire replace
fill ~478 ~169 ~462 ~478 ~169 ~472 minecraft:redstone_wire replace
fill ~480 ~169 ~462 ~480 ~169 ~472 minecraft:redstone_wire replace
setblock ~440 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~466 ~440 ~169 ~476 minecraft:redstone_wire replace
fill ~444 ~169 ~466 ~444 ~169 ~476 minecraft:redstone_wire replace
fill ~448 ~169 ~466 ~448 ~169 ~476 minecraft:redstone_wire replace
fill ~458 ~169 ~466 ~458 ~169 ~476 minecraft:redstone_wire replace
fill ~460 ~169 ~466 ~460 ~169 ~476 minecraft:redstone_wire replace
fill ~472 ~169 ~466 ~472 ~169 ~476 minecraft:redstone_wire replace
fill ~474 ~169 ~466 ~474 ~169 ~476 minecraft:redstone_wire replace
setblock ~442 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~470 ~442 ~169 ~480 minecraft:redstone_wire replace
fill ~450 ~169 ~470 ~450 ~169 ~480 minecraft:redstone_wire replace
fill ~456 ~169 ~470 ~456 ~169 ~480 minecraft:redstone_wire replace
fill ~462 ~169 ~470 ~462 ~169 ~480 minecraft:redstone_wire replace
fill ~470 ~169 ~470 ~470 ~169 ~480 minecraft:redstone_wire replace
fill ~476 ~169 ~470 ~476 ~169 ~480 minecraft:redstone_wire replace
fill ~502 ~169 ~470 ~502 ~169 ~480 minecraft:redstone_wire replace
setblock ~446 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~474 ~446 ~169 ~484 minecraft:redstone_wire replace
fill ~452 ~169 ~474 ~452 ~169 ~484 minecraft:redstone_wire replace
fill ~454 ~169 ~474 ~454 ~169 ~484 minecraft:redstone_wire replace
fill ~464 ~169 ~474 ~464 ~169 ~484 minecraft:redstone_wire replace
fill ~466 ~169 ~474 ~466 ~169 ~484 minecraft:redstone_wire replace
fill ~468 ~169 ~474 ~468 ~169 ~484 minecraft:redstone_wire replace
fill ~478 ~169 ~474 ~478 ~169 ~484 minecraft:redstone_wire replace
fill ~480 ~169 ~474 ~480 ~169 ~484 minecraft:redstone_wire replace
setblock ~440 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~478 ~440 ~169 ~488 minecraft:redstone_wire replace
fill ~444 ~169 ~478 ~444 ~169 ~488 minecraft:redstone_wire replace
fill ~448 ~169 ~478 ~448 ~169 ~488 minecraft:redstone_wire replace
fill ~458 ~169 ~478 ~458 ~169 ~488 minecraft:redstone_wire replace
fill ~460 ~169 ~478 ~460 ~169 ~488 minecraft:redstone_wire replace
fill ~472 ~169 ~478 ~472 ~169 ~488 minecraft:redstone_wire replace
fill ~474 ~169 ~478 ~474 ~169 ~488 minecraft:redstone_wire replace
setblock ~442 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~482 ~442 ~169 ~492 minecraft:redstone_wire replace
fill ~450 ~169 ~482 ~450 ~169 ~492 minecraft:redstone_wire replace
fill ~456 ~169 ~482 ~456 ~169 ~492 minecraft:redstone_wire replace
fill ~462 ~169 ~482 ~462 ~169 ~492 minecraft:redstone_wire replace
fill ~470 ~169 ~482 ~470 ~169 ~492 minecraft:redstone_wire replace
fill ~476 ~169 ~482 ~476 ~169 ~492 minecraft:redstone_wire replace
fill ~502 ~169 ~482 ~502 ~169 ~492 minecraft:redstone_wire replace
setblock ~446 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~486 ~446 ~169 ~496 minecraft:redstone_wire replace
fill ~452 ~169 ~486 ~452 ~169 ~496 minecraft:redstone_wire replace
fill ~454 ~169 ~486 ~454 ~169 ~496 minecraft:redstone_wire replace
fill ~464 ~169 ~486 ~464 ~169 ~496 minecraft:redstone_wire replace
fill ~466 ~169 ~486 ~466 ~169 ~496 minecraft:redstone_wire replace
fill ~468 ~169 ~486 ~468 ~169 ~496 minecraft:redstone_wire replace
fill ~478 ~169 ~486 ~478 ~169 ~496 minecraft:redstone_wire replace
fill ~480 ~169 ~486 ~480 ~169 ~496 minecraft:redstone_wire replace
setblock ~440 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~490 ~440 ~169 ~500 minecraft:redstone_wire replace
fill ~444 ~169 ~490 ~444 ~169 ~500 minecraft:redstone_wire replace
fill ~448 ~169 ~490 ~448 ~169 ~500 minecraft:redstone_wire replace
fill ~458 ~169 ~490 ~458 ~169 ~500 minecraft:redstone_wire replace
fill ~460 ~169 ~490 ~460 ~169 ~500 minecraft:redstone_wire replace
fill ~472 ~169 ~490 ~472 ~169 ~500 minecraft:redstone_wire replace
fill ~474 ~169 ~490 ~474 ~169 ~500 minecraft:redstone_wire replace
setblock ~442 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
