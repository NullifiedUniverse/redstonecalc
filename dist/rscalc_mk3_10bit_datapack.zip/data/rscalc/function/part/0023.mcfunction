setblock ~333 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~348 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~350 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~82 ~49 ~524 minecraft:light_gray_concrete replace
setblock ~106 ~49 ~528 minecraft:light_gray_concrete replace
setblock ~127 ~49 ~532 minecraft:light_gray_concrete replace
setblock ~148 ~49 ~536 minecraft:light_gray_concrete replace
setblock ~175 ~49 ~540 minecraft:light_gray_concrete replace
setblock ~180 ~49 ~542 minecraft:light_gray_concrete replace
setblock ~182 ~49 ~542 minecraft:light_gray_concrete replace
setblock ~199 ~49 ~544 minecraft:light_gray_concrete replace
setblock ~207 ~49 ~546 minecraft:light_gray_concrete replace
setblock ~209 ~49 ~546 minecraft:light_gray_concrete replace
setblock ~223 ~49 ~548 minecraft:light_gray_concrete replace
setblock ~237 ~49 ~550 minecraft:light_gray_concrete replace
setblock ~239 ~49 ~550 minecraft:light_gray_concrete replace
setblock ~241 ~49 ~552 minecraft:light_gray_concrete replace
setblock ~255 ~49 ~554 minecraft:light_gray_concrete replace
setblock ~257 ~49 ~554 minecraft:light_gray_concrete replace
setblock ~283 ~49 ~556 minecraft:light_gray_concrete replace
setblock ~284 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~286 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~301 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~303 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~318 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~320 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~307 ~49 ~560 minecraft:light_gray_concrete replace
setblock ~308 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~310 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~325 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~327 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~342 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~344 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~79 ~49 ~564 minecraft:light_gray_concrete replace
setblock ~103 ~49 ~568 minecraft:light_gray_concrete replace
setblock ~124 ~49 ~572 minecraft:light_gray_concrete replace
setblock ~145 ~49 ~576 minecraft:light_gray_concrete replace
setblock ~169 ~49 ~580 minecraft:light_gray_concrete replace
setblock ~171 ~49 ~582 minecraft:light_gray_concrete replace
setblock ~173 ~49 ~582 minecraft:light_gray_concrete replace
setblock ~190 ~49 ~584 minecraft:light_gray_concrete replace
setblock ~195 ~49 ~586 minecraft:light_gray_concrete replace
setblock ~197 ~49 ~586 minecraft:light_gray_concrete replace
setblock ~220 ~49 ~588 minecraft:light_gray_concrete replace
setblock ~234 ~49 ~590 minecraft:light_gray_concrete replace
setblock ~236 ~49 ~590 minecraft:light_gray_concrete replace
setblock ~238 ~49 ~592 minecraft:light_gray_concrete replace
setblock ~252 ~49 ~594 minecraft:light_gray_concrete replace
setblock ~254 ~49 ~594 minecraft:light_gray_concrete replace
setblock ~280 ~49 ~596 minecraft:light_gray_concrete replace
setblock ~281 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~283 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~298 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~300 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~315 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~317 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~304 ~49 ~600 minecraft:light_gray_concrete replace
setblock ~305 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~307 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~322 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~324 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~339 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~341 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~100 ~49 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~49 ~608 minecraft:light_gray_concrete replace
setblock ~142 ~49 ~612 minecraft:light_gray_concrete replace
setblock ~166 ~49 ~616 minecraft:light_gray_concrete replace
setblock ~168 ~49 ~618 minecraft:light_gray_concrete replace
setblock ~170 ~49 ~618 minecraft:light_gray_concrete replace
setblock ~187 ~49 ~620 minecraft:light_gray_concrete replace
setblock ~192 ~49 ~622 minecraft:light_gray_concrete replace
setblock ~194 ~49 ~622 minecraft:light_gray_concrete replace
setblock ~211 ~49 ~624 minecraft:light_gray_concrete replace
setblock ~219 ~49 ~626 minecraft:light_gray_concrete replace
setblock ~221 ~49 ~626 minecraft:light_gray_concrete replace
setblock ~244 ~49 ~628 minecraft:light_gray_concrete replace
setblock ~258 ~49 ~630 minecraft:light_gray_concrete replace
setblock ~260 ~49 ~630 minecraft:light_gray_concrete replace
setblock ~256 ~49 ~632 minecraft:light_gray_concrete replace
setblock ~270 ~49 ~634 minecraft:light_gray_concrete replace
setblock ~272 ~49 ~634 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~636 minecraft:light_gray_concrete replace
setblock ~296 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~298 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~313 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~315 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~330 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~332 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~151 ~49 ~640 minecraft:light_gray_concrete replace
setblock ~322 ~49 ~644 minecraft:light_gray_concrete replace
setblock ~323 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~325 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~340 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~342 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~357 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~359 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~97 ~49 ~648 minecraft:light_gray_concrete replace
setblock ~298 ~49 ~652 minecraft:light_gray_concrete replace
setblock ~299 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~301 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~316 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~318 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~333 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~335 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~319 ~49 ~656 minecraft:light_gray_concrete replace
setblock ~320 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~322 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~337 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~339 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~354 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~356 ~49 ~658 minecraft:light_gray_concrete replace
fill ~261 ~50 ~32 ~261 ~50 ~364 minecraft:light_gray_concrete replace
fill ~258 ~50 ~36 ~258 ~50 ~376 minecraft:light_gray_concrete replace
fill ~213 ~50 ~40 ~213 ~50 ~344 minecraft:light_gray_concrete replace
fill ~273 ~50 ~72 ~273 ~50 ~76 minecraft:light_gray_concrete replace
fill ~93 ~50 ~240 ~93 ~50 ~248 minecraft:light_gray_concrete replace
fill ~117 ~50 ~260 ~117 ~50 ~268 minecraft:light_gray_concrete replace
fill ~138 ~50 ~276 ~138 ~50 ~284 minecraft:light_gray_concrete replace
fill ~156 ~50 ~288 ~156 ~50 ~296 minecraft:light_gray_concrete replace
fill ~192 ~50 ~308 ~192 ~50 ~328 minecraft:light_gray_concrete replace
fill ~171 ~50 ~312 ~171 ~50 ~320 minecraft:light_gray_concrete replace
fill ~195 ~50 ~336 ~195 ~50 ~340 minecraft:light_gray_concrete replace
fill ~216 ~50 ~352 ~216 ~50 ~356 minecraft:light_gray_concrete replace
fill ~264 ~50 ~364 ~264 ~50 ~368 minecraft:light_gray_concrete replace
fill ~234 ~50 ~380 ~234 ~50 ~384 minecraft:light_gray_concrete replace
fill ~288 ~50 ~384 ~288 ~50 ~388 minecraft:light_gray_concrete replace
fill ~309 ~50 ~388 ~309 ~50 ~392 minecraft:light_gray_concrete replace
fill ~276 ~50 ~392 ~276 ~50 ~396 minecraft:light_gray_concrete replace
fill ~300 ~50 ~396 ~300 ~50 ~400 minecraft:light_gray_concrete replace
fill ~270 ~50 ~400 ~270 ~50 ~404 minecraft:light_gray_concrete replace
fill ~90 ~50 ~408 ~90 ~50 ~412 minecraft:light_gray_concrete replace
fill ~114 ~50 ~412 ~114 ~50 ~416 minecraft:light_gray_concrete replace
fill ~135 ~50 ~416 ~135 ~50 ~420 minecraft:light_gray_concrete replace
fill ~162 ~50 ~420 ~162 ~50 ~424 minecraft:light_gray_concrete replace
fill ~183 ~50 ~424 ~183 ~50 ~428 minecraft:light_gray_concrete replace
fill ~207 ~50 ~428 ~207 ~50 ~432 minecraft:light_gray_concrete replace
fill ~231 ~50 ~432 ~231 ~50 ~436 minecraft:light_gray_concrete replace
fill ~252 ~50 ~436 ~252 ~50 ~440 minecraft:light_gray_concrete replace
fill ~267 ~50 ~440 ~267 ~50 ~444 minecraft:light_gray_concrete replace
fill ~87 ~50 ~444 ~87 ~50 ~448 minecraft:light_gray_concrete replace
fill ~111 ~50 ~448 ~111 ~50 ~452 minecraft:light_gray_concrete replace
fill ~132 ~50 ~452 ~132 ~50 ~456 minecraft:light_gray_concrete replace
fill ~159 ~50 ~456 ~159 ~50 ~460 minecraft:light_gray_concrete replace
fill ~180 ~50 ~460 ~180 ~50 ~464 minecraft:light_gray_concrete replace
fill ~204 ~50 ~464 ~204 ~50 ~468 minecraft:light_gray_concrete replace
fill ~228 ~50 ~468 ~228 ~50 ~472 minecraft:light_gray_concrete replace
fill ~249 ~50 ~472 ~249 ~50 ~476 minecraft:light_gray_concrete replace
fill ~291 ~50 ~476 ~291 ~50 ~480 minecraft:light_gray_concrete replace
fill ~315 ~50 ~480 ~315 ~50 ~484 minecraft:light_gray_concrete replace
fill ~84 ~50 ~484 ~84 ~50 ~488 minecraft:light_gray_concrete replace
fill ~108 ~50 ~488 ~108 ~50 ~492 minecraft:light_gray_concrete replace
fill ~129 ~50 ~492 ~129 ~50 ~496 minecraft:light_gray_concrete replace
fill ~153 ~50 ~496 ~153 ~50 ~500 minecraft:light_gray_concrete replace
fill ~177 ~50 ~500 ~177 ~50 ~504 minecraft:light_gray_concrete replace
fill ~201 ~50 ~504 ~201 ~50 ~508 minecraft:light_gray_concrete replace
fill ~225 ~50 ~508 ~225 ~50 ~512 minecraft:light_gray_concrete replace
fill ~246 ~50 ~512 ~246 ~50 ~516 minecraft:light_gray_concrete replace
fill ~285 ~50 ~516 ~285 ~50 ~520 minecraft:light_gray_concrete replace
fill ~312 ~50 ~520 ~312 ~50 ~524 minecraft:light_gray_concrete replace
fill ~81 ~50 ~524 ~81 ~50 ~528 minecraft:light_gray_concrete replace
fill ~105 ~50 ~528 ~105 ~50 ~532 minecraft:light_gray_concrete replace
fill ~126 ~50 ~532 ~126 ~50 ~536 minecraft:light_gray_concrete replace
fill ~147 ~50 ~536 ~147 ~50 ~540 minecraft:light_gray_concrete replace
fill ~174 ~50 ~540 ~174 ~50 ~544 minecraft:light_gray_concrete replace
fill ~198 ~50 ~544 ~198 ~50 ~548 minecraft:light_gray_concrete replace
fill ~222 ~50 ~548 ~222 ~50 ~552 minecraft:light_gray_concrete replace
fill ~240 ~50 ~552 ~240 ~50 ~556 minecraft:light_gray_concrete replace
fill ~282 ~50 ~556 ~282 ~50 ~560 minecraft:light_gray_concrete replace
fill ~306 ~50 ~560 ~306 ~50 ~564 minecraft:light_gray_concrete replace
fill ~78 ~50 ~564 ~78 ~50 ~568 minecraft:light_gray_concrete replace
fill ~102 ~50 ~568 ~102 ~50 ~572 minecraft:light_gray_concrete replace
fill ~123 ~50 ~572 ~123 ~50 ~576 minecraft:light_gray_concrete replace
fill ~144 ~50 ~576 ~144 ~50 ~580 minecraft:light_gray_concrete replace
fill ~168 ~50 ~580 ~168 ~50 ~584 minecraft:light_gray_concrete replace
fill ~189 ~50 ~584 ~189 ~50 ~588 minecraft:light_gray_concrete replace
fill ~219 ~50 ~588 ~219 ~50 ~592 minecraft:light_gray_concrete replace
fill ~237 ~50 ~592 ~237 ~50 ~596 minecraft:light_gray_concrete replace
fill ~279 ~50 ~596 ~279 ~50 ~600 minecraft:light_gray_concrete replace
fill ~303 ~50 ~600 ~303 ~50 ~604 minecraft:light_gray_concrete replace
fill ~99 ~50 ~604 ~99 ~50 ~608 minecraft:light_gray_concrete replace
fill ~120 ~50 ~608 ~120 ~50 ~612 minecraft:light_gray_concrete replace
fill ~141 ~50 ~612 ~141 ~50 ~616 minecraft:light_gray_concrete replace
fill ~165 ~50 ~616 ~165 ~50 ~620 minecraft:light_gray_concrete replace
fill ~186 ~50 ~620 ~186 ~50 ~624 minecraft:light_gray_concrete replace
fill ~210 ~50 ~624 ~210 ~50 ~628 minecraft:light_gray_concrete replace
fill ~243 ~50 ~628 ~243 ~50 ~632 minecraft:light_gray_concrete replace
fill ~255 ~50 ~632 ~255 ~50 ~636 minecraft:light_gray_concrete replace
fill ~294 ~50 ~636 ~294 ~50 ~640 minecraft:light_gray_concrete replace
fill ~150 ~50 ~640 ~150 ~50 ~644 minecraft:light_gray_concrete replace
fill ~321 ~50 ~644 ~321 ~50 ~648 minecraft:light_gray_concrete replace
fill ~96 ~50 ~648 ~96 ~50 ~652 minecraft:light_gray_concrete replace
fill ~297 ~50 ~652 ~297 ~50 ~656 minecraft:light_gray_concrete replace
fill ~318 ~50 ~656 ~318 ~50 ~660 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~32 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~36 minecraft:light_gray_concrete replace
setblock ~214 ~51 ~40 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~44 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~48 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~53 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~55 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~56 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~59 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~61 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~63 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~65 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~69 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~71 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~75 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~77 minecraft:light_gray_concrete replace
setblock ~273 ~51 ~77 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~79 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~81 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~85 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~87 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~91 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~93 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~95 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~97 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~101 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~103 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~107 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~109 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~111 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~113 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~117 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~119 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~123 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~125 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~127 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~129 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~133 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~135 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~139 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~141 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~143 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~145 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~149 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~151 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~155 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~157 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~159 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~161 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~165 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~167 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~171 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~173 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~175 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~177 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~181 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~183 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~187 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~189 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~191 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~193 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~197 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~199 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~203 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~205 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~207 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~209 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~213 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~215 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~219 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~221 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~223 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~225 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~229 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~231 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~235 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~237 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~239 minecraft:light_gray_concrete replace
setblock ~94 ~51 ~240 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~241 minecraft:light_gray_concrete replace
setblock ~94 ~51 ~244 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~245 minecraft:light_gray_concrete replace
setblock ~93 ~51 ~247 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~247 minecraft:light_gray_concrete replace
setblock ~93 ~51 ~249 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~251 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~253 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~255 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~257 minecraft:light_gray_concrete replace
setblock ~118 ~51 ~260 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~261 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~263 minecraft:light_gray_concrete replace
setblock ~118 ~51 ~264 minecraft:light_gray_concrete replace
setblock ~117 ~51 ~267 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~267 minecraft:light_gray_concrete replace
setblock ~117 ~51 ~269 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~269 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~271 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~273 minecraft:light_gray_concrete replace
setblock ~139 ~51 ~276 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~277 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~279 minecraft:light_gray_concrete replace
setblock ~139 ~51 ~280 minecraft:light_gray_concrete replace
setblock ~138 ~51 ~283 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~283 minecraft:light_gray_concrete replace
setblock ~138 ~51 ~285 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~285 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~287 minecraft:light_gray_concrete replace
setblock ~157 ~51 ~288 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~289 minecraft:light_gray_concrete replace
setblock ~157 ~51 ~292 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~293 minecraft:light_gray_concrete replace
setblock ~156 ~51 ~295 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~295 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~296 minecraft:light_gray_concrete replace
setblock ~156 ~51 ~297 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~299 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~300 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~301 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~303 minecraft:light_gray_concrete replace
setblock ~214 ~51 ~304 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~305 minecraft:light_gray_concrete replace
setblock ~193 ~51 ~308 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~309 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~311 minecraft:light_gray_concrete replace
setblock ~172 ~51 ~312 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~315 minecraft:light_gray_concrete replace
setblock ~172 ~51 ~316 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~317 minecraft:light_gray_concrete replace
setblock ~171 ~51 ~319 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~319 minecraft:light_gray_concrete replace
setblock ~171 ~51 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~51 ~321 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~51 ~323 minecraft:light_gray_concrete replace
setblock ~193 ~51 ~324 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~325 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~327 minecraft:light_gray_concrete replace
setblock ~192 ~51 ~329 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~331 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~333 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~335 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~337 minecraft:light_gray_concrete replace
setblock ~214 ~51 ~340 minecraft:light_gray_concrete replace
setblock ~195 ~51 ~341 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~345 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~347 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~349 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~351 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~353 minecraft:light_gray_concrete replace
setblock ~216 ~51 ~357 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~360 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~365 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~367 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~369 minecraft:light_gray_concrete replace
setblock ~264 ~51 ~369 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~372 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~377 minecraft:light_gray_concrete replace
setblock ~234 ~51 ~385 minecraft:light_gray_concrete replace
setblock ~288 ~51 ~389 minecraft:light_gray_concrete replace
setblock ~309 ~51 ~393 minecraft:light_gray_concrete replace
setblock ~276 ~51 ~397 minecraft:light_gray_concrete replace
setblock ~300 ~51 ~401 minecraft:light_gray_concrete replace
setblock ~270 ~51 ~405 minecraft:light_gray_concrete replace
setblock ~90 ~51 ~413 minecraft:light_gray_concrete replace
setblock ~114 ~51 ~417 minecraft:light_gray_concrete replace
setblock ~135 ~51 ~421 minecraft:light_gray_concrete replace
setblock ~162 ~51 ~425 minecraft:light_gray_concrete replace
setblock ~183 ~51 ~429 minecraft:light_gray_concrete replace
setblock ~207 ~51 ~433 minecraft:light_gray_concrete replace
setblock ~231 ~51 ~437 minecraft:light_gray_concrete replace
setblock ~252 ~51 ~441 minecraft:light_gray_concrete replace
setblock ~267 ~51 ~445 minecraft:light_gray_concrete replace
setblock ~87 ~51 ~449 minecraft:light_gray_concrete replace
setblock ~111 ~51 ~453 minecraft:light_gray_concrete replace
setblock ~132 ~51 ~457 minecraft:light_gray_concrete replace
setblock ~159 ~51 ~461 minecraft:light_gray_concrete replace
setblock ~180 ~51 ~465 minecraft:light_gray_concrete replace
setblock ~204 ~51 ~469 minecraft:light_gray_concrete replace
setblock ~228 ~51 ~473 minecraft:light_gray_concrete replace
setblock ~249 ~51 ~477 minecraft:light_gray_concrete replace
setblock ~291 ~51 ~481 minecraft:light_gray_concrete replace
setblock ~315 ~51 ~485 minecraft:light_gray_concrete replace
setblock ~84 ~51 ~489 minecraft:light_gray_concrete replace
setblock ~108 ~51 ~493 minecraft:light_gray_concrete replace
setblock ~129 ~51 ~497 minecraft:light_gray_concrete replace
setblock ~153 ~51 ~501 minecraft:light_gray_concrete replace
setblock ~177 ~51 ~505 minecraft:light_gray_concrete replace
setblock ~201 ~51 ~509 minecraft:light_gray_concrete replace
setblock ~225 ~51 ~513 minecraft:light_gray_concrete replace
setblock ~246 ~51 ~517 minecraft:light_gray_concrete replace
setblock ~285 ~51 ~521 minecraft:light_gray_concrete replace
setblock ~312 ~51 ~525 minecraft:light_gray_concrete replace
setblock ~81 ~51 ~529 minecraft:light_gray_concrete replace
setblock ~105 ~51 ~533 minecraft:light_gray_concrete replace
setblock ~126 ~51 ~537 minecraft:light_gray_concrete replace
setblock ~147 ~51 ~541 minecraft:light_gray_concrete replace
setblock ~174 ~51 ~545 minecraft:light_gray_concrete replace
setblock ~198 ~51 ~549 minecraft:light_gray_concrete replace
setblock ~222 ~51 ~553 minecraft:light_gray_concrete replace
setblock ~240 ~51 ~557 minecraft:light_gray_concrete replace
setblock ~282 ~51 ~561 minecraft:light_gray_concrete replace
setblock ~306 ~51 ~565 minecraft:light_gray_concrete replace
setblock ~78 ~51 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~51 ~573 minecraft:light_gray_concrete replace
setblock ~123 ~51 ~577 minecraft:light_gray_concrete replace
setblock ~144 ~51 ~581 minecraft:light_gray_concrete replace
setblock ~168 ~51 ~585 minecraft:light_gray_concrete replace
setblock ~189 ~51 ~589 minecraft:light_gray_concrete replace
setblock ~219 ~51 ~593 minecraft:light_gray_concrete replace
setblock ~237 ~51 ~597 minecraft:light_gray_concrete replace
setblock ~279 ~51 ~601 minecraft:light_gray_concrete replace
setblock ~303 ~51 ~605 minecraft:light_gray_concrete replace
setblock ~99 ~51 ~609 minecraft:light_gray_concrete replace
setblock ~120 ~51 ~613 minecraft:light_gray_concrete replace
setblock ~141 ~51 ~617 minecraft:light_gray_concrete replace
setblock ~165 ~51 ~621 minecraft:light_gray_concrete replace
setblock ~186 ~51 ~625 minecraft:light_gray_concrete replace
setblock ~210 ~51 ~629 minecraft:light_gray_concrete replace
setblock ~243 ~51 ~633 minecraft:light_gray_concrete replace
setblock ~255 ~51 ~637 minecraft:light_gray_concrete replace
setblock ~294 ~51 ~641 minecraft:light_gray_concrete replace
setblock ~150 ~51 ~645 minecraft:light_gray_concrete replace
setblock ~321 ~51 ~649 minecraft:light_gray_concrete replace
setblock ~96 ~51 ~653 minecraft:light_gray_concrete replace
setblock ~297 ~51 ~657 minecraft:light_gray_concrete replace
setblock ~318 ~51 ~661 minecraft:light_gray_concrete replace
fill ~273 ~52 ~78 ~275 ~52 ~78 minecraft:light_gray_concrete replace
fill ~274 ~52 ~79 ~274 ~52 ~80 minecraft:light_gray_concrete replace
fill ~93 ~52 ~250 ~95 ~52 ~250 minecraft:light_gray_concrete replace
fill ~94 ~52 ~251 ~94 ~52 ~252 minecraft:light_gray_concrete replace
fill ~117 ~52 ~270 ~119 ~52 ~270 minecraft:light_gray_concrete replace
fill ~118 ~52 ~271 ~118 ~52 ~272 minecraft:light_gray_concrete replace
fill ~138 ~52 ~286 ~140 ~52 ~286 minecraft:light_gray_concrete replace
fill ~139 ~52 ~287 ~139 ~52 ~288 minecraft:light_gray_concrete replace
fill ~153 ~52 ~298 ~156 ~52 ~298 minecraft:light_gray_concrete replace
fill ~154 ~52 ~299 ~154 ~52 ~300 minecraft:light_gray_concrete replace
fill ~168 ~52 ~322 ~171 ~52 ~322 minecraft:light_gray_concrete replace
fill ~169 ~52 ~323 ~169 ~52 ~324 minecraft:light_gray_concrete replace
fill ~189 ~52 ~330 ~194 ~52 ~330 minecraft:light_gray_concrete replace
fill ~190 ~52 ~331 ~190 ~52 ~332 minecraft:light_gray_concrete replace
fill ~193 ~52 ~331 ~193 ~52 ~332 minecraft:light_gray_concrete replace
fill ~189 ~52 ~342 ~195 ~52 ~342 minecraft:light_gray_concrete replace
fill ~190 ~52 ~343 ~190 ~52 ~344 minecraft:light_gray_concrete replace
fill ~193 ~52 ~343 ~193 ~52 ~344 minecraft:light_gray_concrete replace
fill ~210 ~52 ~346 ~215 ~52 ~346 minecraft:light_gray_concrete replace
fill ~211 ~52 ~347 ~211 ~52 ~348 minecraft:light_gray_concrete replace
fill ~214 ~52 ~347 ~214 ~52 ~348 minecraft:light_gray_concrete replace
fill ~210 ~52 ~358 ~216 ~52 ~358 minecraft:light_gray_concrete replace
fill ~211 ~52 ~359 ~211 ~52 ~360 minecraft:light_gray_concrete replace
fill ~214 ~52 ~359 ~214 ~52 ~360 minecraft:light_gray_concrete replace
fill ~261 ~52 ~366 ~266 ~52 ~366 minecraft:light_gray_concrete replace
fill ~262 ~52 ~367 ~262 ~52 ~368 minecraft:light_gray_concrete replace
fill ~265 ~52 ~367 ~265 ~52 ~368 minecraft:light_gray_concrete replace
fill ~261 ~52 ~370 ~266 ~52 ~370 minecraft:light_gray_concrete replace
fill ~262 ~52 ~371 ~262 ~52 ~372 minecraft:light_gray_concrete replace
fill ~265 ~52 ~371 ~265 ~52 ~372 minecraft:light_gray_concrete replace
fill ~234 ~52 ~378 ~308 ~52 ~378 minecraft:light_gray_concrete replace
fill ~235 ~52 ~379 ~235 ~52 ~380 minecraft:light_gray_concrete replace
fill ~238 ~52 ~379 ~238 ~52 ~380 minecraft:light_gray_concrete replace
fill ~271 ~52 ~379 ~271 ~52 ~380 minecraft:light_gray_concrete replace
fill ~307 ~52 ~379 ~307 ~52 ~380 minecraft:light_gray_concrete replace
fill ~234 ~52 ~386 ~239 ~52 ~386 minecraft:light_gray_concrete replace
fill ~235 ~52 ~387 ~235 ~52 ~388 minecraft:light_gray_concrete replace
fill ~238 ~52 ~387 ~238 ~52 ~388 minecraft:light_gray_concrete replace
fill ~270 ~52 ~390 ~308 ~52 ~390 minecraft:light_gray_concrete replace
fill ~271 ~52 ~391 ~271 ~52 ~392 minecraft:light_gray_concrete replace
fill ~307 ~52 ~391 ~307 ~52 ~392 minecraft:light_gray_concrete replace
fill ~309 ~52 ~394 ~311 ~52 ~394 minecraft:light_gray_concrete replace
fill ~310 ~52 ~395 ~310 ~52 ~396 minecraft:light_gray_concrete replace
fill ~276 ~52 ~398 ~278 ~52 ~398 minecraft:light_gray_concrete replace
fill ~277 ~52 ~399 ~277 ~52 ~400 minecraft:light_gray_concrete replace
fill ~297 ~52 ~402 ~300 ~52 ~402 minecraft:light_gray_concrete replace
fill ~298 ~52 ~403 ~298 ~52 ~404 minecraft:light_gray_concrete replace
fill ~270 ~52 ~406 ~272 ~52 ~406 minecraft:light_gray_concrete replace
fill ~271 ~52 ~407 ~271 ~52 ~408 minecraft:light_gray_concrete replace
fill ~90 ~52 ~414 ~92 ~52 ~414 minecraft:light_gray_concrete replace
fill ~91 ~52 ~415 ~91 ~52 ~416 minecraft:light_gray_concrete replace
fill ~114 ~52 ~418 ~116 ~52 ~418 minecraft:light_gray_concrete replace
fill ~115 ~52 ~419 ~115 ~52 ~420 minecraft:light_gray_concrete replace
fill ~135 ~52 ~422 ~137 ~52 ~422 minecraft:light_gray_concrete replace
fill ~136 ~52 ~423 ~136 ~52 ~424 minecraft:light_gray_concrete replace
fill ~159 ~52 ~426 ~162 ~52 ~426 minecraft:light_gray_concrete replace
fill ~160 ~52 ~427 ~160 ~52 ~428 minecraft:light_gray_concrete replace
fill ~180 ~52 ~430 ~183 ~52 ~430 minecraft:light_gray_concrete replace
fill ~181 ~52 ~431 ~181 ~52 ~432 minecraft:light_gray_concrete replace
fill ~204 ~52 ~434 ~207 ~52 ~434 minecraft:light_gray_concrete replace
fill ~205 ~52 ~435 ~205 ~52 ~436 minecraft:light_gray_concrete replace
fill ~231 ~52 ~438 ~233 ~52 ~438 minecraft:light_gray_concrete replace
fill ~232 ~52 ~439 ~232 ~52 ~440 minecraft:light_gray_concrete replace
fill ~252 ~52 ~442 ~257 ~52 ~442 minecraft:light_gray_concrete replace
fill ~256 ~52 ~443 ~256 ~52 ~444 minecraft:light_gray_concrete replace
fill ~267 ~52 ~446 ~269 ~52 ~446 minecraft:light_gray_concrete replace
fill ~268 ~52 ~447 ~268 ~52 ~448 minecraft:light_gray_concrete replace
fill ~87 ~52 ~450 ~89 ~52 ~450 minecraft:light_gray_concrete replace
fill ~88 ~52 ~451 ~88 ~52 ~452 minecraft:light_gray_concrete replace
fill ~111 ~52 ~454 ~113 ~52 ~454 minecraft:light_gray_concrete replace
fill ~112 ~52 ~455 ~112 ~52 ~456 minecraft:light_gray_concrete replace
fill ~132 ~52 ~458 ~134 ~52 ~458 minecraft:light_gray_concrete replace
fill ~133 ~52 ~459 ~133 ~52 ~460 minecraft:light_gray_concrete replace
fill ~156 ~52 ~462 ~159 ~52 ~462 minecraft:light_gray_concrete replace
fill ~157 ~52 ~463 ~157 ~52 ~464 minecraft:light_gray_concrete replace
fill ~177 ~52 ~466 ~180 ~52 ~466 minecraft:light_gray_concrete replace
fill ~178 ~52 ~467 ~178 ~52 ~468 minecraft:light_gray_concrete replace
fill ~201 ~52 ~470 ~204 ~52 ~470 minecraft:light_gray_concrete replace
fill ~202 ~52 ~471 ~202 ~52 ~472 minecraft:light_gray_concrete replace
fill ~225 ~52 ~474 ~228 ~52 ~474 minecraft:light_gray_concrete replace
fill ~226 ~52 ~475 ~226 ~52 ~476 minecraft:light_gray_concrete replace
fill ~249 ~52 ~478 ~254 ~52 ~478 minecraft:light_gray_concrete replace
fill ~253 ~52 ~479 ~253 ~52 ~480 minecraft:light_gray_concrete replace
fill ~288 ~52 ~482 ~291 ~52 ~482 minecraft:light_gray_concrete replace
fill ~289 ~52 ~483 ~289 ~52 ~484 minecraft:light_gray_concrete replace
fill ~315 ~52 ~486 ~317 ~52 ~486 minecraft:light_gray_concrete replace
fill ~316 ~52 ~487 ~316 ~52 ~488 minecraft:light_gray_concrete replace
fill ~84 ~52 ~490 ~86 ~52 ~490 minecraft:light_gray_concrete replace
fill ~85 ~52 ~491 ~85 ~52 ~492 minecraft:light_gray_concrete replace
fill ~108 ~52 ~494 ~110 ~52 ~494 minecraft:light_gray_concrete replace
fill ~109 ~52 ~495 ~109 ~52 ~496 minecraft:light_gray_concrete replace
fill ~129 ~52 ~498 ~131 ~52 ~498 minecraft:light_gray_concrete replace
fill ~130 ~52 ~499 ~130 ~52 ~500 minecraft:light_gray_concrete replace
fill ~150 ~52 ~502 ~153 ~52 ~502 minecraft:light_gray_concrete replace
fill ~151 ~52 ~503 ~151 ~52 ~504 minecraft:light_gray_concrete replace
fill ~174 ~52 ~506 ~177 ~52 ~506 minecraft:light_gray_concrete replace
fill ~175 ~52 ~507 ~175 ~52 ~508 minecraft:light_gray_concrete replace
fill ~198 ~52 ~510 ~201 ~52 ~510 minecraft:light_gray_concrete replace
fill ~199 ~52 ~511 ~199 ~52 ~512 minecraft:light_gray_concrete replace
fill ~222 ~52 ~514 ~225 ~52 ~514 minecraft:light_gray_concrete replace
fill ~223 ~52 ~515 ~223 ~52 ~516 minecraft:light_gray_concrete replace
fill ~246 ~52 ~518 ~251 ~52 ~518 minecraft:light_gray_concrete replace
fill ~250 ~52 ~519 ~250 ~52 ~520 minecraft:light_gray_concrete replace
fill ~285 ~52 ~522 ~287 ~52 ~522 minecraft:light_gray_concrete replace
fill ~286 ~52 ~523 ~286 ~52 ~524 minecraft:light_gray_concrete replace
fill ~312 ~52 ~526 ~314 ~52 ~526 minecraft:light_gray_concrete replace
fill ~313 ~52 ~527 ~313 ~52 ~528 minecraft:light_gray_concrete replace
fill ~81 ~52 ~530 ~83 ~52 ~530 minecraft:light_gray_concrete replace
fill ~82 ~52 ~531 ~82 ~52 ~532 minecraft:light_gray_concrete replace
fill ~105 ~52 ~534 ~107 ~52 ~534 minecraft:light_gray_concrete replace
fill ~106 ~52 ~535 ~106 ~52 ~536 minecraft:light_gray_concrete replace
fill ~126 ~52 ~538 ~128 ~52 ~538 minecraft:light_gray_concrete replace
fill ~127 ~52 ~539 ~127 ~52 ~540 minecraft:light_gray_concrete replace
fill ~147 ~52 ~542 ~149 ~52 ~542 minecraft:light_gray_concrete replace
fill ~148 ~52 ~543 ~148 ~52 ~544 minecraft:light_gray_concrete replace
fill ~171 ~52 ~546 ~174 ~52 ~546 minecraft:light_gray_concrete replace
fill ~172 ~52 ~547 ~172 ~52 ~548 minecraft:light_gray_concrete replace
fill ~195 ~52 ~550 ~198 ~52 ~550 minecraft:light_gray_concrete replace
fill ~196 ~52 ~551 ~196 ~52 ~552 minecraft:light_gray_concrete replace
fill ~219 ~52 ~554 ~222 ~52 ~554 minecraft:light_gray_concrete replace
fill ~220 ~52 ~555 ~220 ~52 ~556 minecraft:light_gray_concrete replace
fill ~240 ~52 ~558 ~245 ~52 ~558 minecraft:light_gray_concrete replace
fill ~244 ~52 ~559 ~244 ~52 ~560 minecraft:light_gray_concrete replace
fill ~282 ~52 ~562 ~284 ~52 ~562 minecraft:light_gray_concrete replace
fill ~283 ~52 ~563 ~283 ~52 ~564 minecraft:light_gray_concrete replace
fill ~303 ~52 ~566 ~306 ~52 ~566 minecraft:light_gray_concrete replace
fill ~304 ~52 ~567 ~304 ~52 ~568 minecraft:light_gray_concrete replace
fill ~78 ~52 ~570 ~80 ~52 ~570 minecraft:light_gray_concrete replace
fill ~79 ~52 ~571 ~79 ~52 ~572 minecraft:light_gray_concrete replace
fill ~102 ~52 ~574 ~104 ~52 ~574 minecraft:light_gray_concrete replace
fill ~103 ~52 ~575 ~103 ~52 ~576 minecraft:light_gray_concrete replace
fill ~123 ~52 ~578 ~125 ~52 ~578 minecraft:light_gray_concrete replace
fill ~124 ~52 ~579 ~124 ~52 ~580 minecraft:light_gray_concrete replace
fill ~144 ~52 ~582 ~146 ~52 ~582 minecraft:light_gray_concrete replace
fill ~145 ~52 ~583 ~145 ~52 ~584 minecraft:light_gray_concrete replace
fill ~165 ~52 ~586 ~168 ~52 ~586 minecraft:light_gray_concrete replace
fill ~166 ~52 ~587 ~166 ~52 ~588 minecraft:light_gray_concrete replace
fill ~186 ~52 ~590 ~189 ~52 ~590 minecraft:light_gray_concrete replace
fill ~187 ~52 ~591 ~187 ~52 ~592 minecraft:light_gray_concrete replace
fill ~216 ~52 ~594 ~219 ~52 ~594 minecraft:light_gray_concrete replace
fill ~217 ~52 ~595 ~217 ~52 ~596 minecraft:light_gray_concrete replace
fill ~237 ~52 ~598 ~242 ~52 ~598 minecraft:light_gray_concrete replace
fill ~241 ~52 ~599 ~241 ~52 ~600 minecraft:light_gray_concrete replace
fill ~279 ~52 ~602 ~281 ~52 ~602 minecraft:light_gray_concrete replace
fill ~280 ~52 ~603 ~280 ~52 ~604 minecraft:light_gray_concrete replace
fill ~300 ~52 ~606 ~303 ~52 ~606 minecraft:light_gray_concrete replace
fill ~301 ~52 ~607 ~301 ~52 ~608 minecraft:light_gray_concrete replace
fill ~99 ~52 ~610 ~101 ~52 ~610 minecraft:light_gray_concrete replace
fill ~100 ~52 ~611 ~100 ~52 ~612 minecraft:light_gray_concrete replace
fill ~120 ~52 ~614 ~122 ~52 ~614 minecraft:light_gray_concrete replace
fill ~121 ~52 ~615 ~121 ~52 ~616 minecraft:light_gray_concrete replace
fill ~141 ~52 ~618 ~143 ~52 ~618 minecraft:light_gray_concrete replace
fill ~142 ~52 ~619 ~142 ~52 ~620 minecraft:light_gray_concrete replace
fill ~162 ~52 ~622 ~165 ~52 ~622 minecraft:light_gray_concrete replace
fill ~163 ~52 ~623 ~163 ~52 ~624 minecraft:light_gray_concrete replace
fill ~183 ~52 ~626 ~186 ~52 ~626 minecraft:light_gray_concrete replace
fill ~184 ~52 ~627 ~184 ~52 ~628 minecraft:light_gray_concrete replace
fill ~207 ~52 ~630 ~210 ~52 ~630 minecraft:light_gray_concrete replace
fill ~208 ~52 ~631 ~208 ~52 ~632 minecraft:light_gray_concrete replace
fill ~243 ~52 ~634 ~248 ~52 ~634 minecraft:light_gray_concrete replace
fill ~247 ~52 ~635 ~247 ~52 ~636 minecraft:light_gray_concrete replace
fill ~255 ~52 ~638 ~260 ~52 ~638 minecraft:light_gray_concrete replace
fill ~259 ~52 ~639 ~259 ~52 ~640 minecraft:light_gray_concrete replace
fill ~291 ~52 ~642 ~294 ~52 ~642 minecraft:light_gray_concrete replace
fill ~292 ~52 ~643 ~292 ~52 ~644 minecraft:light_gray_concrete replace
fill ~93 ~52 ~646 ~230 ~52 ~646 minecraft:light_gray_concrete replace
fill ~94 ~52 ~647 ~94 ~52 ~648 minecraft:light_gray_concrete replace
fill ~118 ~52 ~647 ~118 ~52 ~648 minecraft:light_gray_concrete replace
fill ~139 ~52 ~647 ~139 ~52 ~648 minecraft:light_gray_concrete replace
fill ~154 ~52 ~647 ~154 ~52 ~648 minecraft:light_gray_concrete replace
fill ~169 ~52 ~647 ~169 ~52 ~648 minecraft:light_gray_concrete replace
fill ~229 ~52 ~647 ~229 ~52 ~648 minecraft:light_gray_concrete replace
fill ~321 ~52 ~650 ~323 ~52 ~650 minecraft:light_gray_concrete replace
fill ~322 ~52 ~651 ~322 ~52 ~652 minecraft:light_gray_concrete replace
fill ~96 ~52 ~654 ~98 ~52 ~654 minecraft:light_gray_concrete replace
fill ~97 ~52 ~655 ~97 ~52 ~656 minecraft:light_gray_concrete replace
fill ~294 ~52 ~658 ~297 ~52 ~658 minecraft:light_gray_concrete replace
fill ~295 ~52 ~659 ~295 ~52 ~660 minecraft:light_gray_concrete replace
fill ~318 ~52 ~662 ~320 ~52 ~662 minecraft:light_gray_concrete replace
fill ~319 ~52 ~663 ~319 ~52 ~664 minecraft:light_gray_concrete replace
