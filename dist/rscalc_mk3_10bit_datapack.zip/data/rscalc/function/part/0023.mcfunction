fill ~213 ~43 ~504 ~213 ~43 ~508 minecraft:redstone_wire replace
fill ~243 ~43 ~508 ~243 ~43 ~512 minecraft:redstone_wire replace
fill ~270 ~43 ~512 ~270 ~43 ~516 minecraft:redstone_wire replace
fill ~330 ~43 ~516 ~330 ~43 ~520 minecraft:redstone_wire replace
fill ~357 ~43 ~520 ~357 ~43 ~524 minecraft:redstone_wire replace
fill ~81 ~43 ~524 ~81 ~43 ~528 minecraft:redstone_wire replace
fill ~108 ~43 ~528 ~108 ~43 ~532 minecraft:redstone_wire replace
fill ~132 ~43 ~532 ~132 ~43 ~536 minecraft:redstone_wire replace
fill ~156 ~43 ~536 ~156 ~43 ~540 minecraft:redstone_wire replace
fill ~186 ~43 ~540 ~186 ~43 ~544 minecraft:redstone_wire replace
fill ~210 ~43 ~544 ~210 ~43 ~548 minecraft:redstone_wire replace
fill ~240 ~43 ~548 ~240 ~43 ~552 minecraft:redstone_wire replace
fill ~261 ~43 ~552 ~261 ~43 ~556 minecraft:redstone_wire replace
fill ~327 ~43 ~556 ~327 ~43 ~560 minecraft:redstone_wire replace
fill ~351 ~43 ~560 ~351 ~43 ~564 minecraft:redstone_wire replace
fill ~78 ~43 ~564 ~78 ~43 ~568 minecraft:redstone_wire replace
fill ~105 ~43 ~568 ~105 ~43 ~572 minecraft:redstone_wire replace
fill ~129 ~43 ~572 ~129 ~43 ~576 minecraft:redstone_wire replace
fill ~153 ~43 ~576 ~153 ~43 ~580 minecraft:redstone_wire replace
fill ~180 ~43 ~580 ~180 ~43 ~584 minecraft:redstone_wire replace
fill ~201 ~43 ~584 ~201 ~43 ~588 minecraft:redstone_wire replace
fill ~237 ~43 ~588 ~237 ~43 ~592 minecraft:redstone_wire replace
fill ~258 ~43 ~592 ~258 ~43 ~596 minecraft:redstone_wire replace
fill ~324 ~43 ~596 ~324 ~43 ~600 minecraft:redstone_wire replace
fill ~348 ~43 ~600 ~348 ~43 ~604 minecraft:redstone_wire replace
fill ~102 ~43 ~604 ~102 ~43 ~608 minecraft:redstone_wire replace
fill ~126 ~43 ~608 ~126 ~43 ~612 minecraft:redstone_wire replace
fill ~150 ~43 ~612 ~150 ~43 ~616 minecraft:redstone_wire replace
fill ~177 ~43 ~616 ~177 ~43 ~620 minecraft:redstone_wire replace
fill ~198 ~43 ~620 ~198 ~43 ~624 minecraft:redstone_wire replace
fill ~222 ~43 ~624 ~222 ~43 ~628 minecraft:redstone_wire replace
fill ~264 ~43 ~628 ~264 ~43 ~632 minecraft:redstone_wire replace
fill ~279 ~43 ~632 ~279 ~43 ~636 minecraft:redstone_wire replace
fill ~339 ~43 ~636 ~339 ~43 ~640 minecraft:redstone_wire replace
fill ~159 ~43 ~640 ~159 ~43 ~644 minecraft:redstone_wire replace
fill ~366 ~43 ~644 ~366 ~43 ~648 minecraft:redstone_wire replace
fill ~99 ~43 ~648 ~99 ~43 ~652 minecraft:redstone_wire replace
fill ~342 ~43 ~652 ~342 ~43 ~656 minecraft:redstone_wire replace
fill ~363 ~43 ~656 ~363 ~43 ~660 minecraft:redstone_wire replace
setblock ~300 ~44 ~37 minecraft:redstone_wire replace
setblock ~285 ~44 ~41 minecraft:redstone_wire replace
setblock ~228 ~44 ~45 minecraft:redstone_wire replace
setblock ~303 ~44 ~49 minecraft:redstone_wire replace
setblock ~288 ~44 ~53 minecraft:redstone_wire replace
setblock ~294 ~44 ~61 minecraft:redstone_wire replace
setblock ~318 ~44 ~77 minecraft:redstone_wire replace
setblock ~93 ~44 ~249 minecraft:redstone_wire replace
setblock ~123 ~44 ~269 minecraft:redstone_wire replace
setblock ~96 ~44 ~277 minecraft:redstone_wire replace
setblock ~120 ~44 ~281 minecraft:redstone_wire replace
setblock ~144 ~44 ~285 minecraft:redstone_wire replace
setblock ~147 ~44 ~297 minecraft:redstone_wire replace
setblock ~165 ~44 ~301 minecraft:redstone_wire replace
setblock ~168 ~44 ~313 minecraft:redstone_wire replace
setblock ~225 ~44 ~321 minecraft:redstone_wire replace
setblock ~183 ~44 ~325 minecraft:redstone_wire replace
setblock ~204 ~44 ~329 minecraft:redstone_wire replace
setblock ~249 ~44 ~333 minecraft:redstone_wire replace
setblock ~207 ~44 ~341 minecraft:redstone_wire replace
setblock ~231 ~44 ~345 minecraft:redstone_wire replace
setblock ~267 ~44 ~349 minecraft:redstone_wire replace
setblock ~234 ~44 ~357 minecraft:redstone_wire replace
setblock ~291 ~44 ~361 minecraft:redstone_wire replace
setblock ~306 ~44 ~365 minecraft:redstone_wire replace
setblock ~309 ~44 ~369 minecraft:redstone_wire replace
setblock ~282 ~44 ~373 minecraft:redstone_wire replace
setblock ~297 ~44 ~377 minecraft:redstone_wire replace
setblock ~255 ~44 ~385 minecraft:redstone_wire replace
setblock ~333 ~44 ~389 minecraft:redstone_wire replace
setblock ~354 ~44 ~393 minecraft:redstone_wire replace
setblock ~321 ~44 ~397 minecraft:redstone_wire replace
setblock ~345 ~44 ~401 minecraft:redstone_wire replace
setblock ~315 ~44 ~405 minecraft:redstone_wire replace
setblock ~90 ~44 ~413 minecraft:redstone_wire replace
setblock ~117 ~44 ~417 minecraft:redstone_wire replace
setblock ~141 ~44 ~421 minecraft:redstone_wire replace
setblock ~174 ~44 ~425 minecraft:redstone_wire replace
setblock ~195 ~44 ~429 minecraft:redstone_wire replace
setblock ~219 ~44 ~433 minecraft:redstone_wire replace
setblock ~252 ~44 ~437 minecraft:redstone_wire replace
setblock ~276 ~44 ~441 minecraft:redstone_wire replace
setblock ~312 ~44 ~445 minecraft:redstone_wire replace
setblock ~87 ~44 ~449 minecraft:redstone_wire replace
setblock ~114 ~44 ~453 minecraft:redstone_wire replace
setblock ~138 ~44 ~457 minecraft:redstone_wire replace
setblock ~171 ~44 ~461 minecraft:redstone_wire replace
setblock ~192 ~44 ~465 minecraft:redstone_wire replace
setblock ~216 ~44 ~469 minecraft:redstone_wire replace
setblock ~246 ~44 ~473 minecraft:redstone_wire replace
setblock ~273 ~44 ~477 minecraft:redstone_wire replace
setblock ~336 ~44 ~481 minecraft:redstone_wire replace
setblock ~360 ~44 ~485 minecraft:redstone_wire replace
setblock ~84 ~44 ~489 minecraft:redstone_wire replace
setblock ~111 ~44 ~493 minecraft:redstone_wire replace
setblock ~135 ~44 ~497 minecraft:redstone_wire replace
setblock ~162 ~44 ~501 minecraft:redstone_wire replace
setblock ~189 ~44 ~505 minecraft:redstone_wire replace
setblock ~213 ~44 ~509 minecraft:redstone_wire replace
setblock ~243 ~44 ~513 minecraft:redstone_wire replace
setblock ~270 ~44 ~517 minecraft:redstone_wire replace
setblock ~330 ~44 ~521 minecraft:redstone_wire replace
setblock ~357 ~44 ~525 minecraft:redstone_wire replace
setblock ~81 ~44 ~529 minecraft:redstone_wire replace
setblock ~108 ~44 ~533 minecraft:redstone_wire replace
setblock ~132 ~44 ~537 minecraft:redstone_wire replace
setblock ~156 ~44 ~541 minecraft:redstone_wire replace
setblock ~186 ~44 ~545 minecraft:redstone_wire replace
setblock ~210 ~44 ~549 minecraft:redstone_wire replace
setblock ~240 ~44 ~553 minecraft:redstone_wire replace
setblock ~261 ~44 ~557 minecraft:redstone_wire replace
setblock ~327 ~44 ~561 minecraft:redstone_wire replace
setblock ~351 ~44 ~565 minecraft:redstone_wire replace
setblock ~78 ~44 ~569 minecraft:redstone_wire replace
setblock ~105 ~44 ~573 minecraft:redstone_wire replace
setblock ~129 ~44 ~577 minecraft:redstone_wire replace
setblock ~153 ~44 ~581 minecraft:redstone_wire replace
setblock ~180 ~44 ~585 minecraft:redstone_wire replace
setblock ~201 ~44 ~589 minecraft:redstone_wire replace
setblock ~237 ~44 ~593 minecraft:redstone_wire replace
setblock ~258 ~44 ~597 minecraft:redstone_wire replace
setblock ~324 ~44 ~601 minecraft:redstone_wire replace
setblock ~348 ~44 ~605 minecraft:redstone_wire replace
setblock ~102 ~44 ~609 minecraft:redstone_wire replace
setblock ~126 ~44 ~613 minecraft:redstone_wire replace
setblock ~150 ~44 ~617 minecraft:redstone_wire replace
setblock ~177 ~44 ~621 minecraft:redstone_wire replace
setblock ~198 ~44 ~625 minecraft:redstone_wire replace
setblock ~222 ~44 ~629 minecraft:redstone_wire replace
setblock ~264 ~44 ~633 minecraft:redstone_wire replace
setblock ~279 ~44 ~637 minecraft:redstone_wire replace
setblock ~339 ~44 ~641 minecraft:redstone_wire replace
setblock ~159 ~44 ~645 minecraft:redstone_wire replace
setblock ~366 ~44 ~649 minecraft:redstone_wire replace
setblock ~99 ~44 ~653 minecraft:redstone_wire replace
setblock ~342 ~44 ~657 minecraft:redstone_wire replace
setblock ~363 ~44 ~661 minecraft:redstone_wire replace
fill ~300 ~45 ~38 ~302 ~45 ~38 minecraft:redstone_wire replace
setblock ~301 ~45 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~45 ~42 ~287 ~45 ~42 minecraft:redstone_wire replace
setblock ~286 ~45 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~45 ~46 ~233 ~45 ~46 minecraft:redstone_wire replace
setblock ~234 ~45 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~45 ~46 ~236 ~45 ~46 minecraft:redstone_wire replace
setblock ~235 ~45 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~45 ~50 ~305 ~45 ~50 minecraft:redstone_wire replace
setblock ~304 ~45 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~45 ~54 ~290 ~45 ~54 minecraft:redstone_wire replace
setblock ~289 ~45 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~45 ~62 ~294 ~45 ~62 minecraft:redstone_wire replace
setblock ~292 ~45 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~45 ~78 ~320 ~45 ~78 minecraft:redstone_wire replace
setblock ~319 ~45 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~45 ~250 ~98 ~45 ~250 minecraft:redstone_wire replace
setblock ~94 ~45 ~251 minecraft:redstone_wire replace
setblock ~97 ~45 ~251 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~45 ~270 ~125 ~45 ~270 minecraft:redstone_wire replace
setblock ~121 ~45 ~271 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~45 ~271 minecraft:redstone_wire replace
fill ~93 ~45 ~278 ~98 ~45 ~278 minecraft:redstone_wire replace
setblock ~94 ~45 ~279 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~45 ~279 minecraft:redstone_wire replace
fill ~120 ~45 ~282 ~125 ~45 ~282 minecraft:redstone_wire replace
setblock ~121 ~45 ~283 minecraft:redstone_wire replace
setblock ~124 ~45 ~283 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~45 ~286 ~149 ~45 ~286 minecraft:redstone_wire replace
setblock ~145 ~45 ~287 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~45 ~287 minecraft:redstone_wire replace
fill ~144 ~45 ~298 ~149 ~45 ~298 minecraft:redstone_wire replace
setblock ~145 ~45 ~299 minecraft:redstone_wire replace
setblock ~148 ~45 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~45 ~302 ~170 ~45 ~302 minecraft:redstone_wire replace
setblock ~166 ~45 ~303 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~45 ~303 minecraft:redstone_wire replace
fill ~165 ~45 ~314 ~170 ~45 ~314 minecraft:redstone_wire replace
setblock ~166 ~45 ~315 minecraft:redstone_wire replace
setblock ~169 ~45 ~315 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~45 ~322 ~185 ~45 ~322 minecraft:redstone_wire replace
setblock ~186 ~45 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~45 ~322 ~200 ~45 ~322 minecraft:redstone_wire replace
setblock ~202 ~45 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~45 ~322 ~216 ~45 ~322 minecraft:redstone_wire replace
setblock ~218 ~45 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~45 ~322 ~230 ~45 ~322 minecraft:redstone_wire replace
setblock ~231 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~45 ~322 ~244 ~45 ~322 minecraft:redstone_wire replace
setblock ~246 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~248 ~45 ~322 ~260 ~45 ~322 minecraft:redstone_wire replace
setblock ~262 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~45 ~322 ~276 ~45 ~322 minecraft:redstone_wire replace
setblock ~278 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~45 ~322 ~292 ~45 ~322 minecraft:redstone_wire replace
setblock ~294 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~45 ~322 ~299 ~45 ~322 minecraft:redstone_wire replace
setblock ~184 ~45 ~323 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~45 ~323 minecraft:redstone_wire replace
setblock ~208 ~45 ~323 minecraft:redstone_wire replace
setblock ~232 ~45 ~323 minecraft:redstone_wire replace
setblock ~283 ~45 ~323 minecraft:redstone_wire replace
setblock ~298 ~45 ~323 minecraft:redstone_wire replace
fill ~183 ~45 ~326 ~188 ~45 ~326 minecraft:redstone_wire replace
setblock ~184 ~45 ~327 minecraft:redstone_wire replace
setblock ~187 ~45 ~327 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~45 ~330 ~209 ~45 ~330 minecraft:redstone_wire replace
setblock ~210 ~45 ~330 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~45 ~330 ~212 ~45 ~330 minecraft:redstone_wire replace
setblock ~211 ~45 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~45 ~334 ~208 ~45 ~334 minecraft:redstone_wire replace
setblock ~210 ~45 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~45 ~334 ~224 ~45 ~334 minecraft:redstone_wire replace
setblock ~226 ~45 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~45 ~334 ~240 ~45 ~334 minecraft:redstone_wire replace
setblock ~242 ~45 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~45 ~334 ~255 ~45 ~334 minecraft:redstone_wire replace
setblock ~257 ~45 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~45 ~334 ~272 ~45 ~334 minecraft:redstone_wire replace
setblock ~274 ~45 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~45 ~334 ~289 ~45 ~334 minecraft:redstone_wire replace
setblock ~291 ~45 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~293 ~45 ~334 ~299 ~45 ~334 minecraft:redstone_wire replace
setblock ~208 ~45 ~335 minecraft:redstone_wire replace
setblock ~232 ~45 ~335 minecraft:redstone_wire replace
setblock ~283 ~45 ~335 minecraft:redstone_wire replace
setblock ~298 ~45 ~335 minecraft:redstone_wire replace
fill ~207 ~45 ~342 ~212 ~45 ~342 minecraft:redstone_wire replace
setblock ~213 ~45 ~342 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~214 ~45 ~342 ~215 ~45 ~342 minecraft:redstone_wire replace
setblock ~214 ~45 ~343 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~45 ~346 ~236 ~45 ~346 minecraft:redstone_wire replace
setblock ~237 ~45 ~346 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~45 ~346 ~239 ~45 ~346 minecraft:redstone_wire replace
setblock ~238 ~45 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~45 ~350 ~240 ~45 ~350 minecraft:redstone_wire replace
setblock ~242 ~45 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~45 ~350 ~257 ~45 ~350 minecraft:redstone_wire replace
setblock ~259 ~45 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~45 ~350 ~273 ~45 ~350 minecraft:redstone_wire replace
setblock ~275 ~45 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~277 ~45 ~350 ~290 ~45 ~350 minecraft:redstone_wire replace
setblock ~292 ~45 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~294 ~45 ~350 ~299 ~45 ~350 minecraft:redstone_wire replace
setblock ~232 ~45 ~351 minecraft:redstone_wire replace
setblock ~283 ~45 ~351 minecraft:redstone_wire replace
setblock ~298 ~45 ~351 minecraft:redstone_wire replace
fill ~234 ~45 ~358 ~239 ~45 ~358 minecraft:redstone_wire replace
setblock ~240 ~45 ~358 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~45 ~358 ~242 ~45 ~358 minecraft:redstone_wire replace
setblock ~241 ~45 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~45 ~362 ~283 ~45 ~362 minecraft:redstone_wire replace
setblock ~284 ~45 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~45 ~362 ~296 ~45 ~362 minecraft:redstone_wire replace
setblock ~297 ~45 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~45 ~362 ~299 ~45 ~362 minecraft:redstone_wire replace
setblock ~283 ~45 ~363 minecraft:redstone_wire replace
setblock ~298 ~45 ~363 minecraft:redstone_wire replace
fill ~306 ~45 ~366 ~308 ~45 ~366 minecraft:redstone_wire replace
setblock ~307 ~45 ~367 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~309 ~45 ~370 ~311 ~45 ~370 minecraft:redstone_wire replace
setblock ~310 ~45 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~45 ~374 ~284 ~45 ~374 minecraft:redstone_wire replace
setblock ~283 ~45 ~375 minecraft:redstone_wire replace
fill ~294 ~45 ~378 ~297 ~45 ~378 minecraft:redstone_wire replace
setblock ~295 ~45 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~45 ~386 ~260 ~45 ~386 minecraft:redstone_wire replace
setblock ~259 ~45 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~45 ~390 ~335 ~45 ~390 minecraft:redstone_wire replace
setblock ~334 ~45 ~391 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~45 ~394 ~356 ~45 ~394 minecraft:redstone_wire replace
setblock ~355 ~45 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~45 ~398 ~323 ~45 ~398 minecraft:redstone_wire replace
setblock ~322 ~45 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~45 ~402 ~347 ~45 ~402 minecraft:redstone_wire replace
setblock ~346 ~45 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~45 ~406 ~317 ~45 ~406 minecraft:redstone_wire replace
setblock ~316 ~45 ~407 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~45 ~414 ~92 ~45 ~414 minecraft:redstone_wire replace
setblock ~91 ~45 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~45 ~418 ~119 ~45 ~418 minecraft:redstone_wire replace
setblock ~118 ~45 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~45 ~422 ~143 ~45 ~422 minecraft:redstone_wire replace
setblock ~142 ~45 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~45 ~426 ~176 ~45 ~426 minecraft:redstone_wire replace
setblock ~175 ~45 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~45 ~430 ~200 ~45 ~430 minecraft:redstone_wire replace
setblock ~199 ~45 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~45 ~434 ~224 ~45 ~434 minecraft:redstone_wire replace
setblock ~225 ~45 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~45 ~434 ~227 ~45 ~434 minecraft:redstone_wire replace
setblock ~226 ~45 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~252 ~45 ~438 ~257 ~45 ~438 minecraft:redstone_wire replace
setblock ~256 ~45 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~45 ~442 ~278 ~45 ~442 minecraft:redstone_wire replace
setblock ~277 ~45 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~45 ~446 ~314 ~45 ~446 minecraft:redstone_wire replace
setblock ~313 ~45 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~45 ~450 ~89 ~45 ~450 minecraft:redstone_wire replace
setblock ~88 ~45 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~45 ~454 ~116 ~45 ~454 minecraft:redstone_wire replace
setblock ~115 ~45 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~45 ~458 ~140 ~45 ~458 minecraft:redstone_wire replace
setblock ~139 ~45 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~45 ~462 ~173 ~45 ~462 minecraft:redstone_wire replace
setblock ~172 ~45 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~45 ~466 ~197 ~45 ~466 minecraft:redstone_wire replace
setblock ~196 ~45 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~216 ~45 ~470 ~221 ~45 ~470 minecraft:redstone_wire replace
setblock ~222 ~45 ~470 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~45 ~470 ~224 ~45 ~470 minecraft:redstone_wire replace
setblock ~223 ~45 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~45 ~474 ~251 ~45 ~474 minecraft:redstone_wire replace
setblock ~252 ~45 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~45 ~474 ~254 ~45 ~474 minecraft:redstone_wire replace
setblock ~253 ~45 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~45 ~478 ~275 ~45 ~478 minecraft:redstone_wire replace
setblock ~274 ~45 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~45 ~482 ~338 ~45 ~482 minecraft:redstone_wire replace
setblock ~337 ~45 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~360 ~45 ~486 ~362 ~45 ~486 minecraft:redstone_wire replace
setblock ~361 ~45 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~45 ~490 ~86 ~45 ~490 minecraft:redstone_wire replace
setblock ~85 ~45 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~45 ~494 ~113 ~45 ~494 minecraft:redstone_wire replace
setblock ~112 ~45 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~45 ~498 ~137 ~45 ~498 minecraft:redstone_wire replace
setblock ~136 ~45 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~45 ~502 ~164 ~45 ~502 minecraft:redstone_wire replace
setblock ~163 ~45 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~45 ~506 ~194 ~45 ~506 minecraft:redstone_wire replace
setblock ~193 ~45 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~45 ~510 ~218 ~45 ~510 minecraft:redstone_wire replace
setblock ~219 ~45 ~510 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~45 ~510 ~221 ~45 ~510 minecraft:redstone_wire replace
setblock ~220 ~45 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~243 ~45 ~514 ~248 ~45 ~514 minecraft:redstone_wire replace
setblock ~249 ~45 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~45 ~514 ~251 ~45 ~514 minecraft:redstone_wire replace
setblock ~250 ~45 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~45 ~518 ~272 ~45 ~518 minecraft:redstone_wire replace
setblock ~271 ~45 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~330 ~45 ~522 ~332 ~45 ~522 minecraft:redstone_wire replace
setblock ~331 ~45 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~45 ~526 ~359 ~45 ~526 minecraft:redstone_wire replace
setblock ~358 ~45 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~45 ~530 ~83 ~45 ~530 minecraft:redstone_wire replace
setblock ~82 ~45 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~45 ~534 ~110 ~45 ~534 minecraft:redstone_wire replace
setblock ~109 ~45 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~45 ~538 ~134 ~45 ~538 minecraft:redstone_wire replace
setblock ~133 ~45 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~45 ~542 ~158 ~45 ~542 minecraft:redstone_wire replace
setblock ~157 ~45 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~45 ~546 ~191 ~45 ~546 minecraft:redstone_wire replace
setblock ~190 ~45 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~45 ~550 ~215 ~45 ~550 minecraft:redstone_wire replace
setblock ~216 ~45 ~550 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~45 ~550 ~218 ~45 ~550 minecraft:redstone_wire replace
setblock ~217 ~45 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~45 ~554 ~245 ~45 ~554 minecraft:redstone_wire replace
setblock ~246 ~45 ~554 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~45 ~554 ~248 ~45 ~554 minecraft:redstone_wire replace
setblock ~247 ~45 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~45 ~558 ~266 ~45 ~558 minecraft:redstone_wire replace
setblock ~265 ~45 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~327 ~45 ~562 ~329 ~45 ~562 minecraft:redstone_wire replace
setblock ~328 ~45 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~351 ~45 ~566 ~353 ~45 ~566 minecraft:redstone_wire replace
setblock ~352 ~45 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~45 ~570 ~80 ~45 ~570 minecraft:redstone_wire replace
setblock ~79 ~45 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~45 ~574 ~107 ~45 ~574 minecraft:redstone_wire replace
setblock ~106 ~45 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~45 ~578 ~131 ~45 ~578 minecraft:redstone_wire replace
setblock ~130 ~45 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~45 ~582 ~155 ~45 ~582 minecraft:redstone_wire replace
setblock ~154 ~45 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~45 ~586 ~182 ~45 ~586 minecraft:redstone_wire replace
setblock ~181 ~45 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~45 ~590 ~206 ~45 ~590 minecraft:redstone_wire replace
setblock ~205 ~45 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~45 ~594 ~242 ~45 ~594 minecraft:redstone_wire replace
setblock ~243 ~45 ~594 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~45 ~594 ~245 ~45 ~594 minecraft:redstone_wire replace
setblock ~244 ~45 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~45 ~598 ~263 ~45 ~598 minecraft:redstone_wire replace
setblock ~262 ~45 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~45 ~602 ~326 ~45 ~602 minecraft:redstone_wire replace
setblock ~325 ~45 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~45 ~606 ~350 ~45 ~606 minecraft:redstone_wire replace
setblock ~349 ~45 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~45 ~610 ~104 ~45 ~610 minecraft:redstone_wire replace
setblock ~103 ~45 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~45 ~614 ~128 ~45 ~614 minecraft:redstone_wire replace
setblock ~127 ~45 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~45 ~618 ~152 ~45 ~618 minecraft:redstone_wire replace
setblock ~151 ~45 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~45 ~622 ~179 ~45 ~622 minecraft:redstone_wire replace
setblock ~178 ~45 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~45 ~626 ~203 ~45 ~626 minecraft:redstone_wire replace
setblock ~202 ~45 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~45 ~630 ~227 ~45 ~630 minecraft:redstone_wire replace
setblock ~228 ~45 ~630 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~45 ~630 ~230 ~45 ~630 minecraft:redstone_wire replace
setblock ~229 ~45 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~45 ~634 ~269 ~45 ~634 minecraft:redstone_wire replace
setblock ~268 ~45 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~279 ~45 ~638 ~281 ~45 ~638 minecraft:redstone_wire replace
setblock ~280 ~45 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~45 ~642 ~341 ~45 ~642 minecraft:redstone_wire replace
setblock ~340 ~45 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~45 ~646 ~161 ~45 ~646 minecraft:redstone_wire replace
setblock ~160 ~45 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~366 ~45 ~650 ~368 ~45 ~650 minecraft:redstone_wire replace
setblock ~367 ~45 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~45 ~654 ~101 ~45 ~654 minecraft:redstone_wire replace
setblock ~100 ~45 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~45 ~658 ~344 ~45 ~658 minecraft:redstone_wire replace
setblock ~343 ~45 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~363 ~45 ~662 ~365 ~45 ~662 minecraft:redstone_wire replace
setblock ~364 ~45 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~46 ~40 minecraft:redstone_wire replace
setblock ~286 ~46 ~44 minecraft:redstone_wire replace
setblock ~235 ~46 ~48 minecraft:redstone_wire replace
setblock ~304 ~46 ~52 minecraft:redstone_wire replace
setblock ~289 ~46 ~56 minecraft:redstone_wire replace
setblock ~292 ~46 ~64 minecraft:redstone_wire replace
setblock ~319 ~46 ~80 minecraft:redstone_wire replace
setblock ~94 ~46 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~46 ~252 minecraft:redstone_wire replace
setblock ~121 ~46 ~272 minecraft:redstone_wire replace
setblock ~124 ~46 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~46 ~280 minecraft:redstone_wire replace
setblock ~97 ~46 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~46 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~46 ~284 minecraft:redstone_wire replace
setblock ~145 ~46 ~288 minecraft:redstone_wire replace
setblock ~148 ~46 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~46 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~46 ~300 minecraft:redstone_wire replace
setblock ~166 ~46 ~304 minecraft:redstone_wire replace
setblock ~169 ~46 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~46 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~46 ~316 minecraft:redstone_wire replace
setblock ~184 ~46 ~324 minecraft:redstone_wire replace
setblock ~187 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~46 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~46 ~328 minecraft:redstone_wire replace
setblock ~211 ~46 ~332 minecraft:redstone_wire replace
setblock ~208 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~46 ~344 minecraft:redstone_wire replace
setblock ~238 ~46 ~348 minecraft:redstone_wire replace
setblock ~232 ~46 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~46 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~46 ~360 minecraft:redstone_wire replace
setblock ~283 ~46 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~46 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~46 ~368 minecraft:redstone_wire replace
setblock ~310 ~46 ~372 minecraft:redstone_wire replace
setblock ~283 ~46 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~46 ~380 minecraft:redstone_wire replace
setblock ~259 ~46 ~388 minecraft:redstone_wire replace
setblock ~334 ~46 ~392 minecraft:redstone_wire replace
setblock ~355 ~46 ~396 minecraft:redstone_wire replace
setblock ~322 ~46 ~400 minecraft:redstone_wire replace
setblock ~346 ~46 ~404 minecraft:redstone_wire replace
setblock ~316 ~46 ~408 minecraft:redstone_wire replace
setblock ~91 ~46 ~416 minecraft:redstone_wire replace
setblock ~118 ~46 ~420 minecraft:redstone_wire replace
setblock ~142 ~46 ~424 minecraft:redstone_wire replace
setblock ~175 ~46 ~428 minecraft:redstone_wire replace
setblock ~199 ~46 ~432 minecraft:redstone_wire replace
setblock ~226 ~46 ~436 minecraft:redstone_wire replace
setblock ~256 ~46 ~440 minecraft:redstone_wire replace
setblock ~277 ~46 ~444 minecraft:redstone_wire replace
setblock ~313 ~46 ~448 minecraft:redstone_wire replace
setblock ~88 ~46 ~452 minecraft:redstone_wire replace
setblock ~115 ~46 ~456 minecraft:redstone_wire replace
setblock ~139 ~46 ~460 minecraft:redstone_wire replace
setblock ~172 ~46 ~464 minecraft:redstone_wire replace
setblock ~196 ~46 ~468 minecraft:redstone_wire replace
setblock ~223 ~46 ~472 minecraft:redstone_wire replace
setblock ~253 ~46 ~476 minecraft:redstone_wire replace
setblock ~274 ~46 ~480 minecraft:redstone_wire replace
setblock ~337 ~46 ~484 minecraft:redstone_wire replace
setblock ~361 ~46 ~488 minecraft:redstone_wire replace
setblock ~85 ~46 ~492 minecraft:redstone_wire replace
setblock ~112 ~46 ~496 minecraft:redstone_wire replace
setblock ~136 ~46 ~500 minecraft:redstone_wire replace
setblock ~163 ~46 ~504 minecraft:redstone_wire replace
setblock ~193 ~46 ~508 minecraft:redstone_wire replace
setblock ~220 ~46 ~512 minecraft:redstone_wire replace
setblock ~250 ~46 ~516 minecraft:redstone_wire replace
setblock ~271 ~46 ~520 minecraft:redstone_wire replace
setblock ~331 ~46 ~524 minecraft:redstone_wire replace
setblock ~358 ~46 ~528 minecraft:redstone_wire replace
setblock ~82 ~46 ~532 minecraft:redstone_wire replace
setblock ~109 ~46 ~536 minecraft:redstone_wire replace
setblock ~133 ~46 ~540 minecraft:redstone_wire replace
setblock ~157 ~46 ~544 minecraft:redstone_wire replace
setblock ~190 ~46 ~548 minecraft:redstone_wire replace
setblock ~217 ~46 ~552 minecraft:redstone_wire replace
setblock ~247 ~46 ~556 minecraft:redstone_wire replace
setblock ~265 ~46 ~560 minecraft:redstone_wire replace
setblock ~328 ~46 ~564 minecraft:redstone_wire replace
setblock ~352 ~46 ~568 minecraft:redstone_wire replace
setblock ~79 ~46 ~572 minecraft:redstone_wire replace
setblock ~106 ~46 ~576 minecraft:redstone_wire replace
setblock ~130 ~46 ~580 minecraft:redstone_wire replace
setblock ~154 ~46 ~584 minecraft:redstone_wire replace
setblock ~181 ~46 ~588 minecraft:redstone_wire replace
setblock ~205 ~46 ~592 minecraft:redstone_wire replace
setblock ~244 ~46 ~596 minecraft:redstone_wire replace
setblock ~262 ~46 ~600 minecraft:redstone_wire replace
setblock ~325 ~46 ~604 minecraft:redstone_wire replace
setblock ~349 ~46 ~608 minecraft:redstone_wire replace
setblock ~103 ~46 ~612 minecraft:redstone_wire replace
setblock ~127 ~46 ~616 minecraft:redstone_wire replace
setblock ~151 ~46 ~620 minecraft:redstone_wire replace
setblock ~178 ~46 ~624 minecraft:redstone_wire replace
setblock ~202 ~46 ~628 minecraft:redstone_wire replace
setblock ~229 ~46 ~632 minecraft:redstone_wire replace
setblock ~268 ~46 ~636 minecraft:redstone_wire replace
setblock ~280 ~46 ~640 minecraft:redstone_wire replace
setblock ~340 ~46 ~644 minecraft:redstone_wire replace
setblock ~160 ~46 ~648 minecraft:redstone_wire replace
setblock ~367 ~46 ~652 minecraft:redstone_wire replace
setblock ~100 ~46 ~656 minecraft:redstone_wire replace
setblock ~343 ~46 ~660 minecraft:redstone_wire replace
setblock ~364 ~46 ~664 minecraft:redstone_wire replace
fill ~300 ~47 ~36 ~300 ~47 ~40 minecraft:redstone_wire replace
fill ~285 ~47 ~40 ~285 ~47 ~44 minecraft:redstone_wire replace
fill ~234 ~47 ~44 ~234 ~47 ~48 minecraft:redstone_wire replace
fill ~303 ~47 ~48 ~303 ~47 ~52 minecraft:redstone_wire replace
fill ~288 ~47 ~52 ~288 ~47 ~56 minecraft:redstone_wire replace
fill ~291 ~47 ~60 ~291 ~47 ~64 minecraft:redstone_wire replace
fill ~318 ~47 ~76 ~318 ~47 ~80 minecraft:redstone_wire replace
fill ~96 ~47 ~244 ~96 ~47 ~250 minecraft:redstone_wire replace
fill ~93 ~47 ~248 ~93 ~47 ~250 minecraft:redstone_wire replace
setblock ~93 ~47 ~251 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~47 ~251 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~47 ~252 ~93 ~47 ~264 minecraft:redstone_wire replace
fill ~96 ~47 ~252 ~96 ~47 ~264 minecraft:redstone_wire replace
fill ~123 ~47 ~264 ~123 ~47 ~270 minecraft:redstone_wire replace
setblock ~93 ~47 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~47 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~47 ~268 ~93 ~47 ~280 minecraft:redstone_wire replace
fill ~96 ~47 ~268 ~96 ~47 ~280 minecraft:redstone_wire replace
fill ~120 ~47 ~268 ~120 ~47 ~270 minecraft:redstone_wire replace
setblock ~120 ~47 ~271 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~47 ~271 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~47 ~272 ~120 ~47 ~284 minecraft:redstone_wire replace
fill ~123 ~47 ~272 ~123 ~47 ~284 minecraft:redstone_wire replace
fill ~147 ~47 ~280 ~147 ~47 ~286 minecraft:redstone_wire replace
fill ~144 ~47 ~284 ~144 ~47 ~286 minecraft:redstone_wire replace
setblock ~144 ~47 ~287 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~47 ~287 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~47 ~288 ~144 ~47 ~300 minecraft:redstone_wire replace
fill ~147 ~47 ~288 ~147 ~47 ~300 minecraft:redstone_wire replace
setblock ~168 ~47 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~47 ~294 ~168 ~47 ~302 minecraft:redstone_wire replace
fill ~165 ~47 ~296 ~165 ~47 ~302 minecraft:redstone_wire replace
fill ~297 ~47 ~300 ~297 ~47 ~306 minecraft:redstone_wire replace
setblock ~165 ~47 ~303 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~47 ~303 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~47 ~304 ~165 ~47 ~316 minecraft:redstone_wire replace
fill ~168 ~47 ~304 ~168 ~47 ~316 minecraft:redstone_wire replace
setblock ~282 ~47 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~306 ~282 ~47 ~314 minecraft:redstone_wire replace
setblock ~231 ~47 ~308 minecraft:redstone_wire replace
setblock ~297 ~47 ~308 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~47 ~309 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~47 ~310 ~231 ~47 ~322 minecraft:redstone_wire replace
fill ~297 ~47 ~310 ~297 ~47 ~322 minecraft:redstone_wire replace
setblock ~207 ~47 ~312 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~47 ~314 ~207 ~47 ~322 minecraft:redstone_wire replace
setblock ~186 ~47 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~282 ~47 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~47 ~318 ~186 ~47 ~328 minecraft:redstone_wire replace
fill ~282 ~47 ~318 ~282 ~47 ~330 minecraft:redstone_wire replace
setblock ~183 ~47 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~47 ~322 ~183 ~47 ~328 minecraft:redstone_wire replace
setblock ~207 ~47 ~323 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~47 ~323 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~297 ~47 ~323 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~47 ~324 ~207 ~47 ~336 minecraft:redstone_wire replace
fill ~231 ~47 ~324 ~231 ~47 ~336 minecraft:redstone_wire replace
fill ~297 ~47 ~324 ~297 ~47 ~336 minecraft:redstone_wire replace
fill ~210 ~47 ~328 ~210 ~47 ~332 minecraft:redstone_wire replace
setblock ~282 ~47 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~334 ~282 ~47 ~346 minecraft:redstone_wire replace
setblock ~297 ~47 ~337 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~47 ~338 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~47 ~338 ~297 ~47 ~350 minecraft:redstone_wire replace
fill ~213 ~47 ~340 ~213 ~47 ~344 minecraft:redstone_wire replace
fill ~231 ~47 ~340 ~231 ~47 ~352 minecraft:redstone_wire replace
fill ~237 ~47 ~344 ~237 ~47 ~348 minecraft:redstone_wire replace
setblock ~282 ~47 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~350 ~282 ~47 ~362 minecraft:redstone_wire replace
setblock ~297 ~47 ~351 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~47 ~352 ~297 ~47 ~364 minecraft:redstone_wire replace
fill ~240 ~47 ~356 ~240 ~47 ~360 minecraft:redstone_wire replace
setblock ~282 ~47 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~47 ~364 ~282 ~47 ~376 minecraft:redstone_wire replace
fill ~306 ~47 ~364 ~306 ~47 ~368 minecraft:redstone_wire replace
fill ~309 ~47 ~368 ~309 ~47 ~372 minecraft:redstone_wire replace
fill ~294 ~47 ~376 ~294 ~47 ~380 minecraft:redstone_wire replace
fill ~258 ~47 ~384 ~258 ~47 ~388 minecraft:redstone_wire replace
fill ~333 ~47 ~388 ~333 ~47 ~392 minecraft:redstone_wire replace
fill ~354 ~47 ~392 ~354 ~47 ~396 minecraft:redstone_wire replace
fill ~321 ~47 ~396 ~321 ~47 ~400 minecraft:redstone_wire replace
fill ~345 ~47 ~400 ~345 ~47 ~404 minecraft:redstone_wire replace
fill ~315 ~47 ~404 ~315 ~47 ~408 minecraft:redstone_wire replace
fill ~90 ~47 ~412 ~90 ~47 ~416 minecraft:redstone_wire replace
fill ~117 ~47 ~416 ~117 ~47 ~420 minecraft:redstone_wire replace
fill ~141 ~47 ~420 ~141 ~47 ~424 minecraft:redstone_wire replace
fill ~174 ~47 ~424 ~174 ~47 ~428 minecraft:redstone_wire replace
fill ~198 ~47 ~428 ~198 ~47 ~432 minecraft:redstone_wire replace
fill ~225 ~47 ~432 ~225 ~47 ~436 minecraft:redstone_wire replace
fill ~255 ~47 ~436 ~255 ~47 ~440 minecraft:redstone_wire replace
fill ~276 ~47 ~440 ~276 ~47 ~444 minecraft:redstone_wire replace
fill ~312 ~47 ~444 ~312 ~47 ~448 minecraft:redstone_wire replace
fill ~87 ~47 ~448 ~87 ~47 ~452 minecraft:redstone_wire replace
fill ~114 ~47 ~452 ~114 ~47 ~456 minecraft:redstone_wire replace
fill ~138 ~47 ~456 ~138 ~47 ~460 minecraft:redstone_wire replace
fill ~171 ~47 ~460 ~171 ~47 ~464 minecraft:redstone_wire replace
fill ~195 ~47 ~464 ~195 ~47 ~468 minecraft:redstone_wire replace
fill ~222 ~47 ~468 ~222 ~47 ~472 minecraft:redstone_wire replace
fill ~252 ~47 ~472 ~252 ~47 ~476 minecraft:redstone_wire replace
fill ~273 ~47 ~476 ~273 ~47 ~480 minecraft:redstone_wire replace
fill ~336 ~47 ~480 ~336 ~47 ~484 minecraft:redstone_wire replace
fill ~360 ~47 ~484 ~360 ~47 ~488 minecraft:redstone_wire replace
fill ~84 ~47 ~488 ~84 ~47 ~492 minecraft:redstone_wire replace
fill ~111 ~47 ~492 ~111 ~47 ~496 minecraft:redstone_wire replace
fill ~135 ~47 ~496 ~135 ~47 ~500 minecraft:redstone_wire replace
fill ~162 ~47 ~500 ~162 ~47 ~504 minecraft:redstone_wire replace
fill ~192 ~47 ~504 ~192 ~47 ~508 minecraft:redstone_wire replace
fill ~219 ~47 ~508 ~219 ~47 ~512 minecraft:redstone_wire replace
fill ~249 ~47 ~512 ~249 ~47 ~516 minecraft:redstone_wire replace
fill ~270 ~47 ~516 ~270 ~47 ~520 minecraft:redstone_wire replace
fill ~330 ~47 ~520 ~330 ~47 ~524 minecraft:redstone_wire replace
fill ~357 ~47 ~524 ~357 ~47 ~528 minecraft:redstone_wire replace
fill ~81 ~47 ~528 ~81 ~47 ~532 minecraft:redstone_wire replace
fill ~108 ~47 ~532 ~108 ~47 ~536 minecraft:redstone_wire replace
fill ~132 ~47 ~536 ~132 ~47 ~540 minecraft:redstone_wire replace
fill ~156 ~47 ~540 ~156 ~47 ~544 minecraft:redstone_wire replace
fill ~189 ~47 ~544 ~189 ~47 ~548 minecraft:redstone_wire replace
fill ~216 ~47 ~548 ~216 ~47 ~552 minecraft:redstone_wire replace
fill ~246 ~47 ~552 ~246 ~47 ~556 minecraft:redstone_wire replace
fill ~264 ~47 ~556 ~264 ~47 ~560 minecraft:redstone_wire replace
fill ~327 ~47 ~560 ~327 ~47 ~564 minecraft:redstone_wire replace
fill ~351 ~47 ~564 ~351 ~47 ~568 minecraft:redstone_wire replace
fill ~78 ~47 ~568 ~78 ~47 ~572 minecraft:redstone_wire replace
fill ~105 ~47 ~572 ~105 ~47 ~576 minecraft:redstone_wire replace
fill ~129 ~47 ~576 ~129 ~47 ~580 minecraft:redstone_wire replace
fill ~153 ~47 ~580 ~153 ~47 ~584 minecraft:redstone_wire replace
fill ~180 ~47 ~584 ~180 ~47 ~588 minecraft:redstone_wire replace
fill ~204 ~47 ~588 ~204 ~47 ~592 minecraft:redstone_wire replace
fill ~243 ~47 ~592 ~243 ~47 ~596 minecraft:redstone_wire replace
fill ~261 ~47 ~596 ~261 ~47 ~600 minecraft:redstone_wire replace
fill ~324 ~47 ~600 ~324 ~47 ~604 minecraft:redstone_wire replace
fill ~348 ~47 ~604 ~348 ~47 ~608 minecraft:redstone_wire replace
fill ~102 ~47 ~608 ~102 ~47 ~612 minecraft:redstone_wire replace
fill ~126 ~47 ~612 ~126 ~47 ~616 minecraft:redstone_wire replace
fill ~150 ~47 ~616 ~150 ~47 ~620 minecraft:redstone_wire replace
fill ~177 ~47 ~620 ~177 ~47 ~624 minecraft:redstone_wire replace
fill ~201 ~47 ~624 ~201 ~47 ~628 minecraft:redstone_wire replace
fill ~228 ~47 ~628 ~228 ~47 ~632 minecraft:redstone_wire replace
fill ~267 ~47 ~632 ~267 ~47 ~636 minecraft:redstone_wire replace
fill ~279 ~47 ~636 ~279 ~47 ~640 minecraft:redstone_wire replace
fill ~339 ~47 ~640 ~339 ~47 ~644 minecraft:redstone_wire replace
fill ~159 ~47 ~644 ~159 ~47 ~648 minecraft:redstone_wire replace
fill ~366 ~47 ~648 ~366 ~47 ~652 minecraft:redstone_wire replace
fill ~99 ~47 ~652 ~99 ~47 ~656 minecraft:redstone_wire replace
fill ~342 ~47 ~656 ~342 ~47 ~660 minecraft:redstone_wire replace
fill ~363 ~47 ~660 ~363 ~47 ~664 minecraft:redstone_wire replace
setblock ~300 ~48 ~35 minecraft:redstone_wire replace
setblock ~285 ~48 ~39 minecraft:redstone_wire replace
setblock ~234 ~48 ~43 minecraft:redstone_wire replace
setblock ~303 ~48 ~47 minecraft:redstone_wire replace
setblock ~288 ~48 ~51 minecraft:redstone_wire replace
setblock ~291 ~48 ~59 minecraft:redstone_wire replace
setblock ~318 ~48 ~75 minecraft:redstone_wire replace
setblock ~96 ~48 ~243 minecraft:redstone_wire replace
setblock ~93 ~48 ~247 minecraft:redstone_wire replace
setblock ~123 ~48 ~263 minecraft:redstone_wire replace
setblock ~120 ~48 ~267 minecraft:redstone_wire replace
setblock ~147 ~48 ~279 minecraft:redstone_wire replace
setblock ~144 ~48 ~283 minecraft:redstone_wire replace
setblock ~168 ~48 ~291 minecraft:redstone_wire replace
setblock ~165 ~48 ~295 minecraft:redstone_wire replace
setblock ~297 ~48 ~299 minecraft:redstone_wire replace
setblock ~282 ~48 ~303 minecraft:redstone_wire replace
setblock ~231 ~48 ~307 minecraft:redstone_wire replace
setblock ~207 ~48 ~311 minecraft:redstone_wire replace
setblock ~186 ~48 ~315 minecraft:redstone_wire replace
setblock ~183 ~48 ~319 minecraft:redstone_wire replace
setblock ~210 ~48 ~327 minecraft:redstone_wire replace
setblock ~213 ~48 ~339 minecraft:redstone_wire replace
setblock ~237 ~48 ~343 minecraft:redstone_wire replace
setblock ~240 ~48 ~355 minecraft:redstone_wire replace
setblock ~306 ~48 ~363 minecraft:redstone_wire replace
setblock ~309 ~48 ~367 minecraft:redstone_wire replace
setblock ~294 ~48 ~375 minecraft:redstone_wire replace
setblock ~258 ~48 ~383 minecraft:redstone_wire replace
setblock ~333 ~48 ~387 minecraft:redstone_wire replace
setblock ~354 ~48 ~391 minecraft:redstone_wire replace
setblock ~321 ~48 ~395 minecraft:redstone_wire replace
setblock ~345 ~48 ~399 minecraft:redstone_wire replace
setblock ~315 ~48 ~403 minecraft:redstone_wire replace
setblock ~90 ~48 ~411 minecraft:redstone_wire replace
setblock ~117 ~48 ~415 minecraft:redstone_wire replace
setblock ~141 ~48 ~419 minecraft:redstone_wire replace
setblock ~174 ~48 ~423 minecraft:redstone_wire replace
setblock ~198 ~48 ~427 minecraft:redstone_wire replace
setblock ~225 ~48 ~431 minecraft:redstone_wire replace
setblock ~255 ~48 ~435 minecraft:redstone_wire replace
setblock ~276 ~48 ~439 minecraft:redstone_wire replace
setblock ~312 ~48 ~443 minecraft:redstone_wire replace
setblock ~87 ~48 ~447 minecraft:redstone_wire replace
setblock ~114 ~48 ~451 minecraft:redstone_wire replace
setblock ~138 ~48 ~455 minecraft:redstone_wire replace
setblock ~171 ~48 ~459 minecraft:redstone_wire replace
setblock ~195 ~48 ~463 minecraft:redstone_wire replace
setblock ~222 ~48 ~467 minecraft:redstone_wire replace
setblock ~252 ~48 ~471 minecraft:redstone_wire replace
setblock ~273 ~48 ~475 minecraft:redstone_wire replace
setblock ~336 ~48 ~479 minecraft:redstone_wire replace
setblock ~360 ~48 ~483 minecraft:redstone_wire replace
setblock ~84 ~48 ~487 minecraft:redstone_wire replace
setblock ~111 ~48 ~491 minecraft:redstone_wire replace
setblock ~135 ~48 ~495 minecraft:redstone_wire replace
setblock ~162 ~48 ~499 minecraft:redstone_wire replace
setblock ~192 ~48 ~503 minecraft:redstone_wire replace
setblock ~219 ~48 ~507 minecraft:redstone_wire replace
setblock ~249 ~48 ~511 minecraft:redstone_wire replace
setblock ~270 ~48 ~515 minecraft:redstone_wire replace
setblock ~330 ~48 ~519 minecraft:redstone_wire replace
setblock ~357 ~48 ~523 minecraft:redstone_wire replace
setblock ~81 ~48 ~527 minecraft:redstone_wire replace
setblock ~108 ~48 ~531 minecraft:redstone_wire replace
setblock ~132 ~48 ~535 minecraft:redstone_wire replace
setblock ~156 ~48 ~539 minecraft:redstone_wire replace
setblock ~189 ~48 ~543 minecraft:redstone_wire replace
setblock ~216 ~48 ~547 minecraft:redstone_wire replace
setblock ~246 ~48 ~551 minecraft:redstone_wire replace
setblock ~264 ~48 ~555 minecraft:redstone_wire replace
setblock ~327 ~48 ~559 minecraft:redstone_wire replace
setblock ~351 ~48 ~563 minecraft:redstone_wire replace
setblock ~78 ~48 ~567 minecraft:redstone_wire replace
setblock ~105 ~48 ~571 minecraft:redstone_wire replace
setblock ~129 ~48 ~575 minecraft:redstone_wire replace
setblock ~153 ~48 ~579 minecraft:redstone_wire replace
setblock ~180 ~48 ~583 minecraft:redstone_wire replace
setblock ~204 ~48 ~587 minecraft:redstone_wire replace
setblock ~243 ~48 ~591 minecraft:redstone_wire replace
setblock ~261 ~48 ~595 minecraft:redstone_wire replace
setblock ~324 ~48 ~599 minecraft:redstone_wire replace
setblock ~348 ~48 ~603 minecraft:redstone_wire replace
setblock ~102 ~48 ~607 minecraft:redstone_wire replace
setblock ~126 ~48 ~611 minecraft:redstone_wire replace
setblock ~150 ~48 ~615 minecraft:redstone_wire replace
setblock ~177 ~48 ~619 minecraft:redstone_wire replace
setblock ~201 ~48 ~623 minecraft:redstone_wire replace
setblock ~228 ~48 ~627 minecraft:redstone_wire replace
setblock ~267 ~48 ~631 minecraft:redstone_wire replace
setblock ~279 ~48 ~635 minecraft:redstone_wire replace
setblock ~339 ~48 ~639 minecraft:redstone_wire replace
setblock ~159 ~48 ~643 minecraft:redstone_wire replace
setblock ~366 ~48 ~647 minecraft:redstone_wire replace
setblock ~99 ~48 ~651 minecraft:redstone_wire replace
setblock ~342 ~48 ~655 minecraft:redstone_wire replace
setblock ~363 ~48 ~659 minecraft:redstone_wire replace
setblock ~262 ~49 ~33 minecraft:redstone_wire replace
fill ~261 ~49 ~34 ~273 ~49 ~34 minecraft:redstone_wire replace
setblock ~275 ~49 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~49 ~34 ~290 ~49 ~34 minecraft:redstone_wire replace
setblock ~292 ~49 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~49 ~34 ~300 ~49 ~34 minecraft:redstone_wire replace
setblock ~259 ~49 ~37 minecraft:redstone_wire replace
fill ~258 ~49 ~38 ~260 ~49 ~38 minecraft:redstone_wire replace
setblock ~261 ~49 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~49 ~38 ~275 ~49 ~38 minecraft:redstone_wire replace
setblock ~277 ~49 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~49 ~38 ~285 ~49 ~38 minecraft:redstone_wire replace
setblock ~214 ~49 ~41 minecraft:redstone_wire replace
fill ~213 ~49 ~42 ~224 ~49 ~42 minecraft:redstone_wire replace
setblock ~226 ~49 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~49 ~42 ~234 ~49 ~42 minecraft:redstone_wire replace
setblock ~262 ~49 ~45 minecraft:redstone_wire replace
fill ~261 ~49 ~46 ~262 ~49 ~46 minecraft:redstone_wire replace
setblock ~264 ~49 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~49 ~46 ~278 ~49 ~46 minecraft:redstone_wire replace
setblock ~280 ~49 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~49 ~46 ~294 ~49 ~46 minecraft:redstone_wire replace
setblock ~296 ~49 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~49 ~46 ~303 ~49 ~46 minecraft:redstone_wire replace
setblock ~259 ~49 ~49 minecraft:redstone_wire replace
fill ~258 ~49 ~50 ~261 ~49 ~50 minecraft:redstone_wire replace
setblock ~263 ~49 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~49 ~50 ~278 ~49 ~50 minecraft:redstone_wire replace
setblock ~280 ~49 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~49 ~50 ~288 ~49 ~50 minecraft:redstone_wire replace
setblock ~259 ~49 ~57 minecraft:redstone_wire replace
fill ~258 ~49 ~58 ~264 ~49 ~58 minecraft:redstone_wire replace
setblock ~266 ~49 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~49 ~58 ~281 ~49 ~58 minecraft:redstone_wire replace
setblock ~283 ~49 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~49 ~58 ~291 ~49 ~58 minecraft:redstone_wire replace
setblock ~274 ~49 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~49 ~74 ~274 ~49 ~74 minecraft:redstone_wire replace
setblock ~276 ~49 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~49 ~74 ~291 ~49 ~74 minecraft:redstone_wire replace
setblock ~293 ~49 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~49 ~74 ~308 ~49 ~74 minecraft:redstone_wire replace
setblock ~310 ~49 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~49 ~74 ~318 ~49 ~74 minecraft:redstone_wire replace
setblock ~94 ~49 ~241 minecraft:redstone_wire replace
fill ~93 ~49 ~242 ~96 ~49 ~242 minecraft:redstone_wire replace
setblock ~94 ~49 ~245 minecraft:redstone_wire replace
fill ~93 ~49 ~246 ~95 ~49 ~246 minecraft:redstone_wire replace
setblock ~118 ~49 ~261 minecraft:redstone_wire replace
setblock ~117 ~49 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~49 ~262 ~123 ~49 ~262 minecraft:redstone_wire replace
setblock ~118 ~49 ~265 minecraft:redstone_wire replace
fill ~117 ~49 ~266 ~120 ~49 ~266 minecraft:redstone_wire replace
setblock ~139 ~49 ~277 minecraft:redstone_wire replace
fill ~138 ~49 ~278 ~140 ~49 ~278 minecraft:redstone_wire replace
setblock ~141 ~49 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~49 ~278 ~147 ~49 ~278 minecraft:redstone_wire replace
setblock ~139 ~49 ~281 minecraft:redstone_wire replace
fill ~138 ~49 ~282 ~144 ~49 ~282 minecraft:redstone_wire replace
setblock ~157 ~49 ~289 minecraft:redstone_wire replace
fill ~156 ~49 ~290 ~168 ~49 ~290 minecraft:redstone_wire replace
setblock ~157 ~49 ~293 minecraft:redstone_wire replace
fill ~156 ~49 ~294 ~158 ~49 ~294 minecraft:redstone_wire replace
setblock ~159 ~49 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~49 ~294 ~165 ~49 ~294 minecraft:redstone_wire replace
setblock ~262 ~49 ~297 minecraft:redstone_wire replace
fill ~261 ~49 ~298 ~271 ~49 ~298 minecraft:redstone_wire replace
setblock ~273 ~49 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~49 ~298 ~288 ~49 ~298 minecraft:redstone_wire replace
setblock ~290 ~49 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~49 ~298 ~297 ~49 ~298 minecraft:redstone_wire replace
setblock ~259 ~49 ~301 minecraft:redstone_wire replace
fill ~258 ~49 ~302 ~266 ~49 ~302 minecraft:redstone_wire replace
setblock ~268 ~49 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~49 ~302 ~282 ~49 ~302 minecraft:redstone_wire replace
setblock ~214 ~49 ~305 minecraft:redstone_wire replace
fill ~213 ~49 ~306 ~216 ~49 ~306 minecraft:redstone_wire replace
setblock ~218 ~49 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~49 ~306 ~231 ~49 ~306 minecraft:redstone_wire replace
setblock ~193 ~49 ~309 minecraft:redstone_wire replace
fill ~192 ~49 ~310 ~193 ~49 ~310 minecraft:redstone_wire replace
setblock ~194 ~49 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~49 ~310 ~207 ~49 ~310 minecraft:redstone_wire replace
setblock ~172 ~49 ~313 minecraft:redstone_wire replace
fill ~171 ~49 ~314 ~172 ~49 ~314 minecraft:redstone_wire replace
setblock ~173 ~49 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~49 ~314 ~186 ~49 ~314 minecraft:redstone_wire replace
setblock ~172 ~49 ~317 minecraft:redstone_wire replace
fill ~171 ~49 ~318 ~183 ~49 ~318 minecraft:redstone_wire replace
setblock ~193 ~49 ~325 minecraft:redstone_wire replace
fill ~192 ~49 ~326 ~200 ~49 ~326 minecraft:redstone_wire replace
setblock ~202 ~49 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~49 ~326 ~210 ~49 ~326 minecraft:redstone_wire replace
setblock ~196 ~49 ~337 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~49 ~338 ~203 ~49 ~338 minecraft:redstone_wire replace
setblock ~205 ~49 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~49 ~338 ~213 ~49 ~338 minecraft:redstone_wire replace
setblock ~214 ~49 ~341 minecraft:redstone_wire replace
setblock ~213 ~49 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~49 ~342 ~227 ~49 ~342 minecraft:redstone_wire replace
setblock ~229 ~49 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~49 ~342 ~237 ~49 ~342 minecraft:redstone_wire replace
setblock ~217 ~49 ~353 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~49 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~49 ~354 ~230 ~49 ~354 minecraft:redstone_wire replace
setblock ~232 ~49 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~49 ~354 ~240 ~49 ~354 minecraft:redstone_wire replace
setblock ~262 ~49 ~361 minecraft:redstone_wire replace
fill ~261 ~49 ~362 ~262 ~49 ~362 minecraft:redstone_wire replace
setblock ~264 ~49 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~49 ~362 ~279 ~49 ~362 minecraft:redstone_wire replace
setblock ~281 ~49 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~49 ~362 ~296 ~49 ~362 minecraft:redstone_wire replace
setblock ~298 ~49 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~49 ~362 ~306 ~49 ~362 minecraft:redstone_wire replace
setblock ~265 ~49 ~365 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~49 ~366 ~265 ~49 ~366 minecraft:redstone_wire replace
setblock ~267 ~49 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~49 ~366 ~282 ~49 ~366 minecraft:redstone_wire replace
setblock ~284 ~49 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~49 ~366 ~299 ~49 ~366 minecraft:redstone_wire replace
setblock ~301 ~49 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~49 ~366 ~309 ~49 ~366 minecraft:redstone_wire replace
setblock ~259 ~49 ~373 minecraft:redstone_wire replace
fill ~258 ~49 ~374 ~267 ~49 ~374 minecraft:redstone_wire replace
setblock ~269 ~49 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~49 ~374 ~284 ~49 ~374 minecraft:redstone_wire replace
setblock ~286 ~49 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~49 ~374 ~294 ~49 ~374 minecraft:redstone_wire replace
setblock ~235 ~49 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~234 ~49 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~49 ~382 ~248 ~49 ~382 minecraft:redstone_wire replace
setblock ~250 ~49 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~49 ~382 ~258 ~49 ~382 minecraft:redstone_wire replace
setblock ~289 ~49 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~288 ~49 ~386 ~289 ~49 ~386 minecraft:redstone_wire replace
setblock ~291 ~49 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~49 ~386 ~306 ~49 ~386 minecraft:redstone_wire replace
setblock ~308 ~49 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~49 ~386 ~323 ~49 ~386 minecraft:redstone_wire replace
setblock ~325 ~49 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~49 ~386 ~333 ~49 ~386 minecraft:redstone_wire replace
setblock ~310 ~49 ~389 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~309 ~49 ~390 ~310 ~49 ~390 minecraft:redstone_wire replace
setblock ~312 ~49 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~49 ~390 ~327 ~49 ~390 minecraft:redstone_wire replace
setblock ~329 ~49 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~49 ~390 ~344 ~49 ~390 minecraft:redstone_wire replace
setblock ~346 ~49 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~49 ~390 ~354 ~49 ~390 minecraft:redstone_wire replace
setblock ~277 ~49 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~49 ~394 ~277 ~49 ~394 minecraft:redstone_wire replace
setblock ~279 ~49 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~49 ~394 ~294 ~49 ~394 minecraft:redstone_wire replace
setblock ~296 ~49 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~49 ~394 ~311 ~49 ~394 minecraft:redstone_wire replace
setblock ~313 ~49 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~49 ~394 ~321 ~49 ~394 minecraft:redstone_wire replace
setblock ~301 ~49 ~397 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~300 ~49 ~398 ~301 ~49 ~398 minecraft:redstone_wire replace
setblock ~303 ~49 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~49 ~398 ~318 ~49 ~398 minecraft:redstone_wire replace
setblock ~320 ~49 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~49 ~398 ~335 ~49 ~398 minecraft:redstone_wire replace
setblock ~337 ~49 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~49 ~398 ~345 ~49 ~398 minecraft:redstone_wire replace
setblock ~271 ~49 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~49 ~402 ~271 ~49 ~402 minecraft:redstone_wire replace
setblock ~273 ~49 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~49 ~402 ~288 ~49 ~402 minecraft:redstone_wire replace
setblock ~290 ~49 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~49 ~402 ~305 ~49 ~402 minecraft:redstone_wire replace
setblock ~307 ~49 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~309 ~49 ~402 ~315 ~49 ~402 minecraft:redstone_wire replace
setblock ~91 ~49 ~409 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~49 ~410 ~92 ~49 ~410 minecraft:redstone_wire replace
setblock ~115 ~49 ~413 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~49 ~414 ~117 ~49 ~414 minecraft:redstone_wire replace
setblock ~136 ~49 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~49 ~418 ~141 ~49 ~418 minecraft:redstone_wire replace
setblock ~163 ~49 ~421 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~49 ~422 ~164 ~49 ~422 minecraft:redstone_wire replace
setblock ~166 ~49 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~49 ~422 ~174 ~49 ~422 minecraft:redstone_wire replace
setblock ~184 ~49 ~425 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~49 ~426 ~188 ~49 ~426 minecraft:redstone_wire replace
setblock ~190 ~49 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~49 ~426 ~198 ~49 ~426 minecraft:redstone_wire replace
setblock ~208 ~49 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~49 ~430 ~215 ~49 ~430 minecraft:redstone_wire replace
setblock ~217 ~49 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~49 ~430 ~225 ~49 ~430 minecraft:redstone_wire replace
setblock ~232 ~49 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~49 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~49 ~434 ~245 ~49 ~434 minecraft:redstone_wire replace
setblock ~247 ~49 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~49 ~434 ~255 ~49 ~434 minecraft:redstone_wire replace
setblock ~253 ~49 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~49 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~49 ~438 ~266 ~49 ~438 minecraft:redstone_wire replace
setblock ~268 ~49 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~49 ~438 ~276 ~49 ~438 minecraft:redstone_wire replace
setblock ~268 ~49 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~49 ~442 ~268 ~49 ~442 minecraft:redstone_wire replace
setblock ~270 ~49 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~49 ~442 ~285 ~49 ~442 minecraft:redstone_wire replace
setblock ~287 ~49 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~49 ~442 ~302 ~49 ~442 minecraft:redstone_wire replace
setblock ~304 ~49 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~49 ~442 ~312 ~49 ~442 minecraft:redstone_wire replace
setblock ~88 ~49 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~49 ~446 ~89 ~49 ~446 minecraft:redstone_wire replace
setblock ~112 ~49 ~449 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~49 ~450 ~114 ~49 ~450 minecraft:redstone_wire replace
setblock ~133 ~49 ~453 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~49 ~454 ~138 ~49 ~454 minecraft:redstone_wire replace
setblock ~160 ~49 ~457 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~49 ~458 ~161 ~49 ~458 minecraft:redstone_wire replace
setblock ~163 ~49 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~49 ~458 ~171 ~49 ~458 minecraft:redstone_wire replace
setblock ~181 ~49 ~461 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~49 ~462 ~185 ~49 ~462 minecraft:redstone_wire replace
setblock ~187 ~49 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~49 ~462 ~195 ~49 ~462 minecraft:redstone_wire replace
setblock ~205 ~49 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~49 ~466 ~212 ~49 ~466 minecraft:redstone_wire replace
setblock ~214 ~49 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~49 ~466 ~222 ~49 ~466 minecraft:redstone_wire replace
setblock ~229 ~49 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~49 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~49 ~470 ~242 ~49 ~470 minecraft:redstone_wire replace
setblock ~244 ~49 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~49 ~470 ~252 ~49 ~470 minecraft:redstone_wire replace
setblock ~250 ~49 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~249 ~49 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~49 ~474 ~263 ~49 ~474 minecraft:redstone_wire replace
setblock ~265 ~49 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~49 ~474 ~273 ~49 ~474 minecraft:redstone_wire replace
setblock ~292 ~49 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~291 ~49 ~478 ~292 ~49 ~478 minecraft:redstone_wire replace
setblock ~294 ~49 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~49 ~478 ~309 ~49 ~478 minecraft:redstone_wire replace
setblock ~311 ~49 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~49 ~478 ~326 ~49 ~478 minecraft:redstone_wire replace
setblock ~328 ~49 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~49 ~478 ~336 ~49 ~478 minecraft:redstone_wire replace
setblock ~316 ~49 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~49 ~482 ~316 ~49 ~482 minecraft:redstone_wire replace
setblock ~318 ~49 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~320 ~49 ~482 ~333 ~49 ~482 minecraft:redstone_wire replace
setblock ~335 ~49 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~49 ~482 ~350 ~49 ~482 minecraft:redstone_wire replace
setblock ~352 ~49 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~49 ~482 ~360 ~49 ~482 minecraft:redstone_wire replace
setblock ~85 ~49 ~485 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~49 ~486 ~86 ~49 ~486 minecraft:redstone_wire replace
setblock ~109 ~49 ~489 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~49 ~490 ~111 ~49 ~490 minecraft:redstone_wire replace
setblock ~130 ~49 ~493 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~49 ~494 ~135 ~49 ~494 minecraft:redstone_wire replace
setblock ~154 ~49 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~49 ~498 ~154 ~49 ~498 minecraft:redstone_wire replace
setblock ~155 ~49 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~49 ~498 ~162 ~49 ~498 minecraft:redstone_wire replace
setblock ~178 ~49 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~49 ~502 ~182 ~49 ~502 minecraft:redstone_wire replace
setblock ~184 ~49 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~49 ~502 ~192 ~49 ~502 minecraft:redstone_wire replace
setblock ~202 ~49 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~49 ~506 ~209 ~49 ~506 minecraft:redstone_wire replace
setblock ~211 ~49 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~49 ~506 ~219 ~49 ~506 minecraft:redstone_wire replace
setblock ~226 ~49 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~49 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~49 ~510 ~239 ~49 ~510 minecraft:redstone_wire replace
setblock ~241 ~49 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~49 ~510 ~249 ~49 ~510 minecraft:redstone_wire replace
setblock ~247 ~49 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~246 ~49 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~49 ~514 ~260 ~49 ~514 minecraft:redstone_wire replace
setblock ~262 ~49 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~49 ~514 ~270 ~49 ~514 minecraft:redstone_wire replace
setblock ~286 ~49 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~49 ~518 ~286 ~49 ~518 minecraft:redstone_wire replace
setblock ~288 ~49 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~49 ~518 ~303 ~49 ~518 minecraft:redstone_wire replace
setblock ~305 ~49 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~49 ~518 ~320 ~49 ~518 minecraft:redstone_wire replace
setblock ~322 ~49 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~49 ~518 ~330 ~49 ~518 minecraft:redstone_wire replace
setblock ~313 ~49 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~49 ~522 ~313 ~49 ~522 minecraft:redstone_wire replace
setblock ~315 ~49 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~49 ~522 ~330 ~49 ~522 minecraft:redstone_wire replace
setblock ~332 ~49 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~49 ~522 ~347 ~49 ~522 minecraft:redstone_wire replace
setblock ~349 ~49 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~49 ~522 ~357 ~49 ~522 minecraft:redstone_wire replace
setblock ~82 ~49 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~49 ~526 ~83 ~49 ~526 minecraft:redstone_wire replace
setblock ~106 ~49 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~49 ~530 ~108 ~49 ~530 minecraft:redstone_wire replace
setblock ~127 ~49 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~49 ~534 ~132 ~49 ~534 minecraft:redstone_wire replace
setblock ~148 ~49 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~49 ~538 ~148 ~49 ~538 minecraft:redstone_wire replace
setblock ~149 ~49 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~49 ~538 ~156 ~49 ~538 minecraft:redstone_wire replace
setblock ~175 ~49 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~49 ~542 ~179 ~49 ~542 minecraft:redstone_wire replace
setblock ~181 ~49 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~49 ~542 ~189 ~49 ~542 minecraft:redstone_wire replace
setblock ~199 ~49 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~49 ~546 ~206 ~49 ~546 minecraft:redstone_wire replace
setblock ~208 ~49 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~49 ~546 ~216 ~49 ~546 minecraft:redstone_wire replace
setblock ~223 ~49 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~49 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~49 ~550 ~236 ~49 ~550 minecraft:redstone_wire replace
setblock ~238 ~49 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~49 ~550 ~246 ~49 ~550 minecraft:redstone_wire replace
setblock ~241 ~49 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~240 ~49 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~49 ~554 ~254 ~49 ~554 minecraft:redstone_wire replace
setblock ~256 ~49 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~49 ~554 ~264 ~49 ~554 minecraft:redstone_wire replace
setblock ~283 ~49 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~49 ~558 ~283 ~49 ~558 minecraft:redstone_wire replace
setblock ~285 ~49 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~287 ~49 ~558 ~300 ~49 ~558 minecraft:redstone_wire replace
setblock ~302 ~49 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~49 ~558 ~317 ~49 ~558 minecraft:redstone_wire replace
setblock ~319 ~49 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~49 ~558 ~327 ~49 ~558 minecraft:redstone_wire replace
setblock ~307 ~49 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~306 ~49 ~562 ~307 ~49 ~562 minecraft:redstone_wire replace
setblock ~309 ~49 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~311 ~49 ~562 ~324 ~49 ~562 minecraft:redstone_wire replace
setblock ~326 ~49 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~328 ~49 ~562 ~341 ~49 ~562 minecraft:redstone_wire replace
setblock ~343 ~49 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~345 ~49 ~562 ~351 ~49 ~562 minecraft:redstone_wire replace
setblock ~79 ~49 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~49 ~566 ~80 ~49 ~566 minecraft:redstone_wire replace
setblock ~103 ~49 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~49 ~570 ~105 ~49 ~570 minecraft:redstone_wire replace
setblock ~124 ~49 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~49 ~574 ~129 ~49 ~574 minecraft:redstone_wire replace
setblock ~145 ~49 ~577 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~49 ~578 ~145 ~49 ~578 minecraft:redstone_wire replace
setblock ~146 ~49 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~49 ~578 ~153 ~49 ~578 minecraft:redstone_wire replace
setblock ~169 ~49 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~49 ~582 ~170 ~49 ~582 minecraft:redstone_wire replace
setblock ~172 ~49 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~49 ~582 ~180 ~49 ~582 minecraft:redstone_wire replace
setblock ~190 ~49 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~49 ~586 ~194 ~49 ~586 minecraft:redstone_wire replace
setblock ~196 ~49 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~49 ~586 ~204 ~49 ~586 minecraft:redstone_wire replace
setblock ~220 ~49 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~49 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~49 ~590 ~233 ~49 ~590 minecraft:redstone_wire replace
setblock ~235 ~49 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~49 ~590 ~243 ~49 ~590 minecraft:redstone_wire replace
setblock ~238 ~49 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~237 ~49 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~49 ~594 ~251 ~49 ~594 minecraft:redstone_wire replace
setblock ~253 ~49 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~49 ~594 ~261 ~49 ~594 minecraft:redstone_wire replace
setblock ~280 ~49 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~49 ~598 ~280 ~49 ~598 minecraft:redstone_wire replace
setblock ~282 ~49 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~284 ~49 ~598 ~297 ~49 ~598 minecraft:redstone_wire replace
setblock ~299 ~49 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~49 ~598 ~314 ~49 ~598 minecraft:redstone_wire replace
setblock ~316 ~49 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~49 ~598 ~324 ~49 ~598 minecraft:redstone_wire replace
setblock ~304 ~49 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~303 ~49 ~602 ~304 ~49 ~602 minecraft:redstone_wire replace
setblock ~306 ~49 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~49 ~602 ~321 ~49 ~602 minecraft:redstone_wire replace
setblock ~323 ~49 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~325 ~49 ~602 ~338 ~49 ~602 minecraft:redstone_wire replace
setblock ~340 ~49 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~342 ~49 ~602 ~348 ~49 ~602 minecraft:redstone_wire replace
setblock ~100 ~49 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~49 ~606 ~102 ~49 ~606 minecraft:redstone_wire replace
setblock ~121 ~49 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~49 ~610 ~126 ~49 ~610 minecraft:redstone_wire replace
setblock ~142 ~49 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~49 ~614 ~142 ~49 ~614 minecraft:redstone_wire replace
setblock ~143 ~49 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~49 ~614 ~150 ~49 ~614 minecraft:redstone_wire replace
setblock ~166 ~49 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~49 ~618 ~167 ~49 ~618 minecraft:redstone_wire replace
setblock ~169 ~49 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~49 ~618 ~177 ~49 ~618 minecraft:redstone_wire replace
setblock ~187 ~49 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~49 ~622 ~191 ~49 ~622 minecraft:redstone_wire replace
setblock ~193 ~49 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~49 ~622 ~201 ~49 ~622 minecraft:redstone_wire replace
setblock ~211 ~49 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~49 ~626 ~218 ~49 ~626 minecraft:redstone_wire replace
setblock ~220 ~49 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~49 ~626 ~228 ~49 ~626 minecraft:redstone_wire replace
setblock ~244 ~49 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~49 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~49 ~630 ~257 ~49 ~630 minecraft:redstone_wire replace
setblock ~259 ~49 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~49 ~630 ~267 ~49 ~630 minecraft:redstone_wire replace
setblock ~256 ~49 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~49 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~49 ~634 ~269 ~49 ~634 minecraft:redstone_wire replace
setblock ~271 ~49 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~49 ~634 ~279 ~49 ~634 minecraft:redstone_wire replace
setblock ~295 ~49 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~294 ~49 ~638 ~295 ~49 ~638 minecraft:redstone_wire replace
setblock ~297 ~49 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~299 ~49 ~638 ~312 ~49 ~638 minecraft:redstone_wire replace
setblock ~314 ~49 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~316 ~49 ~638 ~329 ~49 ~638 minecraft:redstone_wire replace
setblock ~331 ~49 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~333 ~49 ~638 ~339 ~49 ~638 minecraft:redstone_wire replace
setblock ~151 ~49 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~49 ~642 ~151 ~49 ~642 minecraft:redstone_wire replace
setblock ~152 ~49 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~49 ~642 ~159 ~49 ~642 minecraft:redstone_wire replace
setblock ~322 ~49 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~321 ~49 ~646 ~322 ~49 ~646 minecraft:redstone_wire replace
setblock ~324 ~49 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~326 ~49 ~646 ~339 ~49 ~646 minecraft:redstone_wire replace
setblock ~341 ~49 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~49 ~646 ~356 ~49 ~646 minecraft:redstone_wire replace
setblock ~358 ~49 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~360 ~49 ~646 ~366 ~49 ~646 minecraft:redstone_wire replace
setblock ~97 ~49 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~49 ~650 ~99 ~49 ~650 minecraft:redstone_wire replace
setblock ~298 ~49 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~49 ~654 ~298 ~49 ~654 minecraft:redstone_wire replace
setblock ~300 ~49 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~49 ~654 ~315 ~49 ~654 minecraft:redstone_wire replace
setblock ~317 ~49 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~49 ~654 ~332 ~49 ~654 minecraft:redstone_wire replace
setblock ~334 ~49 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~49 ~654 ~342 ~49 ~654 minecraft:redstone_wire replace
setblock ~319 ~49 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~49 ~658 ~319 ~49 ~658 minecraft:redstone_wire replace
setblock ~321 ~49 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~323 ~49 ~658 ~336 ~49 ~658 minecraft:redstone_wire replace
setblock ~338 ~49 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~340 ~49 ~658 ~353 ~49 ~658 minecraft:redstone_wire replace
setblock ~355 ~49 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~357 ~49 ~658 ~363 ~49 ~658 minecraft:redstone_wire replace
setblock ~262 ~50 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~50 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~50 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~50 ~72 minecraft:redstone_wire replace
setblock ~94 ~50 ~240 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~50 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~50 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~50 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~50 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~50 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~50 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~50 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~50 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~50 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~50 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~50 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~50 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~50 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~50 ~336 minecraft:redstone_wire replace
setblock ~214 ~50 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~50 ~352 minecraft:redstone_wire replace
setblock ~262 ~50 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~50 ~364 minecraft:redstone_wire replace
setblock ~259 ~50 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~50 ~380 minecraft:redstone_wire replace
setblock ~289 ~50 ~384 minecraft:redstone_wire replace
setblock ~310 ~50 ~388 minecraft:redstone_wire replace
setblock ~277 ~50 ~392 minecraft:redstone_wire replace
setblock ~301 ~50 ~396 minecraft:redstone_wire replace
setblock ~271 ~50 ~400 minecraft:redstone_wire replace
setblock ~91 ~50 ~408 minecraft:redstone_wire replace
setblock ~115 ~50 ~412 minecraft:redstone_wire replace
setblock ~136 ~50 ~416 minecraft:redstone_wire replace
setblock ~163 ~50 ~420 minecraft:redstone_wire replace
setblock ~184 ~50 ~424 minecraft:redstone_wire replace
setblock ~208 ~50 ~428 minecraft:redstone_wire replace
setblock ~232 ~50 ~432 minecraft:redstone_wire replace
setblock ~253 ~50 ~436 minecraft:redstone_wire replace
setblock ~268 ~50 ~440 minecraft:redstone_wire replace
setblock ~88 ~50 ~444 minecraft:redstone_wire replace
setblock ~112 ~50 ~448 minecraft:redstone_wire replace
setblock ~133 ~50 ~452 minecraft:redstone_wire replace
setblock ~160 ~50 ~456 minecraft:redstone_wire replace
setblock ~181 ~50 ~460 minecraft:redstone_wire replace
setblock ~205 ~50 ~464 minecraft:redstone_wire replace
setblock ~229 ~50 ~468 minecraft:redstone_wire replace
setblock ~250 ~50 ~472 minecraft:redstone_wire replace
setblock ~292 ~50 ~476 minecraft:redstone_wire replace
setblock ~316 ~50 ~480 minecraft:redstone_wire replace
setblock ~85 ~50 ~484 minecraft:redstone_wire replace
setblock ~109 ~50 ~488 minecraft:redstone_wire replace
setblock ~130 ~50 ~492 minecraft:redstone_wire replace
setblock ~154 ~50 ~496 minecraft:redstone_wire replace
setblock ~178 ~50 ~500 minecraft:redstone_wire replace
setblock ~202 ~50 ~504 minecraft:redstone_wire replace
setblock ~226 ~50 ~508 minecraft:redstone_wire replace
setblock ~247 ~50 ~512 minecraft:redstone_wire replace
setblock ~286 ~50 ~516 minecraft:redstone_wire replace
setblock ~313 ~50 ~520 minecraft:redstone_wire replace
setblock ~82 ~50 ~524 minecraft:redstone_wire replace
setblock ~106 ~50 ~528 minecraft:redstone_wire replace
setblock ~127 ~50 ~532 minecraft:redstone_wire replace
setblock ~148 ~50 ~536 minecraft:redstone_wire replace
setblock ~175 ~50 ~540 minecraft:redstone_wire replace
setblock ~199 ~50 ~544 minecraft:redstone_wire replace
setblock ~223 ~50 ~548 minecraft:redstone_wire replace
setblock ~241 ~50 ~552 minecraft:redstone_wire replace
setblock ~283 ~50 ~556 minecraft:redstone_wire replace
setblock ~307 ~50 ~560 minecraft:redstone_wire replace
setblock ~79 ~50 ~564 minecraft:redstone_wire replace
setblock ~103 ~50 ~568 minecraft:redstone_wire replace
setblock ~124 ~50 ~572 minecraft:redstone_wire replace
setblock ~145 ~50 ~576 minecraft:redstone_wire replace
setblock ~169 ~50 ~580 minecraft:redstone_wire replace
setblock ~190 ~50 ~584 minecraft:redstone_wire replace
setblock ~220 ~50 ~588 minecraft:redstone_wire replace
setblock ~238 ~50 ~592 minecraft:redstone_wire replace
setblock ~280 ~50 ~596 minecraft:redstone_wire replace
setblock ~304 ~50 ~600 minecraft:redstone_wire replace
setblock ~100 ~50 ~604 minecraft:redstone_wire replace
setblock ~121 ~50 ~608 minecraft:redstone_wire replace
setblock ~142 ~50 ~612 minecraft:redstone_wire replace
setblock ~166 ~50 ~616 minecraft:redstone_wire replace
setblock ~187 ~50 ~620 minecraft:redstone_wire replace
setblock ~211 ~50 ~624 minecraft:redstone_wire replace
setblock ~244 ~50 ~628 minecraft:redstone_wire replace
setblock ~256 ~50 ~632 minecraft:redstone_wire replace
setblock ~295 ~50 ~636 minecraft:redstone_wire replace
setblock ~151 ~50 ~640 minecraft:redstone_wire replace
setblock ~322 ~50 ~644 minecraft:redstone_wire replace
setblock ~97 ~50 ~648 minecraft:redstone_wire replace
setblock ~298 ~50 ~652 minecraft:redstone_wire replace
setblock ~319 ~50 ~656 minecraft:redstone_wire replace
fill ~261 ~51 ~32 ~261 ~51 ~44 minecraft:redstone_wire replace
fill ~258 ~51 ~36 ~258 ~51 ~48 minecraft:redstone_wire replace
fill ~213 ~51 ~40 ~213 ~51 ~52 minecraft:redstone_wire replace
setblock ~261 ~51 ~45 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~46 ~261 ~51 ~58 minecraft:redstone_wire replace
setblock ~258 ~51 ~49 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~50 ~258 ~51 ~62 minecraft:redstone_wire replace
setblock ~213 ~51 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~56 ~213 ~51 ~68 minecraft:redstone_wire replace
setblock ~261 ~51 ~60 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~62 ~261 ~51 ~74 minecraft:redstone_wire replace
setblock ~258 ~51 ~64 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~66 ~258 ~51 ~78 minecraft:redstone_wire replace
setblock ~213 ~51 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~72 ~213 ~51 ~84 minecraft:redstone_wire replace
fill ~273 ~51 ~72 ~273 ~51 ~76 minecraft:redstone_wire replace
setblock ~261 ~51 ~76 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~78 ~261 ~51 ~90 minecraft:redstone_wire replace
setblock ~258 ~51 ~80 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~82 ~258 ~51 ~94 minecraft:redstone_wire replace
setblock ~213 ~51 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~88 ~213 ~51 ~100 minecraft:redstone_wire replace
setblock ~261 ~51 ~92 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~94 ~261 ~51 ~106 minecraft:redstone_wire replace
setblock ~258 ~51 ~96 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~98 ~258 ~51 ~110 minecraft:redstone_wire replace
setblock ~213 ~51 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~104 ~213 ~51 ~116 minecraft:redstone_wire replace
setblock ~261 ~51 ~108 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~110 ~261 ~51 ~122 minecraft:redstone_wire replace
setblock ~258 ~51 ~112 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~114 ~258 ~51 ~126 minecraft:redstone_wire replace
setblock ~213 ~51 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~120 ~213 ~51 ~132 minecraft:redstone_wire replace
setblock ~261 ~51 ~124 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~126 ~261 ~51 ~138 minecraft:redstone_wire replace
setblock ~258 ~51 ~128 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~130 ~258 ~51 ~142 minecraft:redstone_wire replace
setblock ~213 ~51 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~136 ~213 ~51 ~148 minecraft:redstone_wire replace
setblock ~261 ~51 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~142 ~261 ~51 ~154 minecraft:redstone_wire replace
setblock ~258 ~51 ~144 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~146 ~258 ~51 ~158 minecraft:redstone_wire replace
setblock ~213 ~51 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~152 ~213 ~51 ~164 minecraft:redstone_wire replace
setblock ~261 ~51 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~158 ~261 ~51 ~170 minecraft:redstone_wire replace
setblock ~258 ~51 ~160 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~162 ~258 ~51 ~174 minecraft:redstone_wire replace
setblock ~213 ~51 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~168 ~213 ~51 ~180 minecraft:redstone_wire replace
setblock ~261 ~51 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~174 ~261 ~51 ~186 minecraft:redstone_wire replace
setblock ~258 ~51 ~176 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~178 ~258 ~51 ~190 minecraft:redstone_wire replace
setblock ~213 ~51 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~184 ~213 ~51 ~196 minecraft:redstone_wire replace
setblock ~261 ~51 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~190 ~261 ~51 ~202 minecraft:redstone_wire replace
setblock ~258 ~51 ~192 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~194 ~258 ~51 ~206 minecraft:redstone_wire replace
setblock ~213 ~51 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~200 ~213 ~51 ~212 minecraft:redstone_wire replace
setblock ~261 ~51 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~206 ~261 ~51 ~218 minecraft:redstone_wire replace
setblock ~258 ~51 ~208 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~210 ~258 ~51 ~222 minecraft:redstone_wire replace
setblock ~213 ~51 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~216 ~213 ~51 ~228 minecraft:redstone_wire replace
setblock ~261 ~51 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~222 ~261 ~51 ~234 minecraft:redstone_wire replace
setblock ~258 ~51 ~224 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~226 ~258 ~51 ~238 minecraft:redstone_wire replace
setblock ~213 ~51 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~232 ~213 ~51 ~244 minecraft:redstone_wire replace
setblock ~261 ~51 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~238 ~261 ~51 ~250 minecraft:redstone_wire replace
fill ~93 ~51 ~240 ~93 ~51 ~246 minecraft:redstone_wire replace
setblock ~258 ~51 ~240 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~242 ~258 ~51 ~254 minecraft:redstone_wire replace
setblock ~213 ~51 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~51 ~248 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~248 ~213 ~51 ~260 minecraft:redstone_wire replace
setblock ~261 ~51 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~254 ~261 ~51 ~266 minecraft:redstone_wire replace
setblock ~258 ~51 ~256 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~258 ~258 ~51 ~270 minecraft:redstone_wire replace
fill ~117 ~51 ~260 ~117 ~51 ~266 minecraft:redstone_wire replace
setblock ~213 ~51 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~264 ~213 ~51 ~276 minecraft:redstone_wire replace
setblock ~117 ~51 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~51 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~270 ~261 ~51 ~282 minecraft:redstone_wire replace
setblock ~258 ~51 ~272 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~274 ~258 ~51 ~286 minecraft:redstone_wire replace
fill ~138 ~51 ~276 ~138 ~51 ~282 minecraft:redstone_wire replace
setblock ~213 ~51 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~280 ~213 ~51 ~292 minecraft:redstone_wire replace
setblock ~138 ~51 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~51 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~286 ~261 ~51 ~298 minecraft:redstone_wire replace
fill ~156 ~51 ~288 ~156 ~51 ~294 minecraft:redstone_wire replace
setblock ~258 ~51 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~290 ~258 ~51 ~302 minecraft:redstone_wire replace
setblock ~213 ~51 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~51 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~296 ~213 ~51 ~308 minecraft:redstone_wire replace
setblock ~261 ~51 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~302 ~261 ~51 ~314 minecraft:redstone_wire replace
setblock ~258 ~51 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~306 ~258 ~51 ~318 minecraft:redstone_wire replace
fill ~192 ~51 ~308 ~192 ~51 ~320 minecraft:redstone_wire replace
setblock ~213 ~51 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~51 ~312 ~171 ~51 ~318 minecraft:redstone_wire replace
fill ~213 ~51 ~312 ~213 ~51 ~324 minecraft:redstone_wire replace
setblock ~261 ~51 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~318 ~261 ~51 ~330 minecraft:redstone_wire replace
setblock ~171 ~51 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~51 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~51 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~322 ~258 ~51 ~334 minecraft:redstone_wire replace
fill ~192 ~51 ~324 ~192 ~51 ~328 minecraft:redstone_wire replace
setblock ~213 ~51 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~328 ~213 ~51 ~340 minecraft:redstone_wire replace
setblock ~261 ~51 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~334 ~261 ~51 ~346 minecraft:redstone_wire replace
fill ~195 ~51 ~336 ~195 ~51 ~340 minecraft:redstone_wire replace
setblock ~258 ~51 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~338 ~258 ~51 ~350 minecraft:redstone_wire replace
setblock ~213 ~51 ~341 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~342 ~213 ~51 ~344 minecraft:redstone_wire replace
setblock ~261 ~51 ~348 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~350 ~261 ~51 ~362 minecraft:redstone_wire replace
fill ~216 ~51 ~352 ~216 ~51 ~356 minecraft:redstone_wire replace
setblock ~258 ~51 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~354 ~258 ~51 ~366 minecraft:redstone_wire replace
setblock ~261 ~51 ~363 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~51 ~364 minecraft:redstone_wire replace
fill ~264 ~51 ~364 ~264 ~51 ~368 minecraft:redstone_wire replace
setblock ~258 ~51 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~370 ~258 ~51 ~376 minecraft:redstone_wire replace
fill ~234 ~51 ~380 ~234 ~51 ~384 minecraft:redstone_wire replace
fill ~288 ~51 ~384 ~288 ~51 ~388 minecraft:redstone_wire replace
fill ~309 ~51 ~388 ~309 ~51 ~392 minecraft:redstone_wire replace
fill ~276 ~51 ~392 ~276 ~51 ~396 minecraft:redstone_wire replace
fill ~300 ~51 ~396 ~300 ~51 ~400 minecraft:redstone_wire replace
fill ~270 ~51 ~400 ~270 ~51 ~404 minecraft:redstone_wire replace
fill ~90 ~51 ~408 ~90 ~51 ~412 minecraft:redstone_wire replace
fill ~114 ~51 ~412 ~114 ~51 ~416 minecraft:redstone_wire replace
fill ~135 ~51 ~416 ~135 ~51 ~420 minecraft:redstone_wire replace
fill ~162 ~51 ~420 ~162 ~51 ~424 minecraft:redstone_wire replace
fill ~183 ~51 ~424 ~183 ~51 ~428 minecraft:redstone_wire replace
fill ~207 ~51 ~428 ~207 ~51 ~432 minecraft:redstone_wire replace
fill ~231 ~51 ~432 ~231 ~51 ~436 minecraft:redstone_wire replace
fill ~252 ~51 ~436 ~252 ~51 ~440 minecraft:redstone_wire replace
fill ~267 ~51 ~440 ~267 ~51 ~444 minecraft:redstone_wire replace
fill ~87 ~51 ~444 ~87 ~51 ~448 minecraft:redstone_wire replace
fill ~111 ~51 ~448 ~111 ~51 ~452 minecraft:redstone_wire replace
fill ~132 ~51 ~452 ~132 ~51 ~456 minecraft:redstone_wire replace
fill ~159 ~51 ~456 ~159 ~51 ~460 minecraft:redstone_wire replace
fill ~180 ~51 ~460 ~180 ~51 ~464 minecraft:redstone_wire replace
fill ~204 ~51 ~464 ~204 ~51 ~468 minecraft:redstone_wire replace
fill ~228 ~51 ~468 ~228 ~51 ~472 minecraft:redstone_wire replace
fill ~249 ~51 ~472 ~249 ~51 ~476 minecraft:redstone_wire replace
fill ~291 ~51 ~476 ~291 ~51 ~480 minecraft:redstone_wire replace
fill ~315 ~51 ~480 ~315 ~51 ~484 minecraft:redstone_wire replace
fill ~84 ~51 ~484 ~84 ~51 ~488 minecraft:redstone_wire replace
fill ~108 ~51 ~488 ~108 ~51 ~492 minecraft:redstone_wire replace
fill ~129 ~51 ~492 ~129 ~51 ~496 minecraft:redstone_wire replace
fill ~153 ~51 ~496 ~153 ~51 ~500 minecraft:redstone_wire replace
fill ~177 ~51 ~500 ~177 ~51 ~504 minecraft:redstone_wire replace
fill ~201 ~51 ~504 ~201 ~51 ~508 minecraft:redstone_wire replace
fill ~225 ~51 ~508 ~225 ~51 ~512 minecraft:redstone_wire replace
fill ~246 ~51 ~512 ~246 ~51 ~516 minecraft:redstone_wire replace
fill ~285 ~51 ~516 ~285 ~51 ~520 minecraft:redstone_wire replace
fill ~312 ~51 ~520 ~312 ~51 ~524 minecraft:redstone_wire replace
fill ~81 ~51 ~524 ~81 ~51 ~528 minecraft:redstone_wire replace
fill ~105 ~51 ~528 ~105 ~51 ~532 minecraft:redstone_wire replace
fill ~126 ~51 ~532 ~126 ~51 ~536 minecraft:redstone_wire replace
fill ~147 ~51 ~536 ~147 ~51 ~540 minecraft:redstone_wire replace
fill ~174 ~51 ~540 ~174 ~51 ~544 minecraft:redstone_wire replace
fill ~198 ~51 ~544 ~198 ~51 ~548 minecraft:redstone_wire replace
fill ~222 ~51 ~548 ~222 ~51 ~552 minecraft:redstone_wire replace
fill ~240 ~51 ~552 ~240 ~51 ~556 minecraft:redstone_wire replace
fill ~282 ~51 ~556 ~282 ~51 ~560 minecraft:redstone_wire replace
fill ~306 ~51 ~560 ~306 ~51 ~564 minecraft:redstone_wire replace
fill ~78 ~51 ~564 ~78 ~51 ~568 minecraft:redstone_wire replace
fill ~102 ~51 ~568 ~102 ~51 ~572 minecraft:redstone_wire replace
fill ~123 ~51 ~572 ~123 ~51 ~576 minecraft:redstone_wire replace
fill ~144 ~51 ~576 ~144 ~51 ~580 minecraft:redstone_wire replace
fill ~168 ~51 ~580 ~168 ~51 ~584 minecraft:redstone_wire replace
fill ~189 ~51 ~584 ~189 ~51 ~588 minecraft:redstone_wire replace
fill ~219 ~51 ~588 ~219 ~51 ~592 minecraft:redstone_wire replace
fill ~237 ~51 ~592 ~237 ~51 ~596 minecraft:redstone_wire replace
fill ~279 ~51 ~596 ~279 ~51 ~600 minecraft:redstone_wire replace
fill ~303 ~51 ~600 ~303 ~51 ~604 minecraft:redstone_wire replace
fill ~99 ~51 ~604 ~99 ~51 ~608 minecraft:redstone_wire replace
fill ~120 ~51 ~608 ~120 ~51 ~612 minecraft:redstone_wire replace
fill ~141 ~51 ~612 ~141 ~51 ~616 minecraft:redstone_wire replace
fill ~165 ~51 ~616 ~165 ~51 ~620 minecraft:redstone_wire replace
fill ~186 ~51 ~620 ~186 ~51 ~624 minecraft:redstone_wire replace
fill ~210 ~51 ~624 ~210 ~51 ~628 minecraft:redstone_wire replace
fill ~243 ~51 ~628 ~243 ~51 ~632 minecraft:redstone_wire replace
fill ~255 ~51 ~632 ~255 ~51 ~636 minecraft:redstone_wire replace
fill ~294 ~51 ~636 ~294 ~51 ~640 minecraft:redstone_wire replace
fill ~150 ~51 ~640 ~150 ~51 ~644 minecraft:redstone_wire replace
fill ~321 ~51 ~644 ~321 ~51 ~648 minecraft:redstone_wire replace
fill ~96 ~51 ~648 ~96 ~51 ~652 minecraft:redstone_wire replace
fill ~297 ~51 ~652 ~297 ~51 ~656 minecraft:redstone_wire replace
fill ~318 ~51 ~656 ~318 ~51 ~660 minecraft:redstone_wire replace
setblock ~273 ~52 ~77 minecraft:redstone_wire replace
setblock ~93 ~52 ~249 minecraft:redstone_wire replace
setblock ~117 ~52 ~269 minecraft:redstone_wire replace
setblock ~138 ~52 ~285 minecraft:redstone_wire replace
setblock ~156 ~52 ~297 minecraft:redstone_wire replace
setblock ~171 ~52 ~321 minecraft:redstone_wire replace
setblock ~192 ~52 ~329 minecraft:redstone_wire replace
setblock ~195 ~52 ~341 minecraft:redstone_wire replace
setblock ~213 ~52 ~345 minecraft:redstone_wire replace
setblock ~216 ~52 ~357 minecraft:redstone_wire replace
setblock ~261 ~52 ~365 minecraft:redstone_wire replace
setblock ~264 ~52 ~369 minecraft:redstone_wire replace
setblock ~258 ~52 ~377 minecraft:redstone_wire replace
setblock ~234 ~52 ~385 minecraft:redstone_wire replace
setblock ~288 ~52 ~389 minecraft:redstone_wire replace
setblock ~309 ~52 ~393 minecraft:redstone_wire replace
setblock ~276 ~52 ~397 minecraft:redstone_wire replace
setblock ~300 ~52 ~401 minecraft:redstone_wire replace
setblock ~270 ~52 ~405 minecraft:redstone_wire replace
setblock ~90 ~52 ~413 minecraft:redstone_wire replace
setblock ~114 ~52 ~417 minecraft:redstone_wire replace
setblock ~135 ~52 ~421 minecraft:redstone_wire replace
setblock ~162 ~52 ~425 minecraft:redstone_wire replace
setblock ~183 ~52 ~429 minecraft:redstone_wire replace
setblock ~207 ~52 ~433 minecraft:redstone_wire replace
setblock ~231 ~52 ~437 minecraft:redstone_wire replace
setblock ~252 ~52 ~441 minecraft:redstone_wire replace
setblock ~267 ~52 ~445 minecraft:redstone_wire replace
setblock ~87 ~52 ~449 minecraft:redstone_wire replace
setblock ~111 ~52 ~453 minecraft:redstone_wire replace
setblock ~132 ~52 ~457 minecraft:redstone_wire replace
setblock ~159 ~52 ~461 minecraft:redstone_wire replace
setblock ~180 ~52 ~465 minecraft:redstone_wire replace
setblock ~204 ~52 ~469 minecraft:redstone_wire replace
setblock ~228 ~52 ~473 minecraft:redstone_wire replace
setblock ~249 ~52 ~477 minecraft:redstone_wire replace
setblock ~291 ~52 ~481 minecraft:redstone_wire replace
setblock ~315 ~52 ~485 minecraft:redstone_wire replace
setblock ~84 ~52 ~489 minecraft:redstone_wire replace
setblock ~108 ~52 ~493 minecraft:redstone_wire replace
setblock ~129 ~52 ~497 minecraft:redstone_wire replace
setblock ~153 ~52 ~501 minecraft:redstone_wire replace
setblock ~177 ~52 ~505 minecraft:redstone_wire replace
setblock ~201 ~52 ~509 minecraft:redstone_wire replace
setblock ~225 ~52 ~513 minecraft:redstone_wire replace
setblock ~246 ~52 ~517 minecraft:redstone_wire replace
setblock ~285 ~52 ~521 minecraft:redstone_wire replace
setblock ~312 ~52 ~525 minecraft:redstone_wire replace
setblock ~81 ~52 ~529 minecraft:redstone_wire replace
setblock ~105 ~52 ~533 minecraft:redstone_wire replace
setblock ~126 ~52 ~537 minecraft:redstone_wire replace
setblock ~147 ~52 ~541 minecraft:redstone_wire replace
setblock ~174 ~52 ~545 minecraft:redstone_wire replace
setblock ~198 ~52 ~549 minecraft:redstone_wire replace
setblock ~222 ~52 ~553 minecraft:redstone_wire replace
setblock ~240 ~52 ~557 minecraft:redstone_wire replace
setblock ~282 ~52 ~561 minecraft:redstone_wire replace
setblock ~306 ~52 ~565 minecraft:redstone_wire replace
setblock ~78 ~52 ~569 minecraft:redstone_wire replace
setblock ~102 ~52 ~573 minecraft:redstone_wire replace
setblock ~123 ~52 ~577 minecraft:redstone_wire replace
setblock ~144 ~52 ~581 minecraft:redstone_wire replace
setblock ~168 ~52 ~585 minecraft:redstone_wire replace
setblock ~189 ~52 ~589 minecraft:redstone_wire replace
setblock ~219 ~52 ~593 minecraft:redstone_wire replace
setblock ~237 ~52 ~597 minecraft:redstone_wire replace
setblock ~279 ~52 ~601 minecraft:redstone_wire replace
setblock ~303 ~52 ~605 minecraft:redstone_wire replace
setblock ~99 ~52 ~609 minecraft:redstone_wire replace
setblock ~120 ~52 ~613 minecraft:redstone_wire replace
setblock ~141 ~52 ~617 minecraft:redstone_wire replace
setblock ~165 ~52 ~621 minecraft:redstone_wire replace
setblock ~186 ~52 ~625 minecraft:redstone_wire replace
setblock ~210 ~52 ~629 minecraft:redstone_wire replace
setblock ~243 ~52 ~633 minecraft:redstone_wire replace
setblock ~255 ~52 ~637 minecraft:redstone_wire replace
setblock ~294 ~52 ~641 minecraft:redstone_wire replace
setblock ~150 ~52 ~645 minecraft:redstone_wire replace
setblock ~321 ~52 ~649 minecraft:redstone_wire replace
setblock ~96 ~52 ~653 minecraft:redstone_wire replace
setblock ~297 ~52 ~657 minecraft:redstone_wire replace
setblock ~318 ~52 ~661 minecraft:redstone_wire replace
fill ~273 ~53 ~78 ~275 ~53 ~78 minecraft:redstone_wire replace
setblock ~274 ~53 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~53 ~250 ~95 ~53 ~250 minecraft:redstone_wire replace
setblock ~94 ~53 ~251 minecraft:redstone_wire replace
fill ~117 ~53 ~270 ~119 ~53 ~270 minecraft:redstone_wire replace
setblock ~118 ~53 ~271 minecraft:redstone_wire replace
fill ~138 ~53 ~286 ~140 ~53 ~286 minecraft:redstone_wire replace
setblock ~139 ~53 ~287 minecraft:redstone_wire replace
fill ~153 ~53 ~298 ~156 ~53 ~298 minecraft:redstone_wire replace
setblock ~154 ~53 ~299 minecraft:redstone_wire replace
fill ~168 ~53 ~322 ~171 ~53 ~322 minecraft:redstone_wire replace
setblock ~169 ~53 ~323 minecraft:redstone_wire replace
fill ~189 ~53 ~330 ~194 ~53 ~330 minecraft:redstone_wire replace
setblock ~190 ~53 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~53 ~331 minecraft:redstone_wire replace
fill ~189 ~53 ~342 ~195 ~53 ~342 minecraft:redstone_wire replace
setblock ~190 ~53 ~343 minecraft:redstone_wire replace
setblock ~193 ~53 ~343 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~53 ~346 ~215 ~53 ~346 minecraft:redstone_wire replace
setblock ~211 ~53 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~53 ~347 minecraft:redstone_wire replace
fill ~210 ~53 ~358 ~216 ~53 ~358 minecraft:redstone_wire replace
setblock ~211 ~53 ~359 minecraft:redstone_wire replace
setblock ~214 ~53 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~53 ~366 ~266 ~53 ~366 minecraft:redstone_wire replace
setblock ~262 ~53 ~367 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~265 ~53 ~367 minecraft:redstone_wire replace
fill ~261 ~53 ~370 ~266 ~53 ~370 minecraft:redstone_wire replace
setblock ~262 ~53 ~371 minecraft:redstone_wire replace
setblock ~265 ~53 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~53 ~378 ~236 ~53 ~378 minecraft:redstone_wire replace
setblock ~237 ~53 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~53 ~378 ~250 ~53 ~378 minecraft:redstone_wire replace
setblock ~252 ~53 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~53 ~378 ~263 ~53 ~378 minecraft:redstone_wire replace
setblock ~265 ~53 ~378 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~53 ~378 ~280 ~53 ~378 minecraft:redstone_wire replace
setblock ~282 ~53 ~378 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~284 ~53 ~378 ~297 ~53 ~378 minecraft:redstone_wire replace
setblock ~299 ~53 ~378 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~53 ~378 ~308 ~53 ~378 minecraft:redstone_wire replace
setblock ~235 ~53 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~238 ~53 ~379 minecraft:redstone_wire replace
setblock ~271 ~53 ~379 minecraft:redstone_wire replace
setblock ~307 ~53 ~379 minecraft:redstone_wire replace
fill ~234 ~53 ~386 ~239 ~53 ~386 minecraft:redstone_wire replace
setblock ~235 ~53 ~387 minecraft:redstone_wire replace
setblock ~238 ~53 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~53 ~390 ~278 ~53 ~390 minecraft:redstone_wire replace
setblock ~280 ~53 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~53 ~390 ~294 ~53 ~390 minecraft:redstone_wire replace
setblock ~296 ~53 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~53 ~390 ~308 ~53 ~390 minecraft:redstone_wire replace
setblock ~271 ~53 ~391 minecraft:redstone_wire replace
setblock ~307 ~53 ~391 minecraft:redstone_wire replace
fill ~309 ~53 ~394 ~311 ~53 ~394 minecraft:redstone_wire replace
setblock ~310 ~53 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~53 ~398 ~278 ~53 ~398 minecraft:redstone_wire replace
setblock ~277 ~53 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~53 ~402 ~300 ~53 ~402 minecraft:redstone_wire replace
setblock ~298 ~53 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~53 ~406 ~272 ~53 ~406 minecraft:redstone_wire replace
setblock ~271 ~53 ~407 minecraft:redstone_wire replace
fill ~90 ~53 ~414 ~92 ~53 ~414 minecraft:redstone_wire replace
setblock ~91 ~53 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~53 ~418 ~116 ~53 ~418 minecraft:redstone_wire replace
setblock ~115 ~53 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~53 ~422 ~137 ~53 ~422 minecraft:redstone_wire replace
setblock ~136 ~53 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~53 ~426 ~162 ~53 ~426 minecraft:redstone_wire replace
setblock ~160 ~53 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~53 ~430 ~183 ~53 ~430 minecraft:redstone_wire replace
setblock ~181 ~53 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~53 ~434 ~207 ~53 ~434 minecraft:redstone_wire replace
setblock ~205 ~53 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~53 ~438 ~233 ~53 ~438 minecraft:redstone_wire replace
setblock ~232 ~53 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~252 ~53 ~442 ~257 ~53 ~442 minecraft:redstone_wire replace
setblock ~256 ~53 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~53 ~446 ~269 ~53 ~446 minecraft:redstone_wire replace
setblock ~268 ~53 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~53 ~450 ~89 ~53 ~450 minecraft:redstone_wire replace
setblock ~88 ~53 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~53 ~454 ~113 ~53 ~454 minecraft:redstone_wire replace
setblock ~112 ~53 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~53 ~458 ~134 ~53 ~458 minecraft:redstone_wire replace
setblock ~133 ~53 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~53 ~462 ~159 ~53 ~462 minecraft:redstone_wire replace
setblock ~157 ~53 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~53 ~466 ~180 ~53 ~466 minecraft:redstone_wire replace
setblock ~178 ~53 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~53 ~470 ~204 ~53 ~470 minecraft:redstone_wire replace
setblock ~202 ~53 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~53 ~474 ~228 ~53 ~474 minecraft:redstone_wire replace
setblock ~226 ~53 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~53 ~478 ~254 ~53 ~478 minecraft:redstone_wire replace
setblock ~253 ~53 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~53 ~482 ~291 ~53 ~482 minecraft:redstone_wire replace
setblock ~289 ~53 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~53 ~486 ~317 ~53 ~486 minecraft:redstone_wire replace
setblock ~316 ~53 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~53 ~490 ~86 ~53 ~490 minecraft:redstone_wire replace
setblock ~85 ~53 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~53 ~494 ~110 ~53 ~494 minecraft:redstone_wire replace
setblock ~109 ~53 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~53 ~498 ~131 ~53 ~498 minecraft:redstone_wire replace
setblock ~130 ~53 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~53 ~502 ~153 ~53 ~502 minecraft:redstone_wire replace
setblock ~151 ~53 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~53 ~506 ~177 ~53 ~506 minecraft:redstone_wire replace
setblock ~175 ~53 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~53 ~510 ~201 ~53 ~510 minecraft:redstone_wire replace
setblock ~199 ~53 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~53 ~514 ~225 ~53 ~514 minecraft:redstone_wire replace
setblock ~223 ~53 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~53 ~518 ~251 ~53 ~518 minecraft:redstone_wire replace
setblock ~250 ~53 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~53 ~522 ~287 ~53 ~522 minecraft:redstone_wire replace
setblock ~286 ~53 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~53 ~526 ~314 ~53 ~526 minecraft:redstone_wire replace
setblock ~313 ~53 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~53 ~530 ~83 ~53 ~530 minecraft:redstone_wire replace
setblock ~82 ~53 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~53 ~534 ~107 ~53 ~534 minecraft:redstone_wire replace
setblock ~106 ~53 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~53 ~538 ~128 ~53 ~538 minecraft:redstone_wire replace
setblock ~127 ~53 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~53 ~542 ~149 ~53 ~542 minecraft:redstone_wire replace
setblock ~148 ~53 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~53 ~546 ~174 ~53 ~546 minecraft:redstone_wire replace
setblock ~172 ~53 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~53 ~550 ~198 ~53 ~550 minecraft:redstone_wire replace
setblock ~196 ~53 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~53 ~554 ~222 ~53 ~554 minecraft:redstone_wire replace
setblock ~220 ~53 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~53 ~558 ~245 ~53 ~558 minecraft:redstone_wire replace
setblock ~244 ~53 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~53 ~562 ~284 ~53 ~562 minecraft:redstone_wire replace
setblock ~283 ~53 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~53 ~566 ~306 ~53 ~566 minecraft:redstone_wire replace
setblock ~304 ~53 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~53 ~570 ~80 ~53 ~570 minecraft:redstone_wire replace
setblock ~79 ~53 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~53 ~574 ~104 ~53 ~574 minecraft:redstone_wire replace
setblock ~103 ~53 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~53 ~578 ~125 ~53 ~578 minecraft:redstone_wire replace
setblock ~124 ~53 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~53 ~582 ~146 ~53 ~582 minecraft:redstone_wire replace
setblock ~145 ~53 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~53 ~586 ~168 ~53 ~586 minecraft:redstone_wire replace
setblock ~166 ~53 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~53 ~590 ~189 ~53 ~590 minecraft:redstone_wire replace
setblock ~187 ~53 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~216 ~53 ~594 ~219 ~53 ~594 minecraft:redstone_wire replace
setblock ~217 ~53 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~53 ~598 ~242 ~53 ~598 minecraft:redstone_wire replace
setblock ~241 ~53 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~279 ~53 ~602 ~281 ~53 ~602 minecraft:redstone_wire replace
setblock ~280 ~53 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~53 ~606 ~303 ~53 ~606 minecraft:redstone_wire replace
setblock ~301 ~53 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~53 ~610 ~101 ~53 ~610 minecraft:redstone_wire replace
setblock ~100 ~53 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~53 ~614 ~122 ~53 ~614 minecraft:redstone_wire replace
setblock ~121 ~53 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~53 ~618 ~143 ~53 ~618 minecraft:redstone_wire replace
setblock ~142 ~53 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~53 ~622 ~165 ~53 ~622 minecraft:redstone_wire replace
setblock ~163 ~53 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~53 ~626 ~186 ~53 ~626 minecraft:redstone_wire replace
setblock ~184 ~53 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~53 ~630 ~210 ~53 ~630 minecraft:redstone_wire replace
setblock ~208 ~53 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~243 ~53 ~634 ~248 ~53 ~634 minecraft:redstone_wire replace
setblock ~247 ~53 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~53 ~638 ~260 ~53 ~638 minecraft:redstone_wire replace
setblock ~259 ~53 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~53 ~642 ~294 ~53 ~642 minecraft:redstone_wire replace
setblock ~292 ~53 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~53 ~646 ~106 ~53 ~646 minecraft:redstone_wire replace
setblock ~108 ~53 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~53 ~646 ~123 ~53 ~646 minecraft:redstone_wire replace
setblock ~125 ~53 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~53 ~646 ~140 ~53 ~646 minecraft:redstone_wire replace
setblock ~142 ~53 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~53 ~646 ~156 ~53 ~646 minecraft:redstone_wire replace
setblock ~158 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~53 ~646 ~173 ~53 ~646 minecraft:redstone_wire replace
setblock ~175 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~53 ~646 ~190 ~53 ~646 minecraft:redstone_wire replace
setblock ~192 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~53 ~646 ~207 ~53 ~646 minecraft:redstone_wire replace
setblock ~209 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~53 ~646 ~224 ~53 ~646 minecraft:redstone_wire replace
setblock ~226 ~53 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~53 ~646 ~230 ~53 ~646 minecraft:redstone_wire replace
setblock ~94 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~53 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~53 ~650 ~323 ~53 ~650 minecraft:redstone_wire replace
setblock ~322 ~53 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~53 ~654 ~98 ~53 ~654 minecraft:redstone_wire replace
setblock ~97 ~53 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~53 ~658 ~297 ~53 ~658 minecraft:redstone_wire replace
setblock ~295 ~53 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~53 ~662 ~320 ~53 ~662 minecraft:redstone_wire replace
setblock ~319 ~53 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~274 ~54 ~80 minecraft:redstone_wire replace
setblock ~94 ~54 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~54 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~54 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~54 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~54 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~54 ~332 minecraft:redstone_wire replace
setblock ~193 ~54 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~54 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~54 ~344 minecraft:redstone_wire replace
setblock ~211 ~54 ~348 minecraft:redstone_wire replace
setblock ~214 ~54 ~348 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~54 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~54 ~360 minecraft:redstone_wire replace
setblock ~262 ~54 ~368 minecraft:redstone_wire replace
setblock ~265 ~54 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~54 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~54 ~372 minecraft:redstone_wire replace
setblock ~235 ~54 ~380 minecraft:redstone_wire replace
setblock ~238 ~54 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~54 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~54 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~54 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~54 ~388 minecraft:redstone_wire replace
setblock ~271 ~54 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~54 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~54 ~396 minecraft:redstone_wire replace
setblock ~277 ~54 ~400 minecraft:redstone_wire replace
setblock ~298 ~54 ~404 minecraft:redstone_wire replace
setblock ~271 ~54 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~54 ~416 minecraft:redstone_wire replace
setblock ~115 ~54 ~420 minecraft:redstone_wire replace
setblock ~136 ~54 ~424 minecraft:redstone_wire replace
setblock ~160 ~54 ~428 minecraft:redstone_wire replace
setblock ~181 ~54 ~432 minecraft:redstone_wire replace
setblock ~205 ~54 ~436 minecraft:redstone_wire replace
setblock ~232 ~54 ~440 minecraft:redstone_wire replace
setblock ~256 ~54 ~444 minecraft:redstone_wire replace
setblock ~268 ~54 ~448 minecraft:redstone_wire replace
setblock ~88 ~54 ~452 minecraft:redstone_wire replace
setblock ~112 ~54 ~456 minecraft:redstone_wire replace
setblock ~133 ~54 ~460 minecraft:redstone_wire replace
setblock ~157 ~54 ~464 minecraft:redstone_wire replace
setblock ~178 ~54 ~468 minecraft:redstone_wire replace
setblock ~202 ~54 ~472 minecraft:redstone_wire replace
setblock ~226 ~54 ~476 minecraft:redstone_wire replace
setblock ~253 ~54 ~480 minecraft:redstone_wire replace
setblock ~289 ~54 ~484 minecraft:redstone_wire replace
setblock ~316 ~54 ~488 minecraft:redstone_wire replace
setblock ~85 ~54 ~492 minecraft:redstone_wire replace
setblock ~109 ~54 ~496 minecraft:redstone_wire replace
setblock ~130 ~54 ~500 minecraft:redstone_wire replace
setblock ~151 ~54 ~504 minecraft:redstone_wire replace
setblock ~175 ~54 ~508 minecraft:redstone_wire replace
setblock ~199 ~54 ~512 minecraft:redstone_wire replace
setblock ~223 ~54 ~516 minecraft:redstone_wire replace
setblock ~250 ~54 ~520 minecraft:redstone_wire replace
setblock ~286 ~54 ~524 minecraft:redstone_wire replace
setblock ~313 ~54 ~528 minecraft:redstone_wire replace
setblock ~82 ~54 ~532 minecraft:redstone_wire replace
setblock ~106 ~54 ~536 minecraft:redstone_wire replace
setblock ~127 ~54 ~540 minecraft:redstone_wire replace
setblock ~148 ~54 ~544 minecraft:redstone_wire replace
setblock ~172 ~54 ~548 minecraft:redstone_wire replace
setblock ~196 ~54 ~552 minecraft:redstone_wire replace
setblock ~220 ~54 ~556 minecraft:redstone_wire replace
setblock ~244 ~54 ~560 minecraft:redstone_wire replace
setblock ~283 ~54 ~564 minecraft:redstone_wire replace
setblock ~304 ~54 ~568 minecraft:redstone_wire replace
setblock ~79 ~54 ~572 minecraft:redstone_wire replace
setblock ~103 ~54 ~576 minecraft:redstone_wire replace
setblock ~124 ~54 ~580 minecraft:redstone_wire replace
setblock ~145 ~54 ~584 minecraft:redstone_wire replace
setblock ~166 ~54 ~588 minecraft:redstone_wire replace
setblock ~187 ~54 ~592 minecraft:redstone_wire replace
setblock ~217 ~54 ~596 minecraft:redstone_wire replace
setblock ~241 ~54 ~600 minecraft:redstone_wire replace
setblock ~280 ~54 ~604 minecraft:redstone_wire replace
setblock ~301 ~54 ~608 minecraft:redstone_wire replace
setblock ~100 ~54 ~612 minecraft:redstone_wire replace
setblock ~121 ~54 ~616 minecraft:redstone_wire replace
setblock ~142 ~54 ~620 minecraft:redstone_wire replace
setblock ~163 ~54 ~624 minecraft:redstone_wire replace
setblock ~184 ~54 ~628 minecraft:redstone_wire replace
setblock ~208 ~54 ~632 minecraft:redstone_wire replace
setblock ~247 ~54 ~636 minecraft:redstone_wire replace
setblock ~259 ~54 ~640 minecraft:redstone_wire replace
setblock ~292 ~54 ~644 minecraft:redstone_wire replace
setblock ~94 ~54 ~648 minecraft:redstone_wire replace
setblock ~118 ~54 ~648 minecraft:redstone_wire replace
setblock ~139 ~54 ~648 minecraft:redstone_wire replace
setblock ~154 ~54 ~648 minecraft:redstone_wire replace
setblock ~169 ~54 ~648 minecraft:redstone_wire replace
setblock ~229 ~54 ~648 minecraft:redstone_wire replace
setblock ~322 ~54 ~652 minecraft:redstone_wire replace
setblock ~97 ~54 ~656 minecraft:redstone_wire replace
setblock ~295 ~54 ~660 minecraft:redstone_wire replace
setblock ~319 ~54 ~664 minecraft:redstone_wire replace
fill ~273 ~55 ~76 ~273 ~55 ~80 minecraft:redstone_wire replace
fill ~93 ~55 ~248 ~93 ~55 ~250 minecraft:redstone_wire replace
setblock ~93 ~55 ~251 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~252 ~93 ~55 ~264 minecraft:redstone_wire replace
setblock ~93 ~55 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~268 ~93 ~55 ~280 minecraft:redstone_wire replace
setblock ~117 ~55 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~55 ~270 ~117 ~55 ~280 minecraft:redstone_wire replace
setblock ~93 ~55 ~282 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~282 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~284 ~93 ~55 ~296 minecraft:redstone_wire replace
fill ~117 ~55 ~284 ~117 ~55 ~296 minecraft:redstone_wire replace
setblock ~138 ~55 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~55 ~286 ~138 ~55 ~296 minecraft:redstone_wire replace
fill ~153 ~55 ~296 ~153 ~55 ~298 minecraft:redstone_wire replace
setblock ~93 ~55 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~299 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~300 ~93 ~55 ~312 minecraft:redstone_wire replace
fill ~117 ~55 ~300 ~117 ~55 ~312 minecraft:redstone_wire replace
fill ~138 ~55 ~300 ~138 ~55 ~312 minecraft:redstone_wire replace
fill ~153 ~55 ~300 ~153 ~55 ~312 minecraft:redstone_wire replace
setblock ~93 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~316 ~93 ~55 ~328 minecraft:redstone_wire replace
fill ~117 ~55 ~316 ~117 ~55 ~328 minecraft:redstone_wire replace
fill ~138 ~55 ~316 ~138 ~55 ~328 minecraft:redstone_wire replace
fill ~153 ~55 ~316 ~153 ~55 ~328 minecraft:redstone_wire replace
setblock ~168 ~55 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~55 ~322 ~168 ~55 ~328 minecraft:redstone_wire replace
fill ~192 ~55 ~324 ~192 ~55 ~330 minecraft:redstone_wire replace
fill ~189 ~55 ~328 ~189 ~55 ~330 minecraft:redstone_wire replace
setblock ~93 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~55 ~331 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~55 ~331 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~332 ~93 ~55 ~344 minecraft:redstone_wire replace
fill ~117 ~55 ~332 ~117 ~55 ~344 minecraft:redstone_wire replace
fill ~138 ~55 ~332 ~138 ~55 ~344 minecraft:redstone_wire replace
fill ~153 ~55 ~332 ~153 ~55 ~344 minecraft:redstone_wire replace
fill ~168 ~55 ~332 ~168 ~55 ~344 minecraft:redstone_wire replace
fill ~189 ~55 ~332 ~189 ~55 ~344 minecraft:redstone_wire replace
fill ~192 ~55 ~332 ~192 ~55 ~344 minecraft:redstone_wire replace
fill ~213 ~55 ~340 ~213 ~55 ~346 minecraft:redstone_wire replace
fill ~210 ~55 ~344 ~210 ~55 ~346 minecraft:redstone_wire replace
setblock ~93 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~55 ~347 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~55 ~347 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~348 ~93 ~55 ~360 minecraft:redstone_wire replace
fill ~117 ~55 ~348 ~117 ~55 ~360 minecraft:redstone_wire replace
fill ~138 ~55 ~348 ~138 ~55 ~360 minecraft:redstone_wire replace
fill ~153 ~55 ~348 ~153 ~55 ~360 minecraft:redstone_wire replace
fill ~168 ~55 ~348 ~168 ~55 ~360 minecraft:redstone_wire replace
fill ~210 ~55 ~348 ~210 ~55 ~360 minecraft:redstone_wire replace
fill ~213 ~55 ~348 ~213 ~55 ~360 minecraft:redstone_wire replace
setblock ~264 ~55 ~356 minecraft:redstone_wire replace
setblock ~264 ~55 ~358 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~261 ~55 ~360 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~55 ~360 ~264 ~55 ~372 minecraft:redstone_wire replace
setblock ~93 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
