setblock ~165 ~43 ~63 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~65 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~69 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~71 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~75 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~77 minecraft:light_gray_concrete replace
setblock ~318 ~43 ~77 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~79 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~81 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~85 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~87 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~91 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~93 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~95 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~97 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~101 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~103 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~107 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~109 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~111 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~113 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~117 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~119 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~123 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~125 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~127 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~129 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~133 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~135 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~139 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~141 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~143 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~145 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~149 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~151 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~155 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~157 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~159 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~161 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~165 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~167 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~171 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~173 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~175 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~177 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~181 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~183 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~187 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~189 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~191 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~193 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~197 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~199 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~203 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~205 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~207 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~209 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~213 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~215 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~219 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~221 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~223 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~225 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~229 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~231 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~235 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~237 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~239 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~241 minecraft:light_gray_concrete replace
setblock ~94 ~43 ~244 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~245 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~247 minecraft:light_gray_concrete replace
setblock ~124 ~43 ~248 minecraft:light_gray_concrete replace
setblock ~93 ~43 ~249 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~252 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~256 minecraft:light_gray_concrete replace
setblock ~145 ~43 ~260 minecraft:light_gray_concrete replace
setblock ~123 ~43 ~261 minecraft:light_gray_concrete replace
setblock ~123 ~43 ~263 minecraft:light_gray_concrete replace
setblock ~124 ~43 ~264 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~265 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~267 minecraft:light_gray_concrete replace
setblock ~123 ~43 ~269 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~269 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~271 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~275 minecraft:light_gray_concrete replace
setblock ~121 ~43 ~276 minecraft:light_gray_concrete replace
setblock ~96 ~43 ~277 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~277 minecraft:light_gray_concrete replace
setblock ~145 ~43 ~280 minecraft:light_gray_concrete replace
setblock ~120 ~43 ~281 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~281 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~283 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~285 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~285 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~287 minecraft:light_gray_concrete replace
setblock ~148 ~43 ~292 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~296 minecraft:light_gray_concrete replace
setblock ~147 ~43 ~297 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~297 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~299 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~299 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~301 minecraft:light_gray_concrete replace
setblock ~169 ~43 ~308 minecraft:light_gray_concrete replace
setblock ~168 ~43 ~313 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~313 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~315 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~316 minecraft:light_gray_concrete replace
setblock ~184 ~43 ~320 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~321 minecraft:light_gray_concrete replace
setblock ~183 ~43 ~325 minecraft:light_gray_concrete replace
setblock ~204 ~43 ~329 minecraft:light_gray_concrete replace
setblock ~249 ~43 ~333 minecraft:light_gray_concrete replace
setblock ~208 ~43 ~336 minecraft:light_gray_concrete replace
setblock ~207 ~43 ~341 minecraft:light_gray_concrete replace
setblock ~231 ~43 ~345 minecraft:light_gray_concrete replace
setblock ~267 ~43 ~349 minecraft:light_gray_concrete replace
setblock ~235 ~43 ~352 minecraft:light_gray_concrete replace
setblock ~234 ~43 ~357 minecraft:light_gray_concrete replace
setblock ~291 ~43 ~361 minecraft:light_gray_concrete replace
setblock ~310 ~43 ~364 minecraft:light_gray_concrete replace
setblock ~306 ~43 ~365 minecraft:light_gray_concrete replace
setblock ~309 ~43 ~369 minecraft:light_gray_concrete replace
setblock ~282 ~43 ~373 minecraft:light_gray_concrete replace
setblock ~297 ~43 ~377 minecraft:light_gray_concrete replace
setblock ~256 ~43 ~380 minecraft:light_gray_concrete replace
setblock ~255 ~43 ~385 minecraft:light_gray_concrete replace
setblock ~333 ~43 ~389 minecraft:light_gray_concrete replace
setblock ~354 ~43 ~393 minecraft:light_gray_concrete replace
setblock ~346 ~43 ~396 minecraft:light_gray_concrete replace
setblock ~321 ~43 ~397 minecraft:light_gray_concrete replace
setblock ~345 ~43 ~401 minecraft:light_gray_concrete replace
setblock ~315 ~43 ~405 minecraft:light_gray_concrete replace
setblock ~90 ~43 ~413 minecraft:light_gray_concrete replace
setblock ~117 ~43 ~417 minecraft:light_gray_concrete replace
setblock ~141 ~43 ~421 minecraft:light_gray_concrete replace
setblock ~174 ~43 ~425 minecraft:light_gray_concrete replace
setblock ~195 ~43 ~429 minecraft:light_gray_concrete replace
setblock ~219 ~43 ~433 minecraft:light_gray_concrete replace
setblock ~252 ~43 ~437 minecraft:light_gray_concrete replace
setblock ~276 ~43 ~441 minecraft:light_gray_concrete replace
setblock ~312 ~43 ~445 minecraft:light_gray_concrete replace
setblock ~87 ~43 ~449 minecraft:light_gray_concrete replace
setblock ~114 ~43 ~453 minecraft:light_gray_concrete replace
setblock ~138 ~43 ~457 minecraft:light_gray_concrete replace
setblock ~171 ~43 ~461 minecraft:light_gray_concrete replace
setblock ~192 ~43 ~465 minecraft:light_gray_concrete replace
setblock ~216 ~43 ~469 minecraft:light_gray_concrete replace
setblock ~246 ~43 ~473 minecraft:light_gray_concrete replace
setblock ~273 ~43 ~477 minecraft:light_gray_concrete replace
setblock ~336 ~43 ~481 minecraft:light_gray_concrete replace
setblock ~360 ~43 ~485 minecraft:light_gray_concrete replace
setblock ~84 ~43 ~489 minecraft:light_gray_concrete replace
setblock ~111 ~43 ~493 minecraft:light_gray_concrete replace
setblock ~135 ~43 ~497 minecraft:light_gray_concrete replace
setblock ~162 ~43 ~501 minecraft:light_gray_concrete replace
setblock ~189 ~43 ~505 minecraft:light_gray_concrete replace
setblock ~213 ~43 ~509 minecraft:light_gray_concrete replace
setblock ~243 ~43 ~513 minecraft:light_gray_concrete replace
setblock ~270 ~43 ~517 minecraft:light_gray_concrete replace
setblock ~330 ~43 ~521 minecraft:light_gray_concrete replace
setblock ~357 ~43 ~525 minecraft:light_gray_concrete replace
setblock ~81 ~43 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~43 ~533 minecraft:light_gray_concrete replace
setblock ~132 ~43 ~537 minecraft:light_gray_concrete replace
setblock ~156 ~43 ~541 minecraft:light_gray_concrete replace
setblock ~186 ~43 ~545 minecraft:light_gray_concrete replace
setblock ~210 ~43 ~549 minecraft:light_gray_concrete replace
setblock ~240 ~43 ~553 minecraft:light_gray_concrete replace
setblock ~261 ~43 ~557 minecraft:light_gray_concrete replace
setblock ~327 ~43 ~561 minecraft:light_gray_concrete replace
setblock ~351 ~43 ~565 minecraft:light_gray_concrete replace
setblock ~78 ~43 ~569 minecraft:light_gray_concrete replace
setblock ~105 ~43 ~573 minecraft:light_gray_concrete replace
setblock ~129 ~43 ~577 minecraft:light_gray_concrete replace
setblock ~153 ~43 ~581 minecraft:light_gray_concrete replace
setblock ~180 ~43 ~585 minecraft:light_gray_concrete replace
setblock ~201 ~43 ~589 minecraft:light_gray_concrete replace
setblock ~237 ~43 ~593 minecraft:light_gray_concrete replace
setblock ~258 ~43 ~597 minecraft:light_gray_concrete replace
setblock ~324 ~43 ~601 minecraft:light_gray_concrete replace
setblock ~348 ~43 ~605 minecraft:light_gray_concrete replace
setblock ~102 ~43 ~609 minecraft:light_gray_concrete replace
setblock ~126 ~43 ~613 minecraft:light_gray_concrete replace
setblock ~150 ~43 ~617 minecraft:light_gray_concrete replace
setblock ~177 ~43 ~621 minecraft:light_gray_concrete replace
setblock ~198 ~43 ~625 minecraft:light_gray_concrete replace
setblock ~222 ~43 ~629 minecraft:light_gray_concrete replace
setblock ~264 ~43 ~633 minecraft:light_gray_concrete replace
setblock ~279 ~43 ~637 minecraft:light_gray_concrete replace
setblock ~339 ~43 ~641 minecraft:light_gray_concrete replace
setblock ~159 ~43 ~645 minecraft:light_gray_concrete replace
setblock ~366 ~43 ~649 minecraft:light_gray_concrete replace
setblock ~99 ~43 ~653 minecraft:light_gray_concrete replace
setblock ~342 ~43 ~657 minecraft:light_gray_concrete replace
setblock ~363 ~43 ~661 minecraft:light_gray_concrete replace
fill ~300 ~44 ~38 ~302 ~44 ~38 minecraft:light_gray_concrete replace
fill ~301 ~44 ~39 ~301 ~44 ~40 minecraft:light_gray_concrete replace
fill ~285 ~44 ~42 ~287 ~44 ~42 minecraft:light_gray_concrete replace
fill ~286 ~44 ~43 ~286 ~44 ~44 minecraft:light_gray_concrete replace
fill ~228 ~44 ~46 ~236 ~44 ~46 minecraft:light_gray_concrete replace
fill ~235 ~44 ~47 ~235 ~44 ~48 minecraft:light_gray_concrete replace
fill ~303 ~44 ~50 ~305 ~44 ~50 minecraft:light_gray_concrete replace
fill ~304 ~44 ~51 ~304 ~44 ~52 minecraft:light_gray_concrete replace
fill ~288 ~44 ~54 ~290 ~44 ~54 minecraft:light_gray_concrete replace
fill ~289 ~44 ~55 ~289 ~44 ~56 minecraft:light_gray_concrete replace
fill ~291 ~44 ~62 ~294 ~44 ~62 minecraft:light_gray_concrete replace
fill ~292 ~44 ~63 ~292 ~44 ~64 minecraft:light_gray_concrete replace
fill ~318 ~44 ~78 ~320 ~44 ~78 minecraft:light_gray_concrete replace
fill ~319 ~44 ~79 ~319 ~44 ~80 minecraft:light_gray_concrete replace
fill ~93 ~44 ~250 ~98 ~44 ~250 minecraft:light_gray_concrete replace
fill ~94 ~44 ~251 ~94 ~44 ~252 minecraft:light_gray_concrete replace
fill ~97 ~44 ~251 ~97 ~44 ~252 minecraft:light_gray_concrete replace
fill ~120 ~44 ~270 ~125 ~44 ~270 minecraft:light_gray_concrete replace
fill ~121 ~44 ~271 ~121 ~44 ~272 minecraft:light_gray_concrete replace
fill ~124 ~44 ~271 ~124 ~44 ~272 minecraft:light_gray_concrete replace
fill ~93 ~44 ~278 ~98 ~44 ~278 minecraft:light_gray_concrete replace
fill ~94 ~44 ~279 ~94 ~44 ~280 minecraft:light_gray_concrete replace
fill ~97 ~44 ~279 ~97 ~44 ~280 minecraft:light_gray_concrete replace
fill ~120 ~44 ~282 ~125 ~44 ~282 minecraft:light_gray_concrete replace
fill ~121 ~44 ~283 ~121 ~44 ~284 minecraft:light_gray_concrete replace
fill ~124 ~44 ~283 ~124 ~44 ~284 minecraft:light_gray_concrete replace
fill ~144 ~44 ~286 ~149 ~44 ~286 minecraft:light_gray_concrete replace
fill ~145 ~44 ~287 ~145 ~44 ~288 minecraft:light_gray_concrete replace
fill ~148 ~44 ~287 ~148 ~44 ~288 minecraft:light_gray_concrete replace
fill ~144 ~44 ~298 ~149 ~44 ~298 minecraft:light_gray_concrete replace
fill ~145 ~44 ~299 ~145 ~44 ~300 minecraft:light_gray_concrete replace
fill ~148 ~44 ~299 ~148 ~44 ~300 minecraft:light_gray_concrete replace
fill ~165 ~44 ~302 ~170 ~44 ~302 minecraft:light_gray_concrete replace
fill ~166 ~44 ~303 ~166 ~44 ~304 minecraft:light_gray_concrete replace
fill ~169 ~44 ~303 ~169 ~44 ~304 minecraft:light_gray_concrete replace
fill ~165 ~44 ~314 ~170 ~44 ~314 minecraft:light_gray_concrete replace
fill ~166 ~44 ~315 ~166 ~44 ~316 minecraft:light_gray_concrete replace
fill ~169 ~44 ~315 ~169 ~44 ~316 minecraft:light_gray_concrete replace
fill ~183 ~44 ~322 ~299 ~44 ~322 minecraft:light_gray_concrete replace
fill ~184 ~44 ~323 ~184 ~44 ~324 minecraft:light_gray_concrete replace
fill ~187 ~44 ~323 ~187 ~44 ~324 minecraft:light_gray_concrete replace
fill ~208 ~44 ~323 ~208 ~44 ~324 minecraft:light_gray_concrete replace
fill ~232 ~44 ~323 ~232 ~44 ~324 minecraft:light_gray_concrete replace
fill ~283 ~44 ~323 ~283 ~44 ~324 minecraft:light_gray_concrete replace
fill ~298 ~44 ~323 ~298 ~44 ~324 minecraft:light_gray_concrete replace
fill ~183 ~44 ~326 ~188 ~44 ~326 minecraft:light_gray_concrete replace
fill ~184 ~44 ~327 ~184 ~44 ~328 minecraft:light_gray_concrete replace
fill ~187 ~44 ~327 ~187 ~44 ~328 minecraft:light_gray_concrete replace
fill ~204 ~44 ~330 ~212 ~44 ~330 minecraft:light_gray_concrete replace
fill ~211 ~44 ~331 ~211 ~44 ~332 minecraft:light_gray_concrete replace
fill ~207 ~44 ~334 ~299 ~44 ~334 minecraft:light_gray_concrete replace
fill ~208 ~44 ~335 ~208 ~44 ~336 minecraft:light_gray_concrete replace
fill ~232 ~44 ~335 ~232 ~44 ~336 minecraft:light_gray_concrete replace
fill ~283 ~44 ~335 ~283 ~44 ~336 minecraft:light_gray_concrete replace
fill ~298 ~44 ~335 ~298 ~44 ~336 minecraft:light_gray_concrete replace
fill ~207 ~44 ~342 ~215 ~44 ~342 minecraft:light_gray_concrete replace
fill ~214 ~44 ~343 ~214 ~44 ~344 minecraft:light_gray_concrete replace
fill ~231 ~44 ~346 ~239 ~44 ~346 minecraft:light_gray_concrete replace
fill ~238 ~44 ~347 ~238 ~44 ~348 minecraft:light_gray_concrete replace
fill ~231 ~44 ~350 ~299 ~44 ~350 minecraft:light_gray_concrete replace
fill ~232 ~44 ~351 ~232 ~44 ~352 minecraft:light_gray_concrete replace
fill ~283 ~44 ~351 ~283 ~44 ~352 minecraft:light_gray_concrete replace
fill ~298 ~44 ~351 ~298 ~44 ~352 minecraft:light_gray_concrete replace
fill ~234 ~44 ~358 ~242 ~44 ~358 minecraft:light_gray_concrete replace
fill ~241 ~44 ~359 ~241 ~44 ~360 minecraft:light_gray_concrete replace
fill ~282 ~44 ~362 ~299 ~44 ~362 minecraft:light_gray_concrete replace
fill ~283 ~44 ~363 ~283 ~44 ~364 minecraft:light_gray_concrete replace
fill ~298 ~44 ~363 ~298 ~44 ~364 minecraft:light_gray_concrete replace
fill ~306 ~44 ~366 ~308 ~44 ~366 minecraft:light_gray_concrete replace
fill ~307 ~44 ~367 ~307 ~44 ~368 minecraft:light_gray_concrete replace
fill ~309 ~44 ~370 ~311 ~44 ~370 minecraft:light_gray_concrete replace
fill ~310 ~44 ~371 ~310 ~44 ~372 minecraft:light_gray_concrete replace
fill ~282 ~44 ~374 ~284 ~44 ~374 minecraft:light_gray_concrete replace
fill ~283 ~44 ~375 ~283 ~44 ~376 minecraft:light_gray_concrete replace
fill ~294 ~44 ~378 ~297 ~44 ~378 minecraft:light_gray_concrete replace
fill ~295 ~44 ~379 ~295 ~44 ~380 minecraft:light_gray_concrete replace
fill ~255 ~44 ~386 ~260 ~44 ~386 minecraft:light_gray_concrete replace
fill ~259 ~44 ~387 ~259 ~44 ~388 minecraft:light_gray_concrete replace
fill ~333 ~44 ~390 ~335 ~44 ~390 minecraft:light_gray_concrete replace
fill ~334 ~44 ~391 ~334 ~44 ~392 minecraft:light_gray_concrete replace
fill ~354 ~44 ~394 ~356 ~44 ~394 minecraft:light_gray_concrete replace
fill ~355 ~44 ~395 ~355 ~44 ~396 minecraft:light_gray_concrete replace
fill ~321 ~44 ~398 ~323 ~44 ~398 minecraft:light_gray_concrete replace
fill ~322 ~44 ~399 ~322 ~44 ~400 minecraft:light_gray_concrete replace
fill ~345 ~44 ~402 ~347 ~44 ~402 minecraft:light_gray_concrete replace
fill ~346 ~44 ~403 ~346 ~44 ~404 minecraft:light_gray_concrete replace
fill ~315 ~44 ~406 ~317 ~44 ~406 minecraft:light_gray_concrete replace
fill ~316 ~44 ~407 ~316 ~44 ~408 minecraft:light_gray_concrete replace
fill ~90 ~44 ~414 ~92 ~44 ~414 minecraft:light_gray_concrete replace
fill ~91 ~44 ~415 ~91 ~44 ~416 minecraft:light_gray_concrete replace
fill ~117 ~44 ~418 ~119 ~44 ~418 minecraft:light_gray_concrete replace
fill ~118 ~44 ~419 ~118 ~44 ~420 minecraft:light_gray_concrete replace
fill ~141 ~44 ~422 ~143 ~44 ~422 minecraft:light_gray_concrete replace
fill ~142 ~44 ~423 ~142 ~44 ~424 minecraft:light_gray_concrete replace
fill ~174 ~44 ~426 ~176 ~44 ~426 minecraft:light_gray_concrete replace
fill ~175 ~44 ~427 ~175 ~44 ~428 minecraft:light_gray_concrete replace
fill ~195 ~44 ~430 ~200 ~44 ~430 minecraft:light_gray_concrete replace
fill ~199 ~44 ~431 ~199 ~44 ~432 minecraft:light_gray_concrete replace
fill ~219 ~44 ~434 ~227 ~44 ~434 minecraft:light_gray_concrete replace
fill ~226 ~44 ~435 ~226 ~44 ~436 minecraft:light_gray_concrete replace
fill ~252 ~44 ~438 ~257 ~44 ~438 minecraft:light_gray_concrete replace
fill ~256 ~44 ~439 ~256 ~44 ~440 minecraft:light_gray_concrete replace
fill ~276 ~44 ~442 ~278 ~44 ~442 minecraft:light_gray_concrete replace
fill ~277 ~44 ~443 ~277 ~44 ~444 minecraft:light_gray_concrete replace
fill ~312 ~44 ~446 ~314 ~44 ~446 minecraft:light_gray_concrete replace
fill ~313 ~44 ~447 ~313 ~44 ~448 minecraft:light_gray_concrete replace
fill ~87 ~44 ~450 ~89 ~44 ~450 minecraft:light_gray_concrete replace
fill ~88 ~44 ~451 ~88 ~44 ~452 minecraft:light_gray_concrete replace
fill ~114 ~44 ~454 ~116 ~44 ~454 minecraft:light_gray_concrete replace
fill ~115 ~44 ~455 ~115 ~44 ~456 minecraft:light_gray_concrete replace
fill ~138 ~44 ~458 ~140 ~44 ~458 minecraft:light_gray_concrete replace
fill ~139 ~44 ~459 ~139 ~44 ~460 minecraft:light_gray_concrete replace
fill ~171 ~44 ~462 ~173 ~44 ~462 minecraft:light_gray_concrete replace
fill ~172 ~44 ~463 ~172 ~44 ~464 minecraft:light_gray_concrete replace
fill ~192 ~44 ~466 ~197 ~44 ~466 minecraft:light_gray_concrete replace
fill ~196 ~44 ~467 ~196 ~44 ~468 minecraft:light_gray_concrete replace
fill ~216 ~44 ~470 ~224 ~44 ~470 minecraft:light_gray_concrete replace
fill ~223 ~44 ~471 ~223 ~44 ~472 minecraft:light_gray_concrete replace
fill ~246 ~44 ~474 ~254 ~44 ~474 minecraft:light_gray_concrete replace
fill ~253 ~44 ~475 ~253 ~44 ~476 minecraft:light_gray_concrete replace
fill ~273 ~44 ~478 ~275 ~44 ~478 minecraft:light_gray_concrete replace
fill ~274 ~44 ~479 ~274 ~44 ~480 minecraft:light_gray_concrete replace
fill ~336 ~44 ~482 ~338 ~44 ~482 minecraft:light_gray_concrete replace
fill ~337 ~44 ~483 ~337 ~44 ~484 minecraft:light_gray_concrete replace
fill ~360 ~44 ~486 ~362 ~44 ~486 minecraft:light_gray_concrete replace
fill ~361 ~44 ~487 ~361 ~44 ~488 minecraft:light_gray_concrete replace
fill ~84 ~44 ~490 ~86 ~44 ~490 minecraft:light_gray_concrete replace
fill ~85 ~44 ~491 ~85 ~44 ~492 minecraft:light_gray_concrete replace
fill ~111 ~44 ~494 ~113 ~44 ~494 minecraft:light_gray_concrete replace
fill ~112 ~44 ~495 ~112 ~44 ~496 minecraft:light_gray_concrete replace
fill ~135 ~44 ~498 ~137 ~44 ~498 minecraft:light_gray_concrete replace
fill ~136 ~44 ~499 ~136 ~44 ~500 minecraft:light_gray_concrete replace
fill ~162 ~44 ~502 ~164 ~44 ~502 minecraft:light_gray_concrete replace
fill ~163 ~44 ~503 ~163 ~44 ~504 minecraft:light_gray_concrete replace
fill ~189 ~44 ~506 ~194 ~44 ~506 minecraft:light_gray_concrete replace
fill ~193 ~44 ~507 ~193 ~44 ~508 minecraft:light_gray_concrete replace
fill ~213 ~44 ~510 ~221 ~44 ~510 minecraft:light_gray_concrete replace
fill ~220 ~44 ~511 ~220 ~44 ~512 minecraft:light_gray_concrete replace
fill ~243 ~44 ~514 ~251 ~44 ~514 minecraft:light_gray_concrete replace
fill ~250 ~44 ~515 ~250 ~44 ~516 minecraft:light_gray_concrete replace
fill ~270 ~44 ~518 ~272 ~44 ~518 minecraft:light_gray_concrete replace
fill ~271 ~44 ~519 ~271 ~44 ~520 minecraft:light_gray_concrete replace
fill ~330 ~44 ~522 ~332 ~44 ~522 minecraft:light_gray_concrete replace
fill ~331 ~44 ~523 ~331 ~44 ~524 minecraft:light_gray_concrete replace
fill ~357 ~44 ~526 ~359 ~44 ~526 minecraft:light_gray_concrete replace
fill ~358 ~44 ~527 ~358 ~44 ~528 minecraft:light_gray_concrete replace
fill ~81 ~44 ~530 ~83 ~44 ~530 minecraft:light_gray_concrete replace
fill ~82 ~44 ~531 ~82 ~44 ~532 minecraft:light_gray_concrete replace
fill ~108 ~44 ~534 ~110 ~44 ~534 minecraft:light_gray_concrete replace
fill ~109 ~44 ~535 ~109 ~44 ~536 minecraft:light_gray_concrete replace
fill ~132 ~44 ~538 ~134 ~44 ~538 minecraft:light_gray_concrete replace
fill ~133 ~44 ~539 ~133 ~44 ~540 minecraft:light_gray_concrete replace
fill ~156 ~44 ~542 ~158 ~44 ~542 minecraft:light_gray_concrete replace
fill ~157 ~44 ~543 ~157 ~44 ~544 minecraft:light_gray_concrete replace
fill ~186 ~44 ~546 ~191 ~44 ~546 minecraft:light_gray_concrete replace
fill ~190 ~44 ~547 ~190 ~44 ~548 minecraft:light_gray_concrete replace
fill ~210 ~44 ~550 ~218 ~44 ~550 minecraft:light_gray_concrete replace
fill ~217 ~44 ~551 ~217 ~44 ~552 minecraft:light_gray_concrete replace
fill ~240 ~44 ~554 ~248 ~44 ~554 minecraft:light_gray_concrete replace
fill ~247 ~44 ~555 ~247 ~44 ~556 minecraft:light_gray_concrete replace
fill ~261 ~44 ~558 ~266 ~44 ~558 minecraft:light_gray_concrete replace
fill ~265 ~44 ~559 ~265 ~44 ~560 minecraft:light_gray_concrete replace
fill ~327 ~44 ~562 ~329 ~44 ~562 minecraft:light_gray_concrete replace
fill ~328 ~44 ~563 ~328 ~44 ~564 minecraft:light_gray_concrete replace
fill ~351 ~44 ~566 ~353 ~44 ~566 minecraft:light_gray_concrete replace
fill ~352 ~44 ~567 ~352 ~44 ~568 minecraft:light_gray_concrete replace
fill ~78 ~44 ~570 ~80 ~44 ~570 minecraft:light_gray_concrete replace
fill ~79 ~44 ~571 ~79 ~44 ~572 minecraft:light_gray_concrete replace
fill ~105 ~44 ~574 ~107 ~44 ~574 minecraft:light_gray_concrete replace
fill ~106 ~44 ~575 ~106 ~44 ~576 minecraft:light_gray_concrete replace
fill ~129 ~44 ~578 ~131 ~44 ~578 minecraft:light_gray_concrete replace
fill ~130 ~44 ~579 ~130 ~44 ~580 minecraft:light_gray_concrete replace
fill ~153 ~44 ~582 ~155 ~44 ~582 minecraft:light_gray_concrete replace
fill ~154 ~44 ~583 ~154 ~44 ~584 minecraft:light_gray_concrete replace
fill ~180 ~44 ~586 ~182 ~44 ~586 minecraft:light_gray_concrete replace
fill ~181 ~44 ~587 ~181 ~44 ~588 minecraft:light_gray_concrete replace
fill ~201 ~44 ~590 ~206 ~44 ~590 minecraft:light_gray_concrete replace
fill ~205 ~44 ~591 ~205 ~44 ~592 minecraft:light_gray_concrete replace
fill ~237 ~44 ~594 ~245 ~44 ~594 minecraft:light_gray_concrete replace
fill ~244 ~44 ~595 ~244 ~44 ~596 minecraft:light_gray_concrete replace
fill ~258 ~44 ~598 ~263 ~44 ~598 minecraft:light_gray_concrete replace
fill ~262 ~44 ~599 ~262 ~44 ~600 minecraft:light_gray_concrete replace
fill ~324 ~44 ~602 ~326 ~44 ~602 minecraft:light_gray_concrete replace
fill ~325 ~44 ~603 ~325 ~44 ~604 minecraft:light_gray_concrete replace
fill ~348 ~44 ~606 ~350 ~44 ~606 minecraft:light_gray_concrete replace
fill ~349 ~44 ~607 ~349 ~44 ~608 minecraft:light_gray_concrete replace
fill ~102 ~44 ~610 ~104 ~44 ~610 minecraft:light_gray_concrete replace
fill ~103 ~44 ~611 ~103 ~44 ~612 minecraft:light_gray_concrete replace
fill ~126 ~44 ~614 ~128 ~44 ~614 minecraft:light_gray_concrete replace
fill ~127 ~44 ~615 ~127 ~44 ~616 minecraft:light_gray_concrete replace
fill ~150 ~44 ~618 ~152 ~44 ~618 minecraft:light_gray_concrete replace
fill ~151 ~44 ~619 ~151 ~44 ~620 minecraft:light_gray_concrete replace
fill ~177 ~44 ~622 ~179 ~44 ~622 minecraft:light_gray_concrete replace
fill ~178 ~44 ~623 ~178 ~44 ~624 minecraft:light_gray_concrete replace
fill ~198 ~44 ~626 ~203 ~44 ~626 minecraft:light_gray_concrete replace
fill ~202 ~44 ~627 ~202 ~44 ~628 minecraft:light_gray_concrete replace
fill ~222 ~44 ~630 ~230 ~44 ~630 minecraft:light_gray_concrete replace
fill ~229 ~44 ~631 ~229 ~44 ~632 minecraft:light_gray_concrete replace
fill ~264 ~44 ~634 ~269 ~44 ~634 minecraft:light_gray_concrete replace
fill ~268 ~44 ~635 ~268 ~44 ~636 minecraft:light_gray_concrete replace
fill ~279 ~44 ~638 ~281 ~44 ~638 minecraft:light_gray_concrete replace
fill ~280 ~44 ~639 ~280 ~44 ~640 minecraft:light_gray_concrete replace
fill ~339 ~44 ~642 ~341 ~44 ~642 minecraft:light_gray_concrete replace
fill ~340 ~44 ~643 ~340 ~44 ~644 minecraft:light_gray_concrete replace
fill ~159 ~44 ~646 ~161 ~44 ~646 minecraft:light_gray_concrete replace
fill ~160 ~44 ~647 ~160 ~44 ~648 minecraft:light_gray_concrete replace
fill ~366 ~44 ~650 ~368 ~44 ~650 minecraft:light_gray_concrete replace
fill ~367 ~44 ~651 ~367 ~44 ~652 minecraft:light_gray_concrete replace
fill ~99 ~44 ~654 ~101 ~44 ~654 minecraft:light_gray_concrete replace
fill ~100 ~44 ~655 ~100 ~44 ~656 minecraft:light_gray_concrete replace
fill ~342 ~44 ~658 ~344 ~44 ~658 minecraft:light_gray_concrete replace
fill ~343 ~44 ~659 ~343 ~44 ~660 minecraft:light_gray_concrete replace
fill ~363 ~44 ~662 ~365 ~44 ~662 minecraft:light_gray_concrete replace
fill ~364 ~44 ~663 ~364 ~44 ~664 minecraft:light_gray_concrete replace
setblock ~301 ~45 ~40 minecraft:light_gray_concrete replace
setblock ~286 ~45 ~44 minecraft:light_gray_concrete replace
setblock ~235 ~45 ~48 minecraft:light_gray_concrete replace
setblock ~304 ~45 ~52 minecraft:light_gray_concrete replace
setblock ~289 ~45 ~56 minecraft:light_gray_concrete replace
setblock ~292 ~45 ~64 minecraft:light_gray_concrete replace
setblock ~319 ~45 ~80 minecraft:light_gray_concrete replace
setblock ~94 ~45 ~252 minecraft:light_gray_concrete replace
setblock ~97 ~45 ~252 minecraft:light_gray_concrete replace
setblock ~121 ~45 ~272 minecraft:light_gray_concrete replace
setblock ~124 ~45 ~272 minecraft:light_gray_concrete replace
setblock ~94 ~45 ~280 minecraft:light_gray_concrete replace
setblock ~97 ~45 ~280 minecraft:light_gray_concrete replace
setblock ~121 ~45 ~284 minecraft:light_gray_concrete replace
setblock ~124 ~45 ~284 minecraft:light_gray_concrete replace
setblock ~145 ~45 ~288 minecraft:light_gray_concrete replace
setblock ~148 ~45 ~288 minecraft:light_gray_concrete replace
setblock ~145 ~45 ~300 minecraft:light_gray_concrete replace
setblock ~148 ~45 ~300 minecraft:light_gray_concrete replace
setblock ~166 ~45 ~304 minecraft:light_gray_concrete replace
setblock ~169 ~45 ~304 minecraft:light_gray_concrete replace
setblock ~166 ~45 ~316 minecraft:light_gray_concrete replace
setblock ~169 ~45 ~316 minecraft:light_gray_concrete replace
setblock ~201 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~203 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~217 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~219 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~245 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~247 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~261 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~263 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~277 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~279 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~293 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~295 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~184 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~187 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~208 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~232 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~184 ~45 ~328 minecraft:light_gray_concrete replace
setblock ~187 ~45 ~328 minecraft:light_gray_concrete replace
setblock ~211 ~45 ~332 minecraft:light_gray_concrete replace
setblock ~209 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~211 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~225 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~227 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~241 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~243 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~256 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~258 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~273 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~275 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~290 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~292 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~208 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~232 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~214 ~45 ~344 minecraft:light_gray_concrete replace
setblock ~238 ~45 ~348 minecraft:light_gray_concrete replace
setblock ~241 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~243 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~258 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~260 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~274 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~276 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~291 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~293 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~232 ~45 ~352 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~352 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~352 minecraft:light_gray_concrete replace
setblock ~241 ~45 ~360 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~364 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~364 minecraft:light_gray_concrete replace
setblock ~307 ~45 ~368 minecraft:light_gray_concrete replace
setblock ~310 ~45 ~372 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~376 minecraft:light_gray_concrete replace
setblock ~295 ~45 ~380 minecraft:light_gray_concrete replace
setblock ~259 ~45 ~388 minecraft:light_gray_concrete replace
setblock ~334 ~45 ~392 minecraft:light_gray_concrete replace
setblock ~355 ~45 ~396 minecraft:light_gray_concrete replace
setblock ~322 ~45 ~400 minecraft:light_gray_concrete replace
setblock ~346 ~45 ~404 minecraft:light_gray_concrete replace
setblock ~316 ~45 ~408 minecraft:light_gray_concrete replace
setblock ~91 ~45 ~416 minecraft:light_gray_concrete replace
setblock ~118 ~45 ~420 minecraft:light_gray_concrete replace
setblock ~142 ~45 ~424 minecraft:light_gray_concrete replace
setblock ~175 ~45 ~428 minecraft:light_gray_concrete replace
setblock ~199 ~45 ~432 minecraft:light_gray_concrete replace
setblock ~226 ~45 ~436 minecraft:light_gray_concrete replace
setblock ~256 ~45 ~440 minecraft:light_gray_concrete replace
setblock ~277 ~45 ~444 minecraft:light_gray_concrete replace
setblock ~313 ~45 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~45 ~452 minecraft:light_gray_concrete replace
setblock ~115 ~45 ~456 minecraft:light_gray_concrete replace
setblock ~139 ~45 ~460 minecraft:light_gray_concrete replace
setblock ~172 ~45 ~464 minecraft:light_gray_concrete replace
setblock ~196 ~45 ~468 minecraft:light_gray_concrete replace
setblock ~223 ~45 ~472 minecraft:light_gray_concrete replace
setblock ~253 ~45 ~476 minecraft:light_gray_concrete replace
setblock ~274 ~45 ~480 minecraft:light_gray_concrete replace
setblock ~337 ~45 ~484 minecraft:light_gray_concrete replace
setblock ~361 ~45 ~488 minecraft:light_gray_concrete replace
setblock ~85 ~45 ~492 minecraft:light_gray_concrete replace
setblock ~112 ~45 ~496 minecraft:light_gray_concrete replace
setblock ~136 ~45 ~500 minecraft:light_gray_concrete replace
setblock ~163 ~45 ~504 minecraft:light_gray_concrete replace
setblock ~193 ~45 ~508 minecraft:light_gray_concrete replace
setblock ~220 ~45 ~512 minecraft:light_gray_concrete replace
setblock ~250 ~45 ~516 minecraft:light_gray_concrete replace
setblock ~271 ~45 ~520 minecraft:light_gray_concrete replace
setblock ~331 ~45 ~524 minecraft:light_gray_concrete replace
setblock ~358 ~45 ~528 minecraft:light_gray_concrete replace
setblock ~82 ~45 ~532 minecraft:light_gray_concrete replace
setblock ~109 ~45 ~536 minecraft:light_gray_concrete replace
setblock ~133 ~45 ~540 minecraft:light_gray_concrete replace
setblock ~157 ~45 ~544 minecraft:light_gray_concrete replace
setblock ~190 ~45 ~548 minecraft:light_gray_concrete replace
setblock ~217 ~45 ~552 minecraft:light_gray_concrete replace
setblock ~247 ~45 ~556 minecraft:light_gray_concrete replace
setblock ~265 ~45 ~560 minecraft:light_gray_concrete replace
setblock ~328 ~45 ~564 minecraft:light_gray_concrete replace
setblock ~352 ~45 ~568 minecraft:light_gray_concrete replace
setblock ~79 ~45 ~572 minecraft:light_gray_concrete replace
setblock ~106 ~45 ~576 minecraft:light_gray_concrete replace
setblock ~130 ~45 ~580 minecraft:light_gray_concrete replace
setblock ~154 ~45 ~584 minecraft:light_gray_concrete replace
setblock ~181 ~45 ~588 minecraft:light_gray_concrete replace
setblock ~205 ~45 ~592 minecraft:light_gray_concrete replace
setblock ~244 ~45 ~596 minecraft:light_gray_concrete replace
setblock ~262 ~45 ~600 minecraft:light_gray_concrete replace
setblock ~325 ~45 ~604 minecraft:light_gray_concrete replace
setblock ~349 ~45 ~608 minecraft:light_gray_concrete replace
setblock ~103 ~45 ~612 minecraft:light_gray_concrete replace
setblock ~127 ~45 ~616 minecraft:light_gray_concrete replace
setblock ~151 ~45 ~620 minecraft:light_gray_concrete replace
setblock ~178 ~45 ~624 minecraft:light_gray_concrete replace
setblock ~202 ~45 ~628 minecraft:light_gray_concrete replace
setblock ~229 ~45 ~632 minecraft:light_gray_concrete replace
setblock ~268 ~45 ~636 minecraft:light_gray_concrete replace
setblock ~280 ~45 ~640 minecraft:light_gray_concrete replace
setblock ~340 ~45 ~644 minecraft:light_gray_concrete replace
setblock ~160 ~45 ~648 minecraft:light_gray_concrete replace
setblock ~367 ~45 ~652 minecraft:light_gray_concrete replace
setblock ~100 ~45 ~656 minecraft:light_gray_concrete replace
setblock ~343 ~45 ~660 minecraft:light_gray_concrete replace
setblock ~364 ~45 ~664 minecraft:light_gray_concrete replace
fill ~300 ~46 ~36 ~300 ~46 ~40 minecraft:light_gray_concrete replace
fill ~285 ~46 ~40 ~285 ~46 ~44 minecraft:light_gray_concrete replace
fill ~234 ~46 ~44 ~234 ~46 ~48 minecraft:light_gray_concrete replace
fill ~303 ~46 ~48 ~303 ~46 ~52 minecraft:light_gray_concrete replace
fill ~288 ~46 ~52 ~288 ~46 ~56 minecraft:light_gray_concrete replace
fill ~291 ~46 ~60 ~291 ~46 ~64 minecraft:light_gray_concrete replace
fill ~318 ~46 ~76 ~318 ~46 ~80 minecraft:light_gray_concrete replace
fill ~96 ~46 ~244 ~96 ~46 ~280 minecraft:light_gray_concrete replace
fill ~93 ~46 ~248 ~93 ~46 ~280 minecraft:light_gray_concrete replace
fill ~123 ~46 ~264 ~123 ~46 ~284 minecraft:light_gray_concrete replace
fill ~120 ~46 ~268 ~120 ~46 ~284 minecraft:light_gray_concrete replace
fill ~147 ~46 ~280 ~147 ~46 ~300 minecraft:light_gray_concrete replace
fill ~144 ~46 ~284 ~144 ~46 ~300 minecraft:light_gray_concrete replace
fill ~168 ~46 ~292 ~168 ~46 ~316 minecraft:light_gray_concrete replace
fill ~165 ~46 ~296 ~165 ~46 ~316 minecraft:light_gray_concrete replace
fill ~297 ~46 ~300 ~297 ~46 ~364 minecraft:light_gray_concrete replace
fill ~282 ~46 ~304 ~282 ~46 ~376 minecraft:light_gray_concrete replace
fill ~231 ~46 ~308 ~231 ~46 ~352 minecraft:light_gray_concrete replace
fill ~207 ~46 ~312 ~207 ~46 ~336 minecraft:light_gray_concrete replace
fill ~186 ~46 ~316 ~186 ~46 ~328 minecraft:light_gray_concrete replace
fill ~183 ~46 ~320 ~183 ~46 ~328 minecraft:light_gray_concrete replace
fill ~210 ~46 ~328 ~210 ~46 ~332 minecraft:light_gray_concrete replace
fill ~213 ~46 ~340 ~213 ~46 ~344 minecraft:light_gray_concrete replace
fill ~237 ~46 ~344 ~237 ~46 ~348 minecraft:light_gray_concrete replace
fill ~240 ~46 ~356 ~240 ~46 ~360 minecraft:light_gray_concrete replace
fill ~306 ~46 ~364 ~306 ~46 ~368 minecraft:light_gray_concrete replace
fill ~309 ~46 ~368 ~309 ~46 ~372 minecraft:light_gray_concrete replace
fill ~294 ~46 ~376 ~294 ~46 ~380 minecraft:light_gray_concrete replace
fill ~258 ~46 ~384 ~258 ~46 ~388 minecraft:light_gray_concrete replace
fill ~333 ~46 ~388 ~333 ~46 ~392 minecraft:light_gray_concrete replace
fill ~354 ~46 ~392 ~354 ~46 ~396 minecraft:light_gray_concrete replace
fill ~321 ~46 ~396 ~321 ~46 ~400 minecraft:light_gray_concrete replace
fill ~345 ~46 ~400 ~345 ~46 ~404 minecraft:light_gray_concrete replace
fill ~315 ~46 ~404 ~315 ~46 ~408 minecraft:light_gray_concrete replace
fill ~90 ~46 ~412 ~90 ~46 ~416 minecraft:light_gray_concrete replace
fill ~117 ~46 ~416 ~117 ~46 ~420 minecraft:light_gray_concrete replace
fill ~141 ~46 ~420 ~141 ~46 ~424 minecraft:light_gray_concrete replace
fill ~174 ~46 ~424 ~174 ~46 ~428 minecraft:light_gray_concrete replace
fill ~198 ~46 ~428 ~198 ~46 ~432 minecraft:light_gray_concrete replace
fill ~225 ~46 ~432 ~225 ~46 ~436 minecraft:light_gray_concrete replace
fill ~255 ~46 ~436 ~255 ~46 ~440 minecraft:light_gray_concrete replace
