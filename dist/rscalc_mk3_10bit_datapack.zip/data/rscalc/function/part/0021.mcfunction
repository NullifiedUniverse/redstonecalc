fill ~240 ~35 ~32 ~240 ~35 ~44 minecraft:redstone_wire replace
fill ~258 ~35 ~32 ~258 ~35 ~44 minecraft:redstone_wire replace
setblock ~93 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~40 ~93 ~35 ~52 minecraft:redstone_wire replace
fill ~120 ~35 ~40 ~120 ~35 ~52 minecraft:redstone_wire replace
fill ~144 ~35 ~40 ~144 ~35 ~52 minecraft:redstone_wire replace
fill ~150 ~35 ~40 ~150 ~35 ~52 minecraft:redstone_wire replace
fill ~168 ~35 ~40 ~168 ~35 ~52 minecraft:redstone_wire replace
fill ~195 ~35 ~40 ~195 ~35 ~52 minecraft:redstone_wire replace
fill ~201 ~35 ~40 ~201 ~35 ~52 minecraft:redstone_wire replace
fill ~225 ~35 ~40 ~225 ~35 ~52 minecraft:redstone_wire replace
fill ~246 ~35 ~40 ~246 ~35 ~52 minecraft:redstone_wire replace
fill ~300 ~35 ~40 ~300 ~35 ~44 minecraft:redstone_wire replace
setblock ~117 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~48 ~117 ~35 ~60 minecraft:redstone_wire replace
fill ~141 ~35 ~48 ~141 ~35 ~60 minecraft:redstone_wire replace
fill ~171 ~35 ~48 ~171 ~35 ~60 minecraft:redstone_wire replace
fill ~174 ~35 ~48 ~174 ~35 ~60 minecraft:redstone_wire replace
fill ~228 ~35 ~48 ~228 ~35 ~60 minecraft:redstone_wire replace
fill ~240 ~35 ~48 ~240 ~35 ~60 minecraft:redstone_wire replace
fill ~258 ~35 ~48 ~258 ~35 ~60 minecraft:redstone_wire replace
fill ~261 ~35 ~48 ~261 ~35 ~60 minecraft:redstone_wire replace
fill ~282 ~35 ~48 ~282 ~35 ~60 minecraft:redstone_wire replace
fill ~330 ~35 ~48 ~330 ~35 ~52 minecraft:redstone_wire replace
setblock ~93 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~56 ~93 ~35 ~68 minecraft:redstone_wire replace
fill ~120 ~35 ~56 ~120 ~35 ~68 minecraft:redstone_wire replace
fill ~144 ~35 ~56 ~144 ~35 ~68 minecraft:redstone_wire replace
fill ~150 ~35 ~56 ~150 ~35 ~68 minecraft:redstone_wire replace
fill ~168 ~35 ~56 ~168 ~35 ~68 minecraft:redstone_wire replace
fill ~195 ~35 ~56 ~195 ~35 ~68 minecraft:redstone_wire replace
fill ~201 ~35 ~56 ~201 ~35 ~68 minecraft:redstone_wire replace
fill ~225 ~35 ~56 ~225 ~35 ~68 minecraft:redstone_wire replace
fill ~246 ~35 ~56 ~246 ~35 ~68 minecraft:redstone_wire replace
fill ~264 ~35 ~56 ~264 ~35 ~68 minecraft:redstone_wire replace
fill ~315 ~35 ~56 ~315 ~35 ~68 minecraft:redstone_wire replace
fill ~321 ~35 ~56 ~321 ~35 ~60 minecraft:redstone_wire replace
fill ~339 ~35 ~56 ~339 ~35 ~68 minecraft:redstone_wire replace
fill ~318 ~35 ~60 ~318 ~35 ~72 minecraft:redstone_wire replace
fill ~336 ~35 ~60 ~336 ~35 ~72 minecraft:redstone_wire replace
fill ~342 ~35 ~60 ~342 ~35 ~72 minecraft:redstone_wire replace
setblock ~117 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~64 ~117 ~35 ~76 minecraft:redstone_wire replace
fill ~141 ~35 ~64 ~141 ~35 ~76 minecraft:redstone_wire replace
fill ~171 ~35 ~64 ~171 ~35 ~76 minecraft:redstone_wire replace
fill ~174 ~35 ~64 ~174 ~35 ~76 minecraft:redstone_wire replace
fill ~228 ~35 ~64 ~228 ~35 ~76 minecraft:redstone_wire replace
fill ~240 ~35 ~64 ~240 ~35 ~76 minecraft:redstone_wire replace
fill ~258 ~35 ~64 ~258 ~35 ~76 minecraft:redstone_wire replace
fill ~261 ~35 ~64 ~261 ~35 ~76 minecraft:redstone_wire replace
fill ~282 ~35 ~64 ~282 ~35 ~76 minecraft:redstone_wire replace
setblock ~93 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~72 ~93 ~35 ~84 minecraft:redstone_wire replace
fill ~120 ~35 ~72 ~120 ~35 ~84 minecraft:redstone_wire replace
fill ~144 ~35 ~72 ~144 ~35 ~84 minecraft:redstone_wire replace
fill ~150 ~35 ~72 ~150 ~35 ~84 minecraft:redstone_wire replace
fill ~168 ~35 ~72 ~168 ~35 ~84 minecraft:redstone_wire replace
fill ~195 ~35 ~72 ~195 ~35 ~84 minecraft:redstone_wire replace
fill ~201 ~35 ~72 ~201 ~35 ~84 minecraft:redstone_wire replace
fill ~225 ~35 ~72 ~225 ~35 ~84 minecraft:redstone_wire replace
fill ~246 ~35 ~72 ~246 ~35 ~84 minecraft:redstone_wire replace
fill ~264 ~35 ~72 ~264 ~35 ~84 minecraft:redstone_wire replace
fill ~285 ~35 ~72 ~285 ~35 ~84 minecraft:redstone_wire replace
fill ~315 ~35 ~72 ~315 ~35 ~84 minecraft:redstone_wire replace
fill ~327 ~35 ~72 ~327 ~35 ~84 minecraft:redstone_wire replace
fill ~339 ~35 ~72 ~339 ~35 ~84 minecraft:redstone_wire replace
fill ~351 ~35 ~72 ~351 ~35 ~76 minecraft:redstone_wire replace
fill ~387 ~35 ~72 ~387 ~35 ~84 minecraft:redstone_wire replace
setblock ~318 ~35 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~76 ~318 ~35 ~88 minecraft:redstone_wire replace
fill ~336 ~35 ~76 ~336 ~35 ~88 minecraft:redstone_wire replace
fill ~342 ~35 ~76 ~342 ~35 ~88 minecraft:redstone_wire replace
fill ~354 ~35 ~76 ~354 ~35 ~88 minecraft:redstone_wire replace
fill ~360 ~35 ~76 ~360 ~35 ~88 minecraft:redstone_wire replace
fill ~378 ~35 ~76 ~378 ~35 ~88 minecraft:redstone_wire replace
setblock ~117 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~80 ~117 ~35 ~92 minecraft:redstone_wire replace
fill ~141 ~35 ~80 ~141 ~35 ~92 minecraft:redstone_wire replace
fill ~171 ~35 ~80 ~171 ~35 ~92 minecraft:redstone_wire replace
fill ~174 ~35 ~80 ~174 ~35 ~92 minecraft:redstone_wire replace
fill ~228 ~35 ~80 ~228 ~35 ~92 minecraft:redstone_wire replace
fill ~240 ~35 ~80 ~240 ~35 ~92 minecraft:redstone_wire replace
fill ~258 ~35 ~80 ~258 ~35 ~92 minecraft:redstone_wire replace
fill ~261 ~35 ~80 ~261 ~35 ~92 minecraft:redstone_wire replace
fill ~282 ~35 ~80 ~282 ~35 ~92 minecraft:redstone_wire replace
setblock ~93 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~88 ~93 ~35 ~100 minecraft:redstone_wire replace
fill ~120 ~35 ~88 ~120 ~35 ~100 minecraft:redstone_wire replace
fill ~144 ~35 ~88 ~144 ~35 ~100 minecraft:redstone_wire replace
fill ~150 ~35 ~88 ~150 ~35 ~100 minecraft:redstone_wire replace
fill ~168 ~35 ~88 ~168 ~35 ~100 minecraft:redstone_wire replace
fill ~195 ~35 ~88 ~195 ~35 ~100 minecraft:redstone_wire replace
fill ~201 ~35 ~88 ~201 ~35 ~100 minecraft:redstone_wire replace
fill ~225 ~35 ~88 ~225 ~35 ~100 minecraft:redstone_wire replace
fill ~246 ~35 ~88 ~246 ~35 ~100 minecraft:redstone_wire replace
fill ~264 ~35 ~88 ~264 ~35 ~100 minecraft:redstone_wire replace
fill ~285 ~35 ~88 ~285 ~35 ~100 minecraft:redstone_wire replace
fill ~315 ~35 ~88 ~315 ~35 ~100 minecraft:redstone_wire replace
fill ~327 ~35 ~88 ~327 ~35 ~100 minecraft:redstone_wire replace
fill ~339 ~35 ~88 ~339 ~35 ~100 minecraft:redstone_wire replace
fill ~387 ~35 ~88 ~387 ~35 ~100 minecraft:redstone_wire replace
setblock ~318 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~92 ~318 ~35 ~104 minecraft:redstone_wire replace
fill ~336 ~35 ~92 ~336 ~35 ~104 minecraft:redstone_wire replace
fill ~342 ~35 ~92 ~342 ~35 ~104 minecraft:redstone_wire replace
fill ~354 ~35 ~92 ~354 ~35 ~104 minecraft:redstone_wire replace
fill ~360 ~35 ~92 ~360 ~35 ~104 minecraft:redstone_wire replace
fill ~378 ~35 ~92 ~378 ~35 ~104 minecraft:redstone_wire replace
setblock ~117 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~96 ~117 ~35 ~108 minecraft:redstone_wire replace
fill ~141 ~35 ~96 ~141 ~35 ~108 minecraft:redstone_wire replace
fill ~171 ~35 ~96 ~171 ~35 ~108 minecraft:redstone_wire replace
fill ~174 ~35 ~96 ~174 ~35 ~108 minecraft:redstone_wire replace
fill ~228 ~35 ~96 ~228 ~35 ~108 minecraft:redstone_wire replace
fill ~240 ~35 ~96 ~240 ~35 ~108 minecraft:redstone_wire replace
fill ~258 ~35 ~96 ~258 ~35 ~108 minecraft:redstone_wire replace
fill ~261 ~35 ~96 ~261 ~35 ~108 minecraft:redstone_wire replace
fill ~282 ~35 ~96 ~282 ~35 ~108 minecraft:redstone_wire replace
setblock ~93 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~104 ~93 ~35 ~116 minecraft:redstone_wire replace
fill ~120 ~35 ~104 ~120 ~35 ~116 minecraft:redstone_wire replace
fill ~144 ~35 ~104 ~144 ~35 ~116 minecraft:redstone_wire replace
fill ~150 ~35 ~104 ~150 ~35 ~116 minecraft:redstone_wire replace
fill ~168 ~35 ~104 ~168 ~35 ~116 minecraft:redstone_wire replace
fill ~195 ~35 ~104 ~195 ~35 ~116 minecraft:redstone_wire replace
fill ~201 ~35 ~104 ~201 ~35 ~116 minecraft:redstone_wire replace
fill ~225 ~35 ~104 ~225 ~35 ~116 minecraft:redstone_wire replace
fill ~246 ~35 ~104 ~246 ~35 ~116 minecraft:redstone_wire replace
fill ~264 ~35 ~104 ~264 ~35 ~116 minecraft:redstone_wire replace
fill ~285 ~35 ~104 ~285 ~35 ~116 minecraft:redstone_wire replace
fill ~315 ~35 ~104 ~315 ~35 ~116 minecraft:redstone_wire replace
fill ~327 ~35 ~104 ~327 ~35 ~116 minecraft:redstone_wire replace
fill ~339 ~35 ~104 ~339 ~35 ~116 minecraft:redstone_wire replace
fill ~387 ~35 ~104 ~387 ~35 ~116 minecraft:redstone_wire replace
setblock ~318 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~108 ~318 ~35 ~120 minecraft:redstone_wire replace
fill ~336 ~35 ~108 ~336 ~35 ~120 minecraft:redstone_wire replace
fill ~342 ~35 ~108 ~342 ~35 ~120 minecraft:redstone_wire replace
fill ~354 ~35 ~108 ~354 ~35 ~120 minecraft:redstone_wire replace
fill ~360 ~35 ~108 ~360 ~35 ~120 minecraft:redstone_wire replace
fill ~378 ~35 ~108 ~378 ~35 ~120 minecraft:redstone_wire replace
setblock ~117 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~112 ~117 ~35 ~124 minecraft:redstone_wire replace
fill ~141 ~35 ~112 ~141 ~35 ~124 minecraft:redstone_wire replace
fill ~171 ~35 ~112 ~171 ~35 ~124 minecraft:redstone_wire replace
fill ~174 ~35 ~112 ~174 ~35 ~124 minecraft:redstone_wire replace
fill ~228 ~35 ~112 ~228 ~35 ~124 minecraft:redstone_wire replace
fill ~240 ~35 ~112 ~240 ~35 ~124 minecraft:redstone_wire replace
fill ~258 ~35 ~112 ~258 ~35 ~124 minecraft:redstone_wire replace
fill ~261 ~35 ~112 ~261 ~35 ~124 minecraft:redstone_wire replace
fill ~282 ~35 ~112 ~282 ~35 ~124 minecraft:redstone_wire replace
setblock ~93 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~120 ~93 ~35 ~132 minecraft:redstone_wire replace
fill ~120 ~35 ~120 ~120 ~35 ~132 minecraft:redstone_wire replace
fill ~144 ~35 ~120 ~144 ~35 ~132 minecraft:redstone_wire replace
fill ~150 ~35 ~120 ~150 ~35 ~132 minecraft:redstone_wire replace
fill ~168 ~35 ~120 ~168 ~35 ~132 minecraft:redstone_wire replace
fill ~195 ~35 ~120 ~195 ~35 ~132 minecraft:redstone_wire replace
fill ~201 ~35 ~120 ~201 ~35 ~132 minecraft:redstone_wire replace
fill ~225 ~35 ~120 ~225 ~35 ~132 minecraft:redstone_wire replace
fill ~246 ~35 ~120 ~246 ~35 ~132 minecraft:redstone_wire replace
fill ~264 ~35 ~120 ~264 ~35 ~132 minecraft:redstone_wire replace
fill ~285 ~35 ~120 ~285 ~35 ~132 minecraft:redstone_wire replace
fill ~315 ~35 ~120 ~315 ~35 ~132 minecraft:redstone_wire replace
fill ~327 ~35 ~120 ~327 ~35 ~132 minecraft:redstone_wire replace
fill ~339 ~35 ~120 ~339 ~35 ~132 minecraft:redstone_wire replace
fill ~387 ~35 ~120 ~387 ~35 ~132 minecraft:redstone_wire replace
setblock ~318 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~124 ~318 ~35 ~136 minecraft:redstone_wire replace
fill ~336 ~35 ~124 ~336 ~35 ~136 minecraft:redstone_wire replace
fill ~342 ~35 ~124 ~342 ~35 ~136 minecraft:redstone_wire replace
fill ~354 ~35 ~124 ~354 ~35 ~136 minecraft:redstone_wire replace
fill ~360 ~35 ~124 ~360 ~35 ~136 minecraft:redstone_wire replace
fill ~378 ~35 ~124 ~378 ~35 ~136 minecraft:redstone_wire replace
setblock ~117 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~128 ~117 ~35 ~140 minecraft:redstone_wire replace
fill ~141 ~35 ~128 ~141 ~35 ~140 minecraft:redstone_wire replace
fill ~171 ~35 ~128 ~171 ~35 ~140 minecraft:redstone_wire replace
fill ~174 ~35 ~128 ~174 ~35 ~140 minecraft:redstone_wire replace
fill ~228 ~35 ~128 ~228 ~35 ~140 minecraft:redstone_wire replace
fill ~240 ~35 ~128 ~240 ~35 ~140 minecraft:redstone_wire replace
fill ~258 ~35 ~128 ~258 ~35 ~140 minecraft:redstone_wire replace
fill ~261 ~35 ~128 ~261 ~35 ~140 minecraft:redstone_wire replace
fill ~282 ~35 ~128 ~282 ~35 ~140 minecraft:redstone_wire replace
setblock ~93 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~136 ~93 ~35 ~148 minecraft:redstone_wire replace
fill ~120 ~35 ~136 ~120 ~35 ~148 minecraft:redstone_wire replace
fill ~144 ~35 ~136 ~144 ~35 ~148 minecraft:redstone_wire replace
fill ~150 ~35 ~136 ~150 ~35 ~148 minecraft:redstone_wire replace
fill ~168 ~35 ~136 ~168 ~35 ~148 minecraft:redstone_wire replace
fill ~195 ~35 ~136 ~195 ~35 ~148 minecraft:redstone_wire replace
fill ~201 ~35 ~136 ~201 ~35 ~148 minecraft:redstone_wire replace
fill ~225 ~35 ~136 ~225 ~35 ~148 minecraft:redstone_wire replace
fill ~246 ~35 ~136 ~246 ~35 ~148 minecraft:redstone_wire replace
fill ~264 ~35 ~136 ~264 ~35 ~148 minecraft:redstone_wire replace
fill ~285 ~35 ~136 ~285 ~35 ~148 minecraft:redstone_wire replace
fill ~315 ~35 ~136 ~315 ~35 ~148 minecraft:redstone_wire replace
fill ~327 ~35 ~136 ~327 ~35 ~148 minecraft:redstone_wire replace
fill ~339 ~35 ~136 ~339 ~35 ~148 minecraft:redstone_wire replace
fill ~387 ~35 ~136 ~387 ~35 ~148 minecraft:redstone_wire replace
setblock ~318 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~140 ~318 ~35 ~152 minecraft:redstone_wire replace
fill ~336 ~35 ~140 ~336 ~35 ~152 minecraft:redstone_wire replace
fill ~342 ~35 ~140 ~342 ~35 ~152 minecraft:redstone_wire replace
fill ~354 ~35 ~140 ~354 ~35 ~152 minecraft:redstone_wire replace
fill ~360 ~35 ~140 ~360 ~35 ~152 minecraft:redstone_wire replace
fill ~378 ~35 ~140 ~378 ~35 ~152 minecraft:redstone_wire replace
setblock ~117 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~144 ~117 ~35 ~156 minecraft:redstone_wire replace
fill ~141 ~35 ~144 ~141 ~35 ~156 minecraft:redstone_wire replace
fill ~171 ~35 ~144 ~171 ~35 ~156 minecraft:redstone_wire replace
fill ~174 ~35 ~144 ~174 ~35 ~156 minecraft:redstone_wire replace
fill ~228 ~35 ~144 ~228 ~35 ~156 minecraft:redstone_wire replace
fill ~240 ~35 ~144 ~240 ~35 ~156 minecraft:redstone_wire replace
fill ~258 ~35 ~144 ~258 ~35 ~156 minecraft:redstone_wire replace
fill ~261 ~35 ~144 ~261 ~35 ~156 minecraft:redstone_wire replace
fill ~282 ~35 ~144 ~282 ~35 ~156 minecraft:redstone_wire replace
setblock ~93 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~152 ~93 ~35 ~164 minecraft:redstone_wire replace
fill ~120 ~35 ~152 ~120 ~35 ~164 minecraft:redstone_wire replace
fill ~144 ~35 ~152 ~144 ~35 ~164 minecraft:redstone_wire replace
fill ~150 ~35 ~152 ~150 ~35 ~164 minecraft:redstone_wire replace
fill ~168 ~35 ~152 ~168 ~35 ~164 minecraft:redstone_wire replace
fill ~195 ~35 ~152 ~195 ~35 ~164 minecraft:redstone_wire replace
fill ~201 ~35 ~152 ~201 ~35 ~164 minecraft:redstone_wire replace
fill ~225 ~35 ~152 ~225 ~35 ~164 minecraft:redstone_wire replace
fill ~246 ~35 ~152 ~246 ~35 ~164 minecraft:redstone_wire replace
fill ~264 ~35 ~152 ~264 ~35 ~164 minecraft:redstone_wire replace
fill ~285 ~35 ~152 ~285 ~35 ~164 minecraft:redstone_wire replace
fill ~315 ~35 ~152 ~315 ~35 ~164 minecraft:redstone_wire replace
fill ~327 ~35 ~152 ~327 ~35 ~164 minecraft:redstone_wire replace
fill ~339 ~35 ~152 ~339 ~35 ~164 minecraft:redstone_wire replace
fill ~387 ~35 ~152 ~387 ~35 ~164 minecraft:redstone_wire replace
setblock ~318 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~156 ~318 ~35 ~168 minecraft:redstone_wire replace
fill ~336 ~35 ~156 ~336 ~35 ~168 minecraft:redstone_wire replace
fill ~342 ~35 ~156 ~342 ~35 ~168 minecraft:redstone_wire replace
fill ~354 ~35 ~156 ~354 ~35 ~168 minecraft:redstone_wire replace
fill ~360 ~35 ~156 ~360 ~35 ~168 minecraft:redstone_wire replace
fill ~378 ~35 ~156 ~378 ~35 ~168 minecraft:redstone_wire replace
setblock ~117 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~160 ~117 ~35 ~172 minecraft:redstone_wire replace
fill ~141 ~35 ~160 ~141 ~35 ~172 minecraft:redstone_wire replace
fill ~171 ~35 ~160 ~171 ~35 ~172 minecraft:redstone_wire replace
fill ~174 ~35 ~160 ~174 ~35 ~172 minecraft:redstone_wire replace
fill ~228 ~35 ~160 ~228 ~35 ~172 minecraft:redstone_wire replace
fill ~240 ~35 ~160 ~240 ~35 ~172 minecraft:redstone_wire replace
fill ~258 ~35 ~160 ~258 ~35 ~172 minecraft:redstone_wire replace
fill ~261 ~35 ~160 ~261 ~35 ~172 minecraft:redstone_wire replace
fill ~282 ~35 ~160 ~282 ~35 ~172 minecraft:redstone_wire replace
setblock ~93 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~168 ~93 ~35 ~180 minecraft:redstone_wire replace
fill ~120 ~35 ~168 ~120 ~35 ~180 minecraft:redstone_wire replace
fill ~144 ~35 ~168 ~144 ~35 ~180 minecraft:redstone_wire replace
fill ~150 ~35 ~168 ~150 ~35 ~180 minecraft:redstone_wire replace
fill ~168 ~35 ~168 ~168 ~35 ~180 minecraft:redstone_wire replace
fill ~195 ~35 ~168 ~195 ~35 ~180 minecraft:redstone_wire replace
fill ~201 ~35 ~168 ~201 ~35 ~180 minecraft:redstone_wire replace
fill ~225 ~35 ~168 ~225 ~35 ~180 minecraft:redstone_wire replace
fill ~246 ~35 ~168 ~246 ~35 ~180 minecraft:redstone_wire replace
fill ~264 ~35 ~168 ~264 ~35 ~180 minecraft:redstone_wire replace
fill ~285 ~35 ~168 ~285 ~35 ~180 minecraft:redstone_wire replace
fill ~315 ~35 ~168 ~315 ~35 ~180 minecraft:redstone_wire replace
fill ~327 ~35 ~168 ~327 ~35 ~180 minecraft:redstone_wire replace
fill ~339 ~35 ~168 ~339 ~35 ~180 minecraft:redstone_wire replace
fill ~387 ~35 ~168 ~387 ~35 ~180 minecraft:redstone_wire replace
setblock ~318 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~172 ~318 ~35 ~184 minecraft:redstone_wire replace
fill ~336 ~35 ~172 ~336 ~35 ~184 minecraft:redstone_wire replace
fill ~342 ~35 ~172 ~342 ~35 ~184 minecraft:redstone_wire replace
fill ~354 ~35 ~172 ~354 ~35 ~184 minecraft:redstone_wire replace
fill ~360 ~35 ~172 ~360 ~35 ~184 minecraft:redstone_wire replace
fill ~378 ~35 ~172 ~378 ~35 ~184 minecraft:redstone_wire replace
setblock ~117 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~176 ~117 ~35 ~188 minecraft:redstone_wire replace
fill ~141 ~35 ~176 ~141 ~35 ~188 minecraft:redstone_wire replace
fill ~171 ~35 ~176 ~171 ~35 ~188 minecraft:redstone_wire replace
fill ~174 ~35 ~176 ~174 ~35 ~188 minecraft:redstone_wire replace
fill ~228 ~35 ~176 ~228 ~35 ~188 minecraft:redstone_wire replace
fill ~240 ~35 ~176 ~240 ~35 ~188 minecraft:redstone_wire replace
fill ~258 ~35 ~176 ~258 ~35 ~188 minecraft:redstone_wire replace
fill ~261 ~35 ~176 ~261 ~35 ~188 minecraft:redstone_wire replace
fill ~282 ~35 ~176 ~282 ~35 ~188 minecraft:redstone_wire replace
setblock ~93 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~184 ~93 ~35 ~196 minecraft:redstone_wire replace
fill ~120 ~35 ~184 ~120 ~35 ~196 minecraft:redstone_wire replace
fill ~144 ~35 ~184 ~144 ~35 ~196 minecraft:redstone_wire replace
fill ~150 ~35 ~184 ~150 ~35 ~196 minecraft:redstone_wire replace
fill ~168 ~35 ~184 ~168 ~35 ~196 minecraft:redstone_wire replace
fill ~195 ~35 ~184 ~195 ~35 ~196 minecraft:redstone_wire replace
fill ~201 ~35 ~184 ~201 ~35 ~196 minecraft:redstone_wire replace
fill ~225 ~35 ~184 ~225 ~35 ~196 minecraft:redstone_wire replace
fill ~246 ~35 ~184 ~246 ~35 ~196 minecraft:redstone_wire replace
fill ~264 ~35 ~184 ~264 ~35 ~196 minecraft:redstone_wire replace
fill ~285 ~35 ~184 ~285 ~35 ~196 minecraft:redstone_wire replace
fill ~315 ~35 ~184 ~315 ~35 ~196 minecraft:redstone_wire replace
fill ~327 ~35 ~184 ~327 ~35 ~196 minecraft:redstone_wire replace
fill ~339 ~35 ~184 ~339 ~35 ~196 minecraft:redstone_wire replace
fill ~387 ~35 ~184 ~387 ~35 ~196 minecraft:redstone_wire replace
setblock ~318 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~188 ~318 ~35 ~200 minecraft:redstone_wire replace
fill ~336 ~35 ~188 ~336 ~35 ~200 minecraft:redstone_wire replace
fill ~342 ~35 ~188 ~342 ~35 ~200 minecraft:redstone_wire replace
fill ~354 ~35 ~188 ~354 ~35 ~200 minecraft:redstone_wire replace
fill ~360 ~35 ~188 ~360 ~35 ~200 minecraft:redstone_wire replace
fill ~378 ~35 ~188 ~378 ~35 ~200 minecraft:redstone_wire replace
setblock ~117 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~192 ~117 ~35 ~204 minecraft:redstone_wire replace
fill ~141 ~35 ~192 ~141 ~35 ~204 minecraft:redstone_wire replace
fill ~171 ~35 ~192 ~171 ~35 ~204 minecraft:redstone_wire replace
fill ~174 ~35 ~192 ~174 ~35 ~204 minecraft:redstone_wire replace
fill ~228 ~35 ~192 ~228 ~35 ~204 minecraft:redstone_wire replace
fill ~240 ~35 ~192 ~240 ~35 ~204 minecraft:redstone_wire replace
fill ~258 ~35 ~192 ~258 ~35 ~204 minecraft:redstone_wire replace
fill ~261 ~35 ~192 ~261 ~35 ~204 minecraft:redstone_wire replace
fill ~282 ~35 ~192 ~282 ~35 ~204 minecraft:redstone_wire replace
setblock ~93 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~200 ~93 ~35 ~212 minecraft:redstone_wire replace
fill ~120 ~35 ~200 ~120 ~35 ~212 minecraft:redstone_wire replace
fill ~144 ~35 ~200 ~144 ~35 ~212 minecraft:redstone_wire replace
fill ~150 ~35 ~200 ~150 ~35 ~212 minecraft:redstone_wire replace
fill ~168 ~35 ~200 ~168 ~35 ~212 minecraft:redstone_wire replace
fill ~195 ~35 ~200 ~195 ~35 ~212 minecraft:redstone_wire replace
fill ~201 ~35 ~200 ~201 ~35 ~212 minecraft:redstone_wire replace
fill ~225 ~35 ~200 ~225 ~35 ~212 minecraft:redstone_wire replace
fill ~246 ~35 ~200 ~246 ~35 ~212 minecraft:redstone_wire replace
fill ~264 ~35 ~200 ~264 ~35 ~212 minecraft:redstone_wire replace
fill ~285 ~35 ~200 ~285 ~35 ~212 minecraft:redstone_wire replace
fill ~315 ~35 ~200 ~315 ~35 ~212 minecraft:redstone_wire replace
fill ~327 ~35 ~200 ~327 ~35 ~212 minecraft:redstone_wire replace
fill ~339 ~35 ~200 ~339 ~35 ~212 minecraft:redstone_wire replace
fill ~387 ~35 ~200 ~387 ~35 ~212 minecraft:redstone_wire replace
setblock ~318 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~204 ~318 ~35 ~216 minecraft:redstone_wire replace
fill ~336 ~35 ~204 ~336 ~35 ~216 minecraft:redstone_wire replace
fill ~342 ~35 ~204 ~342 ~35 ~216 minecraft:redstone_wire replace
fill ~354 ~35 ~204 ~354 ~35 ~216 minecraft:redstone_wire replace
fill ~360 ~35 ~204 ~360 ~35 ~216 minecraft:redstone_wire replace
fill ~378 ~35 ~204 ~378 ~35 ~216 minecraft:redstone_wire replace
setblock ~117 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~208 ~117 ~35 ~220 minecraft:redstone_wire replace
fill ~141 ~35 ~208 ~141 ~35 ~220 minecraft:redstone_wire replace
fill ~171 ~35 ~208 ~171 ~35 ~220 minecraft:redstone_wire replace
fill ~174 ~35 ~208 ~174 ~35 ~220 minecraft:redstone_wire replace
fill ~228 ~35 ~208 ~228 ~35 ~220 minecraft:redstone_wire replace
fill ~240 ~35 ~208 ~240 ~35 ~220 minecraft:redstone_wire replace
fill ~258 ~35 ~208 ~258 ~35 ~220 minecraft:redstone_wire replace
fill ~261 ~35 ~208 ~261 ~35 ~220 minecraft:redstone_wire replace
fill ~282 ~35 ~208 ~282 ~35 ~220 minecraft:redstone_wire replace
setblock ~93 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~216 ~93 ~35 ~228 minecraft:redstone_wire replace
fill ~120 ~35 ~216 ~120 ~35 ~228 minecraft:redstone_wire replace
fill ~144 ~35 ~216 ~144 ~35 ~228 minecraft:redstone_wire replace
fill ~150 ~35 ~216 ~150 ~35 ~228 minecraft:redstone_wire replace
fill ~168 ~35 ~216 ~168 ~35 ~228 minecraft:redstone_wire replace
fill ~195 ~35 ~216 ~195 ~35 ~228 minecraft:redstone_wire replace
fill ~201 ~35 ~216 ~201 ~35 ~228 minecraft:redstone_wire replace
fill ~225 ~35 ~216 ~225 ~35 ~228 minecraft:redstone_wire replace
fill ~246 ~35 ~216 ~246 ~35 ~228 minecraft:redstone_wire replace
fill ~264 ~35 ~216 ~264 ~35 ~228 minecraft:redstone_wire replace
fill ~285 ~35 ~216 ~285 ~35 ~228 minecraft:redstone_wire replace
fill ~315 ~35 ~216 ~315 ~35 ~228 minecraft:redstone_wire replace
fill ~327 ~35 ~216 ~327 ~35 ~228 minecraft:redstone_wire replace
fill ~339 ~35 ~216 ~339 ~35 ~228 minecraft:redstone_wire replace
fill ~387 ~35 ~216 ~387 ~35 ~228 minecraft:redstone_wire replace
setblock ~318 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~220 ~318 ~35 ~232 minecraft:redstone_wire replace
fill ~336 ~35 ~220 ~336 ~35 ~232 minecraft:redstone_wire replace
fill ~342 ~35 ~220 ~342 ~35 ~232 minecraft:redstone_wire replace
fill ~354 ~35 ~220 ~354 ~35 ~232 minecraft:redstone_wire replace
fill ~360 ~35 ~220 ~360 ~35 ~232 minecraft:redstone_wire replace
fill ~378 ~35 ~220 ~378 ~35 ~232 minecraft:redstone_wire replace
setblock ~117 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~224 ~117 ~35 ~236 minecraft:redstone_wire replace
fill ~141 ~35 ~224 ~141 ~35 ~236 minecraft:redstone_wire replace
fill ~171 ~35 ~224 ~171 ~35 ~236 minecraft:redstone_wire replace
fill ~174 ~35 ~224 ~174 ~35 ~236 minecraft:redstone_wire replace
fill ~228 ~35 ~224 ~228 ~35 ~236 minecraft:redstone_wire replace
fill ~240 ~35 ~224 ~240 ~35 ~236 minecraft:redstone_wire replace
fill ~258 ~35 ~224 ~258 ~35 ~236 minecraft:redstone_wire replace
fill ~261 ~35 ~224 ~261 ~35 ~236 minecraft:redstone_wire replace
fill ~282 ~35 ~224 ~282 ~35 ~236 minecraft:redstone_wire replace
setblock ~93 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~232 ~93 ~35 ~244 minecraft:redstone_wire replace
fill ~120 ~35 ~232 ~120 ~35 ~244 minecraft:redstone_wire replace
fill ~144 ~35 ~232 ~144 ~35 ~244 minecraft:redstone_wire replace
fill ~150 ~35 ~232 ~150 ~35 ~244 minecraft:redstone_wire replace
fill ~168 ~35 ~232 ~168 ~35 ~244 minecraft:redstone_wire replace
fill ~195 ~35 ~232 ~195 ~35 ~244 minecraft:redstone_wire replace
fill ~201 ~35 ~232 ~201 ~35 ~244 minecraft:redstone_wire replace
fill ~225 ~35 ~232 ~225 ~35 ~244 minecraft:redstone_wire replace
fill ~246 ~35 ~232 ~246 ~35 ~244 minecraft:redstone_wire replace
fill ~264 ~35 ~232 ~264 ~35 ~244 minecraft:redstone_wire replace
fill ~285 ~35 ~232 ~285 ~35 ~244 minecraft:redstone_wire replace
fill ~315 ~35 ~232 ~315 ~35 ~244 minecraft:redstone_wire replace
fill ~327 ~35 ~232 ~327 ~35 ~244 minecraft:redstone_wire replace
fill ~339 ~35 ~232 ~339 ~35 ~244 minecraft:redstone_wire replace
fill ~387 ~35 ~232 ~387 ~35 ~244 minecraft:redstone_wire replace
setblock ~318 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~236 ~318 ~35 ~248 minecraft:redstone_wire replace
fill ~336 ~35 ~236 ~336 ~35 ~248 minecraft:redstone_wire replace
fill ~342 ~35 ~236 ~342 ~35 ~248 minecraft:redstone_wire replace
fill ~354 ~35 ~236 ~354 ~35 ~248 minecraft:redstone_wire replace
fill ~360 ~35 ~236 ~360 ~35 ~248 minecraft:redstone_wire replace
fill ~378 ~35 ~236 ~378 ~35 ~248 minecraft:redstone_wire replace
setblock ~117 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~240 ~117 ~35 ~252 minecraft:redstone_wire replace
fill ~141 ~35 ~240 ~141 ~35 ~252 minecraft:redstone_wire replace
fill ~171 ~35 ~240 ~171 ~35 ~252 minecraft:redstone_wire replace
fill ~174 ~35 ~240 ~174 ~35 ~252 minecraft:redstone_wire replace
fill ~228 ~35 ~240 ~228 ~35 ~252 minecraft:redstone_wire replace
fill ~240 ~35 ~240 ~240 ~35 ~252 minecraft:redstone_wire replace
fill ~258 ~35 ~240 ~258 ~35 ~252 minecraft:redstone_wire replace
fill ~261 ~35 ~240 ~261 ~35 ~252 minecraft:redstone_wire replace
fill ~282 ~35 ~240 ~282 ~35 ~252 minecraft:redstone_wire replace
setblock ~93 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~248 ~93 ~35 ~258 minecraft:redstone_wire replace
fill ~120 ~35 ~248 ~120 ~35 ~260 minecraft:redstone_wire replace
fill ~144 ~35 ~248 ~144 ~35 ~260 minecraft:redstone_wire replace
fill ~150 ~35 ~248 ~150 ~35 ~260 minecraft:redstone_wire replace
fill ~168 ~35 ~248 ~168 ~35 ~260 minecraft:redstone_wire replace
fill ~195 ~35 ~248 ~195 ~35 ~260 minecraft:redstone_wire replace
fill ~201 ~35 ~248 ~201 ~35 ~260 minecraft:redstone_wire replace
fill ~225 ~35 ~248 ~225 ~35 ~260 minecraft:redstone_wire replace
fill ~246 ~35 ~248 ~246 ~35 ~260 minecraft:redstone_wire replace
fill ~264 ~35 ~248 ~264 ~35 ~260 minecraft:redstone_wire replace
fill ~285 ~35 ~248 ~285 ~35 ~260 minecraft:redstone_wire replace
fill ~315 ~35 ~248 ~315 ~35 ~260 minecraft:redstone_wire replace
fill ~327 ~35 ~248 ~327 ~35 ~260 minecraft:redstone_wire replace
fill ~339 ~35 ~248 ~339 ~35 ~260 minecraft:redstone_wire replace
fill ~387 ~35 ~248 ~387 ~35 ~260 minecraft:redstone_wire replace
setblock ~318 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~252 ~318 ~35 ~264 minecraft:redstone_wire replace
fill ~336 ~35 ~252 ~336 ~35 ~264 minecraft:redstone_wire replace
fill ~342 ~35 ~252 ~342 ~35 ~264 minecraft:redstone_wire replace
fill ~354 ~35 ~252 ~354 ~35 ~264 minecraft:redstone_wire replace
fill ~360 ~35 ~252 ~360 ~35 ~264 minecraft:redstone_wire replace
fill ~378 ~35 ~252 ~378 ~35 ~264 minecraft:redstone_wire replace
setblock ~117 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~256 ~117 ~35 ~268 minecraft:redstone_wire replace
fill ~141 ~35 ~256 ~141 ~35 ~268 minecraft:redstone_wire replace
fill ~171 ~35 ~256 ~171 ~35 ~268 minecraft:redstone_wire replace
fill ~174 ~35 ~256 ~174 ~35 ~268 minecraft:redstone_wire replace
fill ~180 ~35 ~256 ~180 ~35 ~268 minecraft:redstone_wire replace
fill ~228 ~35 ~256 ~228 ~35 ~268 minecraft:redstone_wire replace
fill ~240 ~35 ~256 ~240 ~35 ~268 minecraft:redstone_wire replace
fill ~258 ~35 ~256 ~258 ~35 ~268 minecraft:redstone_wire replace
fill ~261 ~35 ~256 ~261 ~35 ~268 minecraft:redstone_wire replace
fill ~282 ~35 ~256 ~282 ~35 ~268 minecraft:redstone_wire replace
setblock ~93 ~35 ~260 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~264 minecraft:redstone_wire replace
fill ~144 ~35 ~264 ~144 ~35 ~276 minecraft:redstone_wire replace
fill ~150 ~35 ~264 ~150 ~35 ~268 minecraft:redstone_wire replace
fill ~156 ~35 ~264 ~156 ~35 ~274 minecraft:redstone_wire replace
fill ~168 ~35 ~264 ~168 ~35 ~276 minecraft:redstone_wire replace
fill ~195 ~35 ~264 ~195 ~35 ~276 minecraft:redstone_wire replace
fill ~201 ~35 ~264 ~201 ~35 ~276 minecraft:redstone_wire replace
fill ~225 ~35 ~264 ~225 ~35 ~276 minecraft:redstone_wire replace
fill ~246 ~35 ~264 ~246 ~35 ~276 minecraft:redstone_wire replace
fill ~264 ~35 ~264 ~264 ~35 ~276 minecraft:redstone_wire replace
fill ~285 ~35 ~264 ~285 ~35 ~276 minecraft:redstone_wire replace
fill ~315 ~35 ~264 ~315 ~35 ~276 minecraft:redstone_wire replace
fill ~327 ~35 ~264 ~327 ~35 ~276 minecraft:redstone_wire replace
fill ~339 ~35 ~264 ~339 ~35 ~276 minecraft:redstone_wire replace
fill ~387 ~35 ~264 ~387 ~35 ~276 minecraft:redstone_wire replace
setblock ~318 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~35 ~268 ~213 ~35 ~280 minecraft:redstone_wire replace
fill ~318 ~35 ~268 ~318 ~35 ~280 minecraft:redstone_wire replace
fill ~336 ~35 ~268 ~336 ~35 ~280 minecraft:redstone_wire replace
fill ~342 ~35 ~268 ~342 ~35 ~280 minecraft:redstone_wire replace
fill ~354 ~35 ~268 ~354 ~35 ~280 minecraft:redstone_wire replace
fill ~360 ~35 ~268 ~360 ~35 ~280 minecraft:redstone_wire replace
fill ~378 ~35 ~268 ~378 ~35 ~280 minecraft:redstone_wire replace
setblock ~117 ~35 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~270 ~117 ~35 ~278 minecraft:redstone_wire replace
fill ~141 ~35 ~270 ~141 ~35 ~282 minecraft:redstone_wire replace
fill ~171 ~35 ~270 ~171 ~35 ~282 minecraft:redstone_wire replace
setblock ~174 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~35 ~272 ~174 ~35 ~284 minecraft:redstone_wire replace
setblock ~180 ~35 ~272 minecraft:redstone_wire replace
fill ~228 ~35 ~272 ~228 ~35 ~284 minecraft:redstone_wire replace
fill ~240 ~35 ~272 ~240 ~35 ~284 minecraft:redstone_wire replace
fill ~258 ~35 ~272 ~258 ~35 ~284 minecraft:redstone_wire replace
fill ~261 ~35 ~272 ~261 ~35 ~284 minecraft:redstone_wire replace
fill ~282 ~35 ~272 ~282 ~35 ~284 minecraft:redstone_wire replace
setblock ~156 ~35 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~35 ~276 ~255 ~35 ~288 minecraft:redstone_wire replace
setblock ~144 ~35 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~35 ~278 ~144 ~35 ~290 minecraft:redstone_wire replace
fill ~168 ~35 ~278 ~168 ~35 ~290 minecraft:redstone_wire replace
setblock ~195 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~35 ~278 ~201 ~35 ~290 minecraft:redstone_wire replace
setblock ~225 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~35 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~35 ~280 ~195 ~35 ~292 minecraft:redstone_wire replace
fill ~225 ~35 ~280 ~225 ~35 ~292 minecraft:redstone_wire replace
fill ~246 ~35 ~280 ~246 ~35 ~292 minecraft:redstone_wire replace
fill ~264 ~35 ~280 ~264 ~35 ~292 minecraft:redstone_wire replace
fill ~285 ~35 ~280 ~285 ~35 ~292 minecraft:redstone_wire replace
fill ~315 ~35 ~280 ~315 ~35 ~292 minecraft:redstone_wire replace
fill ~327 ~35 ~280 ~327 ~35 ~292 minecraft:redstone_wire replace
fill ~339 ~35 ~280 ~339 ~35 ~292 minecraft:redstone_wire replace
fill ~387 ~35 ~280 ~387 ~35 ~292 minecraft:redstone_wire replace
setblock ~213 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~283 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~284 minecraft:redstone_wire replace
setblock ~171 ~35 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~35 ~284 ~213 ~35 ~290 minecraft:redstone_wire replace
fill ~318 ~35 ~284 ~318 ~35 ~296 minecraft:redstone_wire replace
fill ~336 ~35 ~284 ~336 ~35 ~296 minecraft:redstone_wire replace
fill ~342 ~35 ~284 ~342 ~35 ~296 minecraft:redstone_wire replace
fill ~354 ~35 ~284 ~354 ~35 ~296 minecraft:redstone_wire replace
fill ~360 ~35 ~284 ~360 ~35 ~296 minecraft:redstone_wire replace
fill ~378 ~35 ~284 ~378 ~35 ~296 minecraft:redstone_wire replace
setblock ~174 ~35 ~285 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~285 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~285 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~35 ~286 ~171 ~35 ~288 minecraft:redstone_wire replace
fill ~174 ~35 ~286 ~174 ~35 ~298 minecraft:redstone_wire replace
setblock ~228 ~35 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~35 ~286 ~240 ~35 ~298 minecraft:redstone_wire replace
fill ~258 ~35 ~286 ~258 ~35 ~298 minecraft:redstone_wire replace
setblock ~261 ~35 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~35 ~288 ~228 ~35 ~300 minecraft:redstone_wire replace
fill ~261 ~35 ~288 ~261 ~35 ~300 minecraft:redstone_wire replace
fill ~282 ~35 ~288 ~282 ~35 ~300 minecraft:redstone_wire replace
setblock ~255 ~35 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~35 ~292 ~255 ~35 ~304 minecraft:redstone_wire replace
fill ~303 ~35 ~292 ~303 ~35 ~304 minecraft:redstone_wire replace
setblock ~195 ~35 ~293 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~293 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~293 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~35 ~294 ~144 ~35 ~296 minecraft:redstone_wire replace
fill ~168 ~35 ~294 ~168 ~35 ~300 minecraft:redstone_wire replace
fill ~195 ~35 ~294 ~195 ~35 ~306 minecraft:redstone_wire replace
fill ~201 ~35 ~294 ~201 ~35 ~302 minecraft:redstone_wire replace
fill ~225 ~35 ~294 ~225 ~35 ~306 minecraft:redstone_wire replace
fill ~246 ~35 ~294 ~246 ~35 ~306 minecraft:redstone_wire replace
setblock ~264 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~35 ~296 ~264 ~35 ~308 minecraft:redstone_wire replace
fill ~285 ~35 ~296 ~285 ~35 ~308 minecraft:redstone_wire replace
fill ~315 ~35 ~296 ~315 ~35 ~308 minecraft:redstone_wire replace
fill ~327 ~35 ~296 ~327 ~35 ~308 minecraft:redstone_wire replace
fill ~339 ~35 ~296 ~339 ~35 ~308 minecraft:redstone_wire replace
fill ~387 ~35 ~296 ~387 ~35 ~308 minecraft:redstone_wire replace
setblock ~318 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~300 ~318 ~35 ~312 minecraft:redstone_wire replace
fill ~333 ~35 ~300 ~333 ~35 ~312 minecraft:redstone_wire replace
fill ~336 ~35 ~300 ~336 ~35 ~312 minecraft:redstone_wire replace
fill ~342 ~35 ~300 ~342 ~35 ~312 minecraft:redstone_wire replace
fill ~354 ~35 ~300 ~354 ~35 ~312 minecraft:redstone_wire replace
fill ~360 ~35 ~300 ~360 ~35 ~312 minecraft:redstone_wire replace
fill ~378 ~35 ~300 ~378 ~35 ~312 minecraft:redstone_wire replace
setblock ~228 ~35 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~35 ~302 ~174 ~35 ~310 minecraft:redstone_wire replace
fill ~228 ~35 ~302 ~228 ~35 ~314 minecraft:redstone_wire replace
fill ~240 ~35 ~302 ~240 ~35 ~314 minecraft:redstone_wire replace
fill ~258 ~35 ~302 ~258 ~35 ~314 minecraft:redstone_wire replace
fill ~261 ~35 ~302 ~261 ~35 ~314 minecraft:redstone_wire replace
fill ~282 ~35 ~302 ~282 ~35 ~314 minecraft:redstone_wire replace
setblock ~201 ~35 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~35 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~35 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~35 ~308 minecraft:redstone_wire replace
fill ~303 ~35 ~308 ~303 ~35 ~320 minecraft:redstone_wire replace
fill ~324 ~35 ~308 ~324 ~35 ~320 minecraft:redstone_wire replace
setblock ~264 ~35 ~309 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~309 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~309 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~35 ~310 ~195 ~35 ~322 minecraft:redstone_wire replace
fill ~225 ~35 ~310 ~225 ~35 ~322 minecraft:redstone_wire replace
fill ~246 ~35 ~310 ~246 ~35 ~322 minecraft:redstone_wire replace
fill ~264 ~35 ~310 ~264 ~35 ~322 minecraft:redstone_wire replace
setblock ~285 ~35 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~35 ~310 ~315 ~35 ~322 minecraft:redstone_wire replace
setblock ~327 ~35 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~35 ~310 ~339 ~35 ~322 minecraft:redstone_wire replace
setblock ~387 ~35 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~35 ~312 ~285 ~35 ~324 minecraft:redstone_wire replace
fill ~327 ~35 ~312 ~327 ~35 ~324 minecraft:redstone_wire replace
fill ~387 ~35 ~312 ~387 ~35 ~324 minecraft:redstone_wire replace
setblock ~318 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~315 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~316 minecraft:redstone_wire replace
setblock ~258 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~316 ~318 ~35 ~328 minecraft:redstone_wire replace
fill ~333 ~35 ~316 ~333 ~35 ~328 minecraft:redstone_wire replace
fill ~336 ~35 ~316 ~336 ~35 ~328 minecraft:redstone_wire replace
fill ~342 ~35 ~316 ~342 ~35 ~328 minecraft:redstone_wire replace
fill ~354 ~35 ~316 ~354 ~35 ~328 minecraft:redstone_wire replace
fill ~360 ~35 ~316 ~360 ~35 ~328 minecraft:redstone_wire replace
fill ~378 ~35 ~316 ~378 ~35 ~328 minecraft:redstone_wire replace
fill ~228 ~35 ~318 ~228 ~35 ~330 minecraft:redstone_wire replace
fill ~258 ~35 ~318 ~258 ~35 ~320 minecraft:redstone_wire replace
fill ~261 ~35 ~318 ~261 ~35 ~330 minecraft:redstone_wire replace
fill ~282 ~35 ~318 ~282 ~35 ~330 minecraft:redstone_wire replace
setblock ~303 ~35 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~35 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~323 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~324 minecraft:redstone_wire replace
setblock ~225 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~35 ~324 ~303 ~35 ~334 minecraft:redstone_wire replace
setblock ~315 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~35 ~324 ~324 ~35 ~336 minecraft:redstone_wire replace
setblock ~339 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~35 ~324 ~348 ~35 ~336 minecraft:redstone_wire replace
setblock ~285 ~35 ~325 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~325 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~325 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~35 ~326 ~225 ~35 ~328 minecraft:redstone_wire replace
fill ~246 ~35 ~326 ~246 ~35 ~332 minecraft:redstone_wire replace
fill ~264 ~35 ~326 ~264 ~35 ~338 minecraft:redstone_wire replace
fill ~285 ~35 ~326 ~285 ~35 ~338 minecraft:redstone_wire replace
fill ~315 ~35 ~326 ~315 ~35 ~338 minecraft:redstone_wire replace
fill ~327 ~35 ~326 ~327 ~35 ~338 minecraft:redstone_wire replace
fill ~339 ~35 ~326 ~339 ~35 ~338 minecraft:redstone_wire replace
fill ~387 ~35 ~326 ~387 ~35 ~338 minecraft:redstone_wire replace
setblock ~318 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~332 ~318 ~35 ~344 minecraft:redstone_wire replace
fill ~333 ~35 ~332 ~333 ~35 ~344 minecraft:redstone_wire replace
fill ~336 ~35 ~332 ~336 ~35 ~344 minecraft:redstone_wire replace
fill ~342 ~35 ~332 ~342 ~35 ~344 minecraft:redstone_wire replace
fill ~354 ~35 ~332 ~354 ~35 ~344 minecraft:redstone_wire replace
fill ~360 ~35 ~332 ~360 ~35 ~344 minecraft:redstone_wire replace
fill ~378 ~35 ~332 ~378 ~35 ~344 minecraft:redstone_wire replace
fill ~228 ~35 ~334 ~228 ~35 ~340 minecraft:redstone_wire replace
fill ~261 ~35 ~334 ~261 ~35 ~342 minecraft:redstone_wire replace
fill ~282 ~35 ~334 ~282 ~35 ~346 minecraft:redstone_wire replace
setblock ~303 ~35 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~35 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~340 ~90 ~35 ~352 minecraft:redstone_wire replace
setblock ~264 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~35 ~340 ~324 ~35 ~352 minecraft:redstone_wire replace
setblock ~327 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~35 ~340 ~348 ~35 ~352 minecraft:redstone_wire replace
setblock ~387 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~35 ~342 ~264 ~35 ~354 minecraft:redstone_wire replace
fill ~285 ~35 ~342 ~285 ~35 ~354 minecraft:redstone_wire replace
fill ~315 ~35 ~342 ~315 ~35 ~354 minecraft:redstone_wire replace
fill ~327 ~35 ~342 ~327 ~35 ~354 minecraft:redstone_wire replace
fill ~339 ~35 ~342 ~339 ~35 ~354 minecraft:redstone_wire replace
fill ~387 ~35 ~342 ~387 ~35 ~354 minecraft:redstone_wire replace
fill ~114 ~35 ~344 ~114 ~35 ~356 minecraft:redstone_wire replace
setblock ~261 ~35 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~35 ~348 ~138 ~35 ~360 minecraft:redstone_wire replace
setblock ~282 ~35 ~348 minecraft:redstone_wire replace
fill ~318 ~35 ~348 ~318 ~35 ~360 minecraft:redstone_wire replace
fill ~333 ~35 ~348 ~333 ~35 ~352 minecraft:redstone_wire replace
fill ~336 ~35 ~348 ~336 ~35 ~360 minecraft:redstone_wire replace
fill ~342 ~35 ~348 ~342 ~35 ~360 minecraft:redstone_wire replace
fill ~354 ~35 ~348 ~354 ~35 ~360 minecraft:redstone_wire replace
fill ~360 ~35 ~348 ~360 ~35 ~360 minecraft:redstone_wire replace
fill ~378 ~35 ~348 ~378 ~35 ~360 minecraft:redstone_wire replace
fill ~186 ~35 ~352 ~186 ~35 ~364 minecraft:redstone_wire replace
setblock ~90 ~35 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~35 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~355 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~356 ~90 ~35 ~368 minecraft:redstone_wire replace
fill ~216 ~35 ~356 ~216 ~35 ~368 minecraft:redstone_wire replace
setblock ~264 ~35 ~356 minecraft:redstone_wire replace
setblock ~285 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~35 ~356 ~324 ~35 ~362 minecraft:redstone_wire replace
setblock ~327 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~35 ~356 ~348 ~35 ~368 minecraft:redstone_wire replace
setblock ~387 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~35 ~358 ~285 ~35 ~370 minecraft:redstone_wire replace
fill ~315 ~35 ~358 ~315 ~35 ~360 minecraft:redstone_wire replace
fill ~327 ~35 ~358 ~327 ~35 ~370 minecraft:redstone_wire replace
fill ~339 ~35 ~358 ~339 ~35 ~366 minecraft:redstone_wire replace
fill ~387 ~35 ~358 ~387 ~35 ~370 minecraft:redstone_wire replace
fill ~114 ~35 ~360 ~114 ~35 ~372 minecraft:redstone_wire replace
fill ~243 ~35 ~360 ~243 ~35 ~372 minecraft:redstone_wire replace
setblock ~138 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~35 ~364 ~138 ~35 ~376 minecraft:redstone_wire replace
fill ~279 ~35 ~364 ~279 ~35 ~376 minecraft:redstone_wire replace
fill ~318 ~35 ~364 ~318 ~35 ~370 minecraft:redstone_wire replace
setblock ~324 ~35 ~364 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~35 ~364 ~336 ~35 ~374 minecraft:redstone_wire replace
fill ~342 ~35 ~364 ~342 ~35 ~376 minecraft:redstone_wire replace
fill ~354 ~35 ~364 ~354 ~35 ~376 minecraft:redstone_wire replace
fill ~360 ~35 ~364 ~360 ~35 ~376 minecraft:redstone_wire replace
fill ~378 ~35 ~364 ~378 ~35 ~376 minecraft:redstone_wire replace
setblock ~186 ~35 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~35 ~368 ~186 ~35 ~380 minecraft:redstone_wire replace
fill ~309 ~35 ~368 ~309 ~35 ~380 minecraft:redstone_wire replace
setblock ~339 ~35 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~35 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~372 ~90 ~35 ~384 minecraft:redstone_wire replace
fill ~216 ~35 ~372 ~216 ~35 ~384 minecraft:redstone_wire replace
setblock ~285 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~35 ~372 ~345 ~35 ~384 minecraft:redstone_wire replace
fill ~348 ~35 ~372 ~348 ~35 ~384 minecraft:redstone_wire replace
setblock ~387 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~35 ~374 ~285 ~35 ~382 minecraft:redstone_wire replace
fill ~327 ~35 ~374 ~327 ~35 ~386 minecraft:redstone_wire replace
fill ~387 ~35 ~374 ~387 ~35 ~386 minecraft:redstone_wire replace
fill ~87 ~35 ~376 ~87 ~35 ~388 minecraft:redstone_wire replace
fill ~114 ~35 ~376 ~114 ~35 ~388 minecraft:redstone_wire replace
fill ~243 ~35 ~376 ~243 ~35 ~388 minecraft:redstone_wire replace
setblock ~336 ~35 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~380 ~111 ~35 ~392 minecraft:redstone_wire replace
fill ~138 ~35 ~380 ~138 ~35 ~392 minecraft:redstone_wire replace
fill ~279 ~35 ~380 ~279 ~35 ~392 minecraft:redstone_wire replace
setblock ~342 ~35 ~380 minecraft:redstone_wire replace
fill ~354 ~35 ~380 ~354 ~35 ~392 minecraft:redstone_wire replace
fill ~360 ~35 ~380 ~360 ~35 ~392 minecraft:redstone_wire replace
fill ~378 ~35 ~380 ~378 ~35 ~392 minecraft:redstone_wire replace
setblock ~186 ~35 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~384 ~135 ~35 ~396 minecraft:redstone_wire replace
fill ~186 ~35 ~384 ~186 ~35 ~396 minecraft:redstone_wire replace
setblock ~285 ~35 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~309 ~35 ~384 ~309 ~35 ~396 minecraft:redstone_wire replace
setblock ~90 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~388 ~90 ~35 ~400 minecraft:redstone_wire replace
fill ~183 ~35 ~388 ~183 ~35 ~400 minecraft:redstone_wire replace
fill ~216 ~35 ~388 ~216 ~35 ~400 minecraft:redstone_wire replace
setblock ~327 ~35 ~388 minecraft:redstone_wire replace
fill ~345 ~35 ~388 ~345 ~35 ~400 minecraft:redstone_wire replace
fill ~348 ~35 ~388 ~348 ~35 ~392 minecraft:redstone_wire replace
setblock ~387 ~35 ~388 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~35 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~387 ~35 ~390 ~387 ~35 ~396 minecraft:redstone_wire replace
fill ~87 ~35 ~392 ~87 ~35 ~404 minecraft:redstone_wire replace
fill ~114 ~35 ~392 ~114 ~35 ~404 minecraft:redstone_wire replace
fill ~207 ~35 ~392 ~207 ~35 ~404 minecraft:redstone_wire replace
fill ~243 ~35 ~392 ~243 ~35 ~404 minecraft:redstone_wire replace
setblock ~111 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~396 ~111 ~35 ~408 minecraft:redstone_wire replace
fill ~138 ~35 ~396 ~138 ~35 ~408 minecraft:redstone_wire replace
fill ~237 ~35 ~396 ~237 ~35 ~408 minecraft:redstone_wire replace
fill ~279 ~35 ~396 ~279 ~35 ~408 minecraft:redstone_wire replace
fill ~354 ~35 ~396 ~354 ~35 ~400 minecraft:redstone_wire replace
fill ~360 ~35 ~396 ~360 ~35 ~402 minecraft:redstone_wire replace
fill ~378 ~35 ~396 ~378 ~35 ~406 minecraft:redstone_wire replace
setblock ~135 ~35 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~35 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~400 ~135 ~35 ~412 minecraft:redstone_wire replace
fill ~186 ~35 ~400 ~186 ~35 ~412 minecraft:redstone_wire replace
fill ~276 ~35 ~400 ~276 ~35 ~412 minecraft:redstone_wire replace
fill ~309 ~35 ~400 ~309 ~35 ~412 minecraft:redstone_wire replace
setblock ~90 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~404 ~90 ~35 ~410 minecraft:redstone_wire replace
fill ~183 ~35 ~404 ~183 ~35 ~416 minecraft:redstone_wire replace
fill ~216 ~35 ~404 ~216 ~35 ~416 minecraft:redstone_wire replace
fill ~306 ~35 ~404 ~306 ~35 ~416 minecraft:redstone_wire replace
fill ~345 ~35 ~404 ~345 ~35 ~416 minecraft:redstone_wire replace
setblock ~360 ~35 ~404 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~35 ~408 ~87 ~35 ~420 minecraft:redstone_wire replace
fill ~114 ~35 ~408 ~114 ~35 ~414 minecraft:redstone_wire replace
fill ~207 ~35 ~408 ~207 ~35 ~420 minecraft:redstone_wire replace
fill ~243 ~35 ~408 ~243 ~35 ~420 minecraft:redstone_wire replace
fill ~369 ~35 ~408 ~369 ~35 ~420 minecraft:redstone_wire replace
setblock ~378 ~35 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~35 ~412 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~412 ~111 ~35 ~424 minecraft:redstone_wire replace
fill ~138 ~35 ~412 ~138 ~35 ~418 minecraft:redstone_wire replace
fill ~237 ~35 ~412 ~237 ~35 ~424 minecraft:redstone_wire replace
fill ~279 ~35 ~412 ~279 ~35 ~424 minecraft:redstone_wire replace
fill ~393 ~35 ~412 ~393 ~35 ~424 minecraft:redstone_wire replace
setblock ~135 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~416 ~84 ~35 ~428 minecraft:redstone_wire replace
setblock ~114 ~35 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~416 ~135 ~35 ~428 minecraft:redstone_wire replace
fill ~186 ~35 ~416 ~186 ~35 ~422 minecraft:redstone_wire replace
fill ~276 ~35 ~416 ~276 ~35 ~428 minecraft:redstone_wire replace
fill ~309 ~35 ~416 ~309 ~35 ~428 minecraft:redstone_wire replace
setblock ~183 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~420 ~108 ~35 ~432 minecraft:redstone_wire replace
setblock ~138 ~35 ~420 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~35 ~420 ~183 ~35 ~432 minecraft:redstone_wire replace
fill ~216 ~35 ~420 ~216 ~35 ~426 minecraft:redstone_wire replace
fill ~306 ~35 ~420 ~306 ~35 ~432 minecraft:redstone_wire replace
fill ~345 ~35 ~420 ~345 ~35 ~432 minecraft:redstone_wire replace
setblock ~87 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~35 ~424 ~87 ~35 ~436 minecraft:redstone_wire replace
fill ~132 ~35 ~424 ~132 ~35 ~436 minecraft:redstone_wire replace
setblock ~186 ~35 ~424 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~35 ~424 ~207 ~35 ~436 minecraft:redstone_wire replace
fill ~243 ~35 ~424 ~243 ~35 ~430 minecraft:redstone_wire replace
fill ~369 ~35 ~424 ~369 ~35 ~436 minecraft:redstone_wire replace
setblock ~111 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~428 ~111 ~35 ~440 minecraft:redstone_wire replace
fill ~165 ~35 ~428 ~165 ~35 ~440 minecraft:redstone_wire replace
setblock ~216 ~35 ~428 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~35 ~428 ~237 ~35 ~440 minecraft:redstone_wire replace
fill ~279 ~35 ~428 ~279 ~35 ~434 minecraft:redstone_wire replace
fill ~393 ~35 ~428 ~393 ~35 ~440 minecraft:redstone_wire replace
setblock ~84 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~432 ~84 ~35 ~444 minecraft:redstone_wire replace
fill ~135 ~35 ~432 ~135 ~35 ~444 minecraft:redstone_wire replace
fill ~204 ~35 ~432 ~204 ~35 ~444 minecraft:redstone_wire replace
setblock ~243 ~35 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~35 ~432 ~276 ~35 ~444 minecraft:redstone_wire replace
fill ~309 ~35 ~432 ~309 ~35 ~438 minecraft:redstone_wire replace
setblock ~108 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~436 ~108 ~35 ~448 minecraft:redstone_wire replace
fill ~183 ~35 ~436 ~183 ~35 ~448 minecraft:redstone_wire replace
fill ~234 ~35 ~436 ~234 ~35 ~448 minecraft:redstone_wire replace
setblock ~279 ~35 ~436 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~35 ~436 ~306 ~35 ~448 minecraft:redstone_wire replace
fill ~345 ~35 ~436 ~345 ~35 ~442 minecraft:redstone_wire replace
setblock ~87 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~35 ~440 ~87 ~35 ~446 minecraft:redstone_wire replace
fill ~132 ~35 ~440 ~132 ~35 ~452 minecraft:redstone_wire replace
fill ~207 ~35 ~440 ~207 ~35 ~452 minecraft:redstone_wire replace
fill ~273 ~35 ~440 ~273 ~35 ~452 minecraft:redstone_wire replace
setblock ~309 ~35 ~440 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~369 ~35 ~440 ~369 ~35 ~452 minecraft:redstone_wire replace
setblock ~111 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~444 ~111 ~35 ~450 minecraft:redstone_wire replace
fill ~165 ~35 ~444 ~165 ~35 ~456 minecraft:redstone_wire replace
fill ~237 ~35 ~444 ~237 ~35 ~456 minecraft:redstone_wire replace
fill ~297 ~35 ~444 ~297 ~35 ~456 minecraft:redstone_wire replace
setblock ~345 ~35 ~444 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~393 ~35 ~444 ~393 ~35 ~456 minecraft:redstone_wire replace
setblock ~84 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~448 ~84 ~35 ~460 minecraft:redstone_wire replace
setblock ~87 ~35 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~448 ~135 ~35 ~454 minecraft:redstone_wire replace
fill ~204 ~35 ~448 ~204 ~35 ~460 minecraft:redstone_wire replace
fill ~276 ~35 ~448 ~276 ~35 ~460 minecraft:redstone_wire replace
fill ~366 ~35 ~448 ~366 ~35 ~460 minecraft:redstone_wire replace
setblock ~108 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~452 ~108 ~35 ~464 minecraft:redstone_wire replace
setblock ~111 ~35 ~452 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~35 ~452 ~183 ~35 ~458 minecraft:redstone_wire replace
fill ~234 ~35 ~452 ~234 ~35 ~464 minecraft:redstone_wire replace
fill ~306 ~35 ~452 ~306 ~35 ~464 minecraft:redstone_wire replace
fill ~390 ~35 ~452 ~390 ~35 ~464 minecraft:redstone_wire replace
setblock ~132 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~456 ~81 ~35 ~468 minecraft:redstone_wire replace
fill ~132 ~35 ~456 ~132 ~35 ~468 minecraft:redstone_wire replace
setblock ~135 ~35 ~456 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~35 ~456 ~207 ~35 ~462 minecraft:redstone_wire replace
fill ~273 ~35 ~456 ~273 ~35 ~468 minecraft:redstone_wire replace
fill ~369 ~35 ~456 ~369 ~35 ~468 minecraft:redstone_wire replace
setblock ~165 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~460 ~105 ~35 ~472 minecraft:redstone_wire replace
fill ~165 ~35 ~460 ~165 ~35 ~472 minecraft:redstone_wire replace
setblock ~183 ~35 ~460 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~35 ~460 ~237 ~35 ~466 minecraft:redstone_wire replace
fill ~297 ~35 ~460 ~297 ~35 ~472 minecraft:redstone_wire replace
fill ~393 ~35 ~460 ~393 ~35 ~472 minecraft:redstone_wire replace
setblock ~84 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~464 ~84 ~35 ~476 minecraft:redstone_wire replace
fill ~129 ~35 ~464 ~129 ~35 ~476 minecraft:redstone_wire replace
fill ~204 ~35 ~464 ~204 ~35 ~476 minecraft:redstone_wire replace
setblock ~207 ~35 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~35 ~464 ~276 ~35 ~470 minecraft:redstone_wire replace
fill ~366 ~35 ~464 ~366 ~35 ~476 minecraft:redstone_wire replace
setblock ~108 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~468 ~108 ~35 ~480 minecraft:redstone_wire replace
fill ~159 ~35 ~468 ~159 ~35 ~480 minecraft:redstone_wire replace
fill ~234 ~35 ~468 ~234 ~35 ~480 minecraft:redstone_wire replace
setblock ~237 ~35 ~468 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~35 ~468 ~306 ~35 ~474 minecraft:redstone_wire replace
fill ~390 ~35 ~468 ~390 ~35 ~480 minecraft:redstone_wire replace
setblock ~81 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~472 ~81 ~35 ~484 minecraft:redstone_wire replace
fill ~132 ~35 ~472 ~132 ~35 ~484 minecraft:redstone_wire replace
fill ~198 ~35 ~472 ~198 ~35 ~484 minecraft:redstone_wire replace
fill ~273 ~35 ~472 ~273 ~35 ~484 minecraft:redstone_wire replace
setblock ~276 ~35 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~369 ~35 ~472 ~369 ~35 ~478 minecraft:redstone_wire replace
setblock ~105 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~476 ~105 ~35 ~488 minecraft:redstone_wire replace
fill ~165 ~35 ~476 ~165 ~35 ~488 minecraft:redstone_wire replace
fill ~231 ~35 ~476 ~231 ~35 ~488 minecraft:redstone_wire replace
fill ~297 ~35 ~476 ~297 ~35 ~488 minecraft:redstone_wire replace
setblock ~306 ~35 ~476 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~393 ~35 ~476 ~393 ~35 ~482 minecraft:redstone_wire replace
setblock ~84 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~480 ~84 ~35 ~486 minecraft:redstone_wire replace
fill ~129 ~35 ~480 ~129 ~35 ~492 minecraft:redstone_wire replace
fill ~204 ~35 ~480 ~204 ~35 ~492 minecraft:redstone_wire replace
fill ~270 ~35 ~480 ~270 ~35 ~492 minecraft:redstone_wire replace
fill ~366 ~35 ~480 ~366 ~35 ~492 minecraft:redstone_wire replace
setblock ~369 ~35 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~484 ~108 ~35 ~490 minecraft:redstone_wire replace
fill ~159 ~35 ~484 ~159 ~35 ~496 minecraft:redstone_wire replace
fill ~234 ~35 ~484 ~234 ~35 ~496 minecraft:redstone_wire replace
fill ~291 ~35 ~484 ~291 ~35 ~496 minecraft:redstone_wire replace
fill ~390 ~35 ~484 ~390 ~35 ~496 minecraft:redstone_wire replace
setblock ~393 ~35 ~484 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~488 ~81 ~35 ~500 minecraft:redstone_wire replace
setblock ~84 ~35 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~35 ~488 ~132 ~35 ~494 minecraft:redstone_wire replace
fill ~198 ~35 ~488 ~198 ~35 ~500 minecraft:redstone_wire replace
fill ~273 ~35 ~488 ~273 ~35 ~500 minecraft:redstone_wire replace
fill ~363 ~35 ~488 ~363 ~35 ~500 minecraft:redstone_wire replace
setblock ~105 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~492 ~105 ~35 ~504 minecraft:redstone_wire replace
setblock ~108 ~35 ~492 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~35 ~492 ~165 ~35 ~498 minecraft:redstone_wire replace
fill ~231 ~35 ~492 ~231 ~35 ~504 minecraft:redstone_wire replace
fill ~297 ~35 ~492 ~297 ~35 ~504 minecraft:redstone_wire replace
fill ~384 ~35 ~492 ~384 ~35 ~504 minecraft:redstone_wire replace
setblock ~129 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~496 ~78 ~35 ~508 minecraft:redstone_wire replace
fill ~129 ~35 ~496 ~129 ~35 ~508 minecraft:redstone_wire replace
setblock ~132 ~35 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~35 ~496 ~204 ~35 ~502 minecraft:redstone_wire replace
fill ~270 ~35 ~496 ~270 ~35 ~508 minecraft:redstone_wire replace
fill ~366 ~35 ~496 ~366 ~35 ~508 minecraft:redstone_wire replace
setblock ~159 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~500 ~102 ~35 ~512 minecraft:redstone_wire replace
fill ~159 ~35 ~500 ~159 ~35 ~512 minecraft:redstone_wire replace
setblock ~165 ~35 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~35 ~500 ~234 ~35 ~506 minecraft:redstone_wire replace
fill ~291 ~35 ~500 ~291 ~35 ~512 minecraft:redstone_wire replace
fill ~390 ~35 ~500 ~390 ~35 ~512 minecraft:redstone_wire replace
setblock ~81 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~504 ~81 ~35 ~516 minecraft:redstone_wire replace
fill ~126 ~35 ~504 ~126 ~35 ~516 minecraft:redstone_wire replace
fill ~198 ~35 ~504 ~198 ~35 ~516 minecraft:redstone_wire replace
setblock ~204 ~35 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~35 ~504 ~273 ~35 ~510 minecraft:redstone_wire replace
fill ~363 ~35 ~504 ~363 ~35 ~516 minecraft:redstone_wire replace
setblock ~105 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~508 ~105 ~35 ~520 minecraft:redstone_wire replace
fill ~153 ~35 ~508 ~153 ~35 ~520 minecraft:redstone_wire replace
fill ~231 ~35 ~508 ~231 ~35 ~520 minecraft:redstone_wire replace
setblock ~234 ~35 ~508 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~35 ~508 ~297 ~35 ~514 minecraft:redstone_wire replace
fill ~384 ~35 ~508 ~384 ~35 ~520 minecraft:redstone_wire replace
setblock ~78 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~512 ~78 ~35 ~524 minecraft:redstone_wire replace
fill ~129 ~35 ~512 ~129 ~35 ~524 minecraft:redstone_wire replace
fill ~192 ~35 ~512 ~192 ~35 ~524 minecraft:redstone_wire replace
fill ~270 ~35 ~512 ~270 ~35 ~524 minecraft:redstone_wire replace
setblock ~273 ~35 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~366 ~35 ~512 ~366 ~35 ~518 minecraft:redstone_wire replace
setblock ~102 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~516 ~102 ~35 ~528 minecraft:redstone_wire replace
fill ~159 ~35 ~516 ~159 ~35 ~528 minecraft:redstone_wire replace
fill ~222 ~35 ~516 ~222 ~35 ~528 minecraft:redstone_wire replace
fill ~291 ~35 ~516 ~291 ~35 ~528 minecraft:redstone_wire replace
setblock ~297 ~35 ~516 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~390 ~35 ~516 ~390 ~35 ~522 minecraft:redstone_wire replace
setblock ~81 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~520 ~81 ~35 ~526 minecraft:redstone_wire replace
fill ~126 ~35 ~520 ~126 ~35 ~532 minecraft:redstone_wire replace
fill ~198 ~35 ~520 ~198 ~35 ~532 minecraft:redstone_wire replace
fill ~267 ~35 ~520 ~267 ~35 ~532 minecraft:redstone_wire replace
fill ~363 ~35 ~520 ~363 ~35 ~532 minecraft:redstone_wire replace
setblock ~366 ~35 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~524 ~105 ~35 ~530 minecraft:redstone_wire replace
fill ~153 ~35 ~524 ~153 ~35 ~536 minecraft:redstone_wire replace
fill ~231 ~35 ~524 ~231 ~35 ~536 minecraft:redstone_wire replace
fill ~288 ~35 ~524 ~288 ~35 ~536 minecraft:redstone_wire replace
fill ~384 ~35 ~524 ~384 ~35 ~536 minecraft:redstone_wire replace
setblock ~390 ~35 ~524 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~528 ~78 ~35 ~540 minecraft:redstone_wire replace
setblock ~81 ~35 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~35 ~528 ~129 ~35 ~534 minecraft:redstone_wire replace
fill ~192 ~35 ~528 ~192 ~35 ~540 minecraft:redstone_wire replace
fill ~270 ~35 ~528 ~270 ~35 ~540 minecraft:redstone_wire replace
fill ~357 ~35 ~528 ~357 ~35 ~540 minecraft:redstone_wire replace
setblock ~102 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~532 ~102 ~35 ~544 minecraft:redstone_wire replace
setblock ~105 ~35 ~532 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~35 ~532 ~159 ~35 ~538 minecraft:redstone_wire replace
fill ~222 ~35 ~532 ~222 ~35 ~544 minecraft:redstone_wire replace
fill ~291 ~35 ~532 ~291 ~35 ~544 minecraft:redstone_wire replace
fill ~381 ~35 ~532 ~381 ~35 ~544 minecraft:redstone_wire replace
setblock ~126 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~536 ~99 ~35 ~548 minecraft:redstone_wire replace
fill ~126 ~35 ~536 ~126 ~35 ~548 minecraft:redstone_wire replace
setblock ~129 ~35 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~35 ~536 ~198 ~35 ~542 minecraft:redstone_wire replace
fill ~267 ~35 ~536 ~267 ~35 ~548 minecraft:redstone_wire replace
fill ~363 ~35 ~536 ~363 ~35 ~548 minecraft:redstone_wire replace
setblock ~153 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~540 ~123 ~35 ~552 minecraft:redstone_wire replace
fill ~153 ~35 ~540 ~153 ~35 ~552 minecraft:redstone_wire replace
setblock ~159 ~35 ~540 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~35 ~540 ~231 ~35 ~546 minecraft:redstone_wire replace
fill ~288 ~35 ~540 ~288 ~35 ~552 minecraft:redstone_wire replace
fill ~384 ~35 ~540 ~384 ~35 ~552 minecraft:redstone_wire replace
setblock ~78 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~544 ~78 ~35 ~556 minecraft:redstone_wire replace
fill ~147 ~35 ~544 ~147 ~35 ~556 minecraft:redstone_wire replace
fill ~192 ~35 ~544 ~192 ~35 ~556 minecraft:redstone_wire replace
setblock ~198 ~35 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~35 ~544 ~270 ~35 ~550 minecraft:redstone_wire replace
fill ~357 ~35 ~544 ~357 ~35 ~556 minecraft:redstone_wire replace
setblock ~102 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~548 ~102 ~35 ~560 minecraft:redstone_wire replace
fill ~189 ~35 ~548 ~189 ~35 ~560 minecraft:redstone_wire replace
fill ~222 ~35 ~548 ~222 ~35 ~560 minecraft:redstone_wire replace
setblock ~231 ~35 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~35 ~548 ~291 ~35 ~554 minecraft:redstone_wire replace
fill ~381 ~35 ~548 ~381 ~35 ~560 minecraft:redstone_wire replace
setblock ~99 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~552 ~99 ~35 ~564 minecraft:redstone_wire replace
fill ~126 ~35 ~552 ~126 ~35 ~564 minecraft:redstone_wire replace
fill ~219 ~35 ~552 ~219 ~35 ~564 minecraft:redstone_wire replace
fill ~267 ~35 ~552 ~267 ~35 ~564 minecraft:redstone_wire replace
setblock ~270 ~35 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~363 ~35 ~552 ~363 ~35 ~558 minecraft:redstone_wire replace
setblock ~123 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~556 ~123 ~35 ~568 minecraft:redstone_wire replace
fill ~153 ~35 ~556 ~153 ~35 ~568 minecraft:redstone_wire replace
fill ~249 ~35 ~556 ~249 ~35 ~568 minecraft:redstone_wire replace
fill ~288 ~35 ~556 ~288 ~35 ~568 minecraft:redstone_wire replace
setblock ~291 ~35 ~556 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~384 ~35 ~556 ~384 ~35 ~562 minecraft:redstone_wire replace
setblock ~78 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~560 ~78 ~35 ~566 minecraft:redstone_wire replace
fill ~147 ~35 ~560 ~147 ~35 ~572 minecraft:redstone_wire replace
fill ~192 ~35 ~560 ~192 ~35 ~572 minecraft:redstone_wire replace
fill ~294 ~35 ~560 ~294 ~35 ~572 minecraft:redstone_wire replace
fill ~357 ~35 ~560 ~357 ~35 ~572 minecraft:redstone_wire replace
setblock ~363 ~35 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~564 ~102 ~35 ~570 minecraft:redstone_wire replace
fill ~189 ~35 ~564 ~189 ~35 ~576 minecraft:redstone_wire replace
fill ~222 ~35 ~564 ~222 ~35 ~576 minecraft:redstone_wire replace
fill ~312 ~35 ~564 ~312 ~35 ~576 minecraft:redstone_wire replace
fill ~381 ~35 ~564 ~381 ~35 ~576 minecraft:redstone_wire replace
setblock ~384 ~35 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~35 ~568 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~568 ~99 ~35 ~580 minecraft:redstone_wire replace
fill ~126 ~35 ~568 ~126 ~35 ~574 minecraft:redstone_wire replace
fill ~219 ~35 ~568 ~219 ~35 ~580 minecraft:redstone_wire replace
fill ~267 ~35 ~568 ~267 ~35 ~580 minecraft:redstone_wire replace
fill ~372 ~35 ~568 ~372 ~35 ~580 minecraft:redstone_wire replace
setblock ~123 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~35 ~572 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~572 ~123 ~35 ~584 minecraft:redstone_wire replace
fill ~153 ~35 ~572 ~153 ~35 ~578 minecraft:redstone_wire replace
fill ~162 ~35 ~572 ~162 ~35 ~584 minecraft:redstone_wire replace
fill ~249 ~35 ~572 ~249 ~35 ~584 minecraft:redstone_wire replace
fill ~288 ~35 ~572 ~288 ~35 ~584 minecraft:redstone_wire replace
setblock ~147 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~35 ~576 ~147 ~35 ~588 minecraft:redstone_wire replace
fill ~192 ~35 ~576 ~192 ~35 ~582 minecraft:redstone_wire replace
fill ~294 ~35 ~576 ~294 ~35 ~588 minecraft:redstone_wire replace
fill ~357 ~35 ~576 ~357 ~35 ~588 minecraft:redstone_wire replace
fill ~399 ~35 ~576 ~399 ~35 ~588 minecraft:redstone_wire replace
setblock ~189 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~580 ~96 ~35 ~592 minecraft:redstone_wire replace
setblock ~153 ~35 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~35 ~580 ~189 ~35 ~592 minecraft:redstone_wire replace
fill ~222 ~35 ~580 ~222 ~35 ~586 minecraft:redstone_wire replace
fill ~312 ~35 ~580 ~312 ~35 ~592 minecraft:redstone_wire replace
fill ~381 ~35 ~580 ~381 ~35 ~592 minecraft:redstone_wire replace
setblock ~99 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~584 ~99 ~35 ~596 minecraft:redstone_wire replace
setblock ~192 ~35 ~584 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~35 ~584 ~219 ~35 ~596 minecraft:redstone_wire replace
fill ~267 ~35 ~584 ~267 ~35 ~590 minecraft:redstone_wire replace
fill ~372 ~35 ~584 ~372 ~35 ~596 minecraft:redstone_wire replace
fill ~375 ~35 ~584 ~375 ~35 ~596 minecraft:redstone_wire replace
setblock ~123 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~588 ~123 ~35 ~600 minecraft:redstone_wire replace
fill ~162 ~35 ~588 ~162 ~35 ~600 minecraft:redstone_wire replace
setblock ~222 ~35 ~588 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~35 ~588 ~249 ~35 ~600 minecraft:redstone_wire replace
fill ~288 ~35 ~588 ~288 ~35 ~594 minecraft:redstone_wire replace
fill ~396 ~35 ~588 ~396 ~35 ~600 minecraft:redstone_wire replace
setblock ~147 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~35 ~592 ~147 ~35 ~604 minecraft:redstone_wire replace
setblock ~267 ~35 ~592 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~35 ~592 ~294 ~35 ~604 minecraft:redstone_wire replace
fill ~357 ~35 ~592 ~357 ~35 ~598 minecraft:redstone_wire replace
fill ~399 ~35 ~592 ~399 ~35 ~604 minecraft:redstone_wire replace
setblock ~96 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~596 ~96 ~35 ~608 minecraft:redstone_wire replace
fill ~189 ~35 ~596 ~189 ~35 ~608 minecraft:redstone_wire replace
setblock ~288 ~35 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~35 ~596 ~312 ~35 ~608 minecraft:redstone_wire replace
fill ~381 ~35 ~596 ~381 ~35 ~602 minecraft:redstone_wire replace
setblock ~99 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~600 ~99 ~35 ~606 minecraft:redstone_wire replace
fill ~219 ~35 ~600 ~219 ~35 ~612 minecraft:redstone_wire replace
setblock ~357 ~35 ~600 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~35 ~600 ~372 ~35 ~612 minecraft:redstone_wire replace
fill ~375 ~35 ~600 ~375 ~35 ~612 minecraft:redstone_wire replace
setblock ~123 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~604 ~123 ~35 ~610 minecraft:redstone_wire replace
fill ~162 ~35 ~604 ~162 ~35 ~616 minecraft:redstone_wire replace
fill ~249 ~35 ~604 ~249 ~35 ~616 minecraft:redstone_wire replace
setblock ~381 ~35 ~604 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~35 ~604 ~396 ~35 ~616 minecraft:redstone_wire replace
setblock ~147 ~35 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~35 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~35 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~35 ~608 ~147 ~35 ~614 minecraft:redstone_wire replace
fill ~294 ~35 ~608 ~294 ~35 ~620 minecraft:redstone_wire replace
fill ~399 ~35 ~608 ~399 ~35 ~620 minecraft:redstone_wire replace
setblock ~96 ~35 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~35 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~612 ~96 ~35 ~624 minecraft:redstone_wire replace
setblock ~123 ~35 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~35 ~612 ~189 ~35 ~618 minecraft:redstone_wire replace
fill ~312 ~35 ~612 ~312 ~35 ~624 minecraft:redstone_wire replace
setblock ~219 ~35 ~614 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~614 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~614 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~35 ~616 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~35 ~616 ~219 ~35 ~622 minecraft:redstone_wire replace
fill ~372 ~35 ~616 ~372 ~35 ~628 minecraft:redstone_wire replace
fill ~375 ~35 ~616 ~375 ~35 ~628 minecraft:redstone_wire replace
setblock ~162 ~35 ~618 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~618 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~618 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~35 ~620 ~162 ~35 ~632 minecraft:redstone_wire replace
setblock ~189 ~35 ~620 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~35 ~620 ~249 ~35 ~626 minecraft:redstone_wire replace
fill ~396 ~35 ~620 ~396 ~35 ~632 minecraft:redstone_wire replace
setblock ~294 ~35 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~35 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~624 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~35 ~624 ~294 ~35 ~630 minecraft:redstone_wire replace
fill ~399 ~35 ~624 ~399 ~35 ~636 minecraft:redstone_wire replace
setblock ~96 ~35 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~628 ~96 ~35 ~640 minecraft:redstone_wire replace
setblock ~249 ~35 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~35 ~628 ~312 ~35 ~634 minecraft:redstone_wire replace
setblock ~372 ~35 ~630 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~630 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~632 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~35 ~632 ~372 ~35 ~638 minecraft:redstone_wire replace
fill ~375 ~35 ~632 ~375 ~35 ~644 minecraft:redstone_wire replace
setblock ~162 ~35 ~634 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~634 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~35 ~636 ~162 ~35 ~642 minecraft:redstone_wire replace
setblock ~312 ~35 ~636 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~35 ~636 ~396 ~35 ~648 minecraft:redstone_wire replace
setblock ~399 ~35 ~638 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~640 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~399 ~35 ~640 ~399 ~35 ~646 minecraft:redstone_wire replace
setblock ~96 ~35 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~644 ~96 ~35 ~650 minecraft:redstone_wire replace
setblock ~162 ~35 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~646 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~375 ~35 ~648 ~375 ~35 ~654 minecraft:redstone_wire replace
setblock ~399 ~35 ~648 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~650 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~35 ~652 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~35 ~652 ~396 ~35 ~658 minecraft:redstone_wire replace
setblock ~375 ~35 ~656 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~36 ~13 minecraft:redstone_wire replace
setblock ~210 ~36 ~21 minecraft:redstone_wire replace
setblock ~252 ~36 ~29 minecraft:redstone_wire replace
setblock ~300 ~36 ~45 minecraft:redstone_wire replace
setblock ~330 ~36 ~53 minecraft:redstone_wire replace
setblock ~321 ~36 ~61 minecraft:redstone_wire replace
setblock ~351 ~36 ~77 minecraft:redstone_wire replace
setblock ~93 ~36 ~261 minecraft:redstone_wire replace
setblock ~120 ~36 ~265 minecraft:redstone_wire replace
setblock ~150 ~36 ~269 minecraft:redstone_wire replace
setblock ~180 ~36 ~273 minecraft:redstone_wire replace
setblock ~156 ~36 ~277 minecraft:redstone_wire replace
setblock ~117 ~36 ~281 minecraft:redstone_wire replace
setblock ~141 ~36 ~285 minecraft:redstone_wire replace
setblock ~171 ~36 ~289 minecraft:redstone_wire replace
setblock ~213 ~36 ~293 minecraft:redstone_wire replace
setblock ~144 ~36 ~297 minecraft:redstone_wire replace
setblock ~168 ~36 ~301 minecraft:redstone_wire replace
setblock ~201 ~36 ~305 minecraft:redstone_wire replace
setblock ~255 ~36 ~309 minecraft:redstone_wire replace
setblock ~174 ~36 ~313 minecraft:redstone_wire replace
setblock ~240 ~36 ~317 minecraft:redstone_wire replace
setblock ~258 ~36 ~321 minecraft:redstone_wire replace
setblock ~195 ~36 ~325 minecraft:redstone_wire replace
setblock ~225 ~36 ~329 minecraft:redstone_wire replace
setblock ~246 ~36 ~333 minecraft:redstone_wire replace
setblock ~303 ~36 ~337 minecraft:redstone_wire replace
setblock ~228 ~36 ~341 minecraft:redstone_wire replace
setblock ~261 ~36 ~345 minecraft:redstone_wire replace
setblock ~282 ~36 ~349 minecraft:redstone_wire replace
setblock ~333 ~36 ~353 minecraft:redstone_wire replace
setblock ~264 ~36 ~357 minecraft:redstone_wire replace
setblock ~315 ~36 ~361 minecraft:redstone_wire replace
setblock ~324 ~36 ~365 minecraft:redstone_wire replace
setblock ~339 ~36 ~369 minecraft:redstone_wire replace
setblock ~318 ~36 ~373 minecraft:redstone_wire replace
setblock ~336 ~36 ~377 minecraft:redstone_wire replace
setblock ~342 ~36 ~381 minecraft:redstone_wire replace
setblock ~285 ~36 ~385 minecraft:redstone_wire replace
setblock ~327 ~36 ~389 minecraft:redstone_wire replace
setblock ~348 ~36 ~393 minecraft:redstone_wire replace
setblock ~387 ~36 ~397 minecraft:redstone_wire replace
setblock ~354 ~36 ~401 minecraft:redstone_wire replace
setblock ~360 ~36 ~405 minecraft:redstone_wire replace
setblock ~378 ~36 ~409 minecraft:redstone_wire replace
setblock ~90 ~36 ~413 minecraft:redstone_wire replace
setblock ~114 ~36 ~417 minecraft:redstone_wire replace
setblock ~138 ~36 ~421 minecraft:redstone_wire replace
setblock ~186 ~36 ~425 minecraft:redstone_wire replace
setblock ~216 ~36 ~429 minecraft:redstone_wire replace
setblock ~243 ~36 ~433 minecraft:redstone_wire replace
setblock ~279 ~36 ~437 minecraft:redstone_wire replace
setblock ~309 ~36 ~441 minecraft:redstone_wire replace
setblock ~345 ~36 ~445 minecraft:redstone_wire replace
setblock ~87 ~36 ~449 minecraft:redstone_wire replace
setblock ~111 ~36 ~453 minecraft:redstone_wire replace
setblock ~135 ~36 ~457 minecraft:redstone_wire replace
setblock ~183 ~36 ~461 minecraft:redstone_wire replace
setblock ~207 ~36 ~465 minecraft:redstone_wire replace
setblock ~237 ~36 ~469 minecraft:redstone_wire replace
setblock ~276 ~36 ~473 minecraft:redstone_wire replace
setblock ~306 ~36 ~477 minecraft:redstone_wire replace
setblock ~369 ~36 ~481 minecraft:redstone_wire replace
setblock ~393 ~36 ~485 minecraft:redstone_wire replace
setblock ~84 ~36 ~489 minecraft:redstone_wire replace
setblock ~108 ~36 ~493 minecraft:redstone_wire replace
setblock ~132 ~36 ~497 minecraft:redstone_wire replace
setblock ~165 ~36 ~501 minecraft:redstone_wire replace
setblock ~204 ~36 ~505 minecraft:redstone_wire replace
setblock ~234 ~36 ~509 minecraft:redstone_wire replace
setblock ~273 ~36 ~513 minecraft:redstone_wire replace
setblock ~297 ~36 ~517 minecraft:redstone_wire replace
setblock ~366 ~36 ~521 minecraft:redstone_wire replace
setblock ~390 ~36 ~525 minecraft:redstone_wire replace
setblock ~81 ~36 ~529 minecraft:redstone_wire replace
setblock ~105 ~36 ~533 minecraft:redstone_wire replace
setblock ~129 ~36 ~537 minecraft:redstone_wire replace
setblock ~159 ~36 ~541 minecraft:redstone_wire replace
setblock ~198 ~36 ~545 minecraft:redstone_wire replace
setblock ~231 ~36 ~549 minecraft:redstone_wire replace
setblock ~270 ~36 ~553 minecraft:redstone_wire replace
setblock ~291 ~36 ~557 minecraft:redstone_wire replace
setblock ~363 ~36 ~561 minecraft:redstone_wire replace
setblock ~384 ~36 ~565 minecraft:redstone_wire replace
setblock ~78 ~36 ~569 minecraft:redstone_wire replace
setblock ~102 ~36 ~573 minecraft:redstone_wire replace
setblock ~126 ~36 ~577 minecraft:redstone_wire replace
setblock ~153 ~36 ~581 minecraft:redstone_wire replace
setblock ~192 ~36 ~585 minecraft:redstone_wire replace
setblock ~222 ~36 ~589 minecraft:redstone_wire replace
setblock ~267 ~36 ~593 minecraft:redstone_wire replace
setblock ~288 ~36 ~597 minecraft:redstone_wire replace
setblock ~357 ~36 ~601 minecraft:redstone_wire replace
setblock ~381 ~36 ~605 minecraft:redstone_wire replace
setblock ~99 ~36 ~609 minecraft:redstone_wire replace
setblock ~123 ~36 ~613 minecraft:redstone_wire replace
setblock ~147 ~36 ~617 minecraft:redstone_wire replace
setblock ~189 ~36 ~621 minecraft:redstone_wire replace
setblock ~219 ~36 ~625 minecraft:redstone_wire replace
setblock ~249 ~36 ~629 minecraft:redstone_wire replace
setblock ~294 ~36 ~633 minecraft:redstone_wire replace
setblock ~312 ~36 ~637 minecraft:redstone_wire replace
setblock ~372 ~36 ~641 minecraft:redstone_wire replace
setblock ~162 ~36 ~645 minecraft:redstone_wire replace
setblock ~399 ~36 ~649 minecraft:redstone_wire replace
setblock ~96 ~36 ~653 minecraft:redstone_wire replace
setblock ~375 ~36 ~657 minecraft:redstone_wire replace
setblock ~396 ~36 ~661 minecraft:redstone_wire replace
fill ~147 ~37 ~14 ~150 ~37 ~14 minecraft:redstone_wire replace
setblock ~152 ~37 ~14 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~37 ~14 ~167 ~37 ~14 minecraft:redstone_wire replace
setblock ~169 ~37 ~14 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~37 ~14 ~183 ~37 ~14 minecraft:redstone_wire replace
setblock ~185 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~37 ~14 ~200 ~37 ~14 minecraft:redstone_wire replace
setblock ~202 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~37 ~14 ~217 ~37 ~14 minecraft:redstone_wire replace
setblock ~219 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~37 ~14 ~234 ~37 ~14 minecraft:redstone_wire replace
setblock ~236 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~37 ~14 ~245 ~37 ~14 minecraft:redstone_wire replace
setblock ~148 ~37 ~15 minecraft:redstone_wire replace
setblock ~175 ~37 ~15 minecraft:redstone_wire replace
setblock ~244 ~37 ~15 minecraft:redstone_wire replace
fill ~177 ~37 ~22 ~183 ~37 ~22 minecraft:redstone_wire replace
setblock ~185 ~37 ~22 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~37 ~22 ~200 ~37 ~22 minecraft:redstone_wire replace
setblock ~202 ~37 ~22 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~37 ~22 ~216 ~37 ~22 minecraft:redstone_wire replace
setblock ~218 ~37 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~37 ~22 ~233 ~37 ~22 minecraft:redstone_wire replace
setblock ~235 ~37 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~37 ~22 ~248 ~37 ~22 minecraft:redstone_wire replace
setblock ~178 ~37 ~23 minecraft:redstone_wire replace
setblock ~247 ~37 ~23 minecraft:redstone_wire replace
fill ~249 ~37 ~30 ~252 ~37 ~30 minecraft:redstone_wire replace
setblock ~250 ~37 ~31 minecraft:redstone_wire replace
fill ~258 ~37 ~46 ~259 ~37 ~46 minecraft:redstone_wire replace
setblock ~261 ~37 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~37 ~46 ~275 ~37 ~46 minecraft:redstone_wire replace
setblock ~277 ~37 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~37 ~46 ~291 ~37 ~46 minecraft:redstone_wire replace
setblock ~293 ~37 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~37 ~46 ~306 ~37 ~46 minecraft:redstone_wire replace
setblock ~308 ~37 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~37 ~46 ~323 ~37 ~46 minecraft:redstone_wire replace
setblock ~325 ~37 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~37 ~46 ~332 ~37 ~46 minecraft:redstone_wire replace
setblock ~259 ~37 ~47 minecraft:redstone_wire replace
setblock ~316 ~37 ~47 minecraft:redstone_wire replace
setblock ~331 ~37 ~47 minecraft:redstone_wire replace
fill ~318 ~37 ~54 ~320 ~37 ~54 minecraft:redstone_wire replace
setblock ~322 ~37 ~54 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~37 ~54 ~335 ~37 ~54 minecraft:redstone_wire replace
setblock ~319 ~37 ~55 minecraft:redstone_wire replace
setblock ~334 ~37 ~55 minecraft:redstone_wire replace
fill ~321 ~37 ~62 ~326 ~37 ~62 minecraft:redstone_wire replace
setblock ~325 ~37 ~63 minecraft:redstone_wire replace
fill ~348 ~37 ~78 ~351 ~37 ~78 minecraft:redstone_wire replace
setblock ~349 ~37 ~79 minecraft:redstone_wire replace
fill ~93 ~37 ~262 ~95 ~37 ~262 minecraft:redstone_wire replace
setblock ~94 ~37 ~263 minecraft:redstone_wire replace
fill ~120 ~37 ~266 ~125 ~37 ~266 minecraft:redstone_wire replace
setblock ~124 ~37 ~267 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~37 ~270 ~105 ~37 ~270 minecraft:redstone_wire replace
setblock ~107 ~37 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~37 ~270 ~122 ~37 ~270 minecraft:redstone_wire replace
setblock ~124 ~37 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~37 ~270 ~139 ~37 ~270 minecraft:redstone_wire replace
setblock ~141 ~37 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~37 ~270 ~157 ~37 ~270 minecraft:redstone_wire replace
setblock ~159 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~161 ~37 ~270 ~174 ~37 ~270 minecraft:redstone_wire replace
setblock ~176 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~37 ~270 ~191 ~37 ~270 minecraft:redstone_wire replace
setblock ~193 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~37 ~270 ~208 ~37 ~270 minecraft:redstone_wire replace
setblock ~210 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~37 ~270 ~225 ~37 ~270 minecraft:redstone_wire replace
setblock ~227 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~37 ~270 ~242 ~37 ~270 minecraft:redstone_wire replace
setblock ~244 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~246 ~37 ~270 ~254 ~37 ~270 minecraft:redstone_wire replace
setblock ~94 ~37 ~271 minecraft:redstone_wire replace
setblock ~127 ~37 ~271 minecraft:redstone_wire replace
setblock ~154 ~37 ~271 minecraft:redstone_wire replace
setblock ~184 ~37 ~271 minecraft:redstone_wire replace
setblock ~253 ~37 ~271 minecraft:redstone_wire replace
fill ~147 ~37 ~274 ~148 ~37 ~274 minecraft:redstone_wire replace
setblock ~150 ~37 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~37 ~274 ~165 ~37 ~274 minecraft:redstone_wire replace
setblock ~167 ~37 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~37 ~274 ~191 ~37 ~274 minecraft:redstone_wire replace
setblock ~193 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~37 ~274 ~208 ~37 ~274 minecraft:redstone_wire replace
setblock ~210 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~37 ~274 ~225 ~37 ~274 minecraft:redstone_wire replace
setblock ~227 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~37 ~274 ~242 ~37 ~274 minecraft:redstone_wire replace
setblock ~243 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~37 ~274 ~245 ~37 ~274 minecraft:redstone_wire replace
setblock ~148 ~37 ~275 minecraft:redstone_wire replace
setblock ~175 ~37 ~275 minecraft:redstone_wire replace
setblock ~244 ~37 ~275 minecraft:redstone_wire replace
fill ~96 ~37 ~278 ~108 ~37 ~278 minecraft:redstone_wire replace
setblock ~110 ~37 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~37 ~278 ~125 ~37 ~278 minecraft:redstone_wire replace
setblock ~126 ~37 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~37 ~278 ~140 ~37 ~278 minecraft:redstone_wire replace
setblock ~142 ~37 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~37 ~278 ~168 ~37 ~278 minecraft:redstone_wire replace
setblock ~170 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~37 ~278 ~185 ~37 ~278 minecraft:redstone_wire replace
setblock ~187 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~37 ~278 ~202 ~37 ~278 minecraft:redstone_wire replace
