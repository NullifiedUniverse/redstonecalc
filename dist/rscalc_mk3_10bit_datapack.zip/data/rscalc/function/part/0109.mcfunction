setblock ~415 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~417 ~157 ~970 ~429 ~157 ~970 minecraft:redstone_wire replace
setblock ~172 ~157 ~971 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~158 ~236 minecraft:redstone_wire replace
setblock ~82 ~158 ~240 minecraft:redstone_wire replace
setblock ~103 ~158 ~268 minecraft:redstone_wire replace
setblock ~100 ~158 ~292 minecraft:redstone_wire replace
setblock ~97 ~158 ~308 minecraft:redstone_wire replace
setblock ~94 ~158 ~336 minecraft:redstone_wire replace
setblock ~91 ~158 ~372 minecraft:redstone_wire replace
setblock ~88 ~158 ~404 minecraft:redstone_wire replace
setblock ~85 ~158 ~436 minecraft:redstone_wire replace
setblock ~79 ~158 ~452 minecraft:redstone_wire replace
setblock ~109 ~158 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~576 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~584 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~644 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~648 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~656 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~664 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~668 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~672 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~676 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~680 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~684 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~688 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~692 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~696 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~700 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~704 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~708 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~712 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~716 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~720 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~724 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~728 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~732 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~158 ~736 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~158 ~740 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~158 ~744 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~158 ~748 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~158 ~752 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~158 ~756 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~158 ~760 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~158 ~764 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~768 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~772 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~776 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~780 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~784 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~788 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~792 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~796 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~800 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~804 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~808 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~812 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~816 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~820 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~824 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~828 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~832 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~836 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~840 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~844 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~848 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~852 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~856 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~860 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~864 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~868 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~872 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~876 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~880 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~884 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~888 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~892 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~896 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~900 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~904 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~908 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~912 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~916 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~920 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~924 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~928 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~932 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~936 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~940 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~944 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~948 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~952 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~956 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~960 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~158 ~964 minecraft:redstone_wire replace
setblock ~169 ~158 ~968 minecraft:redstone_wire replace
setblock ~172 ~158 ~972 minecraft:redstone_wire replace
fill ~105 ~159 ~232 ~105 ~159 ~236 minecraft:redstone_wire replace
fill ~81 ~159 ~236 ~81 ~159 ~240 minecraft:redstone_wire replace
fill ~102 ~159 ~264 ~102 ~159 ~268 minecraft:redstone_wire replace
fill ~99 ~159 ~288 ~99 ~159 ~292 minecraft:redstone_wire replace
fill ~96 ~159 ~304 ~96 ~159 ~308 minecraft:redstone_wire replace
fill ~93 ~159 ~332 ~93 ~159 ~336 minecraft:redstone_wire replace
fill ~90 ~159 ~368 ~90 ~159 ~372 minecraft:redstone_wire replace
fill ~87 ~159 ~400 ~87 ~159 ~404 minecraft:redstone_wire replace
fill ~84 ~159 ~432 ~84 ~159 ~436 minecraft:redstone_wire replace
fill ~78 ~159 ~448 ~78 ~159 ~452 minecraft:redstone_wire replace
fill ~108 ~159 ~536 ~108 ~159 ~540 minecraft:redstone_wire replace
setblock ~108 ~159 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~159 ~542 ~108 ~159 ~554 minecraft:redstone_wire replace
setblock ~108 ~159 ~555 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~159 ~556 ~108 ~159 ~568 minecraft:redstone_wire replace
fill ~111 ~159 ~568 ~111 ~159 ~572 minecraft:redstone_wire replace
setblock ~111 ~159 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~159 ~574 ~111 ~159 ~586 minecraft:redstone_wire replace
setblock ~111 ~159 ~587 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~159 ~588 ~111 ~159 ~600 minecraft:redstone_wire replace
setblock ~114 ~159 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~159 ~602 ~114 ~159 ~608 minecraft:redstone_wire replace
setblock ~114 ~159 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~159 ~610 ~114 ~159 ~622 minecraft:redstone_wire replace
setblock ~114 ~159 ~623 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~159 ~624 ~114 ~159 ~636 minecraft:redstone_wire replace
setblock ~117 ~159 ~636 minecraft:redstone_wire replace
setblock ~117 ~159 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~159 ~638 ~117 ~159 ~650 minecraft:redstone_wire replace
setblock ~117 ~159 ~651 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~159 ~652 ~117 ~159 ~664 minecraft:redstone_wire replace
fill ~120 ~159 ~664 ~120 ~159 ~666 minecraft:redstone_wire replace
setblock ~120 ~159 ~667 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~159 ~668 ~120 ~159 ~680 minecraft:redstone_wire replace
setblock ~123 ~159 ~680 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~159 ~682 ~123 ~159 ~690 minecraft:redstone_wire replace
setblock ~123 ~159 ~691 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~159 ~692 ~123 ~159 ~704 minecraft:redstone_wire replace
setblock ~126 ~159 ~704 minecraft:redstone_wire replace
setblock ~126 ~159 ~705 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~159 ~706 ~126 ~159 ~718 minecraft:redstone_wire replace
setblock ~126 ~159 ~719 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~159 ~720 ~126 ~159 ~732 minecraft:redstone_wire replace
fill ~150 ~159 ~732 ~150 ~159 ~736 minecraft:redstone_wire replace
setblock ~153 ~159 ~736 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~159 ~738 ~153 ~159 ~744 minecraft:redstone_wire replace
setblock ~156 ~159 ~744 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~159 ~746 ~156 ~159 ~752 minecraft:redstone_wire replace
fill ~159 ~159 ~752 ~159 ~159 ~756 minecraft:redstone_wire replace
fill ~162 ~159 ~756 ~162 ~159 ~760 minecraft:redstone_wire replace
fill ~165 ~159 ~760 ~165 ~159 ~764 minecraft:redstone_wire replace
fill ~129 ~159 ~764 ~129 ~159 ~768 minecraft:redstone_wire replace
setblock ~129 ~159 ~769 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~159 ~770 ~129 ~159 ~782 minecraft:redstone_wire replace
setblock ~129 ~159 ~783 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~159 ~784 ~129 ~159 ~796 minecraft:redstone_wire replace
fill ~132 ~159 ~796 ~132 ~159 ~800 minecraft:redstone_wire replace
setblock ~132 ~159 ~801 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~159 ~802 ~132 ~159 ~814 minecraft:redstone_wire replace
setblock ~132 ~159 ~815 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~159 ~816 ~132 ~159 ~828 minecraft:redstone_wire replace
setblock ~135 ~159 ~828 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~159 ~830 ~135 ~159 ~836 minecraft:redstone_wire replace
setblock ~135 ~159 ~837 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~159 ~838 ~135 ~159 ~850 minecraft:redstone_wire replace
setblock ~135 ~159 ~851 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~159 ~852 ~135 ~159 ~864 minecraft:redstone_wire replace
setblock ~138 ~159 ~864 minecraft:redstone_wire replace
setblock ~138 ~159 ~865 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~159 ~866 ~138 ~159 ~878 minecraft:redstone_wire replace
setblock ~138 ~159 ~879 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~159 ~880 ~138 ~159 ~892 minecraft:redstone_wire replace
fill ~141 ~159 ~892 ~141 ~159 ~894 minecraft:redstone_wire replace
setblock ~141 ~159 ~895 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~159 ~896 ~141 ~159 ~908 minecraft:redstone_wire replace
setblock ~144 ~159 ~908 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~159 ~910 ~144 ~159 ~918 minecraft:redstone_wire replace
setblock ~144 ~159 ~919 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~159 ~920 ~144 ~159 ~932 minecraft:redstone_wire replace
setblock ~147 ~159 ~932 minecraft:redstone_wire replace
setblock ~147 ~159 ~933 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~159 ~934 ~147 ~159 ~946 minecraft:redstone_wire replace
setblock ~147 ~159 ~947 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~159 ~948 ~147 ~159 ~960 minecraft:redstone_wire replace
fill ~174 ~159 ~960 ~174 ~159 ~964 minecraft:redstone_wire replace
fill ~168 ~159 ~964 ~168 ~159 ~968 minecraft:redstone_wire replace
fill ~171 ~159 ~968 ~171 ~159 ~972 minecraft:redstone_wire replace
setblock ~105 ~160 ~231 minecraft:redstone_wire replace
setblock ~81 ~160 ~235 minecraft:redstone_wire replace
setblock ~102 ~160 ~263 minecraft:redstone_wire replace
setblock ~99 ~160 ~287 minecraft:redstone_wire replace
setblock ~96 ~160 ~303 minecraft:redstone_wire replace
setblock ~93 ~160 ~331 minecraft:redstone_wire replace
setblock ~90 ~160 ~367 minecraft:redstone_wire replace
setblock ~87 ~160 ~399 minecraft:redstone_wire replace
setblock ~84 ~160 ~431 minecraft:redstone_wire replace
setblock ~78 ~160 ~447 minecraft:redstone_wire replace
setblock ~108 ~160 ~535 minecraft:redstone_wire replace
setblock ~111 ~160 ~567 minecraft:redstone_wire replace
setblock ~114 ~160 ~599 minecraft:redstone_wire replace
setblock ~117 ~160 ~635 minecraft:redstone_wire replace
setblock ~120 ~160 ~663 minecraft:redstone_wire replace
setblock ~123 ~160 ~679 minecraft:redstone_wire replace
setblock ~126 ~160 ~703 minecraft:redstone_wire replace
setblock ~150 ~160 ~731 minecraft:redstone_wire replace
setblock ~153 ~160 ~735 minecraft:redstone_wire replace
setblock ~156 ~160 ~743 minecraft:redstone_wire replace
setblock ~159 ~160 ~751 minecraft:redstone_wire replace
setblock ~162 ~160 ~755 minecraft:redstone_wire replace
setblock ~165 ~160 ~759 minecraft:redstone_wire replace
setblock ~129 ~160 ~763 minecraft:redstone_wire replace
setblock ~132 ~160 ~795 minecraft:redstone_wire replace
setblock ~135 ~160 ~827 minecraft:redstone_wire replace
setblock ~138 ~160 ~863 minecraft:redstone_wire replace
setblock ~141 ~160 ~891 minecraft:redstone_wire replace
setblock ~144 ~160 ~907 minecraft:redstone_wire replace
setblock ~147 ~160 ~931 minecraft:redstone_wire replace
setblock ~174 ~160 ~959 minecraft:redstone_wire replace
setblock ~168 ~160 ~963 minecraft:redstone_wire replace
setblock ~171 ~160 ~967 minecraft:redstone_wire replace
fill ~105 ~161 ~230 ~107 ~161 ~230 minecraft:redstone_wire replace
fill ~81 ~161 ~234 ~83 ~161 ~234 minecraft:redstone_wire replace
fill ~102 ~161 ~262 ~104 ~161 ~262 minecraft:redstone_wire replace
fill ~99 ~161 ~286 ~101 ~161 ~286 minecraft:redstone_wire replace
fill ~96 ~161 ~302 ~98 ~161 ~302 minecraft:redstone_wire replace
fill ~93 ~161 ~330 ~95 ~161 ~330 minecraft:redstone_wire replace
fill ~90 ~161 ~366 ~92 ~161 ~366 minecraft:redstone_wire replace
fill ~87 ~161 ~398 ~89 ~161 ~398 minecraft:redstone_wire replace
fill ~84 ~161 ~430 ~86 ~161 ~430 minecraft:redstone_wire replace
fill ~78 ~161 ~446 ~80 ~161 ~446 minecraft:redstone_wire replace
fill ~108 ~161 ~534 ~110 ~161 ~534 minecraft:redstone_wire replace
fill ~111 ~161 ~566 ~113 ~161 ~566 minecraft:redstone_wire replace
fill ~114 ~161 ~598 ~116 ~161 ~598 minecraft:redstone_wire replace
fill ~117 ~161 ~634 ~119 ~161 ~634 minecraft:redstone_wire replace
fill ~120 ~161 ~662 ~122 ~161 ~662 minecraft:redstone_wire replace
fill ~123 ~161 ~678 ~125 ~161 ~678 minecraft:redstone_wire replace
fill ~126 ~161 ~702 ~128 ~161 ~702 minecraft:redstone_wire replace
fill ~150 ~161 ~730 ~152 ~161 ~730 minecraft:redstone_wire replace
fill ~153 ~161 ~734 ~155 ~161 ~734 minecraft:redstone_wire replace
fill ~156 ~161 ~742 ~158 ~161 ~742 minecraft:redstone_wire replace
fill ~159 ~161 ~750 ~161 ~161 ~750 minecraft:redstone_wire replace
fill ~162 ~161 ~754 ~164 ~161 ~754 minecraft:redstone_wire replace
fill ~165 ~161 ~758 ~167 ~161 ~758 minecraft:redstone_wire replace
fill ~129 ~161 ~762 ~131 ~161 ~762 minecraft:redstone_wire replace
fill ~132 ~161 ~794 ~134 ~161 ~794 minecraft:redstone_wire replace
fill ~135 ~161 ~826 ~137 ~161 ~826 minecraft:redstone_wire replace
fill ~138 ~161 ~862 ~140 ~161 ~862 minecraft:redstone_wire replace
fill ~141 ~161 ~890 ~143 ~161 ~890 minecraft:redstone_wire replace
fill ~144 ~161 ~906 ~146 ~161 ~906 minecraft:redstone_wire replace
fill ~147 ~161 ~930 ~149 ~161 ~930 minecraft:redstone_wire replace
fill ~174 ~161 ~958 ~176 ~161 ~958 minecraft:redstone_wire replace
fill ~168 ~161 ~962 ~170 ~161 ~962 minecraft:redstone_wire replace
fill ~171 ~161 ~966 ~173 ~161 ~966 minecraft:redstone_wire replace
setblock ~108 ~162 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~84 ~162 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~105 ~162 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~102 ~162 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~99 ~162 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~96 ~162 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~93 ~162 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~90 ~162 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~87 ~162 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~81 ~162 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~111 ~162 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~114 ~162 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~117 ~162 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~120 ~162 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~123 ~162 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~126 ~162 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~129 ~162 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~153 ~162 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~156 ~162 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~159 ~162 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~162 ~162 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~165 ~162 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~168 ~162 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~132 ~162 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~135 ~162 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~138 ~162 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~141 ~162 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~144 ~162 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~147 ~162 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~150 ~162 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~171 ~162 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~174 ~162 ~966 minecraft:redstone_torch[lit=true] replace
setblock ~108 ~164 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~84 ~164 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~105 ~164 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~102 ~164 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~99 ~164 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~96 ~164 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~93 ~164 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~90 ~164 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~87 ~164 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~81 ~164 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~111 ~164 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~114 ~164 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~117 ~164 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~120 ~164 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~123 ~164 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~126 ~164 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~129 ~164 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~153 ~164 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~156 ~164 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~159 ~164 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~162 ~164 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~165 ~164 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~168 ~164 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~132 ~164 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~135 ~164 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~138 ~164 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~141 ~164 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~144 ~164 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~147 ~164 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~150 ~164 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~171 ~164 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~174 ~164 ~966 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~110 ~165 ~230 ~120 ~165 ~230 minecraft:redstone_wire replace
setblock ~121 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~230 ~132 ~165 ~230 minecraft:redstone_wire replace
setblock ~133 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~230 ~144 ~165 ~230 minecraft:redstone_wire replace
setblock ~145 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~230 ~156 ~165 ~230 minecraft:redstone_wire replace
setblock ~157 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~230 ~168 ~165 ~230 minecraft:redstone_wire replace
setblock ~169 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~230 ~180 ~165 ~230 minecraft:redstone_wire replace
setblock ~181 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~230 ~192 ~165 ~230 minecraft:redstone_wire replace
setblock ~193 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~230 ~204 ~165 ~230 minecraft:redstone_wire replace
setblock ~205 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~230 ~216 ~165 ~230 minecraft:redstone_wire replace
setblock ~217 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~230 ~228 ~165 ~230 minecraft:redstone_wire replace
setblock ~229 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~230 ~240 ~165 ~230 minecraft:redstone_wire replace
setblock ~241 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~230 ~252 ~165 ~230 minecraft:redstone_wire replace
setblock ~253 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~230 ~264 ~165 ~230 minecraft:redstone_wire replace
setblock ~265 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~230 ~276 ~165 ~230 minecraft:redstone_wire replace
setblock ~277 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~230 ~288 ~165 ~230 minecraft:redstone_wire replace
setblock ~289 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~230 ~300 ~165 ~230 minecraft:redstone_wire replace
setblock ~301 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~230 ~312 ~165 ~230 minecraft:redstone_wire replace
setblock ~313 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~230 ~324 ~165 ~230 minecraft:redstone_wire replace
setblock ~325 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~230 ~336 ~165 ~230 minecraft:redstone_wire replace
setblock ~337 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~230 ~348 ~165 ~230 minecraft:redstone_wire replace
setblock ~349 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~230 ~360 ~165 ~230 minecraft:redstone_wire replace
setblock ~361 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~230 ~372 ~165 ~230 minecraft:redstone_wire replace
setblock ~373 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~230 ~384 ~165 ~230 minecraft:redstone_wire replace
setblock ~385 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~230 ~396 ~165 ~230 minecraft:redstone_wire replace
setblock ~397 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~230 ~408 ~165 ~230 minecraft:redstone_wire replace
setblock ~409 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~230 ~420 ~165 ~230 minecraft:redstone_wire replace
setblock ~421 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~230 ~432 ~165 ~230 minecraft:redstone_wire replace
setblock ~433 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~230 ~444 ~165 ~230 minecraft:redstone_wire replace
setblock ~445 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~230 ~456 ~165 ~230 minecraft:redstone_wire replace
setblock ~457 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~230 ~468 ~165 ~230 minecraft:redstone_wire replace
setblock ~469 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~230 ~480 ~165 ~230 minecraft:redstone_wire replace
setblock ~481 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~165 ~230 ~492 ~165 ~230 minecraft:redstone_wire replace
setblock ~493 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~165 ~230 ~495 ~165 ~230 minecraft:redstone_wire replace
setblock ~85 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~86 ~165 ~234 ~96 ~165 ~234 minecraft:redstone_wire replace
setblock ~97 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~98 ~165 ~234 ~108 ~165 ~234 minecraft:redstone_wire replace
setblock ~109 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~110 ~165 ~234 ~120 ~165 ~234 minecraft:redstone_wire replace
setblock ~121 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~234 ~132 ~165 ~234 minecraft:redstone_wire replace
setblock ~133 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~234 ~144 ~165 ~234 minecraft:redstone_wire replace
setblock ~145 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~234 ~156 ~165 ~234 minecraft:redstone_wire replace
setblock ~157 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~234 ~168 ~165 ~234 minecraft:redstone_wire replace
setblock ~169 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~234 ~180 ~165 ~234 minecraft:redstone_wire replace
setblock ~181 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~234 ~192 ~165 ~234 minecraft:redstone_wire replace
setblock ~193 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~234 ~204 ~165 ~234 minecraft:redstone_wire replace
setblock ~205 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~234 ~216 ~165 ~234 minecraft:redstone_wire replace
setblock ~217 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~234 ~228 ~165 ~234 minecraft:redstone_wire replace
setblock ~229 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~234 ~240 ~165 ~234 minecraft:redstone_wire replace
setblock ~241 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~234 ~252 ~165 ~234 minecraft:redstone_wire replace
setblock ~253 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~234 ~264 ~165 ~234 minecraft:redstone_wire replace
setblock ~265 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~234 ~276 ~165 ~234 minecraft:redstone_wire replace
setblock ~277 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~234 ~288 ~165 ~234 minecraft:redstone_wire replace
setblock ~289 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~234 ~300 ~165 ~234 minecraft:redstone_wire replace
setblock ~301 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~234 ~312 ~165 ~234 minecraft:redstone_wire replace
setblock ~313 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~234 ~324 ~165 ~234 minecraft:redstone_wire replace
setblock ~325 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~234 ~336 ~165 ~234 minecraft:redstone_wire replace
setblock ~337 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~234 ~348 ~165 ~234 minecraft:redstone_wire replace
setblock ~349 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~234 ~360 ~165 ~234 minecraft:redstone_wire replace
setblock ~361 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~234 ~372 ~165 ~234 minecraft:redstone_wire replace
setblock ~373 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~234 ~384 ~165 ~234 minecraft:redstone_wire replace
setblock ~385 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~234 ~396 ~165 ~234 minecraft:redstone_wire replace
setblock ~397 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~234 ~408 ~165 ~234 minecraft:redstone_wire replace
setblock ~409 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~234 ~420 ~165 ~234 minecraft:redstone_wire replace
setblock ~421 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~234 ~432 ~165 ~234 minecraft:redstone_wire replace
setblock ~433 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~234 ~444 ~165 ~234 minecraft:redstone_wire replace
setblock ~445 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~234 ~456 ~165 ~234 minecraft:redstone_wire replace
setblock ~457 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~234 ~468 ~165 ~234 minecraft:redstone_wire replace
setblock ~469 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~234 ~480 ~165 ~234 minecraft:redstone_wire replace
setblock ~481 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~165 ~234 ~492 ~165 ~234 minecraft:redstone_wire replace
setblock ~493 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~165 ~234 ~497 ~165 ~234 minecraft:redstone_wire replace
setblock ~106 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~107 ~165 ~262 ~117 ~165 ~262 minecraft:redstone_wire replace
setblock ~118 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~262 ~129 ~165 ~262 minecraft:redstone_wire replace
setblock ~130 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~262 ~141 ~165 ~262 minecraft:redstone_wire replace
setblock ~142 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~262 ~153 ~165 ~262 minecraft:redstone_wire replace
setblock ~154 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~262 ~165 ~165 ~262 minecraft:redstone_wire replace
setblock ~166 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~262 ~177 ~165 ~262 minecraft:redstone_wire replace
setblock ~178 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~262 ~189 ~165 ~262 minecraft:redstone_wire replace
setblock ~190 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~262 ~201 ~165 ~262 minecraft:redstone_wire replace
setblock ~202 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~262 ~213 ~165 ~262 minecraft:redstone_wire replace
setblock ~214 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~262 ~225 ~165 ~262 minecraft:redstone_wire replace
setblock ~226 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~262 ~237 ~165 ~262 minecraft:redstone_wire replace
setblock ~238 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~262 ~249 ~165 ~262 minecraft:redstone_wire replace
setblock ~250 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~262 ~261 ~165 ~262 minecraft:redstone_wire replace
setblock ~262 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~262 ~273 ~165 ~262 minecraft:redstone_wire replace
setblock ~274 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~262 ~285 ~165 ~262 minecraft:redstone_wire replace
setblock ~286 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~262 ~297 ~165 ~262 minecraft:redstone_wire replace
setblock ~298 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~262 ~309 ~165 ~262 minecraft:redstone_wire replace
setblock ~310 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~262 ~321 ~165 ~262 minecraft:redstone_wire replace
setblock ~322 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~262 ~333 ~165 ~262 minecraft:redstone_wire replace
setblock ~334 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~262 ~345 ~165 ~262 minecraft:redstone_wire replace
setblock ~346 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~262 ~357 ~165 ~262 minecraft:redstone_wire replace
setblock ~358 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~262 ~369 ~165 ~262 minecraft:redstone_wire replace
setblock ~370 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~262 ~381 ~165 ~262 minecraft:redstone_wire replace
setblock ~382 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~262 ~393 ~165 ~262 minecraft:redstone_wire replace
setblock ~394 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~262 ~405 ~165 ~262 minecraft:redstone_wire replace
setblock ~406 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~262 ~417 ~165 ~262 minecraft:redstone_wire replace
setblock ~418 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~262 ~429 ~165 ~262 minecraft:redstone_wire replace
setblock ~430 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~262 ~441 ~165 ~262 minecraft:redstone_wire replace
setblock ~442 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~262 ~453 ~165 ~262 minecraft:redstone_wire replace
setblock ~454 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~262 ~465 ~165 ~262 minecraft:redstone_wire replace
setblock ~466 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~262 ~477 ~165 ~262 minecraft:redstone_wire replace
setblock ~478 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~479 ~165 ~262 ~481 ~165 ~262 minecraft:redstone_wire replace
setblock ~103 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~104 ~165 ~286 ~114 ~165 ~286 minecraft:redstone_wire replace
setblock ~115 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~116 ~165 ~286 ~126 ~165 ~286 minecraft:redstone_wire replace
setblock ~127 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~286 ~138 ~165 ~286 minecraft:redstone_wire replace
setblock ~139 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~286 ~150 ~165 ~286 minecraft:redstone_wire replace
setblock ~151 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~286 ~162 ~165 ~286 minecraft:redstone_wire replace
setblock ~163 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~286 ~174 ~165 ~286 minecraft:redstone_wire replace
setblock ~175 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~286 ~186 ~165 ~286 minecraft:redstone_wire replace
setblock ~187 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~286 ~198 ~165 ~286 minecraft:redstone_wire replace
setblock ~199 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~286 ~210 ~165 ~286 minecraft:redstone_wire replace
setblock ~211 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~286 ~222 ~165 ~286 minecraft:redstone_wire replace
setblock ~223 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~286 ~234 ~165 ~286 minecraft:redstone_wire replace
setblock ~235 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~286 ~246 ~165 ~286 minecraft:redstone_wire replace
setblock ~247 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~286 ~258 ~165 ~286 minecraft:redstone_wire replace
setblock ~259 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~286 ~270 ~165 ~286 minecraft:redstone_wire replace
setblock ~271 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~286 ~282 ~165 ~286 minecraft:redstone_wire replace
setblock ~283 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~286 ~294 ~165 ~286 minecraft:redstone_wire replace
setblock ~295 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~286 ~306 ~165 ~286 minecraft:redstone_wire replace
setblock ~307 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~286 ~318 ~165 ~286 minecraft:redstone_wire replace
setblock ~319 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~286 ~330 ~165 ~286 minecraft:redstone_wire replace
setblock ~331 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~286 ~342 ~165 ~286 minecraft:redstone_wire replace
setblock ~343 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~286 ~354 ~165 ~286 minecraft:redstone_wire replace
setblock ~355 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~286 ~366 ~165 ~286 minecraft:redstone_wire replace
setblock ~367 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~286 ~378 ~165 ~286 minecraft:redstone_wire replace
setblock ~379 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~286 ~390 ~165 ~286 minecraft:redstone_wire replace
setblock ~391 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~286 ~402 ~165 ~286 minecraft:redstone_wire replace
setblock ~403 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~286 ~414 ~165 ~286 minecraft:redstone_wire replace
setblock ~415 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~286 ~426 ~165 ~286 minecraft:redstone_wire replace
setblock ~427 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~286 ~438 ~165 ~286 minecraft:redstone_wire replace
setblock ~439 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~286 ~450 ~165 ~286 minecraft:redstone_wire replace
setblock ~451 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~286 ~462 ~165 ~286 minecraft:redstone_wire replace
setblock ~463 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
