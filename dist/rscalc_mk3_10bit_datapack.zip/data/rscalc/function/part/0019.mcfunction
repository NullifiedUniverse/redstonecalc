setblock ~246 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~121 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~121 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~127 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~127 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~129 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~129 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~131 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~131 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~131 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~137 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~137 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~143 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~143 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~145 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~145 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~147 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~147 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~147 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~153 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~153 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~159 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~159 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~161 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~161 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~163 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~163 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~163 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~169 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~169 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~175 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~175 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~177 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~177 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~179 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~179 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~179 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~185 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~185 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~191 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~191 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~193 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~193 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~195 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~195 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~195 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~201 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~201 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~207 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~207 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~209 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~209 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~211 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~211 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~211 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~217 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~217 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~223 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~223 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~225 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~225 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~227 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~227 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~227 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~233 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~233 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~239 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~239 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~241 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~241 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~243 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~243 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~243 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~249 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~249 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~249 minecraft:light_gray_concrete replace
setblock ~123 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~123 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~123 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~252 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~257 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~257 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~257 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~153 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~252 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~94 ~39 ~264 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~252 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~126 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~126 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~271 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~271 minecraft:light_gray_concrete replace
setblock ~94 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~127 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~154 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~273 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~273 minecraft:light_gray_concrete replace
setblock ~96 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~148 ~39 ~276 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~276 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~276 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~120 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~127 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~154 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~120 ~39 ~281 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~281 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~281 minecraft:light_gray_concrete replace
setblock ~150 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~121 ~39 ~284 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~287 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~287 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~289 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~289 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~291 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~291 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~291 minecraft:light_gray_concrete replace
setblock ~121 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~148 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~154 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~156 ~39 ~295 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~295 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~295 minecraft:light_gray_concrete replace
setblock ~178 ~39 ~296 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~296 minecraft:light_gray_concrete replace
setblock ~156 ~39 ~297 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~297 minecraft:light_gray_concrete replace
setblock ~180 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~157 ~39 ~300 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~303 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~303 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~305 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~305 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~307 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~307 minecraft:light_gray_concrete replace
setblock ~157 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~178 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~309 minecraft:light_gray_concrete replace
setblock ~186 ~39 ~311 minecraft:light_gray_concrete replace
setblock ~250 ~39 ~312 minecraft:light_gray_concrete replace
setblock ~186 ~39 ~313 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~313 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~187 ~39 ~316 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~255 ~39 ~319 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~319 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~319 minecraft:light_gray_concrete replace
setblock ~187 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~250 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~321 minecraft:light_gray_concrete replace
setblock ~201 ~39 ~323 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~323 minecraft:light_gray_concrete replace
setblock ~201 ~39 ~325 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~325 minecraft:light_gray_concrete replace
setblock ~222 ~39 ~327 minecraft:light_gray_concrete replace
setblock ~202 ~39 ~328 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~329 minecraft:light_gray_concrete replace
setblock ~279 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~335 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~335 minecraft:light_gray_concrete replace
setblock ~202 ~39 ~336 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~337 minecraft:light_gray_concrete replace
setblock ~225 ~39 ~339 minecraft:light_gray_concrete replace
setblock ~259 ~39 ~340 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~340 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~340 minecraft:light_gray_concrete replace
setblock ~225 ~39 ~341 minecraft:light_gray_concrete replace
setblock ~261 ~39 ~343 minecraft:light_gray_concrete replace
setblock ~226 ~39 ~344 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~345 minecraft:light_gray_concrete replace
setblock ~297 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~351 minecraft:light_gray_concrete replace
setblock ~226 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~259 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~264 ~39 ~355 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~356 minecraft:light_gray_concrete replace
setblock ~334 ~39 ~356 minecraft:light_gray_concrete replace
setblock ~264 ~39 ~357 minecraft:light_gray_concrete replace
setblock ~321 ~39 ~359 minecraft:light_gray_concrete replace
setblock ~265 ~39 ~360 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~361 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~363 minecraft:light_gray_concrete replace
setblock ~336 ~39 ~363 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~363 minecraft:light_gray_concrete replace
setblock ~265 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~334 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~336 ~39 ~365 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~365 minecraft:light_gray_concrete replace
setblock ~339 ~39 ~367 minecraft:light_gray_concrete replace
setblock ~325 ~39 ~368 minecraft:light_gray_concrete replace
setblock ~339 ~39 ~369 minecraft:light_gray_concrete replace
setblock ~312 ~39 ~371 minecraft:light_gray_concrete replace
setblock ~339 ~39 ~371 minecraft:light_gray_concrete replace
setblock ~327 ~39 ~375 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~325 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~340 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~379 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~381 minecraft:light_gray_concrete replace
setblock ~285 ~39 ~383 minecraft:light_gray_concrete replace
setblock ~340 ~39 ~384 minecraft:light_gray_concrete replace
setblock ~285 ~39 ~385 minecraft:light_gray_concrete replace
setblock ~363 ~39 ~387 minecraft:light_gray_concrete replace
setblock ~286 ~39 ~388 minecraft:light_gray_concrete replace
setblock ~384 ~39 ~391 minecraft:light_gray_concrete replace
setblock ~286 ~39 ~392 minecraft:light_gray_concrete replace
setblock ~384 ~39 ~393 minecraft:light_gray_concrete replace
setblock ~351 ~39 ~395 minecraft:light_gray_concrete replace
setblock ~349 ~39 ~396 minecraft:light_gray_concrete replace
setblock ~351 ~39 ~397 minecraft:light_gray_concrete replace
setblock ~375 ~39 ~399 minecraft:light_gray_concrete replace
setblock ~375 ~39 ~401 minecraft:light_gray_concrete replace
setblock ~345 ~39 ~403 minecraft:light_gray_concrete replace
setblock ~349 ~39 ~408 minecraft:light_gray_concrete replace
setblock ~376 ~39 ~408 minecraft:light_gray_concrete replace
setblock ~90 ~39 ~411 minecraft:light_gray_concrete replace
setblock ~376 ~39 ~412 minecraft:light_gray_concrete replace
setblock ~117 ~39 ~415 minecraft:light_gray_concrete replace
setblock ~144 ~39 ~419 minecraft:light_gray_concrete replace
setblock ~192 ~39 ~423 minecraft:light_gray_concrete replace
setblock ~213 ~39 ~427 minecraft:light_gray_concrete replace
setblock ~237 ~39 ~431 minecraft:light_gray_concrete replace
setblock ~282 ~39 ~435 minecraft:light_gray_concrete replace
setblock ~306 ~39 ~439 minecraft:light_gray_concrete replace
setblock ~342 ~39 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~39 ~447 minecraft:light_gray_concrete replace
setblock ~114 ~39 ~451 minecraft:light_gray_concrete replace
setblock ~141 ~39 ~455 minecraft:light_gray_concrete replace
setblock ~189 ~39 ~459 minecraft:light_gray_concrete replace
setblock ~210 ~39 ~463 minecraft:light_gray_concrete replace
setblock ~234 ~39 ~467 minecraft:light_gray_concrete replace
setblock ~276 ~39 ~471 minecraft:light_gray_concrete replace
setblock ~303 ~39 ~475 minecraft:light_gray_concrete replace
setblock ~366 ~39 ~479 minecraft:light_gray_concrete replace
setblock ~390 ~39 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~39 ~487 minecraft:light_gray_concrete replace
setblock ~111 ~39 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~39 ~495 minecraft:light_gray_concrete replace
setblock ~171 ~39 ~499 minecraft:light_gray_concrete replace
setblock ~207 ~39 ~503 minecraft:light_gray_concrete replace
setblock ~231 ~39 ~507 minecraft:light_gray_concrete replace
setblock ~273 ~39 ~511 minecraft:light_gray_concrete replace
setblock ~300 ~39 ~515 minecraft:light_gray_concrete replace
setblock ~360 ~39 ~519 minecraft:light_gray_concrete replace
setblock ~387 ~39 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~39 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~39 ~531 minecraft:light_gray_concrete replace
setblock ~135 ~39 ~535 minecraft:light_gray_concrete replace
setblock ~165 ~39 ~539 minecraft:light_gray_concrete replace
setblock ~204 ~39 ~543 minecraft:light_gray_concrete replace
setblock ~228 ~39 ~547 minecraft:light_gray_concrete replace
setblock ~270 ~39 ~551 minecraft:light_gray_concrete replace
setblock ~291 ~39 ~555 minecraft:light_gray_concrete replace
setblock ~357 ~39 ~559 minecraft:light_gray_concrete replace
setblock ~381 ~39 ~563 minecraft:light_gray_concrete replace
setblock ~78 ~39 ~567 minecraft:light_gray_concrete replace
setblock ~105 ~39 ~571 minecraft:light_gray_concrete replace
setblock ~132 ~39 ~575 minecraft:light_gray_concrete replace
setblock ~162 ~39 ~579 minecraft:light_gray_concrete replace
setblock ~198 ~39 ~583 minecraft:light_gray_concrete replace
setblock ~219 ~39 ~587 minecraft:light_gray_concrete replace
setblock ~267 ~39 ~591 minecraft:light_gray_concrete replace
setblock ~288 ~39 ~595 minecraft:light_gray_concrete replace
setblock ~354 ~39 ~599 minecraft:light_gray_concrete replace
setblock ~378 ~39 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~39 ~607 minecraft:light_gray_concrete replace
setblock ~129 ~39 ~611 minecraft:light_gray_concrete replace
setblock ~159 ~39 ~615 minecraft:light_gray_concrete replace
setblock ~195 ~39 ~619 minecraft:light_gray_concrete replace
setblock ~216 ~39 ~623 minecraft:light_gray_concrete replace
setblock ~240 ~39 ~627 minecraft:light_gray_concrete replace
setblock ~294 ~39 ~631 minecraft:light_gray_concrete replace
setblock ~309 ~39 ~635 minecraft:light_gray_concrete replace
setblock ~369 ~39 ~639 minecraft:light_gray_concrete replace
setblock ~168 ~39 ~643 minecraft:light_gray_concrete replace
setblock ~396 ~39 ~647 minecraft:light_gray_concrete replace
setblock ~99 ~39 ~651 minecraft:light_gray_concrete replace
setblock ~372 ~39 ~655 minecraft:light_gray_concrete replace
setblock ~393 ~39 ~659 minecraft:light_gray_concrete replace
fill ~226 ~40 ~0 ~226 ~40 ~1 minecraft:light_gray_concrete replace
fill ~225 ~40 ~2 ~243 ~40 ~2 minecraft:light_gray_concrete replace
fill ~166 ~40 ~4 ~166 ~40 ~5 minecraft:light_gray_concrete replace
fill ~165 ~40 ~6 ~174 ~40 ~6 minecraft:light_gray_concrete replace
fill ~145 ~40 ~8 ~145 ~40 ~9 minecraft:light_gray_concrete replace
fill ~144 ~40 ~10 ~147 ~40 ~10 minecraft:light_gray_concrete replace
fill ~226 ~40 ~12 ~226 ~40 ~13 minecraft:light_gray_concrete replace
fill ~225 ~40 ~14 ~246 ~40 ~14 minecraft:light_gray_concrete replace
fill ~166 ~40 ~16 ~166 ~40 ~17 minecraft:light_gray_concrete replace
fill ~165 ~40 ~18 ~177 ~40 ~18 minecraft:light_gray_concrete replace
fill ~226 ~40 ~24 ~226 ~40 ~25 minecraft:light_gray_concrete replace
fill ~225 ~40 ~26 ~249 ~40 ~26 minecraft:light_gray_concrete replace
fill ~301 ~40 ~32 ~301 ~40 ~33 minecraft:light_gray_concrete replace
fill ~300 ~40 ~34 ~330 ~40 ~34 minecraft:light_gray_concrete replace
fill ~286 ~40 ~36 ~286 ~40 ~37 minecraft:light_gray_concrete replace
fill ~285 ~40 ~38 ~315 ~40 ~38 minecraft:light_gray_concrete replace
fill ~229 ~40 ~40 ~229 ~40 ~41 minecraft:light_gray_concrete replace
fill ~228 ~40 ~42 ~258 ~40 ~42 minecraft:light_gray_concrete replace
fill ~304 ~40 ~44 ~304 ~40 ~45 minecraft:light_gray_concrete replace
fill ~303 ~40 ~46 ~333 ~40 ~46 minecraft:light_gray_concrete replace
fill ~289 ~40 ~48 ~289 ~40 ~49 minecraft:light_gray_concrete replace
fill ~288 ~40 ~50 ~318 ~40 ~50 minecraft:light_gray_concrete replace
fill ~295 ~40 ~56 ~295 ~40 ~57 minecraft:light_gray_concrete replace
fill ~294 ~40 ~58 ~324 ~40 ~58 minecraft:light_gray_concrete replace
fill ~319 ~40 ~72 ~319 ~40 ~73 minecraft:light_gray_concrete replace
fill ~318 ~40 ~74 ~348 ~40 ~74 minecraft:light_gray_concrete replace
fill ~94 ~40 ~244 ~94 ~40 ~245 minecraft:light_gray_concrete replace
fill ~93 ~40 ~246 ~95 ~40 ~246 minecraft:light_gray_concrete replace
fill ~124 ~40 ~248 ~124 ~40 ~249 minecraft:light_gray_concrete replace
fill ~123 ~40 ~250 ~125 ~40 ~250 minecraft:light_gray_concrete replace
fill ~226 ~40 ~252 ~226 ~40 ~253 minecraft:light_gray_concrete replace
fill ~225 ~40 ~254 ~252 ~40 ~254 minecraft:light_gray_concrete replace
fill ~166 ~40 ~256 ~166 ~40 ~257 minecraft:light_gray_concrete replace
fill ~165 ~40 ~258 ~183 ~40 ~258 minecraft:light_gray_concrete replace
fill ~145 ~40 ~260 ~145 ~40 ~261 minecraft:light_gray_concrete replace
fill ~144 ~40 ~262 ~153 ~40 ~262 minecraft:light_gray_concrete replace
fill ~124 ~40 ~264 ~124 ~40 ~265 minecraft:light_gray_concrete replace
fill ~123 ~40 ~266 ~126 ~40 ~266 minecraft:light_gray_concrete replace
fill ~97 ~40 ~272 ~97 ~40 ~273 minecraft:light_gray_concrete replace
fill ~96 ~40 ~274 ~98 ~40 ~274 minecraft:light_gray_concrete replace
fill ~121 ~40 ~276 ~121 ~40 ~277 minecraft:light_gray_concrete replace
fill ~120 ~40 ~278 ~122 ~40 ~278 minecraft:light_gray_concrete replace
fill ~145 ~40 ~280 ~145 ~40 ~281 minecraft:light_gray_concrete replace
fill ~144 ~40 ~282 ~150 ~40 ~282 minecraft:light_gray_concrete replace
fill ~148 ~40 ~292 ~148 ~40 ~293 minecraft:light_gray_concrete replace
fill ~147 ~40 ~294 ~156 ~40 ~294 minecraft:light_gray_concrete replace
fill ~166 ~40 ~296 ~166 ~40 ~297 minecraft:light_gray_concrete replace
fill ~165 ~40 ~298 ~180 ~40 ~298 minecraft:light_gray_concrete replace
fill ~169 ~40 ~308 ~169 ~40 ~309 minecraft:light_gray_concrete replace
fill ~168 ~40 ~310 ~186 ~40 ~310 minecraft:light_gray_concrete replace
fill ~226 ~40 ~316 ~226 ~40 ~317 minecraft:light_gray_concrete replace
fill ~225 ~40 ~318 ~255 ~40 ~318 minecraft:light_gray_concrete replace
fill ~184 ~40 ~320 ~184 ~40 ~321 minecraft:light_gray_concrete replace
fill ~183 ~40 ~322 ~201 ~40 ~322 minecraft:light_gray_concrete replace
fill ~205 ~40 ~324 ~205 ~40 ~325 minecraft:light_gray_concrete replace
fill ~204 ~40 ~326 ~222 ~40 ~326 minecraft:light_gray_concrete replace
fill ~250 ~40 ~328 ~250 ~40 ~329 minecraft:light_gray_concrete replace
fill ~249 ~40 ~330 ~279 ~40 ~330 minecraft:light_gray_concrete replace
fill ~208 ~40 ~336 ~208 ~40 ~337 minecraft:light_gray_concrete replace
fill ~207 ~40 ~338 ~225 ~40 ~338 minecraft:light_gray_concrete replace
fill ~232 ~40 ~340 ~232 ~40 ~341 minecraft:light_gray_concrete replace
fill ~231 ~40 ~342 ~261 ~40 ~342 minecraft:light_gray_concrete replace
fill ~268 ~40 ~344 ~268 ~40 ~345 minecraft:light_gray_concrete replace
fill ~267 ~40 ~346 ~297 ~40 ~346 minecraft:light_gray_concrete replace
fill ~235 ~40 ~352 ~235 ~40 ~353 minecraft:light_gray_concrete replace
fill ~234 ~40 ~354 ~264 ~40 ~354 minecraft:light_gray_concrete replace
fill ~292 ~40 ~356 ~292 ~40 ~357 minecraft:light_gray_concrete replace
fill ~291 ~40 ~358 ~321 ~40 ~358 minecraft:light_gray_concrete replace
