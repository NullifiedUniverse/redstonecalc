fill ~315 ~27 ~176 ~315 ~27 ~188 minecraft:redstone_wire replace
fill ~342 ~27 ~176 ~342 ~27 ~188 minecraft:redstone_wire replace
setblock ~78 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~180 ~78 ~27 ~192 minecraft:redstone_wire replace
fill ~81 ~27 ~180 ~81 ~27 ~192 minecraft:redstone_wire replace
fill ~117 ~27 ~180 ~117 ~27 ~192 minecraft:redstone_wire replace
fill ~129 ~27 ~180 ~129 ~27 ~192 minecraft:redstone_wire replace
fill ~132 ~27 ~180 ~132 ~27 ~192 minecraft:redstone_wire replace
fill ~135 ~27 ~180 ~135 ~27 ~192 minecraft:redstone_wire replace
fill ~165 ~27 ~180 ~165 ~27 ~192 minecraft:redstone_wire replace
fill ~186 ~27 ~180 ~186 ~27 ~192 minecraft:redstone_wire replace
fill ~192 ~27 ~180 ~192 ~27 ~192 minecraft:redstone_wire replace
fill ~219 ~27 ~180 ~219 ~27 ~192 minecraft:redstone_wire replace
fill ~240 ~27 ~180 ~240 ~27 ~192 minecraft:redstone_wire replace
fill ~264 ~27 ~180 ~264 ~27 ~192 minecraft:redstone_wire replace
setblock ~84 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~184 ~84 ~27 ~196 minecraft:redstone_wire replace
fill ~96 ~27 ~184 ~96 ~27 ~196 minecraft:redstone_wire replace
fill ~102 ~27 ~184 ~102 ~27 ~196 minecraft:redstone_wire replace
fill ~111 ~27 ~184 ~111 ~27 ~196 minecraft:redstone_wire replace
fill ~141 ~27 ~184 ~141 ~27 ~196 minecraft:redstone_wire replace
fill ~156 ~27 ~184 ~156 ~27 ~196 minecraft:redstone_wire replace
fill ~159 ~27 ~184 ~159 ~27 ~196 minecraft:redstone_wire replace
fill ~168 ~27 ~184 ~168 ~27 ~196 minecraft:redstone_wire replace
fill ~171 ~27 ~184 ~171 ~27 ~196 minecraft:redstone_wire replace
fill ~195 ~27 ~184 ~195 ~27 ~196 minecraft:redstone_wire replace
fill ~201 ~27 ~184 ~201 ~27 ~196 minecraft:redstone_wire replace
fill ~222 ~27 ~184 ~222 ~27 ~196 minecraft:redstone_wire replace
fill ~234 ~27 ~184 ~234 ~27 ~196 minecraft:redstone_wire replace
fill ~291 ~27 ~184 ~291 ~27 ~196 minecraft:redstone_wire replace
fill ~312 ~27 ~184 ~312 ~27 ~196 minecraft:redstone_wire replace
fill ~336 ~27 ~184 ~336 ~27 ~196 minecraft:redstone_wire replace
setblock ~87 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~188 ~87 ~27 ~200 minecraft:redstone_wire replace
fill ~99 ~27 ~188 ~99 ~27 ~200 minecraft:redstone_wire replace
fill ~105 ~27 ~188 ~105 ~27 ~200 minecraft:redstone_wire replace
fill ~120 ~27 ~188 ~120 ~27 ~200 minecraft:redstone_wire replace
fill ~144 ~27 ~188 ~144 ~27 ~200 minecraft:redstone_wire replace
fill ~180 ~27 ~188 ~180 ~27 ~200 minecraft:redstone_wire replace
fill ~183 ~27 ~188 ~183 ~27 ~200 minecraft:redstone_wire replace
fill ~204 ~27 ~188 ~204 ~27 ~200 minecraft:redstone_wire replace
fill ~210 ~27 ~188 ~210 ~27 ~200 minecraft:redstone_wire replace
fill ~213 ~27 ~188 ~213 ~27 ~200 minecraft:redstone_wire replace
fill ~228 ~27 ~188 ~228 ~27 ~200 minecraft:redstone_wire replace
fill ~231 ~27 ~188 ~231 ~27 ~200 minecraft:redstone_wire replace
fill ~252 ~27 ~188 ~252 ~27 ~200 minecraft:redstone_wire replace
fill ~255 ~27 ~188 ~255 ~27 ~200 minecraft:redstone_wire replace
fill ~261 ~27 ~188 ~261 ~27 ~200 minecraft:redstone_wire replace
fill ~270 ~27 ~188 ~270 ~27 ~200 minecraft:redstone_wire replace
fill ~279 ~27 ~188 ~279 ~27 ~200 minecraft:redstone_wire replace
setblock ~90 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~192 ~90 ~27 ~204 minecraft:redstone_wire replace
fill ~108 ~27 ~192 ~108 ~27 ~204 minecraft:redstone_wire replace
fill ~114 ~27 ~192 ~114 ~27 ~204 minecraft:redstone_wire replace
fill ~123 ~27 ~192 ~123 ~27 ~204 minecraft:redstone_wire replace
fill ~138 ~27 ~192 ~138 ~27 ~204 minecraft:redstone_wire replace
fill ~150 ~27 ~192 ~150 ~27 ~204 minecraft:redstone_wire replace
fill ~174 ~27 ~192 ~174 ~27 ~204 minecraft:redstone_wire replace
fill ~189 ~27 ~192 ~189 ~27 ~204 minecraft:redstone_wire replace
fill ~198 ~27 ~192 ~198 ~27 ~204 minecraft:redstone_wire replace
fill ~216 ~27 ~192 ~216 ~27 ~204 minecraft:redstone_wire replace
fill ~237 ~27 ~192 ~237 ~27 ~204 minecraft:redstone_wire replace
fill ~243 ~27 ~192 ~243 ~27 ~204 minecraft:redstone_wire replace
fill ~315 ~27 ~192 ~315 ~27 ~204 minecraft:redstone_wire replace
fill ~342 ~27 ~192 ~342 ~27 ~204 minecraft:redstone_wire replace
setblock ~78 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~196 ~78 ~27 ~208 minecraft:redstone_wire replace
fill ~81 ~27 ~196 ~81 ~27 ~208 minecraft:redstone_wire replace
fill ~117 ~27 ~196 ~117 ~27 ~208 minecraft:redstone_wire replace
fill ~129 ~27 ~196 ~129 ~27 ~208 minecraft:redstone_wire replace
fill ~132 ~27 ~196 ~132 ~27 ~208 minecraft:redstone_wire replace
fill ~135 ~27 ~196 ~135 ~27 ~208 minecraft:redstone_wire replace
fill ~165 ~27 ~196 ~165 ~27 ~208 minecraft:redstone_wire replace
fill ~186 ~27 ~196 ~186 ~27 ~208 minecraft:redstone_wire replace
fill ~192 ~27 ~196 ~192 ~27 ~208 minecraft:redstone_wire replace
fill ~219 ~27 ~196 ~219 ~27 ~208 minecraft:redstone_wire replace
fill ~240 ~27 ~196 ~240 ~27 ~208 minecraft:redstone_wire replace
fill ~246 ~27 ~196 ~246 ~27 ~208 minecraft:redstone_wire replace
fill ~264 ~27 ~196 ~264 ~27 ~208 minecraft:redstone_wire replace
setblock ~84 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~200 ~84 ~27 ~212 minecraft:redstone_wire replace
fill ~96 ~27 ~200 ~96 ~27 ~212 minecraft:redstone_wire replace
fill ~102 ~27 ~200 ~102 ~27 ~212 minecraft:redstone_wire replace
fill ~111 ~27 ~200 ~111 ~27 ~212 minecraft:redstone_wire replace
fill ~141 ~27 ~200 ~141 ~27 ~212 minecraft:redstone_wire replace
fill ~156 ~27 ~200 ~156 ~27 ~212 minecraft:redstone_wire replace
fill ~159 ~27 ~200 ~159 ~27 ~212 minecraft:redstone_wire replace
fill ~168 ~27 ~200 ~168 ~27 ~212 minecraft:redstone_wire replace
fill ~171 ~27 ~200 ~171 ~27 ~212 minecraft:redstone_wire replace
fill ~195 ~27 ~200 ~195 ~27 ~212 minecraft:redstone_wire replace
fill ~201 ~27 ~200 ~201 ~27 ~212 minecraft:redstone_wire replace
fill ~222 ~27 ~200 ~222 ~27 ~212 minecraft:redstone_wire replace
fill ~234 ~27 ~200 ~234 ~27 ~212 minecraft:redstone_wire replace
fill ~258 ~27 ~200 ~258 ~27 ~212 minecraft:redstone_wire replace
fill ~291 ~27 ~200 ~291 ~27 ~212 minecraft:redstone_wire replace
fill ~312 ~27 ~200 ~312 ~27 ~212 minecraft:redstone_wire replace
fill ~336 ~27 ~200 ~336 ~27 ~212 minecraft:redstone_wire replace
setblock ~87 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~204 ~87 ~27 ~216 minecraft:redstone_wire replace
fill ~99 ~27 ~204 ~99 ~27 ~216 minecraft:redstone_wire replace
fill ~105 ~27 ~204 ~105 ~27 ~216 minecraft:redstone_wire replace
fill ~120 ~27 ~204 ~120 ~27 ~216 minecraft:redstone_wire replace
fill ~144 ~27 ~204 ~144 ~27 ~216 minecraft:redstone_wire replace
fill ~180 ~27 ~204 ~180 ~27 ~216 minecraft:redstone_wire replace
fill ~183 ~27 ~204 ~183 ~27 ~216 minecraft:redstone_wire replace
fill ~204 ~27 ~204 ~204 ~27 ~216 minecraft:redstone_wire replace
fill ~210 ~27 ~204 ~210 ~27 ~216 minecraft:redstone_wire replace
fill ~213 ~27 ~204 ~213 ~27 ~216 minecraft:redstone_wire replace
fill ~228 ~27 ~204 ~228 ~27 ~216 minecraft:redstone_wire replace
fill ~231 ~27 ~204 ~231 ~27 ~216 minecraft:redstone_wire replace
fill ~252 ~27 ~204 ~252 ~27 ~216 minecraft:redstone_wire replace
fill ~255 ~27 ~204 ~255 ~27 ~216 minecraft:redstone_wire replace
fill ~261 ~27 ~204 ~261 ~27 ~216 minecraft:redstone_wire replace
fill ~270 ~27 ~204 ~270 ~27 ~216 minecraft:redstone_wire replace
fill ~279 ~27 ~204 ~279 ~27 ~216 minecraft:redstone_wire replace
fill ~285 ~27 ~204 ~285 ~27 ~216 minecraft:redstone_wire replace
fill ~288 ~27 ~204 ~288 ~27 ~216 minecraft:redstone_wire replace
setblock ~90 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~208 ~90 ~27 ~220 minecraft:redstone_wire replace
fill ~108 ~27 ~208 ~108 ~27 ~220 minecraft:redstone_wire replace
fill ~114 ~27 ~208 ~114 ~27 ~220 minecraft:redstone_wire replace
fill ~123 ~27 ~208 ~123 ~27 ~220 minecraft:redstone_wire replace
fill ~138 ~27 ~208 ~138 ~27 ~220 minecraft:redstone_wire replace
fill ~150 ~27 ~208 ~150 ~27 ~220 minecraft:redstone_wire replace
fill ~174 ~27 ~208 ~174 ~27 ~220 minecraft:redstone_wire replace
fill ~189 ~27 ~208 ~189 ~27 ~220 minecraft:redstone_wire replace
fill ~198 ~27 ~208 ~198 ~27 ~220 minecraft:redstone_wire replace
fill ~216 ~27 ~208 ~216 ~27 ~220 minecraft:redstone_wire replace
fill ~237 ~27 ~208 ~237 ~27 ~220 minecraft:redstone_wire replace
fill ~243 ~27 ~208 ~243 ~27 ~220 minecraft:redstone_wire replace
fill ~294 ~27 ~208 ~294 ~27 ~220 minecraft:redstone_wire replace
fill ~297 ~27 ~208 ~297 ~27 ~220 minecraft:redstone_wire replace
fill ~315 ~27 ~208 ~315 ~27 ~220 minecraft:redstone_wire replace
fill ~342 ~27 ~208 ~342 ~27 ~220 minecraft:redstone_wire replace
setblock ~78 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~212 ~78 ~27 ~224 minecraft:redstone_wire replace
fill ~81 ~27 ~212 ~81 ~27 ~224 minecraft:redstone_wire replace
fill ~117 ~27 ~212 ~117 ~27 ~224 minecraft:redstone_wire replace
fill ~129 ~27 ~212 ~129 ~27 ~224 minecraft:redstone_wire replace
fill ~132 ~27 ~212 ~132 ~27 ~224 minecraft:redstone_wire replace
fill ~135 ~27 ~212 ~135 ~27 ~224 minecraft:redstone_wire replace
fill ~165 ~27 ~212 ~165 ~27 ~224 minecraft:redstone_wire replace
fill ~186 ~27 ~212 ~186 ~27 ~224 minecraft:redstone_wire replace
fill ~192 ~27 ~212 ~192 ~27 ~224 minecraft:redstone_wire replace
fill ~219 ~27 ~212 ~219 ~27 ~224 minecraft:redstone_wire replace
fill ~240 ~27 ~212 ~240 ~27 ~224 minecraft:redstone_wire replace
fill ~246 ~27 ~212 ~246 ~27 ~224 minecraft:redstone_wire replace
fill ~264 ~27 ~212 ~264 ~27 ~224 minecraft:redstone_wire replace
fill ~318 ~27 ~212 ~318 ~27 ~224 minecraft:redstone_wire replace
setblock ~84 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~216 ~84 ~27 ~228 minecraft:redstone_wire replace
fill ~96 ~27 ~216 ~96 ~27 ~228 minecraft:redstone_wire replace
fill ~102 ~27 ~216 ~102 ~27 ~228 minecraft:redstone_wire replace
fill ~111 ~27 ~216 ~111 ~27 ~228 minecraft:redstone_wire replace
fill ~141 ~27 ~216 ~141 ~27 ~228 minecraft:redstone_wire replace
fill ~156 ~27 ~216 ~156 ~27 ~228 minecraft:redstone_wire replace
fill ~159 ~27 ~216 ~159 ~27 ~228 minecraft:redstone_wire replace
fill ~168 ~27 ~216 ~168 ~27 ~228 minecraft:redstone_wire replace
fill ~171 ~27 ~216 ~171 ~27 ~228 minecraft:redstone_wire replace
fill ~195 ~27 ~216 ~195 ~27 ~228 minecraft:redstone_wire replace
fill ~201 ~27 ~216 ~201 ~27 ~228 minecraft:redstone_wire replace
fill ~222 ~27 ~216 ~222 ~27 ~228 minecraft:redstone_wire replace
fill ~234 ~27 ~216 ~234 ~27 ~228 minecraft:redstone_wire replace
fill ~258 ~27 ~216 ~258 ~27 ~228 minecraft:redstone_wire replace
fill ~291 ~27 ~216 ~291 ~27 ~228 minecraft:redstone_wire replace
fill ~312 ~27 ~216 ~312 ~27 ~228 minecraft:redstone_wire replace
fill ~330 ~27 ~216 ~330 ~27 ~228 minecraft:redstone_wire replace
fill ~336 ~27 ~216 ~336 ~27 ~228 minecraft:redstone_wire replace
setblock ~87 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~220 ~87 ~27 ~232 minecraft:redstone_wire replace
fill ~99 ~27 ~220 ~99 ~27 ~232 minecraft:redstone_wire replace
fill ~105 ~27 ~220 ~105 ~27 ~232 minecraft:redstone_wire replace
fill ~120 ~27 ~220 ~120 ~27 ~232 minecraft:redstone_wire replace
fill ~144 ~27 ~220 ~144 ~27 ~232 minecraft:redstone_wire replace
fill ~180 ~27 ~220 ~180 ~27 ~232 minecraft:redstone_wire replace
fill ~183 ~27 ~220 ~183 ~27 ~232 minecraft:redstone_wire replace
fill ~204 ~27 ~220 ~204 ~27 ~232 minecraft:redstone_wire replace
fill ~210 ~27 ~220 ~210 ~27 ~232 minecraft:redstone_wire replace
fill ~213 ~27 ~220 ~213 ~27 ~232 minecraft:redstone_wire replace
fill ~228 ~27 ~220 ~228 ~27 ~232 minecraft:redstone_wire replace
fill ~231 ~27 ~220 ~231 ~27 ~232 minecraft:redstone_wire replace
fill ~252 ~27 ~220 ~252 ~27 ~232 minecraft:redstone_wire replace
fill ~255 ~27 ~220 ~255 ~27 ~232 minecraft:redstone_wire replace
fill ~261 ~27 ~220 ~261 ~27 ~232 minecraft:redstone_wire replace
fill ~270 ~27 ~220 ~270 ~27 ~232 minecraft:redstone_wire replace
fill ~279 ~27 ~220 ~279 ~27 ~232 minecraft:redstone_wire replace
fill ~285 ~27 ~220 ~285 ~27 ~232 minecraft:redstone_wire replace
fill ~288 ~27 ~220 ~288 ~27 ~232 minecraft:redstone_wire replace
fill ~333 ~27 ~220 ~333 ~27 ~232 minecraft:redstone_wire replace
setblock ~90 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~224 ~90 ~27 ~236 minecraft:redstone_wire replace
fill ~108 ~27 ~224 ~108 ~27 ~236 minecraft:redstone_wire replace
fill ~114 ~27 ~224 ~114 ~27 ~236 minecraft:redstone_wire replace
fill ~123 ~27 ~224 ~123 ~27 ~236 minecraft:redstone_wire replace
fill ~138 ~27 ~224 ~138 ~27 ~236 minecraft:redstone_wire replace
fill ~150 ~27 ~224 ~150 ~27 ~236 minecraft:redstone_wire replace
fill ~174 ~27 ~224 ~174 ~27 ~236 minecraft:redstone_wire replace
fill ~189 ~27 ~224 ~189 ~27 ~236 minecraft:redstone_wire replace
fill ~198 ~27 ~224 ~198 ~27 ~236 minecraft:redstone_wire replace
fill ~216 ~27 ~224 ~216 ~27 ~236 minecraft:redstone_wire replace
fill ~237 ~27 ~224 ~237 ~27 ~236 minecraft:redstone_wire replace
fill ~243 ~27 ~224 ~243 ~27 ~236 minecraft:redstone_wire replace
fill ~267 ~27 ~224 ~267 ~27 ~236 minecraft:redstone_wire replace
fill ~294 ~27 ~224 ~294 ~27 ~236 minecraft:redstone_wire replace
fill ~297 ~27 ~224 ~297 ~27 ~236 minecraft:redstone_wire replace
fill ~315 ~27 ~224 ~315 ~27 ~236 minecraft:redstone_wire replace
fill ~342 ~27 ~224 ~342 ~27 ~236 minecraft:redstone_wire replace
setblock ~78 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~228 ~78 ~27 ~240 minecraft:redstone_wire replace
fill ~81 ~27 ~228 ~81 ~27 ~240 minecraft:redstone_wire replace
fill ~117 ~27 ~228 ~117 ~27 ~240 minecraft:redstone_wire replace
fill ~129 ~27 ~228 ~129 ~27 ~240 minecraft:redstone_wire replace
fill ~132 ~27 ~228 ~132 ~27 ~240 minecraft:redstone_wire replace
fill ~135 ~27 ~228 ~135 ~27 ~240 minecraft:redstone_wire replace
fill ~165 ~27 ~228 ~165 ~27 ~240 minecraft:redstone_wire replace
fill ~186 ~27 ~228 ~186 ~27 ~240 minecraft:redstone_wire replace
fill ~192 ~27 ~228 ~192 ~27 ~240 minecraft:redstone_wire replace
fill ~219 ~27 ~228 ~219 ~27 ~240 minecraft:redstone_wire replace
fill ~240 ~27 ~228 ~240 ~27 ~240 minecraft:redstone_wire replace
fill ~246 ~27 ~228 ~246 ~27 ~240 minecraft:redstone_wire replace
fill ~264 ~27 ~228 ~264 ~27 ~240 minecraft:redstone_wire replace
fill ~273 ~27 ~228 ~273 ~27 ~240 minecraft:redstone_wire replace
fill ~318 ~27 ~228 ~318 ~27 ~240 minecraft:redstone_wire replace
setblock ~84 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~232 ~84 ~27 ~244 minecraft:redstone_wire replace
fill ~96 ~27 ~232 ~96 ~27 ~244 minecraft:redstone_wire replace
fill ~102 ~27 ~232 ~102 ~27 ~244 minecraft:redstone_wire replace
fill ~111 ~27 ~232 ~111 ~27 ~244 minecraft:redstone_wire replace
fill ~141 ~27 ~232 ~141 ~27 ~244 minecraft:redstone_wire replace
fill ~156 ~27 ~232 ~156 ~27 ~244 minecraft:redstone_wire replace
fill ~159 ~27 ~232 ~159 ~27 ~244 minecraft:redstone_wire replace
fill ~168 ~27 ~232 ~168 ~27 ~244 minecraft:redstone_wire replace
fill ~171 ~27 ~232 ~171 ~27 ~244 minecraft:redstone_wire replace
fill ~195 ~27 ~232 ~195 ~27 ~244 minecraft:redstone_wire replace
fill ~201 ~27 ~232 ~201 ~27 ~244 minecraft:redstone_wire replace
fill ~222 ~27 ~232 ~222 ~27 ~244 minecraft:redstone_wire replace
fill ~234 ~27 ~232 ~234 ~27 ~244 minecraft:redstone_wire replace
fill ~258 ~27 ~232 ~258 ~27 ~244 minecraft:redstone_wire replace
fill ~276 ~27 ~232 ~276 ~27 ~244 minecraft:redstone_wire replace
fill ~291 ~27 ~232 ~291 ~27 ~244 minecraft:redstone_wire replace
fill ~312 ~27 ~232 ~312 ~27 ~244 minecraft:redstone_wire replace
fill ~330 ~27 ~232 ~330 ~27 ~244 minecraft:redstone_wire replace
fill ~336 ~27 ~232 ~336 ~27 ~244 minecraft:redstone_wire replace
setblock ~87 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~236 ~87 ~27 ~248 minecraft:redstone_wire replace
fill ~99 ~27 ~236 ~99 ~27 ~248 minecraft:redstone_wire replace
fill ~105 ~27 ~236 ~105 ~27 ~248 minecraft:redstone_wire replace
fill ~120 ~27 ~236 ~120 ~27 ~248 minecraft:redstone_wire replace
fill ~144 ~27 ~236 ~144 ~27 ~248 minecraft:redstone_wire replace
fill ~180 ~27 ~236 ~180 ~27 ~248 minecraft:redstone_wire replace
fill ~183 ~27 ~236 ~183 ~27 ~248 minecraft:redstone_wire replace
fill ~204 ~27 ~236 ~204 ~27 ~248 minecraft:redstone_wire replace
fill ~210 ~27 ~236 ~210 ~27 ~248 minecraft:redstone_wire replace
fill ~213 ~27 ~236 ~213 ~27 ~248 minecraft:redstone_wire replace
fill ~228 ~27 ~236 ~228 ~27 ~248 minecraft:redstone_wire replace
fill ~231 ~27 ~236 ~231 ~27 ~248 minecraft:redstone_wire replace
fill ~252 ~27 ~236 ~252 ~27 ~248 minecraft:redstone_wire replace
fill ~255 ~27 ~236 ~255 ~27 ~248 minecraft:redstone_wire replace
fill ~261 ~27 ~236 ~261 ~27 ~248 minecraft:redstone_wire replace
fill ~270 ~27 ~236 ~270 ~27 ~248 minecraft:redstone_wire replace
fill ~279 ~27 ~236 ~279 ~27 ~248 minecraft:redstone_wire replace
fill ~285 ~27 ~236 ~285 ~27 ~248 minecraft:redstone_wire replace
fill ~288 ~27 ~236 ~288 ~27 ~248 minecraft:redstone_wire replace
fill ~303 ~27 ~236 ~303 ~27 ~248 minecraft:redstone_wire replace
fill ~306 ~27 ~236 ~306 ~27 ~248 minecraft:redstone_wire replace
fill ~333 ~27 ~236 ~333 ~27 ~248 minecraft:redstone_wire replace
setblock ~90 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~240 ~90 ~27 ~252 minecraft:redstone_wire replace
fill ~108 ~27 ~240 ~108 ~27 ~252 minecraft:redstone_wire replace
fill ~114 ~27 ~240 ~114 ~27 ~252 minecraft:redstone_wire replace
fill ~123 ~27 ~240 ~123 ~27 ~252 minecraft:redstone_wire replace
fill ~138 ~27 ~240 ~138 ~27 ~252 minecraft:redstone_wire replace
fill ~150 ~27 ~240 ~150 ~27 ~252 minecraft:redstone_wire replace
fill ~174 ~27 ~240 ~174 ~27 ~252 minecraft:redstone_wire replace
fill ~189 ~27 ~240 ~189 ~27 ~252 minecraft:redstone_wire replace
fill ~198 ~27 ~240 ~198 ~27 ~252 minecraft:redstone_wire replace
fill ~216 ~27 ~240 ~216 ~27 ~252 minecraft:redstone_wire replace
fill ~237 ~27 ~240 ~237 ~27 ~252 minecraft:redstone_wire replace
fill ~243 ~27 ~240 ~243 ~27 ~252 minecraft:redstone_wire replace
fill ~267 ~27 ~240 ~267 ~27 ~252 minecraft:redstone_wire replace
fill ~294 ~27 ~240 ~294 ~27 ~252 minecraft:redstone_wire replace
fill ~297 ~27 ~240 ~297 ~27 ~252 minecraft:redstone_wire replace
fill ~315 ~27 ~240 ~315 ~27 ~252 minecraft:redstone_wire replace
fill ~321 ~27 ~240 ~321 ~27 ~252 minecraft:redstone_wire replace
fill ~324 ~27 ~240 ~324 ~27 ~252 minecraft:redstone_wire replace
fill ~342 ~27 ~240 ~342 ~27 ~252 minecraft:redstone_wire replace
setblock ~78 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~244 ~78 ~27 ~256 minecraft:redstone_wire replace
fill ~81 ~27 ~244 ~81 ~27 ~256 minecraft:redstone_wire replace
fill ~117 ~27 ~244 ~117 ~27 ~256 minecraft:redstone_wire replace
fill ~129 ~27 ~244 ~129 ~27 ~256 minecraft:redstone_wire replace
fill ~132 ~27 ~244 ~132 ~27 ~256 minecraft:redstone_wire replace
fill ~135 ~27 ~244 ~135 ~27 ~256 minecraft:redstone_wire replace
fill ~165 ~27 ~244 ~165 ~27 ~256 minecraft:redstone_wire replace
fill ~186 ~27 ~244 ~186 ~27 ~256 minecraft:redstone_wire replace
fill ~192 ~27 ~244 ~192 ~27 ~256 minecraft:redstone_wire replace
fill ~219 ~27 ~244 ~219 ~27 ~256 minecraft:redstone_wire replace
fill ~240 ~27 ~244 ~240 ~27 ~256 minecraft:redstone_wire replace
fill ~246 ~27 ~244 ~246 ~27 ~256 minecraft:redstone_wire replace
fill ~264 ~27 ~244 ~264 ~27 ~256 minecraft:redstone_wire replace
fill ~273 ~27 ~244 ~273 ~27 ~256 minecraft:redstone_wire replace
fill ~318 ~27 ~244 ~318 ~27 ~256 minecraft:redstone_wire replace
fill ~345 ~27 ~244 ~345 ~27 ~256 minecraft:redstone_wire replace
setblock ~84 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~248 ~84 ~27 ~260 minecraft:redstone_wire replace
fill ~96 ~27 ~248 ~96 ~27 ~260 minecraft:redstone_wire replace
fill ~102 ~27 ~248 ~102 ~27 ~260 minecraft:redstone_wire replace
fill ~111 ~27 ~248 ~111 ~27 ~260 minecraft:redstone_wire replace
fill ~141 ~27 ~248 ~141 ~27 ~260 minecraft:redstone_wire replace
fill ~156 ~27 ~248 ~156 ~27 ~260 minecraft:redstone_wire replace
fill ~159 ~27 ~248 ~159 ~27 ~260 minecraft:redstone_wire replace
fill ~168 ~27 ~248 ~168 ~27 ~260 minecraft:redstone_wire replace
fill ~171 ~27 ~248 ~171 ~27 ~260 minecraft:redstone_wire replace
fill ~195 ~27 ~248 ~195 ~27 ~260 minecraft:redstone_wire replace
fill ~201 ~27 ~248 ~201 ~27 ~260 minecraft:redstone_wire replace
fill ~222 ~27 ~248 ~222 ~27 ~260 minecraft:redstone_wire replace
fill ~234 ~27 ~248 ~234 ~27 ~260 minecraft:redstone_wire replace
fill ~258 ~27 ~248 ~258 ~27 ~260 minecraft:redstone_wire replace
fill ~276 ~27 ~248 ~276 ~27 ~260 minecraft:redstone_wire replace
fill ~291 ~27 ~248 ~291 ~27 ~260 minecraft:redstone_wire replace
fill ~312 ~27 ~248 ~312 ~27 ~260 minecraft:redstone_wire replace
fill ~330 ~27 ~248 ~330 ~27 ~260 minecraft:redstone_wire replace
fill ~336 ~27 ~248 ~336 ~27 ~260 minecraft:redstone_wire replace
fill ~348 ~27 ~248 ~348 ~27 ~260 minecraft:redstone_wire replace
setblock ~87 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~252 ~87 ~27 ~264 minecraft:redstone_wire replace
fill ~99 ~27 ~252 ~99 ~27 ~264 minecraft:redstone_wire replace
fill ~105 ~27 ~252 ~105 ~27 ~264 minecraft:redstone_wire replace
fill ~120 ~27 ~252 ~120 ~27 ~264 minecraft:redstone_wire replace
fill ~144 ~27 ~252 ~144 ~27 ~264 minecraft:redstone_wire replace
fill ~180 ~27 ~252 ~180 ~27 ~264 minecraft:redstone_wire replace
fill ~183 ~27 ~252 ~183 ~27 ~264 minecraft:redstone_wire replace
fill ~204 ~27 ~252 ~204 ~27 ~264 minecraft:redstone_wire replace
fill ~210 ~27 ~252 ~210 ~27 ~264 minecraft:redstone_wire replace
fill ~213 ~27 ~252 ~213 ~27 ~264 minecraft:redstone_wire replace
fill ~228 ~27 ~252 ~228 ~27 ~264 minecraft:redstone_wire replace
fill ~231 ~27 ~252 ~231 ~27 ~264 minecraft:redstone_wire replace
fill ~252 ~27 ~252 ~252 ~27 ~264 minecraft:redstone_wire replace
fill ~255 ~27 ~252 ~255 ~27 ~264 minecraft:redstone_wire replace
fill ~261 ~27 ~252 ~261 ~27 ~264 minecraft:redstone_wire replace
fill ~270 ~27 ~252 ~270 ~27 ~264 minecraft:redstone_wire replace
fill ~279 ~27 ~252 ~279 ~27 ~264 minecraft:redstone_wire replace
fill ~285 ~27 ~252 ~285 ~27 ~264 minecraft:redstone_wire replace
fill ~288 ~27 ~252 ~288 ~27 ~264 minecraft:redstone_wire replace
fill ~303 ~27 ~252 ~303 ~27 ~264 minecraft:redstone_wire replace
fill ~306 ~27 ~252 ~306 ~27 ~264 minecraft:redstone_wire replace
fill ~333 ~27 ~252 ~333 ~27 ~264 minecraft:redstone_wire replace
fill ~351 ~27 ~252 ~351 ~27 ~264 minecraft:redstone_wire replace
setblock ~90 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~256 ~90 ~27 ~268 minecraft:redstone_wire replace
fill ~108 ~27 ~256 ~108 ~27 ~268 minecraft:redstone_wire replace
fill ~114 ~27 ~256 ~114 ~27 ~268 minecraft:redstone_wire replace
fill ~123 ~27 ~256 ~123 ~27 ~268 minecraft:redstone_wire replace
fill ~138 ~27 ~256 ~138 ~27 ~268 minecraft:redstone_wire replace
fill ~147 ~27 ~256 ~147 ~27 ~266 minecraft:redstone_wire replace
fill ~150 ~27 ~256 ~150 ~27 ~268 minecraft:redstone_wire replace
fill ~174 ~27 ~256 ~174 ~27 ~268 minecraft:redstone_wire replace
fill ~189 ~27 ~256 ~189 ~27 ~268 minecraft:redstone_wire replace
fill ~198 ~27 ~256 ~198 ~27 ~268 minecraft:redstone_wire replace
fill ~216 ~27 ~256 ~216 ~27 ~268 minecraft:redstone_wire replace
fill ~237 ~27 ~256 ~237 ~27 ~268 minecraft:redstone_wire replace
fill ~243 ~27 ~256 ~243 ~27 ~268 minecraft:redstone_wire replace
fill ~267 ~27 ~256 ~267 ~27 ~268 minecraft:redstone_wire replace
fill ~294 ~27 ~256 ~294 ~27 ~268 minecraft:redstone_wire replace
fill ~297 ~27 ~256 ~297 ~27 ~268 minecraft:redstone_wire replace
fill ~315 ~27 ~256 ~315 ~27 ~268 minecraft:redstone_wire replace
fill ~321 ~27 ~256 ~321 ~27 ~268 minecraft:redstone_wire replace
fill ~324 ~27 ~256 ~324 ~27 ~268 minecraft:redstone_wire replace
fill ~342 ~27 ~256 ~342 ~27 ~268 minecraft:redstone_wire replace
setblock ~132 ~27 ~257 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~257 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~27 ~258 ~132 ~27 ~260 minecraft:redstone_wire replace
fill ~135 ~27 ~258 ~135 ~27 ~264 minecraft:redstone_wire replace
setblock ~165 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~260 ~78 ~27 ~272 minecraft:redstone_wire replace
fill ~81 ~27 ~260 ~81 ~27 ~272 minecraft:redstone_wire replace
fill ~117 ~27 ~260 ~117 ~27 ~272 minecraft:redstone_wire replace
fill ~129 ~27 ~260 ~129 ~27 ~272 minecraft:redstone_wire replace
fill ~165 ~27 ~260 ~165 ~27 ~272 minecraft:redstone_wire replace
fill ~186 ~27 ~260 ~186 ~27 ~272 minecraft:redstone_wire replace
fill ~192 ~27 ~260 ~192 ~27 ~272 minecraft:redstone_wire replace
fill ~219 ~27 ~260 ~219 ~27 ~272 minecraft:redstone_wire replace
fill ~240 ~27 ~260 ~240 ~27 ~272 minecraft:redstone_wire replace
fill ~246 ~27 ~260 ~246 ~27 ~272 minecraft:redstone_wire replace
fill ~264 ~27 ~260 ~264 ~27 ~272 minecraft:redstone_wire replace
fill ~273 ~27 ~260 ~273 ~27 ~272 minecraft:redstone_wire replace
fill ~318 ~27 ~260 ~318 ~27 ~272 minecraft:redstone_wire replace
fill ~339 ~27 ~260 ~339 ~27 ~272 minecraft:redstone_wire replace
fill ~345 ~27 ~260 ~345 ~27 ~272 minecraft:redstone_wire replace
setblock ~111 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~262 ~111 ~27 ~274 minecraft:redstone_wire replace
setblock ~141 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~262 ~171 ~27 ~274 minecraft:redstone_wire replace
setblock ~195 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~262 ~234 ~27 ~274 minecraft:redstone_wire replace
setblock ~258 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~262 ~312 ~27 ~274 minecraft:redstone_wire replace
setblock ~330 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~264 ~84 ~27 ~276 minecraft:redstone_wire replace
fill ~96 ~27 ~264 ~96 ~27 ~276 minecraft:redstone_wire replace
fill ~102 ~27 ~264 ~102 ~27 ~276 minecraft:redstone_wire replace
fill ~141 ~27 ~264 ~141 ~27 ~276 minecraft:redstone_wire replace
fill ~156 ~27 ~264 ~156 ~27 ~270 minecraft:redstone_wire replace
fill ~159 ~27 ~264 ~159 ~27 ~274 minecraft:redstone_wire replace
fill ~168 ~27 ~264 ~168 ~27 ~276 minecraft:redstone_wire replace
fill ~195 ~27 ~264 ~195 ~27 ~276 minecraft:redstone_wire replace
fill ~201 ~27 ~264 ~201 ~27 ~276 minecraft:redstone_wire replace
fill ~222 ~27 ~264 ~222 ~27 ~276 minecraft:redstone_wire replace
fill ~258 ~27 ~264 ~258 ~27 ~276 minecraft:redstone_wire replace
fill ~276 ~27 ~264 ~276 ~27 ~276 minecraft:redstone_wire replace
fill ~291 ~27 ~264 ~291 ~27 ~276 minecraft:redstone_wire replace
fill ~330 ~27 ~264 ~330 ~27 ~276 minecraft:redstone_wire replace
fill ~336 ~27 ~264 ~336 ~27 ~276 minecraft:redstone_wire replace
fill ~348 ~27 ~264 ~348 ~27 ~276 minecraft:redstone_wire replace
setblock ~87 ~27 ~265 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~27 ~265 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~27 ~265 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~266 ~87 ~27 ~278 minecraft:redstone_wire replace
setblock ~99 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~266 ~333 ~27 ~278 minecraft:redstone_wire replace
fill ~351 ~27 ~266 ~351 ~27 ~278 minecraft:redstone_wire replace
fill ~99 ~27 ~268 ~99 ~27 ~280 minecraft:redstone_wire replace
fill ~105 ~27 ~268 ~105 ~27 ~280 minecraft:redstone_wire replace
fill ~120 ~27 ~268 ~120 ~27 ~280 minecraft:redstone_wire replace
fill ~144 ~27 ~268 ~144 ~27 ~280 minecraft:redstone_wire replace
setblock ~147 ~27 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~27 ~268 ~180 ~27 ~278 minecraft:redstone_wire replace
fill ~183 ~27 ~268 ~183 ~27 ~280 minecraft:redstone_wire replace
fill ~204 ~27 ~268 ~204 ~27 ~280 minecraft:redstone_wire replace
fill ~210 ~27 ~268 ~210 ~27 ~280 minecraft:redstone_wire replace
fill ~213 ~27 ~268 ~213 ~27 ~280 minecraft:redstone_wire replace
fill ~228 ~27 ~268 ~228 ~27 ~280 minecraft:redstone_wire replace
fill ~231 ~27 ~268 ~231 ~27 ~280 minecraft:redstone_wire replace
fill ~252 ~27 ~268 ~252 ~27 ~280 minecraft:redstone_wire replace
fill ~255 ~27 ~268 ~255 ~27 ~280 minecraft:redstone_wire replace
fill ~261 ~27 ~268 ~261 ~27 ~280 minecraft:redstone_wire replace
fill ~270 ~27 ~268 ~270 ~27 ~280 minecraft:redstone_wire replace
fill ~279 ~27 ~268 ~279 ~27 ~280 minecraft:redstone_wire replace
fill ~285 ~27 ~268 ~285 ~27 ~280 minecraft:redstone_wire replace
fill ~288 ~27 ~268 ~288 ~27 ~280 minecraft:redstone_wire replace
fill ~303 ~27 ~268 ~303 ~27 ~280 minecraft:redstone_wire replace
fill ~306 ~27 ~268 ~306 ~27 ~280 minecraft:redstone_wire replace
setblock ~123 ~27 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~270 ~123 ~27 ~282 minecraft:redstone_wire replace
setblock ~138 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~272 ~90 ~27 ~284 minecraft:redstone_wire replace
fill ~108 ~27 ~272 ~108 ~27 ~284 minecraft:redstone_wire replace
fill ~114 ~27 ~272 ~114 ~27 ~284 minecraft:redstone_wire replace
fill ~138 ~27 ~272 ~138 ~27 ~284 minecraft:redstone_wire replace
fill ~150 ~27 ~272 ~150 ~27 ~284 minecraft:redstone_wire replace
setblock ~156 ~27 ~272 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~27 ~272 ~174 ~27 ~284 minecraft:redstone_wire replace
fill ~189 ~27 ~272 ~189 ~27 ~284 minecraft:redstone_wire replace
fill ~198 ~27 ~272 ~198 ~27 ~284 minecraft:redstone_wire replace
fill ~216 ~27 ~272 ~216 ~27 ~284 minecraft:redstone_wire replace
fill ~237 ~27 ~272 ~237 ~27 ~284 minecraft:redstone_wire replace
fill ~243 ~27 ~272 ~243 ~27 ~284 minecraft:redstone_wire replace
fill ~267 ~27 ~272 ~267 ~27 ~284 minecraft:redstone_wire replace
fill ~294 ~27 ~272 ~294 ~27 ~284 minecraft:redstone_wire replace
fill ~297 ~27 ~272 ~297 ~27 ~284 minecraft:redstone_wire replace
fill ~315 ~27 ~272 ~315 ~27 ~284 minecraft:redstone_wire replace
fill ~321 ~27 ~272 ~321 ~27 ~284 minecraft:redstone_wire replace
fill ~324 ~27 ~272 ~324 ~27 ~284 minecraft:redstone_wire replace
fill ~342 ~27 ~272 ~342 ~27 ~284 minecraft:redstone_wire replace
setblock ~81 ~27 ~273 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~273 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~27 ~273 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~274 ~81 ~27 ~286 minecraft:redstone_wire replace
setblock ~117 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~274 ~318 ~27 ~286 minecraft:redstone_wire replace
setblock ~339 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~274 ~345 ~27 ~286 minecraft:redstone_wire replace
fill ~78 ~27 ~276 ~78 ~27 ~288 minecraft:redstone_wire replace
setblock ~111 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~276 ~117 ~27 ~288 minecraft:redstone_wire replace
fill ~129 ~27 ~276 ~129 ~27 ~288 minecraft:redstone_wire replace
setblock ~159 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~27 ~276 ~165 ~27 ~288 minecraft:redstone_wire replace
setblock ~171 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~276 ~186 ~27 ~288 minecraft:redstone_wire replace
fill ~192 ~27 ~276 ~192 ~27 ~288 minecraft:redstone_wire replace
fill ~219 ~27 ~276 ~219 ~27 ~288 minecraft:redstone_wire replace
setblock ~234 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~276 ~240 ~27 ~288 minecraft:redstone_wire replace
fill ~246 ~27 ~276 ~246 ~27 ~288 minecraft:redstone_wire replace
fill ~264 ~27 ~276 ~264 ~27 ~288 minecraft:redstone_wire replace
fill ~273 ~27 ~276 ~273 ~27 ~288 minecraft:redstone_wire replace
setblock ~312 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~276 ~339 ~27 ~288 minecraft:redstone_wire replace
setblock ~84 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~278 ~111 ~27 ~290 minecraft:redstone_wire replace
setblock ~141 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~278 ~171 ~27 ~290 minecraft:redstone_wire replace
setblock ~195 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~278 ~234 ~27 ~290 minecraft:redstone_wire replace
setblock ~258 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~278 ~312 ~27 ~290 minecraft:redstone_wire replace
setblock ~330 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~280 ~84 ~27 ~292 minecraft:redstone_wire replace
setblock ~87 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~280 ~93 ~27 ~292 minecraft:redstone_wire replace
fill ~96 ~27 ~280 ~96 ~27 ~292 minecraft:redstone_wire replace
fill ~102 ~27 ~280 ~102 ~27 ~292 minecraft:redstone_wire replace
fill ~141 ~27 ~280 ~141 ~27 ~292 minecraft:redstone_wire replace
fill ~168 ~27 ~280 ~168 ~27 ~292 minecraft:redstone_wire replace
setblock ~180 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~27 ~280 ~195 ~27 ~292 minecraft:redstone_wire replace
fill ~201 ~27 ~280 ~201 ~27 ~292 minecraft:redstone_wire replace
fill ~222 ~27 ~280 ~222 ~27 ~292 minecraft:redstone_wire replace
fill ~258 ~27 ~280 ~258 ~27 ~292 minecraft:redstone_wire replace
fill ~276 ~27 ~280 ~276 ~27 ~292 minecraft:redstone_wire replace
fill ~291 ~27 ~280 ~291 ~27 ~292 minecraft:redstone_wire replace
fill ~330 ~27 ~280 ~330 ~27 ~292 minecraft:redstone_wire replace
setblock ~333 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~280 ~336 ~27 ~292 minecraft:redstone_wire replace
fill ~348 ~27 ~280 ~348 ~27 ~292 minecraft:redstone_wire replace
setblock ~351 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~281 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~282 ~87 ~27 ~294 minecraft:redstone_wire replace
setblock ~99 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~282 ~270 ~27 ~294 minecraft:redstone_wire replace
setblock ~279 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~282 ~333 ~27 ~294 minecraft:redstone_wire replace
fill ~351 ~27 ~282 ~351 ~27 ~294 minecraft:redstone_wire replace
fill ~99 ~27 ~284 ~99 ~27 ~296 minecraft:redstone_wire replace
fill ~105 ~27 ~284 ~105 ~27 ~296 minecraft:redstone_wire replace
fill ~120 ~27 ~284 ~120 ~27 ~296 minecraft:redstone_wire replace
setblock ~123 ~27 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~284 ~144 ~27 ~296 minecraft:redstone_wire replace
fill ~162 ~27 ~284 ~162 ~27 ~296 minecraft:redstone_wire replace
setblock ~183 ~27 ~284 minecraft:redstone_wire replace
fill ~204 ~27 ~284 ~204 ~27 ~296 minecraft:redstone_wire replace
fill ~210 ~27 ~284 ~210 ~27 ~288 minecraft:redstone_wire replace
fill ~213 ~27 ~284 ~213 ~27 ~290 minecraft:redstone_wire replace
fill ~228 ~27 ~284 ~228 ~27 ~294 minecraft:redstone_wire replace
fill ~231 ~27 ~284 ~231 ~27 ~296 minecraft:redstone_wire replace
fill ~252 ~27 ~284 ~252 ~27 ~296 minecraft:redstone_wire replace
fill ~255 ~27 ~284 ~255 ~27 ~296 minecraft:redstone_wire replace
fill ~261 ~27 ~284 ~261 ~27 ~296 minecraft:redstone_wire replace
fill ~279 ~27 ~284 ~279 ~27 ~296 minecraft:redstone_wire replace
fill ~285 ~27 ~284 ~285 ~27 ~296 minecraft:redstone_wire replace
fill ~288 ~27 ~284 ~288 ~27 ~296 minecraft:redstone_wire replace
fill ~303 ~27 ~284 ~303 ~27 ~296 minecraft:redstone_wire replace
fill ~306 ~27 ~284 ~306 ~27 ~296 minecraft:redstone_wire replace
setblock ~90 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~286 ~123 ~27 ~298 minecraft:redstone_wire replace
setblock ~138 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~288 ~90 ~27 ~300 minecraft:redstone_wire replace
fill ~108 ~27 ~288 ~108 ~27 ~300 minecraft:redstone_wire replace
fill ~114 ~27 ~288 ~114 ~27 ~300 minecraft:redstone_wire replace
fill ~138 ~27 ~288 ~138 ~27 ~300 minecraft:redstone_wire replace
fill ~150 ~27 ~288 ~150 ~27 ~300 minecraft:redstone_wire replace
fill ~174 ~27 ~288 ~174 ~27 ~300 minecraft:redstone_wire replace
fill ~189 ~27 ~288 ~189 ~27 ~300 minecraft:redstone_wire replace
fill ~198 ~27 ~288 ~198 ~27 ~300 minecraft:redstone_wire replace
fill ~216 ~27 ~288 ~216 ~27 ~300 minecraft:redstone_wire replace
fill ~237 ~27 ~288 ~237 ~27 ~300 minecraft:redstone_wire replace
fill ~243 ~27 ~288 ~243 ~27 ~300 minecraft:redstone_wire replace
fill ~267 ~27 ~288 ~267 ~27 ~300 minecraft:redstone_wire replace
fill ~294 ~27 ~288 ~294 ~27 ~300 minecraft:redstone_wire replace
fill ~297 ~27 ~288 ~297 ~27 ~300 minecraft:redstone_wire replace
fill ~315 ~27 ~288 ~315 ~27 ~300 minecraft:redstone_wire replace
setblock ~318 ~27 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~27 ~288 ~321 ~27 ~300 minecraft:redstone_wire replace
fill ~324 ~27 ~288 ~324 ~27 ~300 minecraft:redstone_wire replace
fill ~342 ~27 ~288 ~342 ~27 ~300 minecraft:redstone_wire replace
setblock ~345 ~27 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~290 ~81 ~27 ~302 minecraft:redstone_wire replace
setblock ~117 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~290 ~318 ~27 ~302 minecraft:redstone_wire replace
setblock ~339 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~290 ~345 ~27 ~302 minecraft:redstone_wire replace
fill ~78 ~27 ~292 ~78 ~27 ~304 minecraft:redstone_wire replace
setblock ~111 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~292 ~117 ~27 ~304 minecraft:redstone_wire replace
fill ~129 ~27 ~292 ~129 ~27 ~304 minecraft:redstone_wire replace
fill ~165 ~27 ~292 ~165 ~27 ~304 minecraft:redstone_wire replace
setblock ~171 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~292 ~186 ~27 ~304 minecraft:redstone_wire replace
fill ~192 ~27 ~292 ~192 ~27 ~304 minecraft:redstone_wire replace
setblock ~213 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~27 ~292 ~219 ~27 ~304 minecraft:redstone_wire replace
setblock ~234 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~292 ~240 ~27 ~304 minecraft:redstone_wire replace
fill ~246 ~27 ~292 ~246 ~27 ~304 minecraft:redstone_wire replace
fill ~264 ~27 ~292 ~264 ~27 ~304 minecraft:redstone_wire replace
fill ~273 ~27 ~292 ~273 ~27 ~304 minecraft:redstone_wire replace
setblock ~312 ~27 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~292 ~339 ~27 ~304 minecraft:redstone_wire replace
setblock ~84 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~294 ~111 ~27 ~306 minecraft:redstone_wire replace
setblock ~141 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~294 ~171 ~27 ~306 minecraft:redstone_wire replace
setblock ~195 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~294 ~234 ~27 ~306 minecraft:redstone_wire replace
setblock ~258 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~294 ~312 ~27 ~306 minecraft:redstone_wire replace
setblock ~330 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~296 ~84 ~27 ~308 minecraft:redstone_wire replace
setblock ~87 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~296 ~93 ~27 ~308 minecraft:redstone_wire replace
fill ~96 ~27 ~296 ~96 ~27 ~308 minecraft:redstone_wire replace
fill ~102 ~27 ~296 ~102 ~27 ~308 minecraft:redstone_wire replace
fill ~141 ~27 ~296 ~141 ~27 ~308 minecraft:redstone_wire replace
fill ~168 ~27 ~296 ~168 ~27 ~308 minecraft:redstone_wire replace
fill ~195 ~27 ~296 ~195 ~27 ~308 minecraft:redstone_wire replace
fill ~201 ~27 ~296 ~201 ~27 ~308 minecraft:redstone_wire replace
fill ~222 ~27 ~296 ~222 ~27 ~308 minecraft:redstone_wire replace
setblock ~228 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~27 ~296 ~258 ~27 ~308 minecraft:redstone_wire replace
setblock ~270 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~296 ~276 ~27 ~308 minecraft:redstone_wire replace
fill ~291 ~27 ~296 ~291 ~27 ~308 minecraft:redstone_wire replace
fill ~330 ~27 ~296 ~330 ~27 ~308 minecraft:redstone_wire replace
setblock ~333 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~296 ~336 ~27 ~308 minecraft:redstone_wire replace
fill ~348 ~27 ~296 ~348 ~27 ~308 minecraft:redstone_wire replace
setblock ~351 ~27 ~296 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~296 ~357 ~27 ~308 minecraft:redstone_wire replace
fill ~87 ~27 ~298 ~87 ~27 ~310 minecraft:redstone_wire replace
setblock ~99 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~298 ~270 ~27 ~310 minecraft:redstone_wire replace
setblock ~279 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~298 ~333 ~27 ~310 minecraft:redstone_wire replace
fill ~351 ~27 ~298 ~351 ~27 ~310 minecraft:redstone_wire replace
fill ~99 ~27 ~300 ~99 ~27 ~312 minecraft:redstone_wire replace
fill ~105 ~27 ~300 ~105 ~27 ~312 minecraft:redstone_wire replace
fill ~120 ~27 ~300 ~120 ~27 ~312 minecraft:redstone_wire replace
setblock ~123 ~27 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~300 ~144 ~27 ~312 minecraft:redstone_wire replace
fill ~162 ~27 ~300 ~162 ~27 ~312 minecraft:redstone_wire replace
fill ~204 ~27 ~300 ~204 ~27 ~312 minecraft:redstone_wire replace
setblock ~231 ~27 ~300 minecraft:redstone_wire replace
fill ~252 ~27 ~300 ~252 ~27 ~304 minecraft:redstone_wire replace
fill ~255 ~27 ~300 ~255 ~27 ~306 minecraft:redstone_wire replace
fill ~261 ~27 ~300 ~261 ~27 ~312 minecraft:redstone_wire replace
fill ~279 ~27 ~300 ~279 ~27 ~312 minecraft:redstone_wire replace
fill ~285 ~27 ~300 ~285 ~27 ~310 minecraft:redstone_wire replace
fill ~288 ~27 ~300 ~288 ~27 ~312 minecraft:redstone_wire replace
fill ~303 ~27 ~300 ~303 ~27 ~312 minecraft:redstone_wire replace
fill ~306 ~27 ~300 ~306 ~27 ~312 minecraft:redstone_wire replace
fill ~354 ~27 ~300 ~354 ~27 ~312 minecraft:redstone_wire replace
setblock ~90 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~302 ~123 ~27 ~314 minecraft:redstone_wire replace
setblock ~138 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~304 ~90 ~27 ~316 minecraft:redstone_wire replace
fill ~108 ~27 ~304 ~108 ~27 ~316 minecraft:redstone_wire replace
fill ~114 ~27 ~304 ~114 ~27 ~316 minecraft:redstone_wire replace
fill ~138 ~27 ~304 ~138 ~27 ~316 minecraft:redstone_wire replace
fill ~150 ~27 ~304 ~150 ~27 ~316 minecraft:redstone_wire replace
fill ~174 ~27 ~304 ~174 ~27 ~316 minecraft:redstone_wire replace
fill ~189 ~27 ~304 ~189 ~27 ~316 minecraft:redstone_wire replace
fill ~198 ~27 ~304 ~198 ~27 ~316 minecraft:redstone_wire replace
fill ~216 ~27 ~304 ~216 ~27 ~316 minecraft:redstone_wire replace
fill ~237 ~27 ~304 ~237 ~27 ~316 minecraft:redstone_wire replace
fill ~243 ~27 ~304 ~243 ~27 ~316 minecraft:redstone_wire replace
fill ~267 ~27 ~304 ~267 ~27 ~316 minecraft:redstone_wire replace
fill ~294 ~27 ~304 ~294 ~27 ~316 minecraft:redstone_wire replace
fill ~297 ~27 ~304 ~297 ~27 ~316 minecraft:redstone_wire replace
fill ~315 ~27 ~304 ~315 ~27 ~316 minecraft:redstone_wire replace
setblock ~318 ~27 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~27 ~304 ~321 ~27 ~316 minecraft:redstone_wire replace
fill ~324 ~27 ~304 ~324 ~27 ~316 minecraft:redstone_wire replace
fill ~342 ~27 ~304 ~342 ~27 ~316 minecraft:redstone_wire replace
setblock ~345 ~27 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~306 ~81 ~27 ~318 minecraft:redstone_wire replace
setblock ~117 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~306 ~318 ~27 ~318 minecraft:redstone_wire replace
setblock ~339 ~27 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~306 ~345 ~27 ~318 minecraft:redstone_wire replace
fill ~78 ~27 ~308 ~78 ~27 ~320 minecraft:redstone_wire replace
setblock ~111 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~308 ~117 ~27 ~320 minecraft:redstone_wire replace
fill ~129 ~27 ~308 ~129 ~27 ~320 minecraft:redstone_wire replace
fill ~165 ~27 ~308 ~165 ~27 ~320 minecraft:redstone_wire replace
setblock ~171 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~308 ~186 ~27 ~320 minecraft:redstone_wire replace
fill ~192 ~27 ~308 ~192 ~27 ~320 minecraft:redstone_wire replace
fill ~219 ~27 ~308 ~219 ~27 ~320 minecraft:redstone_wire replace
setblock ~234 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~308 ~240 ~27 ~320 minecraft:redstone_wire replace
fill ~246 ~27 ~308 ~246 ~27 ~320 minecraft:redstone_wire replace
setblock ~255 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~27 ~308 ~264 ~27 ~320 minecraft:redstone_wire replace
fill ~273 ~27 ~308 ~273 ~27 ~320 minecraft:redstone_wire replace
setblock ~312 ~27 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~308 ~339 ~27 ~320 minecraft:redstone_wire replace
setblock ~84 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~310 ~111 ~27 ~322 minecraft:redstone_wire replace
setblock ~141 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~310 ~171 ~27 ~322 minecraft:redstone_wire replace
setblock ~195 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~310 ~234 ~27 ~322 minecraft:redstone_wire replace
setblock ~258 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~310 ~312 ~27 ~322 minecraft:redstone_wire replace
setblock ~330 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~312 ~84 ~27 ~324 minecraft:redstone_wire replace
setblock ~87 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~312 ~93 ~27 ~324 minecraft:redstone_wire replace
fill ~96 ~27 ~312 ~96 ~27 ~324 minecraft:redstone_wire replace
fill ~102 ~27 ~312 ~102 ~27 ~324 minecraft:redstone_wire replace
fill ~141 ~27 ~312 ~141 ~27 ~324 minecraft:redstone_wire replace
fill ~168 ~27 ~312 ~168 ~27 ~324 minecraft:redstone_wire replace
fill ~195 ~27 ~312 ~195 ~27 ~324 minecraft:redstone_wire replace
fill ~201 ~27 ~312 ~201 ~27 ~324 minecraft:redstone_wire replace
fill ~222 ~27 ~312 ~222 ~27 ~324 minecraft:redstone_wire replace
fill ~258 ~27 ~312 ~258 ~27 ~324 minecraft:redstone_wire replace
setblock ~270 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~312 ~276 ~27 ~324 minecraft:redstone_wire replace
setblock ~285 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~312 ~291 ~27 ~324 minecraft:redstone_wire replace
fill ~330 ~27 ~312 ~330 ~27 ~324 minecraft:redstone_wire replace
setblock ~333 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~312 ~336 ~27 ~324 minecraft:redstone_wire replace
fill ~348 ~27 ~312 ~348 ~27 ~324 minecraft:redstone_wire replace
setblock ~351 ~27 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~312 ~357 ~27 ~324 minecraft:redstone_wire replace
fill ~87 ~27 ~314 ~87 ~27 ~326 minecraft:redstone_wire replace
setblock ~99 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~314 ~270 ~27 ~326 minecraft:redstone_wire replace
setblock ~279 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~314 ~333 ~27 ~326 minecraft:redstone_wire replace
fill ~351 ~27 ~314 ~351 ~27 ~326 minecraft:redstone_wire replace
setblock ~354 ~27 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~316 ~99 ~27 ~328 minecraft:redstone_wire replace
fill ~105 ~27 ~316 ~105 ~27 ~328 minecraft:redstone_wire replace
fill ~120 ~27 ~316 ~120 ~27 ~328 minecraft:redstone_wire replace
setblock ~123 ~27 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~316 ~144 ~27 ~328 minecraft:redstone_wire replace
fill ~162 ~27 ~316 ~162 ~27 ~328 minecraft:redstone_wire replace
fill ~204 ~27 ~316 ~204 ~27 ~328 minecraft:redstone_wire replace
fill ~261 ~27 ~316 ~261 ~27 ~328 minecraft:redstone_wire replace
fill ~279 ~27 ~316 ~279 ~27 ~328 minecraft:redstone_wire replace
setblock ~288 ~27 ~316 minecraft:redstone_wire replace
fill ~303 ~27 ~316 ~303 ~27 ~326 minecraft:redstone_wire replace
fill ~306 ~27 ~316 ~306 ~27 ~328 minecraft:redstone_wire replace
fill ~354 ~27 ~316 ~354 ~27 ~328 minecraft:redstone_wire replace
setblock ~90 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~318 ~123 ~27 ~330 minecraft:redstone_wire replace
setblock ~138 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~318 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~320 ~90 ~27 ~332 minecraft:redstone_wire replace
fill ~108 ~27 ~320 ~108 ~27 ~332 minecraft:redstone_wire replace
fill ~114 ~27 ~320 ~114 ~27 ~332 minecraft:redstone_wire replace
fill ~138 ~27 ~320 ~138 ~27 ~332 minecraft:redstone_wire replace
fill ~150 ~27 ~320 ~150 ~27 ~332 minecraft:redstone_wire replace
fill ~174 ~27 ~320 ~174 ~27 ~332 minecraft:redstone_wire replace
fill ~189 ~27 ~320 ~189 ~27 ~332 minecraft:redstone_wire replace
fill ~198 ~27 ~320 ~198 ~27 ~332 minecraft:redstone_wire replace
fill ~216 ~27 ~320 ~216 ~27 ~332 minecraft:redstone_wire replace
fill ~237 ~27 ~320 ~237 ~27 ~332 minecraft:redstone_wire replace
fill ~243 ~27 ~320 ~243 ~27 ~332 minecraft:redstone_wire replace
fill ~267 ~27 ~320 ~267 ~27 ~332 minecraft:redstone_wire replace
setblock ~294 ~27 ~320 minecraft:redstone_wire replace
fill ~297 ~27 ~320 ~297 ~27 ~324 minecraft:redstone_wire replace
fill ~315 ~27 ~320 ~315 ~27 ~332 minecraft:redstone_wire replace
setblock ~318 ~27 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~27 ~320 ~321 ~27 ~332 minecraft:redstone_wire replace
fill ~324 ~27 ~320 ~324 ~27 ~332 minecraft:redstone_wire replace
fill ~342 ~27 ~320 ~342 ~27 ~332 minecraft:redstone_wire replace
setblock ~345 ~27 ~320 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~322 ~81 ~27 ~334 minecraft:redstone_wire replace
setblock ~117 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~322 ~318 ~27 ~334 minecraft:redstone_wire replace
setblock ~339 ~27 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~322 ~345 ~27 ~334 minecraft:redstone_wire replace
fill ~78 ~27 ~324 ~78 ~27 ~336 minecraft:redstone_wire replace
setblock ~111 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~324 ~117 ~27 ~336 minecraft:redstone_wire replace
fill ~129 ~27 ~324 ~129 ~27 ~336 minecraft:redstone_wire replace
fill ~165 ~27 ~324 ~165 ~27 ~336 minecraft:redstone_wire replace
setblock ~171 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~324 ~186 ~27 ~336 minecraft:redstone_wire replace
fill ~192 ~27 ~324 ~192 ~27 ~336 minecraft:redstone_wire replace
fill ~219 ~27 ~324 ~219 ~27 ~336 minecraft:redstone_wire replace
setblock ~234 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~324 ~240 ~27 ~336 minecraft:redstone_wire replace
fill ~246 ~27 ~324 ~246 ~27 ~336 minecraft:redstone_wire replace
fill ~264 ~27 ~324 ~264 ~27 ~336 minecraft:redstone_wire replace
fill ~273 ~27 ~324 ~273 ~27 ~336 minecraft:redstone_wire replace
setblock ~312 ~27 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~324 ~339 ~27 ~336 minecraft:redstone_wire replace
setblock ~84 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~326 ~111 ~27 ~338 minecraft:redstone_wire replace
setblock ~141 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~326 ~171 ~27 ~338 minecraft:redstone_wire replace
setblock ~195 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~326 ~234 ~27 ~338 minecraft:redstone_wire replace
setblock ~258 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~326 ~312 ~27 ~338 minecraft:redstone_wire replace
setblock ~330 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~328 ~84 ~27 ~340 minecraft:redstone_wire replace
setblock ~87 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~328 ~93 ~27 ~340 minecraft:redstone_wire replace
fill ~96 ~27 ~328 ~96 ~27 ~340 minecraft:redstone_wire replace
fill ~102 ~27 ~328 ~102 ~27 ~340 minecraft:redstone_wire replace
fill ~141 ~27 ~328 ~141 ~27 ~340 minecraft:redstone_wire replace
fill ~168 ~27 ~328 ~168 ~27 ~340 minecraft:redstone_wire replace
fill ~195 ~27 ~328 ~195 ~27 ~340 minecraft:redstone_wire replace
fill ~201 ~27 ~328 ~201 ~27 ~340 minecraft:redstone_wire replace
fill ~222 ~27 ~328 ~222 ~27 ~340 minecraft:redstone_wire replace
fill ~258 ~27 ~328 ~258 ~27 ~340 minecraft:redstone_wire replace
setblock ~270 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~328 ~276 ~27 ~340 minecraft:redstone_wire replace
fill ~291 ~27 ~328 ~291 ~27 ~340 minecraft:redstone_wire replace
setblock ~303 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~330 ~27 ~328 ~330 ~27 ~340 minecraft:redstone_wire replace
setblock ~333 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~328 ~336 ~27 ~340 minecraft:redstone_wire replace
fill ~348 ~27 ~328 ~348 ~27 ~340 minecraft:redstone_wire replace
setblock ~351 ~27 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~328 ~357 ~27 ~340 minecraft:redstone_wire replace
fill ~87 ~27 ~330 ~87 ~27 ~342 minecraft:redstone_wire replace
setblock ~99 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~330 ~270 ~27 ~342 minecraft:redstone_wire replace
setblock ~279 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~330 ~333 ~27 ~342 minecraft:redstone_wire replace
fill ~351 ~27 ~330 ~351 ~27 ~342 minecraft:redstone_wire replace
setblock ~354 ~27 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~332 ~99 ~27 ~344 minecraft:redstone_wire replace
fill ~105 ~27 ~332 ~105 ~27 ~344 minecraft:redstone_wire replace
fill ~120 ~27 ~332 ~120 ~27 ~344 minecraft:redstone_wire replace
setblock ~123 ~27 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~332 ~144 ~27 ~344 minecraft:redstone_wire replace
fill ~162 ~27 ~332 ~162 ~27 ~344 minecraft:redstone_wire replace
fill ~204 ~27 ~332 ~204 ~27 ~344 minecraft:redstone_wire replace
fill ~261 ~27 ~332 ~261 ~27 ~344 minecraft:redstone_wire replace
fill ~279 ~27 ~332 ~279 ~27 ~344 minecraft:redstone_wire replace
setblock ~306 ~27 ~332 minecraft:redstone_wire replace
fill ~354 ~27 ~332 ~354 ~27 ~344 minecraft:redstone_wire replace
setblock ~90 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~334 ~123 ~27 ~346 minecraft:redstone_wire replace
setblock ~138 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~334 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~336 ~90 ~27 ~342 minecraft:redstone_wire replace
fill ~108 ~27 ~336 ~108 ~27 ~348 minecraft:redstone_wire replace
fill ~114 ~27 ~336 ~114 ~27 ~348 minecraft:redstone_wire replace
fill ~138 ~27 ~336 ~138 ~27 ~348 minecraft:redstone_wire replace
fill ~150 ~27 ~336 ~150 ~27 ~348 minecraft:redstone_wire replace
fill ~174 ~27 ~336 ~174 ~27 ~348 minecraft:redstone_wire replace
fill ~189 ~27 ~336 ~189 ~27 ~348 minecraft:redstone_wire replace
fill ~198 ~27 ~336 ~198 ~27 ~348 minecraft:redstone_wire replace
fill ~216 ~27 ~336 ~216 ~27 ~348 minecraft:redstone_wire replace
fill ~237 ~27 ~336 ~237 ~27 ~348 minecraft:redstone_wire replace
fill ~243 ~27 ~336 ~243 ~27 ~348 minecraft:redstone_wire replace
fill ~267 ~27 ~336 ~267 ~27 ~348 minecraft:redstone_wire replace
fill ~315 ~27 ~336 ~315 ~27 ~348 minecraft:redstone_wire replace
setblock ~318 ~27 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~336 minecraft:redstone_wire replace
fill ~324 ~27 ~336 ~324 ~27 ~340 minecraft:redstone_wire replace
fill ~342 ~27 ~336 ~342 ~27 ~348 minecraft:redstone_wire replace
setblock ~345 ~27 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~338 ~81 ~27 ~350 minecraft:redstone_wire replace
setblock ~117 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~338 ~318 ~27 ~350 minecraft:redstone_wire replace
setblock ~339 ~27 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~338 ~345 ~27 ~350 minecraft:redstone_wire replace
fill ~78 ~27 ~340 ~78 ~27 ~352 minecraft:redstone_wire replace
setblock ~111 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~340 ~117 ~27 ~352 minecraft:redstone_wire replace
fill ~129 ~27 ~340 ~129 ~27 ~352 minecraft:redstone_wire replace
fill ~165 ~27 ~340 ~165 ~27 ~352 minecraft:redstone_wire replace
setblock ~171 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~340 ~186 ~27 ~352 minecraft:redstone_wire replace
fill ~192 ~27 ~340 ~192 ~27 ~352 minecraft:redstone_wire replace
fill ~219 ~27 ~340 ~219 ~27 ~352 minecraft:redstone_wire replace
setblock ~234 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~340 ~240 ~27 ~352 minecraft:redstone_wire replace
fill ~246 ~27 ~340 ~246 ~27 ~352 minecraft:redstone_wire replace
fill ~264 ~27 ~340 ~264 ~27 ~352 minecraft:redstone_wire replace
fill ~273 ~27 ~340 ~273 ~27 ~352 minecraft:redstone_wire replace
setblock ~312 ~27 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~340 ~339 ~27 ~352 minecraft:redstone_wire replace
setblock ~84 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~342 ~111 ~27 ~348 minecraft:redstone_wire replace
setblock ~141 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~342 ~171 ~27 ~354 minecraft:redstone_wire replace
setblock ~195 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~342 ~234 ~27 ~354 minecraft:redstone_wire replace
setblock ~258 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~342 ~312 ~27 ~354 minecraft:redstone_wire replace
setblock ~330 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~344 ~84 ~27 ~356 minecraft:redstone_wire replace
setblock ~87 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~344 ~93 ~27 ~356 minecraft:redstone_wire replace
fill ~96 ~27 ~344 ~96 ~27 ~356 minecraft:redstone_wire replace
fill ~102 ~27 ~344 ~102 ~27 ~356 minecraft:redstone_wire replace
fill ~141 ~27 ~344 ~141 ~27 ~356 minecraft:redstone_wire replace
fill ~168 ~27 ~344 ~168 ~27 ~356 minecraft:redstone_wire replace
fill ~195 ~27 ~344 ~195 ~27 ~356 minecraft:redstone_wire replace
fill ~201 ~27 ~344 ~201 ~27 ~356 minecraft:redstone_wire replace
fill ~222 ~27 ~344 ~222 ~27 ~356 minecraft:redstone_wire replace
fill ~258 ~27 ~344 ~258 ~27 ~356 minecraft:redstone_wire replace
setblock ~270 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~344 ~276 ~27 ~356 minecraft:redstone_wire replace
fill ~291 ~27 ~344 ~291 ~27 ~356 minecraft:redstone_wire replace
fill ~330 ~27 ~344 ~330 ~27 ~356 minecraft:redstone_wire replace
setblock ~333 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~344 ~336 ~27 ~356 minecraft:redstone_wire replace
fill ~348 ~27 ~344 ~348 ~27 ~356 minecraft:redstone_wire replace
setblock ~351 ~27 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~344 ~357 ~27 ~356 minecraft:redstone_wire replace
fill ~87 ~27 ~346 ~87 ~27 ~358 minecraft:redstone_wire replace
setblock ~99 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~346 ~270 ~27 ~358 minecraft:redstone_wire replace
setblock ~279 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~346 ~333 ~27 ~358 minecraft:redstone_wire replace
fill ~351 ~27 ~346 ~351 ~27 ~358 minecraft:redstone_wire replace
setblock ~354 ~27 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~348 ~99 ~27 ~360 minecraft:redstone_wire replace
fill ~105 ~27 ~348 ~105 ~27 ~360 minecraft:redstone_wire replace
fill ~120 ~27 ~348 ~120 ~27 ~360 minecraft:redstone_wire replace
setblock ~123 ~27 ~348 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~348 ~144 ~27 ~360 minecraft:redstone_wire replace
fill ~162 ~27 ~348 ~162 ~27 ~360 minecraft:redstone_wire replace
fill ~204 ~27 ~348 ~204 ~27 ~360 minecraft:redstone_wire replace
fill ~261 ~27 ~348 ~261 ~27 ~360 minecraft:redstone_wire replace
fill ~279 ~27 ~348 ~279 ~27 ~360 minecraft:redstone_wire replace
fill ~354 ~27 ~348 ~354 ~27 ~360 minecraft:redstone_wire replace
setblock ~108 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~350 ~123 ~27 ~362 minecraft:redstone_wire replace
setblock ~138 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~350 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~27 ~352 ~108 ~27 ~364 minecraft:redstone_wire replace
fill ~114 ~27 ~352 ~114 ~27 ~364 minecraft:redstone_wire replace
setblock ~138 ~27 ~352 minecraft:redstone_wire replace
fill ~150 ~27 ~352 ~150 ~27 ~364 minecraft:redstone_wire replace
fill ~174 ~27 ~352 ~174 ~27 ~364 minecraft:redstone_wire replace
fill ~189 ~27 ~352 ~189 ~27 ~364 minecraft:redstone_wire replace
fill ~198 ~27 ~352 ~198 ~27 ~358 minecraft:redstone_wire replace
fill ~216 ~27 ~352 ~216 ~27 ~364 minecraft:redstone_wire replace
fill ~237 ~27 ~352 ~237 ~27 ~364 minecraft:redstone_wire replace
fill ~243 ~27 ~352 ~243 ~27 ~364 minecraft:redstone_wire replace
fill ~267 ~27 ~352 ~267 ~27 ~364 minecraft:redstone_wire replace
fill ~315 ~27 ~352 ~315 ~27 ~364 minecraft:redstone_wire replace
setblock ~318 ~27 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~352 ~342 ~27 ~364 minecraft:redstone_wire replace
setblock ~345 ~27 ~352 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~354 ~81 ~27 ~366 minecraft:redstone_wire replace
setblock ~117 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~354 ~318 ~27 ~366 minecraft:redstone_wire replace
setblock ~339 ~27 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~354 ~345 ~27 ~366 minecraft:redstone_wire replace
setblock ~171 ~27 ~355 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~356 ~78 ~27 ~368 minecraft:redstone_wire replace
fill ~117 ~27 ~356 ~117 ~27 ~368 minecraft:redstone_wire replace
fill ~129 ~27 ~356 ~129 ~27 ~368 minecraft:redstone_wire replace
fill ~165 ~27 ~356 ~165 ~27 ~368 minecraft:redstone_wire replace
setblock ~171 ~27 ~356 minecraft:redstone_wire replace
fill ~186 ~27 ~356 ~186 ~27 ~368 minecraft:redstone_wire replace
fill ~192 ~27 ~356 ~192 ~27 ~368 minecraft:redstone_wire replace
fill ~219 ~27 ~356 ~219 ~27 ~368 minecraft:redstone_wire replace
setblock ~234 ~27 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~356 ~240 ~27 ~368 minecraft:redstone_wire replace
fill ~246 ~27 ~356 ~246 ~27 ~368 minecraft:redstone_wire replace
fill ~264 ~27 ~356 ~264 ~27 ~368 minecraft:redstone_wire replace
fill ~273 ~27 ~356 ~273 ~27 ~368 minecraft:redstone_wire replace
setblock ~312 ~27 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~356 ~339 ~27 ~368 minecraft:redstone_wire replace
setblock ~84 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~358 ~234 ~27 ~364 minecraft:redstone_wire replace
setblock ~258 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~358 ~312 ~27 ~370 minecraft:redstone_wire replace
setblock ~330 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~360 ~84 ~27 ~372 minecraft:redstone_wire replace
setblock ~87 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~360 ~93 ~27 ~372 minecraft:redstone_wire replace
fill ~96 ~27 ~360 ~96 ~27 ~372 minecraft:redstone_wire replace
fill ~102 ~27 ~360 ~102 ~27 ~372 minecraft:redstone_wire replace
fill ~141 ~27 ~360 ~141 ~27 ~372 minecraft:redstone_wire replace
fill ~168 ~27 ~360 ~168 ~27 ~372 minecraft:redstone_wire replace
fill ~195 ~27 ~360 ~195 ~27 ~372 minecraft:redstone_wire replace
setblock ~198 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~27 ~360 ~201 ~27 ~372 minecraft:redstone_wire replace
fill ~222 ~27 ~360 ~222 ~27 ~372 minecraft:redstone_wire replace
fill ~258 ~27 ~360 ~258 ~27 ~372 minecraft:redstone_wire replace
setblock ~270 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~360 ~276 ~27 ~372 minecraft:redstone_wire replace
fill ~291 ~27 ~360 ~291 ~27 ~372 minecraft:redstone_wire replace
fill ~330 ~27 ~360 ~330 ~27 ~372 minecraft:redstone_wire replace
setblock ~333 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~360 ~336 ~27 ~372 minecraft:redstone_wire replace
fill ~348 ~27 ~360 ~348 ~27 ~372 minecraft:redstone_wire replace
setblock ~351 ~27 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~360 ~357 ~27 ~372 minecraft:redstone_wire replace
fill ~87 ~27 ~362 ~87 ~27 ~374 minecraft:redstone_wire replace
setblock ~99 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~362 ~270 ~27 ~374 minecraft:redstone_wire replace
setblock ~279 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~362 ~333 ~27 ~374 minecraft:redstone_wire replace
fill ~351 ~27 ~362 ~351 ~27 ~374 minecraft:redstone_wire replace
setblock ~354 ~27 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~364 ~99 ~27 ~376 minecraft:redstone_wire replace
fill ~105 ~27 ~364 ~105 ~27 ~376 minecraft:redstone_wire replace
fill ~120 ~27 ~364 ~120 ~27 ~376 minecraft:redstone_wire replace
setblock ~123 ~27 ~364 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~364 ~144 ~27 ~376 minecraft:redstone_wire replace
fill ~162 ~27 ~364 ~162 ~27 ~376 minecraft:redstone_wire replace
fill ~204 ~27 ~364 ~204 ~27 ~376 minecraft:redstone_wire replace
fill ~261 ~27 ~364 ~261 ~27 ~368 minecraft:redstone_wire replace
fill ~279 ~27 ~364 ~279 ~27 ~370 minecraft:redstone_wire replace
fill ~354 ~27 ~364 ~354 ~27 ~376 minecraft:redstone_wire replace
setblock ~108 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~366 ~123 ~27 ~378 minecraft:redstone_wire replace
setblock ~150 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~27 ~368 ~108 ~27 ~380 minecraft:redstone_wire replace
fill ~114 ~27 ~368 ~114 ~27 ~380 minecraft:redstone_wire replace
fill ~150 ~27 ~368 ~150 ~27 ~380 minecraft:redstone_wire replace
fill ~174 ~27 ~368 ~174 ~27 ~380 minecraft:redstone_wire replace
fill ~189 ~27 ~368 ~189 ~27 ~380 minecraft:redstone_wire replace
fill ~216 ~27 ~368 ~216 ~27 ~380 minecraft:redstone_wire replace
fill ~237 ~27 ~368 ~237 ~27 ~380 minecraft:redstone_wire replace
fill ~243 ~27 ~368 ~243 ~27 ~380 minecraft:redstone_wire replace
fill ~267 ~27 ~368 ~267 ~27 ~380 minecraft:redstone_wire replace
fill ~315 ~27 ~368 ~315 ~27 ~380 minecraft:redstone_wire replace
setblock ~318 ~27 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~368 ~342 ~27 ~380 minecraft:redstone_wire replace
setblock ~345 ~27 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~370 ~81 ~27 ~382 minecraft:redstone_wire replace
setblock ~117 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~370 ~318 ~27 ~382 minecraft:redstone_wire replace
setblock ~339 ~27 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~370 ~345 ~27 ~382 minecraft:redstone_wire replace
fill ~78 ~27 ~372 ~78 ~27 ~384 minecraft:redstone_wire replace
fill ~117 ~27 ~372 ~117 ~27 ~384 minecraft:redstone_wire replace
fill ~129 ~27 ~372 ~129 ~27 ~384 minecraft:redstone_wire replace
fill ~165 ~27 ~372 ~165 ~27 ~384 minecraft:redstone_wire replace
fill ~186 ~27 ~372 ~186 ~27 ~384 minecraft:redstone_wire replace
fill ~192 ~27 ~372 ~192 ~27 ~384 minecraft:redstone_wire replace
fill ~219 ~27 ~372 ~219 ~27 ~384 minecraft:redstone_wire replace
fill ~240 ~27 ~372 ~240 ~27 ~384 minecraft:redstone_wire replace
fill ~246 ~27 ~372 ~246 ~27 ~384 minecraft:redstone_wire replace
fill ~264 ~27 ~372 ~264 ~27 ~384 minecraft:redstone_wire replace
fill ~273 ~27 ~372 ~273 ~27 ~384 minecraft:redstone_wire replace
setblock ~279 ~27 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~372 ~339 ~27 ~384 minecraft:redstone_wire replace
setblock ~84 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~374 ~312 ~27 ~376 minecraft:redstone_wire replace
setblock ~330 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~376 ~84 ~27 ~388 minecraft:redstone_wire replace
setblock ~87 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~376 ~93 ~27 ~388 minecraft:redstone_wire replace
fill ~96 ~27 ~376 ~96 ~27 ~388 minecraft:redstone_wire replace
fill ~102 ~27 ~376 ~102 ~27 ~388 minecraft:redstone_wire replace
fill ~141 ~27 ~376 ~141 ~27 ~388 minecraft:redstone_wire replace
fill ~168 ~27 ~376 ~168 ~27 ~388 minecraft:redstone_wire replace
fill ~195 ~27 ~376 ~195 ~27 ~388 minecraft:redstone_wire replace
fill ~201 ~27 ~376 ~201 ~27 ~388 minecraft:redstone_wire replace
fill ~222 ~27 ~376 ~222 ~27 ~388 minecraft:redstone_wire replace
fill ~258 ~27 ~376 ~258 ~27 ~388 minecraft:redstone_wire replace
setblock ~270 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~376 ~276 ~27 ~388 minecraft:redstone_wire replace
fill ~291 ~27 ~376 ~291 ~27 ~388 minecraft:redstone_wire replace
fill ~330 ~27 ~376 ~330 ~27 ~388 minecraft:redstone_wire replace
setblock ~333 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~376 ~336 ~27 ~388 minecraft:redstone_wire replace
fill ~348 ~27 ~376 ~348 ~27 ~388 minecraft:redstone_wire replace
setblock ~351 ~27 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~376 ~357 ~27 ~388 minecraft:redstone_wire replace
fill ~87 ~27 ~378 ~87 ~27 ~380 minecraft:redstone_wire replace
setblock ~99 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~378 ~270 ~27 ~390 minecraft:redstone_wire replace
fill ~333 ~27 ~378 ~333 ~27 ~390 minecraft:redstone_wire replace
fill ~351 ~27 ~378 ~351 ~27 ~390 minecraft:redstone_wire replace
setblock ~354 ~27 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~380 ~99 ~27 ~392 minecraft:redstone_wire replace
fill ~105 ~27 ~380 ~105 ~27 ~392 minecraft:redstone_wire replace
fill ~120 ~27 ~380 ~120 ~27 ~392 minecraft:redstone_wire replace
setblock ~123 ~27 ~380 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~380 ~144 ~27 ~392 minecraft:redstone_wire replace
fill ~162 ~27 ~380 ~162 ~27 ~392 minecraft:redstone_wire replace
fill ~204 ~27 ~380 ~204 ~27 ~392 minecraft:redstone_wire replace
fill ~354 ~27 ~380 ~354 ~27 ~392 minecraft:redstone_wire replace
setblock ~108 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~382 ~123 ~27 ~394 minecraft:redstone_wire replace
setblock ~150 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~384 minecraft:redstone_wire replace
fill ~114 ~27 ~384 ~114 ~27 ~396 minecraft:redstone_wire replace
fill ~150 ~27 ~384 ~150 ~27 ~396 minecraft:redstone_wire replace
fill ~174 ~27 ~384 ~174 ~27 ~396 minecraft:redstone_wire replace
fill ~189 ~27 ~384 ~189 ~27 ~396 minecraft:redstone_wire replace
fill ~216 ~27 ~384 ~216 ~27 ~396 minecraft:redstone_wire replace
fill ~237 ~27 ~384 ~237 ~27 ~396 minecraft:redstone_wire replace
fill ~243 ~27 ~384 ~243 ~27 ~396 minecraft:redstone_wire replace
fill ~267 ~27 ~384 ~267 ~27 ~396 minecraft:redstone_wire replace
fill ~315 ~27 ~384 ~315 ~27 ~396 minecraft:redstone_wire replace
setblock ~318 ~27 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~384 ~342 ~27 ~396 minecraft:redstone_wire replace
setblock ~345 ~27 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~386 ~81 ~27 ~398 minecraft:redstone_wire replace
setblock ~117 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~386 ~318 ~27 ~398 minecraft:redstone_wire replace
setblock ~339 ~27 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~386 ~345 ~27 ~398 minecraft:redstone_wire replace
fill ~78 ~27 ~388 ~78 ~27 ~400 minecraft:redstone_wire replace
fill ~117 ~27 ~388 ~117 ~27 ~400 minecraft:redstone_wire replace
setblock ~129 ~27 ~388 minecraft:redstone_wire replace
fill ~165 ~27 ~388 ~165 ~27 ~400 minecraft:redstone_wire replace
fill ~186 ~27 ~388 ~186 ~27 ~400 minecraft:redstone_wire replace
fill ~192 ~27 ~388 ~192 ~27 ~400 minecraft:redstone_wire replace
fill ~219 ~27 ~388 ~219 ~27 ~400 minecraft:redstone_wire replace
fill ~240 ~27 ~388 ~240 ~27 ~400 minecraft:redstone_wire replace
fill ~246 ~27 ~388 ~246 ~27 ~400 minecraft:redstone_wire replace
fill ~264 ~27 ~388 ~264 ~27 ~400 minecraft:redstone_wire replace
fill ~273 ~27 ~388 ~273 ~27 ~400 minecraft:redstone_wire replace
fill ~339 ~27 ~388 ~339 ~27 ~400 minecraft:redstone_wire replace
setblock ~84 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~392 ~84 ~27 ~404 minecraft:redstone_wire replace
fill ~93 ~27 ~392 ~93 ~27 ~404 minecraft:redstone_wire replace
fill ~96 ~27 ~392 ~96 ~27 ~404 minecraft:redstone_wire replace
fill ~102 ~27 ~392 ~102 ~27 ~404 minecraft:redstone_wire replace
fill ~141 ~27 ~392 ~141 ~27 ~404 minecraft:redstone_wire replace
setblock ~168 ~27 ~392 minecraft:redstone_wire replace
fill ~195 ~27 ~392 ~195 ~27 ~396 minecraft:redstone_wire replace
fill ~201 ~27 ~392 ~201 ~27 ~404 minecraft:redstone_wire replace
fill ~222 ~27 ~392 ~222 ~27 ~398 minecraft:redstone_wire replace
fill ~258 ~27 ~392 ~258 ~27 ~402 minecraft:redstone_wire replace
setblock ~270 ~27 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~27 ~392 ~276 ~27 ~404 minecraft:redstone_wire replace
fill ~291 ~27 ~392 ~291 ~27 ~404 minecraft:redstone_wire replace
fill ~330 ~27 ~392 ~330 ~27 ~404 minecraft:redstone_wire replace
setblock ~333 ~27 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~392 ~336 ~27 ~404 minecraft:redstone_wire replace
fill ~348 ~27 ~392 ~348 ~27 ~404 minecraft:redstone_wire replace
setblock ~351 ~27 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~392 ~357 ~27 ~404 minecraft:redstone_wire replace
setblock ~99 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~394 ~270 ~27 ~406 minecraft:redstone_wire replace
fill ~333 ~27 ~394 ~333 ~27 ~406 minecraft:redstone_wire replace
fill ~351 ~27 ~394 ~351 ~27 ~406 minecraft:redstone_wire replace
setblock ~354 ~27 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~396 ~99 ~27 ~408 minecraft:redstone_wire replace
fill ~105 ~27 ~396 ~105 ~27 ~408 minecraft:redstone_wire replace
fill ~120 ~27 ~396 ~120 ~27 ~408 minecraft:redstone_wire replace
setblock ~123 ~27 ~396 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~396 ~144 ~27 ~408 minecraft:redstone_wire replace
fill ~162 ~27 ~396 ~162 ~27 ~408 minecraft:redstone_wire replace
fill ~204 ~27 ~396 ~204 ~27 ~408 minecraft:redstone_wire replace
fill ~354 ~27 ~396 ~354 ~27 ~408 minecraft:redstone_wire replace
setblock ~114 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~398 ~123 ~27 ~410 minecraft:redstone_wire replace
setblock ~150 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~400 ~114 ~27 ~412 minecraft:redstone_wire replace
fill ~150 ~27 ~400 ~150 ~27 ~412 minecraft:redstone_wire replace
fill ~174 ~27 ~400 ~174 ~27 ~412 minecraft:redstone_wire replace
fill ~189 ~27 ~400 ~189 ~27 ~412 minecraft:redstone_wire replace
fill ~216 ~27 ~400 ~216 ~27 ~412 minecraft:redstone_wire replace
setblock ~222 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~27 ~400 ~237 ~27 ~412 minecraft:redstone_wire replace
fill ~243 ~27 ~400 ~243 ~27 ~412 minecraft:redstone_wire replace
fill ~267 ~27 ~400 ~267 ~27 ~412 minecraft:redstone_wire replace
fill ~315 ~27 ~400 ~315 ~27 ~412 minecraft:redstone_wire replace
setblock ~318 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~400 ~342 ~27 ~412 minecraft:redstone_wire replace
setblock ~345 ~27 ~400 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~402 ~81 ~27 ~414 minecraft:redstone_wire replace
setblock ~117 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~402 ~318 ~27 ~414 minecraft:redstone_wire replace
setblock ~339 ~27 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~402 ~345 ~27 ~414 minecraft:redstone_wire replace
fill ~78 ~27 ~404 ~78 ~27 ~416 minecraft:redstone_wire replace
fill ~117 ~27 ~404 ~117 ~27 ~416 minecraft:redstone_wire replace
fill ~165 ~27 ~404 ~165 ~27 ~416 minecraft:redstone_wire replace
fill ~186 ~27 ~404 ~186 ~27 ~416 minecraft:redstone_wire replace
fill ~192 ~27 ~404 ~192 ~27 ~416 minecraft:redstone_wire replace
fill ~219 ~27 ~404 ~219 ~27 ~416 minecraft:redstone_wire replace
fill ~240 ~27 ~404 ~240 ~27 ~416 minecraft:redstone_wire replace
fill ~246 ~27 ~404 ~246 ~27 ~416 minecraft:redstone_wire replace
setblock ~258 ~27 ~404 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~27 ~404 ~264 ~27 ~416 minecraft:redstone_wire replace
fill ~273 ~27 ~404 ~273 ~27 ~416 minecraft:redstone_wire replace
fill ~339 ~27 ~404 ~339 ~27 ~416 minecraft:redstone_wire replace
setblock ~84 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~408 ~84 ~27 ~418 minecraft:redstone_wire replace
fill ~93 ~27 ~408 ~93 ~27 ~420 minecraft:redstone_wire replace
fill ~96 ~27 ~408 ~96 ~27 ~420 minecraft:redstone_wire replace
fill ~102 ~27 ~408 ~102 ~27 ~420 minecraft:redstone_wire replace
fill ~141 ~27 ~408 ~141 ~27 ~420 minecraft:redstone_wire replace
fill ~201 ~27 ~408 ~201 ~27 ~420 minecraft:redstone_wire replace
setblock ~270 ~27 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~408 minecraft:redstone_wire replace
fill ~291 ~27 ~408 ~291 ~27 ~420 minecraft:redstone_wire replace
fill ~330 ~27 ~408 ~330 ~27 ~420 minecraft:redstone_wire replace
setblock ~333 ~27 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~408 ~336 ~27 ~420 minecraft:redstone_wire replace
fill ~348 ~27 ~408 ~348 ~27 ~420 minecraft:redstone_wire replace
setblock ~351 ~27 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~408 ~357 ~27 ~420 minecraft:redstone_wire replace
setblock ~99 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~410 ~270 ~27 ~422 minecraft:redstone_wire replace
fill ~333 ~27 ~410 ~333 ~27 ~412 minecraft:redstone_wire replace
fill ~351 ~27 ~410 ~351 ~27 ~416 minecraft:redstone_wire replace
setblock ~354 ~27 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~412 ~99 ~27 ~424 minecraft:redstone_wire replace
fill ~105 ~27 ~412 ~105 ~27 ~422 minecraft:redstone_wire replace
fill ~120 ~27 ~412 ~120 ~27 ~424 minecraft:redstone_wire replace
setblock ~123 ~27 ~412 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~412 ~144 ~27 ~424 minecraft:redstone_wire replace
fill ~162 ~27 ~412 ~162 ~27 ~424 minecraft:redstone_wire replace
fill ~204 ~27 ~412 ~204 ~27 ~424 minecraft:redstone_wire replace
fill ~354 ~27 ~412 ~354 ~27 ~424 minecraft:redstone_wire replace
setblock ~114 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~414 ~123 ~27 ~426 minecraft:redstone_wire replace
setblock ~150 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~416 ~114 ~27 ~428 minecraft:redstone_wire replace
fill ~150 ~27 ~416 ~150 ~27 ~428 minecraft:redstone_wire replace
fill ~174 ~27 ~416 ~174 ~27 ~428 minecraft:redstone_wire replace
fill ~189 ~27 ~416 ~189 ~27 ~428 minecraft:redstone_wire replace
fill ~216 ~27 ~416 ~216 ~27 ~428 minecraft:redstone_wire replace
fill ~237 ~27 ~416 ~237 ~27 ~428 minecraft:redstone_wire replace
fill ~243 ~27 ~416 ~243 ~27 ~428 minecraft:redstone_wire replace
fill ~267 ~27 ~416 ~267 ~27 ~428 minecraft:redstone_wire replace
fill ~315 ~27 ~416 ~315 ~27 ~428 minecraft:redstone_wire replace
setblock ~318 ~27 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~416 ~342 ~27 ~428 minecraft:redstone_wire replace
setblock ~345 ~27 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~418 ~81 ~27 ~430 minecraft:redstone_wire replace
setblock ~117 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~418 ~318 ~27 ~430 minecraft:redstone_wire replace
setblock ~339 ~27 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~418 ~345 ~27 ~430 minecraft:redstone_wire replace
fill ~78 ~27 ~420 ~78 ~27 ~432 minecraft:redstone_wire replace
setblock ~84 ~27 ~420 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~420 ~117 ~27 ~432 minecraft:redstone_wire replace
fill ~165 ~27 ~420 ~165 ~27 ~430 minecraft:redstone_wire replace
fill ~186 ~27 ~420 ~186 ~27 ~432 minecraft:redstone_wire replace
fill ~192 ~27 ~420 ~192 ~27 ~432 minecraft:redstone_wire replace
fill ~219 ~27 ~420 ~219 ~27 ~432 minecraft:redstone_wire replace
fill ~240 ~27 ~420 ~240 ~27 ~432 minecraft:redstone_wire replace
fill ~246 ~27 ~420 ~246 ~27 ~432 minecraft:redstone_wire replace
fill ~264 ~27 ~420 ~264 ~27 ~432 minecraft:redstone_wire replace
fill ~273 ~27 ~420 ~273 ~27 ~432 minecraft:redstone_wire replace
fill ~339 ~27 ~420 ~339 ~27 ~432 minecraft:redstone_wire replace
setblock ~93 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~424 ~93 ~27 ~436 minecraft:redstone_wire replace
