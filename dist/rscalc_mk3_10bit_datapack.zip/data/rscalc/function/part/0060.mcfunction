setblock ~160 ~21 ~179 minecraft:redstone_wire replace
setblock ~159 ~21 ~182 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~21 ~182 ~171 ~21 ~182 minecraft:redstone_wire replace
setblock ~160 ~21 ~183 minecraft:redstone_wire replace
fill ~201 ~21 ~186 ~207 ~21 ~186 minecraft:redstone_wire replace
setblock ~202 ~21 ~187 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~21 ~190 ~192 ~21 ~190 minecraft:redstone_wire replace
setblock ~190 ~21 ~191 minecraft:redstone_wire replace
fill ~192 ~21 ~194 ~195 ~21 ~194 minecraft:redstone_wire replace
setblock ~193 ~21 ~195 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~21 ~198 ~198 ~21 ~198 minecraft:redstone_wire replace
setblock ~196 ~21 ~199 minecraft:redstone_wire replace
fill ~195 ~21 ~202 ~201 ~21 ~202 minecraft:redstone_wire replace
setblock ~196 ~21 ~203 minecraft:redstone_wire replace
fill ~216 ~21 ~206 ~219 ~21 ~206 minecraft:redstone_wire replace
setblock ~217 ~21 ~207 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~21 ~210 ~213 ~21 ~210 minecraft:redstone_wire replace
setblock ~211 ~21 ~211 minecraft:redstone_wire replace
fill ~213 ~21 ~214 ~216 ~21 ~214 minecraft:redstone_wire replace
setblock ~214 ~21 ~215 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~21 ~218 ~222 ~21 ~218 minecraft:redstone_wire replace
setblock ~220 ~21 ~219 minecraft:redstone_wire replace
fill ~219 ~21 ~222 ~225 ~21 ~222 minecraft:redstone_wire replace
setblock ~220 ~21 ~223 minecraft:redstone_wire replace
fill ~243 ~21 ~226 ~252 ~21 ~226 minecraft:redstone_wire replace
setblock ~244 ~21 ~227 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~21 ~230 ~255 ~21 ~230 minecraft:redstone_wire replace
setblock ~247 ~21 ~231 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~21 ~234 ~267 ~21 ~234 minecraft:redstone_wire replace
setblock ~259 ~21 ~235 minecraft:redstone_wire replace
fill ~267 ~21 ~238 ~276 ~21 ~238 minecraft:redstone_wire replace
setblock ~268 ~21 ~239 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~21 ~242 ~279 ~21 ~242 minecraft:redstone_wire replace
setblock ~271 ~21 ~243 minecraft:redstone_wire replace
fill ~270 ~21 ~246 ~271 ~21 ~246 minecraft:redstone_wire replace
setblock ~273 ~21 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~21 ~246 ~282 ~21 ~246 minecraft:redstone_wire replace
setblock ~271 ~21 ~247 minecraft:redstone_wire replace
fill ~228 ~21 ~250 ~234 ~21 ~250 minecraft:redstone_wire replace
setblock ~229 ~21 ~251 minecraft:redstone_wire replace
fill ~234 ~21 ~254 ~240 ~21 ~254 minecraft:redstone_wire replace
setblock ~235 ~21 ~255 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~21 ~258 ~243 ~21 ~258 minecraft:redstone_wire replace
setblock ~238 ~21 ~259 minecraft:redstone_wire replace
fill ~237 ~21 ~262 ~246 ~21 ~262 minecraft:redstone_wire replace
setblock ~238 ~21 ~263 minecraft:redstone_wire replace
fill ~252 ~21 ~266 ~261 ~21 ~266 minecraft:redstone_wire replace
setblock ~253 ~21 ~267 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~21 ~270 ~273 ~21 ~270 minecraft:redstone_wire replace
setblock ~265 ~21 ~271 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~21 ~274 ~288 ~21 ~274 minecraft:redstone_wire replace
setblock ~277 ~21 ~275 minecraft:redstone_wire replace
fill ~279 ~21 ~278 ~291 ~21 ~278 minecraft:redstone_wire replace
setblock ~280 ~21 ~279 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~21 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~21 ~282 ~294 ~21 ~282 minecraft:redstone_wire replace
setblock ~283 ~21 ~283 minecraft:redstone_wire replace
fill ~282 ~21 ~286 ~286 ~21 ~286 minecraft:redstone_wire replace
setblock ~288 ~21 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~21 ~286 ~297 ~21 ~286 minecraft:redstone_wire replace
setblock ~283 ~21 ~287 minecraft:redstone_wire replace
fill ~135 ~21 ~290 ~146 ~21 ~290 minecraft:redstone_wire replace
setblock ~148 ~21 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~21 ~290 ~163 ~21 ~290 minecraft:redstone_wire replace
setblock ~164 ~21 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~21 ~290 ~189 ~21 ~290 minecraft:redstone_wire replace
setblock ~191 ~21 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~21 ~290 ~206 ~21 ~290 minecraft:redstone_wire replace
setblock ~136 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~21 ~291 minecraft:redstone_wire replace
setblock ~166 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~21 ~291 minecraft:redstone_wire replace
setblock ~178 ~21 ~291 minecraft:redstone_wire replace
setblock ~184 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~21 ~291 minecraft:redstone_wire replace
setblock ~205 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~21 ~294 ~139 ~21 ~294 minecraft:redstone_wire replace
setblock ~141 ~21 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~21 ~294 ~156 ~21 ~294 minecraft:redstone_wire replace
setblock ~158 ~21 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~21 ~294 ~173 ~21 ~294 minecraft:redstone_wire replace
setblock ~174 ~21 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~21 ~294 ~185 ~21 ~294 minecraft:redstone_wire replace
setblock ~186 ~21 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~21 ~294 ~200 ~21 ~294 minecraft:redstone_wire replace
setblock ~202 ~21 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~21 ~294 ~206 ~21 ~294 minecraft:redstone_wire replace
setblock ~136 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~21 ~295 minecraft:redstone_wire replace
setblock ~166 ~21 ~295 minecraft:redstone_wire replace
setblock ~172 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~21 ~295 minecraft:redstone_wire replace
setblock ~187 ~21 ~295 minecraft:redstone_wire replace
setblock ~205 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~21 ~298 ~164 ~21 ~298 minecraft:redstone_wire replace
setblock ~165 ~21 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~21 ~298 ~178 ~21 ~298 minecraft:redstone_wire replace
setblock ~179 ~21 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~21 ~298 ~193 ~21 ~298 minecraft:redstone_wire replace
setblock ~195 ~21 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~197 ~21 ~298 ~206 ~21 ~298 minecraft:redstone_wire replace
setblock ~163 ~21 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~21 ~299 minecraft:redstone_wire replace
setblock ~172 ~21 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~21 ~299 minecraft:redstone_wire replace
setblock ~184 ~21 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~21 ~299 minecraft:redstone_wire replace
setblock ~205 ~21 ~299 minecraft:redstone_wire replace
fill ~285 ~21 ~302 ~287 ~21 ~302 minecraft:redstone_wire replace
setblock ~288 ~21 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~21 ~302 ~300 ~21 ~302 minecraft:redstone_wire replace
setblock ~286 ~21 ~303 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~21 ~306 ~228 ~21 ~306 minecraft:redstone_wire replace
setblock ~223 ~21 ~307 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~79 ~22 ~12 minecraft:redstone_wire replace
setblock ~103 ~22 ~16 minecraft:redstone_wire replace
setblock ~91 ~22 ~20 minecraft:redstone_wire replace
setblock ~109 ~22 ~24 minecraft:redstone_wire replace
setblock ~106 ~22 ~28 minecraft:redstone_wire replace
setblock ~124 ~22 ~32 minecraft:redstone_wire replace
setblock ~127 ~22 ~36 minecraft:redstone_wire replace
setblock ~145 ~22 ~40 minecraft:redstone_wire replace
setblock ~151 ~22 ~44 minecraft:redstone_wire replace
setblock ~169 ~22 ~48 minecraft:redstone_wire replace
setblock ~175 ~22 ~52 minecraft:redstone_wire replace
setblock ~199 ~22 ~56 minecraft:redstone_wire replace
setblock ~208 ~22 ~60 minecraft:redstone_wire replace
setblock ~232 ~22 ~64 minecraft:redstone_wire replace
setblock ~241 ~22 ~68 minecraft:redstone_wire replace
setblock ~256 ~22 ~72 minecraft:redstone_wire replace
setblock ~226 ~22 ~76 minecraft:redstone_wire replace
setblock ~262 ~22 ~80 minecraft:redstone_wire replace
setblock ~250 ~22 ~84 minecraft:redstone_wire replace
setblock ~274 ~22 ~88 minecraft:redstone_wire replace
setblock ~82 ~22 ~92 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~22 ~96 minecraft:redstone_wire replace
setblock ~88 ~22 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~22 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~22 ~108 minecraft:redstone_wire replace
setblock ~94 ~22 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~22 ~116 minecraft:redstone_wire replace
setblock ~100 ~22 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~22 ~124 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~22 ~128 minecraft:redstone_wire replace
setblock ~112 ~22 ~132 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~22 ~136 minecraft:redstone_wire replace
setblock ~118 ~22 ~140 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~22 ~144 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~22 ~148 minecraft:redstone_wire replace
setblock ~130 ~22 ~152 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~22 ~156 minecraft:redstone_wire replace
setblock ~142 ~22 ~160 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~22 ~164 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~22 ~168 minecraft:redstone_wire replace
setblock ~154 ~22 ~172 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~22 ~176 minecraft:redstone_wire replace
setblock ~160 ~22 ~180 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~22 ~184 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~22 ~188 minecraft:redstone_wire replace
setblock ~190 ~22 ~192 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~22 ~196 minecraft:redstone_wire replace
setblock ~196 ~22 ~200 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~22 ~204 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~22 ~208 minecraft:redstone_wire replace
setblock ~211 ~22 ~212 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~22 ~216 minecraft:redstone_wire replace
setblock ~220 ~22 ~220 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~22 ~224 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~22 ~228 minecraft:redstone_wire replace
setblock ~247 ~22 ~232 minecraft:redstone_wire replace
setblock ~259 ~22 ~236 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~22 ~240 minecraft:redstone_wire replace
setblock ~271 ~22 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~22 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~22 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~22 ~256 minecraft:redstone_wire replace
setblock ~238 ~22 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~22 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~22 ~268 minecraft:redstone_wire replace
setblock ~265 ~22 ~272 minecraft:redstone_wire replace
setblock ~277 ~22 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~22 ~280 minecraft:redstone_wire replace
setblock ~283 ~22 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~22 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~22 ~292 minecraft:redstone_wire replace
setblock ~163 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~22 ~292 minecraft:redstone_wire replace
setblock ~172 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~22 ~292 minecraft:redstone_wire replace
setblock ~187 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~22 ~292 minecraft:redstone_wire replace
setblock ~136 ~22 ~296 minecraft:redstone_wire replace
setblock ~163 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~22 ~296 minecraft:redstone_wire replace
setblock ~178 ~22 ~296 minecraft:redstone_wire replace
setblock ~184 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~22 ~296 minecraft:redstone_wire replace
setblock ~163 ~22 ~300 minecraft:redstone_wire replace
setblock ~166 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~22 ~300 minecraft:redstone_wire replace
setblock ~178 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~22 ~300 minecraft:redstone_wire replace
setblock ~187 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~22 ~304 minecraft:redstone_wire replace
setblock ~223 ~22 ~308 minecraft:redstone_wire replace
fill ~78 ~23 ~8 ~78 ~23 ~12 minecraft:redstone_wire replace
fill ~102 ~23 ~12 ~102 ~23 ~16 minecraft:redstone_wire replace
fill ~90 ~23 ~16 ~90 ~23 ~20 minecraft:redstone_wire replace
fill ~108 ~23 ~20 ~108 ~23 ~24 minecraft:redstone_wire replace
fill ~105 ~23 ~24 ~105 ~23 ~28 minecraft:redstone_wire replace
fill ~123 ~23 ~28 ~123 ~23 ~32 minecraft:redstone_wire replace
fill ~126 ~23 ~32 ~126 ~23 ~36 minecraft:redstone_wire replace
fill ~144 ~23 ~36 ~144 ~23 ~40 minecraft:redstone_wire replace
fill ~150 ~23 ~40 ~150 ~23 ~44 minecraft:redstone_wire replace
fill ~168 ~23 ~44 ~168 ~23 ~48 minecraft:redstone_wire replace
fill ~174 ~23 ~48 ~174 ~23 ~52 minecraft:redstone_wire replace
fill ~198 ~23 ~52 ~198 ~23 ~56 minecraft:redstone_wire replace
fill ~207 ~23 ~56 ~207 ~23 ~60 minecraft:redstone_wire replace
fill ~231 ~23 ~60 ~231 ~23 ~64 minecraft:redstone_wire replace
fill ~240 ~23 ~64 ~240 ~23 ~68 minecraft:redstone_wire replace
fill ~255 ~23 ~68 ~255 ~23 ~72 minecraft:redstone_wire replace
fill ~225 ~23 ~72 ~225 ~23 ~76 minecraft:redstone_wire replace
fill ~261 ~23 ~76 ~261 ~23 ~80 minecraft:redstone_wire replace
fill ~249 ~23 ~80 ~249 ~23 ~84 minecraft:redstone_wire replace
fill ~273 ~23 ~84 ~273 ~23 ~88 minecraft:redstone_wire replace
fill ~81 ~23 ~88 ~81 ~23 ~92 minecraft:redstone_wire replace
fill ~84 ~23 ~92 ~84 ~23 ~96 minecraft:redstone_wire replace
setblock ~87 ~23 ~96 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~23 ~98 ~87 ~23 ~104 minecraft:redstone_wire replace
fill ~120 ~23 ~104 ~120 ~23 ~108 minecraft:redstone_wire replace
fill ~93 ~23 ~108 ~93 ~23 ~112 minecraft:redstone_wire replace
fill ~96 ~23 ~112 ~96 ~23 ~116 minecraft:redstone_wire replace
setblock ~99 ~23 ~116 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~23 ~118 ~99 ~23 ~124 minecraft:redstone_wire replace
fill ~132 ~23 ~124 ~132 ~23 ~128 minecraft:redstone_wire replace
fill ~111 ~23 ~128 ~111 ~23 ~132 minecraft:redstone_wire replace
fill ~114 ~23 ~132 ~114 ~23 ~136 minecraft:redstone_wire replace
setblock ~117 ~23 ~136 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~23 ~138 ~117 ~23 ~144 minecraft:redstone_wire replace
fill ~147 ~23 ~144 ~147 ~23 ~148 minecraft:redstone_wire replace
fill ~129 ~23 ~148 ~129 ~23 ~152 minecraft:redstone_wire replace
fill ~138 ~23 ~152 ~138 ~23 ~156 minecraft:redstone_wire replace
setblock ~141 ~23 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~23 ~158 ~141 ~23 ~164 minecraft:redstone_wire replace
setblock ~180 ~23 ~160 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~23 ~162 ~180 ~23 ~168 minecraft:redstone_wire replace
setblock ~153 ~23 ~164 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~23 ~166 ~153 ~23 ~172 minecraft:redstone_wire replace
setblock ~156 ~23 ~168 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~23 ~170 ~156 ~23 ~176 minecraft:redstone_wire replace
setblock ~159 ~23 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~23 ~174 ~159 ~23 ~184 minecraft:redstone_wire replace
setblock ~201 ~23 ~176 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~23 ~178 ~201 ~23 ~188 minecraft:redstone_wire replace
setblock ~189 ~23 ~180 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~23 ~182 ~189 ~23 ~192 minecraft:redstone_wire replace
setblock ~192 ~23 ~184 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~23 ~186 ~192 ~23 ~196 minecraft:redstone_wire replace
setblock ~195 ~23 ~188 minecraft:redstone_wire replace
setblock ~195 ~23 ~190 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~23 ~192 ~195 ~23 ~204 minecraft:redstone_wire replace
setblock ~216 ~23 ~192 minecraft:redstone_wire replace
setblock ~216 ~23 ~194 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~23 ~196 minecraft:redstone_wire replace
fill ~216 ~23 ~196 ~216 ~23 ~208 minecraft:redstone_wire replace
setblock ~210 ~23 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~23 ~200 ~210 ~23 ~212 minecraft:redstone_wire replace
setblock ~213 ~23 ~200 minecraft:redstone_wire replace
setblock ~213 ~23 ~202 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~213 ~23 ~204 ~213 ~23 ~216 minecraft:redstone_wire replace
fill ~219 ~23 ~204 ~219 ~23 ~208 minecraft:redstone_wire replace
fill ~243 ~23 ~208 ~243 ~23 ~212 minecraft:redstone_wire replace
setblock ~219 ~23 ~210 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~219 ~23 ~212 ~219 ~23 ~224 minecraft:redstone_wire replace
fill ~246 ~23 ~212 ~246 ~23 ~216 minecraft:redstone_wire replace
setblock ~243 ~23 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~23 ~216 ~243 ~23 ~228 minecraft:redstone_wire replace
fill ~258 ~23 ~216 ~258 ~23 ~220 minecraft:redstone_wire replace
setblock ~246 ~23 ~218 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~23 ~220 ~246 ~23 ~232 minecraft:redstone_wire replace
fill ~267 ~23 ~220 ~267 ~23 ~224 minecraft:redstone_wire replace
setblock ~258 ~23 ~222 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~23 ~224 ~258 ~23 ~236 minecraft:redstone_wire replace
setblock ~270 ~23 ~224 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~267 ~23 ~226 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~23 ~226 ~270 ~23 ~232 minecraft:redstone_wire replace
setblock ~228 ~23 ~228 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~23 ~228 ~267 ~23 ~240 minecraft:redstone_wire replace
fill ~228 ~23 ~230 ~228 ~23 ~236 minecraft:redstone_wire replace
setblock ~234 ~23 ~232 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~234 ~23 ~234 ~234 ~23 ~240 minecraft:redstone_wire replace
setblock ~270 ~23 ~234 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~237 ~23 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~23 ~236 ~270 ~23 ~248 minecraft:redstone_wire replace
setblock ~228 ~23 ~238 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~23 ~238 ~237 ~23 ~248 minecraft:redstone_wire replace
fill ~228 ~23 ~240 ~228 ~23 ~252 minecraft:redstone_wire replace
setblock ~252 ~23 ~240 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~234 ~23 ~242 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~23 ~242 ~252 ~23 ~252 minecraft:redstone_wire replace
fill ~234 ~23 ~244 ~234 ~23 ~256 minecraft:redstone_wire replace
setblock ~264 ~23 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~23 ~246 ~264 ~23 ~256 minecraft:redstone_wire replace
setblock ~276 ~23 ~248 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~237 ~23 ~250 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~23 ~250 ~276 ~23 ~260 minecraft:redstone_wire replace
fill ~237 ~23 ~252 ~237 ~23 ~264 minecraft:redstone_wire replace
setblock ~279 ~23 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~23 ~254 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~23 ~254 ~279 ~23 ~264 minecraft:redstone_wire replace
fill ~252 ~23 ~256 ~252 ~23 ~268 minecraft:redstone_wire replace
setblock ~282 ~23 ~256 minecraft:redstone_wire replace
setblock ~264 ~23 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~282 ~23 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~23 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~23 ~260 ~264 ~23 ~272 minecraft:redstone_wire replace
fill ~282 ~23 ~260 ~282 ~23 ~272 minecraft:redstone_wire replace
fill ~204 ~23 ~262 ~204 ~23 ~268 minecraft:redstone_wire replace
setblock ~276 ~23 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~23 ~264 ~186 ~23 ~268 minecraft:redstone_wire replace
fill ~276 ~23 ~264 ~276 ~23 ~276 minecraft:redstone_wire replace
setblock ~279 ~23 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~23 ~268 minecraft:redstone_wire replace
fill ~279 ~23 ~268 ~279 ~23 ~280 minecraft:redstone_wire replace
setblock ~183 ~23 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~23 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~23 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~23 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~23 ~272 ~183 ~23 ~284 minecraft:redstone_wire replace
fill ~186 ~23 ~272 ~186 ~23 ~284 minecraft:redstone_wire replace
fill ~204 ~23 ~272 ~204 ~23 ~284 minecraft:redstone_wire replace
fill ~177 ~23 ~274 ~177 ~23 ~284 minecraft:redstone_wire replace
setblock ~282 ~23 ~274 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~23 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~23 ~276 ~282 ~23 ~288 minecraft:redstone_wire replace
fill ~171 ~23 ~278 ~171 ~23 ~284 minecraft:redstone_wire replace
fill ~165 ~23 ~280 ~165 ~23 ~284 minecraft:redstone_wire replace
setblock ~162 ~23 ~284 minecraft:redstone_wire replace
setblock ~162 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~23 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~23 ~288 ~162 ~23 ~300 minecraft:redstone_wire replace
fill ~165 ~23 ~288 ~165 ~23 ~300 minecraft:redstone_wire replace
fill ~171 ~23 ~288 ~171 ~23 ~300 minecraft:redstone_wire replace
fill ~177 ~23 ~288 ~177 ~23 ~300 minecraft:redstone_wire replace
fill ~183 ~23 ~288 ~183 ~23 ~300 minecraft:redstone_wire replace
fill ~186 ~23 ~288 ~186 ~23 ~300 minecraft:redstone_wire replace
fill ~204 ~23 ~288 ~204 ~23 ~300 minecraft:redstone_wire replace
fill ~135 ~23 ~290 ~135 ~23 ~296 minecraft:redstone_wire replace
fill ~285 ~23 ~300 ~285 ~23 ~304 minecraft:redstone_wire replace
fill ~222 ~23 ~304 ~222 ~23 ~308 minecraft:redstone_wire replace
setblock ~78 ~24 ~7 minecraft:redstone_wire replace
setblock ~102 ~24 ~11 minecraft:redstone_wire replace
setblock ~90 ~24 ~15 minecraft:redstone_wire replace
setblock ~108 ~24 ~19 minecraft:redstone_wire replace
setblock ~105 ~24 ~23 minecraft:redstone_wire replace
setblock ~123 ~24 ~27 minecraft:redstone_wire replace
setblock ~126 ~24 ~31 minecraft:redstone_wire replace
setblock ~144 ~24 ~35 minecraft:redstone_wire replace
setblock ~150 ~24 ~39 minecraft:redstone_wire replace
setblock ~168 ~24 ~43 minecraft:redstone_wire replace
setblock ~174 ~24 ~47 minecraft:redstone_wire replace
setblock ~198 ~24 ~51 minecraft:redstone_wire replace
setblock ~207 ~24 ~55 minecraft:redstone_wire replace
setblock ~231 ~24 ~59 minecraft:redstone_wire replace
setblock ~240 ~24 ~63 minecraft:redstone_wire replace
setblock ~255 ~24 ~67 minecraft:redstone_wire replace
setblock ~225 ~24 ~71 minecraft:redstone_wire replace
setblock ~261 ~24 ~75 minecraft:redstone_wire replace
setblock ~249 ~24 ~79 minecraft:redstone_wire replace
setblock ~273 ~24 ~83 minecraft:redstone_wire replace
setblock ~81 ~24 ~87 minecraft:redstone_wire replace
setblock ~84 ~24 ~91 minecraft:redstone_wire replace
setblock ~87 ~24 ~95 minecraft:redstone_wire replace
setblock ~120 ~24 ~103 minecraft:redstone_wire replace
setblock ~93 ~24 ~107 minecraft:redstone_wire replace
setblock ~96 ~24 ~111 minecraft:redstone_wire replace
setblock ~99 ~24 ~115 minecraft:redstone_wire replace
setblock ~132 ~24 ~123 minecraft:redstone_wire replace
setblock ~111 ~24 ~127 minecraft:redstone_wire replace
setblock ~114 ~24 ~131 minecraft:redstone_wire replace
setblock ~117 ~24 ~135 minecraft:redstone_wire replace
setblock ~147 ~24 ~143 minecraft:redstone_wire replace
setblock ~129 ~24 ~147 minecraft:redstone_wire replace
setblock ~138 ~24 ~151 minecraft:redstone_wire replace
setblock ~141 ~24 ~155 minecraft:redstone_wire replace
setblock ~180 ~24 ~159 minecraft:redstone_wire replace
setblock ~153 ~24 ~163 minecraft:redstone_wire replace
setblock ~156 ~24 ~167 minecraft:redstone_wire replace
setblock ~159 ~24 ~171 minecraft:redstone_wire replace
setblock ~201 ~24 ~175 minecraft:redstone_wire replace
setblock ~189 ~24 ~179 minecraft:redstone_wire replace
setblock ~192 ~24 ~183 minecraft:redstone_wire replace
setblock ~195 ~24 ~187 minecraft:redstone_wire replace
setblock ~216 ~24 ~191 minecraft:redstone_wire replace
setblock ~210 ~24 ~195 minecraft:redstone_wire replace
setblock ~213 ~24 ~199 minecraft:redstone_wire replace
setblock ~219 ~24 ~203 minecraft:redstone_wire replace
setblock ~243 ~24 ~207 minecraft:redstone_wire replace
setblock ~246 ~24 ~211 minecraft:redstone_wire replace
setblock ~258 ~24 ~215 minecraft:redstone_wire replace
setblock ~267 ~24 ~219 minecraft:redstone_wire replace
setblock ~270 ~24 ~223 minecraft:redstone_wire replace
setblock ~228 ~24 ~227 minecraft:redstone_wire replace
setblock ~234 ~24 ~231 minecraft:redstone_wire replace
setblock ~237 ~24 ~235 minecraft:redstone_wire replace
setblock ~252 ~24 ~239 minecraft:redstone_wire replace
setblock ~264 ~24 ~243 minecraft:redstone_wire replace
setblock ~276 ~24 ~247 minecraft:redstone_wire replace
setblock ~279 ~24 ~251 minecraft:redstone_wire replace
setblock ~282 ~24 ~255 minecraft:redstone_wire replace
setblock ~204 ~24 ~259 minecraft:redstone_wire replace
setblock ~186 ~24 ~263 minecraft:redstone_wire replace
setblock ~183 ~24 ~267 minecraft:redstone_wire replace
setblock ~177 ~24 ~271 minecraft:redstone_wire replace
setblock ~171 ~24 ~275 minecraft:redstone_wire replace
setblock ~165 ~24 ~279 minecraft:redstone_wire replace
setblock ~162 ~24 ~283 minecraft:redstone_wire replace
setblock ~135 ~24 ~287 minecraft:redstone_wire replace
setblock ~285 ~24 ~299 minecraft:redstone_wire replace
setblock ~222 ~24 ~303 minecraft:redstone_wire replace
setblock ~79 ~25 ~5 minecraft:redstone_wire replace
fill ~78 ~25 ~6 ~80 ~25 ~6 minecraft:redstone_wire replace
setblock ~97 ~25 ~9 minecraft:redstone_wire replace
setblock ~127 ~25 ~9 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~25 ~10 ~108 ~25 ~10 minecraft:redstone_wire replace
setblock ~110 ~25 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~25 ~10 ~125 ~25 ~10 minecraft:redstone_wire replace
setblock ~126 ~25 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~25 ~10 ~128 ~25 ~10 minecraft:redstone_wire replace
setblock ~100 ~25 ~13 minecraft:redstone_wire replace
fill ~90 ~25 ~14 ~96 ~25 ~14 minecraft:redstone_wire replace
setblock ~98 ~25 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~100 ~25 ~14 ~101 ~25 ~14 minecraft:redstone_wire replace
setblock ~91 ~25 ~17 minecraft:redstone_wire replace
setblock ~115 ~25 ~17 minecraft:redstone_wire replace
setblock ~154 ~25 ~17 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~25 ~18 ~98 ~25 ~18 minecraft:redstone_wire replace
setblock ~100 ~25 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~25 ~18 ~113 ~25 ~18 minecraft:redstone_wire replace
setblock ~114 ~25 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~25 ~18 ~127 ~25 ~18 minecraft:redstone_wire replace
setblock ~129 ~25 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~131 ~25 ~18 ~143 ~25 ~18 minecraft:redstone_wire replace
setblock ~145 ~25 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~25 ~18 ~155 ~25 ~18 minecraft:redstone_wire replace
setblock ~118 ~25 ~21 minecraft:redstone_wire replace
fill ~105 ~25 ~22 ~111 ~25 ~22 minecraft:redstone_wire replace
setblock ~113 ~25 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~25 ~22 ~119 ~25 ~22 minecraft:redstone_wire replace
setblock ~112 ~25 ~25 minecraft:redstone_wire replace
setblock ~142 ~25 ~25 minecraft:redstone_wire replace
setblock ~178 ~25 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~25 ~26 ~113 ~25 ~26 minecraft:redstone_wire replace
setblock ~115 ~25 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~25 ~26 ~129 ~25 ~26 minecraft:redstone_wire replace
setblock ~131 ~25 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~25 ~26 ~146 ~25 ~26 minecraft:redstone_wire replace
setblock ~148 ~25 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~25 ~26 ~163 ~25 ~26 minecraft:redstone_wire replace
setblock ~165 ~25 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~167 ~25 ~26 ~179 ~25 ~26 minecraft:redstone_wire replace
setblock ~145 ~25 ~29 minecraft:redstone_wire replace
fill ~126 ~25 ~30 ~132 ~25 ~30 minecraft:redstone_wire replace
setblock ~134 ~25 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~25 ~30 ~146 ~25 ~30 minecraft:redstone_wire replace
setblock ~139 ~25 ~33 minecraft:redstone_wire replace
setblock ~175 ~25 ~33 minecraft:redstone_wire replace
setblock ~208 ~25 ~33 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~25 ~34 ~150 ~25 ~34 minecraft:redstone_wire replace
setblock ~152 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~154 ~25 ~34 ~167 ~25 ~34 minecraft:redstone_wire replace
setblock ~169 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~25 ~34 ~184 ~25 ~34 minecraft:redstone_wire replace
setblock ~186 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~188 ~25 ~34 ~201 ~25 ~34 minecraft:redstone_wire replace
setblock ~203 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~25 ~34 ~209 ~25 ~34 minecraft:redstone_wire replace
setblock ~187 ~25 ~37 minecraft:redstone_wire replace
fill ~150 ~25 ~38 ~156 ~25 ~38 minecraft:redstone_wire replace
setblock ~158 ~25 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~25 ~38 ~173 ~25 ~38 minecraft:redstone_wire replace
setblock ~175 ~25 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~25 ~38 ~188 ~25 ~38 minecraft:redstone_wire replace
setblock ~172 ~25 ~41 minecraft:redstone_wire replace
setblock ~202 ~25 ~41 minecraft:redstone_wire replace
setblock ~226 ~25 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~25 ~42 ~173 ~25 ~42 minecraft:redstone_wire replace
setblock ~175 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~25 ~42 ~189 ~25 ~42 minecraft:redstone_wire replace
setblock ~191 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~25 ~42 ~205 ~25 ~42 minecraft:redstone_wire replace
setblock ~207 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~209 ~25 ~42 ~221 ~25 ~42 minecraft:redstone_wire replace
setblock ~223 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~25 ~42 ~227 ~25 ~42 minecraft:redstone_wire replace
setblock ~205 ~25 ~45 minecraft:redstone_wire replace
fill ~174 ~25 ~46 ~180 ~25 ~46 minecraft:redstone_wire replace
setblock ~182 ~25 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~184 ~25 ~46 ~197 ~25 ~46 minecraft:redstone_wire replace
setblock ~199 ~25 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~201 ~25 ~46 ~206 ~25 ~46 minecraft:redstone_wire replace
setblock ~199 ~25 ~49 minecraft:redstone_wire replace
setblock ~238 ~25 ~49 minecraft:redstone_wire replace
setblock ~250 ~25 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~25 ~50 ~204 ~25 ~50 minecraft:redstone_wire replace
setblock ~206 ~25 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~25 ~50 ~221 ~25 ~50 minecraft:redstone_wire replace
setblock ~223 ~25 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~25 ~50 ~238 ~25 ~50 minecraft:redstone_wire replace
setblock ~239 ~25 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~25 ~50 ~251 ~25 ~50 minecraft:redstone_wire replace
setblock ~241 ~25 ~53 minecraft:redstone_wire replace
fill ~207 ~25 ~54 ~213 ~25 ~54 minecraft:redstone_wire replace
setblock ~215 ~25 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~25 ~54 ~230 ~25 ~54 minecraft:redstone_wire replace
setblock ~232 ~25 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~25 ~54 ~242 ~25 ~54 minecraft:redstone_wire replace
setblock ~235 ~25 ~57 minecraft:redstone_wire replace
setblock ~283 ~25 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~25 ~57 minecraft:redstone_wire replace
fill ~231 ~25 ~58 ~237 ~25 ~58 minecraft:redstone_wire replace
setblock ~239 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~25 ~58 ~254 ~25 ~58 minecraft:redstone_wire replace
setblock ~256 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~258 ~25 ~58 ~271 ~25 ~58 minecraft:redstone_wire replace
setblock ~273 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~275 ~25 ~58 ~288 ~25 ~58 minecraft:redstone_wire replace
setblock ~290 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~58 ~293 ~25 ~58 minecraft:redstone_wire replace
setblock ~262 ~25 ~61 minecraft:redstone_wire replace
setblock ~271 ~25 ~61 minecraft:redstone_wire replace
setblock ~301 ~25 ~61 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~240 ~25 ~62 ~246 ~25 ~62 minecraft:redstone_wire replace
setblock ~248 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~25 ~62 ~263 ~25 ~62 minecraft:redstone_wire replace
setblock ~265 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~25 ~62 ~280 ~25 ~62 minecraft:redstone_wire replace
setblock ~282 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~284 ~25 ~62 ~297 ~25 ~62 minecraft:redstone_wire replace
setblock ~299 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~25 ~62 ~302 ~25 ~62 minecraft:redstone_wire replace
setblock ~316 ~25 ~65 minecraft:redstone_wire replace
fill ~255 ~25 ~66 ~261 ~25 ~66 minecraft:redstone_wire replace
setblock ~263 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~25 ~66 ~278 ~25 ~66 minecraft:redstone_wire replace
setblock ~280 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~25 ~66 ~295 ~25 ~66 minecraft:redstone_wire replace
setblock ~297 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~299 ~25 ~66 ~312 ~25 ~66 minecraft:redstone_wire replace
setblock ~314 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~316 ~25 ~66 ~317 ~25 ~66 minecraft:redstone_wire replace
setblock ~265 ~25 ~69 minecraft:redstone_wire replace
fill ~225 ~25 ~70 ~231 ~25 ~70 minecraft:redstone_wire replace
setblock ~233 ~25 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~25 ~70 ~248 ~25 ~70 minecraft:redstone_wire replace
setblock ~250 ~25 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~25 ~70 ~265 ~25 ~70 minecraft:redstone_wire replace
setblock ~266 ~25 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~310 ~25 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~25 ~73 minecraft:redstone_wire replace
setblock ~337 ~25 ~73 minecraft:redstone_wire replace
fill ~261 ~25 ~74 ~267 ~25 ~74 minecraft:redstone_wire replace
setblock ~269 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~271 ~25 ~74 ~284 ~25 ~74 minecraft:redstone_wire replace
setblock ~286 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~25 ~74 ~301 ~25 ~74 minecraft:redstone_wire replace
setblock ~303 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~305 ~25 ~74 ~318 ~25 ~74 minecraft:redstone_wire replace
setblock ~320 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~322 ~25 ~74 ~335 ~25 ~74 minecraft:redstone_wire replace
setblock ~336 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~25 ~74 ~338 ~25 ~74 minecraft:redstone_wire replace
setblock ~280 ~25 ~77 minecraft:redstone_wire replace
setblock ~328 ~25 ~77 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~25 ~78 ~255 ~25 ~78 minecraft:redstone_wire replace
setblock ~257 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~25 ~78 ~272 ~25 ~78 minecraft:redstone_wire replace
setblock ~274 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~25 ~78 ~289 ~25 ~78 minecraft:redstone_wire replace
setblock ~291 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~293 ~25 ~78 ~306 ~25 ~78 minecraft:redstone_wire replace
setblock ~308 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~25 ~78 ~323 ~25 ~78 minecraft:redstone_wire replace
setblock ~325 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~25 ~78 ~329 ~25 ~78 minecraft:redstone_wire replace
setblock ~343 ~25 ~81 minecraft:redstone_wire replace
fill ~273 ~25 ~82 ~279 ~25 ~82 minecraft:redstone_wire replace
setblock ~281 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~25 ~82 ~296 ~25 ~82 minecraft:redstone_wire replace
