fill ~59 ~0 ~92 ~60 ~0 ~92 minecraft:glass replace
fill ~59 ~0 ~93 ~60 ~0 ~93 minecraft:glass replace
fill ~53 ~0 ~94 ~58 ~0 ~94 minecraft:light_gray_concrete replace
fill ~59 ~0 ~94 ~60 ~0 ~94 minecraft:glass replace
fill ~59 ~0 ~95 ~60 ~0 ~95 minecraft:glass replace
fill ~49 ~0 ~96 ~58 ~0 ~96 minecraft:light_gray_concrete replace
fill ~59 ~0 ~96 ~60 ~0 ~96 minecraft:glass replace
fill ~59 ~0 ~97 ~60 ~0 ~97 minecraft:glass replace
fill ~45 ~0 ~98 ~58 ~0 ~98 minecraft:light_gray_concrete replace
fill ~59 ~0 ~98 ~60 ~0 ~98 minecraft:glass replace
fill ~59 ~0 ~99 ~60 ~0 ~99 minecraft:glass replace
fill ~41 ~0 ~100 ~58 ~0 ~100 minecraft:light_gray_concrete replace
fill ~59 ~0 ~100 ~60 ~0 ~100 minecraft:glass replace
fill ~59 ~0 ~101 ~60 ~0 ~101 minecraft:glass replace
fill ~37 ~0 ~102 ~58 ~0 ~102 minecraft:light_gray_concrete replace
fill ~59 ~0 ~102 ~60 ~0 ~102 minecraft:glass replace
fill ~59 ~0 ~103 ~60 ~0 ~103 minecraft:glass replace
fill ~33 ~0 ~104 ~58 ~0 ~104 minecraft:light_gray_concrete replace
fill ~59 ~0 ~104 ~60 ~0 ~104 minecraft:glass replace
fill ~59 ~0 ~105 ~60 ~0 ~105 minecraft:glass replace
fill ~29 ~0 ~106 ~58 ~0 ~106 minecraft:light_gray_concrete replace
fill ~59 ~0 ~106 ~60 ~0 ~106 minecraft:glass replace
fill ~59 ~0 ~107 ~60 ~0 ~107 minecraft:glass replace
fill ~25 ~0 ~108 ~58 ~0 ~108 minecraft:light_gray_concrete replace
fill ~59 ~0 ~108 ~60 ~0 ~108 minecraft:glass replace
fill ~59 ~0 ~109 ~60 ~0 ~109 minecraft:glass replace
fill ~21 ~0 ~110 ~58 ~0 ~110 minecraft:light_gray_concrete replace
fill ~59 ~0 ~110 ~60 ~0 ~110 minecraft:glass replace
fill ~59 ~0 ~111 ~60 ~0 ~111 minecraft:glass replace
fill ~17 ~0 ~112 ~58 ~0 ~112 minecraft:light_gray_concrete replace
fill ~59 ~0 ~112 ~60 ~0 ~112 minecraft:glass replace
fill ~59 ~0 ~113 ~60 ~0 ~113 minecraft:glass replace
fill ~13 ~0 ~114 ~58 ~0 ~114 minecraft:light_gray_concrete replace
fill ~59 ~0 ~114 ~60 ~0 ~114 minecraft:glass replace
fill ~59 ~0 ~115 ~60 ~0 ~115 minecraft:glass replace
fill ~9 ~0 ~116 ~58 ~0 ~116 minecraft:light_gray_concrete replace
fill ~59 ~0 ~116 ~60 ~0 ~116 minecraft:glass replace
fill ~59 ~0 ~117 ~60 ~0 ~117 minecraft:glass replace
fill ~5 ~0 ~118 ~58 ~0 ~118 minecraft:light_gray_concrete replace
fill ~59 ~0 ~118 ~60 ~0 ~118 minecraft:glass replace
fill ~59 ~0 ~119 ~60 ~0 ~119 minecraft:glass replace
fill ~1 ~0 ~120 ~58 ~0 ~120 minecraft:light_gray_concrete replace
fill ~59 ~0 ~120 ~60 ~0 ~120 minecraft:glass replace
fill ~59 ~0 ~121 ~60 ~0 ~121 minecraft:glass replace
fill ~59 ~0 ~122 ~60 ~0 ~122 minecraft:glass replace
setblock ~52 ~1 ~94 minecraft:light_gray_concrete replace
setblock ~48 ~1 ~96 minecraft:light_gray_concrete replace
setblock ~44 ~1 ~98 minecraft:light_gray_concrete replace
setblock ~40 ~1 ~100 minecraft:light_gray_concrete replace
setblock ~36 ~1 ~102 minecraft:light_gray_concrete replace
setblock ~32 ~1 ~104 minecraft:light_gray_concrete replace
setblock ~28 ~1 ~106 minecraft:light_gray_concrete replace
setblock ~24 ~1 ~108 minecraft:light_gray_concrete replace
setblock ~20 ~1 ~110 minecraft:light_gray_concrete replace
setblock ~16 ~1 ~112 minecraft:light_gray_concrete replace
setblock ~12 ~1 ~114 minecraft:light_gray_concrete replace
setblock ~8 ~1 ~116 minecraft:light_gray_concrete replace
setblock ~4 ~1 ~118 minecraft:light_gray_concrete replace
setblock ~0 ~1 ~120 minecraft:light_gray_concrete replace
setblock ~52 ~3 ~94 minecraft:light_gray_concrete replace
setblock ~48 ~3 ~96 minecraft:light_gray_concrete replace
setblock ~44 ~3 ~98 minecraft:light_gray_concrete replace
setblock ~40 ~3 ~100 minecraft:light_gray_concrete replace
setblock ~36 ~3 ~102 minecraft:light_gray_concrete replace
setblock ~32 ~3 ~104 minecraft:light_gray_concrete replace
setblock ~28 ~3 ~106 minecraft:light_gray_concrete replace
setblock ~24 ~3 ~108 minecraft:light_gray_concrete replace
setblock ~20 ~3 ~110 minecraft:light_gray_concrete replace
setblock ~16 ~3 ~112 minecraft:light_gray_concrete replace
setblock ~12 ~3 ~114 minecraft:light_gray_concrete replace
setblock ~8 ~3 ~116 minecraft:light_gray_concrete replace
setblock ~4 ~3 ~118 minecraft:light_gray_concrete replace
setblock ~0 ~3 ~120 minecraft:light_gray_concrete replace
fill ~55 ~4 ~94 ~58 ~4 ~94 minecraft:light_gray_concrete replace
fill ~51 ~4 ~96 ~58 ~4 ~96 minecraft:light_gray_concrete replace
fill ~47 ~4 ~98 ~58 ~4 ~98 minecraft:light_gray_concrete replace
fill ~43 ~4 ~100 ~58 ~4 ~100 minecraft:light_gray_concrete replace
fill ~39 ~4 ~102 ~58 ~4 ~102 minecraft:light_gray_concrete replace
fill ~35 ~4 ~104 ~58 ~4 ~104 minecraft:light_gray_concrete replace
fill ~31 ~4 ~106 ~58 ~4 ~106 minecraft:light_gray_concrete replace
fill ~27 ~4 ~108 ~58 ~4 ~108 minecraft:light_gray_concrete replace
fill ~23 ~4 ~110 ~58 ~4 ~110 minecraft:light_gray_concrete replace
fill ~19 ~4 ~112 ~58 ~4 ~112 minecraft:light_gray_concrete replace
fill ~15 ~4 ~114 ~58 ~4 ~114 minecraft:light_gray_concrete replace
fill ~11 ~4 ~116 ~58 ~4 ~116 minecraft:light_gray_concrete replace
fill ~7 ~4 ~118 ~58 ~4 ~118 minecraft:light_gray_concrete replace
fill ~3 ~4 ~120 ~58 ~4 ~120 minecraft:light_gray_concrete replace
setblock ~52 ~5 ~94 minecraft:light_gray_concrete replace
setblock ~54 ~5 ~94 minecraft:light_gray_concrete replace
setblock ~48 ~5 ~96 minecraft:light_gray_concrete replace
setblock ~50 ~5 ~96 minecraft:light_gray_concrete replace
setblock ~44 ~5 ~98 minecraft:light_gray_concrete replace
setblock ~46 ~5 ~98 minecraft:light_gray_concrete replace
setblock ~40 ~5 ~100 minecraft:light_gray_concrete replace
setblock ~42 ~5 ~100 minecraft:light_gray_concrete replace
setblock ~36 ~5 ~102 minecraft:light_gray_concrete replace
setblock ~38 ~5 ~102 minecraft:light_gray_concrete replace
setblock ~32 ~5 ~104 minecraft:light_gray_concrete replace
setblock ~34 ~5 ~104 minecraft:light_gray_concrete replace
setblock ~28 ~5 ~106 minecraft:light_gray_concrete replace
setblock ~30 ~5 ~106 minecraft:light_gray_concrete replace
setblock ~24 ~5 ~108 minecraft:light_gray_concrete replace
setblock ~26 ~5 ~108 minecraft:light_gray_concrete replace
setblock ~20 ~5 ~110 minecraft:light_gray_concrete replace
setblock ~22 ~5 ~110 minecraft:light_gray_concrete replace
setblock ~16 ~5 ~112 minecraft:light_gray_concrete replace
setblock ~18 ~5 ~112 minecraft:light_gray_concrete replace
setblock ~12 ~5 ~114 minecraft:light_gray_concrete replace
setblock ~14 ~5 ~114 minecraft:light_gray_concrete replace
setblock ~8 ~5 ~116 minecraft:light_gray_concrete replace
setblock ~10 ~5 ~116 minecraft:light_gray_concrete replace
setblock ~4 ~5 ~118 minecraft:light_gray_concrete replace
setblock ~6 ~5 ~118 minecraft:light_gray_concrete replace
setblock ~0 ~5 ~120 minecraft:light_gray_concrete replace
setblock ~2 ~5 ~120 minecraft:light_gray_concrete replace
setblock ~52 ~7 ~94 minecraft:light_gray_concrete replace
setblock ~54 ~7 ~94 minecraft:light_gray_concrete replace
setblock ~48 ~7 ~96 minecraft:light_gray_concrete replace
setblock ~50 ~7 ~96 minecraft:light_gray_concrete replace
setblock ~44 ~7 ~98 minecraft:light_gray_concrete replace
setblock ~46 ~7 ~98 minecraft:light_gray_concrete replace
setblock ~40 ~7 ~100 minecraft:light_gray_concrete replace
setblock ~42 ~7 ~100 minecraft:light_gray_concrete replace
setblock ~36 ~7 ~102 minecraft:light_gray_concrete replace
setblock ~38 ~7 ~102 minecraft:light_gray_concrete replace
setblock ~32 ~7 ~104 minecraft:light_gray_concrete replace
setblock ~34 ~7 ~104 minecraft:light_gray_concrete replace
setblock ~28 ~7 ~106 minecraft:light_gray_concrete replace
setblock ~30 ~7 ~106 minecraft:light_gray_concrete replace
setblock ~24 ~7 ~108 minecraft:light_gray_concrete replace
setblock ~26 ~7 ~108 minecraft:light_gray_concrete replace
setblock ~20 ~7 ~110 minecraft:light_gray_concrete replace
setblock ~22 ~7 ~110 minecraft:light_gray_concrete replace
setblock ~16 ~7 ~112 minecraft:light_gray_concrete replace
setblock ~18 ~7 ~112 minecraft:light_gray_concrete replace
setblock ~12 ~7 ~114 minecraft:light_gray_concrete replace
setblock ~14 ~7 ~114 minecraft:light_gray_concrete replace
setblock ~8 ~7 ~116 minecraft:light_gray_concrete replace
setblock ~10 ~7 ~116 minecraft:light_gray_concrete replace
setblock ~4 ~7 ~118 minecraft:light_gray_concrete replace
setblock ~6 ~7 ~118 minecraft:light_gray_concrete replace
setblock ~0 ~7 ~120 minecraft:light_gray_concrete replace
setblock ~2 ~7 ~120 minecraft:light_gray_concrete replace
fill ~38 ~8 ~3 ~38 ~8 ~101 minecraft:light_gray_concrete replace
fill ~34 ~8 ~7 ~34 ~8 ~103 minecraft:light_gray_concrete replace
fill ~30 ~8 ~11 ~30 ~8 ~105 minecraft:light_gray_concrete replace
fill ~26 ~8 ~15 ~26 ~8 ~107 minecraft:light_gray_concrete replace
fill ~22 ~8 ~19 ~22 ~8 ~109 minecraft:light_gray_concrete replace
fill ~18 ~8 ~23 ~18 ~8 ~111 minecraft:light_gray_concrete replace
fill ~14 ~8 ~27 ~14 ~8 ~113 minecraft:light_gray_concrete replace
fill ~10 ~8 ~31 ~10 ~8 ~115 minecraft:light_gray_concrete replace
fill ~6 ~8 ~35 ~6 ~8 ~117 minecraft:light_gray_concrete replace
fill ~2 ~8 ~39 ~2 ~8 ~119 minecraft:light_gray_concrete replace
fill ~36 ~8 ~43 ~36 ~8 ~101 minecraft:light_gray_concrete replace
fill ~32 ~8 ~47 ~32 ~8 ~103 minecraft:light_gray_concrete replace
fill ~28 ~8 ~51 ~28 ~8 ~105 minecraft:light_gray_concrete replace
fill ~24 ~8 ~55 ~24 ~8 ~107 minecraft:light_gray_concrete replace
fill ~20 ~8 ~59 ~20 ~8 ~109 minecraft:light_gray_concrete replace
fill ~16 ~8 ~63 ~16 ~8 ~111 minecraft:light_gray_concrete replace
fill ~12 ~8 ~67 ~12 ~8 ~113 minecraft:light_gray_concrete replace
fill ~8 ~8 ~71 ~8 ~8 ~115 minecraft:light_gray_concrete replace
fill ~4 ~8 ~75 ~4 ~8 ~117 minecraft:light_gray_concrete replace
fill ~0 ~8 ~79 ~0 ~8 ~119 minecraft:light_gray_concrete replace
fill ~52 ~8 ~95 ~52 ~8 ~97 minecraft:light_gray_concrete replace
fill ~48 ~8 ~97 ~48 ~8 ~105 minecraft:light_gray_concrete replace
fill ~50 ~8 ~97 ~50 ~8 ~101 minecraft:light_gray_concrete replace
fill ~44 ~8 ~99 ~44 ~8 ~113 minecraft:light_gray_concrete replace
fill ~46 ~8 ~99 ~46 ~8 ~109 minecraft:light_gray_concrete replace
fill ~40 ~8 ~101 ~40 ~8 ~121 minecraft:light_gray_concrete replace
fill ~42 ~8 ~101 ~42 ~8 ~117 minecraft:light_gray_concrete replace
setblock ~38 ~9 ~2 minecraft:light_gray_concrete replace
setblock ~34 ~9 ~6 minecraft:light_gray_concrete replace
setblock ~30 ~9 ~10 minecraft:light_gray_concrete replace
setblock ~26 ~9 ~14 minecraft:light_gray_concrete replace
setblock ~22 ~9 ~18 minecraft:light_gray_concrete replace
setblock ~18 ~9 ~22 minecraft:light_gray_concrete replace
setblock ~14 ~9 ~26 minecraft:light_gray_concrete replace
setblock ~10 ~9 ~30 minecraft:light_gray_concrete replace
setblock ~6 ~9 ~34 minecraft:light_gray_concrete replace
setblock ~2 ~9 ~38 minecraft:light_gray_concrete replace
setblock ~36 ~9 ~42 minecraft:light_gray_concrete replace
setblock ~32 ~9 ~46 minecraft:light_gray_concrete replace
setblock ~28 ~9 ~50 minecraft:light_gray_concrete replace
setblock ~24 ~9 ~54 minecraft:light_gray_concrete replace
setblock ~20 ~9 ~58 minecraft:light_gray_concrete replace
setblock ~16 ~9 ~62 minecraft:light_gray_concrete replace
setblock ~12 ~9 ~66 minecraft:light_gray_concrete replace
setblock ~8 ~9 ~70 minecraft:light_gray_concrete replace
setblock ~4 ~9 ~74 minecraft:light_gray_concrete replace
setblock ~0 ~9 ~78 minecraft:light_gray_concrete replace
setblock ~52 ~9 ~94 minecraft:light_gray_concrete replace
setblock ~54 ~9 ~94 minecraft:light_gray_concrete replace
setblock ~48 ~9 ~96 minecraft:light_gray_concrete replace
setblock ~50 ~9 ~96 minecraft:light_gray_concrete replace
setblock ~44 ~9 ~98 minecraft:light_gray_concrete replace
setblock ~46 ~9 ~98 minecraft:light_gray_concrete replace
setblock ~52 ~9 ~98 minecraft:light_gray_concrete replace
setblock ~40 ~9 ~100 minecraft:light_gray_concrete replace
setblock ~42 ~9 ~100 minecraft:light_gray_concrete replace
setblock ~36 ~9 ~102 minecraft:light_gray_concrete replace
setblock ~38 ~9 ~102 minecraft:light_gray_concrete replace
setblock ~50 ~9 ~102 minecraft:light_gray_concrete replace
setblock ~32 ~9 ~104 minecraft:light_gray_concrete replace
setblock ~34 ~9 ~104 minecraft:light_gray_concrete replace
setblock ~28 ~9 ~106 minecraft:light_gray_concrete replace
setblock ~30 ~9 ~106 minecraft:light_gray_concrete replace
setblock ~48 ~9 ~106 minecraft:light_gray_concrete replace
setblock ~24 ~9 ~108 minecraft:light_gray_concrete replace
setblock ~26 ~9 ~108 minecraft:light_gray_concrete replace
setblock ~20 ~9 ~110 minecraft:light_gray_concrete replace
setblock ~22 ~9 ~110 minecraft:light_gray_concrete replace
setblock ~46 ~9 ~110 minecraft:light_gray_concrete replace
setblock ~16 ~9 ~112 minecraft:light_gray_concrete replace
setblock ~18 ~9 ~112 minecraft:light_gray_concrete replace
setblock ~12 ~9 ~114 minecraft:light_gray_concrete replace
setblock ~14 ~9 ~114 minecraft:light_gray_concrete replace
setblock ~44 ~9 ~114 minecraft:light_gray_concrete replace
setblock ~8 ~9 ~116 minecraft:light_gray_concrete replace
setblock ~10 ~9 ~116 minecraft:light_gray_concrete replace
setblock ~4 ~9 ~118 minecraft:light_gray_concrete replace
setblock ~6 ~9 ~118 minecraft:light_gray_concrete replace
setblock ~42 ~9 ~118 minecraft:light_gray_concrete replace
setblock ~0 ~9 ~120 minecraft:light_gray_concrete replace
setblock ~2 ~9 ~120 minecraft:light_gray_concrete replace
setblock ~40 ~9 ~122 minecraft:light_gray_concrete replace
setblock ~38 ~11 ~2 minecraft:light_gray_concrete replace
setblock ~34 ~11 ~6 minecraft:light_gray_concrete replace
setblock ~30 ~11 ~10 minecraft:light_gray_concrete replace
setblock ~26 ~11 ~14 minecraft:light_gray_concrete replace
setblock ~22 ~11 ~18 minecraft:light_gray_concrete replace
setblock ~18 ~11 ~22 minecraft:light_gray_concrete replace
setblock ~14 ~11 ~26 minecraft:light_gray_concrete replace
setblock ~10 ~11 ~30 minecraft:light_gray_concrete replace
setblock ~6 ~11 ~34 minecraft:light_gray_concrete replace
setblock ~2 ~11 ~38 minecraft:light_gray_concrete replace
setblock ~36 ~11 ~42 minecraft:light_gray_concrete replace
setblock ~32 ~11 ~46 minecraft:light_gray_concrete replace
setblock ~28 ~11 ~50 minecraft:light_gray_concrete replace
setblock ~24 ~11 ~54 minecraft:light_gray_concrete replace
setblock ~20 ~11 ~58 minecraft:light_gray_concrete replace
setblock ~16 ~11 ~62 minecraft:light_gray_concrete replace
setblock ~12 ~11 ~66 minecraft:light_gray_concrete replace
setblock ~8 ~11 ~70 minecraft:light_gray_concrete replace
setblock ~4 ~11 ~74 minecraft:light_gray_concrete replace
setblock ~0 ~11 ~78 minecraft:light_gray_concrete replace
setblock ~54 ~11 ~94 minecraft:light_gray_concrete replace
setblock ~52 ~11 ~98 minecraft:light_gray_concrete replace
setblock ~50 ~11 ~102 minecraft:light_gray_concrete replace
setblock ~48 ~11 ~106 minecraft:light_gray_concrete replace
setblock ~46 ~11 ~110 minecraft:light_gray_concrete replace
setblock ~44 ~11 ~114 minecraft:light_gray_concrete replace
setblock ~42 ~11 ~118 minecraft:light_gray_concrete replace
setblock ~40 ~11 ~122 minecraft:light_gray_concrete replace
fill ~39 ~12 ~2 ~75 ~12 ~2 minecraft:light_gray_concrete replace
fill ~35 ~12 ~6 ~75 ~12 ~6 minecraft:light_gray_concrete replace
fill ~31 ~12 ~10 ~75 ~12 ~10 minecraft:light_gray_concrete replace
fill ~27 ~12 ~14 ~75 ~12 ~14 minecraft:light_gray_concrete replace
fill ~23 ~12 ~18 ~75 ~12 ~18 minecraft:light_gray_concrete replace
fill ~19 ~12 ~22 ~75 ~12 ~22 minecraft:light_gray_concrete replace
fill ~15 ~12 ~26 ~75 ~12 ~26 minecraft:light_gray_concrete replace
fill ~11 ~12 ~30 ~75 ~12 ~30 minecraft:light_gray_concrete replace
fill ~7 ~12 ~34 ~75 ~12 ~34 minecraft:light_gray_concrete replace
fill ~3 ~12 ~38 ~75 ~12 ~38 minecraft:light_gray_concrete replace
fill ~37 ~12 ~42 ~75 ~12 ~42 minecraft:light_gray_concrete replace
fill ~33 ~12 ~46 ~75 ~12 ~46 minecraft:light_gray_concrete replace
fill ~29 ~12 ~50 ~75 ~12 ~50 minecraft:light_gray_concrete replace
fill ~25 ~12 ~54 ~75 ~12 ~54 minecraft:light_gray_concrete replace
fill ~21 ~12 ~58 ~75 ~12 ~58 minecraft:light_gray_concrete replace
fill ~17 ~12 ~62 ~75 ~12 ~62 minecraft:light_gray_concrete replace
fill ~13 ~12 ~66 ~75 ~12 ~66 minecraft:light_gray_concrete replace
fill ~9 ~12 ~70 ~75 ~12 ~70 minecraft:light_gray_concrete replace
fill ~5 ~12 ~74 ~75 ~12 ~74 minecraft:light_gray_concrete replace
fill ~1 ~12 ~78 ~75 ~12 ~78 minecraft:light_gray_concrete replace
fill ~55 ~12 ~94 ~63 ~12 ~94 minecraft:light_gray_concrete replace
fill ~53 ~12 ~98 ~63 ~12 ~98 minecraft:light_gray_concrete replace
fill ~51 ~12 ~102 ~63 ~12 ~102 minecraft:light_gray_concrete replace
fill ~49 ~12 ~106 ~63 ~12 ~106 minecraft:light_gray_concrete replace
fill ~47 ~12 ~110 ~63 ~12 ~110 minecraft:light_gray_concrete replace
fill ~45 ~12 ~114 ~63 ~12 ~114 minecraft:light_gray_concrete replace
fill ~43 ~12 ~118 ~63 ~12 ~118 minecraft:light_gray_concrete replace
fill ~41 ~12 ~122 ~63 ~12 ~122 minecraft:light_gray_concrete replace
setblock ~38 ~13 ~2 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~2 minecraft:light_gray_concrete replace
setblock ~34 ~13 ~6 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~6 minecraft:light_gray_concrete replace
setblock ~30 ~13 ~10 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~10 minecraft:light_gray_concrete replace
setblock ~26 ~13 ~14 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~14 minecraft:light_gray_concrete replace
setblock ~22 ~13 ~18 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~18 minecraft:light_gray_concrete replace
setblock ~18 ~13 ~22 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~22 minecraft:light_gray_concrete replace
setblock ~14 ~13 ~26 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~26 minecraft:light_gray_concrete replace
setblock ~10 ~13 ~30 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~30 minecraft:light_gray_concrete replace
setblock ~6 ~13 ~34 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~34 minecraft:light_gray_concrete replace
setblock ~2 ~13 ~38 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~38 minecraft:light_gray_concrete replace
setblock ~36 ~13 ~42 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~42 minecraft:light_gray_concrete replace
setblock ~32 ~13 ~46 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~46 minecraft:light_gray_concrete replace
setblock ~28 ~13 ~50 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~50 minecraft:light_gray_concrete replace
setblock ~24 ~13 ~54 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~54 minecraft:light_gray_concrete replace
setblock ~20 ~13 ~58 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~58 minecraft:light_gray_concrete replace
setblock ~16 ~13 ~62 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~62 minecraft:light_gray_concrete replace
setblock ~12 ~13 ~66 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~66 minecraft:light_gray_concrete replace
setblock ~8 ~13 ~70 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~70 minecraft:light_gray_concrete replace
setblock ~4 ~13 ~74 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~74 minecraft:light_gray_concrete replace
setblock ~0 ~13 ~78 minecraft:light_gray_concrete replace
setblock ~76 ~13 ~78 minecraft:light_gray_concrete replace
setblock ~54 ~13 ~94 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~94 minecraft:light_gray_concrete replace
setblock ~52 ~13 ~98 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~98 minecraft:light_gray_concrete replace
setblock ~50 ~13 ~102 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~102 minecraft:light_gray_concrete replace
setblock ~48 ~13 ~106 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~106 minecraft:light_gray_concrete replace
setblock ~46 ~13 ~110 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~110 minecraft:light_gray_concrete replace
setblock ~44 ~13 ~114 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~114 minecraft:light_gray_concrete replace
setblock ~42 ~13 ~118 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~118 minecraft:light_gray_concrete replace
setblock ~40 ~13 ~122 minecraft:light_gray_concrete replace
setblock ~64 ~13 ~122 minecraft:light_gray_concrete replace
fill ~74 ~14 ~90 ~74 ~14 ~95 minecraft:light_gray_concrete replace
fill ~74 ~14 ~96 ~75 ~14 ~96 minecraft:light_gray_concrete replace
fill ~74 ~14 ~97 ~74 ~14 ~99 minecraft:light_gray_concrete replace
fill ~74 ~14 ~100 ~75 ~14 ~100 minecraft:light_gray_concrete replace
fill ~74 ~14 ~101 ~74 ~14 ~103 minecraft:light_gray_concrete replace
fill ~74 ~14 ~104 ~75 ~14 ~104 minecraft:light_gray_concrete replace
fill ~74 ~14 ~105 ~74 ~14 ~107 minecraft:light_gray_concrete replace
fill ~74 ~14 ~108 ~75 ~14 ~108 minecraft:light_gray_concrete replace
fill ~74 ~14 ~109 ~74 ~14 ~111 minecraft:light_gray_concrete replace
fill ~74 ~14 ~112 ~75 ~14 ~112 minecraft:light_gray_concrete replace
fill ~74 ~14 ~113 ~74 ~14 ~115 minecraft:light_gray_concrete replace
fill ~74 ~14 ~116 ~75 ~14 ~116 minecraft:light_gray_concrete replace
fill ~74 ~14 ~117 ~74 ~14 ~119 minecraft:light_gray_concrete replace
fill ~74 ~14 ~120 ~75 ~14 ~120 minecraft:light_gray_concrete replace
fill ~74 ~14 ~121 ~74 ~14 ~123 minecraft:light_gray_concrete replace
fill ~74 ~14 ~124 ~75 ~14 ~124 minecraft:light_gray_concrete replace
fill ~65 ~14 ~125 ~74 ~14 ~125 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~2 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~6 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~10 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~14 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~18 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~22 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~26 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~30 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~34 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~38 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~42 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~46 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~50 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~54 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~58 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~62 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~66 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~70 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~74 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~78 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~94 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~96 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~98 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~100 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~102 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~104 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~106 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~108 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~110 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~112 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~114 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~116 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~118 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~120 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~122 minecraft:light_gray_concrete replace
setblock ~76 ~15 ~124 minecraft:light_gray_concrete replace
setblock ~64 ~15 ~125 minecraft:light_gray_concrete replace
fill ~77 ~16 ~2 ~110 ~16 ~2 minecraft:light_gray_concrete replace
fill ~79 ~16 ~3 ~79 ~16 ~4 minecraft:light_gray_concrete replace
fill ~82 ~16 ~3 ~82 ~16 ~4 minecraft:light_gray_concrete replace
fill ~85 ~16 ~3 ~85 ~16 ~4 minecraft:light_gray_concrete replace
fill ~88 ~16 ~3 ~88 ~16 ~4 minecraft:light_gray_concrete replace
fill ~91 ~16 ~3 ~91 ~16 ~4 minecraft:light_gray_concrete replace
fill ~109 ~16 ~3 ~109 ~16 ~4 minecraft:light_gray_concrete replace
fill ~77 ~16 ~6 ~116 ~16 ~6 minecraft:light_gray_concrete replace
fill ~94 ~16 ~7 ~94 ~16 ~8 minecraft:light_gray_concrete replace
fill ~97 ~16 ~7 ~97 ~16 ~8 minecraft:light_gray_concrete replace
fill ~100 ~16 ~7 ~100 ~16 ~8 minecraft:light_gray_concrete replace
fill ~103 ~16 ~7 ~103 ~16 ~8 minecraft:light_gray_concrete replace
fill ~106 ~16 ~7 ~106 ~16 ~8 minecraft:light_gray_concrete replace
fill ~115 ~16 ~7 ~115 ~16 ~8 minecraft:light_gray_concrete replace
fill ~77 ~16 ~10 ~134 ~16 ~10 minecraft:light_gray_concrete replace
fill ~112 ~16 ~11 ~112 ~16 ~12 minecraft:light_gray_concrete replace
fill ~118 ~16 ~11 ~118 ~16 ~12 minecraft:light_gray_concrete replace
fill ~121 ~16 ~11 ~121 ~16 ~12 minecraft:light_gray_concrete replace
fill ~124 ~16 ~11 ~124 ~16 ~12 minecraft:light_gray_concrete replace
fill ~127 ~16 ~11 ~127 ~16 ~12 minecraft:light_gray_concrete replace
fill ~133 ~16 ~11 ~133 ~16 ~12 minecraft:light_gray_concrete replace
fill ~77 ~16 ~14 ~155 ~16 ~14 minecraft:light_gray_concrete replace
fill ~136 ~16 ~15 ~136 ~16 ~16 minecraft:light_gray_concrete replace
fill ~139 ~16 ~15 ~139 ~16 ~16 minecraft:light_gray_concrete replace
fill ~145 ~16 ~15 ~145 ~16 ~16 minecraft:light_gray_concrete replace
fill ~148 ~16 ~15 ~148 ~16 ~16 minecraft:light_gray_concrete replace
fill ~151 ~16 ~15 ~151 ~16 ~16 minecraft:light_gray_concrete replace
fill ~154 ~16 ~15 ~154 ~16 ~16 minecraft:light_gray_concrete replace
fill ~77 ~16 ~18 ~176 ~16 ~18 minecraft:light_gray_concrete replace
fill ~160 ~16 ~19 ~160 ~16 ~20 minecraft:light_gray_concrete replace
fill ~163 ~16 ~19 ~163 ~16 ~20 minecraft:light_gray_concrete replace
fill ~166 ~16 ~19 ~166 ~16 ~20 minecraft:light_gray_concrete replace
fill ~169 ~16 ~19 ~169 ~16 ~20 minecraft:light_gray_concrete replace
fill ~172 ~16 ~19 ~172 ~16 ~20 minecraft:light_gray_concrete replace
fill ~175 ~16 ~19 ~175 ~16 ~20 minecraft:light_gray_concrete replace
fill ~77 ~16 ~22 ~206 ~16 ~22 minecraft:light_gray_concrete replace
fill ~184 ~16 ~23 ~184 ~16 ~24 minecraft:light_gray_concrete replace
fill ~193 ~16 ~23 ~193 ~16 ~24 minecraft:light_gray_concrete replace
fill ~196 ~16 ~23 ~196 ~16 ~24 minecraft:light_gray_concrete replace
fill ~199 ~16 ~23 ~199 ~16 ~24 minecraft:light_gray_concrete replace
fill ~202 ~16 ~23 ~202 ~16 ~24 minecraft:light_gray_concrete replace
fill ~205 ~16 ~23 ~205 ~16 ~24 minecraft:light_gray_concrete replace
fill ~77 ~16 ~26 ~239 ~16 ~26 minecraft:light_gray_concrete replace
fill ~211 ~16 ~27 ~211 ~16 ~28 minecraft:light_gray_concrete replace
fill ~214 ~16 ~27 ~214 ~16 ~28 minecraft:light_gray_concrete replace
fill ~217 ~16 ~27 ~217 ~16 ~28 minecraft:light_gray_concrete replace
fill ~223 ~16 ~27 ~223 ~16 ~28 minecraft:light_gray_concrete replace
fill ~226 ~16 ~27 ~226 ~16 ~28 minecraft:light_gray_concrete replace
fill ~238 ~16 ~27 ~238 ~16 ~28 minecraft:light_gray_concrete replace
fill ~77 ~16 ~30 ~284 ~16 ~30 minecraft:light_gray_concrete replace
fill ~250 ~16 ~31 ~250 ~16 ~32 minecraft:light_gray_concrete replace
fill ~265 ~16 ~31 ~265 ~16 ~32 minecraft:light_gray_concrete replace
fill ~268 ~16 ~31 ~268 ~16 ~32 minecraft:light_gray_concrete replace
fill ~277 ~16 ~31 ~277 ~16 ~32 minecraft:light_gray_concrete replace
fill ~280 ~16 ~31 ~280 ~16 ~32 minecraft:light_gray_concrete replace
fill ~283 ~16 ~31 ~283 ~16 ~32 minecraft:light_gray_concrete replace
fill ~77 ~16 ~34 ~272 ~16 ~34 minecraft:light_gray_concrete replace
fill ~232 ~16 ~35 ~232 ~16 ~36 minecraft:light_gray_concrete replace
fill ~235 ~16 ~35 ~235 ~16 ~36 minecraft:light_gray_concrete replace
fill ~241 ~16 ~35 ~241 ~16 ~36 minecraft:light_gray_concrete replace
fill ~244 ~16 ~35 ~244 ~16 ~36 minecraft:light_gray_concrete replace
fill ~247 ~16 ~35 ~247 ~16 ~36 minecraft:light_gray_concrete replace
fill ~271 ~16 ~35 ~271 ~16 ~36 minecraft:light_gray_concrete replace
fill ~77 ~16 ~38 ~299 ~16 ~38 minecraft:light_gray_concrete replace
fill ~259 ~16 ~39 ~259 ~16 ~40 minecraft:light_gray_concrete replace
fill ~286 ~16 ~39 ~286 ~16 ~40 minecraft:light_gray_concrete replace
fill ~289 ~16 ~39 ~289 ~16 ~40 minecraft:light_gray_concrete replace
fill ~292 ~16 ~39 ~292 ~16 ~40 minecraft:light_gray_concrete replace
fill ~295 ~16 ~39 ~295 ~16 ~40 minecraft:light_gray_concrete replace
fill ~298 ~16 ~39 ~298 ~16 ~40 minecraft:light_gray_concrete replace
fill ~77 ~16 ~42 ~131 ~16 ~42 minecraft:light_gray_concrete replace
fill ~82 ~16 ~43 ~82 ~16 ~44 minecraft:light_gray_concrete replace
fill ~85 ~16 ~43 ~85 ~16 ~44 minecraft:light_gray_concrete replace
fill ~88 ~16 ~43 ~88 ~16 ~44 minecraft:light_gray_concrete replace
fill ~91 ~16 ~43 ~91 ~16 ~44 minecraft:light_gray_concrete replace
fill ~130 ~16 ~43 ~130 ~16 ~44 minecraft:light_gray_concrete replace
fill ~77 ~16 ~46 ~143 ~16 ~46 minecraft:light_gray_concrete replace
fill ~97 ~16 ~47 ~97 ~16 ~48 minecraft:light_gray_concrete replace
fill ~100 ~16 ~47 ~100 ~16 ~48 minecraft:light_gray_concrete replace
fill ~103 ~16 ~47 ~103 ~16 ~48 minecraft:light_gray_concrete replace
fill ~106 ~16 ~47 ~106 ~16 ~48 minecraft:light_gray_concrete replace
fill ~142 ~16 ~47 ~142 ~16 ~48 minecraft:light_gray_concrete replace
fill ~77 ~16 ~50 ~158 ~16 ~50 minecraft:light_gray_concrete replace
fill ~118 ~16 ~51 ~118 ~16 ~52 minecraft:light_gray_concrete replace
fill ~121 ~16 ~51 ~121 ~16 ~52 minecraft:light_gray_concrete replace
fill ~124 ~16 ~51 ~124 ~16 ~52 minecraft:light_gray_concrete replace
fill ~127 ~16 ~51 ~127 ~16 ~52 minecraft:light_gray_concrete replace
fill ~157 ~16 ~51 ~157 ~16 ~52 minecraft:light_gray_concrete replace
fill ~77 ~16 ~54 ~191 ~16 ~54 minecraft:light_gray_concrete replace
fill ~139 ~16 ~55 ~139 ~16 ~56 minecraft:light_gray_concrete replace
fill ~145 ~16 ~55 ~145 ~16 ~56 minecraft:light_gray_concrete replace
fill ~148 ~16 ~55 ~148 ~16 ~56 minecraft:light_gray_concrete replace
fill ~151 ~16 ~55 ~151 ~16 ~56 minecraft:light_gray_concrete replace
fill ~190 ~16 ~55 ~190 ~16 ~56 minecraft:light_gray_concrete replace
fill ~77 ~16 ~58 ~209 ~16 ~58 minecraft:light_gray_concrete replace
fill ~163 ~16 ~59 ~163 ~16 ~60 minecraft:light_gray_concrete replace
fill ~166 ~16 ~59 ~166 ~16 ~60 minecraft:light_gray_concrete replace
fill ~169 ~16 ~59 ~169 ~16 ~60 minecraft:light_gray_concrete replace
fill ~172 ~16 ~59 ~172 ~16 ~60 minecraft:light_gray_concrete replace
fill ~208 ~16 ~59 ~208 ~16 ~60 minecraft:light_gray_concrete replace
fill ~77 ~16 ~62 ~221 ~16 ~62 minecraft:light_gray_concrete replace
fill ~193 ~16 ~63 ~193 ~16 ~64 minecraft:light_gray_concrete replace
fill ~196 ~16 ~63 ~196 ~16 ~64 minecraft:light_gray_concrete replace
fill ~199 ~16 ~63 ~199 ~16 ~64 minecraft:light_gray_concrete replace
fill ~202 ~16 ~63 ~202 ~16 ~64 minecraft:light_gray_concrete replace
fill ~220 ~16 ~63 ~220 ~16 ~64 minecraft:light_gray_concrete replace
fill ~77 ~16 ~66 ~254 ~16 ~66 minecraft:light_gray_concrete replace
fill ~214 ~16 ~67 ~214 ~16 ~68 minecraft:light_gray_concrete replace
fill ~217 ~16 ~67 ~217 ~16 ~68 minecraft:light_gray_concrete replace
fill ~223 ~16 ~67 ~223 ~16 ~68 minecraft:light_gray_concrete replace
fill ~226 ~16 ~67 ~226 ~16 ~68 minecraft:light_gray_concrete replace
fill ~253 ~16 ~67 ~253 ~16 ~68 minecraft:light_gray_concrete replace
fill ~77 ~16 ~70 ~284 ~16 ~70 minecraft:light_gray_concrete replace
fill ~256 ~16 ~71 ~256 ~16 ~72 minecraft:light_gray_concrete replace
fill ~268 ~16 ~71 ~268 ~16 ~72 minecraft:light_gray_concrete replace
fill ~277 ~16 ~71 ~277 ~16 ~72 minecraft:light_gray_concrete replace
fill ~280 ~16 ~71 ~280 ~16 ~72 minecraft:light_gray_concrete replace
fill ~283 ~16 ~71 ~283 ~16 ~72 minecraft:light_gray_concrete replace
fill ~77 ~16 ~74 ~263 ~16 ~74 minecraft:light_gray_concrete replace
fill ~235 ~16 ~75 ~235 ~16 ~76 minecraft:light_gray_concrete replace
fill ~241 ~16 ~75 ~241 ~16 ~76 minecraft:light_gray_concrete replace
fill ~244 ~16 ~75 ~244 ~16 ~76 minecraft:light_gray_concrete replace
fill ~247 ~16 ~75 ~247 ~16 ~76 minecraft:light_gray_concrete replace
fill ~262 ~16 ~75 ~262 ~16 ~76 minecraft:light_gray_concrete replace
fill ~77 ~16 ~78 ~299 ~16 ~78 minecraft:light_gray_concrete replace
fill ~274 ~16 ~79 ~274 ~16 ~80 minecraft:light_gray_concrete replace
fill ~289 ~16 ~79 ~289 ~16 ~80 minecraft:light_gray_concrete replace
fill ~292 ~16 ~79 ~292 ~16 ~80 minecraft:light_gray_concrete replace
fill ~295 ~16 ~79 ~295 ~16 ~80 minecraft:light_gray_concrete replace
fill ~298 ~16 ~79 ~298 ~16 ~80 minecraft:light_gray_concrete replace
fill ~78 ~16 ~82 ~302 ~16 ~82 minecraft:light_gray_concrete replace
fill ~301 ~16 ~83 ~301 ~16 ~84 minecraft:light_gray_concrete replace
fill ~78 ~16 ~86 ~302 ~16 ~86 minecraft:light_gray_concrete replace
fill ~301 ~16 ~87 ~301 ~16 ~88 minecraft:light_gray_concrete replace
fill ~63 ~16 ~90 ~63 ~16 ~125 minecraft:light_gray_concrete replace
fill ~78 ~16 ~90 ~302 ~16 ~90 minecraft:light_gray_concrete replace
fill ~301 ~16 ~91 ~301 ~16 ~92 minecraft:light_gray_concrete replace
fill ~65 ~16 ~94 ~302 ~16 ~94 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~95 minecraft:light_gray_concrete replace
fill ~301 ~16 ~95 ~301 ~16 ~96 minecraft:light_gray_concrete replace
fill ~65 ~16 ~98 ~302 ~16 ~98 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~99 minecraft:light_gray_concrete replace
fill ~187 ~16 ~99 ~187 ~16 ~100 minecraft:light_gray_concrete replace
fill ~301 ~16 ~99 ~301 ~16 ~100 minecraft:light_gray_concrete replace
fill ~65 ~16 ~102 ~302 ~16 ~102 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~103 minecraft:light_gray_concrete replace
fill ~178 ~16 ~103 ~178 ~16 ~104 minecraft:light_gray_concrete replace
fill ~301 ~16 ~103 ~301 ~16 ~104 minecraft:light_gray_concrete replace
fill ~65 ~16 ~106 ~302 ~16 ~106 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~107 minecraft:light_gray_concrete replace
fill ~178 ~16 ~107 ~178 ~16 ~108 minecraft:light_gray_concrete replace
fill ~187 ~16 ~107 ~187 ~16 ~108 minecraft:light_gray_concrete replace
fill ~301 ~16 ~107 ~301 ~16 ~108 minecraft:light_gray_concrete replace
fill ~65 ~16 ~110 ~302 ~16 ~110 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~111 minecraft:light_gray_concrete replace
fill ~181 ~16 ~111 ~181 ~16 ~112 minecraft:light_gray_concrete replace
fill ~301 ~16 ~111 ~301 ~16 ~112 minecraft:light_gray_concrete replace
fill ~65 ~16 ~114 ~302 ~16 ~114 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~115 minecraft:light_gray_concrete replace
fill ~181 ~16 ~115 ~181 ~16 ~116 minecraft:light_gray_concrete replace
fill ~187 ~16 ~115 ~187 ~16 ~116 minecraft:light_gray_concrete replace
fill ~301 ~16 ~115 ~301 ~16 ~116 minecraft:light_gray_concrete replace
fill ~65 ~16 ~118 ~302 ~16 ~118 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~119 minecraft:light_gray_concrete replace
fill ~178 ~16 ~119 ~178 ~16 ~120 minecraft:light_gray_concrete replace
fill ~181 ~16 ~119 ~181 ~16 ~120 minecraft:light_gray_concrete replace
fill ~301 ~16 ~119 ~301 ~16 ~120 minecraft:light_gray_concrete replace
fill ~65 ~16 ~122 ~302 ~16 ~122 minecraft:light_gray_concrete replace
setblock ~76 ~16 ~123 minecraft:light_gray_concrete replace
fill ~178 ~16 ~123 ~178 ~16 ~124 minecraft:light_gray_concrete replace
fill ~181 ~16 ~123 ~181 ~16 ~124 minecraft:light_gray_concrete replace
fill ~187 ~16 ~123 ~187 ~16 ~124 minecraft:light_gray_concrete replace
fill ~301 ~16 ~123 ~301 ~16 ~124 minecraft:light_gray_concrete replace
fill ~78 ~16 ~126 ~230 ~16 ~126 minecraft:light_gray_concrete replace
fill ~229 ~16 ~127 ~229 ~16 ~128 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~2 minecraft:light_gray_concrete replace
setblock ~104 ~17 ~2 minecraft:light_gray_concrete replace
setblock ~106 ~17 ~2 minecraft:light_gray_concrete replace
setblock ~79 ~17 ~4 minecraft:light_gray_concrete replace
setblock ~82 ~17 ~4 minecraft:light_gray_concrete replace
setblock ~85 ~17 ~4 minecraft:light_gray_concrete replace
setblock ~88 ~17 ~4 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~4 minecraft:light_gray_concrete replace
setblock ~109 ~17 ~4 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~6 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~6 minecraft:light_gray_concrete replace
setblock ~93 ~17 ~6 minecraft:light_gray_concrete replace
setblock ~108 ~17 ~6 minecraft:light_gray_concrete replace
setblock ~110 ~17 ~6 minecraft:light_gray_concrete replace
setblock ~94 ~17 ~8 minecraft:light_gray_concrete replace
setblock ~97 ~17 ~8 minecraft:light_gray_concrete replace
setblock ~100 ~17 ~8 minecraft:light_gray_concrete replace
setblock ~103 ~17 ~8 minecraft:light_gray_concrete replace
setblock ~106 ~17 ~8 minecraft:light_gray_concrete replace
setblock ~115 ~17 ~8 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~10 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~10 minecraft:light_gray_concrete replace
setblock ~93 ~17 ~10 minecraft:light_gray_concrete replace
setblock ~108 ~17 ~10 minecraft:light_gray_concrete replace
setblock ~110 ~17 ~10 minecraft:light_gray_concrete replace
setblock ~112 ~17 ~12 minecraft:light_gray_concrete replace
setblock ~118 ~17 ~12 minecraft:light_gray_concrete replace
setblock ~121 ~17 ~12 minecraft:light_gray_concrete replace
setblock ~124 ~17 ~12 minecraft:light_gray_concrete replace
setblock ~127 ~17 ~12 minecraft:light_gray_concrete replace
setblock ~133 ~17 ~12 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~14 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~14 minecraft:light_gray_concrete replace
setblock ~93 ~17 ~14 minecraft:light_gray_concrete replace
