setblock ~258 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~208 ~117 ~35 ~220 minecraft:redstone_wire replace
fill ~141 ~35 ~208 ~141 ~35 ~220 minecraft:redstone_wire replace
fill ~171 ~35 ~208 ~171 ~35 ~220 minecraft:redstone_wire replace
fill ~174 ~35 ~208 ~174 ~35 ~220 minecraft:redstone_wire replace
fill ~228 ~35 ~208 ~228 ~35 ~220 minecraft:redstone_wire replace
fill ~240 ~35 ~208 ~240 ~35 ~220 minecraft:redstone_wire replace
fill ~258 ~35 ~208 ~258 ~35 ~220 minecraft:redstone_wire replace
fill ~261 ~35 ~208 ~261 ~35 ~220 minecraft:redstone_wire replace
fill ~282 ~35 ~208 ~282 ~35 ~220 minecraft:redstone_wire replace
setblock ~93 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~216 ~93 ~35 ~228 minecraft:redstone_wire replace
fill ~120 ~35 ~216 ~120 ~35 ~228 minecraft:redstone_wire replace
fill ~144 ~35 ~216 ~144 ~35 ~228 minecraft:redstone_wire replace
fill ~150 ~35 ~216 ~150 ~35 ~228 minecraft:redstone_wire replace
fill ~168 ~35 ~216 ~168 ~35 ~228 minecraft:redstone_wire replace
fill ~195 ~35 ~216 ~195 ~35 ~228 minecraft:redstone_wire replace
fill ~201 ~35 ~216 ~201 ~35 ~228 minecraft:redstone_wire replace
fill ~225 ~35 ~216 ~225 ~35 ~228 minecraft:redstone_wire replace
fill ~246 ~35 ~216 ~246 ~35 ~228 minecraft:redstone_wire replace
fill ~264 ~35 ~216 ~264 ~35 ~228 minecraft:redstone_wire replace
fill ~285 ~35 ~216 ~285 ~35 ~228 minecraft:redstone_wire replace
fill ~315 ~35 ~216 ~315 ~35 ~228 minecraft:redstone_wire replace
fill ~327 ~35 ~216 ~327 ~35 ~228 minecraft:redstone_wire replace
fill ~339 ~35 ~216 ~339 ~35 ~228 minecraft:redstone_wire replace
fill ~387 ~35 ~216 ~387 ~35 ~228 minecraft:redstone_wire replace
setblock ~318 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~220 ~318 ~35 ~232 minecraft:redstone_wire replace
fill ~336 ~35 ~220 ~336 ~35 ~232 minecraft:redstone_wire replace
fill ~342 ~35 ~220 ~342 ~35 ~232 minecraft:redstone_wire replace
fill ~354 ~35 ~220 ~354 ~35 ~232 minecraft:redstone_wire replace
fill ~360 ~35 ~220 ~360 ~35 ~232 minecraft:redstone_wire replace
fill ~378 ~35 ~220 ~378 ~35 ~232 minecraft:redstone_wire replace
setblock ~117 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~224 ~117 ~35 ~236 minecraft:redstone_wire replace
fill ~141 ~35 ~224 ~141 ~35 ~236 minecraft:redstone_wire replace
fill ~171 ~35 ~224 ~171 ~35 ~236 minecraft:redstone_wire replace
fill ~174 ~35 ~224 ~174 ~35 ~236 minecraft:redstone_wire replace
fill ~228 ~35 ~224 ~228 ~35 ~236 minecraft:redstone_wire replace
fill ~240 ~35 ~224 ~240 ~35 ~236 minecraft:redstone_wire replace
fill ~258 ~35 ~224 ~258 ~35 ~236 minecraft:redstone_wire replace
fill ~261 ~35 ~224 ~261 ~35 ~236 minecraft:redstone_wire replace
fill ~282 ~35 ~224 ~282 ~35 ~236 minecraft:redstone_wire replace
setblock ~93 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~232 ~93 ~35 ~244 minecraft:redstone_wire replace
fill ~120 ~35 ~232 ~120 ~35 ~244 minecraft:redstone_wire replace
fill ~144 ~35 ~232 ~144 ~35 ~244 minecraft:redstone_wire replace
fill ~150 ~35 ~232 ~150 ~35 ~244 minecraft:redstone_wire replace
fill ~168 ~35 ~232 ~168 ~35 ~244 minecraft:redstone_wire replace
fill ~195 ~35 ~232 ~195 ~35 ~244 minecraft:redstone_wire replace
fill ~201 ~35 ~232 ~201 ~35 ~244 minecraft:redstone_wire replace
fill ~225 ~35 ~232 ~225 ~35 ~244 minecraft:redstone_wire replace
fill ~246 ~35 ~232 ~246 ~35 ~244 minecraft:redstone_wire replace
fill ~264 ~35 ~232 ~264 ~35 ~244 minecraft:redstone_wire replace
fill ~285 ~35 ~232 ~285 ~35 ~244 minecraft:redstone_wire replace
fill ~315 ~35 ~232 ~315 ~35 ~244 minecraft:redstone_wire replace
fill ~327 ~35 ~232 ~327 ~35 ~244 minecraft:redstone_wire replace
fill ~339 ~35 ~232 ~339 ~35 ~244 minecraft:redstone_wire replace
fill ~387 ~35 ~232 ~387 ~35 ~244 minecraft:redstone_wire replace
setblock ~318 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~236 ~318 ~35 ~248 minecraft:redstone_wire replace
fill ~336 ~35 ~236 ~336 ~35 ~248 minecraft:redstone_wire replace
fill ~342 ~35 ~236 ~342 ~35 ~248 minecraft:redstone_wire replace
fill ~354 ~35 ~236 ~354 ~35 ~248 minecraft:redstone_wire replace
fill ~360 ~35 ~236 ~360 ~35 ~248 minecraft:redstone_wire replace
fill ~378 ~35 ~236 ~378 ~35 ~248 minecraft:redstone_wire replace
setblock ~117 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~240 ~117 ~35 ~252 minecraft:redstone_wire replace
fill ~141 ~35 ~240 ~141 ~35 ~252 minecraft:redstone_wire replace
fill ~171 ~35 ~240 ~171 ~35 ~252 minecraft:redstone_wire replace
fill ~174 ~35 ~240 ~174 ~35 ~252 minecraft:redstone_wire replace
fill ~228 ~35 ~240 ~228 ~35 ~252 minecraft:redstone_wire replace
fill ~240 ~35 ~240 ~240 ~35 ~252 minecraft:redstone_wire replace
fill ~258 ~35 ~240 ~258 ~35 ~252 minecraft:redstone_wire replace
fill ~261 ~35 ~240 ~261 ~35 ~252 minecraft:redstone_wire replace
fill ~282 ~35 ~240 ~282 ~35 ~252 minecraft:redstone_wire replace
setblock ~93 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~248 ~93 ~35 ~258 minecraft:redstone_wire replace
fill ~120 ~35 ~248 ~120 ~35 ~260 minecraft:redstone_wire replace
fill ~144 ~35 ~248 ~144 ~35 ~260 minecraft:redstone_wire replace
fill ~150 ~35 ~248 ~150 ~35 ~260 minecraft:redstone_wire replace
fill ~168 ~35 ~248 ~168 ~35 ~260 minecraft:redstone_wire replace
fill ~195 ~35 ~248 ~195 ~35 ~260 minecraft:redstone_wire replace
fill ~201 ~35 ~248 ~201 ~35 ~260 minecraft:redstone_wire replace
fill ~225 ~35 ~248 ~225 ~35 ~260 minecraft:redstone_wire replace
fill ~246 ~35 ~248 ~246 ~35 ~260 minecraft:redstone_wire replace
fill ~264 ~35 ~248 ~264 ~35 ~260 minecraft:redstone_wire replace
fill ~285 ~35 ~248 ~285 ~35 ~260 minecraft:redstone_wire replace
fill ~315 ~35 ~248 ~315 ~35 ~260 minecraft:redstone_wire replace
fill ~327 ~35 ~248 ~327 ~35 ~260 minecraft:redstone_wire replace
fill ~339 ~35 ~248 ~339 ~35 ~260 minecraft:redstone_wire replace
fill ~387 ~35 ~248 ~387 ~35 ~260 minecraft:redstone_wire replace
setblock ~318 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~252 ~318 ~35 ~264 minecraft:redstone_wire replace
fill ~336 ~35 ~252 ~336 ~35 ~264 minecraft:redstone_wire replace
fill ~342 ~35 ~252 ~342 ~35 ~264 minecraft:redstone_wire replace
fill ~354 ~35 ~252 ~354 ~35 ~264 minecraft:redstone_wire replace
fill ~360 ~35 ~252 ~360 ~35 ~264 minecraft:redstone_wire replace
fill ~378 ~35 ~252 ~378 ~35 ~264 minecraft:redstone_wire replace
setblock ~117 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~256 ~117 ~35 ~268 minecraft:redstone_wire replace
fill ~141 ~35 ~256 ~141 ~35 ~268 minecraft:redstone_wire replace
fill ~171 ~35 ~256 ~171 ~35 ~268 minecraft:redstone_wire replace
fill ~174 ~35 ~256 ~174 ~35 ~268 minecraft:redstone_wire replace
fill ~180 ~35 ~256 ~180 ~35 ~268 minecraft:redstone_wire replace
fill ~228 ~35 ~256 ~228 ~35 ~268 minecraft:redstone_wire replace
fill ~240 ~35 ~256 ~240 ~35 ~268 minecraft:redstone_wire replace
fill ~258 ~35 ~256 ~258 ~35 ~268 minecraft:redstone_wire replace
fill ~261 ~35 ~256 ~261 ~35 ~268 minecraft:redstone_wire replace
fill ~282 ~35 ~256 ~282 ~35 ~268 minecraft:redstone_wire replace
setblock ~93 ~35 ~260 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~264 minecraft:redstone_wire replace
fill ~144 ~35 ~264 ~144 ~35 ~276 minecraft:redstone_wire replace
fill ~150 ~35 ~264 ~150 ~35 ~268 minecraft:redstone_wire replace
fill ~156 ~35 ~264 ~156 ~35 ~274 minecraft:redstone_wire replace
fill ~168 ~35 ~264 ~168 ~35 ~276 minecraft:redstone_wire replace
fill ~195 ~35 ~264 ~195 ~35 ~276 minecraft:redstone_wire replace
fill ~201 ~35 ~264 ~201 ~35 ~276 minecraft:redstone_wire replace
fill ~225 ~35 ~264 ~225 ~35 ~276 minecraft:redstone_wire replace
fill ~246 ~35 ~264 ~246 ~35 ~276 minecraft:redstone_wire replace
fill ~264 ~35 ~264 ~264 ~35 ~276 minecraft:redstone_wire replace
fill ~285 ~35 ~264 ~285 ~35 ~276 minecraft:redstone_wire replace
fill ~315 ~35 ~264 ~315 ~35 ~276 minecraft:redstone_wire replace
fill ~327 ~35 ~264 ~327 ~35 ~276 minecraft:redstone_wire replace
fill ~339 ~35 ~264 ~339 ~35 ~276 minecraft:redstone_wire replace
fill ~387 ~35 ~264 ~387 ~35 ~276 minecraft:redstone_wire replace
setblock ~318 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~35 ~268 ~213 ~35 ~280 minecraft:redstone_wire replace
fill ~318 ~35 ~268 ~318 ~35 ~280 minecraft:redstone_wire replace
fill ~336 ~35 ~268 ~336 ~35 ~280 minecraft:redstone_wire replace
fill ~342 ~35 ~268 ~342 ~35 ~280 minecraft:redstone_wire replace
fill ~354 ~35 ~268 ~354 ~35 ~280 minecraft:redstone_wire replace
fill ~360 ~35 ~268 ~360 ~35 ~280 minecraft:redstone_wire replace
fill ~378 ~35 ~268 ~378 ~35 ~280 minecraft:redstone_wire replace
setblock ~117 ~35 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~270 ~117 ~35 ~278 minecraft:redstone_wire replace
fill ~141 ~35 ~270 ~141 ~35 ~282 minecraft:redstone_wire replace
fill ~171 ~35 ~270 ~171 ~35 ~282 minecraft:redstone_wire replace
setblock ~174 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~35 ~272 ~174 ~35 ~284 minecraft:redstone_wire replace
setblock ~180 ~35 ~272 minecraft:redstone_wire replace
fill ~228 ~35 ~272 ~228 ~35 ~284 minecraft:redstone_wire replace
fill ~240 ~35 ~272 ~240 ~35 ~284 minecraft:redstone_wire replace
fill ~258 ~35 ~272 ~258 ~35 ~284 minecraft:redstone_wire replace
fill ~261 ~35 ~272 ~261 ~35 ~284 minecraft:redstone_wire replace
fill ~282 ~35 ~272 ~282 ~35 ~284 minecraft:redstone_wire replace
setblock ~156 ~35 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~35 ~276 ~255 ~35 ~288 minecraft:redstone_wire replace
setblock ~144 ~35 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~35 ~278 ~144 ~35 ~290 minecraft:redstone_wire replace
fill ~168 ~35 ~278 ~168 ~35 ~290 minecraft:redstone_wire replace
setblock ~195 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~35 ~278 ~201 ~35 ~290 minecraft:redstone_wire replace
setblock ~225 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~35 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~35 ~280 ~195 ~35 ~292 minecraft:redstone_wire replace
fill ~225 ~35 ~280 ~225 ~35 ~292 minecraft:redstone_wire replace
fill ~246 ~35 ~280 ~246 ~35 ~292 minecraft:redstone_wire replace
fill ~264 ~35 ~280 ~264 ~35 ~292 minecraft:redstone_wire replace
fill ~285 ~35 ~280 ~285 ~35 ~292 minecraft:redstone_wire replace
fill ~315 ~35 ~280 ~315 ~35 ~292 minecraft:redstone_wire replace
fill ~327 ~35 ~280 ~327 ~35 ~292 minecraft:redstone_wire replace
fill ~339 ~35 ~280 ~339 ~35 ~292 minecraft:redstone_wire replace
fill ~387 ~35 ~280 ~387 ~35 ~292 minecraft:redstone_wire replace
setblock ~213 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~283 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~284 minecraft:redstone_wire replace
setblock ~171 ~35 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~35 ~284 ~213 ~35 ~290 minecraft:redstone_wire replace
fill ~318 ~35 ~284 ~318 ~35 ~296 minecraft:redstone_wire replace
fill ~336 ~35 ~284 ~336 ~35 ~296 minecraft:redstone_wire replace
fill ~342 ~35 ~284 ~342 ~35 ~296 minecraft:redstone_wire replace
fill ~354 ~35 ~284 ~354 ~35 ~296 minecraft:redstone_wire replace
fill ~360 ~35 ~284 ~360 ~35 ~296 minecraft:redstone_wire replace
fill ~378 ~35 ~284 ~378 ~35 ~296 minecraft:redstone_wire replace
setblock ~174 ~35 ~285 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~285 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~285 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~35 ~286 ~171 ~35 ~288 minecraft:redstone_wire replace
fill ~174 ~35 ~286 ~174 ~35 ~298 minecraft:redstone_wire replace
setblock ~228 ~35 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~35 ~286 ~240 ~35 ~298 minecraft:redstone_wire replace
fill ~258 ~35 ~286 ~258 ~35 ~298 minecraft:redstone_wire replace
setblock ~261 ~35 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~35 ~288 ~228 ~35 ~300 minecraft:redstone_wire replace
fill ~261 ~35 ~288 ~261 ~35 ~300 minecraft:redstone_wire replace
fill ~282 ~35 ~288 ~282 ~35 ~300 minecraft:redstone_wire replace
setblock ~255 ~35 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~35 ~292 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~35 ~292 ~255 ~35 ~304 minecraft:redstone_wire replace
fill ~303 ~35 ~292 ~303 ~35 ~304 minecraft:redstone_wire replace
setblock ~195 ~35 ~293 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~293 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~293 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~35 ~294 ~144 ~35 ~296 minecraft:redstone_wire replace
fill ~168 ~35 ~294 ~168 ~35 ~300 minecraft:redstone_wire replace
fill ~195 ~35 ~294 ~195 ~35 ~306 minecraft:redstone_wire replace
fill ~201 ~35 ~294 ~201 ~35 ~302 minecraft:redstone_wire replace
fill ~225 ~35 ~294 ~225 ~35 ~306 minecraft:redstone_wire replace
fill ~246 ~35 ~294 ~246 ~35 ~306 minecraft:redstone_wire replace
setblock ~264 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~35 ~296 ~264 ~35 ~308 minecraft:redstone_wire replace
fill ~285 ~35 ~296 ~285 ~35 ~308 minecraft:redstone_wire replace
fill ~315 ~35 ~296 ~315 ~35 ~308 minecraft:redstone_wire replace
fill ~327 ~35 ~296 ~327 ~35 ~308 minecraft:redstone_wire replace
fill ~339 ~35 ~296 ~339 ~35 ~308 minecraft:redstone_wire replace
fill ~387 ~35 ~296 ~387 ~35 ~308 minecraft:redstone_wire replace
setblock ~318 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~300 ~318 ~35 ~312 minecraft:redstone_wire replace
fill ~333 ~35 ~300 ~333 ~35 ~312 minecraft:redstone_wire replace
fill ~336 ~35 ~300 ~336 ~35 ~312 minecraft:redstone_wire replace
fill ~342 ~35 ~300 ~342 ~35 ~312 minecraft:redstone_wire replace
fill ~354 ~35 ~300 ~354 ~35 ~312 minecraft:redstone_wire replace
fill ~360 ~35 ~300 ~360 ~35 ~312 minecraft:redstone_wire replace
fill ~378 ~35 ~300 ~378 ~35 ~312 minecraft:redstone_wire replace
setblock ~228 ~35 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~35 ~302 ~174 ~35 ~310 minecraft:redstone_wire replace
fill ~228 ~35 ~302 ~228 ~35 ~314 minecraft:redstone_wire replace
fill ~240 ~35 ~302 ~240 ~35 ~314 minecraft:redstone_wire replace
fill ~258 ~35 ~302 ~258 ~35 ~314 minecraft:redstone_wire replace
fill ~261 ~35 ~302 ~261 ~35 ~314 minecraft:redstone_wire replace
fill ~282 ~35 ~302 ~282 ~35 ~314 minecraft:redstone_wire replace
setblock ~201 ~35 ~304 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~35 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~35 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~308 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~35 ~308 minecraft:redstone_wire replace
fill ~303 ~35 ~308 ~303 ~35 ~320 minecraft:redstone_wire replace
fill ~324 ~35 ~308 ~324 ~35 ~320 minecraft:redstone_wire replace
setblock ~264 ~35 ~309 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~309 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~309 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~35 ~310 ~195 ~35 ~322 minecraft:redstone_wire replace
fill ~225 ~35 ~310 ~225 ~35 ~322 minecraft:redstone_wire replace
fill ~246 ~35 ~310 ~246 ~35 ~322 minecraft:redstone_wire replace
fill ~264 ~35 ~310 ~264 ~35 ~322 minecraft:redstone_wire replace
setblock ~285 ~35 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~35 ~310 ~315 ~35 ~322 minecraft:redstone_wire replace
setblock ~327 ~35 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~35 ~310 ~339 ~35 ~322 minecraft:redstone_wire replace
setblock ~387 ~35 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~312 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~35 ~312 ~285 ~35 ~324 minecraft:redstone_wire replace
fill ~327 ~35 ~312 ~327 ~35 ~324 minecraft:redstone_wire replace
fill ~387 ~35 ~312 ~387 ~35 ~324 minecraft:redstone_wire replace
setblock ~318 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~315 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~316 minecraft:redstone_wire replace
setblock ~258 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~316 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~316 ~318 ~35 ~328 minecraft:redstone_wire replace
fill ~333 ~35 ~316 ~333 ~35 ~328 minecraft:redstone_wire replace
fill ~336 ~35 ~316 ~336 ~35 ~328 minecraft:redstone_wire replace
fill ~342 ~35 ~316 ~342 ~35 ~328 minecraft:redstone_wire replace
fill ~354 ~35 ~316 ~354 ~35 ~328 minecraft:redstone_wire replace
fill ~360 ~35 ~316 ~360 ~35 ~328 minecraft:redstone_wire replace
fill ~378 ~35 ~316 ~378 ~35 ~328 minecraft:redstone_wire replace
fill ~228 ~35 ~318 ~228 ~35 ~330 minecraft:redstone_wire replace
fill ~258 ~35 ~318 ~258 ~35 ~320 minecraft:redstone_wire replace
fill ~261 ~35 ~318 ~261 ~35 ~330 minecraft:redstone_wire replace
fill ~282 ~35 ~318 ~282 ~35 ~330 minecraft:redstone_wire replace
setblock ~303 ~35 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~35 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~323 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~324 minecraft:redstone_wire replace
setblock ~225 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~35 ~324 ~303 ~35 ~334 minecraft:redstone_wire replace
setblock ~315 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~35 ~324 ~324 ~35 ~336 minecraft:redstone_wire replace
setblock ~339 ~35 ~324 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~35 ~324 ~348 ~35 ~336 minecraft:redstone_wire replace
setblock ~285 ~35 ~325 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~325 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~325 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~35 ~326 ~225 ~35 ~328 minecraft:redstone_wire replace
fill ~246 ~35 ~326 ~246 ~35 ~332 minecraft:redstone_wire replace
fill ~264 ~35 ~326 ~264 ~35 ~338 minecraft:redstone_wire replace
fill ~285 ~35 ~326 ~285 ~35 ~338 minecraft:redstone_wire replace
fill ~315 ~35 ~326 ~315 ~35 ~338 minecraft:redstone_wire replace
fill ~327 ~35 ~326 ~327 ~35 ~338 minecraft:redstone_wire replace
fill ~339 ~35 ~326 ~339 ~35 ~338 minecraft:redstone_wire replace
fill ~387 ~35 ~326 ~387 ~35 ~338 minecraft:redstone_wire replace
setblock ~318 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~332 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~332 ~318 ~35 ~344 minecraft:redstone_wire replace
fill ~333 ~35 ~332 ~333 ~35 ~344 minecraft:redstone_wire replace
fill ~336 ~35 ~332 ~336 ~35 ~344 minecraft:redstone_wire replace
fill ~342 ~35 ~332 ~342 ~35 ~344 minecraft:redstone_wire replace
fill ~354 ~35 ~332 ~354 ~35 ~344 minecraft:redstone_wire replace
fill ~360 ~35 ~332 ~360 ~35 ~344 minecraft:redstone_wire replace
fill ~378 ~35 ~332 ~378 ~35 ~344 minecraft:redstone_wire replace
fill ~228 ~35 ~334 ~228 ~35 ~340 minecraft:redstone_wire replace
fill ~261 ~35 ~334 ~261 ~35 ~342 minecraft:redstone_wire replace
fill ~282 ~35 ~334 ~282 ~35 ~346 minecraft:redstone_wire replace
setblock ~303 ~35 ~336 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~35 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~340 ~90 ~35 ~352 minecraft:redstone_wire replace
setblock ~264 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~35 ~340 ~324 ~35 ~352 minecraft:redstone_wire replace
setblock ~327 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~35 ~340 ~348 ~35 ~352 minecraft:redstone_wire replace
setblock ~387 ~35 ~340 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~35 ~342 ~264 ~35 ~354 minecraft:redstone_wire replace
fill ~285 ~35 ~342 ~285 ~35 ~354 minecraft:redstone_wire replace
fill ~315 ~35 ~342 ~315 ~35 ~354 minecraft:redstone_wire replace
fill ~327 ~35 ~342 ~327 ~35 ~354 minecraft:redstone_wire replace
fill ~339 ~35 ~342 ~339 ~35 ~354 minecraft:redstone_wire replace
fill ~387 ~35 ~342 ~387 ~35 ~354 minecraft:redstone_wire replace
fill ~114 ~35 ~344 ~114 ~35 ~356 minecraft:redstone_wire replace
setblock ~261 ~35 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~35 ~348 ~138 ~35 ~360 minecraft:redstone_wire replace
setblock ~282 ~35 ~348 minecraft:redstone_wire replace
fill ~318 ~35 ~348 ~318 ~35 ~360 minecraft:redstone_wire replace
fill ~333 ~35 ~348 ~333 ~35 ~352 minecraft:redstone_wire replace
fill ~336 ~35 ~348 ~336 ~35 ~360 minecraft:redstone_wire replace
fill ~342 ~35 ~348 ~342 ~35 ~360 minecraft:redstone_wire replace
fill ~354 ~35 ~348 ~354 ~35 ~360 minecraft:redstone_wire replace
fill ~360 ~35 ~348 ~360 ~35 ~360 minecraft:redstone_wire replace
fill ~378 ~35 ~348 ~378 ~35 ~360 minecraft:redstone_wire replace
fill ~186 ~35 ~352 ~186 ~35 ~364 minecraft:redstone_wire replace
setblock ~90 ~35 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~35 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~355 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~356 ~90 ~35 ~368 minecraft:redstone_wire replace
fill ~216 ~35 ~356 ~216 ~35 ~368 minecraft:redstone_wire replace
setblock ~264 ~35 ~356 minecraft:redstone_wire replace
setblock ~285 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~35 ~356 ~324 ~35 ~362 minecraft:redstone_wire replace
setblock ~327 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~35 ~356 ~348 ~35 ~368 minecraft:redstone_wire replace
setblock ~387 ~35 ~356 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~35 ~358 ~285 ~35 ~370 minecraft:redstone_wire replace
fill ~315 ~35 ~358 ~315 ~35 ~360 minecraft:redstone_wire replace
fill ~327 ~35 ~358 ~327 ~35 ~370 minecraft:redstone_wire replace
fill ~339 ~35 ~358 ~339 ~35 ~366 minecraft:redstone_wire replace
fill ~387 ~35 ~358 ~387 ~35 ~370 minecraft:redstone_wire replace
fill ~114 ~35 ~360 ~114 ~35 ~372 minecraft:redstone_wire replace
fill ~243 ~35 ~360 ~243 ~35 ~372 minecraft:redstone_wire replace
setblock ~138 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~35 ~364 ~138 ~35 ~376 minecraft:redstone_wire replace
fill ~279 ~35 ~364 ~279 ~35 ~376 minecraft:redstone_wire replace
fill ~318 ~35 ~364 ~318 ~35 ~370 minecraft:redstone_wire replace
setblock ~324 ~35 ~364 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~35 ~364 ~336 ~35 ~374 minecraft:redstone_wire replace
fill ~342 ~35 ~364 ~342 ~35 ~376 minecraft:redstone_wire replace
fill ~354 ~35 ~364 ~354 ~35 ~376 minecraft:redstone_wire replace
fill ~360 ~35 ~364 ~360 ~35 ~376 minecraft:redstone_wire replace
fill ~378 ~35 ~364 ~378 ~35 ~376 minecraft:redstone_wire replace
setblock ~186 ~35 ~366 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~35 ~368 ~186 ~35 ~380 minecraft:redstone_wire replace
fill ~309 ~35 ~368 ~309 ~35 ~380 minecraft:redstone_wire replace
setblock ~339 ~35 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~35 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~372 ~90 ~35 ~384 minecraft:redstone_wire replace
fill ~216 ~35 ~372 ~216 ~35 ~384 minecraft:redstone_wire replace
setblock ~285 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~35 ~372 ~345 ~35 ~384 minecraft:redstone_wire replace
fill ~348 ~35 ~372 ~348 ~35 ~384 minecraft:redstone_wire replace
setblock ~387 ~35 ~372 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~35 ~374 ~285 ~35 ~382 minecraft:redstone_wire replace
fill ~327 ~35 ~374 ~327 ~35 ~386 minecraft:redstone_wire replace
fill ~387 ~35 ~374 ~387 ~35 ~386 minecraft:redstone_wire replace
fill ~87 ~35 ~376 ~87 ~35 ~388 minecraft:redstone_wire replace
fill ~114 ~35 ~376 ~114 ~35 ~388 minecraft:redstone_wire replace
fill ~243 ~35 ~376 ~243 ~35 ~388 minecraft:redstone_wire replace
setblock ~336 ~35 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~380 ~111 ~35 ~392 minecraft:redstone_wire replace
fill ~138 ~35 ~380 ~138 ~35 ~392 minecraft:redstone_wire replace
fill ~279 ~35 ~380 ~279 ~35 ~392 minecraft:redstone_wire replace
setblock ~342 ~35 ~380 minecraft:redstone_wire replace
fill ~354 ~35 ~380 ~354 ~35 ~392 minecraft:redstone_wire replace
fill ~360 ~35 ~380 ~360 ~35 ~392 minecraft:redstone_wire replace
fill ~378 ~35 ~380 ~378 ~35 ~392 minecraft:redstone_wire replace
setblock ~186 ~35 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~382 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~384 ~135 ~35 ~396 minecraft:redstone_wire replace
fill ~186 ~35 ~384 ~186 ~35 ~396 minecraft:redstone_wire replace
setblock ~285 ~35 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~309 ~35 ~384 ~309 ~35 ~396 minecraft:redstone_wire replace
setblock ~90 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~35 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~388 ~90 ~35 ~400 minecraft:redstone_wire replace
fill ~183 ~35 ~388 ~183 ~35 ~400 minecraft:redstone_wire replace
fill ~216 ~35 ~388 ~216 ~35 ~400 minecraft:redstone_wire replace
setblock ~327 ~35 ~388 minecraft:redstone_wire replace
fill ~345 ~35 ~388 ~345 ~35 ~400 minecraft:redstone_wire replace
fill ~348 ~35 ~388 ~348 ~35 ~392 minecraft:redstone_wire replace
setblock ~387 ~35 ~388 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~35 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~387 ~35 ~390 ~387 ~35 ~396 minecraft:redstone_wire replace
fill ~87 ~35 ~392 ~87 ~35 ~404 minecraft:redstone_wire replace
fill ~114 ~35 ~392 ~114 ~35 ~404 minecraft:redstone_wire replace
fill ~207 ~35 ~392 ~207 ~35 ~404 minecraft:redstone_wire replace
fill ~243 ~35 ~392 ~243 ~35 ~404 minecraft:redstone_wire replace
setblock ~111 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
