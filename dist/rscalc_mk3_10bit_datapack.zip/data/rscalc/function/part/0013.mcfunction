setblock ~268 ~31 ~320 minecraft:light_gray_concrete replace
setblock ~273 ~31 ~321 minecraft:light_gray_concrete replace
setblock ~274 ~31 ~324 minecraft:light_gray_concrete replace
setblock ~279 ~31 ~327 minecraft:light_gray_concrete replace
setblock ~274 ~31 ~328 minecraft:light_gray_concrete replace
setblock ~279 ~31 ~329 minecraft:light_gray_concrete replace
setblock ~280 ~31 ~332 minecraft:light_gray_concrete replace
setblock ~294 ~31 ~335 minecraft:light_gray_concrete replace
setblock ~280 ~31 ~336 minecraft:light_gray_concrete replace
setblock ~294 ~31 ~337 minecraft:light_gray_concrete replace
setblock ~295 ~31 ~340 minecraft:light_gray_concrete replace
setblock ~90 ~31 ~343 minecraft:light_gray_concrete replace
setblock ~295 ~31 ~344 minecraft:light_gray_concrete replace
setblock ~111 ~31 ~347 minecraft:light_gray_concrete replace
setblock ~135 ~31 ~351 minecraft:light_gray_concrete replace
setblock ~165 ~31 ~355 minecraft:light_gray_concrete replace
setblock ~189 ~31 ~359 minecraft:light_gray_concrete replace
setblock ~219 ~31 ~363 minecraft:light_gray_concrete replace
setblock ~243 ~31 ~367 minecraft:light_gray_concrete replace
setblock ~261 ~31 ~371 minecraft:light_gray_concrete replace
setblock ~285 ~31 ~375 minecraft:light_gray_concrete replace
setblock ~87 ~31 ~379 minecraft:light_gray_concrete replace
setblock ~108 ~31 ~383 minecraft:light_gray_concrete replace
setblock ~129 ~31 ~387 minecraft:light_gray_concrete replace
setblock ~162 ~31 ~391 minecraft:light_gray_concrete replace
setblock ~186 ~31 ~395 minecraft:light_gray_concrete replace
setblock ~210 ~31 ~399 minecraft:light_gray_concrete replace
setblock ~240 ~31 ~403 minecraft:light_gray_concrete replace
setblock ~258 ~31 ~407 minecraft:light_gray_concrete replace
setblock ~303 ~31 ~411 minecraft:light_gray_concrete replace
setblock ~321 ~31 ~415 minecraft:light_gray_concrete replace
setblock ~84 ~31 ~419 minecraft:light_gray_concrete replace
setblock ~105 ~31 ~423 minecraft:light_gray_concrete replace
setblock ~123 ~31 ~427 minecraft:light_gray_concrete replace
setblock ~159 ~31 ~431 minecraft:light_gray_concrete replace
setblock ~183 ~31 ~435 minecraft:light_gray_concrete replace
setblock ~207 ~31 ~439 minecraft:light_gray_concrete replace
setblock ~231 ~31 ~443 minecraft:light_gray_concrete replace
setblock ~255 ~31 ~447 minecraft:light_gray_concrete replace
setblock ~300 ~31 ~451 minecraft:light_gray_concrete replace
setblock ~318 ~31 ~455 minecraft:light_gray_concrete replace
setblock ~81 ~31 ~459 minecraft:light_gray_concrete replace
setblock ~102 ~31 ~463 minecraft:light_gray_concrete replace
setblock ~120 ~31 ~467 minecraft:light_gray_concrete replace
setblock ~147 ~31 ~471 minecraft:light_gray_concrete replace
setblock ~180 ~31 ~475 minecraft:light_gray_concrete replace
setblock ~204 ~31 ~479 minecraft:light_gray_concrete replace
setblock ~228 ~31 ~483 minecraft:light_gray_concrete replace
setblock ~249 ~31 ~487 minecraft:light_gray_concrete replace
setblock ~291 ~31 ~491 minecraft:light_gray_concrete replace
setblock ~315 ~31 ~495 minecraft:light_gray_concrete replace
setblock ~78 ~31 ~499 minecraft:light_gray_concrete replace
setblock ~99 ~31 ~503 minecraft:light_gray_concrete replace
setblock ~117 ~31 ~507 minecraft:light_gray_concrete replace
setblock ~141 ~31 ~511 minecraft:light_gray_concrete replace
setblock ~177 ~31 ~515 minecraft:light_gray_concrete replace
setblock ~195 ~31 ~519 minecraft:light_gray_concrete replace
setblock ~225 ~31 ~523 minecraft:light_gray_concrete replace
setblock ~246 ~31 ~527 minecraft:light_gray_concrete replace
setblock ~288 ~31 ~531 minecraft:light_gray_concrete replace
setblock ~312 ~31 ~535 minecraft:light_gray_concrete replace
setblock ~96 ~31 ~539 minecraft:light_gray_concrete replace
setblock ~114 ~31 ~543 minecraft:light_gray_concrete replace
setblock ~138 ~31 ~547 minecraft:light_gray_concrete replace
setblock ~168 ~31 ~551 minecraft:light_gray_concrete replace
setblock ~192 ~31 ~555 minecraft:light_gray_concrete replace
setblock ~222 ~31 ~559 minecraft:light_gray_concrete replace
setblock ~252 ~31 ~563 minecraft:light_gray_concrete replace
setblock ~270 ~31 ~567 minecraft:light_gray_concrete replace
setblock ~306 ~31 ~571 minecraft:light_gray_concrete replace
setblock ~156 ~31 ~575 minecraft:light_gray_concrete replace
setblock ~327 ~31 ~579 minecraft:light_gray_concrete replace
setblock ~93 ~31 ~583 minecraft:light_gray_concrete replace
setblock ~309 ~31 ~587 minecraft:light_gray_concrete replace
setblock ~324 ~31 ~591 minecraft:light_gray_concrete replace
fill ~94 ~32 ~8 ~94 ~32 ~9 minecraft:light_gray_concrete replace
fill ~121 ~32 ~8 ~121 ~32 ~9 minecraft:light_gray_concrete replace
fill ~151 ~32 ~8 ~151 ~32 ~9 minecraft:light_gray_concrete replace
fill ~178 ~32 ~8 ~178 ~32 ~9 minecraft:light_gray_concrete replace
fill ~93 ~32 ~10 ~179 ~32 ~10 minecraft:light_gray_concrete replace
fill ~118 ~32 ~16 ~118 ~32 ~17 minecraft:light_gray_concrete replace
fill ~142 ~32 ~16 ~142 ~32 ~17 minecraft:light_gray_concrete replace
fill ~172 ~32 ~16 ~172 ~32 ~17 minecraft:light_gray_concrete replace
fill ~211 ~32 ~16 ~211 ~32 ~17 minecraft:light_gray_concrete replace
fill ~117 ~32 ~18 ~212 ~32 ~18 minecraft:light_gray_concrete replace
fill ~145 ~32 ~24 ~145 ~32 ~25 minecraft:light_gray_concrete replace
fill ~169 ~32 ~24 ~169 ~32 ~25 minecraft:light_gray_concrete replace
fill ~202 ~32 ~24 ~202 ~32 ~25 minecraft:light_gray_concrete replace
fill ~253 ~32 ~24 ~253 ~32 ~25 minecraft:light_gray_concrete replace
fill ~144 ~32 ~26 ~254 ~32 ~26 minecraft:light_gray_concrete replace
fill ~175 ~32 ~32 ~175 ~32 ~33 minecraft:light_gray_concrete replace
fill ~241 ~32 ~32 ~241 ~32 ~33 minecraft:light_gray_concrete replace
fill ~259 ~32 ~32 ~259 ~32 ~33 minecraft:light_gray_concrete replace
fill ~174 ~32 ~34 ~260 ~32 ~34 minecraft:light_gray_concrete replace
fill ~196 ~32 ~40 ~196 ~32 ~41 minecraft:light_gray_concrete replace
fill ~226 ~32 ~40 ~226 ~32 ~41 minecraft:light_gray_concrete replace
fill ~247 ~32 ~40 ~247 ~32 ~41 minecraft:light_gray_concrete replace
fill ~301 ~32 ~40 ~301 ~32 ~41 minecraft:light_gray_concrete replace
fill ~195 ~32 ~42 ~302 ~32 ~42 minecraft:light_gray_concrete replace
fill ~229 ~32 ~48 ~229 ~32 ~49 minecraft:light_gray_concrete replace
fill ~262 ~32 ~48 ~262 ~32 ~49 minecraft:light_gray_concrete replace
fill ~283 ~32 ~48 ~283 ~32 ~49 minecraft:light_gray_concrete replace
fill ~331 ~32 ~48 ~331 ~32 ~49 minecraft:light_gray_concrete replace
fill ~228 ~32 ~50 ~332 ~32 ~50 minecraft:light_gray_concrete replace
fill ~265 ~32 ~56 ~265 ~32 ~57 minecraft:light_gray_concrete replace
fill ~316 ~32 ~56 ~316 ~32 ~57 minecraft:light_gray_concrete replace
fill ~322 ~32 ~56 ~322 ~32 ~57 minecraft:light_gray_concrete replace
fill ~340 ~32 ~56 ~340 ~32 ~57 minecraft:light_gray_concrete replace
fill ~264 ~32 ~58 ~341 ~32 ~58 minecraft:light_gray_concrete replace
fill ~319 ~32 ~60 ~319 ~32 ~61 minecraft:light_gray_concrete replace
fill ~337 ~32 ~60 ~337 ~32 ~61 minecraft:light_gray_concrete replace
fill ~343 ~32 ~60 ~343 ~32 ~61 minecraft:light_gray_concrete replace
fill ~276 ~32 ~62 ~344 ~32 ~62 minecraft:light_gray_concrete replace
fill ~286 ~32 ~72 ~286 ~32 ~73 minecraft:light_gray_concrete replace
fill ~328 ~32 ~72 ~328 ~32 ~73 minecraft:light_gray_concrete replace
fill ~352 ~32 ~72 ~352 ~32 ~73 minecraft:light_gray_concrete replace
fill ~388 ~32 ~72 ~388 ~32 ~73 minecraft:light_gray_concrete replace
fill ~282 ~32 ~74 ~389 ~32 ~74 minecraft:light_gray_concrete replace
fill ~355 ~32 ~76 ~355 ~32 ~77 minecraft:light_gray_concrete replace
fill ~361 ~32 ~76 ~361 ~32 ~77 minecraft:light_gray_concrete replace
fill ~379 ~32 ~76 ~379 ~32 ~77 minecraft:light_gray_concrete replace
fill ~297 ~32 ~78 ~380 ~32 ~78 minecraft:light_gray_concrete replace
fill ~94 ~32 ~256 ~94 ~32 ~257 minecraft:light_gray_concrete replace
fill ~121 ~32 ~256 ~121 ~32 ~257 minecraft:light_gray_concrete replace
fill ~151 ~32 ~256 ~151 ~32 ~257 minecraft:light_gray_concrete replace
fill ~181 ~32 ~256 ~181 ~32 ~257 minecraft:light_gray_concrete replace
fill ~93 ~32 ~258 ~182 ~32 ~258 minecraft:light_gray_concrete replace
fill ~157 ~32 ~264 ~157 ~32 ~265 minecraft:light_gray_concrete replace
fill ~144 ~32 ~266 ~158 ~32 ~266 minecraft:light_gray_concrete replace
fill ~118 ~32 ~268 ~118 ~32 ~269 minecraft:light_gray_concrete replace
fill ~142 ~32 ~268 ~142 ~32 ~269 minecraft:light_gray_concrete replace
fill ~172 ~32 ~268 ~172 ~32 ~269 minecraft:light_gray_concrete replace
fill ~214 ~32 ~268 ~214 ~32 ~269 minecraft:light_gray_concrete replace
fill ~117 ~32 ~270 ~215 ~32 ~270 minecraft:light_gray_concrete replace
fill ~145 ~32 ~276 ~145 ~32 ~277 minecraft:light_gray_concrete replace
fill ~169 ~32 ~276 ~169 ~32 ~277 minecraft:light_gray_concrete replace
fill ~202 ~32 ~276 ~202 ~32 ~277 minecraft:light_gray_concrete replace
fill ~256 ~32 ~276 ~256 ~32 ~277 minecraft:light_gray_concrete replace
fill ~144 ~32 ~278 ~257 ~32 ~278 minecraft:light_gray_concrete replace
fill ~175 ~32 ~284 ~175 ~32 ~285 minecraft:light_gray_concrete replace
fill ~241 ~32 ~284 ~241 ~32 ~285 minecraft:light_gray_concrete replace
fill ~259 ~32 ~284 ~259 ~32 ~285 minecraft:light_gray_concrete replace
fill ~174 ~32 ~286 ~260 ~32 ~286 minecraft:light_gray_concrete replace
fill ~196 ~32 ~292 ~196 ~32 ~293 minecraft:light_gray_concrete replace
fill ~226 ~32 ~292 ~226 ~32 ~293 minecraft:light_gray_concrete replace
fill ~247 ~32 ~292 ~247 ~32 ~293 minecraft:light_gray_concrete replace
fill ~304 ~32 ~292 ~304 ~32 ~293 minecraft:light_gray_concrete replace
fill ~195 ~32 ~294 ~305 ~32 ~294 minecraft:light_gray_concrete replace
fill ~229 ~32 ~300 ~229 ~32 ~301 minecraft:light_gray_concrete replace
fill ~262 ~32 ~300 ~262 ~32 ~301 minecraft:light_gray_concrete replace
fill ~283 ~32 ~300 ~283 ~32 ~301 minecraft:light_gray_concrete replace
fill ~334 ~32 ~300 ~334 ~32 ~301 minecraft:light_gray_concrete replace
fill ~228 ~32 ~302 ~335 ~32 ~302 minecraft:light_gray_concrete replace
fill ~265 ~32 ~308 ~265 ~32 ~309 minecraft:light_gray_concrete replace
fill ~316 ~32 ~308 ~316 ~32 ~309 minecraft:light_gray_concrete replace
fill ~325 ~32 ~308 ~325 ~32 ~309 minecraft:light_gray_concrete replace
fill ~340 ~32 ~308 ~340 ~32 ~309 minecraft:light_gray_concrete replace
fill ~264 ~32 ~310 ~341 ~32 ~310 minecraft:light_gray_concrete replace
fill ~319 ~32 ~316 ~319 ~32 ~317 minecraft:light_gray_concrete replace
fill ~337 ~32 ~316 ~337 ~32 ~317 minecraft:light_gray_concrete replace
fill ~343 ~32 ~316 ~343 ~32 ~317 minecraft:light_gray_concrete replace
fill ~273 ~32 ~318 ~344 ~32 ~318 minecraft:light_gray_concrete replace
fill ~286 ~32 ~324 ~286 ~32 ~325 minecraft:light_gray_concrete replace
fill ~328 ~32 ~324 ~328 ~32 ~325 minecraft:light_gray_concrete replace
fill ~349 ~32 ~324 ~349 ~32 ~325 minecraft:light_gray_concrete replace
fill ~388 ~32 ~324 ~388 ~32 ~325 minecraft:light_gray_concrete replace
fill ~279 ~32 ~326 ~389 ~32 ~326 minecraft:light_gray_concrete replace
fill ~355 ~32 ~332 ~355 ~32 ~333 minecraft:light_gray_concrete replace
fill ~361 ~32 ~332 ~361 ~32 ~333 minecraft:light_gray_concrete replace
fill ~379 ~32 ~332 ~379 ~32 ~333 minecraft:light_gray_concrete replace
fill ~294 ~32 ~334 ~380 ~32 ~334 minecraft:light_gray_concrete replace
fill ~91 ~32 ~340 ~91 ~32 ~341 minecraft:light_gray_concrete replace
fill ~90 ~32 ~342 ~92 ~32 ~342 minecraft:light_gray_concrete replace
fill ~115 ~32 ~344 ~115 ~32 ~345 minecraft:light_gray_concrete replace
fill ~111 ~32 ~346 ~116 ~32 ~346 minecraft:light_gray_concrete replace
fill ~139 ~32 ~348 ~139 ~32 ~349 minecraft:light_gray_concrete replace
fill ~135 ~32 ~350 ~140 ~32 ~350 minecraft:light_gray_concrete replace
fill ~187 ~32 ~352 ~187 ~32 ~353 minecraft:light_gray_concrete replace
fill ~165 ~32 ~354 ~188 ~32 ~354 minecraft:light_gray_concrete replace
fill ~217 ~32 ~356 ~217 ~32 ~357 minecraft:light_gray_concrete replace
fill ~189 ~32 ~358 ~218 ~32 ~358 minecraft:light_gray_concrete replace
fill ~244 ~32 ~360 ~244 ~32 ~361 minecraft:light_gray_concrete replace
fill ~219 ~32 ~362 ~245 ~32 ~362 minecraft:light_gray_concrete replace
fill ~280 ~32 ~364 ~280 ~32 ~365 minecraft:light_gray_concrete replace
fill ~243 ~32 ~366 ~281 ~32 ~366 minecraft:light_gray_concrete replace
fill ~310 ~32 ~368 ~310 ~32 ~369 minecraft:light_gray_concrete replace
fill ~261 ~32 ~370 ~311 ~32 ~370 minecraft:light_gray_concrete replace
fill ~346 ~32 ~372 ~346 ~32 ~373 minecraft:light_gray_concrete replace
fill ~285 ~32 ~374 ~347 ~32 ~374 minecraft:light_gray_concrete replace
fill ~88 ~32 ~376 ~88 ~32 ~377 minecraft:light_gray_concrete replace
fill ~87 ~32 ~378 ~89 ~32 ~378 minecraft:light_gray_concrete replace
fill ~112 ~32 ~380 ~112 ~32 ~381 minecraft:light_gray_concrete replace
fill ~108 ~32 ~382 ~113 ~32 ~382 minecraft:light_gray_concrete replace
fill ~136 ~32 ~384 ~136 ~32 ~385 minecraft:light_gray_concrete replace
fill ~129 ~32 ~386 ~137 ~32 ~386 minecraft:light_gray_concrete replace
fill ~184 ~32 ~388 ~184 ~32 ~389 minecraft:light_gray_concrete replace
fill ~162 ~32 ~390 ~185 ~32 ~390 minecraft:light_gray_concrete replace
fill ~208 ~32 ~392 ~208 ~32 ~393 minecraft:light_gray_concrete replace
fill ~186 ~32 ~394 ~209 ~32 ~394 minecraft:light_gray_concrete replace
fill ~238 ~32 ~396 ~238 ~32 ~397 minecraft:light_gray_concrete replace
fill ~210 ~32 ~398 ~239 ~32 ~398 minecraft:light_gray_concrete replace
fill ~277 ~32 ~400 ~277 ~32 ~401 minecraft:light_gray_concrete replace
fill ~240 ~32 ~402 ~278 ~32 ~402 minecraft:light_gray_concrete replace
fill ~307 ~32 ~404 ~307 ~32 ~405 minecraft:light_gray_concrete replace
fill ~258 ~32 ~406 ~308 ~32 ~406 minecraft:light_gray_concrete replace
fill ~370 ~32 ~408 ~370 ~32 ~409 minecraft:light_gray_concrete replace
fill ~303 ~32 ~410 ~371 ~32 ~410 minecraft:light_gray_concrete replace
fill ~394 ~32 ~412 ~394 ~32 ~413 minecraft:light_gray_concrete replace
fill ~321 ~32 ~414 ~395 ~32 ~414 minecraft:light_gray_concrete replace
fill ~85 ~32 ~416 ~85 ~32 ~417 minecraft:light_gray_concrete replace
fill ~84 ~32 ~418 ~86 ~32 ~418 minecraft:light_gray_concrete replace
fill ~109 ~32 ~420 ~109 ~32 ~421 minecraft:light_gray_concrete replace
fill ~105 ~32 ~422 ~110 ~32 ~422 minecraft:light_gray_concrete replace
fill ~133 ~32 ~424 ~133 ~32 ~425 minecraft:light_gray_concrete replace
fill ~123 ~32 ~426 ~134 ~32 ~426 minecraft:light_gray_concrete replace
fill ~166 ~32 ~428 ~166 ~32 ~429 minecraft:light_gray_concrete replace
fill ~159 ~32 ~430 ~167 ~32 ~430 minecraft:light_gray_concrete replace
fill ~205 ~32 ~432 ~205 ~32 ~433 minecraft:light_gray_concrete replace
fill ~183 ~32 ~434 ~206 ~32 ~434 minecraft:light_gray_concrete replace
fill ~235 ~32 ~436 ~235 ~32 ~437 minecraft:light_gray_concrete replace
fill ~207 ~32 ~438 ~236 ~32 ~438 minecraft:light_gray_concrete replace
fill ~274 ~32 ~440 ~274 ~32 ~441 minecraft:light_gray_concrete replace
fill ~231 ~32 ~442 ~275 ~32 ~442 minecraft:light_gray_concrete replace
fill ~298 ~32 ~444 ~298 ~32 ~445 minecraft:light_gray_concrete replace
fill ~255 ~32 ~446 ~299 ~32 ~446 minecraft:light_gray_concrete replace
fill ~367 ~32 ~448 ~367 ~32 ~449 minecraft:light_gray_concrete replace
fill ~300 ~32 ~450 ~368 ~32 ~450 minecraft:light_gray_concrete replace
fill ~391 ~32 ~452 ~391 ~32 ~453 minecraft:light_gray_concrete replace
fill ~318 ~32 ~454 ~392 ~32 ~454 minecraft:light_gray_concrete replace
fill ~82 ~32 ~456 ~82 ~32 ~457 minecraft:light_gray_concrete replace
fill ~81 ~32 ~458 ~83 ~32 ~458 minecraft:light_gray_concrete replace
fill ~106 ~32 ~460 ~106 ~32 ~461 minecraft:light_gray_concrete replace
fill ~102 ~32 ~462 ~107 ~32 ~462 minecraft:light_gray_concrete replace
fill ~130 ~32 ~464 ~130 ~32 ~465 minecraft:light_gray_concrete replace
fill ~120 ~32 ~466 ~131 ~32 ~466 minecraft:light_gray_concrete replace
fill ~160 ~32 ~468 ~160 ~32 ~469 minecraft:light_gray_concrete replace
fill ~147 ~32 ~470 ~161 ~32 ~470 minecraft:light_gray_concrete replace
fill ~199 ~32 ~472 ~199 ~32 ~473 minecraft:light_gray_concrete replace
fill ~180 ~32 ~474 ~200 ~32 ~474 minecraft:light_gray_concrete replace
fill ~232 ~32 ~476 ~232 ~32 ~477 minecraft:light_gray_concrete replace
fill ~204 ~32 ~478 ~233 ~32 ~478 minecraft:light_gray_concrete replace
fill ~271 ~32 ~480 ~271 ~32 ~481 minecraft:light_gray_concrete replace
fill ~228 ~32 ~482 ~272 ~32 ~482 minecraft:light_gray_concrete replace
fill ~292 ~32 ~484 ~292 ~32 ~485 minecraft:light_gray_concrete replace
fill ~249 ~32 ~486 ~293 ~32 ~486 minecraft:light_gray_concrete replace
fill ~364 ~32 ~488 ~364 ~32 ~489 minecraft:light_gray_concrete replace
fill ~291 ~32 ~490 ~365 ~32 ~490 minecraft:light_gray_concrete replace
fill ~385 ~32 ~492 ~385 ~32 ~493 minecraft:light_gray_concrete replace
fill ~315 ~32 ~494 ~386 ~32 ~494 minecraft:light_gray_concrete replace
fill ~79 ~32 ~496 ~79 ~32 ~497 minecraft:light_gray_concrete replace
fill ~78 ~32 ~498 ~80 ~32 ~498 minecraft:light_gray_concrete replace
fill ~103 ~32 ~500 ~103 ~32 ~501 minecraft:light_gray_concrete replace
fill ~99 ~32 ~502 ~104 ~32 ~502 minecraft:light_gray_concrete replace
fill ~127 ~32 ~504 ~127 ~32 ~505 minecraft:light_gray_concrete replace
fill ~117 ~32 ~506 ~128 ~32 ~506 minecraft:light_gray_concrete replace
fill ~154 ~32 ~508 ~154 ~32 ~509 minecraft:light_gray_concrete replace
fill ~141 ~32 ~510 ~155 ~32 ~510 minecraft:light_gray_concrete replace
fill ~193 ~32 ~512 ~193 ~32 ~513 minecraft:light_gray_concrete replace
fill ~177 ~32 ~514 ~194 ~32 ~514 minecraft:light_gray_concrete replace
fill ~223 ~32 ~516 ~223 ~32 ~517 minecraft:light_gray_concrete replace
fill ~195 ~32 ~518 ~224 ~32 ~518 minecraft:light_gray_concrete replace
fill ~268 ~32 ~520 ~268 ~32 ~521 minecraft:light_gray_concrete replace
fill ~225 ~32 ~522 ~269 ~32 ~522 minecraft:light_gray_concrete replace
fill ~289 ~32 ~524 ~289 ~32 ~525 minecraft:light_gray_concrete replace
fill ~246 ~32 ~526 ~290 ~32 ~526 minecraft:light_gray_concrete replace
fill ~358 ~32 ~528 ~358 ~32 ~529 minecraft:light_gray_concrete replace
fill ~288 ~32 ~530 ~359 ~32 ~530 minecraft:light_gray_concrete replace
fill ~382 ~32 ~532 ~382 ~32 ~533 minecraft:light_gray_concrete replace
fill ~312 ~32 ~534 ~383 ~32 ~534 minecraft:light_gray_concrete replace
fill ~100 ~32 ~536 ~100 ~32 ~537 minecraft:light_gray_concrete replace
fill ~96 ~32 ~538 ~101 ~32 ~538 minecraft:light_gray_concrete replace
fill ~124 ~32 ~540 ~124 ~32 ~541 minecraft:light_gray_concrete replace
fill ~114 ~32 ~542 ~125 ~32 ~542 minecraft:light_gray_concrete replace
fill ~148 ~32 ~544 ~148 ~32 ~545 minecraft:light_gray_concrete replace
fill ~138 ~32 ~546 ~149 ~32 ~546 minecraft:light_gray_concrete replace
fill ~190 ~32 ~548 ~190 ~32 ~549 minecraft:light_gray_concrete replace
fill ~168 ~32 ~550 ~191 ~32 ~550 minecraft:light_gray_concrete replace
fill ~220 ~32 ~552 ~220 ~32 ~553 minecraft:light_gray_concrete replace
fill ~192 ~32 ~554 ~221 ~32 ~554 minecraft:light_gray_concrete replace
fill ~250 ~32 ~556 ~250 ~32 ~557 minecraft:light_gray_concrete replace
fill ~222 ~32 ~558 ~251 ~32 ~558 minecraft:light_gray_concrete replace
fill ~295 ~32 ~560 ~295 ~32 ~561 minecraft:light_gray_concrete replace
fill ~252 ~32 ~562 ~296 ~32 ~562 minecraft:light_gray_concrete replace
fill ~313 ~32 ~564 ~313 ~32 ~565 minecraft:light_gray_concrete replace
fill ~270 ~32 ~566 ~314 ~32 ~566 minecraft:light_gray_concrete replace
fill ~373 ~32 ~568 ~373 ~32 ~569 minecraft:light_gray_concrete replace
fill ~306 ~32 ~570 ~374 ~32 ~570 minecraft:light_gray_concrete replace
fill ~163 ~32 ~572 ~163 ~32 ~573 minecraft:light_gray_concrete replace
fill ~156 ~32 ~574 ~164 ~32 ~574 minecraft:light_gray_concrete replace
fill ~400 ~32 ~576 ~400 ~32 ~577 minecraft:light_gray_concrete replace
fill ~327 ~32 ~578 ~401 ~32 ~578 minecraft:light_gray_concrete replace
fill ~97 ~32 ~580 ~97 ~32 ~581 minecraft:light_gray_concrete replace
fill ~93 ~32 ~582 ~98 ~32 ~582 minecraft:light_gray_concrete replace
fill ~376 ~32 ~584 ~376 ~32 ~585 minecraft:light_gray_concrete replace
fill ~309 ~32 ~586 ~377 ~32 ~586 minecraft:light_gray_concrete replace
fill ~397 ~32 ~588 ~397 ~32 ~589 minecraft:light_gray_concrete replace
fill ~324 ~32 ~590 ~398 ~32 ~590 minecraft:light_gray_concrete replace
setblock ~94 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~151 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~178 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~100 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~102 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~117 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~119 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~133 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~135 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~165 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~167 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~118 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~142 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~172 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~211 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~126 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~128 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~157 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~159 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~174 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~176 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~191 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~193 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~208 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~210 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~169 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~253 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~162 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~164 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~178 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~180 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~195 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~197 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~212 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~246 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~248 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~175 ~33 ~32 minecraft:light_gray_concrete replace
setblock ~241 ~33 ~32 minecraft:light_gray_concrete replace
setblock ~259 ~33 ~32 minecraft:light_gray_concrete replace
setblock ~189 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~191 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~205 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~207 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~222 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~224 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~254 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~196 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~226 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~247 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~301 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~204 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~206 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~220 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~222 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~237 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~239 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~254 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~271 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~273 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~288 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~290 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~262 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~283 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~241 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~243 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~258 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~260 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~275 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~277 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~311 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~265 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~322 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~340 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~270 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~272 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~288 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~302 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~304 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~318 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~320 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~336 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~60 minecraft:light_gray_concrete replace
setblock ~337 ~33 ~60 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~60 minecraft:light_gray_concrete replace
setblock ~283 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~285 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~300 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~302 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~332 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~352 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~388 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~289 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~291 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~306 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~308 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~323 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~325 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~340 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~342 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~357 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~359 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~374 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~376 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~355 ~33 ~76 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~76 minecraft:light_gray_concrete replace
setblock ~379 ~33 ~76 minecraft:light_gray_concrete replace
setblock ~303 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~305 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~321 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~335 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~337 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~351 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~353 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~369 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~94 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~151 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~181 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~100 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~102 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~117 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~119 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~147 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~162 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~164 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~157 ~33 ~264 minecraft:light_gray_concrete replace
setblock ~151 ~33 ~266 minecraft:light_gray_concrete replace
setblock ~153 ~33 ~266 minecraft:light_gray_concrete replace
setblock ~118 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~142 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~172 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~123 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~138 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~140 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~166 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~168 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~183 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~185 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~200 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~169 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~159 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~161 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~187 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~189 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~204 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~206 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~221 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~223 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~238 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~240 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~175 ~33 ~284 minecraft:light_gray_concrete replace
setblock ~241 ~33 ~284 minecraft:light_gray_concrete replace
setblock ~259 ~33 ~284 minecraft:light_gray_concrete replace
setblock ~186 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~188 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~216 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~233 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~248 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~196 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~226 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~247 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~304 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~201 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~203 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~261 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~263 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~278 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~280 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~295 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~297 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~262 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~283 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~252 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~267 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~269 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~299 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~301 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~318 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~265 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~325 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~340 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~280 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~282 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~297 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~299 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~329 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~316 minecraft:light_gray_concrete replace
setblock ~337 ~33 ~316 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~316 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~288 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~303 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~305 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~349 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~388 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~311 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~360 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~375 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~377 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~355 ~33 ~332 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~332 minecraft:light_gray_concrete replace
setblock ~379 ~33 ~332 minecraft:light_gray_concrete replace
setblock ~307 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~324 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~360 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~375 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~377 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~91 ~33 ~340 minecraft:light_gray_concrete replace
setblock ~115 ~33 ~344 minecraft:light_gray_concrete replace
setblock ~139 ~33 ~348 minecraft:light_gray_concrete replace
setblock ~187 ~33 ~352 minecraft:light_gray_concrete replace
setblock ~172 ~33 ~354 minecraft:light_gray_concrete replace
setblock ~174 ~33 ~354 minecraft:light_gray_concrete replace
setblock ~217 ~33 ~356 minecraft:light_gray_concrete replace
setblock ~196 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~198 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~213 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~215 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~244 ~33 ~360 minecraft:light_gray_concrete replace
setblock ~226 ~33 ~362 minecraft:light_gray_concrete replace
setblock ~228 ~33 ~362 minecraft:light_gray_concrete replace
setblock ~280 ~33 ~364 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~252 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~267 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~269 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~310 ~33 ~368 minecraft:light_gray_concrete replace
setblock ~268 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~270 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~285 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~287 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~302 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~304 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~346 ~33 ~372 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~311 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~345 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~88 ~33 ~376 minecraft:light_gray_concrete replace
setblock ~112 ~33 ~380 minecraft:light_gray_concrete replace
setblock ~136 ~33 ~384 minecraft:light_gray_concrete replace
setblock ~184 ~33 ~388 minecraft:light_gray_concrete replace
setblock ~169 ~33 ~390 minecraft:light_gray_concrete replace
setblock ~171 ~33 ~390 minecraft:light_gray_concrete replace
setblock ~208 ~33 ~392 minecraft:light_gray_concrete replace
