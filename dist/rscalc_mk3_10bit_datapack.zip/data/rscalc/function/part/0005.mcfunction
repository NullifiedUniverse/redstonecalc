setblock ~306 ~35 ~419 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~419 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~421 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~421 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~421 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~421 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~421 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~423 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~423 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~423 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~423 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~423 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~425 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~425 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~425 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~425 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~425 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~427 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~427 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~427 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~427 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~427 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~429 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~429 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~429 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~429 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~429 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~431 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~431 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~431 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~431 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~431 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~433 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~433 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~433 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~433 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~433 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~435 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~435 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~435 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~435 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~435 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~437 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~437 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~437 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~437 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~437 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~439 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~439 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~439 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~439 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~439 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~441 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~441 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~441 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~441 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~441 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~443 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~443 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~443 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~443 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~443 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~445 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~445 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~445 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~445 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~445 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~447 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~447 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~447 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~447 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~447 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~449 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~449 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~449 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~449 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~449 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~451 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~451 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~451 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~451 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~451 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~453 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~453 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~453 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~453 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~453 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~455 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~455 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~455 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~455 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~455 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~457 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~457 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~457 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~457 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~457 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~459 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~459 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~459 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~459 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~459 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~461 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~461 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~461 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~461 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~461 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~463 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~463 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~463 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~463 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~463 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~465 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~465 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~465 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~465 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~465 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~467 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~467 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~467 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~467 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~467 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~469 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~469 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~469 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~469 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~469 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~471 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~471 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~471 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~471 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~471 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~473 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~473 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~473 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~473 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~473 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~475 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~475 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~475 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~475 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~475 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~477 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~477 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~477 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~477 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~477 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~479 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~479 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~479 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~479 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~479 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~481 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~481 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~481 minecraft:light_gray_concrete replace
setblock ~369 ~35 ~481 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~481 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~483 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~483 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~483 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~483 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~483 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~485 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~485 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~485 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~485 minecraft:light_gray_concrete replace
setblock ~393 ~35 ~485 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~487 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~487 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~487 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~487 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~487 minecraft:light_gray_concrete replace
setblock ~84 ~35 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~489 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~489 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~489 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~491 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~491 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~491 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~35 ~493 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~493 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~493 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~493 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~493 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~495 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~495 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~495 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~495 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~495 minecraft:light_gray_concrete replace
setblock ~132 ~35 ~497 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~497 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~497 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~497 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~497 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~499 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~499 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~499 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~499 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~499 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~501 minecraft:light_gray_concrete replace
setblock ~165 ~35 ~501 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~501 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~501 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~501 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~503 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~503 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~503 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~503 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~503 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~505 minecraft:light_gray_concrete replace
setblock ~204 ~35 ~505 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~505 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~505 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~505 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~507 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~507 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~507 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~507 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~507 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~509 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~509 minecraft:light_gray_concrete replace
setblock ~234 ~35 ~509 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~509 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~509 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~511 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~511 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~511 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~511 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~511 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~513 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~513 minecraft:light_gray_concrete replace
setblock ~273 ~35 ~513 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~513 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~513 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~515 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~515 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~515 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~515 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~515 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~517 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~517 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~517 minecraft:light_gray_concrete replace
setblock ~297 ~35 ~517 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~517 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~519 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~519 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~519 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~519 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~519 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~521 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~521 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~521 minecraft:light_gray_concrete replace
setblock ~366 ~35 ~521 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~521 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~523 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~523 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~523 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~523 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~523 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~525 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~525 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~525 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~525 minecraft:light_gray_concrete replace
setblock ~390 ~35 ~525 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~527 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~527 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~527 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~527 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~527 minecraft:light_gray_concrete replace
setblock ~81 ~35 ~529 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~529 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~529 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~529 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~529 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~531 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~531 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~531 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~531 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~531 minecraft:light_gray_concrete replace
setblock ~105 ~35 ~533 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~533 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~533 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~533 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~533 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~535 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~535 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~535 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~535 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~535 minecraft:light_gray_concrete replace
setblock ~129 ~35 ~537 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~537 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~537 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~537 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~537 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~539 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~539 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~539 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~539 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~539 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~541 minecraft:light_gray_concrete replace
setblock ~159 ~35 ~541 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~541 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~541 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~541 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~543 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~543 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~543 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~543 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~543 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~545 minecraft:light_gray_concrete replace
setblock ~198 ~35 ~545 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~545 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~545 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~547 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~547 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~547 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~547 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~547 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~549 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~549 minecraft:light_gray_concrete replace
setblock ~231 ~35 ~549 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~549 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~549 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~551 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~551 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~551 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~551 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~551 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~553 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~553 minecraft:light_gray_concrete replace
setblock ~270 ~35 ~553 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~553 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~553 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~555 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~555 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~555 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~555 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~557 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~557 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~557 minecraft:light_gray_concrete replace
setblock ~291 ~35 ~557 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~557 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~559 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~559 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~559 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~559 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~559 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~561 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~561 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~561 minecraft:light_gray_concrete replace
setblock ~363 ~35 ~561 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~561 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~563 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~563 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~563 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~563 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~563 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~565 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~565 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~565 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~565 minecraft:light_gray_concrete replace
setblock ~384 ~35 ~565 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~567 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~567 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~567 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~567 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~567 minecraft:light_gray_concrete replace
setblock ~78 ~35 ~569 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~569 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~569 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~569 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~571 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~571 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~571 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~571 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~35 ~573 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~573 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~573 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~573 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~573 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~575 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~575 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~575 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~575 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~575 minecraft:light_gray_concrete replace
setblock ~126 ~35 ~577 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~577 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~577 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~577 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~577 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~579 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~579 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~579 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~579 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~579 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~581 minecraft:light_gray_concrete replace
setblock ~153 ~35 ~581 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~581 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~581 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~581 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~583 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~583 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~583 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~583 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~583 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~585 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~585 minecraft:light_gray_concrete replace
setblock ~192 ~35 ~585 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~585 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~585 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~587 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~587 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~587 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~587 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~587 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~589 minecraft:light_gray_concrete replace
setblock ~222 ~35 ~589 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~589 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~589 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~589 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~591 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~591 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~591 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~591 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~591 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~593 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~593 minecraft:light_gray_concrete replace
setblock ~267 ~35 ~593 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~593 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~593 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~595 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~595 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~595 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~595 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~595 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~597 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~597 minecraft:light_gray_concrete replace
setblock ~288 ~35 ~597 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~597 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~597 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~599 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~599 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~599 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~599 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~599 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~601 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~601 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~601 minecraft:light_gray_concrete replace
setblock ~357 ~35 ~601 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~601 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~603 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~603 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~603 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~603 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~603 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~605 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~605 minecraft:light_gray_concrete replace
setblock ~381 ~35 ~605 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~605 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~607 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~607 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~607 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~607 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~609 minecraft:light_gray_concrete replace
setblock ~99 ~35 ~609 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~609 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~609 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~611 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~611 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~611 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~611 minecraft:light_gray_concrete replace
setblock ~123 ~35 ~613 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~613 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~613 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~613 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~615 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~615 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~615 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~615 minecraft:light_gray_concrete replace
setblock ~147 ~35 ~617 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~617 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~617 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~617 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~619 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~619 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~619 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~619 minecraft:light_gray_concrete replace
setblock ~189 ~35 ~621 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~621 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~621 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~623 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~623 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~623 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~625 minecraft:light_gray_concrete replace
setblock ~219 ~35 ~625 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~625 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~627 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~627 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~627 minecraft:light_gray_concrete replace
setblock ~249 ~35 ~629 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~629 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~629 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~631 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~631 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~631 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~633 minecraft:light_gray_concrete replace
setblock ~294 ~35 ~633 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~633 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~635 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~635 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~635 minecraft:light_gray_concrete replace
setblock ~312 ~35 ~637 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~637 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~639 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~639 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~641 minecraft:light_gray_concrete replace
setblock ~372 ~35 ~641 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~643 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~643 minecraft:light_gray_concrete replace
setblock ~162 ~35 ~645 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~645 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~647 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~647 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~649 minecraft:light_gray_concrete replace
setblock ~399 ~35 ~649 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~651 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~651 minecraft:light_gray_concrete replace
setblock ~96 ~35 ~653 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~655 minecraft:light_gray_concrete replace
setblock ~375 ~35 ~657 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~659 minecraft:light_gray_concrete replace
setblock ~396 ~35 ~661 minecraft:light_gray_concrete replace
fill ~147 ~36 ~14 ~245 ~36 ~14 minecraft:light_gray_concrete replace
fill ~148 ~36 ~15 ~148 ~36 ~16 minecraft:light_gray_concrete replace
fill ~175 ~36 ~15 ~175 ~36 ~16 minecraft:light_gray_concrete replace
fill ~244 ~36 ~15 ~244 ~36 ~16 minecraft:light_gray_concrete replace
fill ~177 ~36 ~22 ~248 ~36 ~22 minecraft:light_gray_concrete replace
fill ~178 ~36 ~23 ~178 ~36 ~24 minecraft:light_gray_concrete replace
fill ~247 ~36 ~23 ~247 ~36 ~24 minecraft:light_gray_concrete replace
fill ~249 ~36 ~30 ~252 ~36 ~30 minecraft:light_gray_concrete replace
fill ~250 ~36 ~31 ~250 ~36 ~32 minecraft:light_gray_concrete replace
fill ~258 ~36 ~46 ~332 ~36 ~46 minecraft:light_gray_concrete replace
fill ~259 ~36 ~47 ~259 ~36 ~48 minecraft:light_gray_concrete replace
fill ~316 ~36 ~47 ~316 ~36 ~48 minecraft:light_gray_concrete replace
fill ~331 ~36 ~47 ~331 ~36 ~48 minecraft:light_gray_concrete replace
fill ~318 ~36 ~54 ~335 ~36 ~54 minecraft:light_gray_concrete replace
fill ~319 ~36 ~55 ~319 ~36 ~56 minecraft:light_gray_concrete replace
fill ~334 ~36 ~55 ~334 ~36 ~56 minecraft:light_gray_concrete replace
fill ~321 ~36 ~62 ~326 ~36 ~62 minecraft:light_gray_concrete replace
fill ~325 ~36 ~63 ~325 ~36 ~64 minecraft:light_gray_concrete replace
fill ~348 ~36 ~78 ~351 ~36 ~78 minecraft:light_gray_concrete replace
fill ~349 ~36 ~79 ~349 ~36 ~80 minecraft:light_gray_concrete replace
fill ~93 ~36 ~262 ~95 ~36 ~262 minecraft:light_gray_concrete replace
fill ~94 ~36 ~263 ~94 ~36 ~264 minecraft:light_gray_concrete replace
fill ~120 ~36 ~266 ~125 ~36 ~266 minecraft:light_gray_concrete replace
fill ~124 ~36 ~267 ~124 ~36 ~268 minecraft:light_gray_concrete replace
fill ~93 ~36 ~270 ~254 ~36 ~270 minecraft:light_gray_concrete replace
fill ~94 ~36 ~271 ~94 ~36 ~272 minecraft:light_gray_concrete replace
fill ~127 ~36 ~271 ~127 ~36 ~272 minecraft:light_gray_concrete replace
fill ~154 ~36 ~271 ~154 ~36 ~272 minecraft:light_gray_concrete replace
fill ~184 ~36 ~271 ~184 ~36 ~272 minecraft:light_gray_concrete replace
fill ~253 ~36 ~271 ~253 ~36 ~272 minecraft:light_gray_concrete replace
fill ~147 ~36 ~274 ~245 ~36 ~274 minecraft:light_gray_concrete replace
fill ~148 ~36 ~275 ~148 ~36 ~276 minecraft:light_gray_concrete replace
fill ~175 ~36 ~275 ~175 ~36 ~276 minecraft:light_gray_concrete replace
fill ~244 ~36 ~275 ~244 ~36 ~276 minecraft:light_gray_concrete replace
fill ~96 ~36 ~278 ~254 ~36 ~278 minecraft:light_gray_concrete replace
fill ~97 ~36 ~279 ~97 ~36 ~280 minecraft:light_gray_concrete replace
fill ~127 ~36 ~279 ~127 ~36 ~280 minecraft:light_gray_concrete replace
fill ~154 ~36 ~279 ~154 ~36 ~280 minecraft:light_gray_concrete replace
fill ~184 ~36 ~279 ~184 ~36 ~280 minecraft:light_gray_concrete replace
fill ~253 ~36 ~279 ~253 ~36 ~280 minecraft:light_gray_concrete replace
fill ~117 ~36 ~282 ~122 ~36 ~282 minecraft:light_gray_concrete replace
fill ~121 ~36 ~283 ~121 ~36 ~284 minecraft:light_gray_concrete replace
fill ~141 ~36 ~286 ~152 ~36 ~286 minecraft:light_gray_concrete replace
fill ~151 ~36 ~287 ~151 ~36 ~288 minecraft:light_gray_concrete replace
fill ~120 ~36 ~290 ~254 ~36 ~290 minecraft:light_gray_concrete replace
fill ~121 ~36 ~291 ~121 ~36 ~292 minecraft:light_gray_concrete replace
fill ~148 ~36 ~291 ~148 ~36 ~292 minecraft:light_gray_concrete replace
fill ~154 ~36 ~291 ~154 ~36 ~292 minecraft:light_gray_concrete replace
fill ~175 ~36 ~291 ~175 ~36 ~292 minecraft:light_gray_concrete replace
fill ~184 ~36 ~291 ~184 ~36 ~292 minecraft:light_gray_concrete replace
fill ~244 ~36 ~291 ~244 ~36 ~292 minecraft:light_gray_concrete replace
fill ~253 ~36 ~291 ~253 ~36 ~292 minecraft:light_gray_concrete replace
fill ~177 ~36 ~294 ~248 ~36 ~294 minecraft:light_gray_concrete replace
fill ~178 ~36 ~295 ~178 ~36 ~296 minecraft:light_gray_concrete replace
fill ~247 ~36 ~295 ~247 ~36 ~296 minecraft:light_gray_concrete replace
fill ~144 ~36 ~298 ~158 ~36 ~298 minecraft:light_gray_concrete replace
fill ~157 ~36 ~299 ~157 ~36 ~300 minecraft:light_gray_concrete replace
fill ~168 ~36 ~302 ~182 ~36 ~302 minecraft:light_gray_concrete replace
fill ~181 ~36 ~303 ~181 ~36 ~304 minecraft:light_gray_concrete replace
fill ~156 ~36 ~306 ~254 ~36 ~306 minecraft:light_gray_concrete replace
fill ~157 ~36 ~307 ~157 ~36 ~308 minecraft:light_gray_concrete replace
fill ~175 ~36 ~307 ~175 ~36 ~308 minecraft:light_gray_concrete replace
fill ~178 ~36 ~307 ~178 ~36 ~308 minecraft:light_gray_concrete replace
fill ~184 ~36 ~307 ~184 ~36 ~308 minecraft:light_gray_concrete replace
fill ~244 ~36 ~307 ~244 ~36 ~308 minecraft:light_gray_concrete replace
fill ~247 ~36 ~307 ~247 ~36 ~308 minecraft:light_gray_concrete replace
fill ~253 ~36 ~307 ~253 ~36 ~308 minecraft:light_gray_concrete replace
fill ~249 ~36 ~310 ~255 ~36 ~310 minecraft:light_gray_concrete replace
fill ~250 ~36 ~311 ~250 ~36 ~312 minecraft:light_gray_concrete replace
fill ~174 ~36 ~314 ~188 ~36 ~314 minecraft:light_gray_concrete replace
fill ~187 ~36 ~315 ~187 ~36 ~316 minecraft:light_gray_concrete replace
fill ~186 ~36 ~318 ~254 ~36 ~318 minecraft:light_gray_concrete replace
fill ~187 ~36 ~319 ~187 ~36 ~320 minecraft:light_gray_concrete replace
fill ~244 ~36 ~319 ~244 ~36 ~320 minecraft:light_gray_concrete replace
fill ~247 ~36 ~319 ~247 ~36 ~320 minecraft:light_gray_concrete replace
fill ~250 ~36 ~319 ~250 ~36 ~320 minecraft:light_gray_concrete replace
fill ~253 ~36 ~319 ~253 ~36 ~320 minecraft:light_gray_concrete replace
fill ~255 ~36 ~322 ~258 ~36 ~322 minecraft:light_gray_concrete replace
fill ~256 ~36 ~323 ~256 ~36 ~324 minecraft:light_gray_concrete replace
fill ~195 ~36 ~326 ~203 ~36 ~326 minecraft:light_gray_concrete replace
fill ~202 ~36 ~327 ~202 ~36 ~328 minecraft:light_gray_concrete replace
fill ~222 ~36 ~330 ~225 ~36 ~330 minecraft:light_gray_concrete replace
fill ~223 ~36 ~331 ~223 ~36 ~332 minecraft:light_gray_concrete replace
fill ~201 ~36 ~334 ~281 ~36 ~334 minecraft:light_gray_concrete replace
fill ~202 ~36 ~335 ~202 ~36 ~336 minecraft:light_gray_concrete replace
fill ~280 ~36 ~335 ~280 ~36 ~336 minecraft:light_gray_concrete replace
fill ~258 ~36 ~338 ~332 ~36 ~338 minecraft:light_gray_concrete replace
fill ~259 ~36 ~339 ~259 ~36 ~340 minecraft:light_gray_concrete replace
fill ~316 ~36 ~339 ~316 ~36 ~340 minecraft:light_gray_concrete replace
fill ~331 ~36 ~339 ~331 ~36 ~340 minecraft:light_gray_concrete replace
fill ~225 ~36 ~342 ~228 ~36 ~342 minecraft:light_gray_concrete replace
fill ~226 ~36 ~343 ~226 ~36 ~344 minecraft:light_gray_concrete replace
fill ~261 ~36 ~346 ~263 ~36 ~346 minecraft:light_gray_concrete replace
fill ~262 ~36 ~347 ~262 ~36 ~348 minecraft:light_gray_concrete replace
fill ~225 ~36 ~350 ~332 ~36 ~350 minecraft:light_gray_concrete replace
fill ~226 ~36 ~351 ~226 ~36 ~352 minecraft:light_gray_concrete replace
fill ~259 ~36 ~351 ~259 ~36 ~352 minecraft:light_gray_concrete replace
fill ~298 ~36 ~351 ~298 ~36 ~352 minecraft:light_gray_concrete replace
fill ~316 ~36 ~351 ~316 ~36 ~352 minecraft:light_gray_concrete replace
fill ~331 ~36 ~351 ~331 ~36 ~352 minecraft:light_gray_concrete replace
fill ~318 ~36 ~354 ~335 ~36 ~354 minecraft:light_gray_concrete replace
fill ~319 ~36 ~355 ~319 ~36 ~356 minecraft:light_gray_concrete replace
fill ~334 ~36 ~355 ~334 ~36 ~356 minecraft:light_gray_concrete replace
fill ~264 ~36 ~358 ~266 ~36 ~358 minecraft:light_gray_concrete replace
fill ~265 ~36 ~359 ~265 ~36 ~360 minecraft:light_gray_concrete replace
fill ~264 ~36 ~362 ~335 ~36 ~362 minecraft:light_gray_concrete replace
fill ~265 ~36 ~363 ~265 ~36 ~364 minecraft:light_gray_concrete replace
fill ~316 ~36 ~363 ~316 ~36 ~364 minecraft:light_gray_concrete replace
fill ~319 ~36 ~363 ~319 ~36 ~364 minecraft:light_gray_concrete replace
fill ~322 ~36 ~363 ~322 ~36 ~364 minecraft:light_gray_concrete replace
fill ~331 ~36 ~363 ~331 ~36 ~364 minecraft:light_gray_concrete replace
fill ~334 ~36 ~363 ~334 ~36 ~364 minecraft:light_gray_concrete replace
fill ~324 ~36 ~366 ~326 ~36 ~366 minecraft:light_gray_concrete replace
fill ~325 ~36 ~367 ~325 ~36 ~368 minecraft:light_gray_concrete replace
fill ~336 ~36 ~370 ~339 ~36 ~370 minecraft:light_gray_concrete replace
fill ~337 ~36 ~371 ~337 ~36 ~372 minecraft:light_gray_concrete replace
fill ~312 ~36 ~374 ~341 ~36 ~374 minecraft:light_gray_concrete replace
fill ~313 ~36 ~375 ~313 ~36 ~376 minecraft:light_gray_concrete replace
fill ~316 ~36 ~375 ~316 ~36 ~376 minecraft:light_gray_concrete replace
fill ~319 ~36 ~375 ~319 ~36 ~376 minecraft:light_gray_concrete replace
fill ~325 ~36 ~375 ~325 ~36 ~376 minecraft:light_gray_concrete replace
fill ~340 ~36 ~375 ~340 ~36 ~376 minecraft:light_gray_concrete replace
fill ~327 ~36 ~378 ~336 ~36 ~378 minecraft:light_gray_concrete replace
fill ~328 ~36 ~379 ~328 ~36 ~380 minecraft:light_gray_concrete replace
fill ~339 ~36 ~382 ~342 ~36 ~382 minecraft:light_gray_concrete replace
fill ~340 ~36 ~383 ~340 ~36 ~384 minecraft:light_gray_concrete replace
fill ~285 ~36 ~386 ~287 ~36 ~386 minecraft:light_gray_concrete replace
fill ~286 ~36 ~387 ~286 ~36 ~388 minecraft:light_gray_concrete replace
fill ~285 ~36 ~390 ~365 ~36 ~390 minecraft:light_gray_concrete replace
fill ~286 ~36 ~391 ~286 ~36 ~392 minecraft:light_gray_concrete replace
fill ~364 ~36 ~391 ~364 ~36 ~392 minecraft:light_gray_concrete replace
fill ~348 ~36 ~394 ~350 ~36 ~394 minecraft:light_gray_concrete replace
fill ~349 ~36 ~395 ~349 ~36 ~396 minecraft:light_gray_concrete replace
fill ~384 ~36 ~398 ~387 ~36 ~398 minecraft:light_gray_concrete replace
fill ~385 ~36 ~399 ~385 ~36 ~400 minecraft:light_gray_concrete replace
fill ~351 ~36 ~402 ~354 ~36 ~402 minecraft:light_gray_concrete replace
fill ~352 ~36 ~403 ~352 ~36 ~404 minecraft:light_gray_concrete replace
fill ~345 ~36 ~406 ~377 ~36 ~406 minecraft:light_gray_concrete replace
fill ~346 ~36 ~407 ~346 ~36 ~408 minecraft:light_gray_concrete replace
fill ~349 ~36 ~407 ~349 ~36 ~408 minecraft:light_gray_concrete replace
fill ~376 ~36 ~407 ~376 ~36 ~408 minecraft:light_gray_concrete replace
fill ~375 ~36 ~410 ~378 ~36 ~410 minecraft:light_gray_concrete replace
fill ~376 ~36 ~411 ~376 ~36 ~412 minecraft:light_gray_concrete replace
fill ~90 ~36 ~414 ~92 ~36 ~414 minecraft:light_gray_concrete replace
fill ~91 ~36 ~415 ~91 ~36 ~416 minecraft:light_gray_concrete replace
fill ~114 ~36 ~418 ~119 ~36 ~418 minecraft:light_gray_concrete replace
fill ~118 ~36 ~419 ~118 ~36 ~420 minecraft:light_gray_concrete replace
fill ~138 ~36 ~422 ~146 ~36 ~422 minecraft:light_gray_concrete replace
fill ~145 ~36 ~423 ~145 ~36 ~424 minecraft:light_gray_concrete replace
fill ~186 ~36 ~426 ~194 ~36 ~426 minecraft:light_gray_concrete replace
fill ~193 ~36 ~427 ~193 ~36 ~428 minecraft:light_gray_concrete replace
fill ~213 ~36 ~430 ~216 ~36 ~430 minecraft:light_gray_concrete replace
fill ~214 ~36 ~431 ~214 ~36 ~432 minecraft:light_gray_concrete replace
fill ~237 ~36 ~434 ~243 ~36 ~434 minecraft:light_gray_concrete replace
fill ~238 ~36 ~435 ~238 ~36 ~436 minecraft:light_gray_concrete replace
fill ~279 ~36 ~438 ~284 ~36 ~438 minecraft:light_gray_concrete replace
fill ~283 ~36 ~439 ~283 ~36 ~440 minecraft:light_gray_concrete replace
fill ~306 ~36 ~442 ~309 ~36 ~442 minecraft:light_gray_concrete replace
fill ~307 ~36 ~443 ~307 ~36 ~444 minecraft:light_gray_concrete replace
fill ~342 ~36 ~446 ~345 ~36 ~446 minecraft:light_gray_concrete replace
fill ~343 ~36 ~447 ~343 ~36 ~448 minecraft:light_gray_concrete replace
fill ~87 ~36 ~450 ~89 ~36 ~450 minecraft:light_gray_concrete replace
fill ~88 ~36 ~451 ~88 ~36 ~452 minecraft:light_gray_concrete replace
fill ~111 ~36 ~454 ~116 ~36 ~454 minecraft:light_gray_concrete replace
fill ~115 ~36 ~455 ~115 ~36 ~456 minecraft:light_gray_concrete replace
fill ~135 ~36 ~458 ~143 ~36 ~458 minecraft:light_gray_concrete replace
fill ~142 ~36 ~459 ~142 ~36 ~460 minecraft:light_gray_concrete replace
fill ~183 ~36 ~462 ~191 ~36 ~462 minecraft:light_gray_concrete replace
fill ~190 ~36 ~463 ~190 ~36 ~464 minecraft:light_gray_concrete replace
fill ~207 ~36 ~466 ~212 ~36 ~466 minecraft:light_gray_concrete replace
fill ~211 ~36 ~467 ~211 ~36 ~468 minecraft:light_gray_concrete replace
fill ~234 ~36 ~470 ~237 ~36 ~470 minecraft:light_gray_concrete replace
fill ~235 ~36 ~471 ~235 ~36 ~472 minecraft:light_gray_concrete replace
fill ~276 ~36 ~474 ~278 ~36 ~474 minecraft:light_gray_concrete replace
fill ~277 ~36 ~475 ~277 ~36 ~476 minecraft:light_gray_concrete replace
fill ~303 ~36 ~478 ~306 ~36 ~478 minecraft:light_gray_concrete replace
fill ~304 ~36 ~479 ~304 ~36 ~480 minecraft:light_gray_concrete replace
fill ~366 ~36 ~482 ~369 ~36 ~482 minecraft:light_gray_concrete replace
fill ~367 ~36 ~483 ~367 ~36 ~484 minecraft:light_gray_concrete replace
fill ~390 ~36 ~486 ~393 ~36 ~486 minecraft:light_gray_concrete replace
fill ~391 ~36 ~487 ~391 ~36 ~488 minecraft:light_gray_concrete replace
fill ~84 ~36 ~490 ~86 ~36 ~490 minecraft:light_gray_concrete replace
fill ~85 ~36 ~491 ~85 ~36 ~492 minecraft:light_gray_concrete replace
fill ~108 ~36 ~494 ~113 ~36 ~494 minecraft:light_gray_concrete replace
fill ~112 ~36 ~495 ~112 ~36 ~496 minecraft:light_gray_concrete replace
fill ~132 ~36 ~498 ~140 ~36 ~498 minecraft:light_gray_concrete replace
fill ~139 ~36 ~499 ~139 ~36 ~500 minecraft:light_gray_concrete replace
fill ~165 ~36 ~502 ~173 ~36 ~502 minecraft:light_gray_concrete replace
fill ~172 ~36 ~503 ~172 ~36 ~504 minecraft:light_gray_concrete replace
fill ~204 ~36 ~506 ~209 ~36 ~506 minecraft:light_gray_concrete replace
fill ~208 ~36 ~507 ~208 ~36 ~508 minecraft:light_gray_concrete replace
fill ~231 ~36 ~510 ~234 ~36 ~510 minecraft:light_gray_concrete replace
fill ~232 ~36 ~511 ~232 ~36 ~512 minecraft:light_gray_concrete replace
fill ~273 ~36 ~514 ~275 ~36 ~514 minecraft:light_gray_concrete replace
fill ~274 ~36 ~515 ~274 ~36 ~516 minecraft:light_gray_concrete replace
fill ~297 ~36 ~518 ~302 ~36 ~518 minecraft:light_gray_concrete replace
fill ~301 ~36 ~519 ~301 ~36 ~520 minecraft:light_gray_concrete replace
fill ~360 ~36 ~522 ~366 ~36 ~522 minecraft:light_gray_concrete replace
fill ~361 ~36 ~523 ~361 ~36 ~524 minecraft:light_gray_concrete replace
fill ~387 ~36 ~526 ~390 ~36 ~526 minecraft:light_gray_concrete replace
fill ~388 ~36 ~527 ~388 ~36 ~528 minecraft:light_gray_concrete replace
fill ~81 ~36 ~530 ~83 ~36 ~530 minecraft:light_gray_concrete replace
fill ~82 ~36 ~531 ~82 ~36 ~532 minecraft:light_gray_concrete replace
fill ~105 ~36 ~534 ~110 ~36 ~534 minecraft:light_gray_concrete replace
fill ~109 ~36 ~535 ~109 ~36 ~536 minecraft:light_gray_concrete replace
fill ~129 ~36 ~538 ~137 ~36 ~538 minecraft:light_gray_concrete replace
fill ~136 ~36 ~539 ~136 ~36 ~540 minecraft:light_gray_concrete replace
fill ~159 ~36 ~542 ~167 ~36 ~542 minecraft:light_gray_concrete replace
fill ~166 ~36 ~543 ~166 ~36 ~544 minecraft:light_gray_concrete replace
fill ~198 ~36 ~546 ~206 ~36 ~546 minecraft:light_gray_concrete replace
fill ~205 ~36 ~547 ~205 ~36 ~548 minecraft:light_gray_concrete replace
fill ~228 ~36 ~550 ~231 ~36 ~550 minecraft:light_gray_concrete replace
fill ~229 ~36 ~551 ~229 ~36 ~552 minecraft:light_gray_concrete replace
fill ~270 ~36 ~554 ~272 ~36 ~554 minecraft:light_gray_concrete replace
fill ~271 ~36 ~555 ~271 ~36 ~556 minecraft:light_gray_concrete replace
fill ~291 ~36 ~558 ~293 ~36 ~558 minecraft:light_gray_concrete replace
fill ~292 ~36 ~559 ~292 ~36 ~560 minecraft:light_gray_concrete replace
fill ~357 ~36 ~562 ~363 ~36 ~562 minecraft:light_gray_concrete replace
fill ~358 ~36 ~563 ~358 ~36 ~564 minecraft:light_gray_concrete replace
fill ~381 ~36 ~566 ~384 ~36 ~566 minecraft:light_gray_concrete replace
fill ~382 ~36 ~567 ~382 ~36 ~568 minecraft:light_gray_concrete replace
fill ~78 ~36 ~570 ~80 ~36 ~570 minecraft:light_gray_concrete replace
fill ~79 ~36 ~571 ~79 ~36 ~572 minecraft:light_gray_concrete replace
fill ~102 ~36 ~574 ~107 ~36 ~574 minecraft:light_gray_concrete replace
fill ~106 ~36 ~575 ~106 ~36 ~576 minecraft:light_gray_concrete replace
fill ~126 ~36 ~578 ~134 ~36 ~578 minecraft:light_gray_concrete replace
fill ~133 ~36 ~579 ~133 ~36 ~580 minecraft:light_gray_concrete replace
fill ~153 ~36 ~582 ~164 ~36 ~582 minecraft:light_gray_concrete replace
fill ~163 ~36 ~583 ~163 ~36 ~584 minecraft:light_gray_concrete replace
fill ~192 ~36 ~586 ~200 ~36 ~586 minecraft:light_gray_concrete replace
fill ~199 ~36 ~587 ~199 ~36 ~588 minecraft:light_gray_concrete replace
fill ~219 ~36 ~590 ~222 ~36 ~590 minecraft:light_gray_concrete replace
fill ~220 ~36 ~591 ~220 ~36 ~592 minecraft:light_gray_concrete replace
fill ~267 ~36 ~594 ~269 ~36 ~594 minecraft:light_gray_concrete replace
fill ~268 ~36 ~595 ~268 ~36 ~596 minecraft:light_gray_concrete replace
fill ~288 ~36 ~598 ~290 ~36 ~598 minecraft:light_gray_concrete replace
fill ~289 ~36 ~599 ~289 ~36 ~600 minecraft:light_gray_concrete replace
fill ~354 ~36 ~602 ~357 ~36 ~602 minecraft:light_gray_concrete replace
fill ~355 ~36 ~603 ~355 ~36 ~604 minecraft:light_gray_concrete replace
fill ~378 ~36 ~606 ~381 ~36 ~606 minecraft:light_gray_concrete replace
fill ~379 ~36 ~607 ~379 ~36 ~608 minecraft:light_gray_concrete replace
fill ~99 ~36 ~610 ~104 ~36 ~610 minecraft:light_gray_concrete replace
fill ~103 ~36 ~611 ~103 ~36 ~612 minecraft:light_gray_concrete replace
fill ~123 ~36 ~614 ~131 ~36 ~614 minecraft:light_gray_concrete replace
fill ~130 ~36 ~615 ~130 ~36 ~616 minecraft:light_gray_concrete replace
fill ~147 ~36 ~618 ~161 ~36 ~618 minecraft:light_gray_concrete replace
fill ~160 ~36 ~619 ~160 ~36 ~620 minecraft:light_gray_concrete replace
fill ~189 ~36 ~622 ~197 ~36 ~622 minecraft:light_gray_concrete replace
fill ~196 ~36 ~623 ~196 ~36 ~624 minecraft:light_gray_concrete replace
fill ~216 ~36 ~626 ~219 ~36 ~626 minecraft:light_gray_concrete replace
fill ~217 ~36 ~627 ~217 ~36 ~628 minecraft:light_gray_concrete replace
fill ~240 ~36 ~630 ~249 ~36 ~630 minecraft:light_gray_concrete replace
fill ~241 ~36 ~631 ~241 ~36 ~632 minecraft:light_gray_concrete replace
fill ~294 ~36 ~634 ~296 ~36 ~634 minecraft:light_gray_concrete replace
fill ~295 ~36 ~635 ~295 ~36 ~636 minecraft:light_gray_concrete replace
fill ~309 ~36 ~638 ~312 ~36 ~638 minecraft:light_gray_concrete replace
fill ~310 ~36 ~639 ~310 ~36 ~640 minecraft:light_gray_concrete replace
fill ~369 ~36 ~642 ~372 ~36 ~642 minecraft:light_gray_concrete replace
fill ~370 ~36 ~643 ~370 ~36 ~644 minecraft:light_gray_concrete replace
fill ~162 ~36 ~646 ~170 ~36 ~646 minecraft:light_gray_concrete replace
fill ~169 ~36 ~647 ~169 ~36 ~648 minecraft:light_gray_concrete replace
fill ~396 ~36 ~650 ~399 ~36 ~650 minecraft:light_gray_concrete replace
fill ~397 ~36 ~651 ~397 ~36 ~652 minecraft:light_gray_concrete replace
fill ~96 ~36 ~654 ~101 ~36 ~654 minecraft:light_gray_concrete replace
fill ~100 ~36 ~655 ~100 ~36 ~656 minecraft:light_gray_concrete replace
fill ~372 ~36 ~658 ~375 ~36 ~658 minecraft:light_gray_concrete replace
fill ~373 ~36 ~659 ~373 ~36 ~660 minecraft:light_gray_concrete replace
fill ~393 ~36 ~662 ~396 ~36 ~662 minecraft:light_gray_concrete replace
fill ~394 ~36 ~663 ~394 ~36 ~664 minecraft:light_gray_concrete replace
setblock ~151 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~153 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~168 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~170 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~201 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~203 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~218 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~220 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~235 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~237 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~148 ~37 ~16 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~16 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~16 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~201 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~203 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~217 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~219 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~234 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~236 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~178 ~37 ~24 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~24 minecraft:light_gray_concrete replace
setblock ~250 ~37 ~32 minecraft:light_gray_concrete replace
setblock ~260 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~262 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~276 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~278 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~292 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~294 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~307 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~309 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~324 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~326 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~259 ~37 ~48 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~48 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~48 minecraft:light_gray_concrete replace
setblock ~321 ~37 ~54 minecraft:light_gray_concrete replace
setblock ~323 ~37 ~54 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~56 minecraft:light_gray_concrete replace
setblock ~334 ~37 ~56 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~64 minecraft:light_gray_concrete replace
setblock ~349 ~37 ~80 minecraft:light_gray_concrete replace
setblock ~94 ~37 ~264 minecraft:light_gray_concrete replace
setblock ~124 ~37 ~268 minecraft:light_gray_concrete replace
setblock ~106 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~108 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~123 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~125 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~140 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~142 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~158 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~160 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~177 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~192 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~194 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~209 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~243 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~245 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~94 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~127 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~149 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~151 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~166 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~168 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~192 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~194 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~209 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~148 ~37 ~276 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~276 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~276 minecraft:light_gray_concrete replace
setblock ~109 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~111 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~141 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~143 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~169 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~171 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~188 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~203 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~205 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~220 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~222 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~237 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~239 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~97 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~127 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~121 ~37 ~284 minecraft:light_gray_concrete replace
setblock ~151 ~37 ~288 minecraft:light_gray_concrete replace
setblock ~125 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~127 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~142 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~144 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~159 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~161 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~181 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~183 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~198 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~200 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~215 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~217 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~232 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~234 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~249 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~251 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~121 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~148 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~181 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~183 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~198 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~200 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~243 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~245 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~178 ~37 ~296 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~296 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~298 minecraft:light_gray_concrete replace
setblock ~156 ~37 ~298 minecraft:light_gray_concrete replace
setblock ~157 ~37 ~300 minecraft:light_gray_concrete replace
setblock ~174 ~37 ~302 minecraft:light_gray_concrete replace
setblock ~176 ~37 ~302 minecraft:light_gray_concrete replace
setblock ~181 ~37 ~304 minecraft:light_gray_concrete replace
setblock ~169 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~171 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~188 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~214 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~216 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~231 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~233 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~157 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~178 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~250 ~37 ~312 minecraft:light_gray_concrete replace
setblock ~187 ~37 ~316 minecraft:light_gray_concrete replace
setblock ~192 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~194 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~209 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~187 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~250 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~256 ~37 ~324 minecraft:light_gray_concrete replace
setblock ~202 ~37 ~328 minecraft:light_gray_concrete replace
setblock ~223 ~37 ~332 minecraft:light_gray_concrete replace
setblock ~204 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~206 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~221 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~223 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~238 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~240 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~252 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~254 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~269 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~202 ~37 ~336 minecraft:light_gray_concrete replace
setblock ~280 ~37 ~336 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~273 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~288 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~290 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~259 ~37 ~340 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~340 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~340 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~344 minecraft:light_gray_concrete replace
setblock ~262 ~37 ~348 minecraft:light_gray_concrete replace
setblock ~234 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~236 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~251 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~268 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~270 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~294 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~296 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~311 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~313 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~328 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~330 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~259 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~298 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~323 ~37 ~354 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~354 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~356 minecraft:light_gray_concrete replace
setblock ~334 ~37 ~356 minecraft:light_gray_concrete replace
setblock ~265 ~37 ~360 minecraft:light_gray_concrete replace
setblock ~269 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~286 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~288 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~303 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~305 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~327 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~265 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~322 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~334 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~368 minecraft:light_gray_concrete replace
setblock ~337 ~37 ~372 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~374 minecraft:light_gray_concrete replace
setblock ~333 ~37 ~374 minecraft:light_gray_concrete replace
setblock ~313 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~340 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~328 ~37 ~380 minecraft:light_gray_concrete replace
setblock ~340 ~37 ~384 minecraft:light_gray_concrete replace
setblock ~286 ~37 ~388 minecraft:light_gray_concrete replace
setblock ~296 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~298 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~313 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~315 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~339 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~341 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~356 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~358 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~286 ~37 ~392 minecraft:light_gray_concrete replace
setblock ~364 ~37 ~392 minecraft:light_gray_concrete replace
setblock ~349 ~37 ~396 minecraft:light_gray_concrete replace
setblock ~385 ~37 ~400 minecraft:light_gray_concrete replace
setblock ~352 ~37 ~404 minecraft:light_gray_concrete replace
setblock ~373 ~37 ~406 minecraft:light_gray_concrete replace
setblock ~375 ~37 ~406 minecraft:light_gray_concrete replace
setblock ~346 ~37 ~408 minecraft:light_gray_concrete replace
setblock ~349 ~37 ~408 minecraft:light_gray_concrete replace
setblock ~376 ~37 ~408 minecraft:light_gray_concrete replace
setblock ~376 ~37 ~412 minecraft:light_gray_concrete replace
setblock ~91 ~37 ~416 minecraft:light_gray_concrete replace
setblock ~118 ~37 ~420 minecraft:light_gray_concrete replace
setblock ~145 ~37 ~424 minecraft:light_gray_concrete replace
setblock ~193 ~37 ~428 minecraft:light_gray_concrete replace
setblock ~214 ~37 ~432 minecraft:light_gray_concrete replace
setblock ~238 ~37 ~436 minecraft:light_gray_concrete replace
setblock ~283 ~37 ~440 minecraft:light_gray_concrete replace
setblock ~307 ~37 ~444 minecraft:light_gray_concrete replace
setblock ~343 ~37 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~37 ~452 minecraft:light_gray_concrete replace
setblock ~115 ~37 ~456 minecraft:light_gray_concrete replace
setblock ~142 ~37 ~460 minecraft:light_gray_concrete replace
setblock ~190 ~37 ~464 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~468 minecraft:light_gray_concrete replace
setblock ~235 ~37 ~472 minecraft:light_gray_concrete replace
setblock ~277 ~37 ~476 minecraft:light_gray_concrete replace
setblock ~304 ~37 ~480 minecraft:light_gray_concrete replace
setblock ~367 ~37 ~484 minecraft:light_gray_concrete replace
setblock ~391 ~37 ~488 minecraft:light_gray_concrete replace
setblock ~85 ~37 ~492 minecraft:light_gray_concrete replace
setblock ~112 ~37 ~496 minecraft:light_gray_concrete replace
setblock ~139 ~37 ~500 minecraft:light_gray_concrete replace
setblock ~172 ~37 ~504 minecraft:light_gray_concrete replace
setblock ~208 ~37 ~508 minecraft:light_gray_concrete replace
setblock ~232 ~37 ~512 minecraft:light_gray_concrete replace
setblock ~274 ~37 ~516 minecraft:light_gray_concrete replace
setblock ~301 ~37 ~520 minecraft:light_gray_concrete replace
setblock ~361 ~37 ~524 minecraft:light_gray_concrete replace
setblock ~388 ~37 ~528 minecraft:light_gray_concrete replace
setblock ~82 ~37 ~532 minecraft:light_gray_concrete replace
setblock ~109 ~37 ~536 minecraft:light_gray_concrete replace
setblock ~136 ~37 ~540 minecraft:light_gray_concrete replace
setblock ~166 ~37 ~544 minecraft:light_gray_concrete replace
setblock ~205 ~37 ~548 minecraft:light_gray_concrete replace
setblock ~229 ~37 ~552 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~556 minecraft:light_gray_concrete replace
setblock ~292 ~37 ~560 minecraft:light_gray_concrete replace
setblock ~358 ~37 ~564 minecraft:light_gray_concrete replace
setblock ~382 ~37 ~568 minecraft:light_gray_concrete replace
setblock ~79 ~37 ~572 minecraft:light_gray_concrete replace
setblock ~106 ~37 ~576 minecraft:light_gray_concrete replace
setblock ~133 ~37 ~580 minecraft:light_gray_concrete replace
setblock ~163 ~37 ~584 minecraft:light_gray_concrete replace
setblock ~199 ~37 ~588 minecraft:light_gray_concrete replace
setblock ~220 ~37 ~592 minecraft:light_gray_concrete replace
setblock ~268 ~37 ~596 minecraft:light_gray_concrete replace
setblock ~289 ~37 ~600 minecraft:light_gray_concrete replace
setblock ~355 ~37 ~604 minecraft:light_gray_concrete replace
setblock ~379 ~37 ~608 minecraft:light_gray_concrete replace
setblock ~103 ~37 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~37 ~616 minecraft:light_gray_concrete replace
setblock ~160 ~37 ~620 minecraft:light_gray_concrete replace
setblock ~196 ~37 ~624 minecraft:light_gray_concrete replace
setblock ~217 ~37 ~628 minecraft:light_gray_concrete replace
setblock ~241 ~37 ~632 minecraft:light_gray_concrete replace
setblock ~295 ~37 ~636 minecraft:light_gray_concrete replace
setblock ~310 ~37 ~640 minecraft:light_gray_concrete replace
setblock ~370 ~37 ~644 minecraft:light_gray_concrete replace
setblock ~169 ~37 ~648 minecraft:light_gray_concrete replace
setblock ~397 ~37 ~652 minecraft:light_gray_concrete replace
setblock ~100 ~37 ~656 minecraft:light_gray_concrete replace
setblock ~373 ~37 ~660 minecraft:light_gray_concrete replace
setblock ~394 ~37 ~664 minecraft:light_gray_concrete replace
fill ~243 ~38 ~4 ~243 ~38 ~320 minecraft:light_gray_concrete replace
fill ~174 ~38 ~8 ~174 ~38 ~308 minecraft:light_gray_concrete replace
fill ~147 ~38 ~12 ~147 ~38 ~292 minecraft:light_gray_concrete replace
fill ~246 ~38 ~16 ~246 ~38 ~320 minecraft:light_gray_concrete replace
fill ~177 ~38 ~20 ~177 ~38 ~308 minecraft:light_gray_concrete replace
fill ~249 ~38 ~28 ~249 ~38 ~320 minecraft:light_gray_concrete replace
fill ~330 ~38 ~36 ~330 ~38 ~364 minecraft:light_gray_concrete replace
fill ~315 ~38 ~40 ~315 ~38 ~376 minecraft:light_gray_concrete replace
fill ~258 ~38 ~44 ~258 ~38 ~352 minecraft:light_gray_concrete replace
fill ~333 ~38 ~48 ~333 ~38 ~364 minecraft:light_gray_concrete replace
fill ~318 ~38 ~52 ~318 ~38 ~376 minecraft:light_gray_concrete replace
fill ~324 ~38 ~60 ~324 ~38 ~376 minecraft:light_gray_concrete replace
fill ~348 ~38 ~76 ~348 ~38 ~408 minecraft:light_gray_concrete replace
fill ~93 ~38 ~248 ~93 ~38 ~272 minecraft:light_gray_concrete replace
fill ~123 ~38 ~252 ~123 ~38 ~268 minecraft:light_gray_concrete replace
fill ~252 ~38 ~256 ~252 ~38 ~320 minecraft:light_gray_concrete replace
fill ~183 ~38 ~260 ~183 ~38 ~308 minecraft:light_gray_concrete replace
fill ~153 ~38 ~264 ~153 ~38 ~292 minecraft:light_gray_concrete replace
fill ~126 ~38 ~268 ~126 ~38 ~280 minecraft:light_gray_concrete replace
fill ~96 ~38 ~276 ~96 ~38 ~280 minecraft:light_gray_concrete replace
fill ~120 ~38 ~280 ~120 ~38 ~292 minecraft:light_gray_concrete replace
fill ~150 ~38 ~284 ~150 ~38 ~288 minecraft:light_gray_concrete replace
fill ~156 ~38 ~296 ~156 ~38 ~308 minecraft:light_gray_concrete replace
fill ~180 ~38 ~300 ~180 ~38 ~304 minecraft:light_gray_concrete replace
fill ~186 ~38 ~312 ~186 ~38 ~320 minecraft:light_gray_concrete replace
fill ~255 ~38 ~320 ~255 ~38 ~324 minecraft:light_gray_concrete replace
fill ~201 ~38 ~324 ~201 ~38 ~336 minecraft:light_gray_concrete replace
fill ~222 ~38 ~328 ~222 ~38 ~332 minecraft:light_gray_concrete replace
fill ~279 ~38 ~332 ~279 ~38 ~336 minecraft:light_gray_concrete replace
fill ~225 ~38 ~340 ~225 ~38 ~352 minecraft:light_gray_concrete replace
fill ~261 ~38 ~344 ~261 ~38 ~348 minecraft:light_gray_concrete replace
fill ~297 ~38 ~348 ~297 ~38 ~352 minecraft:light_gray_concrete replace
fill ~264 ~38 ~356 ~264 ~38 ~364 minecraft:light_gray_concrete replace
fill ~321 ~38 ~360 ~321 ~38 ~364 minecraft:light_gray_concrete replace
fill ~336 ~38 ~364 ~336 ~38 ~372 minecraft:light_gray_concrete replace
fill ~339 ~38 ~368 ~339 ~38 ~384 minecraft:light_gray_concrete replace
fill ~312 ~38 ~372 ~312 ~38 ~376 minecraft:light_gray_concrete replace
fill ~327 ~38 ~376 ~327 ~38 ~380 minecraft:light_gray_concrete replace
fill ~285 ~38 ~384 ~285 ~38 ~392 minecraft:light_gray_concrete replace
fill ~363 ~38 ~388 ~363 ~38 ~392 minecraft:light_gray_concrete replace
fill ~384 ~38 ~392 ~384 ~38 ~400 minecraft:light_gray_concrete replace
fill ~351 ~38 ~396 ~351 ~38 ~404 minecraft:light_gray_concrete replace
fill ~375 ~38 ~400 ~375 ~38 ~412 minecraft:light_gray_concrete replace
fill ~345 ~38 ~404 ~345 ~38 ~408 minecraft:light_gray_concrete replace
fill ~90 ~38 ~412 ~90 ~38 ~416 minecraft:light_gray_concrete replace
fill ~117 ~38 ~416 ~117 ~38 ~420 minecraft:light_gray_concrete replace
fill ~144 ~38 ~420 ~144 ~38 ~424 minecraft:light_gray_concrete replace
fill ~192 ~38 ~424 ~192 ~38 ~428 minecraft:light_gray_concrete replace
fill ~213 ~38 ~428 ~213 ~38 ~432 minecraft:light_gray_concrete replace
fill ~237 ~38 ~432 ~237 ~38 ~436 minecraft:light_gray_concrete replace
fill ~282 ~38 ~436 ~282 ~38 ~440 minecraft:light_gray_concrete replace
fill ~306 ~38 ~440 ~306 ~38 ~444 minecraft:light_gray_concrete replace
fill ~342 ~38 ~444 ~342 ~38 ~448 minecraft:light_gray_concrete replace
fill ~87 ~38 ~448 ~87 ~38 ~452 minecraft:light_gray_concrete replace
fill ~114 ~38 ~452 ~114 ~38 ~456 minecraft:light_gray_concrete replace
fill ~141 ~38 ~456 ~141 ~38 ~460 minecraft:light_gray_concrete replace
fill ~189 ~38 ~460 ~189 ~38 ~464 minecraft:light_gray_concrete replace
fill ~210 ~38 ~464 ~210 ~38 ~468 minecraft:light_gray_concrete replace
fill ~234 ~38 ~468 ~234 ~38 ~472 minecraft:light_gray_concrete replace
fill ~276 ~38 ~472 ~276 ~38 ~476 minecraft:light_gray_concrete replace
fill ~303 ~38 ~476 ~303 ~38 ~480 minecraft:light_gray_concrete replace
fill ~366 ~38 ~480 ~366 ~38 ~484 minecraft:light_gray_concrete replace
fill ~390 ~38 ~484 ~390 ~38 ~488 minecraft:light_gray_concrete replace
fill ~84 ~38 ~488 ~84 ~38 ~492 minecraft:light_gray_concrete replace
fill ~111 ~38 ~492 ~111 ~38 ~496 minecraft:light_gray_concrete replace
fill ~138 ~38 ~496 ~138 ~38 ~500 minecraft:light_gray_concrete replace
fill ~171 ~38 ~500 ~171 ~38 ~504 minecraft:light_gray_concrete replace
fill ~207 ~38 ~504 ~207 ~38 ~508 minecraft:light_gray_concrete replace
fill ~231 ~38 ~508 ~231 ~38 ~512 minecraft:light_gray_concrete replace
fill ~273 ~38 ~512 ~273 ~38 ~516 minecraft:light_gray_concrete replace
fill ~300 ~38 ~516 ~300 ~38 ~520 minecraft:light_gray_concrete replace
fill ~360 ~38 ~520 ~360 ~38 ~524 minecraft:light_gray_concrete replace
fill ~387 ~38 ~524 ~387 ~38 ~528 minecraft:light_gray_concrete replace
fill ~81 ~38 ~528 ~81 ~38 ~532 minecraft:light_gray_concrete replace
fill ~108 ~38 ~532 ~108 ~38 ~536 minecraft:light_gray_concrete replace
fill ~135 ~38 ~536 ~135 ~38 ~540 minecraft:light_gray_concrete replace
fill ~165 ~38 ~540 ~165 ~38 ~544 minecraft:light_gray_concrete replace
fill ~204 ~38 ~544 ~204 ~38 ~548 minecraft:light_gray_concrete replace
fill ~228 ~38 ~548 ~228 ~38 ~552 minecraft:light_gray_concrete replace
fill ~270 ~38 ~552 ~270 ~38 ~556 minecraft:light_gray_concrete replace
fill ~291 ~38 ~556 ~291 ~38 ~560 minecraft:light_gray_concrete replace
fill ~357 ~38 ~560 ~357 ~38 ~564 minecraft:light_gray_concrete replace
fill ~381 ~38 ~564 ~381 ~38 ~568 minecraft:light_gray_concrete replace
fill ~78 ~38 ~568 ~78 ~38 ~572 minecraft:light_gray_concrete replace
fill ~105 ~38 ~572 ~105 ~38 ~576 minecraft:light_gray_concrete replace
fill ~132 ~38 ~576 ~132 ~38 ~580 minecraft:light_gray_concrete replace
fill ~162 ~38 ~580 ~162 ~38 ~584 minecraft:light_gray_concrete replace
fill ~198 ~38 ~584 ~198 ~38 ~588 minecraft:light_gray_concrete replace
fill ~219 ~38 ~588 ~219 ~38 ~592 minecraft:light_gray_concrete replace
fill ~267 ~38 ~592 ~267 ~38 ~596 minecraft:light_gray_concrete replace
fill ~288 ~38 ~596 ~288 ~38 ~600 minecraft:light_gray_concrete replace
fill ~354 ~38 ~600 ~354 ~38 ~604 minecraft:light_gray_concrete replace
fill ~378 ~38 ~604 ~378 ~38 ~608 minecraft:light_gray_concrete replace
fill ~102 ~38 ~608 ~102 ~38 ~612 minecraft:light_gray_concrete replace
fill ~129 ~38 ~612 ~129 ~38 ~616 minecraft:light_gray_concrete replace
fill ~159 ~38 ~616 ~159 ~38 ~620 minecraft:light_gray_concrete replace
fill ~195 ~38 ~620 ~195 ~38 ~624 minecraft:light_gray_concrete replace
fill ~216 ~38 ~624 ~216 ~38 ~628 minecraft:light_gray_concrete replace
fill ~240 ~38 ~628 ~240 ~38 ~632 minecraft:light_gray_concrete replace
fill ~294 ~38 ~632 ~294 ~38 ~636 minecraft:light_gray_concrete replace
fill ~309 ~38 ~636 ~309 ~38 ~640 minecraft:light_gray_concrete replace
fill ~369 ~38 ~640 ~369 ~38 ~644 minecraft:light_gray_concrete replace
fill ~168 ~38 ~644 ~168 ~38 ~648 minecraft:light_gray_concrete replace
fill ~396 ~38 ~648 ~396 ~38 ~652 minecraft:light_gray_concrete replace
fill ~99 ~38 ~652 ~99 ~38 ~656 minecraft:light_gray_concrete replace
fill ~372 ~38 ~656 ~372 ~38 ~660 minecraft:light_gray_concrete replace
fill ~393 ~38 ~660 ~393 ~38 ~664 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~3 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~5 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~7 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~7 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~9 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~11 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~13 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~15 minecraft:light_gray_concrete replace
setblock ~148 ~39 ~16 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~16 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~16 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~19 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~19 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~23 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~23 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~23 minecraft:light_gray_concrete replace
setblock ~178 ~39 ~24 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~24 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~27 minecraft:light_gray_concrete replace
setblock ~250 ~39 ~32 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~33 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~35 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~35 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~35 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~41 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~43 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~43 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~45 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~47 minecraft:light_gray_concrete replace
setblock ~259 ~39 ~48 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~48 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~48 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~49 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~49 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~56 minecraft:light_gray_concrete replace
setblock ~334 ~39 ~56 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~57 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~59 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~59 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~59 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~63 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~63 minecraft:light_gray_concrete replace
setblock ~325 ~39 ~64 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~65 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~65 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~67 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~67 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~67 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~73 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~73 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~77 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~77 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~77 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~79 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~79 minecraft:light_gray_concrete replace
setblock ~349 ~39 ~80 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~81 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~81 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~83 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~83 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~83 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~89 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~89 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~95 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~95 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~97 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~97 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~99 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~99 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~99 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~105 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~105 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~111 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~111 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~113 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~113 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~115 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~115 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~115 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~119 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~121 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~121 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~123 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~125 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~127 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~127 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~129 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~129 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~131 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~131 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~131 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~133 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~135 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~137 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~137 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~139 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~141 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~143 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~143 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~145 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~145 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~147 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~147 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~147 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~149 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~151 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~153 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~153 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~155 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~157 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~159 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~159 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~161 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~161 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~163 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~163 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~163 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~165 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~167 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~169 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~169 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~171 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~173 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~175 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~175 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~177 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~177 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~179 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~179 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~179 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~181 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~183 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~185 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~185 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~187 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~189 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~191 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~191 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~193 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~193 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~195 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~195 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~195 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~197 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~199 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~201 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~201 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~203 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~205 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~207 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~207 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~209 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~209 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~211 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~211 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~211 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~213 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~215 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~217 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~217 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~219 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~221 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~223 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~223 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~225 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~225 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~227 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~227 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~227 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~229 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~231 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~233 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~233 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~235 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~237 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~239 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~239 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~241 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~241 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~243 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~243 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~243 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~245 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~247 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~249 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~249 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~249 minecraft:light_gray_concrete replace
setblock ~123 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~251 minecraft:light_gray_concrete replace
setblock ~123 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~253 minecraft:light_gray_concrete replace
setblock ~123 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~252 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~255 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~257 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~257 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~257 minecraft:light_gray_concrete replace
setblock ~93 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~259 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~261 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~153 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~252 ~39 ~263 minecraft:light_gray_concrete replace
setblock ~94 ~39 ~264 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~252 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~265 minecraft:light_gray_concrete replace
setblock ~126 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~267 minecraft:light_gray_concrete replace
setblock ~126 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~269 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~271 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~271 minecraft:light_gray_concrete replace
setblock ~94 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~127 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~154 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~272 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~273 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~273 minecraft:light_gray_concrete replace
setblock ~96 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~275 minecraft:light_gray_concrete replace
setblock ~148 ~39 ~276 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~276 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~276 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~277 minecraft:light_gray_concrete replace
setblock ~120 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~279 minecraft:light_gray_concrete replace
setblock ~127 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~154 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~280 minecraft:light_gray_concrete replace
setblock ~120 ~39 ~281 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~281 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~281 minecraft:light_gray_concrete replace
setblock ~150 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~283 minecraft:light_gray_concrete replace
setblock ~121 ~39 ~284 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~285 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~287 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~287 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~289 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~289 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~291 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~291 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~291 minecraft:light_gray_concrete replace
setblock ~121 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~148 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~154 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~292 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~293 minecraft:light_gray_concrete replace
setblock ~156 ~39 ~295 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~295 minecraft:light_gray_concrete replace
setblock ~183 ~39 ~295 minecraft:light_gray_concrete replace
setblock ~178 ~39 ~296 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~296 minecraft:light_gray_concrete replace
setblock ~156 ~39 ~297 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~297 minecraft:light_gray_concrete replace
setblock ~180 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~299 minecraft:light_gray_concrete replace
setblock ~157 ~39 ~300 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~301 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~303 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~303 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~305 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~305 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~307 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~307 minecraft:light_gray_concrete replace
setblock ~157 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~178 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~184 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~308 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~309 minecraft:light_gray_concrete replace
setblock ~186 ~39 ~311 minecraft:light_gray_concrete replace
setblock ~250 ~39 ~312 minecraft:light_gray_concrete replace
setblock ~186 ~39 ~313 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~313 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~315 minecraft:light_gray_concrete replace
setblock ~187 ~39 ~316 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~317 minecraft:light_gray_concrete replace
setblock ~255 ~39 ~319 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~319 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~319 minecraft:light_gray_concrete replace
setblock ~187 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~250 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~253 ~39 ~320 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~321 minecraft:light_gray_concrete replace
setblock ~201 ~39 ~323 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~323 minecraft:light_gray_concrete replace
setblock ~201 ~39 ~325 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~325 minecraft:light_gray_concrete replace
setblock ~222 ~39 ~327 minecraft:light_gray_concrete replace
setblock ~202 ~39 ~328 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~329 minecraft:light_gray_concrete replace
setblock ~279 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~331 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~333 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~335 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~335 minecraft:light_gray_concrete replace
setblock ~202 ~39 ~336 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~337 minecraft:light_gray_concrete replace
setblock ~225 ~39 ~339 minecraft:light_gray_concrete replace
setblock ~259 ~39 ~340 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~340 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~340 minecraft:light_gray_concrete replace
setblock ~225 ~39 ~341 minecraft:light_gray_concrete replace
setblock ~261 ~39 ~343 minecraft:light_gray_concrete replace
setblock ~226 ~39 ~344 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~345 minecraft:light_gray_concrete replace
setblock ~297 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~347 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~349 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~351 minecraft:light_gray_concrete replace
setblock ~226 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~259 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~352 minecraft:light_gray_concrete replace
setblock ~264 ~39 ~355 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~356 minecraft:light_gray_concrete replace
setblock ~334 ~39 ~356 minecraft:light_gray_concrete replace
setblock ~264 ~39 ~357 minecraft:light_gray_concrete replace
setblock ~321 ~39 ~359 minecraft:light_gray_concrete replace
setblock ~265 ~39 ~360 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~361 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~363 minecraft:light_gray_concrete replace
setblock ~336 ~39 ~363 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~363 minecraft:light_gray_concrete replace
setblock ~265 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~334 ~39 ~364 minecraft:light_gray_concrete replace
setblock ~336 ~39 ~365 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~365 minecraft:light_gray_concrete replace
setblock ~339 ~39 ~367 minecraft:light_gray_concrete replace
setblock ~325 ~39 ~368 minecraft:light_gray_concrete replace
setblock ~339 ~39 ~369 minecraft:light_gray_concrete replace
setblock ~312 ~39 ~371 minecraft:light_gray_concrete replace
setblock ~339 ~39 ~371 minecraft:light_gray_concrete replace
setblock ~327 ~39 ~375 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~325 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~340 ~39 ~376 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~379 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~381 minecraft:light_gray_concrete replace
setblock ~285 ~39 ~383 minecraft:light_gray_concrete replace
setblock ~340 ~39 ~384 minecraft:light_gray_concrete replace
setblock ~285 ~39 ~385 minecraft:light_gray_concrete replace
setblock ~363 ~39 ~387 minecraft:light_gray_concrete replace
setblock ~286 ~39 ~388 minecraft:light_gray_concrete replace
setblock ~384 ~39 ~391 minecraft:light_gray_concrete replace
setblock ~286 ~39 ~392 minecraft:light_gray_concrete replace
setblock ~384 ~39 ~393 minecraft:light_gray_concrete replace
setblock ~351 ~39 ~395 minecraft:light_gray_concrete replace
setblock ~349 ~39 ~396 minecraft:light_gray_concrete replace
setblock ~351 ~39 ~397 minecraft:light_gray_concrete replace
setblock ~375 ~39 ~399 minecraft:light_gray_concrete replace
setblock ~375 ~39 ~401 minecraft:light_gray_concrete replace
setblock ~345 ~39 ~403 minecraft:light_gray_concrete replace
setblock ~349 ~39 ~408 minecraft:light_gray_concrete replace
setblock ~376 ~39 ~408 minecraft:light_gray_concrete replace
setblock ~90 ~39 ~411 minecraft:light_gray_concrete replace
setblock ~376 ~39 ~412 minecraft:light_gray_concrete replace
setblock ~117 ~39 ~415 minecraft:light_gray_concrete replace
setblock ~144 ~39 ~419 minecraft:light_gray_concrete replace
setblock ~192 ~39 ~423 minecraft:light_gray_concrete replace
setblock ~213 ~39 ~427 minecraft:light_gray_concrete replace
setblock ~237 ~39 ~431 minecraft:light_gray_concrete replace
setblock ~282 ~39 ~435 minecraft:light_gray_concrete replace
setblock ~306 ~39 ~439 minecraft:light_gray_concrete replace
setblock ~342 ~39 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~39 ~447 minecraft:light_gray_concrete replace
setblock ~114 ~39 ~451 minecraft:light_gray_concrete replace
setblock ~141 ~39 ~455 minecraft:light_gray_concrete replace
setblock ~189 ~39 ~459 minecraft:light_gray_concrete replace
setblock ~210 ~39 ~463 minecraft:light_gray_concrete replace
setblock ~234 ~39 ~467 minecraft:light_gray_concrete replace
setblock ~276 ~39 ~471 minecraft:light_gray_concrete replace
setblock ~303 ~39 ~475 minecraft:light_gray_concrete replace
setblock ~366 ~39 ~479 minecraft:light_gray_concrete replace
setblock ~390 ~39 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~39 ~487 minecraft:light_gray_concrete replace
setblock ~111 ~39 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~39 ~495 minecraft:light_gray_concrete replace
setblock ~171 ~39 ~499 minecraft:light_gray_concrete replace
setblock ~207 ~39 ~503 minecraft:light_gray_concrete replace
setblock ~231 ~39 ~507 minecraft:light_gray_concrete replace
setblock ~273 ~39 ~511 minecraft:light_gray_concrete replace
setblock ~300 ~39 ~515 minecraft:light_gray_concrete replace
setblock ~360 ~39 ~519 minecraft:light_gray_concrete replace
setblock ~387 ~39 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~39 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~39 ~531 minecraft:light_gray_concrete replace
setblock ~135 ~39 ~535 minecraft:light_gray_concrete replace
setblock ~165 ~39 ~539 minecraft:light_gray_concrete replace
setblock ~204 ~39 ~543 minecraft:light_gray_concrete replace
setblock ~228 ~39 ~547 minecraft:light_gray_concrete replace
setblock ~270 ~39 ~551 minecraft:light_gray_concrete replace
setblock ~291 ~39 ~555 minecraft:light_gray_concrete replace
setblock ~357 ~39 ~559 minecraft:light_gray_concrete replace
setblock ~381 ~39 ~563 minecraft:light_gray_concrete replace
setblock ~78 ~39 ~567 minecraft:light_gray_concrete replace
setblock ~105 ~39 ~571 minecraft:light_gray_concrete replace
setblock ~132 ~39 ~575 minecraft:light_gray_concrete replace
setblock ~162 ~39 ~579 minecraft:light_gray_concrete replace
setblock ~198 ~39 ~583 minecraft:light_gray_concrete replace
setblock ~219 ~39 ~587 minecraft:light_gray_concrete replace
setblock ~267 ~39 ~591 minecraft:light_gray_concrete replace
setblock ~288 ~39 ~595 minecraft:light_gray_concrete replace
setblock ~354 ~39 ~599 minecraft:light_gray_concrete replace
setblock ~378 ~39 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~39 ~607 minecraft:light_gray_concrete replace
setblock ~129 ~39 ~611 minecraft:light_gray_concrete replace
setblock ~159 ~39 ~615 minecraft:light_gray_concrete replace
setblock ~195 ~39 ~619 minecraft:light_gray_concrete replace
setblock ~216 ~39 ~623 minecraft:light_gray_concrete replace
setblock ~240 ~39 ~627 minecraft:light_gray_concrete replace
setblock ~294 ~39 ~631 minecraft:light_gray_concrete replace
setblock ~309 ~39 ~635 minecraft:light_gray_concrete replace
setblock ~369 ~39 ~639 minecraft:light_gray_concrete replace
setblock ~168 ~39 ~643 minecraft:light_gray_concrete replace
setblock ~396 ~39 ~647 minecraft:light_gray_concrete replace
setblock ~99 ~39 ~651 minecraft:light_gray_concrete replace
setblock ~372 ~39 ~655 minecraft:light_gray_concrete replace
setblock ~393 ~39 ~659 minecraft:light_gray_concrete replace
fill ~226 ~40 ~0 ~226 ~40 ~1 minecraft:light_gray_concrete replace
fill ~225 ~40 ~2 ~243 ~40 ~2 minecraft:light_gray_concrete replace
fill ~166 ~40 ~4 ~166 ~40 ~5 minecraft:light_gray_concrete replace
fill ~165 ~40 ~6 ~174 ~40 ~6 minecraft:light_gray_concrete replace
fill ~145 ~40 ~8 ~145 ~40 ~9 minecraft:light_gray_concrete replace
fill ~144 ~40 ~10 ~147 ~40 ~10 minecraft:light_gray_concrete replace
fill ~226 ~40 ~12 ~226 ~40 ~13 minecraft:light_gray_concrete replace
fill ~225 ~40 ~14 ~246 ~40 ~14 minecraft:light_gray_concrete replace
fill ~166 ~40 ~16 ~166 ~40 ~17 minecraft:light_gray_concrete replace
fill ~165 ~40 ~18 ~177 ~40 ~18 minecraft:light_gray_concrete replace
fill ~226 ~40 ~24 ~226 ~40 ~25 minecraft:light_gray_concrete replace
fill ~225 ~40 ~26 ~249 ~40 ~26 minecraft:light_gray_concrete replace
fill ~301 ~40 ~32 ~301 ~40 ~33 minecraft:light_gray_concrete replace
fill ~300 ~40 ~34 ~330 ~40 ~34 minecraft:light_gray_concrete replace
fill ~286 ~40 ~36 ~286 ~40 ~37 minecraft:light_gray_concrete replace
fill ~285 ~40 ~38 ~315 ~40 ~38 minecraft:light_gray_concrete replace
fill ~229 ~40 ~40 ~229 ~40 ~41 minecraft:light_gray_concrete replace
fill ~228 ~40 ~42 ~258 ~40 ~42 minecraft:light_gray_concrete replace
fill ~304 ~40 ~44 ~304 ~40 ~45 minecraft:light_gray_concrete replace
fill ~303 ~40 ~46 ~333 ~40 ~46 minecraft:light_gray_concrete replace
fill ~289 ~40 ~48 ~289 ~40 ~49 minecraft:light_gray_concrete replace
fill ~288 ~40 ~50 ~318 ~40 ~50 minecraft:light_gray_concrete replace
fill ~295 ~40 ~56 ~295 ~40 ~57 minecraft:light_gray_concrete replace
fill ~294 ~40 ~58 ~324 ~40 ~58 minecraft:light_gray_concrete replace
fill ~319 ~40 ~72 ~319 ~40 ~73 minecraft:light_gray_concrete replace
fill ~318 ~40 ~74 ~348 ~40 ~74 minecraft:light_gray_concrete replace
fill ~94 ~40 ~244 ~94 ~40 ~245 minecraft:light_gray_concrete replace
fill ~93 ~40 ~246 ~95 ~40 ~246 minecraft:light_gray_concrete replace
fill ~124 ~40 ~248 ~124 ~40 ~249 minecraft:light_gray_concrete replace
fill ~123 ~40 ~250 ~125 ~40 ~250 minecraft:light_gray_concrete replace
fill ~226 ~40 ~252 ~226 ~40 ~253 minecraft:light_gray_concrete replace
fill ~225 ~40 ~254 ~252 ~40 ~254 minecraft:light_gray_concrete replace
fill ~166 ~40 ~256 ~166 ~40 ~257 minecraft:light_gray_concrete replace
fill ~165 ~40 ~258 ~183 ~40 ~258 minecraft:light_gray_concrete replace
fill ~145 ~40 ~260 ~145 ~40 ~261 minecraft:light_gray_concrete replace
fill ~144 ~40 ~262 ~153 ~40 ~262 minecraft:light_gray_concrete replace
fill ~124 ~40 ~264 ~124 ~40 ~265 minecraft:light_gray_concrete replace
fill ~123 ~40 ~266 ~126 ~40 ~266 minecraft:light_gray_concrete replace
fill ~97 ~40 ~272 ~97 ~40 ~273 minecraft:light_gray_concrete replace
fill ~96 ~40 ~274 ~98 ~40 ~274 minecraft:light_gray_concrete replace
fill ~121 ~40 ~276 ~121 ~40 ~277 minecraft:light_gray_concrete replace
fill ~120 ~40 ~278 ~122 ~40 ~278 minecraft:light_gray_concrete replace
fill ~145 ~40 ~280 ~145 ~40 ~281 minecraft:light_gray_concrete replace
fill ~144 ~40 ~282 ~150 ~40 ~282 minecraft:light_gray_concrete replace
fill ~148 ~40 ~292 ~148 ~40 ~293 minecraft:light_gray_concrete replace
fill ~147 ~40 ~294 ~156 ~40 ~294 minecraft:light_gray_concrete replace
fill ~166 ~40 ~296 ~166 ~40 ~297 minecraft:light_gray_concrete replace
fill ~165 ~40 ~298 ~180 ~40 ~298 minecraft:light_gray_concrete replace
fill ~169 ~40 ~308 ~169 ~40 ~309 minecraft:light_gray_concrete replace
fill ~168 ~40 ~310 ~186 ~40 ~310 minecraft:light_gray_concrete replace
fill ~226 ~40 ~316 ~226 ~40 ~317 minecraft:light_gray_concrete replace
fill ~225 ~40 ~318 ~255 ~40 ~318 minecraft:light_gray_concrete replace
fill ~184 ~40 ~320 ~184 ~40 ~321 minecraft:light_gray_concrete replace
fill ~183 ~40 ~322 ~201 ~40 ~322 minecraft:light_gray_concrete replace
fill ~205 ~40 ~324 ~205 ~40 ~325 minecraft:light_gray_concrete replace
fill ~204 ~40 ~326 ~222 ~40 ~326 minecraft:light_gray_concrete replace
fill ~250 ~40 ~328 ~250 ~40 ~329 minecraft:light_gray_concrete replace
fill ~249 ~40 ~330 ~279 ~40 ~330 minecraft:light_gray_concrete replace
fill ~208 ~40 ~336 ~208 ~40 ~337 minecraft:light_gray_concrete replace
fill ~207 ~40 ~338 ~225 ~40 ~338 minecraft:light_gray_concrete replace
fill ~232 ~40 ~340 ~232 ~40 ~341 minecraft:light_gray_concrete replace
fill ~231 ~40 ~342 ~261 ~40 ~342 minecraft:light_gray_concrete replace
fill ~268 ~40 ~344 ~268 ~40 ~345 minecraft:light_gray_concrete replace
fill ~267 ~40 ~346 ~297 ~40 ~346 minecraft:light_gray_concrete replace
fill ~235 ~40 ~352 ~235 ~40 ~353 minecraft:light_gray_concrete replace
fill ~234 ~40 ~354 ~264 ~40 ~354 minecraft:light_gray_concrete replace
fill ~292 ~40 ~356 ~292 ~40 ~357 minecraft:light_gray_concrete replace
fill ~291 ~40 ~358 ~321 ~40 ~358 minecraft:light_gray_concrete replace
