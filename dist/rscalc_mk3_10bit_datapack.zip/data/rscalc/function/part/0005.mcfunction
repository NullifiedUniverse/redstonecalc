setblock ~96 ~23 ~111 minecraft:light_gray_concrete replace
setblock ~94 ~23 ~112 minecraft:light_gray_concrete replace
setblock ~99 ~23 ~115 minecraft:light_gray_concrete replace
setblock ~99 ~23 ~117 minecraft:light_gray_concrete replace
setblock ~100 ~23 ~120 minecraft:light_gray_concrete replace
setblock ~132 ~23 ~123 minecraft:light_gray_concrete replace
setblock ~100 ~23 ~124 minecraft:light_gray_concrete replace
setblock ~111 ~23 ~127 minecraft:light_gray_concrete replace
setblock ~114 ~23 ~131 minecraft:light_gray_concrete replace
setblock ~112 ~23 ~132 minecraft:light_gray_concrete replace
setblock ~117 ~23 ~135 minecraft:light_gray_concrete replace
setblock ~117 ~23 ~137 minecraft:light_gray_concrete replace
setblock ~118 ~23 ~140 minecraft:light_gray_concrete replace
setblock ~147 ~23 ~143 minecraft:light_gray_concrete replace
setblock ~118 ~23 ~144 minecraft:light_gray_concrete replace
setblock ~129 ~23 ~147 minecraft:light_gray_concrete replace
setblock ~138 ~23 ~151 minecraft:light_gray_concrete replace
setblock ~130 ~23 ~152 minecraft:light_gray_concrete replace
setblock ~141 ~23 ~155 minecraft:light_gray_concrete replace
setblock ~141 ~23 ~157 minecraft:light_gray_concrete replace
setblock ~180 ~23 ~159 minecraft:light_gray_concrete replace
setblock ~142 ~23 ~160 minecraft:light_gray_concrete replace
setblock ~180 ~23 ~161 minecraft:light_gray_concrete replace
setblock ~153 ~23 ~163 minecraft:light_gray_concrete replace
setblock ~142 ~23 ~164 minecraft:light_gray_concrete replace
setblock ~153 ~23 ~165 minecraft:light_gray_concrete replace
setblock ~156 ~23 ~167 minecraft:light_gray_concrete replace
setblock ~156 ~23 ~169 minecraft:light_gray_concrete replace
setblock ~159 ~23 ~171 minecraft:light_gray_concrete replace
setblock ~154 ~23 ~172 minecraft:light_gray_concrete replace
setblock ~159 ~23 ~173 minecraft:light_gray_concrete replace
setblock ~201 ~23 ~175 minecraft:light_gray_concrete replace
setblock ~201 ~23 ~177 minecraft:light_gray_concrete replace
setblock ~189 ~23 ~179 minecraft:light_gray_concrete replace
setblock ~160 ~23 ~180 minecraft:light_gray_concrete replace
setblock ~189 ~23 ~181 minecraft:light_gray_concrete replace
setblock ~192 ~23 ~183 minecraft:light_gray_concrete replace
setblock ~160 ~23 ~184 minecraft:light_gray_concrete replace
setblock ~192 ~23 ~185 minecraft:light_gray_concrete replace
setblock ~195 ~23 ~187 minecraft:light_gray_concrete replace
setblock ~195 ~23 ~189 minecraft:light_gray_concrete replace
setblock ~195 ~23 ~191 minecraft:light_gray_concrete replace
setblock ~216 ~23 ~191 minecraft:light_gray_concrete replace
setblock ~190 ~23 ~192 minecraft:light_gray_concrete replace
setblock ~216 ~23 ~193 minecraft:light_gray_concrete replace
setblock ~210 ~23 ~195 minecraft:light_gray_concrete replace
setblock ~216 ~23 ~195 minecraft:light_gray_concrete replace
setblock ~210 ~23 ~197 minecraft:light_gray_concrete replace
setblock ~210 ~23 ~199 minecraft:light_gray_concrete replace
setblock ~213 ~23 ~199 minecraft:light_gray_concrete replace
setblock ~196 ~23 ~200 minecraft:light_gray_concrete replace
setblock ~213 ~23 ~201 minecraft:light_gray_concrete replace
setblock ~213 ~23 ~203 minecraft:light_gray_concrete replace
setblock ~219 ~23 ~203 minecraft:light_gray_concrete replace
setblock ~196 ~23 ~204 minecraft:light_gray_concrete replace
setblock ~243 ~23 ~207 minecraft:light_gray_concrete replace
setblock ~219 ~23 ~209 minecraft:light_gray_concrete replace
setblock ~219 ~23 ~211 minecraft:light_gray_concrete replace
setblock ~246 ~23 ~211 minecraft:light_gray_concrete replace
setblock ~211 ~23 ~212 minecraft:light_gray_concrete replace
setblock ~243 ~23 ~213 minecraft:light_gray_concrete replace
setblock ~243 ~23 ~215 minecraft:light_gray_concrete replace
setblock ~258 ~23 ~215 minecraft:light_gray_concrete replace
setblock ~246 ~23 ~217 minecraft:light_gray_concrete replace
setblock ~246 ~23 ~219 minecraft:light_gray_concrete replace
setblock ~267 ~23 ~219 minecraft:light_gray_concrete replace
setblock ~220 ~23 ~220 minecraft:light_gray_concrete replace
setblock ~258 ~23 ~221 minecraft:light_gray_concrete replace
setblock ~258 ~23 ~223 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~223 minecraft:light_gray_concrete replace
setblock ~220 ~23 ~224 minecraft:light_gray_concrete replace
setblock ~267 ~23 ~225 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~225 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~227 minecraft:light_gray_concrete replace
setblock ~267 ~23 ~227 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~229 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~231 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~233 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~233 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~235 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~235 minecraft:light_gray_concrete replace
setblock ~259 ~23 ~236 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~237 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~239 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~239 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~241 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~241 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~243 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~243 minecraft:light_gray_concrete replace
setblock ~271 ~23 ~244 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~245 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~247 minecraft:light_gray_concrete replace
setblock ~271 ~23 ~248 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~249 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~249 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~251 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~251 minecraft:light_gray_concrete replace
setblock ~229 ~23 ~252 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~253 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~253 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~255 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~255 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~257 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~257 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~259 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~259 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~259 minecraft:light_gray_concrete replace
setblock ~238 ~23 ~260 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~261 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~261 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~263 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~263 minecraft:light_gray_concrete replace
setblock ~238 ~23 ~264 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~265 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~267 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~267 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~269 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~269 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~269 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~273 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~273 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~275 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~275 minecraft:light_gray_concrete replace
setblock ~277 ~23 ~276 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~277 minecraft:light_gray_concrete replace
setblock ~165 ~23 ~279 minecraft:light_gray_concrete replace
setblock ~162 ~23 ~283 minecraft:light_gray_concrete replace
setblock ~283 ~23 ~284 minecraft:light_gray_concrete replace
setblock ~162 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~165 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~135 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~162 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~165 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~283 ~23 ~288 minecraft:light_gray_concrete replace
setblock ~135 ~23 ~289 minecraft:light_gray_concrete replace
setblock ~163 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~172 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~178 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~187 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~163 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~166 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~184 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~187 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~285 ~23 ~299 minecraft:light_gray_concrete replace
setblock ~166 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~178 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~187 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~205 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~222 ~23 ~303 minecraft:light_gray_concrete replace
fill ~79 ~24 ~4 ~79 ~24 ~5 minecraft:light_gray_concrete replace
fill ~78 ~24 ~6 ~80 ~24 ~6 minecraft:light_gray_concrete replace
fill ~97 ~24 ~8 ~97 ~24 ~9 minecraft:light_gray_concrete replace
fill ~127 ~24 ~8 ~127 ~24 ~9 minecraft:light_gray_concrete replace
fill ~96 ~24 ~10 ~128 ~24 ~10 minecraft:light_gray_concrete replace
fill ~100 ~24 ~12 ~100 ~24 ~13 minecraft:light_gray_concrete replace
fill ~90 ~24 ~14 ~101 ~24 ~14 minecraft:light_gray_concrete replace
fill ~91 ~24 ~16 ~91 ~24 ~17 minecraft:light_gray_concrete replace
fill ~115 ~24 ~16 ~115 ~24 ~17 minecraft:light_gray_concrete replace
fill ~154 ~24 ~16 ~154 ~24 ~17 minecraft:light_gray_concrete replace
fill ~90 ~24 ~18 ~155 ~24 ~18 minecraft:light_gray_concrete replace
fill ~118 ~24 ~20 ~118 ~24 ~21 minecraft:light_gray_concrete replace
fill ~105 ~24 ~22 ~119 ~24 ~22 minecraft:light_gray_concrete replace
fill ~112 ~24 ~24 ~112 ~24 ~25 minecraft:light_gray_concrete replace
fill ~142 ~24 ~24 ~142 ~24 ~25 minecraft:light_gray_concrete replace
fill ~178 ~24 ~24 ~178 ~24 ~25 minecraft:light_gray_concrete replace
fill ~111 ~24 ~26 ~179 ~24 ~26 minecraft:light_gray_concrete replace
fill ~145 ~24 ~28 ~145 ~24 ~29 minecraft:light_gray_concrete replace
fill ~126 ~24 ~30 ~146 ~24 ~30 minecraft:light_gray_concrete replace
fill ~139 ~24 ~32 ~139 ~24 ~33 minecraft:light_gray_concrete replace
fill ~175 ~24 ~32 ~175 ~24 ~33 minecraft:light_gray_concrete replace
fill ~208 ~24 ~32 ~208 ~24 ~33 minecraft:light_gray_concrete replace
fill ~138 ~24 ~34 ~209 ~24 ~34 minecraft:light_gray_concrete replace
fill ~187 ~24 ~36 ~187 ~24 ~37 minecraft:light_gray_concrete replace
fill ~150 ~24 ~38 ~188 ~24 ~38 minecraft:light_gray_concrete replace
fill ~172 ~24 ~40 ~172 ~24 ~41 minecraft:light_gray_concrete replace
fill ~202 ~24 ~40 ~202 ~24 ~41 minecraft:light_gray_concrete replace
fill ~226 ~24 ~40 ~226 ~24 ~41 minecraft:light_gray_concrete replace
fill ~168 ~24 ~42 ~227 ~24 ~42 minecraft:light_gray_concrete replace
fill ~205 ~24 ~44 ~205 ~24 ~45 minecraft:light_gray_concrete replace
fill ~174 ~24 ~46 ~206 ~24 ~46 minecraft:light_gray_concrete replace
fill ~199 ~24 ~48 ~199 ~24 ~49 minecraft:light_gray_concrete replace
fill ~238 ~24 ~48 ~238 ~24 ~49 minecraft:light_gray_concrete replace
fill ~250 ~24 ~48 ~250 ~24 ~49 minecraft:light_gray_concrete replace
fill ~198 ~24 ~50 ~251 ~24 ~50 minecraft:light_gray_concrete replace
fill ~241 ~24 ~52 ~241 ~24 ~53 minecraft:light_gray_concrete replace
fill ~207 ~24 ~54 ~242 ~24 ~54 minecraft:light_gray_concrete replace
fill ~235 ~24 ~56 ~235 ~24 ~57 minecraft:light_gray_concrete replace
fill ~283 ~24 ~56 ~283 ~24 ~57 minecraft:light_gray_concrete replace
fill ~292 ~24 ~56 ~292 ~24 ~57 minecraft:light_gray_concrete replace
fill ~231 ~24 ~58 ~293 ~24 ~58 minecraft:light_gray_concrete replace
fill ~262 ~24 ~60 ~262 ~24 ~61 minecraft:light_gray_concrete replace
fill ~271 ~24 ~60 ~271 ~24 ~61 minecraft:light_gray_concrete replace
fill ~301 ~24 ~60 ~301 ~24 ~61 minecraft:light_gray_concrete replace
fill ~240 ~24 ~62 ~302 ~24 ~62 minecraft:light_gray_concrete replace
fill ~316 ~24 ~64 ~316 ~24 ~65 minecraft:light_gray_concrete replace
fill ~255 ~24 ~66 ~317 ~24 ~66 minecraft:light_gray_concrete replace
fill ~265 ~24 ~68 ~265 ~24 ~69 minecraft:light_gray_concrete replace
fill ~225 ~24 ~70 ~266 ~24 ~70 minecraft:light_gray_concrete replace
fill ~310 ~24 ~72 ~310 ~24 ~73 minecraft:light_gray_concrete replace
fill ~313 ~24 ~72 ~313 ~24 ~73 minecraft:light_gray_concrete replace
fill ~337 ~24 ~72 ~337 ~24 ~73 minecraft:light_gray_concrete replace
fill ~261 ~24 ~74 ~338 ~24 ~74 minecraft:light_gray_concrete replace
fill ~280 ~24 ~76 ~280 ~24 ~77 minecraft:light_gray_concrete replace
fill ~328 ~24 ~76 ~328 ~24 ~77 minecraft:light_gray_concrete replace
fill ~249 ~24 ~78 ~329 ~24 ~78 minecraft:light_gray_concrete replace
fill ~343 ~24 ~80 ~343 ~24 ~81 minecraft:light_gray_concrete replace
fill ~273 ~24 ~82 ~344 ~24 ~82 minecraft:light_gray_concrete replace
fill ~82 ~24 ~84 ~82 ~24 ~85 minecraft:light_gray_concrete replace
fill ~81 ~24 ~86 ~83 ~24 ~86 minecraft:light_gray_concrete replace
fill ~85 ~24 ~88 ~85 ~24 ~89 minecraft:light_gray_concrete replace
fill ~84 ~24 ~90 ~86 ~24 ~90 minecraft:light_gray_concrete replace
fill ~88 ~24 ~92 ~88 ~24 ~93 minecraft:light_gray_concrete replace
fill ~87 ~24 ~94 ~89 ~24 ~94 minecraft:light_gray_concrete replace
fill ~133 ~24 ~100 ~133 ~24 ~101 minecraft:light_gray_concrete replace
fill ~136 ~24 ~100 ~136 ~24 ~101 minecraft:light_gray_concrete replace
fill ~120 ~24 ~102 ~137 ~24 ~102 minecraft:light_gray_concrete replace
fill ~103 ~24 ~104 ~103 ~24 ~105 minecraft:light_gray_concrete replace
fill ~93 ~24 ~106 ~104 ~24 ~106 minecraft:light_gray_concrete replace
fill ~106 ~24 ~108 ~106 ~24 ~109 minecraft:light_gray_concrete replace
fill ~96 ~24 ~110 ~107 ~24 ~110 minecraft:light_gray_concrete replace
fill ~109 ~24 ~112 ~109 ~24 ~113 minecraft:light_gray_concrete replace
fill ~99 ~24 ~114 ~110 ~24 ~114 minecraft:light_gray_concrete replace
fill ~157 ~24 ~120 ~157 ~24 ~121 minecraft:light_gray_concrete replace
fill ~160 ~24 ~120 ~160 ~24 ~121 minecraft:light_gray_concrete replace
fill ~132 ~24 ~122 ~161 ~24 ~122 minecraft:light_gray_concrete replace
fill ~121 ~24 ~124 ~121 ~24 ~125 minecraft:light_gray_concrete replace
fill ~111 ~24 ~126 ~122 ~24 ~126 minecraft:light_gray_concrete replace
fill ~124 ~24 ~128 ~124 ~24 ~129 minecraft:light_gray_concrete replace
fill ~114 ~24 ~130 ~125 ~24 ~130 minecraft:light_gray_concrete replace
fill ~130 ~24 ~132 ~130 ~24 ~133 minecraft:light_gray_concrete replace
fill ~117 ~24 ~134 ~131 ~24 ~134 minecraft:light_gray_concrete replace
fill ~181 ~24 ~140 ~181 ~24 ~141 minecraft:light_gray_concrete replace
fill ~184 ~24 ~140 ~184 ~24 ~141 minecraft:light_gray_concrete replace
fill ~147 ~24 ~142 ~185 ~24 ~142 minecraft:light_gray_concrete replace
fill ~151 ~24 ~144 ~151 ~24 ~145 minecraft:light_gray_concrete replace
fill ~129 ~24 ~146 ~152 ~24 ~146 minecraft:light_gray_concrete replace
fill ~166 ~24 ~148 ~166 ~24 ~149 minecraft:light_gray_concrete replace
fill ~138 ~24 ~150 ~167 ~24 ~150 minecraft:light_gray_concrete replace
fill ~169 ~24 ~152 ~169 ~24 ~153 minecraft:light_gray_concrete replace
fill ~141 ~24 ~154 ~170 ~24 ~154 minecraft:light_gray_concrete replace
fill ~211 ~24 ~156 ~211 ~24 ~157 minecraft:light_gray_concrete replace
fill ~214 ~24 ~156 ~214 ~24 ~157 minecraft:light_gray_concrete replace
fill ~180 ~24 ~158 ~215 ~24 ~158 minecraft:light_gray_concrete replace
fill ~190 ~24 ~160 ~190 ~24 ~161 minecraft:light_gray_concrete replace
fill ~153 ~24 ~162 ~191 ~24 ~162 minecraft:light_gray_concrete replace
fill ~193 ~24 ~164 ~193 ~24 ~165 minecraft:light_gray_concrete replace
fill ~156 ~24 ~166 ~194 ~24 ~166 minecraft:light_gray_concrete replace
fill ~196 ~24 ~168 ~196 ~24 ~169 minecraft:light_gray_concrete replace
fill ~159 ~24 ~170 ~197 ~24 ~170 minecraft:light_gray_concrete replace
fill ~229 ~24 ~172 ~229 ~24 ~173 minecraft:light_gray_concrete replace
fill ~232 ~24 ~172 ~232 ~24 ~173 minecraft:light_gray_concrete replace
fill ~201 ~24 ~174 ~233 ~24 ~174 minecraft:light_gray_concrete replace
fill ~217 ~24 ~176 ~217 ~24 ~177 minecraft:light_gray_concrete replace
fill ~189 ~24 ~178 ~218 ~24 ~178 minecraft:light_gray_concrete replace
fill ~220 ~24 ~180 ~220 ~24 ~181 minecraft:light_gray_concrete replace
fill ~192 ~24 ~182 ~221 ~24 ~182 minecraft:light_gray_concrete replace
fill ~223 ~24 ~184 ~223 ~24 ~185 minecraft:light_gray_concrete replace
fill ~195 ~24 ~186 ~224 ~24 ~186 minecraft:light_gray_concrete replace
fill ~253 ~24 ~188 ~253 ~24 ~189 minecraft:light_gray_concrete replace
fill ~256 ~24 ~188 ~256 ~24 ~189 minecraft:light_gray_concrete replace
fill ~216 ~24 ~190 ~257 ~24 ~190 minecraft:light_gray_concrete replace
fill ~244 ~24 ~192 ~244 ~24 ~193 minecraft:light_gray_concrete replace
fill ~210 ~24 ~194 ~245 ~24 ~194 minecraft:light_gray_concrete replace
fill ~247 ~24 ~196 ~247 ~24 ~197 minecraft:light_gray_concrete replace
fill ~213 ~24 ~198 ~248 ~24 ~198 minecraft:light_gray_concrete replace
fill ~259 ~24 ~200 ~259 ~24 ~201 minecraft:light_gray_concrete replace
fill ~219 ~24 ~202 ~260 ~24 ~202 minecraft:light_gray_concrete replace
fill ~286 ~24 ~204 ~286 ~24 ~205 minecraft:light_gray_concrete replace
fill ~289 ~24 ~204 ~289 ~24 ~205 minecraft:light_gray_concrete replace
fill ~243 ~24 ~206 ~290 ~24 ~206 minecraft:light_gray_concrete replace
fill ~295 ~24 ~208 ~295 ~24 ~209 minecraft:light_gray_concrete replace
fill ~298 ~24 ~208 ~298 ~24 ~209 minecraft:light_gray_concrete replace
fill ~246 ~24 ~210 ~299 ~24 ~210 minecraft:light_gray_concrete replace
fill ~319 ~24 ~212 ~319 ~24 ~213 minecraft:light_gray_concrete replace
fill ~258 ~24 ~214 ~320 ~24 ~214 minecraft:light_gray_concrete replace
fill ~331 ~24 ~216 ~331 ~24 ~217 minecraft:light_gray_concrete replace
fill ~267 ~24 ~218 ~332 ~24 ~218 minecraft:light_gray_concrete replace
fill ~334 ~24 ~220 ~334 ~24 ~221 minecraft:light_gray_concrete replace
fill ~270 ~24 ~222 ~335 ~24 ~222 minecraft:light_gray_concrete replace
fill ~268 ~24 ~224 ~268 ~24 ~225 minecraft:light_gray_concrete replace
fill ~228 ~24 ~226 ~269 ~24 ~226 minecraft:light_gray_concrete replace
fill ~274 ~24 ~228 ~274 ~24 ~229 minecraft:light_gray_concrete replace
fill ~234 ~24 ~230 ~275 ~24 ~230 minecraft:light_gray_concrete replace
fill ~277 ~24 ~232 ~277 ~24 ~233 minecraft:light_gray_concrete replace
fill ~237 ~24 ~234 ~278 ~24 ~234 minecraft:light_gray_concrete replace
fill ~304 ~24 ~236 ~304 ~24 ~237 minecraft:light_gray_concrete replace
fill ~307 ~24 ~236 ~307 ~24 ~237 minecraft:light_gray_concrete replace
fill ~252 ~24 ~238 ~308 ~24 ~238 minecraft:light_gray_concrete replace
fill ~322 ~24 ~240 ~322 ~24 ~241 minecraft:light_gray_concrete replace
fill ~325 ~24 ~240 ~325 ~24 ~241 minecraft:light_gray_concrete replace
fill ~264 ~24 ~242 ~326 ~24 ~242 minecraft:light_gray_concrete replace
fill ~346 ~24 ~244 ~346 ~24 ~245 minecraft:light_gray_concrete replace
fill ~276 ~24 ~246 ~347 ~24 ~246 minecraft:light_gray_concrete replace
fill ~349 ~24 ~248 ~349 ~24 ~249 minecraft:light_gray_concrete replace
fill ~279 ~24 ~250 ~350 ~24 ~250 minecraft:light_gray_concrete replace
fill ~352 ~24 ~252 ~352 ~24 ~253 minecraft:light_gray_concrete replace
fill ~282 ~24 ~254 ~353 ~24 ~254 minecraft:light_gray_concrete replace
fill ~133 ~24 ~256 ~133 ~24 ~257 minecraft:light_gray_concrete replace
fill ~136 ~24 ~256 ~136 ~24 ~257 minecraft:light_gray_concrete replace
fill ~148 ~24 ~256 ~148 ~24 ~257 minecraft:light_gray_concrete replace
fill ~157 ~24 ~256 ~157 ~24 ~257 minecraft:light_gray_concrete replace
fill ~160 ~24 ~256 ~160 ~24 ~257 minecraft:light_gray_concrete replace
fill ~181 ~24 ~256 ~181 ~24 ~257 minecraft:light_gray_concrete replace
fill ~184 ~24 ~256 ~184 ~24 ~257 minecraft:light_gray_concrete replace
fill ~211 ~24 ~256 ~211 ~24 ~257 minecraft:light_gray_concrete replace
fill ~214 ~24 ~256 ~214 ~24 ~257 minecraft:light_gray_concrete replace
fill ~229 ~24 ~256 ~229 ~24 ~257 minecraft:light_gray_concrete replace
fill ~232 ~24 ~256 ~232 ~24 ~257 minecraft:light_gray_concrete replace
fill ~253 ~24 ~256 ~253 ~24 ~257 minecraft:light_gray_concrete replace
fill ~256 ~24 ~256 ~256 ~24 ~257 minecraft:light_gray_concrete replace
fill ~286 ~24 ~256 ~286 ~24 ~257 minecraft:light_gray_concrete replace
fill ~289 ~24 ~256 ~289 ~24 ~257 minecraft:light_gray_concrete replace
fill ~295 ~24 ~256 ~295 ~24 ~257 minecraft:light_gray_concrete replace
fill ~298 ~24 ~256 ~298 ~24 ~257 minecraft:light_gray_concrete replace
fill ~304 ~24 ~256 ~304 ~24 ~257 minecraft:light_gray_concrete replace
fill ~307 ~24 ~256 ~307 ~24 ~257 minecraft:light_gray_concrete replace
fill ~322 ~24 ~256 ~322 ~24 ~257 minecraft:light_gray_concrete replace
fill ~325 ~24 ~256 ~325 ~24 ~257 minecraft:light_gray_concrete replace
fill ~132 ~24 ~258 ~326 ~24 ~258 minecraft:light_gray_concrete replace
fill ~91 ~24 ~260 ~91 ~24 ~261 minecraft:light_gray_concrete replace
fill ~112 ~24 ~260 ~112 ~24 ~261 minecraft:light_gray_concrete replace
fill ~139 ~24 ~260 ~139 ~24 ~261 minecraft:light_gray_concrete replace
fill ~172 ~24 ~260 ~172 ~24 ~261 minecraft:light_gray_concrete replace
fill ~199 ~24 ~260 ~199 ~24 ~261 minecraft:light_gray_concrete replace
fill ~235 ~24 ~260 ~235 ~24 ~261 minecraft:light_gray_concrete replace
fill ~262 ~24 ~260 ~262 ~24 ~261 minecraft:light_gray_concrete replace
fill ~280 ~24 ~260 ~280 ~24 ~261 minecraft:light_gray_concrete replace
fill ~313 ~24 ~260 ~313 ~24 ~261 minecraft:light_gray_concrete replace
fill ~340 ~24 ~260 ~340 ~24 ~261 minecraft:light_gray_concrete replace
fill ~90 ~24 ~262 ~341 ~24 ~262 minecraft:light_gray_concrete replace
fill ~88 ~24 ~264 ~88 ~24 ~265 minecraft:light_gray_concrete replace
fill ~109 ~24 ~264 ~109 ~24 ~265 minecraft:light_gray_concrete replace
fill ~130 ~24 ~264 ~130 ~24 ~265 minecraft:light_gray_concrete replace
fill ~169 ~24 ~264 ~169 ~24 ~265 minecraft:light_gray_concrete replace
fill ~196 ~24 ~264 ~196 ~24 ~265 minecraft:light_gray_concrete replace
fill ~223 ~24 ~264 ~223 ~24 ~265 minecraft:light_gray_concrete replace
fill ~259 ~24 ~264 ~259 ~24 ~265 minecraft:light_gray_concrete replace
fill ~277 ~24 ~264 ~277 ~24 ~265 minecraft:light_gray_concrete replace
fill ~334 ~24 ~264 ~334 ~24 ~265 minecraft:light_gray_concrete replace
fill ~352 ~24 ~264 ~352 ~24 ~265 minecraft:light_gray_concrete replace
fill ~87 ~24 ~266 ~353 ~24 ~266 minecraft:light_gray_concrete replace
fill ~85 ~24 ~268 ~85 ~24 ~269 minecraft:light_gray_concrete replace
fill ~106 ~24 ~268 ~106 ~24 ~269 minecraft:light_gray_concrete replace
fill ~124 ~24 ~268 ~124 ~24 ~269 minecraft:light_gray_concrete replace
fill ~166 ~24 ~268 ~166 ~24 ~269 minecraft:light_gray_concrete replace
fill ~193 ~24 ~268 ~193 ~24 ~269 minecraft:light_gray_concrete replace
fill ~220 ~24 ~268 ~220 ~24 ~269 minecraft:light_gray_concrete replace
fill ~247 ~24 ~268 ~247 ~24 ~269 minecraft:light_gray_concrete replace
fill ~274 ~24 ~268 ~274 ~24 ~269 minecraft:light_gray_concrete replace
fill ~331 ~24 ~268 ~331 ~24 ~269 minecraft:light_gray_concrete replace
fill ~349 ~24 ~268 ~349 ~24 ~269 minecraft:light_gray_concrete replace
fill ~84 ~24 ~270 ~350 ~24 ~270 minecraft:light_gray_concrete replace
fill ~82 ~24 ~272 ~82 ~24 ~273 minecraft:light_gray_concrete replace
fill ~103 ~24 ~272 ~103 ~24 ~273 minecraft:light_gray_concrete replace
fill ~121 ~24 ~272 ~121 ~24 ~273 minecraft:light_gray_concrete replace
fill ~151 ~24 ~272 ~151 ~24 ~273 minecraft:light_gray_concrete replace
fill ~190 ~24 ~272 ~190 ~24 ~273 minecraft:light_gray_concrete replace
fill ~217 ~24 ~272 ~217 ~24 ~273 minecraft:light_gray_concrete replace
fill ~244 ~24 ~272 ~244 ~24 ~273 minecraft:light_gray_concrete replace
fill ~268 ~24 ~272 ~268 ~24 ~273 minecraft:light_gray_concrete replace
fill ~319 ~24 ~272 ~319 ~24 ~273 minecraft:light_gray_concrete replace
fill ~346 ~24 ~272 ~346 ~24 ~273 minecraft:light_gray_concrete replace
fill ~81 ~24 ~274 ~347 ~24 ~274 minecraft:light_gray_concrete replace
fill ~79 ~24 ~276 ~79 ~24 ~277 minecraft:light_gray_concrete replace
fill ~100 ~24 ~276 ~100 ~24 ~277 minecraft:light_gray_concrete replace
fill ~118 ~24 ~276 ~118 ~24 ~277 minecraft:light_gray_concrete replace
fill ~145 ~24 ~276 ~145 ~24 ~277 minecraft:light_gray_concrete replace
fill ~187 ~24 ~276 ~187 ~24 ~277 minecraft:light_gray_concrete replace
fill ~205 ~24 ~276 ~205 ~24 ~277 minecraft:light_gray_concrete replace
fill ~241 ~24 ~276 ~241 ~24 ~277 minecraft:light_gray_concrete replace
fill ~265 ~24 ~276 ~265 ~24 ~277 minecraft:light_gray_concrete replace
fill ~316 ~24 ~276 ~316 ~24 ~277 minecraft:light_gray_concrete replace
fill ~343 ~24 ~276 ~343 ~24 ~277 minecraft:light_gray_concrete replace
fill ~78 ~24 ~278 ~344 ~24 ~278 minecraft:light_gray_concrete replace
fill ~94 ~24 ~280 ~94 ~24 ~281 minecraft:light_gray_concrete replace
fill ~97 ~24 ~280 ~97 ~24 ~281 minecraft:light_gray_concrete replace
fill ~115 ~24 ~280 ~115 ~24 ~281 minecraft:light_gray_concrete replace
fill ~142 ~24 ~280 ~142 ~24 ~281 minecraft:light_gray_concrete replace
fill ~175 ~24 ~280 ~175 ~24 ~281 minecraft:light_gray_concrete replace
fill ~202 ~24 ~280 ~202 ~24 ~281 minecraft:light_gray_concrete replace
fill ~238 ~24 ~280 ~238 ~24 ~281 minecraft:light_gray_concrete replace
fill ~271 ~24 ~280 ~271 ~24 ~281 minecraft:light_gray_concrete replace
fill ~292 ~24 ~280 ~292 ~24 ~281 minecraft:light_gray_concrete replace
fill ~337 ~24 ~280 ~337 ~24 ~281 minecraft:light_gray_concrete replace
fill ~93 ~24 ~282 ~338 ~24 ~282 minecraft:light_gray_concrete replace
fill ~163 ~24 ~284 ~163 ~24 ~285 minecraft:light_gray_concrete replace
fill ~135 ~24 ~286 ~164 ~24 ~286 minecraft:light_gray_concrete replace
fill ~358 ~24 ~296 ~358 ~24 ~297 minecraft:light_gray_concrete replace
fill ~285 ~24 ~298 ~359 ~24 ~298 minecraft:light_gray_concrete replace
fill ~94 ~24 ~300 ~94 ~24 ~301 minecraft:light_gray_concrete replace
fill ~340 ~24 ~300 ~340 ~24 ~301 minecraft:light_gray_concrete replace
fill ~355 ~24 ~300 ~355 ~24 ~301 minecraft:light_gray_concrete replace
fill ~93 ~24 ~302 ~356 ~24 ~302 minecraft:light_gray_concrete replace
setblock ~79 ~25 ~4 minecraft:light_gray_concrete replace
setblock ~97 ~25 ~8 minecraft:light_gray_concrete replace
setblock ~127 ~25 ~8 minecraft:light_gray_concrete replace
setblock ~109 ~25 ~10 minecraft:light_gray_concrete replace
setblock ~111 ~25 ~10 minecraft:light_gray_concrete replace
setblock ~100 ~25 ~12 minecraft:light_gray_concrete replace
setblock ~97 ~25 ~14 minecraft:light_gray_concrete replace
setblock ~99 ~25 ~14 minecraft:light_gray_concrete replace
setblock ~91 ~25 ~16 minecraft:light_gray_concrete replace
setblock ~115 ~25 ~16 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~16 minecraft:light_gray_concrete replace
setblock ~99 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~101 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~128 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~144 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~146 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~118 ~25 ~20 minecraft:light_gray_concrete replace
setblock ~112 ~25 ~22 minecraft:light_gray_concrete replace
setblock ~114 ~25 ~22 minecraft:light_gray_concrete replace
setblock ~112 ~25 ~24 minecraft:light_gray_concrete replace
setblock ~142 ~25 ~24 minecraft:light_gray_concrete replace
setblock ~178 ~25 ~24 minecraft:light_gray_concrete replace
setblock ~114 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~116 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~132 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~149 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~28 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~30 minecraft:light_gray_concrete replace
setblock ~135 ~25 ~30 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~32 minecraft:light_gray_concrete replace
setblock ~175 ~25 ~32 minecraft:light_gray_concrete replace
setblock ~208 ~25 ~32 minecraft:light_gray_concrete replace
setblock ~151 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~153 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~168 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~170 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~185 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~187 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~204 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~187 ~25 ~36 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~159 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~40 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~40 minecraft:light_gray_concrete replace
setblock ~226 ~25 ~40 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~192 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~206 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~208 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~222 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~44 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~183 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~198 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~200 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~199 ~25 ~48 minecraft:light_gray_concrete replace
setblock ~238 ~25 ~48 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~48 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~222 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~52 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~216 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~231 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~233 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~235 ~25 ~56 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~56 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~56 minecraft:light_gray_concrete replace
setblock ~238 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~240 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~255 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~257 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~272 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~291 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~262 ~25 ~60 minecraft:light_gray_concrete replace
setblock ~271 ~25 ~60 minecraft:light_gray_concrete replace
setblock ~301 ~25 ~60 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~249 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~264 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~281 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~64 minecraft:light_gray_concrete replace
setblock ~262 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~264 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~279 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~281 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~315 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~68 minecraft:light_gray_concrete replace
setblock ~232 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~234 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~249 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~251 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~310 ~25 ~72 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~72 minecraft:light_gray_concrete replace
setblock ~337 ~25 ~72 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~270 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~285 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~287 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~302 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~304 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~321 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~76 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~76 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~258 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~273 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~275 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~290 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~324 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~80 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~297 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~333 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~82 ~25 ~84 minecraft:light_gray_concrete replace
setblock ~85 ~25 ~88 minecraft:light_gray_concrete replace
setblock ~88 ~25 ~92 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~100 minecraft:light_gray_concrete replace
setblock ~136 ~25 ~100 minecraft:light_gray_concrete replace
setblock ~127 ~25 ~102 minecraft:light_gray_concrete replace
setblock ~129 ~25 ~102 minecraft:light_gray_concrete replace
setblock ~103 ~25 ~104 minecraft:light_gray_concrete replace
setblock ~100 ~25 ~106 minecraft:light_gray_concrete replace
setblock ~102 ~25 ~106 minecraft:light_gray_concrete replace
setblock ~106 ~25 ~108 minecraft:light_gray_concrete replace
setblock ~103 ~25 ~110 minecraft:light_gray_concrete replace
setblock ~105 ~25 ~110 minecraft:light_gray_concrete replace
setblock ~109 ~25 ~112 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~120 minecraft:light_gray_concrete replace
setblock ~160 ~25 ~120 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~122 minecraft:light_gray_concrete replace
setblock ~141 ~25 ~122 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~124 minecraft:light_gray_concrete replace
setblock ~118 ~25 ~126 minecraft:light_gray_concrete replace
setblock ~120 ~25 ~126 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~128 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~130 minecraft:light_gray_concrete replace
setblock ~123 ~25 ~130 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~132 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~140 minecraft:light_gray_concrete replace
setblock ~184 ~25 ~140 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~171 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~173 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~151 ~25 ~144 minecraft:light_gray_concrete replace
setblock ~136 ~25 ~146 minecraft:light_gray_concrete replace
setblock ~138 ~25 ~146 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~148 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~162 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~169 ~25 ~152 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~154 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~154 minecraft:light_gray_concrete replace
setblock ~211 ~25 ~156 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~156 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~158 minecraft:light_gray_concrete replace
setblock ~195 ~25 ~158 minecraft:light_gray_concrete replace
