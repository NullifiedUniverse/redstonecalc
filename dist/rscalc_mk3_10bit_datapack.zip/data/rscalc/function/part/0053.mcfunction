setblock ~112 ~159 ~592 minecraft:light_gray_concrete replace
setblock ~112 ~159 ~596 minecraft:light_gray_concrete replace
setblock ~114 ~159 ~599 minecraft:light_gray_concrete replace
setblock ~112 ~159 ~600 minecraft:light_gray_concrete replace
setblock ~114 ~159 ~601 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~608 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~616 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~620 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~628 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~632 minecraft:light_gray_concrete replace
setblock ~117 ~159 ~635 minecraft:light_gray_concrete replace
setblock ~115 ~159 ~636 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~640 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~644 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~648 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~652 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~656 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~660 minecraft:light_gray_concrete replace
setblock ~120 ~159 ~663 minecraft:light_gray_concrete replace
setblock ~118 ~159 ~664 minecraft:light_gray_concrete replace
setblock ~121 ~159 ~668 minecraft:light_gray_concrete replace
setblock ~121 ~159 ~672 minecraft:light_gray_concrete replace
setblock ~121 ~159 ~676 minecraft:light_gray_concrete replace
setblock ~123 ~159 ~679 minecraft:light_gray_concrete replace
setblock ~121 ~159 ~680 minecraft:light_gray_concrete replace
setblock ~123 ~159 ~681 minecraft:light_gray_concrete replace
setblock ~124 ~159 ~684 minecraft:light_gray_concrete replace
setblock ~124 ~159 ~688 minecraft:light_gray_concrete replace
setblock ~124 ~159 ~692 minecraft:light_gray_concrete replace
setblock ~124 ~159 ~696 minecraft:light_gray_concrete replace
setblock ~124 ~159 ~700 minecraft:light_gray_concrete replace
setblock ~126 ~159 ~703 minecraft:light_gray_concrete replace
setblock ~124 ~159 ~704 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~708 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~712 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~716 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~720 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~724 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~728 minecraft:light_gray_concrete replace
setblock ~150 ~159 ~731 minecraft:light_gray_concrete replace
setblock ~127 ~159 ~732 minecraft:light_gray_concrete replace
setblock ~153 ~159 ~735 minecraft:light_gray_concrete replace
setblock ~151 ~159 ~736 minecraft:light_gray_concrete replace
setblock ~153 ~159 ~737 minecraft:light_gray_concrete replace
setblock ~154 ~159 ~740 minecraft:light_gray_concrete replace
setblock ~156 ~159 ~743 minecraft:light_gray_concrete replace
setblock ~154 ~159 ~744 minecraft:light_gray_concrete replace
setblock ~156 ~159 ~745 minecraft:light_gray_concrete replace
setblock ~157 ~159 ~748 minecraft:light_gray_concrete replace
setblock ~159 ~159 ~751 minecraft:light_gray_concrete replace
setblock ~157 ~159 ~752 minecraft:light_gray_concrete replace
setblock ~162 ~159 ~755 minecraft:light_gray_concrete replace
setblock ~160 ~159 ~756 minecraft:light_gray_concrete replace
setblock ~165 ~159 ~759 minecraft:light_gray_concrete replace
setblock ~163 ~159 ~760 minecraft:light_gray_concrete replace
setblock ~129 ~159 ~763 minecraft:light_gray_concrete replace
setblock ~166 ~159 ~764 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~768 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~772 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~776 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~780 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~784 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~788 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~792 minecraft:light_gray_concrete replace
setblock ~132 ~159 ~795 minecraft:light_gray_concrete replace
setblock ~130 ~159 ~796 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~800 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~804 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~808 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~812 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~816 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~820 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~824 minecraft:light_gray_concrete replace
setblock ~135 ~159 ~827 minecraft:light_gray_concrete replace
setblock ~133 ~159 ~828 minecraft:light_gray_concrete replace
setblock ~135 ~159 ~829 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~832 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~836 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~840 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~844 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~848 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~852 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~856 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~860 minecraft:light_gray_concrete replace
setblock ~138 ~159 ~863 minecraft:light_gray_concrete replace
setblock ~136 ~159 ~864 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~868 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~872 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~876 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~880 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~884 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~888 minecraft:light_gray_concrete replace
setblock ~141 ~159 ~891 minecraft:light_gray_concrete replace
setblock ~139 ~159 ~892 minecraft:light_gray_concrete replace
setblock ~142 ~159 ~896 minecraft:light_gray_concrete replace
setblock ~142 ~159 ~900 minecraft:light_gray_concrete replace
setblock ~142 ~159 ~904 minecraft:light_gray_concrete replace
setblock ~144 ~159 ~907 minecraft:light_gray_concrete replace
setblock ~142 ~159 ~908 minecraft:light_gray_concrete replace
setblock ~144 ~159 ~909 minecraft:light_gray_concrete replace
setblock ~145 ~159 ~912 minecraft:light_gray_concrete replace
setblock ~145 ~159 ~916 minecraft:light_gray_concrete replace
setblock ~145 ~159 ~920 minecraft:light_gray_concrete replace
setblock ~145 ~159 ~924 minecraft:light_gray_concrete replace
setblock ~145 ~159 ~928 minecraft:light_gray_concrete replace
setblock ~147 ~159 ~931 minecraft:light_gray_concrete replace
setblock ~145 ~159 ~932 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~936 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~940 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~944 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~948 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~952 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~956 minecraft:light_gray_concrete replace
setblock ~174 ~159 ~959 minecraft:light_gray_concrete replace
setblock ~148 ~159 ~960 minecraft:light_gray_concrete replace
setblock ~168 ~159 ~963 minecraft:light_gray_concrete replace
setblock ~171 ~159 ~967 minecraft:light_gray_concrete replace
fill ~105 ~160 ~230 ~107 ~160 ~230 minecraft:light_gray_concrete replace
fill ~81 ~160 ~234 ~83 ~160 ~234 minecraft:light_gray_concrete replace
fill ~102 ~160 ~262 ~104 ~160 ~262 minecraft:light_gray_concrete replace
fill ~99 ~160 ~286 ~101 ~160 ~286 minecraft:light_gray_concrete replace
fill ~96 ~160 ~302 ~98 ~160 ~302 minecraft:light_gray_concrete replace
fill ~93 ~160 ~330 ~95 ~160 ~330 minecraft:light_gray_concrete replace
fill ~90 ~160 ~366 ~92 ~160 ~366 minecraft:light_gray_concrete replace
fill ~87 ~160 ~398 ~89 ~160 ~398 minecraft:light_gray_concrete replace
fill ~84 ~160 ~430 ~86 ~160 ~430 minecraft:light_gray_concrete replace
fill ~78 ~160 ~446 ~80 ~160 ~446 minecraft:light_gray_concrete replace
fill ~108 ~160 ~534 ~110 ~160 ~534 minecraft:light_gray_concrete replace
fill ~111 ~160 ~566 ~113 ~160 ~566 minecraft:light_gray_concrete replace
fill ~114 ~160 ~598 ~116 ~160 ~598 minecraft:light_gray_concrete replace
fill ~117 ~160 ~634 ~119 ~160 ~634 minecraft:light_gray_concrete replace
fill ~120 ~160 ~662 ~122 ~160 ~662 minecraft:light_gray_concrete replace
fill ~123 ~160 ~678 ~125 ~160 ~678 minecraft:light_gray_concrete replace
fill ~126 ~160 ~702 ~128 ~160 ~702 minecraft:light_gray_concrete replace
fill ~150 ~160 ~730 ~152 ~160 ~730 minecraft:light_gray_concrete replace
fill ~153 ~160 ~734 ~155 ~160 ~734 minecraft:light_gray_concrete replace
fill ~156 ~160 ~742 ~158 ~160 ~742 minecraft:light_gray_concrete replace
fill ~159 ~160 ~750 ~161 ~160 ~750 minecraft:light_gray_concrete replace
fill ~162 ~160 ~754 ~164 ~160 ~754 minecraft:light_gray_concrete replace
fill ~165 ~160 ~758 ~167 ~160 ~758 minecraft:light_gray_concrete replace
fill ~129 ~160 ~762 ~131 ~160 ~762 minecraft:light_gray_concrete replace
fill ~132 ~160 ~794 ~134 ~160 ~794 minecraft:light_gray_concrete replace
fill ~135 ~160 ~826 ~137 ~160 ~826 minecraft:light_gray_concrete replace
fill ~138 ~160 ~862 ~140 ~160 ~862 minecraft:light_gray_concrete replace
fill ~141 ~160 ~890 ~143 ~160 ~890 minecraft:light_gray_concrete replace
fill ~144 ~160 ~906 ~146 ~160 ~906 minecraft:light_gray_concrete replace
fill ~147 ~160 ~930 ~149 ~160 ~930 minecraft:light_gray_concrete replace
fill ~174 ~160 ~958 ~176 ~160 ~958 minecraft:light_gray_concrete replace
fill ~168 ~160 ~962 ~170 ~160 ~962 minecraft:light_gray_concrete replace
fill ~171 ~160 ~966 ~173 ~160 ~966 minecraft:light_gray_concrete replace
setblock ~108 ~161 ~230 minecraft:light_gray_concrete replace
setblock ~84 ~161 ~234 minecraft:light_gray_concrete replace
setblock ~105 ~161 ~262 minecraft:light_gray_concrete replace
setblock ~102 ~161 ~286 minecraft:light_gray_concrete replace
setblock ~99 ~161 ~302 minecraft:light_gray_concrete replace
setblock ~96 ~161 ~330 minecraft:light_gray_concrete replace
setblock ~93 ~161 ~366 minecraft:light_gray_concrete replace
setblock ~90 ~161 ~398 minecraft:light_gray_concrete replace
setblock ~87 ~161 ~430 minecraft:light_gray_concrete replace
setblock ~81 ~161 ~446 minecraft:light_gray_concrete replace
setblock ~111 ~161 ~534 minecraft:light_gray_concrete replace
setblock ~114 ~161 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~161 ~598 minecraft:light_gray_concrete replace
setblock ~120 ~161 ~634 minecraft:light_gray_concrete replace
setblock ~123 ~161 ~662 minecraft:light_gray_concrete replace
setblock ~126 ~161 ~678 minecraft:light_gray_concrete replace
setblock ~129 ~161 ~702 minecraft:light_gray_concrete replace
setblock ~153 ~161 ~730 minecraft:light_gray_concrete replace
setblock ~156 ~161 ~734 minecraft:light_gray_concrete replace
setblock ~159 ~161 ~742 minecraft:light_gray_concrete replace
setblock ~162 ~161 ~750 minecraft:light_gray_concrete replace
setblock ~165 ~161 ~754 minecraft:light_gray_concrete replace
setblock ~168 ~161 ~758 minecraft:light_gray_concrete replace
setblock ~132 ~161 ~762 minecraft:light_gray_concrete replace
setblock ~135 ~161 ~794 minecraft:light_gray_concrete replace
setblock ~138 ~161 ~826 minecraft:light_gray_concrete replace
setblock ~141 ~161 ~862 minecraft:light_gray_concrete replace
setblock ~144 ~161 ~890 minecraft:light_gray_concrete replace
setblock ~147 ~161 ~906 minecraft:light_gray_concrete replace
setblock ~150 ~161 ~930 minecraft:light_gray_concrete replace
setblock ~177 ~161 ~958 minecraft:redstone_lamp[lit=false] replace
setblock ~171 ~161 ~962 minecraft:light_gray_concrete replace
setblock ~174 ~161 ~966 minecraft:light_gray_concrete replace
setblock ~108 ~163 ~230 minecraft:light_gray_concrete replace
setblock ~84 ~163 ~234 minecraft:light_gray_concrete replace
setblock ~105 ~163 ~262 minecraft:light_gray_concrete replace
setblock ~102 ~163 ~286 minecraft:light_gray_concrete replace
setblock ~99 ~163 ~302 minecraft:light_gray_concrete replace
setblock ~96 ~163 ~330 minecraft:light_gray_concrete replace
setblock ~93 ~163 ~366 minecraft:light_gray_concrete replace
setblock ~90 ~163 ~398 minecraft:light_gray_concrete replace
setblock ~87 ~163 ~430 minecraft:light_gray_concrete replace
setblock ~81 ~163 ~446 minecraft:light_gray_concrete replace
setblock ~111 ~163 ~534 minecraft:light_gray_concrete replace
setblock ~114 ~163 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~163 ~598 minecraft:light_gray_concrete replace
setblock ~120 ~163 ~634 minecraft:light_gray_concrete replace
setblock ~123 ~163 ~662 minecraft:light_gray_concrete replace
setblock ~126 ~163 ~678 minecraft:light_gray_concrete replace
setblock ~129 ~163 ~702 minecraft:light_gray_concrete replace
setblock ~153 ~163 ~730 minecraft:light_gray_concrete replace
setblock ~156 ~163 ~734 minecraft:light_gray_concrete replace
setblock ~159 ~163 ~742 minecraft:light_gray_concrete replace
setblock ~162 ~163 ~750 minecraft:light_gray_concrete replace
setblock ~165 ~163 ~754 minecraft:light_gray_concrete replace
setblock ~168 ~163 ~758 minecraft:light_gray_concrete replace
setblock ~132 ~163 ~762 minecraft:light_gray_concrete replace
setblock ~135 ~163 ~794 minecraft:light_gray_concrete replace
setblock ~138 ~163 ~826 minecraft:light_gray_concrete replace
setblock ~141 ~163 ~862 minecraft:light_gray_concrete replace
setblock ~144 ~163 ~890 minecraft:light_gray_concrete replace
setblock ~147 ~163 ~906 minecraft:light_gray_concrete replace
setblock ~150 ~163 ~930 minecraft:light_gray_concrete replace
setblock ~171 ~163 ~962 minecraft:light_gray_concrete replace
setblock ~174 ~163 ~966 minecraft:light_gray_concrete replace
fill ~109 ~164 ~230 ~495 ~164 ~230 minecraft:light_gray_concrete replace
fill ~85 ~164 ~234 ~497 ~164 ~234 minecraft:light_gray_concrete replace
fill ~106 ~164 ~262 ~481 ~164 ~262 minecraft:light_gray_concrete replace
fill ~103 ~164 ~286 ~483 ~164 ~286 minecraft:light_gray_concrete replace
fill ~100 ~164 ~302 ~485 ~164 ~302 minecraft:light_gray_concrete replace
fill ~97 ~164 ~330 ~487 ~164 ~330 minecraft:light_gray_concrete replace
fill ~94 ~164 ~366 ~489 ~164 ~366 minecraft:light_gray_concrete replace
fill ~91 ~164 ~398 ~491 ~164 ~398 minecraft:light_gray_concrete replace
fill ~88 ~164 ~430 ~493 ~164 ~430 minecraft:light_gray_concrete replace
fill ~82 ~164 ~446 ~499 ~164 ~446 minecraft:light_gray_concrete replace
fill ~112 ~164 ~534 ~467 ~164 ~534 minecraft:light_gray_concrete replace
fill ~115 ~164 ~566 ~469 ~164 ~566 minecraft:light_gray_concrete replace
fill ~118 ~164 ~598 ~471 ~164 ~598 minecraft:light_gray_concrete replace
fill ~121 ~164 ~634 ~473 ~164 ~634 minecraft:light_gray_concrete replace
fill ~124 ~164 ~662 ~475 ~164 ~662 minecraft:light_gray_concrete replace
fill ~127 ~164 ~678 ~477 ~164 ~678 minecraft:light_gray_concrete replace
fill ~130 ~164 ~702 ~479 ~164 ~702 minecraft:light_gray_concrete replace
fill ~154 ~164 ~730 ~439 ~164 ~730 minecraft:light_gray_concrete replace
fill ~157 ~164 ~734 ~441 ~164 ~734 minecraft:light_gray_concrete replace
fill ~160 ~164 ~742 ~443 ~164 ~742 minecraft:light_gray_concrete replace
fill ~163 ~164 ~750 ~445 ~164 ~750 minecraft:light_gray_concrete replace
fill ~166 ~164 ~754 ~447 ~164 ~754 minecraft:light_gray_concrete replace
fill ~169 ~164 ~758 ~449 ~164 ~758 minecraft:light_gray_concrete replace
fill ~133 ~164 ~762 ~453 ~164 ~762 minecraft:light_gray_concrete replace
fill ~136 ~164 ~794 ~455 ~164 ~794 minecraft:light_gray_concrete replace
fill ~139 ~164 ~826 ~457 ~164 ~826 minecraft:light_gray_concrete replace
fill ~142 ~164 ~862 ~459 ~164 ~862 minecraft:light_gray_concrete replace
fill ~145 ~164 ~890 ~461 ~164 ~890 minecraft:light_gray_concrete replace
fill ~148 ~164 ~906 ~463 ~164 ~906 minecraft:light_gray_concrete replace
fill ~151 ~164 ~930 ~465 ~164 ~930 minecraft:light_gray_concrete replace
fill ~172 ~164 ~962 ~501 ~164 ~962 minecraft:light_gray_concrete replace
fill ~175 ~164 ~966 ~451 ~164 ~966 minecraft:light_gray_concrete replace
setblock ~108 ~165 ~230 minecraft:light_gray_concrete replace
setblock ~496 ~165 ~230 minecraft:light_gray_concrete replace
setblock ~84 ~165 ~234 minecraft:light_gray_concrete replace
setblock ~498 ~165 ~234 minecraft:light_gray_concrete replace
setblock ~105 ~165 ~262 minecraft:light_gray_concrete replace
setblock ~482 ~165 ~262 minecraft:light_gray_concrete replace
setblock ~102 ~165 ~286 minecraft:light_gray_concrete replace
setblock ~484 ~165 ~286 minecraft:light_gray_concrete replace
setblock ~99 ~165 ~302 minecraft:light_gray_concrete replace
setblock ~486 ~165 ~302 minecraft:light_gray_concrete replace
setblock ~96 ~165 ~330 minecraft:light_gray_concrete replace
setblock ~488 ~165 ~330 minecraft:light_gray_concrete replace
setblock ~93 ~165 ~366 minecraft:light_gray_concrete replace
setblock ~490 ~165 ~366 minecraft:light_gray_concrete replace
setblock ~90 ~165 ~398 minecraft:light_gray_concrete replace
setblock ~492 ~165 ~398 minecraft:light_gray_concrete replace
setblock ~87 ~165 ~430 minecraft:light_gray_concrete replace
setblock ~494 ~165 ~430 minecraft:light_gray_concrete replace
setblock ~81 ~165 ~446 minecraft:light_gray_concrete replace
setblock ~500 ~165 ~446 minecraft:light_gray_concrete replace
setblock ~111 ~165 ~534 minecraft:light_gray_concrete replace
setblock ~468 ~165 ~534 minecraft:light_gray_concrete replace
setblock ~114 ~165 ~566 minecraft:light_gray_concrete replace
setblock ~470 ~165 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~165 ~598 minecraft:light_gray_concrete replace
setblock ~472 ~165 ~598 minecraft:light_gray_concrete replace
setblock ~120 ~165 ~634 minecraft:light_gray_concrete replace
setblock ~474 ~165 ~634 minecraft:light_gray_concrete replace
setblock ~123 ~165 ~662 minecraft:light_gray_concrete replace
setblock ~476 ~165 ~662 minecraft:light_gray_concrete replace
setblock ~126 ~165 ~678 minecraft:light_gray_concrete replace
setblock ~478 ~165 ~678 minecraft:light_gray_concrete replace
setblock ~129 ~165 ~702 minecraft:light_gray_concrete replace
setblock ~480 ~165 ~702 minecraft:light_gray_concrete replace
setblock ~153 ~165 ~730 minecraft:light_gray_concrete replace
setblock ~440 ~165 ~730 minecraft:light_gray_concrete replace
setblock ~156 ~165 ~734 minecraft:light_gray_concrete replace
setblock ~442 ~165 ~734 minecraft:light_gray_concrete replace
setblock ~159 ~165 ~742 minecraft:light_gray_concrete replace
setblock ~444 ~165 ~742 minecraft:light_gray_concrete replace
setblock ~162 ~165 ~750 minecraft:light_gray_concrete replace
setblock ~446 ~165 ~750 minecraft:light_gray_concrete replace
setblock ~165 ~165 ~754 minecraft:light_gray_concrete replace
setblock ~448 ~165 ~754 minecraft:light_gray_concrete replace
setblock ~168 ~165 ~758 minecraft:light_gray_concrete replace
setblock ~450 ~165 ~758 minecraft:light_gray_concrete replace
setblock ~132 ~165 ~762 minecraft:light_gray_concrete replace
setblock ~454 ~165 ~762 minecraft:light_gray_concrete replace
setblock ~135 ~165 ~794 minecraft:light_gray_concrete replace
setblock ~456 ~165 ~794 minecraft:light_gray_concrete replace
setblock ~138 ~165 ~826 minecraft:light_gray_concrete replace
setblock ~458 ~165 ~826 minecraft:light_gray_concrete replace
setblock ~141 ~165 ~862 minecraft:light_gray_concrete replace
setblock ~460 ~165 ~862 minecraft:light_gray_concrete replace
setblock ~144 ~165 ~890 minecraft:light_gray_concrete replace
setblock ~462 ~165 ~890 minecraft:light_gray_concrete replace
setblock ~147 ~165 ~906 minecraft:light_gray_concrete replace
setblock ~464 ~165 ~906 minecraft:light_gray_concrete replace
setblock ~150 ~165 ~930 minecraft:light_gray_concrete replace
setblock ~466 ~165 ~930 minecraft:light_gray_concrete replace
setblock ~171 ~165 ~962 minecraft:light_gray_concrete replace
setblock ~502 ~165 ~962 minecraft:light_gray_concrete replace
setblock ~174 ~165 ~966 minecraft:light_gray_concrete replace
setblock ~452 ~165 ~966 minecraft:light_gray_concrete replace
setblock ~496 ~167 ~230 minecraft:light_gray_concrete replace
setblock ~498 ~167 ~234 minecraft:light_gray_concrete replace
setblock ~482 ~167 ~262 minecraft:light_gray_concrete replace
setblock ~484 ~167 ~286 minecraft:light_gray_concrete replace
setblock ~486 ~167 ~302 minecraft:light_gray_concrete replace
setblock ~488 ~167 ~330 minecraft:light_gray_concrete replace
setblock ~490 ~167 ~366 minecraft:light_gray_concrete replace
setblock ~492 ~167 ~398 minecraft:light_gray_concrete replace
setblock ~494 ~167 ~430 minecraft:light_gray_concrete replace
setblock ~500 ~167 ~446 minecraft:light_gray_concrete replace
setblock ~468 ~167 ~534 minecraft:light_gray_concrete replace
setblock ~470 ~167 ~566 minecraft:light_gray_concrete replace
setblock ~472 ~167 ~598 minecraft:light_gray_concrete replace
setblock ~474 ~167 ~634 minecraft:light_gray_concrete replace
setblock ~476 ~167 ~662 minecraft:light_gray_concrete replace
setblock ~478 ~167 ~678 minecraft:light_gray_concrete replace
setblock ~480 ~167 ~702 minecraft:light_gray_concrete replace
setblock ~440 ~167 ~730 minecraft:light_gray_concrete replace
setblock ~442 ~167 ~734 minecraft:light_gray_concrete replace
setblock ~444 ~167 ~742 minecraft:light_gray_concrete replace
setblock ~446 ~167 ~750 minecraft:light_gray_concrete replace
setblock ~448 ~167 ~754 minecraft:light_gray_concrete replace
setblock ~450 ~167 ~758 minecraft:light_gray_concrete replace
setblock ~454 ~167 ~762 minecraft:light_gray_concrete replace
setblock ~456 ~167 ~794 minecraft:light_gray_concrete replace
setblock ~458 ~167 ~826 minecraft:light_gray_concrete replace
setblock ~460 ~167 ~862 minecraft:light_gray_concrete replace
setblock ~462 ~167 ~890 minecraft:light_gray_concrete replace
setblock ~464 ~167 ~906 minecraft:light_gray_concrete replace
setblock ~466 ~167 ~930 minecraft:light_gray_concrete replace
setblock ~502 ~167 ~962 minecraft:light_gray_concrete replace
setblock ~452 ~167 ~966 minecraft:light_gray_concrete replace
fill ~440 ~168 ~3 ~440 ~168 ~729 minecraft:light_gray_concrete replace
fill ~454 ~168 ~3 ~454 ~168 ~761 minecraft:light_gray_concrete replace
fill ~468 ~168 ~3 ~468 ~168 ~533 minecraft:light_gray_concrete replace
fill ~494 ~168 ~3 ~494 ~168 ~429 minecraft:light_gray_concrete replace
fill ~498 ~168 ~3 ~498 ~168 ~233 minecraft:light_gray_concrete replace
fill ~450 ~168 ~5 ~450 ~168 ~757 minecraft:light_gray_concrete replace
fill ~464 ~168 ~5 ~464 ~168 ~905 minecraft:light_gray_concrete replace
fill ~478 ~168 ~5 ~478 ~168 ~677 minecraft:light_gray_concrete replace
fill ~484 ~168 ~5 ~484 ~168 ~285 minecraft:light_gray_concrete replace
fill ~500 ~168 ~5 ~500 ~168 ~445 minecraft:light_gray_concrete replace
fill ~442 ~168 ~7 ~442 ~168 ~733 minecraft:light_gray_concrete replace
fill ~456 ~168 ~7 ~456 ~168 ~793 minecraft:light_gray_concrete replace
fill ~470 ~168 ~7 ~470 ~168 ~565 minecraft:light_gray_concrete replace
fill ~492 ~168 ~7 ~492 ~168 ~397 minecraft:light_gray_concrete replace
fill ~502 ~168 ~7 ~502 ~168 ~961 minecraft:light_gray_concrete replace
fill ~452 ~168 ~9 ~452 ~168 ~965 minecraft:light_gray_concrete replace
fill ~466 ~168 ~9 ~466 ~168 ~929 minecraft:light_gray_concrete replace
fill ~480 ~168 ~9 ~480 ~168 ~701 minecraft:light_gray_concrete replace
fill ~482 ~168 ~9 ~482 ~168 ~261 minecraft:light_gray_concrete replace
fill ~496 ~168 ~9 ~496 ~168 ~229 minecraft:light_gray_concrete replace
fill ~448 ~168 ~11 ~448 ~168 ~753 minecraft:light_gray_concrete replace
fill ~462 ~168 ~11 ~462 ~168 ~889 minecraft:light_gray_concrete replace
fill ~476 ~168 ~11 ~476 ~168 ~661 minecraft:light_gray_concrete replace
fill ~486 ~168 ~11 ~486 ~168 ~301 minecraft:light_gray_concrete replace
fill ~444 ~168 ~13 ~444 ~168 ~741 minecraft:light_gray_concrete replace
fill ~458 ~168 ~13 ~458 ~168 ~825 minecraft:light_gray_concrete replace
fill ~472 ~168 ~13 ~472 ~168 ~597 minecraft:light_gray_concrete replace
fill ~490 ~168 ~13 ~490 ~168 ~365 minecraft:light_gray_concrete replace
fill ~446 ~168 ~15 ~446 ~168 ~749 minecraft:light_gray_concrete replace
fill ~460 ~168 ~15 ~460 ~168 ~861 minecraft:light_gray_concrete replace
fill ~474 ~168 ~15 ~474 ~168 ~633 minecraft:light_gray_concrete replace
fill ~488 ~168 ~15 ~488 ~168 ~329 minecraft:light_gray_concrete replace
setblock ~440 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~498 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~500 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~502 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~496 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~496 ~169 ~230 minecraft:light_gray_concrete replace
setblock ~498 ~169 ~234 minecraft:light_gray_concrete replace
setblock ~482 ~169 ~262 minecraft:light_gray_concrete replace
setblock ~484 ~169 ~286 minecraft:light_gray_concrete replace
setblock ~486 ~169 ~302 minecraft:light_gray_concrete replace
setblock ~488 ~169 ~330 minecraft:light_gray_concrete replace
setblock ~490 ~169 ~366 minecraft:light_gray_concrete replace
setblock ~492 ~169 ~398 minecraft:light_gray_concrete replace
setblock ~494 ~169 ~430 minecraft:light_gray_concrete replace
setblock ~500 ~169 ~446 minecraft:light_gray_concrete replace
setblock ~468 ~169 ~534 minecraft:light_gray_concrete replace
setblock ~470 ~169 ~566 minecraft:light_gray_concrete replace
setblock ~472 ~169 ~598 minecraft:light_gray_concrete replace
setblock ~474 ~169 ~634 minecraft:light_gray_concrete replace
setblock ~476 ~169 ~662 minecraft:light_gray_concrete replace
setblock ~478 ~169 ~678 minecraft:light_gray_concrete replace
setblock ~480 ~169 ~702 minecraft:light_gray_concrete replace
setblock ~440 ~169 ~730 minecraft:light_gray_concrete replace
setblock ~442 ~169 ~734 minecraft:light_gray_concrete replace
setblock ~444 ~169 ~742 minecraft:light_gray_concrete replace
setblock ~446 ~169 ~750 minecraft:light_gray_concrete replace
setblock ~448 ~169 ~754 minecraft:light_gray_concrete replace
setblock ~450 ~169 ~758 minecraft:light_gray_concrete replace
setblock ~454 ~169 ~762 minecraft:light_gray_concrete replace
setblock ~456 ~169 ~794 minecraft:light_gray_concrete replace
setblock ~458 ~169 ~826 minecraft:light_gray_concrete replace
setblock ~460 ~169 ~862 minecraft:light_gray_concrete replace
setblock ~462 ~169 ~890 minecraft:light_gray_concrete replace
setblock ~464 ~169 ~906 minecraft:light_gray_concrete replace
setblock ~466 ~169 ~930 minecraft:light_gray_concrete replace
setblock ~502 ~169 ~962 minecraft:light_gray_concrete replace
setblock ~452 ~169 ~966 minecraft:light_gray_concrete replace
setblock ~440 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~498 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~500 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~502 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~496 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~171 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~171 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~171 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~171 ~14 minecraft:light_gray_concrete replace
fill ~499 ~172 ~2 ~553 ~172 ~2 minecraft:light_gray_concrete replace
fill ~501 ~172 ~4 ~553 ~172 ~4 minecraft:light_gray_concrete replace
fill ~503 ~172 ~6 ~553 ~172 ~6 minecraft:light_gray_concrete replace
fill ~497 ~172 ~8 ~553 ~172 ~8 minecraft:light_gray_concrete replace
setblock ~440 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~498 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~500 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~502 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~496 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~175 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~175 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~175 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~175 ~14 minecraft:light_gray_concrete replace
fill ~495 ~176 ~2 ~547 ~176 ~2 minecraft:light_gray_concrete replace
fill ~485 ~176 ~4 ~545 ~176 ~4 minecraft:light_gray_concrete replace
fill ~493 ~176 ~6 ~549 ~176 ~6 minecraft:light_gray_concrete replace
fill ~483 ~176 ~8 ~547 ~176 ~8 minecraft:light_gray_concrete replace
fill ~487 ~176 ~10 ~545 ~176 ~10 minecraft:light_gray_concrete replace
fill ~491 ~176 ~12 ~549 ~176 ~12 minecraft:light_gray_concrete replace
fill ~489 ~176 ~14 ~547 ~176 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~179 ~4 minecraft:light_gray_concrete replace
