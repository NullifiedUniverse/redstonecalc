fill ~315 ~27 ~464 ~315 ~27 ~476 minecraft:redstone_wire replace
setblock ~318 ~27 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~464 ~342 ~27 ~476 minecraft:redstone_wire replace
setblock ~345 ~27 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~466 ~318 ~27 ~478 minecraft:redstone_wire replace
setblock ~339 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~466 ~345 ~27 ~478 minecraft:redstone_wire replace
fill ~78 ~27 ~468 ~78 ~27 ~480 minecraft:redstone_wire replace
fill ~117 ~27 ~468 ~117 ~27 ~480 minecraft:redstone_wire replace
setblock ~120 ~27 ~468 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~468 ~186 ~27 ~480 minecraft:redstone_wire replace
fill ~240 ~27 ~468 ~240 ~27 ~480 minecraft:redstone_wire replace
fill ~264 ~27 ~468 ~264 ~27 ~480 minecraft:redstone_wire replace
fill ~339 ~27 ~468 ~339 ~27 ~480 minecraft:redstone_wire replace
setblock ~93 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~472 ~93 ~27 ~484 minecraft:redstone_wire replace
fill ~96 ~27 ~472 ~96 ~27 ~484 minecraft:redstone_wire replace
fill ~141 ~27 ~472 ~141 ~27 ~484 minecraft:redstone_wire replace
setblock ~150 ~27 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~27 ~472 ~201 ~27 ~484 minecraft:redstone_wire replace
setblock ~270 ~27 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~472 ~291 ~27 ~484 minecraft:redstone_wire replace
fill ~336 ~27 ~472 ~336 ~27 ~484 minecraft:redstone_wire replace
fill ~357 ~27 ~472 ~357 ~27 ~484 minecraft:redstone_wire replace
setblock ~99 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~474 ~270 ~27 ~486 minecraft:redstone_wire replace
setblock ~354 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~476 ~99 ~27 ~488 minecraft:redstone_wire replace
fill ~144 ~27 ~476 ~144 ~27 ~488 minecraft:redstone_wire replace
fill ~162 ~27 ~476 ~162 ~27 ~488 minecraft:redstone_wire replace
setblock ~189 ~27 ~476 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~27 ~476 ~204 ~27 ~488 minecraft:redstone_wire replace
fill ~354 ~27 ~476 ~354 ~27 ~488 minecraft:redstone_wire replace
setblock ~114 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~480 ~114 ~27 ~492 minecraft:redstone_wire replace
fill ~174 ~27 ~480 ~174 ~27 ~492 minecraft:redstone_wire replace
setblock ~216 ~27 ~480 minecraft:redstone_wire replace
fill ~237 ~27 ~480 ~237 ~27 ~492 minecraft:redstone_wire replace
fill ~243 ~27 ~480 ~243 ~27 ~484 minecraft:redstone_wire replace
fill ~267 ~27 ~480 ~267 ~27 ~486 minecraft:redstone_wire replace
fill ~315 ~27 ~480 ~315 ~27 ~492 minecraft:redstone_wire replace
setblock ~318 ~27 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~480 ~342 ~27 ~492 minecraft:redstone_wire replace
setblock ~345 ~27 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~482 ~318 ~27 ~490 minecraft:redstone_wire replace
setblock ~339 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~482 ~345 ~27 ~494 minecraft:redstone_wire replace
fill ~78 ~27 ~484 ~78 ~27 ~496 minecraft:redstone_wire replace
fill ~117 ~27 ~484 ~117 ~27 ~496 minecraft:redstone_wire replace
fill ~186 ~27 ~484 ~186 ~27 ~496 minecraft:redstone_wire replace
fill ~240 ~27 ~484 ~240 ~27 ~496 minecraft:redstone_wire replace
fill ~264 ~27 ~484 ~264 ~27 ~496 minecraft:redstone_wire replace
fill ~339 ~27 ~484 ~339 ~27 ~496 minecraft:redstone_wire replace
setblock ~93 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~488 ~93 ~27 ~500 minecraft:redstone_wire replace
fill ~96 ~27 ~488 ~96 ~27 ~500 minecraft:redstone_wire replace
fill ~141 ~27 ~488 ~141 ~27 ~500 minecraft:redstone_wire replace
fill ~201 ~27 ~488 ~201 ~27 ~500 minecraft:redstone_wire replace
setblock ~267 ~27 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~488 ~291 ~27 ~500 minecraft:redstone_wire replace
fill ~336 ~27 ~488 ~336 ~27 ~500 minecraft:redstone_wire replace
fill ~357 ~27 ~488 ~357 ~27 ~500 minecraft:redstone_wire replace
setblock ~99 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~490 ~270 ~27 ~502 minecraft:redstone_wire replace
setblock ~354 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~492 ~99 ~27 ~502 minecraft:redstone_wire replace
fill ~144 ~27 ~492 ~144 ~27 ~504 minecraft:redstone_wire replace
fill ~162 ~27 ~492 ~162 ~27 ~504 minecraft:redstone_wire replace
fill ~204 ~27 ~492 ~204 ~27 ~504 minecraft:redstone_wire replace
setblock ~318 ~27 ~492 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~492 ~354 ~27 ~504 minecraft:redstone_wire replace
setblock ~114 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~27 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~496 ~114 ~27 ~508 minecraft:redstone_wire replace
fill ~174 ~27 ~496 ~174 ~27 ~508 minecraft:redstone_wire replace
fill ~237 ~27 ~496 ~237 ~27 ~508 minecraft:redstone_wire replace
fill ~315 ~27 ~496 ~315 ~27 ~508 minecraft:redstone_wire replace
fill ~342 ~27 ~496 ~342 ~27 ~508 minecraft:redstone_wire replace
setblock ~345 ~27 ~496 minecraft:redstone_wire replace
setblock ~78 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~500 minecraft:redstone_wire replace
fill ~117 ~27 ~500 ~117 ~27 ~506 minecraft:redstone_wire replace
fill ~186 ~27 ~500 ~186 ~27 ~512 minecraft:redstone_wire replace
fill ~240 ~27 ~500 ~240 ~27 ~512 minecraft:redstone_wire replace
fill ~264 ~27 ~500 ~264 ~27 ~512 minecraft:redstone_wire replace
fill ~339 ~27 ~500 ~339 ~27 ~512 minecraft:redstone_wire replace
setblock ~93 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~504 ~93 ~27 ~516 minecraft:redstone_wire replace
fill ~96 ~27 ~504 ~96 ~27 ~516 minecraft:redstone_wire replace
setblock ~99 ~27 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~27 ~504 ~141 ~27 ~516 minecraft:redstone_wire replace
fill ~201 ~27 ~504 ~201 ~27 ~516 minecraft:redstone_wire replace
setblock ~270 ~27 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~504 ~291 ~27 ~516 minecraft:redstone_wire replace
fill ~336 ~27 ~504 ~336 ~27 ~516 minecraft:redstone_wire replace
fill ~357 ~27 ~504 ~357 ~27 ~516 minecraft:redstone_wire replace
setblock ~144 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~506 ~270 ~27 ~518 minecraft:redstone_wire replace
setblock ~354 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~508 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~508 ~144 ~27 ~512 minecraft:redstone_wire replace
fill ~162 ~27 ~508 ~162 ~27 ~520 minecraft:redstone_wire replace
fill ~204 ~27 ~508 ~204 ~27 ~518 minecraft:redstone_wire replace
fill ~354 ~27 ~508 ~354 ~27 ~520 minecraft:redstone_wire replace
setblock ~114 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~512 ~114 ~27 ~524 minecraft:redstone_wire replace
fill ~174 ~27 ~512 ~174 ~27 ~524 minecraft:redstone_wire replace
fill ~237 ~27 ~512 ~237 ~27 ~524 minecraft:redstone_wire replace
fill ~315 ~27 ~512 ~315 ~27 ~524 minecraft:redstone_wire replace
fill ~342 ~27 ~512 ~342 ~27 ~524 minecraft:redstone_wire replace
setblock ~186 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~516 minecraft:redstone_wire replace
fill ~240 ~27 ~516 ~240 ~27 ~522 minecraft:redstone_wire replace
fill ~264 ~27 ~516 ~264 ~27 ~526 minecraft:redstone_wire replace
fill ~339 ~27 ~516 ~339 ~27 ~528 minecraft:redstone_wire replace
setblock ~93 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~520 ~93 ~27 ~532 minecraft:redstone_wire replace
fill ~96 ~27 ~520 ~96 ~27 ~532 minecraft:redstone_wire replace
fill ~141 ~27 ~520 ~141 ~27 ~532 minecraft:redstone_wire replace
fill ~201 ~27 ~520 ~201 ~27 ~532 minecraft:redstone_wire replace
setblock ~204 ~27 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~520 ~291 ~27 ~532 minecraft:redstone_wire replace
fill ~336 ~27 ~520 ~336 ~27 ~532 minecraft:redstone_wire replace
fill ~357 ~27 ~520 ~357 ~27 ~532 minecraft:redstone_wire replace
setblock ~162 ~27 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~522 ~270 ~27 ~534 minecraft:redstone_wire replace
setblock ~354 ~27 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~524 ~162 ~27 ~536 minecraft:redstone_wire replace
setblock ~240 ~27 ~524 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~524 ~354 ~27 ~536 minecraft:redstone_wire replace
setblock ~114 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~528 ~114 ~27 ~540 minecraft:redstone_wire replace
fill ~174 ~27 ~528 ~174 ~27 ~540 minecraft:redstone_wire replace
fill ~237 ~27 ~528 ~237 ~27 ~540 minecraft:redstone_wire replace
setblock ~264 ~27 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~27 ~528 ~315 ~27 ~532 minecraft:redstone_wire replace
fill ~342 ~27 ~528 ~342 ~27 ~534 minecraft:redstone_wire replace
setblock ~339 ~27 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~532 ~339 ~27 ~544 minecraft:redstone_wire replace
setblock ~93 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~536 ~93 ~27 ~548 minecraft:redstone_wire replace
fill ~96 ~27 ~536 ~96 ~27 ~540 minecraft:redstone_wire replace
fill ~141 ~27 ~536 ~141 ~27 ~546 minecraft:redstone_wire replace
fill ~201 ~27 ~536 ~201 ~27 ~548 minecraft:redstone_wire replace
setblock ~270 ~27 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~536 ~291 ~27 ~548 minecraft:redstone_wire replace
fill ~336 ~27 ~536 ~336 ~27 ~548 minecraft:redstone_wire replace
setblock ~342 ~27 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~536 ~357 ~27 ~548 minecraft:redstone_wire replace
setblock ~162 ~27 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~538 ~270 ~27 ~550 minecraft:redstone_wire replace
setblock ~354 ~27 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~540 ~162 ~27 ~552 minecraft:redstone_wire replace
fill ~354 ~27 ~540 ~354 ~27 ~552 minecraft:redstone_wire replace
setblock ~114 ~27 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~544 minecraft:redstone_wire replace
fill ~174 ~27 ~544 ~174 ~27 ~550 minecraft:redstone_wire replace
fill ~237 ~27 ~544 ~237 ~27 ~556 minecraft:redstone_wire replace
setblock ~339 ~27 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~548 ~339 ~27 ~560 minecraft:redstone_wire replace
setblock ~93 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~552 ~93 ~27 ~564 minecraft:redstone_wire replace
setblock ~174 ~27 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~27 ~552 ~201 ~27 ~556 minecraft:redstone_wire replace
setblock ~270 ~27 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~552 ~291 ~27 ~564 minecraft:redstone_wire replace
fill ~336 ~27 ~552 ~336 ~27 ~564 minecraft:redstone_wire replace
fill ~357 ~27 ~552 ~357 ~27 ~564 minecraft:redstone_wire replace
setblock ~162 ~27 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~554 ~270 ~27 ~562 minecraft:redstone_wire replace
setblock ~354 ~27 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~556 ~162 ~27 ~568 minecraft:redstone_wire replace
fill ~354 ~27 ~556 ~354 ~27 ~568 minecraft:redstone_wire replace
setblock ~237 ~27 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~560 minecraft:redstone_wire replace
setblock ~339 ~27 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~564 ~339 ~27 ~576 minecraft:redstone_wire replace
setblock ~93 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~568 ~93 ~27 ~580 minecraft:redstone_wire replace
setblock ~291 ~27 ~568 minecraft:redstone_wire replace
fill ~336 ~27 ~568 ~336 ~27 ~572 minecraft:redstone_wire replace
fill ~357 ~27 ~568 ~357 ~27 ~578 minecraft:redstone_wire replace
setblock ~162 ~27 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~27 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~572 ~162 ~27 ~576 minecraft:redstone_wire replace
fill ~354 ~27 ~572 ~354 ~27 ~584 minecraft:redstone_wire replace
setblock ~339 ~27 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~580 ~339 ~27 ~586 minecraft:redstone_wire replace
setblock ~357 ~27 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~584 minecraft:redstone_wire replace
setblock ~354 ~27 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~27 ~588 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~588 ~354 ~27 ~592 minecraft:redstone_wire replace
setblock ~126 ~28 ~13 minecraft:redstone_wire replace
setblock ~153 ~28 ~21 minecraft:redstone_wire replace
setblock ~177 ~28 ~29 minecraft:redstone_wire replace
setblock ~207 ~28 ~37 minecraft:redstone_wire replace
setblock ~225 ~28 ~45 minecraft:redstone_wire replace
setblock ~249 ~28 ~53 minecraft:redstone_wire replace
setblock ~282 ~28 ~61 minecraft:redstone_wire replace
setblock ~300 ~28 ~65 minecraft:redstone_wire replace
setblock ~309 ~28 ~77 minecraft:redstone_wire replace
setblock ~327 ~28 ~81 minecraft:redstone_wire replace
setblock ~132 ~28 ~261 minecraft:redstone_wire replace
setblock ~135 ~28 ~265 minecraft:redstone_wire replace
setblock ~147 ~28 ~269 minecraft:redstone_wire replace
setblock ~156 ~28 ~273 minecraft:redstone_wire replace
setblock ~159 ~28 ~277 minecraft:redstone_wire replace
setblock ~180 ~28 ~281 minecraft:redstone_wire replace
setblock ~183 ~28 ~285 minecraft:redstone_wire replace
setblock ~210 ~28 ~289 minecraft:redstone_wire replace
setblock ~213 ~28 ~293 minecraft:redstone_wire replace
setblock ~228 ~28 ~297 minecraft:redstone_wire replace
setblock ~231 ~28 ~301 minecraft:redstone_wire replace
setblock ~252 ~28 ~305 minecraft:redstone_wire replace
setblock ~255 ~28 ~309 minecraft:redstone_wire replace
setblock ~285 ~28 ~313 minecraft:redstone_wire replace
setblock ~288 ~28 ~317 minecraft:redstone_wire replace
setblock ~294 ~28 ~321 minecraft:redstone_wire replace
setblock ~297 ~28 ~325 minecraft:redstone_wire replace
setblock ~303 ~28 ~329 minecraft:redstone_wire replace
setblock ~306 ~28 ~333 minecraft:redstone_wire replace
setblock ~321 ~28 ~337 minecraft:redstone_wire replace
setblock ~324 ~28 ~341 minecraft:redstone_wire replace
setblock ~90 ~28 ~345 minecraft:redstone_wire replace
setblock ~111 ~28 ~349 minecraft:redstone_wire replace
setblock ~138 ~28 ~353 minecraft:redstone_wire replace
setblock ~171 ~28 ~357 minecraft:redstone_wire replace
setblock ~198 ~28 ~361 minecraft:redstone_wire replace
setblock ~234 ~28 ~365 minecraft:redstone_wire replace
setblock ~261 ~28 ~369 minecraft:redstone_wire replace
setblock ~279 ~28 ~373 minecraft:redstone_wire replace
setblock ~312 ~28 ~377 minecraft:redstone_wire replace
setblock ~87 ~28 ~381 minecraft:redstone_wire replace
setblock ~108 ~28 ~385 minecraft:redstone_wire replace
setblock ~129 ~28 ~389 minecraft:redstone_wire replace
setblock ~168 ~28 ~393 minecraft:redstone_wire replace
setblock ~195 ~28 ~397 minecraft:redstone_wire replace
setblock ~222 ~28 ~401 minecraft:redstone_wire replace
setblock ~258 ~28 ~405 minecraft:redstone_wire replace
setblock ~276 ~28 ~409 minecraft:redstone_wire replace
setblock ~333 ~28 ~413 minecraft:redstone_wire replace
setblock ~351 ~28 ~417 minecraft:redstone_wire replace
setblock ~84 ~28 ~421 minecraft:redstone_wire replace
setblock ~105 ~28 ~425 minecraft:redstone_wire replace
setblock ~123 ~28 ~429 minecraft:redstone_wire replace
setblock ~165 ~28 ~433 minecraft:redstone_wire replace
setblock ~192 ~28 ~437 minecraft:redstone_wire replace
setblock ~219 ~28 ~441 minecraft:redstone_wire replace
setblock ~246 ~28 ~445 minecraft:redstone_wire replace
setblock ~273 ~28 ~449 minecraft:redstone_wire replace
setblock ~330 ~28 ~453 minecraft:redstone_wire replace
setblock ~348 ~28 ~457 minecraft:redstone_wire replace
setblock ~81 ~28 ~461 minecraft:redstone_wire replace
setblock ~102 ~28 ~465 minecraft:redstone_wire replace
setblock ~120 ~28 ~469 minecraft:redstone_wire replace
setblock ~150 ~28 ~473 minecraft:redstone_wire replace
setblock ~189 ~28 ~477 minecraft:redstone_wire replace
setblock ~216 ~28 ~481 minecraft:redstone_wire replace
setblock ~243 ~28 ~485 minecraft:redstone_wire replace
setblock ~267 ~28 ~489 minecraft:redstone_wire replace
setblock ~318 ~28 ~493 minecraft:redstone_wire replace
setblock ~345 ~28 ~497 minecraft:redstone_wire replace
setblock ~78 ~28 ~501 minecraft:redstone_wire replace
setblock ~99 ~28 ~505 minecraft:redstone_wire replace
setblock ~117 ~28 ~509 minecraft:redstone_wire replace
setblock ~144 ~28 ~513 minecraft:redstone_wire replace
setblock ~186 ~28 ~517 minecraft:redstone_wire replace
setblock ~204 ~28 ~521 minecraft:redstone_wire replace
setblock ~240 ~28 ~525 minecraft:redstone_wire replace
setblock ~264 ~28 ~529 minecraft:redstone_wire replace
setblock ~315 ~28 ~533 minecraft:redstone_wire replace
setblock ~342 ~28 ~537 minecraft:redstone_wire replace
setblock ~96 ~28 ~541 minecraft:redstone_wire replace
setblock ~114 ~28 ~545 minecraft:redstone_wire replace
setblock ~141 ~28 ~549 minecraft:redstone_wire replace
setblock ~174 ~28 ~553 minecraft:redstone_wire replace
setblock ~201 ~28 ~557 minecraft:redstone_wire replace
setblock ~237 ~28 ~561 minecraft:redstone_wire replace
setblock ~270 ~28 ~565 minecraft:redstone_wire replace
setblock ~291 ~28 ~569 minecraft:redstone_wire replace
setblock ~336 ~28 ~573 minecraft:redstone_wire replace
setblock ~162 ~28 ~577 minecraft:redstone_wire replace
setblock ~357 ~28 ~581 minecraft:redstone_wire replace
setblock ~93 ~28 ~585 minecraft:redstone_wire replace
setblock ~339 ~28 ~589 minecraft:redstone_wire replace
setblock ~354 ~28 ~593 minecraft:redstone_wire replace
fill ~126 ~29 ~14 ~128 ~29 ~14 minecraft:redstone_wire replace
setblock ~127 ~29 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~29 ~22 ~153 ~29 ~22 minecraft:redstone_wire replace
setblock ~151 ~29 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~29 ~30 ~177 ~29 ~30 minecraft:redstone_wire replace
setblock ~172 ~29 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~29 ~38 ~199 ~29 ~38 minecraft:redstone_wire replace
setblock ~200 ~29 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~29 ~38 ~207 ~29 ~38 minecraft:redstone_wire replace
setblock ~199 ~29 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~29 ~46 ~215 ~29 ~46 minecraft:redstone_wire replace
setblock ~217 ~29 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~29 ~46 ~225 ~29 ~46 minecraft:redstone_wire replace
setblock ~214 ~29 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~29 ~54 ~239 ~29 ~54 minecraft:redstone_wire replace
setblock ~241 ~29 ~54 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~29 ~54 ~249 ~29 ~54 minecraft:redstone_wire replace
setblock ~235 ~29 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~29 ~62 ~272 ~29 ~62 minecraft:redstone_wire replace
setblock ~274 ~29 ~62 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~29 ~62 ~282 ~29 ~62 minecraft:redstone_wire replace
setblock ~265 ~29 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~29 ~66 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~29 ~66 ~290 ~29 ~66 minecraft:redstone_wire replace
setblock ~292 ~29 ~66 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~29 ~66 ~300 ~29 ~66 minecraft:redstone_wire replace
setblock ~277 ~29 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~29 ~78 ~284 ~29 ~78 minecraft:redstone_wire replace
setblock ~285 ~29 ~78 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~29 ~78 ~299 ~29 ~78 minecraft:redstone_wire replace
setblock ~301 ~29 ~78 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~29 ~78 ~309 ~29 ~78 minecraft:redstone_wire replace
setblock ~283 ~29 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~29 ~82 ~300 ~29 ~82 minecraft:redstone_wire replace
setblock ~302 ~29 ~82 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~29 ~82 ~317 ~29 ~82 minecraft:redstone_wire replace
setblock ~319 ~29 ~82 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~29 ~82 ~327 ~29 ~82 minecraft:redstone_wire replace
setblock ~298 ~29 ~83 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~29 ~262 ~134 ~29 ~262 minecraft:redstone_wire replace
setblock ~133 ~29 ~263 minecraft:redstone_wire replace
fill ~132 ~29 ~266 ~135 ~29 ~266 minecraft:redstone_wire replace
setblock ~133 ~29 ~267 minecraft:redstone_wire replace
fill ~144 ~29 ~270 ~147 ~29 ~270 minecraft:redstone_wire replace
setblock ~145 ~29 ~271 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~29 ~274 ~156 ~29 ~274 minecraft:redstone_wire replace
setblock ~154 ~29 ~275 minecraft:redstone_wire replace
fill ~153 ~29 ~278 ~159 ~29 ~278 minecraft:redstone_wire replace
setblock ~154 ~29 ~279 minecraft:redstone_wire replace
fill ~174 ~29 ~282 ~180 ~29 ~282 minecraft:redstone_wire replace
setblock ~175 ~29 ~283 minecraft:redstone_wire replace
fill ~174 ~29 ~286 ~183 ~29 ~286 minecraft:redstone_wire replace
setblock ~175 ~29 ~287 minecraft:redstone_wire replace
fill ~201 ~29 ~290 ~202 ~29 ~290 minecraft:redstone_wire replace
setblock ~203 ~29 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~29 ~290 ~210 ~29 ~290 minecraft:redstone_wire replace
setblock ~202 ~29 ~291 minecraft:redstone_wire replace
fill ~201 ~29 ~294 ~213 ~29 ~294 minecraft:redstone_wire replace
setblock ~202 ~29 ~295 minecraft:redstone_wire replace
fill ~216 ~29 ~298 ~228 ~29 ~298 minecraft:redstone_wire replace
setblock ~217 ~29 ~299 minecraft:redstone_wire replace
fill ~216 ~29 ~302 ~218 ~29 ~302 minecraft:redstone_wire replace
setblock ~219 ~29 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~29 ~302 ~231 ~29 ~302 minecraft:redstone_wire replace
setblock ~217 ~29 ~303 minecraft:redstone_wire replace
fill ~237 ~29 ~306 ~241 ~29 ~306 minecraft:redstone_wire replace
setblock ~243 ~29 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~29 ~306 ~252 ~29 ~306 minecraft:redstone_wire replace
setblock ~238 ~29 ~307 minecraft:redstone_wire replace
fill ~237 ~29 ~310 ~239 ~29 ~310 minecraft:redstone_wire replace
setblock ~241 ~29 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~29 ~310 ~255 ~29 ~310 minecraft:redstone_wire replace
setblock ~238 ~29 ~311 minecraft:redstone_wire replace
fill ~267 ~29 ~314 ~269 ~29 ~314 minecraft:redstone_wire replace
setblock ~271 ~29 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~29 ~314 ~285 ~29 ~314 minecraft:redstone_wire replace
setblock ~268 ~29 ~315 minecraft:redstone_wire replace
fill ~267 ~29 ~318 ~273 ~29 ~318 minecraft:redstone_wire replace
setblock ~275 ~29 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~29 ~318 ~288 ~29 ~318 minecraft:redstone_wire replace
setblock ~268 ~29 ~319 minecraft:redstone_wire replace
fill ~273 ~29 ~322 ~279 ~29 ~322 minecraft:redstone_wire replace
setblock ~281 ~29 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~29 ~322 ~294 ~29 ~322 minecraft:redstone_wire replace
setblock ~274 ~29 ~323 minecraft:redstone_wire replace
fill ~273 ~29 ~326 ~286 ~29 ~326 minecraft:redstone_wire replace
setblock ~288 ~29 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~29 ~326 ~297 ~29 ~326 minecraft:redstone_wire replace
setblock ~274 ~29 ~327 minecraft:redstone_wire replace
fill ~279 ~29 ~330 ~287 ~29 ~330 minecraft:redstone_wire replace
setblock ~289 ~29 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~29 ~330 ~303 ~29 ~330 minecraft:redstone_wire replace
setblock ~280 ~29 ~331 minecraft:redstone_wire replace
fill ~279 ~29 ~334 ~291 ~29 ~334 minecraft:redstone_wire replace
setblock ~293 ~29 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~29 ~334 ~306 ~29 ~334 minecraft:redstone_wire replace
setblock ~280 ~29 ~335 minecraft:redstone_wire replace
fill ~294 ~29 ~338 ~306 ~29 ~338 minecraft:redstone_wire replace
setblock ~308 ~29 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~29 ~338 ~321 ~29 ~338 minecraft:redstone_wire replace
setblock ~295 ~29 ~339 minecraft:redstone_wire replace
fill ~294 ~29 ~342 ~296 ~29 ~342 minecraft:redstone_wire replace
setblock ~298 ~29 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~29 ~342 ~313 ~29 ~342 minecraft:redstone_wire replace
setblock ~315 ~29 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~29 ~342 ~324 ~29 ~342 minecraft:redstone_wire replace
setblock ~295 ~29 ~343 minecraft:redstone_wire replace
fill ~90 ~29 ~346 ~92 ~29 ~346 minecraft:redstone_wire replace
setblock ~91 ~29 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~29 ~350 ~113 ~29 ~350 minecraft:redstone_wire replace
setblock ~112 ~29 ~351 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~29 ~354 ~138 ~29 ~354 minecraft:redstone_wire replace
setblock ~136 ~29 ~355 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~29 ~358 ~171 ~29 ~358 minecraft:redstone_wire replace
setblock ~166 ~29 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~29 ~362 ~198 ~29 ~362 minecraft:redstone_wire replace
setblock ~190 ~29 ~363 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~29 ~366 ~225 ~29 ~366 minecraft:redstone_wire replace
setblock ~227 ~29 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~29 ~366 ~234 ~29 ~366 minecraft:redstone_wire replace
setblock ~220 ~29 ~367 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~243 ~29 ~370 ~250 ~29 ~370 minecraft:redstone_wire replace
setblock ~252 ~29 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~29 ~370 ~261 ~29 ~370 minecraft:redstone_wire replace
setblock ~244 ~29 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~29 ~374 ~263 ~29 ~374 minecraft:redstone_wire replace
setblock ~265 ~29 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~29 ~374 ~279 ~29 ~374 minecraft:redstone_wire replace
setblock ~262 ~29 ~375 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~29 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~29 ~378 ~299 ~29 ~378 minecraft:redstone_wire replace
setblock ~301 ~29 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~29 ~378 ~312 ~29 ~378 minecraft:redstone_wire replace
setblock ~286 ~29 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~29 ~382 ~89 ~29 ~382 minecraft:redstone_wire replace
setblock ~88 ~29 ~383 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~29 ~386 ~110 ~29 ~386 minecraft:redstone_wire replace
setblock ~109 ~29 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~29 ~390 ~131 ~29 ~390 minecraft:redstone_wire replace
setblock ~130 ~29 ~391 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~29 ~394 ~168 ~29 ~394 minecraft:redstone_wire replace
setblock ~163 ~29 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~29 ~398 ~187 ~29 ~398 minecraft:redstone_wire replace
setblock ~188 ~29 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~29 ~398 ~195 ~29 ~398 minecraft:redstone_wire replace
setblock ~187 ~29 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~29 ~402 ~222 ~29 ~402 minecraft:redstone_wire replace
setblock ~211 ~29 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~29 ~406 ~242 ~29 ~406 minecraft:redstone_wire replace
setblock ~244 ~29 ~406 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~29 ~406 ~258 ~29 ~406 minecraft:redstone_wire replace
setblock ~241 ~29 ~407 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~29 ~410 ~261 ~29 ~410 minecraft:redstone_wire replace
setblock ~263 ~29 ~410 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~29 ~410 ~276 ~29 ~410 minecraft:redstone_wire replace
setblock ~259 ~29 ~411 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~29 ~414 ~305 ~29 ~414 minecraft:redstone_wire replace
setblock ~306 ~29 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~29 ~414 ~320 ~29 ~414 minecraft:redstone_wire replace
setblock ~322 ~29 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~29 ~414 ~333 ~29 ~414 minecraft:redstone_wire replace
setblock ~304 ~29 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~29 ~418 ~325 ~29 ~418 minecraft:redstone_wire replace
setblock ~327 ~29 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~29 ~418 ~342 ~29 ~418 minecraft:redstone_wire replace
setblock ~344 ~29 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~29 ~418 ~351 ~29 ~418 minecraft:redstone_wire replace
setblock ~322 ~29 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~29 ~422 ~86 ~29 ~422 minecraft:redstone_wire replace
setblock ~85 ~29 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~29 ~426 ~107 ~29 ~426 minecraft:redstone_wire replace
setblock ~106 ~29 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~29 ~430 ~125 ~29 ~430 minecraft:redstone_wire replace
setblock ~124 ~29 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~29 ~434 ~165 ~29 ~434 minecraft:redstone_wire replace
setblock ~160 ~29 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~29 ~438 ~192 ~29 ~438 minecraft:redstone_wire replace
setblock ~184 ~29 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~29 ~442 ~208 ~29 ~442 minecraft:redstone_wire replace
setblock ~210 ~29 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~29 ~442 ~219 ~29 ~442 minecraft:redstone_wire replace
setblock ~208 ~29 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~29 ~446 ~232 ~29 ~446 minecraft:redstone_wire replace
setblock ~233 ~29 ~446 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~29 ~446 ~246 ~29 ~446 minecraft:redstone_wire replace
setblock ~232 ~29 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~29 ~450 ~257 ~29 ~450 minecraft:redstone_wire replace
setblock ~259 ~29 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~29 ~450 ~273 ~29 ~450 minecraft:redstone_wire replace
setblock ~256 ~29 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~29 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~29 ~454 ~314 ~29 ~454 minecraft:redstone_wire replace
setblock ~316 ~29 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~29 ~454 ~330 ~29 ~454 minecraft:redstone_wire replace
setblock ~301 ~29 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~29 ~458 ~320 ~29 ~458 minecraft:redstone_wire replace
setblock ~321 ~29 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~29 ~458 ~334 ~29 ~458 minecraft:redstone_wire replace
setblock ~336 ~29 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~338 ~29 ~458 ~348 ~29 ~458 minecraft:redstone_wire replace
setblock ~319 ~29 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~29 ~462 ~83 ~29 ~462 minecraft:redstone_wire replace
setblock ~82 ~29 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~29 ~466 ~104 ~29 ~466 minecraft:redstone_wire replace
setblock ~103 ~29 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~29 ~470 ~122 ~29 ~470 minecraft:redstone_wire replace
setblock ~121 ~29 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~29 ~474 ~150 ~29 ~474 minecraft:redstone_wire replace
setblock ~148 ~29 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~29 ~478 ~189 ~29 ~478 minecraft:redstone_wire replace
setblock ~181 ~29 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~29 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~29 ~482 ~216 ~29 ~482 minecraft:redstone_wire replace
setblock ~205 ~29 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~29 ~486 ~232 ~29 ~486 minecraft:redstone_wire replace
setblock ~234 ~29 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~29 ~486 ~243 ~29 ~486 minecraft:redstone_wire replace
setblock ~229 ~29 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~29 ~490 ~251 ~29 ~490 minecraft:redstone_wire replace
setblock ~253 ~29 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~29 ~490 ~267 ~29 ~490 minecraft:redstone_wire replace
setblock ~250 ~29 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~29 ~494 ~302 ~29 ~494 minecraft:redstone_wire replace
setblock ~304 ~29 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
