fill ~96 ~90 ~612 ~96 ~90 ~616 minecraft:light_gray_concrete replace
fill ~99 ~90 ~616 ~99 ~90 ~620 minecraft:light_gray_concrete replace
fill ~102 ~90 ~620 ~102 ~90 ~624 minecraft:light_gray_concrete replace
fill ~108 ~90 ~624 ~108 ~90 ~628 minecraft:light_gray_concrete replace
fill ~105 ~90 ~632 ~105 ~90 ~636 minecraft:light_gray_concrete replace
fill ~123 ~90 ~640 ~123 ~90 ~644 minecraft:light_gray_concrete replace
fill ~84 ~90 ~644 ~84 ~90 ~648 minecraft:light_gray_concrete replace
fill ~117 ~90 ~648 ~117 ~90 ~652 minecraft:light_gray_concrete replace
fill ~111 ~90 ~652 ~111 ~90 ~656 minecraft:light_gray_concrete replace
fill ~120 ~90 ~656 ~120 ~90 ~660 minecraft:light_gray_concrete replace
setblock ~114 ~91 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~91 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~91 ~601 minecraft:light_gray_concrete replace
setblock ~78 ~91 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~91 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~91 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~91 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~91 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~91 ~625 minecraft:light_gray_concrete replace
setblock ~108 ~91 ~629 minecraft:light_gray_concrete replace
setblock ~105 ~91 ~637 minecraft:light_gray_concrete replace
setblock ~123 ~91 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~91 ~649 minecraft:light_gray_concrete replace
setblock ~112 ~91 ~652 minecraft:light_gray_concrete replace
setblock ~117 ~91 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~91 ~657 minecraft:light_gray_concrete replace
setblock ~120 ~91 ~661 minecraft:light_gray_concrete replace
fill ~114 ~92 ~386 ~122 ~92 ~386 minecraft:light_gray_concrete replace
fill ~121 ~92 ~387 ~121 ~92 ~388 minecraft:light_gray_concrete replace
fill ~81 ~92 ~398 ~83 ~92 ~398 minecraft:light_gray_concrete replace
fill ~82 ~92 ~399 ~82 ~92 ~400 minecraft:light_gray_concrete replace
fill ~87 ~92 ~602 ~89 ~92 ~602 minecraft:light_gray_concrete replace
fill ~88 ~92 ~603 ~88 ~92 ~604 minecraft:light_gray_concrete replace
fill ~78 ~92 ~606 ~80 ~92 ~606 minecraft:light_gray_concrete replace
fill ~79 ~92 ~607 ~79 ~92 ~608 minecraft:light_gray_concrete replace
fill ~90 ~92 ~610 ~92 ~92 ~610 minecraft:light_gray_concrete replace
fill ~91 ~92 ~611 ~91 ~92 ~612 minecraft:light_gray_concrete replace
fill ~93 ~92 ~614 ~95 ~92 ~614 minecraft:light_gray_concrete replace
fill ~94 ~92 ~615 ~94 ~92 ~616 minecraft:light_gray_concrete replace
fill ~96 ~92 ~618 ~98 ~92 ~618 minecraft:light_gray_concrete replace
fill ~97 ~92 ~619 ~97 ~92 ~620 minecraft:light_gray_concrete replace
fill ~99 ~92 ~622 ~101 ~92 ~622 minecraft:light_gray_concrete replace
fill ~100 ~92 ~623 ~100 ~92 ~624 minecraft:light_gray_concrete replace
fill ~102 ~92 ~626 ~104 ~92 ~626 minecraft:light_gray_concrete replace
fill ~103 ~92 ~627 ~103 ~92 ~628 minecraft:light_gray_concrete replace
fill ~105 ~92 ~630 ~125 ~92 ~630 minecraft:light_gray_concrete replace
fill ~106 ~92 ~631 ~106 ~92 ~632 minecraft:light_gray_concrete replace
fill ~112 ~92 ~631 ~112 ~92 ~632 minecraft:light_gray_concrete replace
fill ~115 ~92 ~631 ~115 ~92 ~632 minecraft:light_gray_concrete replace
fill ~118 ~92 ~631 ~118 ~92 ~632 minecraft:light_gray_concrete replace
fill ~124 ~92 ~631 ~124 ~92 ~632 minecraft:light_gray_concrete replace
fill ~105 ~92 ~638 ~128 ~92 ~638 minecraft:light_gray_concrete replace
fill ~106 ~92 ~639 ~106 ~92 ~640 minecraft:light_gray_concrete replace
fill ~109 ~92 ~639 ~109 ~92 ~640 minecraft:light_gray_concrete replace
fill ~112 ~92 ~639 ~112 ~92 ~640 minecraft:light_gray_concrete replace
fill ~115 ~92 ~639 ~115 ~92 ~640 minecraft:light_gray_concrete replace
fill ~127 ~92 ~639 ~127 ~92 ~640 minecraft:light_gray_concrete replace
fill ~123 ~92 ~646 ~137 ~92 ~646 minecraft:light_gray_concrete replace
fill ~136 ~92 ~647 ~136 ~92 ~648 minecraft:light_gray_concrete replace
fill ~84 ~92 ~650 ~86 ~92 ~650 minecraft:light_gray_concrete replace
fill ~85 ~92 ~651 ~85 ~92 ~652 minecraft:light_gray_concrete replace
fill ~117 ~92 ~654 ~131 ~92 ~654 minecraft:light_gray_concrete replace
fill ~130 ~92 ~655 ~130 ~92 ~656 minecraft:light_gray_concrete replace
fill ~105 ~92 ~658 ~128 ~92 ~658 minecraft:light_gray_concrete replace
fill ~106 ~92 ~659 ~106 ~92 ~660 minecraft:light_gray_concrete replace
fill ~109 ~92 ~659 ~109 ~92 ~660 minecraft:light_gray_concrete replace
fill ~112 ~92 ~659 ~112 ~92 ~660 minecraft:light_gray_concrete replace
fill ~115 ~92 ~659 ~115 ~92 ~660 minecraft:light_gray_concrete replace
fill ~118 ~92 ~659 ~118 ~92 ~660 minecraft:light_gray_concrete replace
fill ~124 ~92 ~659 ~124 ~92 ~660 minecraft:light_gray_concrete replace
fill ~127 ~92 ~659 ~127 ~92 ~660 minecraft:light_gray_concrete replace
fill ~120 ~92 ~662 ~134 ~92 ~662 minecraft:light_gray_concrete replace
fill ~133 ~92 ~663 ~133 ~92 ~664 minecraft:light_gray_concrete replace
setblock ~121 ~93 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~93 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~93 ~604 minecraft:light_gray_concrete replace
setblock ~79 ~93 ~608 minecraft:light_gray_concrete replace
setblock ~91 ~93 ~612 minecraft:light_gray_concrete replace
setblock ~94 ~93 ~616 minecraft:light_gray_concrete replace
setblock ~97 ~93 ~620 minecraft:light_gray_concrete replace
setblock ~100 ~93 ~624 minecraft:light_gray_concrete replace
setblock ~103 ~93 ~628 minecraft:light_gray_concrete replace
setblock ~106 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~112 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~115 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~118 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~106 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~109 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~112 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~115 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~127 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~130 ~93 ~646 minecraft:light_gray_concrete replace
setblock ~132 ~93 ~646 minecraft:light_gray_concrete replace
setblock ~136 ~93 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~93 ~652 minecraft:light_gray_concrete replace
setblock ~124 ~93 ~654 minecraft:light_gray_concrete replace
setblock ~126 ~93 ~654 minecraft:light_gray_concrete replace
setblock ~130 ~93 ~656 minecraft:light_gray_concrete replace
setblock ~106 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~109 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~112 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~115 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~118 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~124 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~127 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~127 ~93 ~662 minecraft:light_gray_concrete replace
setblock ~129 ~93 ~662 minecraft:light_gray_concrete replace
setblock ~133 ~93 ~664 minecraft:light_gray_concrete replace
fill ~120 ~94 ~384 ~120 ~94 ~388 minecraft:light_gray_concrete replace
fill ~81 ~94 ~396 ~81 ~94 ~400 minecraft:light_gray_concrete replace
fill ~87 ~94 ~584 ~87 ~94 ~604 minecraft:light_gray_concrete replace
fill ~78 ~94 ~588 ~78 ~94 ~608 minecraft:light_gray_concrete replace
fill ~90 ~94 ~592 ~90 ~94 ~612 minecraft:light_gray_concrete replace
fill ~93 ~94 ~596 ~93 ~94 ~616 minecraft:light_gray_concrete replace
fill ~96 ~94 ~600 ~96 ~94 ~620 minecraft:light_gray_concrete replace
fill ~99 ~94 ~604 ~99 ~94 ~624 minecraft:light_gray_concrete replace
fill ~102 ~94 ~608 ~102 ~94 ~628 minecraft:light_gray_concrete replace
fill ~123 ~94 ~612 ~123 ~94 ~660 minecraft:light_gray_concrete replace
fill ~117 ~94 ~616 ~117 ~94 ~660 minecraft:light_gray_concrete replace
fill ~114 ~94 ~620 ~114 ~94 ~660 minecraft:light_gray_concrete replace
fill ~111 ~94 ~624 ~111 ~94 ~660 minecraft:light_gray_concrete replace
fill ~105 ~94 ~628 ~105 ~94 ~660 minecraft:light_gray_concrete replace
fill ~126 ~94 ~632 ~126 ~94 ~660 minecraft:light_gray_concrete replace
fill ~108 ~94 ~636 ~108 ~94 ~660 minecraft:light_gray_concrete replace
fill ~135 ~94 ~644 ~135 ~94 ~648 minecraft:light_gray_concrete replace
fill ~84 ~94 ~648 ~84 ~94 ~652 minecraft:light_gray_concrete replace
fill ~129 ~94 ~652 ~129 ~94 ~656 minecraft:light_gray_concrete replace
fill ~132 ~94 ~660 ~132 ~94 ~664 minecraft:light_gray_concrete replace
setblock ~120 ~95 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~95 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~95 ~583 minecraft:light_gray_concrete replace
setblock ~78 ~95 ~587 minecraft:light_gray_concrete replace
setblock ~87 ~95 ~589 minecraft:light_gray_concrete replace
setblock ~87 ~95 ~591 minecraft:light_gray_concrete replace
setblock ~90 ~95 ~591 minecraft:light_gray_concrete replace
setblock ~78 ~95 ~593 minecraft:light_gray_concrete replace
setblock ~78 ~95 ~595 minecraft:light_gray_concrete replace
setblock ~93 ~95 ~595 minecraft:light_gray_concrete replace
setblock ~90 ~95 ~597 minecraft:light_gray_concrete replace
setblock ~90 ~95 ~599 minecraft:light_gray_concrete replace
setblock ~96 ~95 ~599 minecraft:light_gray_concrete replace
setblock ~93 ~95 ~601 minecraft:light_gray_concrete replace
setblock ~93 ~95 ~603 minecraft:light_gray_concrete replace
setblock ~99 ~95 ~603 minecraft:light_gray_concrete replace
setblock ~96 ~95 ~605 minecraft:light_gray_concrete replace
setblock ~96 ~95 ~607 minecraft:light_gray_concrete replace
setblock ~102 ~95 ~607 minecraft:light_gray_concrete replace
setblock ~99 ~95 ~609 minecraft:light_gray_concrete replace
setblock ~99 ~95 ~611 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~611 minecraft:light_gray_concrete replace
setblock ~102 ~95 ~613 minecraft:light_gray_concrete replace
setblock ~102 ~95 ~615 minecraft:light_gray_concrete replace
setblock ~117 ~95 ~615 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~615 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~617 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~619 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~621 minecraft:light_gray_concrete replace
setblock ~111 ~95 ~623 minecraft:light_gray_concrete replace
setblock ~105 ~95 ~627 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~631 minecraft:light_gray_concrete replace
setblock ~106 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~115 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~118 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~633 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~635 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~637 minecraft:light_gray_concrete replace
setblock ~109 ~95 ~640 minecraft:light_gray_concrete replace
setblock ~115 ~95 ~640 minecraft:light_gray_concrete replace
setblock ~127 ~95 ~640 minecraft:light_gray_concrete replace
setblock ~135 ~95 ~643 minecraft:light_gray_concrete replace
setblock ~105 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~111 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~117 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~105 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~111 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~117 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~129 ~95 ~651 minecraft:light_gray_concrete replace
setblock ~132 ~95 ~659 minecraft:light_gray_concrete replace
setblock ~106 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~112 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~115 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~124 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~127 ~95 ~660 minecraft:light_gray_concrete replace
fill ~115 ~96 ~380 ~115 ~96 ~381 minecraft:light_gray_concrete replace
fill ~114 ~96 ~382 ~120 ~96 ~382 minecraft:light_gray_concrete replace
fill ~82 ~96 ~392 ~82 ~96 ~393 minecraft:light_gray_concrete replace
fill ~81 ~96 ~394 ~83 ~96 ~394 minecraft:light_gray_concrete replace
fill ~88 ~96 ~580 ~88 ~96 ~581 minecraft:light_gray_concrete replace
fill ~87 ~96 ~582 ~89 ~96 ~582 minecraft:light_gray_concrete replace
fill ~79 ~96 ~584 ~79 ~96 ~585 minecraft:light_gray_concrete replace
fill ~78 ~96 ~586 ~80 ~96 ~586 minecraft:light_gray_concrete replace
fill ~91 ~96 ~588 ~91 ~96 ~589 minecraft:light_gray_concrete replace
fill ~90 ~96 ~590 ~92 ~96 ~590 minecraft:light_gray_concrete replace
fill ~94 ~96 ~592 ~94 ~96 ~593 minecraft:light_gray_concrete replace
fill ~93 ~96 ~594 ~95 ~96 ~594 minecraft:light_gray_concrete replace
fill ~97 ~96 ~596 ~97 ~96 ~597 minecraft:light_gray_concrete replace
fill ~96 ~96 ~598 ~98 ~96 ~598 minecraft:light_gray_concrete replace
fill ~100 ~96 ~600 ~100 ~96 ~601 minecraft:light_gray_concrete replace
fill ~99 ~96 ~602 ~101 ~96 ~602 minecraft:light_gray_concrete replace
fill ~103 ~96 ~604 ~103 ~96 ~605 minecraft:light_gray_concrete replace
fill ~102 ~96 ~606 ~104 ~96 ~606 minecraft:light_gray_concrete replace
fill ~118 ~96 ~608 ~118 ~96 ~609 minecraft:light_gray_concrete replace
fill ~117 ~96 ~610 ~123 ~96 ~610 minecraft:light_gray_concrete replace
fill ~112 ~96 ~612 ~112 ~96 ~613 minecraft:light_gray_concrete replace
fill ~111 ~96 ~614 ~117 ~96 ~614 minecraft:light_gray_concrete replace
fill ~112 ~96 ~616 ~112 ~96 ~617 minecraft:light_gray_concrete replace
fill ~111 ~96 ~618 ~114 ~96 ~618 minecraft:light_gray_concrete replace
fill ~109 ~96 ~620 ~109 ~96 ~621 minecraft:light_gray_concrete replace
fill ~108 ~96 ~622 ~111 ~96 ~622 minecraft:light_gray_concrete replace
fill ~106 ~96 ~624 ~106 ~96 ~625 minecraft:light_gray_concrete replace
fill ~105 ~96 ~626 ~107 ~96 ~626 minecraft:light_gray_concrete replace
fill ~118 ~96 ~628 ~118 ~96 ~629 minecraft:light_gray_concrete replace
fill ~117 ~96 ~630 ~126 ~96 ~630 minecraft:light_gray_concrete replace
fill ~106 ~96 ~632 ~106 ~96 ~633 minecraft:light_gray_concrete replace
fill ~105 ~96 ~634 ~108 ~96 ~634 minecraft:light_gray_concrete replace
fill ~127 ~96 ~640 ~127 ~96 ~641 minecraft:light_gray_concrete replace
fill ~126 ~96 ~642 ~135 ~96 ~642 minecraft:light_gray_concrete replace
fill ~85 ~96 ~644 ~85 ~96 ~645 minecraft:light_gray_concrete replace
fill ~84 ~96 ~646 ~86 ~96 ~646 minecraft:light_gray_concrete replace
fill ~121 ~96 ~648 ~121 ~96 ~649 minecraft:light_gray_concrete replace
fill ~120 ~96 ~650 ~129 ~96 ~650 minecraft:light_gray_concrete replace
fill ~124 ~96 ~656 ~124 ~96 ~657 minecraft:light_gray_concrete replace
fill ~123 ~96 ~658 ~132 ~96 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~97 ~380 minecraft:light_gray_concrete replace
setblock ~82 ~97 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~97 ~580 minecraft:light_gray_concrete replace
setblock ~79 ~97 ~584 minecraft:light_gray_concrete replace
setblock ~91 ~97 ~588 minecraft:light_gray_concrete replace
setblock ~94 ~97 ~592 minecraft:light_gray_concrete replace
setblock ~97 ~97 ~596 minecraft:light_gray_concrete replace
setblock ~100 ~97 ~600 minecraft:light_gray_concrete replace
setblock ~103 ~97 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~97 ~608 minecraft:light_gray_concrete replace
setblock ~112 ~97 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~97 ~616 minecraft:light_gray_concrete replace
setblock ~109 ~97 ~620 minecraft:light_gray_concrete replace
setblock ~106 ~97 ~624 minecraft:light_gray_concrete replace
setblock ~118 ~97 ~628 minecraft:light_gray_concrete replace
setblock ~106 ~97 ~632 minecraft:light_gray_concrete replace
setblock ~127 ~97 ~640 minecraft:light_gray_concrete replace
setblock ~85 ~97 ~644 minecraft:light_gray_concrete replace
setblock ~121 ~97 ~648 minecraft:light_gray_concrete replace
setblock ~124 ~97 ~656 minecraft:light_gray_concrete replace
fill ~114 ~98 ~380 ~114 ~98 ~384 minecraft:light_gray_concrete replace
fill ~81 ~98 ~392 ~81 ~98 ~396 minecraft:light_gray_concrete replace
fill ~87 ~98 ~580 ~87 ~98 ~584 minecraft:light_gray_concrete replace
fill ~78 ~98 ~584 ~78 ~98 ~588 minecraft:light_gray_concrete replace
fill ~90 ~98 ~588 ~90 ~98 ~592 minecraft:light_gray_concrete replace
fill ~93 ~98 ~592 ~93 ~98 ~596 minecraft:light_gray_concrete replace
fill ~96 ~98 ~596 ~96 ~98 ~600 minecraft:light_gray_concrete replace
fill ~99 ~98 ~600 ~99 ~98 ~604 minecraft:light_gray_concrete replace
fill ~102 ~98 ~604 ~102 ~98 ~608 minecraft:light_gray_concrete replace
fill ~117 ~98 ~608 ~117 ~98 ~632 minecraft:light_gray_concrete replace
fill ~111 ~98 ~612 ~111 ~98 ~620 minecraft:light_gray_concrete replace
fill ~108 ~98 ~620 ~108 ~98 ~624 minecraft:light_gray_concrete replace
fill ~105 ~98 ~624 ~105 ~98 ~636 minecraft:light_gray_concrete replace
fill ~126 ~98 ~640 ~126 ~98 ~644 minecraft:light_gray_concrete replace
fill ~84 ~98 ~644 ~84 ~98 ~648 minecraft:light_gray_concrete replace
fill ~120 ~98 ~648 ~120 ~98 ~652 minecraft:light_gray_concrete replace
fill ~123 ~98 ~656 ~123 ~98 ~660 minecraft:light_gray_concrete replace
setblock ~114 ~99 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~99 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~99 ~585 minecraft:light_gray_concrete replace
setblock ~78 ~99 ~589 minecraft:light_gray_concrete replace
setblock ~90 ~99 ~593 minecraft:light_gray_concrete replace
setblock ~93 ~99 ~597 minecraft:light_gray_concrete replace
setblock ~96 ~99 ~601 minecraft:light_gray_concrete replace
setblock ~99 ~99 ~605 minecraft:light_gray_concrete replace
setblock ~118 ~99 ~608 minecraft:light_gray_concrete replace
setblock ~102 ~99 ~609 minecraft:light_gray_concrete replace
setblock ~112 ~99 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~99 ~616 minecraft:light_gray_concrete replace
setblock ~111 ~99 ~619 minecraft:light_gray_concrete replace
setblock ~109 ~99 ~620 minecraft:light_gray_concrete replace
setblock ~111 ~99 ~621 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~621 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~623 minecraft:light_gray_concrete replace
setblock ~106 ~99 ~624 minecraft:light_gray_concrete replace
setblock ~108 ~99 ~625 minecraft:light_gray_concrete replace
setblock ~118 ~99 ~628 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~631 minecraft:light_gray_concrete replace
setblock ~106 ~99 ~632 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~633 minecraft:light_gray_concrete replace
setblock ~105 ~99 ~635 minecraft:light_gray_concrete replace
setblock ~105 ~99 ~637 minecraft:light_gray_concrete replace
setblock ~126 ~99 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~99 ~649 minecraft:light_gray_concrete replace
setblock ~120 ~99 ~653 minecraft:light_gray_concrete replace
setblock ~123 ~99 ~661 minecraft:light_gray_concrete replace
fill ~114 ~100 ~386 ~128 ~100 ~386 minecraft:light_gray_concrete replace
fill ~127 ~100 ~387 ~127 ~100 ~388 minecraft:light_gray_concrete replace
fill ~81 ~100 ~398 ~83 ~100 ~398 minecraft:light_gray_concrete replace
fill ~82 ~100 ~399 ~82 ~100 ~400 minecraft:light_gray_concrete replace
fill ~87 ~100 ~586 ~89 ~100 ~586 minecraft:light_gray_concrete replace
fill ~88 ~100 ~587 ~88 ~100 ~588 minecraft:light_gray_concrete replace
fill ~78 ~100 ~590 ~80 ~100 ~590 minecraft:light_gray_concrete replace
fill ~79 ~100 ~591 ~79 ~100 ~592 minecraft:light_gray_concrete replace
fill ~90 ~100 ~594 ~92 ~100 ~594 minecraft:light_gray_concrete replace
fill ~91 ~100 ~595 ~91 ~100 ~596 minecraft:light_gray_concrete replace
fill ~93 ~100 ~598 ~95 ~100 ~598 minecraft:light_gray_concrete replace
fill ~94 ~100 ~599 ~94 ~100 ~600 minecraft:light_gray_concrete replace
fill ~96 ~100 ~602 ~98 ~100 ~602 minecraft:light_gray_concrete replace
fill ~97 ~100 ~603 ~97 ~100 ~604 minecraft:light_gray_concrete replace
fill ~99 ~100 ~606 ~101 ~100 ~606 minecraft:light_gray_concrete replace
fill ~100 ~100 ~607 ~100 ~100 ~608 minecraft:light_gray_concrete replace
fill ~102 ~100 ~610 ~131 ~100 ~610 minecraft:light_gray_concrete replace
fill ~103 ~100 ~611 ~103 ~100 ~612 minecraft:light_gray_concrete replace
fill ~106 ~100 ~611 ~106 ~100 ~612 minecraft:light_gray_concrete replace
fill ~109 ~100 ~611 ~109 ~100 ~612 minecraft:light_gray_concrete replace
fill ~112 ~100 ~611 ~112 ~100 ~612 minecraft:light_gray_concrete replace
fill ~115 ~100 ~611 ~115 ~100 ~612 minecraft:light_gray_concrete replace
fill ~118 ~100 ~611 ~118 ~100 ~612 minecraft:light_gray_concrete replace
fill ~121 ~100 ~611 ~121 ~100 ~612 minecraft:light_gray_concrete replace
fill ~130 ~100 ~611 ~130 ~100 ~612 minecraft:light_gray_concrete replace
fill ~105 ~100 ~622 ~137 ~100 ~622 minecraft:light_gray_concrete replace
fill ~106 ~100 ~623 ~106 ~100 ~624 minecraft:light_gray_concrete replace
fill ~112 ~100 ~623 ~112 ~100 ~624 minecraft:light_gray_concrete replace
fill ~115 ~100 ~623 ~115 ~100 ~624 minecraft:light_gray_concrete replace
fill ~121 ~100 ~623 ~121 ~100 ~624 minecraft:light_gray_concrete replace
fill ~124 ~100 ~623 ~124 ~100 ~624 minecraft:light_gray_concrete replace
fill ~130 ~100 ~623 ~130 ~100 ~624 minecraft:light_gray_concrete replace
fill ~136 ~100 ~623 ~136 ~100 ~624 minecraft:light_gray_concrete replace
fill ~102 ~100 ~626 ~134 ~100 ~626 minecraft:light_gray_concrete replace
fill ~103 ~100 ~627 ~103 ~100 ~628 minecraft:light_gray_concrete replace
fill ~109 ~100 ~627 ~109 ~100 ~628 minecraft:light_gray_concrete replace
fill ~112 ~100 ~627 ~112 ~100 ~628 minecraft:light_gray_concrete replace
fill ~118 ~100 ~627 ~118 ~100 ~628 minecraft:light_gray_concrete replace
fill ~124 ~100 ~627 ~124 ~100 ~628 minecraft:light_gray_concrete replace
fill ~133 ~100 ~627 ~133 ~100 ~628 minecraft:light_gray_concrete replace
fill ~117 ~100 ~634 ~140 ~100 ~634 minecraft:light_gray_concrete replace
fill ~139 ~100 ~635 ~139 ~100 ~636 minecraft:light_gray_concrete replace
fill ~102 ~100 ~638 ~137 ~100 ~638 minecraft:light_gray_concrete replace
fill ~103 ~100 ~639 ~103 ~100 ~640 minecraft:light_gray_concrete replace
fill ~106 ~100 ~639 ~106 ~100 ~640 minecraft:light_gray_concrete replace
fill ~109 ~100 ~639 ~109 ~100 ~640 minecraft:light_gray_concrete replace
fill ~115 ~100 ~639 ~115 ~100 ~640 minecraft:light_gray_concrete replace
fill ~121 ~100 ~639 ~121 ~100 ~640 minecraft:light_gray_concrete replace
fill ~124 ~100 ~639 ~124 ~100 ~640 minecraft:light_gray_concrete replace
fill ~136 ~100 ~639 ~136 ~100 ~640 minecraft:light_gray_concrete replace
fill ~126 ~100 ~646 ~149 ~100 ~646 minecraft:light_gray_concrete replace
fill ~148 ~100 ~647 ~148 ~100 ~648 minecraft:light_gray_concrete replace
fill ~84 ~100 ~650 ~86 ~100 ~650 minecraft:light_gray_concrete replace
fill ~85 ~100 ~651 ~85 ~100 ~652 minecraft:light_gray_concrete replace
fill ~120 ~100 ~654 ~143 ~100 ~654 minecraft:light_gray_concrete replace
fill ~142 ~100 ~655 ~142 ~100 ~656 minecraft:light_gray_concrete replace
fill ~123 ~100 ~662 ~146 ~100 ~662 minecraft:light_gray_concrete replace
fill ~145 ~100 ~663 ~145 ~100 ~664 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~386 minecraft:light_gray_concrete replace
setblock ~123 ~101 ~386 minecraft:light_gray_concrete replace
setblock ~127 ~101 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~101 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~101 ~588 minecraft:light_gray_concrete replace
setblock ~79 ~101 ~592 minecraft:light_gray_concrete replace
setblock ~91 ~101 ~596 minecraft:light_gray_concrete replace
setblock ~94 ~101 ~600 minecraft:light_gray_concrete replace
setblock ~97 ~101 ~604 minecraft:light_gray_concrete replace
setblock ~100 ~101 ~608 minecraft:light_gray_concrete replace
setblock ~103 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~106 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~118 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~106 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~112 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~124 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~626 minecraft:light_gray_concrete replace
setblock ~117 ~101 ~626 minecraft:light_gray_concrete replace
setblock ~103 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~112 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~118 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~124 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~133 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~634 minecraft:light_gray_concrete replace
setblock ~132 ~101 ~634 minecraft:light_gray_concrete replace
setblock ~139 ~101 ~636 minecraft:light_gray_concrete replace
setblock ~118 ~101 ~638 minecraft:light_gray_concrete replace
setblock ~120 ~101 ~638 minecraft:light_gray_concrete replace
setblock ~103 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~106 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~109 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~136 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~133 ~101 ~646 minecraft:light_gray_concrete replace
setblock ~135 ~101 ~646 minecraft:light_gray_concrete replace
setblock ~148 ~101 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~101 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~101 ~654 minecraft:light_gray_concrete replace
setblock ~129 ~101 ~654 minecraft:light_gray_concrete replace
setblock ~142 ~101 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~662 minecraft:light_gray_concrete replace
setblock ~132 ~101 ~662 minecraft:light_gray_concrete replace
setblock ~145 ~101 ~664 minecraft:light_gray_concrete replace
fill ~126 ~102 ~384 ~126 ~102 ~388 minecraft:light_gray_concrete replace
fill ~81 ~102 ~396 ~81 ~102 ~400 minecraft:light_gray_concrete replace
fill ~87 ~102 ~556 ~87 ~102 ~588 minecraft:light_gray_concrete replace
fill ~78 ~102 ~560 ~78 ~102 ~592 minecraft:light_gray_concrete replace
fill ~90 ~102 ~564 ~90 ~102 ~596 minecraft:light_gray_concrete replace
fill ~93 ~102 ~568 ~93 ~102 ~600 minecraft:light_gray_concrete replace
fill ~96 ~102 ~572 ~96 ~102 ~604 minecraft:light_gray_concrete replace
fill ~99 ~102 ~576 ~99 ~102 ~608 minecraft:light_gray_concrete replace
fill ~129 ~102 ~580 ~129 ~102 ~624 minecraft:light_gray_concrete replace
fill ~120 ~102 ~584 ~120 ~102 ~640 minecraft:light_gray_concrete replace
fill ~117 ~102 ~588 ~117 ~102 ~628 minecraft:light_gray_concrete replace
fill ~114 ~102 ~592 ~114 ~102 ~640 minecraft:light_gray_concrete replace
fill ~111 ~102 ~596 ~111 ~102 ~628 minecraft:light_gray_concrete replace
fill ~108 ~102 ~600 ~108 ~102 ~640 minecraft:light_gray_concrete replace
fill ~105 ~102 ~604 ~105 ~102 ~640 minecraft:light_gray_concrete replace
fill ~102 ~102 ~608 ~102 ~102 ~640 minecraft:light_gray_concrete replace
fill ~135 ~102 ~616 ~135 ~102 ~640 minecraft:light_gray_concrete replace
fill ~123 ~102 ~620 ~123 ~102 ~640 minecraft:light_gray_concrete replace
fill ~132 ~102 ~624 ~132 ~102 ~628 minecraft:light_gray_concrete replace
fill ~138 ~102 ~632 ~138 ~102 ~636 minecraft:light_gray_concrete replace
fill ~147 ~102 ~644 ~147 ~102 ~648 minecraft:light_gray_concrete replace
fill ~84 ~102 ~648 ~84 ~102 ~652 minecraft:light_gray_concrete replace
fill ~141 ~102 ~652 ~141 ~102 ~656 minecraft:light_gray_concrete replace
fill ~144 ~102 ~660 ~144 ~102 ~664 minecraft:light_gray_concrete replace
setblock ~126 ~103 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~103 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~555 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~557 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~559 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~559 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~561 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~563 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~563 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~565 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~567 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~567 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~569 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~571 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~571 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~573 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~573 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~575 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~575 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~577 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~577 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~579 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~579 minecraft:light_gray_concrete replace
setblock ~129 ~103 ~579 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~581 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~583 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~583 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~585 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~585 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~587 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~587 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~589 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~589 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~591 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~591 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~593 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~129 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~129 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~108 ~103 ~599 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~599 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~599 minecraft:light_gray_concrete replace
setblock ~108 ~103 ~601 minecraft:light_gray_concrete replace
setblock ~105 ~103 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~103 ~607 minecraft:light_gray_concrete replace
setblock ~103 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~613 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~613 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~615 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~615 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~615 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~617 minecraft:light_gray_concrete replace
setblock ~123 ~103 ~619 minecraft:light_gray_concrete replace
setblock ~132 ~103 ~623 minecraft:light_gray_concrete replace
setblock ~106 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~121 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~130 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~105 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~105 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~103 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~118 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~133 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~138 ~103 ~631 minecraft:light_gray_concrete replace
setblock ~139 ~103 ~636 minecraft:light_gray_concrete replace
setblock ~115 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~121 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~136 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~147 ~103 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~103 ~647 minecraft:light_gray_concrete replace
setblock ~141 ~103 ~651 minecraft:light_gray_concrete replace
setblock ~144 ~103 ~659 minecraft:light_gray_concrete replace
fill ~112 ~104 ~380 ~112 ~104 ~381 minecraft:light_gray_concrete replace
fill ~111 ~104 ~382 ~126 ~104 ~382 minecraft:light_gray_concrete replace
fill ~82 ~104 ~392 ~82 ~104 ~393 minecraft:light_gray_concrete replace
fill ~81 ~104 ~394 ~83 ~104 ~394 minecraft:light_gray_concrete replace
fill ~88 ~104 ~552 ~88 ~104 ~553 minecraft:light_gray_concrete replace
fill ~87 ~104 ~554 ~89 ~104 ~554 minecraft:light_gray_concrete replace
fill ~79 ~104 ~556 ~79 ~104 ~557 minecraft:light_gray_concrete replace
fill ~78 ~104 ~558 ~80 ~104 ~558 minecraft:light_gray_concrete replace
fill ~91 ~104 ~560 ~91 ~104 ~561 minecraft:light_gray_concrete replace
fill ~90 ~104 ~562 ~92 ~104 ~562 minecraft:light_gray_concrete replace
fill ~94 ~104 ~564 ~94 ~104 ~565 minecraft:light_gray_concrete replace
fill ~93 ~104 ~566 ~95 ~104 ~566 minecraft:light_gray_concrete replace
fill ~97 ~104 ~568 ~97 ~104 ~569 minecraft:light_gray_concrete replace
fill ~96 ~104 ~570 ~98 ~104 ~570 minecraft:light_gray_concrete replace
fill ~100 ~104 ~572 ~100 ~104 ~573 minecraft:light_gray_concrete replace
fill ~99 ~104 ~574 ~101 ~104 ~574 minecraft:light_gray_concrete replace
fill ~115 ~104 ~576 ~115 ~104 ~577 minecraft:light_gray_concrete replace
fill ~114 ~104 ~578 ~129 ~104 ~578 minecraft:light_gray_concrete replace
fill ~109 ~104 ~580 ~109 ~104 ~581 minecraft:light_gray_concrete replace
fill ~108 ~104 ~582 ~120 ~104 ~582 minecraft:light_gray_concrete replace
fill ~109 ~104 ~584 ~109 ~104 ~585 minecraft:light_gray_concrete replace
fill ~108 ~104 ~586 ~117 ~104 ~586 minecraft:light_gray_concrete replace
fill ~106 ~104 ~588 ~106 ~104 ~589 minecraft:light_gray_concrete replace
fill ~105 ~104 ~590 ~114 ~104 ~590 minecraft:light_gray_concrete replace
fill ~106 ~104 ~592 ~106 ~104 ~593 minecraft:light_gray_concrete replace
fill ~105 ~104 ~594 ~111 ~104 ~594 minecraft:light_gray_concrete replace
fill ~106 ~104 ~596 ~106 ~104 ~597 minecraft:light_gray_concrete replace
fill ~105 ~104 ~598 ~108 ~104 ~598 minecraft:light_gray_concrete replace
fill ~103 ~104 ~600 ~103 ~104 ~601 minecraft:light_gray_concrete replace
fill ~102 ~104 ~602 ~105 ~104 ~602 minecraft:light_gray_concrete replace
fill ~103 ~104 ~604 ~103 ~104 ~605 minecraft:light_gray_concrete replace
fill ~102 ~104 ~606 ~104 ~104 ~606 minecraft:light_gray_concrete replace
fill ~115 ~104 ~612 ~115 ~104 ~613 minecraft:light_gray_concrete replace
fill ~114 ~104 ~614 ~135 ~104 ~614 minecraft:light_gray_concrete replace
fill ~109 ~104 ~616 ~109 ~104 ~617 minecraft:light_gray_concrete replace
fill ~108 ~104 ~618 ~123 ~104 ~618 minecraft:light_gray_concrete replace
fill ~115 ~104 ~620 ~115 ~104 ~621 minecraft:light_gray_concrete replace
fill ~114 ~104 ~622 ~132 ~104 ~622 minecraft:light_gray_concrete replace
fill ~118 ~104 ~628 ~118 ~104 ~629 minecraft:light_gray_concrete replace
fill ~117 ~104 ~630 ~138 ~104 ~630 minecraft:light_gray_concrete replace
fill ~127 ~104 ~640 ~127 ~104 ~641 minecraft:light_gray_concrete replace
fill ~126 ~104 ~642 ~147 ~104 ~642 minecraft:light_gray_concrete replace
fill ~85 ~104 ~644 ~85 ~104 ~645 minecraft:light_gray_concrete replace
fill ~84 ~104 ~646 ~86 ~104 ~646 minecraft:light_gray_concrete replace
fill ~121 ~104 ~648 ~121 ~104 ~649 minecraft:light_gray_concrete replace
fill ~120 ~104 ~650 ~141 ~104 ~650 minecraft:light_gray_concrete replace
fill ~124 ~104 ~656 ~124 ~104 ~657 minecraft:light_gray_concrete replace
fill ~123 ~104 ~658 ~144 ~104 ~658 minecraft:light_gray_concrete replace
setblock ~112 ~105 ~380 minecraft:light_gray_concrete replace
setblock ~117 ~105 ~382 minecraft:light_gray_concrete replace
setblock ~119 ~105 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~105 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~105 ~552 minecraft:light_gray_concrete replace
setblock ~79 ~105 ~556 minecraft:light_gray_concrete replace
setblock ~91 ~105 ~560 minecraft:light_gray_concrete replace
setblock ~94 ~105 ~564 minecraft:light_gray_concrete replace
setblock ~97 ~105 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~105 ~572 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~576 minecraft:light_gray_concrete replace
setblock ~109 ~105 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~105 ~584 minecraft:light_gray_concrete replace
setblock ~106 ~105 ~588 minecraft:light_gray_concrete replace
setblock ~106 ~105 ~592 minecraft:light_gray_concrete replace
setblock ~106 ~105 ~596 minecraft:light_gray_concrete replace
setblock ~103 ~105 ~600 minecraft:light_gray_concrete replace
setblock ~103 ~105 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~612 minecraft:light_gray_concrete replace
setblock ~120 ~105 ~614 minecraft:light_gray_concrete replace
setblock ~122 ~105 ~614 minecraft:light_gray_concrete replace
setblock ~109 ~105 ~616 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~618 minecraft:light_gray_concrete replace
setblock ~117 ~105 ~618 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~620 minecraft:light_gray_concrete replace
setblock ~123 ~105 ~622 minecraft:light_gray_concrete replace
setblock ~125 ~105 ~622 minecraft:light_gray_concrete replace
setblock ~118 ~105 ~628 minecraft:light_gray_concrete replace
setblock ~129 ~105 ~630 minecraft:light_gray_concrete replace
setblock ~131 ~105 ~630 minecraft:light_gray_concrete replace
setblock ~127 ~105 ~640 minecraft:light_gray_concrete replace
setblock ~138 ~105 ~642 minecraft:light_gray_concrete replace
setblock ~140 ~105 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~105 ~644 minecraft:light_gray_concrete replace
setblock ~121 ~105 ~648 minecraft:light_gray_concrete replace
setblock ~132 ~105 ~650 minecraft:light_gray_concrete replace
setblock ~134 ~105 ~650 minecraft:light_gray_concrete replace
setblock ~124 ~105 ~656 minecraft:light_gray_concrete replace
setblock ~135 ~105 ~658 minecraft:light_gray_concrete replace
setblock ~137 ~105 ~658 minecraft:light_gray_concrete replace
fill ~111 ~106 ~380 ~111 ~106 ~384 minecraft:light_gray_concrete replace
fill ~81 ~106 ~392 ~81 ~106 ~396 minecraft:light_gray_concrete replace
fill ~87 ~106 ~552 ~87 ~106 ~556 minecraft:light_gray_concrete replace
fill ~78 ~106 ~556 ~78 ~106 ~560 minecraft:light_gray_concrete replace
fill ~90 ~106 ~560 ~90 ~106 ~564 minecraft:light_gray_concrete replace
fill ~93 ~106 ~564 ~93 ~106 ~568 minecraft:light_gray_concrete replace
fill ~96 ~106 ~568 ~96 ~106 ~572 minecraft:light_gray_concrete replace
fill ~99 ~106 ~572 ~99 ~106 ~576 minecraft:light_gray_concrete replace
fill ~114 ~106 ~576 ~114 ~106 ~624 minecraft:light_gray_concrete replace
fill ~108 ~106 ~580 ~108 ~106 ~620 minecraft:light_gray_concrete replace
fill ~105 ~106 ~588 ~105 ~106 ~600 minecraft:light_gray_concrete replace
fill ~102 ~106 ~600 ~102 ~106 ~608 minecraft:light_gray_concrete replace
fill ~117 ~106 ~628 ~117 ~106 ~632 minecraft:light_gray_concrete replace
fill ~126 ~106 ~640 ~126 ~106 ~644 minecraft:light_gray_concrete replace
fill ~84 ~106 ~644 ~84 ~106 ~648 minecraft:light_gray_concrete replace
fill ~120 ~106 ~648 ~120 ~106 ~652 minecraft:light_gray_concrete replace
fill ~123 ~106 ~656 ~123 ~106 ~660 minecraft:light_gray_concrete replace
setblock ~111 ~107 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~107 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~107 ~557 minecraft:light_gray_concrete replace
setblock ~78 ~107 ~561 minecraft:light_gray_concrete replace
setblock ~90 ~107 ~565 minecraft:light_gray_concrete replace
setblock ~93 ~107 ~569 minecraft:light_gray_concrete replace
setblock ~96 ~107 ~573 minecraft:light_gray_concrete replace
setblock ~115 ~107 ~576 minecraft:light_gray_concrete replace
setblock ~99 ~107 ~577 minecraft:light_gray_concrete replace
setblock ~109 ~107 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~107 ~584 minecraft:light_gray_concrete replace
setblock ~106 ~107 ~588 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~589 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~591 minecraft:light_gray_concrete replace
setblock ~106 ~107 ~592 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~593 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~595 minecraft:light_gray_concrete replace
setblock ~106 ~107 ~596 minecraft:light_gray_concrete replace
setblock ~105 ~107 ~599 minecraft:light_gray_concrete replace
setblock ~103 ~107 ~600 minecraft:light_gray_concrete replace
setblock ~105 ~107 ~601 minecraft:light_gray_concrete replace
setblock ~103 ~107 ~604 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~605 minecraft:light_gray_concrete replace
setblock ~102 ~107 ~607 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~607 minecraft:light_gray_concrete replace
setblock ~102 ~107 ~609 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~609 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~611 minecraft:light_gray_concrete replace
setblock ~115 ~107 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~107 ~616 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~619 minecraft:light_gray_concrete replace
setblock ~115 ~107 ~620 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~621 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~625 minecraft:light_gray_concrete replace
setblock ~118 ~107 ~628 minecraft:light_gray_concrete replace
setblock ~117 ~107 ~633 minecraft:light_gray_concrete replace
setblock ~126 ~107 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~107 ~649 minecraft:light_gray_concrete replace
setblock ~120 ~107 ~653 minecraft:light_gray_concrete replace
setblock ~123 ~107 ~661 minecraft:light_gray_concrete replace
fill ~111 ~108 ~386 ~125 ~108 ~386 minecraft:light_gray_concrete replace
fill ~124 ~108 ~387 ~124 ~108 ~388 minecraft:light_gray_concrete replace
fill ~81 ~108 ~398 ~83 ~108 ~398 minecraft:light_gray_concrete replace
fill ~82 ~108 ~399 ~82 ~108 ~400 minecraft:light_gray_concrete replace
fill ~87 ~108 ~558 ~89 ~108 ~558 minecraft:light_gray_concrete replace
fill ~88 ~108 ~559 ~88 ~108 ~560 minecraft:light_gray_concrete replace
fill ~78 ~108 ~562 ~80 ~108 ~562 minecraft:light_gray_concrete replace
fill ~79 ~108 ~563 ~79 ~108 ~564 minecraft:light_gray_concrete replace
fill ~90 ~108 ~566 ~92 ~108 ~566 minecraft:light_gray_concrete replace
fill ~91 ~108 ~567 ~91 ~108 ~568 minecraft:light_gray_concrete replace
fill ~93 ~108 ~570 ~95 ~108 ~570 minecraft:light_gray_concrete replace
fill ~94 ~108 ~571 ~94 ~108 ~572 minecraft:light_gray_concrete replace
fill ~96 ~108 ~574 ~98 ~108 ~574 minecraft:light_gray_concrete replace
fill ~97 ~108 ~575 ~97 ~108 ~576 minecraft:light_gray_concrete replace
fill ~99 ~108 ~578 ~128 ~108 ~578 minecraft:light_gray_concrete replace
fill ~100 ~108 ~579 ~100 ~108 ~580 minecraft:light_gray_concrete replace
fill ~103 ~108 ~579 ~103 ~108 ~580 minecraft:light_gray_concrete replace
fill ~106 ~108 ~579 ~106 ~108 ~580 minecraft:light_gray_concrete replace
fill ~109 ~108 ~579 ~109 ~108 ~580 minecraft:light_gray_concrete replace
fill ~112 ~108 ~579 ~112 ~108 ~580 minecraft:light_gray_concrete replace
fill ~115 ~108 ~579 ~115 ~108 ~580 minecraft:light_gray_concrete replace
fill ~118 ~108 ~579 ~118 ~108 ~580 minecraft:light_gray_concrete replace
fill ~127 ~108 ~579 ~127 ~108 ~580 minecraft:light_gray_concrete replace
fill ~99 ~108 ~602 ~134 ~108 ~602 minecraft:light_gray_concrete replace
fill ~100 ~108 ~603 ~100 ~108 ~604 minecraft:light_gray_concrete replace
fill ~106 ~108 ~603 ~106 ~108 ~604 minecraft:light_gray_concrete replace
fill ~109 ~108 ~603 ~109 ~108 ~604 minecraft:light_gray_concrete replace
fill ~112 ~108 ~603 ~112 ~108 ~604 minecraft:light_gray_concrete replace
fill ~118 ~108 ~603 ~118 ~108 ~604 minecraft:light_gray_concrete replace
fill ~121 ~108 ~603 ~121 ~108 ~604 minecraft:light_gray_concrete replace
fill ~133 ~108 ~603 ~133 ~108 ~604 minecraft:light_gray_concrete replace
fill ~99 ~108 ~610 ~131 ~108 ~610 minecraft:light_gray_concrete replace
fill ~100 ~108 ~611 ~100 ~108 ~612 minecraft:light_gray_concrete replace
fill ~103 ~108 ~611 ~103 ~108 ~612 minecraft:light_gray_concrete replace
fill ~109 ~108 ~611 ~109 ~108 ~612 minecraft:light_gray_concrete replace
fill ~115 ~108 ~611 ~115 ~108 ~612 minecraft:light_gray_concrete replace
fill ~121 ~108 ~611 ~121 ~108 ~612 minecraft:light_gray_concrete replace
fill ~130 ~108 ~611 ~130 ~108 ~612 minecraft:light_gray_concrete replace
fill ~102 ~108 ~622 ~134 ~108 ~622 minecraft:light_gray_concrete replace
fill ~103 ~108 ~623 ~103 ~108 ~624 minecraft:light_gray_concrete replace
fill ~106 ~108 ~623 ~106 ~108 ~624 minecraft:light_gray_concrete replace
fill ~112 ~108 ~623 ~112 ~108 ~624 minecraft:light_gray_concrete replace
fill ~118 ~108 ~623 ~118 ~108 ~624 minecraft:light_gray_concrete replace
fill ~121 ~108 ~623 ~121 ~108 ~624 minecraft:light_gray_concrete replace
fill ~127 ~108 ~623 ~127 ~108 ~624 minecraft:light_gray_concrete replace
fill ~133 ~108 ~623 ~133 ~108 ~624 minecraft:light_gray_concrete replace
fill ~114 ~108 ~626 ~137 ~108 ~626 minecraft:light_gray_concrete replace
fill ~136 ~108 ~627 ~136 ~108 ~628 minecraft:light_gray_concrete replace
fill ~117 ~108 ~634 ~140 ~108 ~634 minecraft:light_gray_concrete replace
fill ~139 ~108 ~635 ~139 ~108 ~636 minecraft:light_gray_concrete replace
fill ~126 ~108 ~646 ~149 ~108 ~646 minecraft:light_gray_concrete replace
fill ~148 ~108 ~647 ~148 ~108 ~648 minecraft:light_gray_concrete replace
fill ~84 ~108 ~650 ~86 ~108 ~650 minecraft:light_gray_concrete replace
fill ~85 ~108 ~651 ~85 ~108 ~652 minecraft:light_gray_concrete replace
fill ~120 ~108 ~654 ~143 ~108 ~654 minecraft:light_gray_concrete replace
fill ~142 ~108 ~655 ~142 ~108 ~656 minecraft:light_gray_concrete replace
fill ~123 ~108 ~662 ~146 ~108 ~662 minecraft:light_gray_concrete replace
fill ~145 ~108 ~663 ~145 ~108 ~664 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~386 minecraft:light_gray_concrete replace
setblock ~120 ~109 ~386 minecraft:light_gray_concrete replace
setblock ~124 ~109 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~109 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~109 ~560 minecraft:light_gray_concrete replace
setblock ~79 ~109 ~564 minecraft:light_gray_concrete replace
setblock ~91 ~109 ~568 minecraft:light_gray_concrete replace
setblock ~94 ~109 ~572 minecraft:light_gray_concrete replace
setblock ~97 ~109 ~576 minecraft:light_gray_concrete replace
setblock ~100 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~103 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~106 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~112 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~115 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~100 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~106 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~109 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~112 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~133 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~100 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~103 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~103 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~106 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~112 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~121 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~127 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~133 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~124 ~109 ~626 minecraft:light_gray_concrete replace
setblock ~126 ~109 ~626 minecraft:light_gray_concrete replace
setblock ~136 ~109 ~628 minecraft:light_gray_concrete replace
setblock ~124 ~109 ~634 minecraft:light_gray_concrete replace
setblock ~126 ~109 ~634 minecraft:light_gray_concrete replace
setblock ~139 ~109 ~636 minecraft:light_gray_concrete replace
setblock ~133 ~109 ~646 minecraft:light_gray_concrete replace
setblock ~135 ~109 ~646 minecraft:light_gray_concrete replace
setblock ~148 ~109 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~109 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~109 ~654 minecraft:light_gray_concrete replace
setblock ~129 ~109 ~654 minecraft:light_gray_concrete replace
setblock ~142 ~109 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~109 ~662 minecraft:light_gray_concrete replace
setblock ~132 ~109 ~662 minecraft:light_gray_concrete replace
setblock ~145 ~109 ~664 minecraft:light_gray_concrete replace
fill ~123 ~110 ~384 ~123 ~110 ~388 minecraft:light_gray_concrete replace
fill ~81 ~110 ~396 ~81 ~110 ~400 minecraft:light_gray_concrete replace
fill ~87 ~110 ~528 ~87 ~110 ~560 minecraft:light_gray_concrete replace
fill ~78 ~110 ~532 ~78 ~110 ~564 minecraft:light_gray_concrete replace
fill ~90 ~110 ~536 ~90 ~110 ~568 minecraft:light_gray_concrete replace
fill ~93 ~110 ~540 ~93 ~110 ~572 minecraft:light_gray_concrete replace
fill ~96 ~110 ~544 ~96 ~110 ~576 minecraft:light_gray_concrete replace
fill ~126 ~110 ~548 ~126 ~110 ~624 minecraft:light_gray_concrete replace
fill ~117 ~110 ~552 ~117 ~110 ~624 minecraft:light_gray_concrete replace
fill ~114 ~110 ~556 ~114 ~110 ~612 minecraft:light_gray_concrete replace
fill ~111 ~110 ~560 ~111 ~110 ~624 minecraft:light_gray_concrete replace
fill ~108 ~110 ~564 ~108 ~110 ~612 minecraft:light_gray_concrete replace
fill ~105 ~110 ~568 ~105 ~110 ~624 minecraft:light_gray_concrete replace
fill ~102 ~110 ~572 ~102 ~110 ~624 minecraft:light_gray_concrete replace
fill ~99 ~110 ~576 ~99 ~110 ~612 minecraft:light_gray_concrete replace
fill ~132 ~110 ~596 ~132 ~110 ~624 minecraft:light_gray_concrete replace
fill ~120 ~110 ~600 ~120 ~110 ~624 minecraft:light_gray_concrete replace
fill ~129 ~110 ~608 ~129 ~110 ~612 minecraft:light_gray_concrete replace
fill ~135 ~110 ~624 ~135 ~110 ~628 minecraft:light_gray_concrete replace
fill ~138 ~110 ~632 ~138 ~110 ~636 minecraft:light_gray_concrete replace
fill ~147 ~110 ~644 ~147 ~110 ~648 minecraft:light_gray_concrete replace
fill ~84 ~110 ~648 ~84 ~110 ~652 minecraft:light_gray_concrete replace
fill ~141 ~110 ~652 ~141 ~110 ~656 minecraft:light_gray_concrete replace
fill ~144 ~110 ~660 ~144 ~110 ~664 minecraft:light_gray_concrete replace
setblock ~123 ~111 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~111 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~527 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~529 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~531 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~531 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~533 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~535 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~535 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~537 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~539 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~539 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~541 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~543 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~543 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~545 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~545 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~547 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~547 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~547 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~549 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~551 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~551 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~553 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~553 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~555 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~555 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~557 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~557 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~559 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~559 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~561 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~567 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~567 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~567 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~573 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~575 minecraft:light_gray_concrete replace
setblock ~103 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~581 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~581 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~581 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~583 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~583 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~583 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~120 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~120 ~111 ~601 minecraft:light_gray_concrete replace
setblock ~106 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~133 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~129 ~111 ~607 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~100 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~135 ~111 ~623 minecraft:light_gray_concrete replace
setblock ~106 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~112 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~118 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~127 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~133 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~111 ~628 minecraft:light_gray_concrete replace
setblock ~138 ~111 ~631 minecraft:light_gray_concrete replace
setblock ~139 ~111 ~636 minecraft:light_gray_concrete replace
setblock ~147 ~111 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~111 ~647 minecraft:light_gray_concrete replace
setblock ~141 ~111 ~651 minecraft:light_gray_concrete replace
setblock ~144 ~111 ~659 minecraft:light_gray_concrete replace
fill ~109 ~112 ~380 ~109 ~112 ~381 minecraft:light_gray_concrete replace
fill ~108 ~112 ~382 ~123 ~112 ~382 minecraft:light_gray_concrete replace
fill ~82 ~112 ~392 ~82 ~112 ~393 minecraft:light_gray_concrete replace
fill ~81 ~112 ~394 ~83 ~112 ~394 minecraft:light_gray_concrete replace
fill ~88 ~112 ~524 ~88 ~112 ~525 minecraft:light_gray_concrete replace
fill ~87 ~112 ~526 ~89 ~112 ~526 minecraft:light_gray_concrete replace
fill ~79 ~112 ~528 ~79 ~112 ~529 minecraft:light_gray_concrete replace
fill ~78 ~112 ~530 ~80 ~112 ~530 minecraft:light_gray_concrete replace
fill ~91 ~112 ~532 ~91 ~112 ~533 minecraft:light_gray_concrete replace
fill ~90 ~112 ~534 ~92 ~112 ~534 minecraft:light_gray_concrete replace
fill ~94 ~112 ~536 ~94 ~112 ~537 minecraft:light_gray_concrete replace
fill ~93 ~112 ~538 ~95 ~112 ~538 minecraft:light_gray_concrete replace
fill ~97 ~112 ~540 ~97 ~112 ~541 minecraft:light_gray_concrete replace
fill ~96 ~112 ~542 ~98 ~112 ~542 minecraft:light_gray_concrete replace
fill ~112 ~112 ~544 ~112 ~112 ~545 minecraft:light_gray_concrete replace
fill ~111 ~112 ~546 ~126 ~112 ~546 minecraft:light_gray_concrete replace
fill ~106 ~112 ~548 ~106 ~112 ~549 minecraft:light_gray_concrete replace
fill ~105 ~112 ~550 ~117 ~112 ~550 minecraft:light_gray_concrete replace
fill ~106 ~112 ~552 ~106 ~112 ~553 minecraft:light_gray_concrete replace
fill ~105 ~112 ~554 ~114 ~112 ~554 minecraft:light_gray_concrete replace
fill ~103 ~112 ~556 ~103 ~112 ~557 minecraft:light_gray_concrete replace
fill ~102 ~112 ~558 ~111 ~112 ~558 minecraft:light_gray_concrete replace
fill ~103 ~112 ~560 ~103 ~112 ~561 minecraft:light_gray_concrete replace
fill ~102 ~112 ~562 ~108 ~112 ~562 minecraft:light_gray_concrete replace
fill ~100 ~112 ~564 ~100 ~112 ~565 minecraft:light_gray_concrete replace
fill ~99 ~112 ~566 ~105 ~112 ~566 minecraft:light_gray_concrete replace
fill ~100 ~112 ~568 ~100 ~112 ~569 minecraft:light_gray_concrete replace
fill ~99 ~112 ~570 ~102 ~112 ~570 minecraft:light_gray_concrete replace
fill ~100 ~112 ~572 ~100 ~112 ~573 minecraft:light_gray_concrete replace
fill ~99 ~112 ~574 ~101 ~112 ~574 minecraft:light_gray_concrete replace
fill ~112 ~112 ~592 ~112 ~112 ~593 minecraft:light_gray_concrete replace
fill ~111 ~112 ~594 ~132 ~112 ~594 minecraft:light_gray_concrete replace
fill ~106 ~112 ~596 ~106 ~112 ~597 minecraft:light_gray_concrete replace
fill ~105 ~112 ~598 ~120 ~112 ~598 minecraft:light_gray_concrete replace
fill ~112 ~112 ~604 ~112 ~112 ~605 minecraft:light_gray_concrete replace
fill ~111 ~112 ~606 ~129 ~112 ~606 minecraft:light_gray_concrete replace
fill ~115 ~112 ~620 ~115 ~112 ~621 minecraft:light_gray_concrete replace
fill ~114 ~112 ~622 ~135 ~112 ~622 minecraft:light_gray_concrete replace
fill ~118 ~112 ~628 ~118 ~112 ~629 minecraft:light_gray_concrete replace
fill ~117 ~112 ~630 ~138 ~112 ~630 minecraft:light_gray_concrete replace
fill ~127 ~112 ~640 ~127 ~112 ~641 minecraft:light_gray_concrete replace
fill ~126 ~112 ~642 ~147 ~112 ~642 minecraft:light_gray_concrete replace
fill ~85 ~112 ~644 ~85 ~112 ~645 minecraft:light_gray_concrete replace
fill ~84 ~112 ~646 ~86 ~112 ~646 minecraft:light_gray_concrete replace
fill ~121 ~112 ~648 ~121 ~112 ~649 minecraft:light_gray_concrete replace
fill ~120 ~112 ~650 ~141 ~112 ~650 minecraft:light_gray_concrete replace
fill ~124 ~112 ~656 ~124 ~112 ~657 minecraft:light_gray_concrete replace
fill ~123 ~112 ~658 ~144 ~112 ~658 minecraft:light_gray_concrete replace
setblock ~109 ~113 ~380 minecraft:light_gray_concrete replace
setblock ~114 ~113 ~382 minecraft:light_gray_concrete replace
setblock ~116 ~113 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~113 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~113 ~524 minecraft:light_gray_concrete replace
setblock ~79 ~113 ~528 minecraft:light_gray_concrete replace
setblock ~91 ~113 ~532 minecraft:light_gray_concrete replace
setblock ~94 ~113 ~536 minecraft:light_gray_concrete replace
setblock ~97 ~113 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~113 ~544 minecraft:light_gray_concrete replace
setblock ~106 ~113 ~548 minecraft:light_gray_concrete replace
setblock ~106 ~113 ~552 minecraft:light_gray_concrete replace
setblock ~103 ~113 ~556 minecraft:light_gray_concrete replace
setblock ~103 ~113 ~560 minecraft:light_gray_concrete replace
setblock ~100 ~113 ~564 minecraft:light_gray_concrete replace
setblock ~100 ~113 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~113 ~572 minecraft:light_gray_concrete replace
setblock ~112 ~113 ~592 minecraft:light_gray_concrete replace
setblock ~117 ~113 ~594 minecraft:light_gray_concrete replace
setblock ~119 ~113 ~594 minecraft:light_gray_concrete replace
setblock ~106 ~113 ~596 minecraft:light_gray_concrete replace
setblock ~112 ~113 ~604 minecraft:light_gray_concrete replace
setblock ~120 ~113 ~606 minecraft:light_gray_concrete replace
setblock ~122 ~113 ~606 minecraft:light_gray_concrete replace
setblock ~115 ~113 ~620 minecraft:light_gray_concrete replace
setblock ~126 ~113 ~622 minecraft:light_gray_concrete replace
setblock ~128 ~113 ~622 minecraft:light_gray_concrete replace
setblock ~118 ~113 ~628 minecraft:light_gray_concrete replace
setblock ~129 ~113 ~630 minecraft:light_gray_concrete replace
setblock ~131 ~113 ~630 minecraft:light_gray_concrete replace
setblock ~127 ~113 ~640 minecraft:light_gray_concrete replace
setblock ~138 ~113 ~642 minecraft:light_gray_concrete replace
setblock ~140 ~113 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~113 ~644 minecraft:light_gray_concrete replace
setblock ~121 ~113 ~648 minecraft:light_gray_concrete replace
setblock ~132 ~113 ~650 minecraft:light_gray_concrete replace
setblock ~134 ~113 ~650 minecraft:light_gray_concrete replace
setblock ~124 ~113 ~656 minecraft:light_gray_concrete replace
setblock ~135 ~113 ~658 minecraft:light_gray_concrete replace
setblock ~137 ~113 ~658 minecraft:light_gray_concrete replace
fill ~108 ~114 ~380 ~108 ~114 ~384 minecraft:light_gray_concrete replace
fill ~81 ~114 ~392 ~81 ~114 ~396 minecraft:light_gray_concrete replace
fill ~87 ~114 ~524 ~87 ~114 ~528 minecraft:light_gray_concrete replace
fill ~78 ~114 ~528 ~78 ~114 ~532 minecraft:light_gray_concrete replace
fill ~90 ~114 ~532 ~90 ~114 ~536 minecraft:light_gray_concrete replace
fill ~93 ~114 ~536 ~93 ~114 ~540 minecraft:light_gray_concrete replace
fill ~96 ~114 ~540 ~96 ~114 ~544 minecraft:light_gray_concrete replace
fill ~111 ~114 ~544 ~111 ~114 ~608 minecraft:light_gray_concrete replace
fill ~105 ~114 ~548 ~105 ~114 ~600 minecraft:light_gray_concrete replace
fill ~102 ~114 ~556 ~102 ~114 ~564 minecraft:light_gray_concrete replace
fill ~99 ~114 ~564 ~99 ~114 ~576 minecraft:light_gray_concrete replace
fill ~114 ~114 ~620 ~114 ~114 ~624 minecraft:light_gray_concrete replace
fill ~117 ~114 ~628 ~117 ~114 ~632 minecraft:light_gray_concrete replace
fill ~126 ~114 ~640 ~126 ~114 ~644 minecraft:light_gray_concrete replace
fill ~84 ~114 ~644 ~84 ~114 ~648 minecraft:light_gray_concrete replace
fill ~120 ~114 ~648 ~120 ~114 ~652 minecraft:light_gray_concrete replace
fill ~123 ~114 ~656 ~123 ~114 ~660 minecraft:light_gray_concrete replace
setblock ~108 ~115 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~115 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~115 ~529 minecraft:light_gray_concrete replace
setblock ~78 ~115 ~533 minecraft:light_gray_concrete replace
setblock ~90 ~115 ~537 minecraft:light_gray_concrete replace
setblock ~93 ~115 ~541 minecraft:light_gray_concrete replace
setblock ~112 ~115 ~544 minecraft:light_gray_concrete replace
setblock ~96 ~115 ~545 minecraft:light_gray_concrete replace
setblock ~106 ~115 ~548 minecraft:light_gray_concrete replace
setblock ~106 ~115 ~552 minecraft:light_gray_concrete replace
setblock ~103 ~115 ~556 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~557 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~559 minecraft:light_gray_concrete replace
setblock ~103 ~115 ~560 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~561 minecraft:light_gray_concrete replace
setblock ~102 ~115 ~563 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~563 minecraft:light_gray_concrete replace
setblock ~100 ~115 ~564 minecraft:light_gray_concrete replace
setblock ~102 ~115 ~565 minecraft:light_gray_concrete replace
setblock ~100 ~115 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~115 ~572 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~573 minecraft:light_gray_concrete replace
setblock ~99 ~115 ~575 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~115 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~579 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~589 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~591 minecraft:light_gray_concrete replace
setblock ~112 ~115 ~592 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~593 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~595 minecraft:light_gray_concrete replace
setblock ~106 ~115 ~596 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~601 minecraft:light_gray_concrete replace
setblock ~112 ~115 ~604 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~609 minecraft:light_gray_concrete replace
setblock ~115 ~115 ~620 minecraft:light_gray_concrete replace
setblock ~114 ~115 ~625 minecraft:light_gray_concrete replace
setblock ~118 ~115 ~628 minecraft:light_gray_concrete replace
setblock ~117 ~115 ~633 minecraft:light_gray_concrete replace
setblock ~126 ~115 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~115 ~649 minecraft:light_gray_concrete replace
setblock ~120 ~115 ~653 minecraft:light_gray_concrete replace
setblock ~123 ~115 ~661 minecraft:light_gray_concrete replace
fill ~108 ~116 ~386 ~122 ~116 ~386 minecraft:light_gray_concrete replace
fill ~121 ~116 ~387 ~121 ~116 ~388 minecraft:light_gray_concrete replace
fill ~81 ~116 ~398 ~83 ~116 ~398 minecraft:light_gray_concrete replace
fill ~82 ~116 ~399 ~82 ~116 ~400 minecraft:light_gray_concrete replace
fill ~87 ~116 ~530 ~89 ~116 ~530 minecraft:light_gray_concrete replace
fill ~88 ~116 ~531 ~88 ~116 ~532 minecraft:light_gray_concrete replace
fill ~78 ~116 ~534 ~80 ~116 ~534 minecraft:light_gray_concrete replace
fill ~79 ~116 ~535 ~79 ~116 ~536 minecraft:light_gray_concrete replace
fill ~90 ~116 ~538 ~92 ~116 ~538 minecraft:light_gray_concrete replace
fill ~91 ~116 ~539 ~91 ~116 ~540 minecraft:light_gray_concrete replace
fill ~93 ~116 ~542 ~95 ~116 ~542 minecraft:light_gray_concrete replace
fill ~94 ~116 ~543 ~94 ~116 ~544 minecraft:light_gray_concrete replace
fill ~96 ~116 ~546 ~125 ~116 ~546 minecraft:light_gray_concrete replace
fill ~97 ~116 ~547 ~97 ~116 ~548 minecraft:light_gray_concrete replace
fill ~100 ~116 ~547 ~100 ~116 ~548 minecraft:light_gray_concrete replace
fill ~103 ~116 ~547 ~103 ~116 ~548 minecraft:light_gray_concrete replace
fill ~106 ~116 ~547 ~106 ~116 ~548 minecraft:light_gray_concrete replace
fill ~109 ~116 ~547 ~109 ~116 ~548 minecraft:light_gray_concrete replace
fill ~112 ~116 ~547 ~112 ~116 ~548 minecraft:light_gray_concrete replace
fill ~115 ~116 ~547 ~115 ~116 ~548 minecraft:light_gray_concrete replace
fill ~124 ~116 ~547 ~124 ~116 ~548 minecraft:light_gray_concrete replace
fill ~96 ~116 ~566 ~131 ~116 ~566 minecraft:light_gray_concrete replace
fill ~97 ~116 ~567 ~97 ~116 ~568 minecraft:light_gray_concrete replace
fill ~103 ~116 ~567 ~103 ~116 ~568 minecraft:light_gray_concrete replace
fill ~109 ~116 ~567 ~109 ~116 ~568 minecraft:light_gray_concrete replace
fill ~112 ~116 ~567 ~112 ~116 ~568 minecraft:light_gray_concrete replace
fill ~118 ~116 ~567 ~118 ~116 ~568 minecraft:light_gray_concrete replace
fill ~130 ~116 ~567 ~130 ~116 ~568 minecraft:light_gray_concrete replace
fill ~96 ~116 ~578 ~128 ~116 ~578 minecraft:light_gray_concrete replace
fill ~97 ~116 ~579 ~97 ~116 ~580 minecraft:light_gray_concrete replace
fill ~100 ~116 ~579 ~100 ~116 ~580 minecraft:light_gray_concrete replace
fill ~103 ~116 ~579 ~103 ~116 ~580 minecraft:light_gray_concrete replace
fill ~106 ~116 ~579 ~106 ~116 ~580 minecraft:light_gray_concrete replace
fill ~115 ~116 ~579 ~115 ~116 ~580 minecraft:light_gray_concrete replace
fill ~118 ~116 ~579 ~118 ~116 ~580 minecraft:light_gray_concrete replace
fill ~127 ~116 ~579 ~127 ~116 ~580 minecraft:light_gray_concrete replace
fill ~99 ~116 ~602 ~128 ~116 ~602 minecraft:light_gray_concrete replace
fill ~100 ~116 ~603 ~100 ~116 ~604 minecraft:light_gray_concrete replace
fill ~106 ~116 ~603 ~106 ~116 ~604 minecraft:light_gray_concrete replace
fill ~109 ~116 ~603 ~109 ~116 ~604 minecraft:light_gray_concrete replace
fill ~115 ~116 ~603 ~115 ~116 ~604 minecraft:light_gray_concrete replace
fill ~118 ~116 ~603 ~118 ~116 ~604 minecraft:light_gray_concrete replace
fill ~124 ~116 ~603 ~124 ~116 ~604 minecraft:light_gray_concrete replace
fill ~127 ~116 ~603 ~127 ~116 ~604 minecraft:light_gray_concrete replace
fill ~111 ~116 ~610 ~149 ~116 ~610 minecraft:light_gray_concrete replace
fill ~133 ~116 ~611 ~133 ~116 ~612 minecraft:light_gray_concrete replace
fill ~136 ~116 ~611 ~136 ~116 ~612 minecraft:light_gray_concrete replace
fill ~139 ~116 ~611 ~139 ~116 ~612 minecraft:light_gray_concrete replace
fill ~142 ~116 ~611 ~142 ~116 ~612 minecraft:light_gray_concrete replace
fill ~148 ~116 ~611 ~148 ~116 ~612 minecraft:light_gray_concrete replace
fill ~114 ~116 ~626 ~152 ~116 ~626 minecraft:light_gray_concrete replace
fill ~133 ~116 ~627 ~133 ~116 ~628 minecraft:light_gray_concrete replace
fill ~139 ~116 ~627 ~139 ~116 ~628 minecraft:light_gray_concrete replace
fill ~142 ~116 ~627 ~142 ~116 ~628 minecraft:light_gray_concrete replace
fill ~145 ~116 ~627 ~145 ~116 ~628 minecraft:light_gray_concrete replace
fill ~151 ~116 ~627 ~151 ~116 ~628 minecraft:light_gray_concrete replace
fill ~117 ~116 ~634 ~152 ~116 ~634 minecraft:light_gray_concrete replace
fill ~133 ~116 ~635 ~133 ~116 ~636 minecraft:light_gray_concrete replace
fill ~136 ~116 ~635 ~136 ~116 ~636 minecraft:light_gray_concrete replace
fill ~139 ~116 ~635 ~139 ~116 ~636 minecraft:light_gray_concrete replace
fill ~142 ~116 ~635 ~142 ~116 ~636 minecraft:light_gray_concrete replace
fill ~145 ~116 ~635 ~145 ~116 ~636 minecraft:light_gray_concrete replace
fill ~148 ~116 ~635 ~148 ~116 ~636 minecraft:light_gray_concrete replace
fill ~151 ~116 ~635 ~151 ~116 ~636 minecraft:light_gray_concrete replace
fill ~126 ~116 ~646 ~161 ~116 ~646 minecraft:light_gray_concrete replace
fill ~160 ~116 ~647 ~160 ~116 ~648 minecraft:light_gray_concrete replace
fill ~84 ~116 ~650 ~86 ~116 ~650 minecraft:light_gray_concrete replace
fill ~85 ~116 ~651 ~85 ~116 ~652 minecraft:light_gray_concrete replace
fill ~120 ~116 ~654 ~155 ~116 ~654 minecraft:light_gray_concrete replace
fill ~154 ~116 ~655 ~154 ~116 ~656 minecraft:light_gray_concrete replace
fill ~123 ~116 ~662 ~158 ~116 ~662 minecraft:light_gray_concrete replace
fill ~157 ~116 ~663 ~157 ~116 ~664 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~386 minecraft:light_gray_concrete replace
setblock ~117 ~117 ~386 minecraft:light_gray_concrete replace
setblock ~121 ~117 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~117 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~117 ~532 minecraft:light_gray_concrete replace
setblock ~79 ~117 ~536 minecraft:light_gray_concrete replace
setblock ~91 ~117 ~540 minecraft:light_gray_concrete replace
setblock ~94 ~117 ~544 minecraft:light_gray_concrete replace
setblock ~97 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~100 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~106 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~117 ~566 minecraft:light_gray_concrete replace
setblock ~97 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~103 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~109 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~118 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~578 minecraft:light_gray_concrete replace
setblock ~114 ~117 ~578 minecraft:light_gray_concrete replace
setblock ~97 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~100 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~103 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~106 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~602 minecraft:light_gray_concrete replace
setblock ~114 ~117 ~602 minecraft:light_gray_concrete replace
setblock ~100 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~106 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~109 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~124 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~127 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~117 ~610 minecraft:light_gray_concrete replace
setblock ~123 ~117 ~610 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~136 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~142 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~148 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~117 ~626 minecraft:light_gray_concrete replace
setblock ~123 ~117 ~626 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~139 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~145 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~151 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~124 ~117 ~634 minecraft:light_gray_concrete replace
setblock ~126 ~117 ~634 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~136 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~139 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~142 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~145 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~148 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~151 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~135 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~150 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~152 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~160 ~117 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~117 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~129 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~144 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~146 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~154 ~117 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~132 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~147 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~149 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~157 ~117 ~664 minecraft:light_gray_concrete replace
fill ~120 ~118 ~384 ~120 ~118 ~388 minecraft:light_gray_concrete replace
fill ~81 ~118 ~396 ~81 ~118 ~400 minecraft:light_gray_concrete replace
fill ~87 ~118 ~500 ~87 ~118 ~532 minecraft:light_gray_concrete replace
fill ~78 ~118 ~504 ~78 ~118 ~536 minecraft:light_gray_concrete replace
fill ~90 ~118 ~508 ~90 ~118 ~540 minecraft:light_gray_concrete replace
fill ~93 ~118 ~512 ~93 ~118 ~544 minecraft:light_gray_concrete replace
fill ~123 ~118 ~516 ~123 ~118 ~604 minecraft:light_gray_concrete replace
fill ~114 ~118 ~520 ~114 ~118 ~604 minecraft:light_gray_concrete replace
fill ~111 ~118 ~524 ~111 ~118 ~568 minecraft:light_gray_concrete replace
fill ~108 ~118 ~528 ~108 ~118 ~604 minecraft:light_gray_concrete replace
fill ~105 ~118 ~532 ~105 ~118 ~604 minecraft:light_gray_concrete replace
fill ~102 ~118 ~536 ~102 ~118 ~580 minecraft:light_gray_concrete replace
fill ~99 ~118 ~540 ~99 ~118 ~604 minecraft:light_gray_concrete replace
fill ~96 ~118 ~544 ~96 ~118 ~580 minecraft:light_gray_concrete replace
fill ~129 ~118 ~560 ~129 ~118 ~568 minecraft:light_gray_concrete replace
fill ~117 ~118 ~564 ~117 ~118 ~604 minecraft:light_gray_concrete replace
fill ~126 ~118 ~576 ~126 ~118 ~604 minecraft:light_gray_concrete replace
fill ~147 ~118 ~592 ~147 ~118 ~636 minecraft:light_gray_concrete replace
fill ~141 ~118 ~596 ~141 ~118 ~636 minecraft:light_gray_concrete replace
fill ~138 ~118 ~600 ~138 ~118 ~636 minecraft:light_gray_concrete replace
fill ~135 ~118 ~604 ~135 ~118 ~636 minecraft:light_gray_concrete replace
fill ~132 ~118 ~608 ~132 ~118 ~636 minecraft:light_gray_concrete replace
fill ~150 ~118 ~620 ~150 ~118 ~636 minecraft:light_gray_concrete replace
fill ~144 ~118 ~624 ~144 ~118 ~636 minecraft:light_gray_concrete replace
fill ~159 ~118 ~644 ~159 ~118 ~648 minecraft:light_gray_concrete replace
fill ~84 ~118 ~648 ~84 ~118 ~652 minecraft:light_gray_concrete replace
fill ~153 ~118 ~652 ~153 ~118 ~656 minecraft:light_gray_concrete replace
fill ~156 ~118 ~660 ~156 ~118 ~664 minecraft:light_gray_concrete replace
setblock ~120 ~119 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~119 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~499 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~501 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~503 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~503 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~505 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~507 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~507 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~509 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~511 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~511 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~513 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~515 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~515 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~517 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~517 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~519 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~519 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~521 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~523 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~523 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~529 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~531 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~531 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~533 minecraft:light_gray_concrete replace
setblock ~102 ~119 ~535 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~537 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~539 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~539 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~96 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~97 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~96 ~119 ~551 minecraft:light_gray_concrete replace
setblock ~102 ~119 ~551 minecraft:light_gray_concrete replace
setblock ~96 ~119 ~553 minecraft:light_gray_concrete replace
setblock ~102 ~119 ~553 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~553 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~555 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~129 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~129 ~119 ~561 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~563 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~565 minecraft:light_gray_concrete replace
setblock ~97 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~103 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~577 minecraft:light_gray_concrete replace
setblock ~106 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~115 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~593 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~595 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~597 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~599 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~603 minecraft:light_gray_concrete replace
setblock ~100 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~106 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~124 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~127 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~609 minecraft:light_gray_concrete replace
setblock ~136 ~119 ~612 minecraft:light_gray_concrete replace
setblock ~142 ~119 ~612 minecraft:light_gray_concrete replace
setblock ~148 ~119 ~612 minecraft:light_gray_concrete replace
setblock ~150 ~119 ~619 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~150 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~144 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~150 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~144 ~119 ~625 minecraft:light_gray_concrete replace
setblock ~139 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~145 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~151 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~133 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~139 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~142 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~148 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~151 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~159 ~119 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~119 ~647 minecraft:light_gray_concrete replace
setblock ~153 ~119 ~651 minecraft:light_gray_concrete replace
setblock ~156 ~119 ~659 minecraft:light_gray_concrete replace
fill ~106 ~120 ~380 ~106 ~120 ~381 minecraft:light_gray_concrete replace
fill ~105 ~120 ~382 ~120 ~120 ~382 minecraft:light_gray_concrete replace
fill ~82 ~120 ~392 ~82 ~120 ~393 minecraft:light_gray_concrete replace
fill ~81 ~120 ~394 ~83 ~120 ~394 minecraft:light_gray_concrete replace
fill ~88 ~120 ~496 ~88 ~120 ~497 minecraft:light_gray_concrete replace
fill ~87 ~120 ~498 ~89 ~120 ~498 minecraft:light_gray_concrete replace
fill ~79 ~120 ~500 ~79 ~120 ~501 minecraft:light_gray_concrete replace
fill ~78 ~120 ~502 ~80 ~120 ~502 minecraft:light_gray_concrete replace
fill ~91 ~120 ~504 ~91 ~120 ~505 minecraft:light_gray_concrete replace
fill ~90 ~120 ~506 ~92 ~120 ~506 minecraft:light_gray_concrete replace
fill ~94 ~120 ~508 ~94 ~120 ~509 minecraft:light_gray_concrete replace
fill ~93 ~120 ~510 ~95 ~120 ~510 minecraft:light_gray_concrete replace
fill ~109 ~120 ~512 ~109 ~120 ~513 minecraft:light_gray_concrete replace
fill ~108 ~120 ~514 ~123 ~120 ~514 minecraft:light_gray_concrete replace
fill ~103 ~120 ~516 ~103 ~120 ~517 minecraft:light_gray_concrete replace
fill ~102 ~120 ~518 ~114 ~120 ~518 minecraft:light_gray_concrete replace
fill ~103 ~120 ~520 ~103 ~120 ~521 minecraft:light_gray_concrete replace
fill ~102 ~120 ~522 ~111 ~120 ~522 minecraft:light_gray_concrete replace
fill ~100 ~120 ~524 ~100 ~120 ~525 minecraft:light_gray_concrete replace
fill ~99 ~120 ~526 ~108 ~120 ~526 minecraft:light_gray_concrete replace
fill ~100 ~120 ~528 ~100 ~120 ~529 minecraft:light_gray_concrete replace
fill ~99 ~120 ~530 ~105 ~120 ~530 minecraft:light_gray_concrete replace
fill ~100 ~120 ~532 ~100 ~120 ~533 minecraft:light_gray_concrete replace
fill ~99 ~120 ~534 ~102 ~120 ~534 minecraft:light_gray_concrete replace
fill ~97 ~120 ~536 ~97 ~120 ~537 minecraft:light_gray_concrete replace
fill ~96 ~120 ~538 ~99 ~120 ~538 minecraft:light_gray_concrete replace
fill ~97 ~120 ~540 ~97 ~120 ~541 minecraft:light_gray_concrete replace
fill ~96 ~120 ~542 ~98 ~120 ~542 minecraft:light_gray_concrete replace
fill ~109 ~120 ~556 ~109 ~120 ~557 minecraft:light_gray_concrete replace
fill ~108 ~120 ~558 ~129 ~120 ~558 minecraft:light_gray_concrete replace
fill ~103 ~120 ~560 ~103 ~120 ~561 minecraft:light_gray_concrete replace
fill ~102 ~120 ~562 ~117 ~120 ~562 minecraft:light_gray_concrete replace
fill ~109 ~120 ~572 ~109 ~120 ~573 minecraft:light_gray_concrete replace
fill ~108 ~120 ~574 ~126 ~120 ~574 minecraft:light_gray_concrete replace
fill ~121 ~120 ~588 ~121 ~120 ~589 minecraft:light_gray_concrete replace
fill ~120 ~120 ~590 ~147 ~120 ~590 minecraft:light_gray_concrete replace
fill ~118 ~120 ~592 ~118 ~120 ~593 minecraft:light_gray_concrete replace
fill ~117 ~120 ~594 ~141 ~120 ~594 minecraft:light_gray_concrete replace
fill ~115 ~120 ~596 ~115 ~120 ~597 minecraft:light_gray_concrete replace
fill ~114 ~120 ~598 ~138 ~120 ~598 minecraft:light_gray_concrete replace
fill ~115 ~120 ~600 ~115 ~120 ~601 minecraft:light_gray_concrete replace
fill ~114 ~120 ~602 ~135 ~120 ~602 minecraft:light_gray_concrete replace
fill ~112 ~120 ~604 ~112 ~120 ~605 minecraft:light_gray_concrete replace
fill ~111 ~120 ~606 ~132 ~120 ~606 minecraft:light_gray_concrete replace
fill ~121 ~120 ~616 ~121 ~120 ~617 minecraft:light_gray_concrete replace
fill ~120 ~120 ~618 ~150 ~120 ~618 minecraft:light_gray_concrete replace
fill ~118 ~120 ~620 ~118 ~120 ~621 minecraft:light_gray_concrete replace
fill ~117 ~120 ~622 ~144 ~120 ~622 minecraft:light_gray_concrete replace
fill ~130 ~120 ~640 ~130 ~120 ~641 minecraft:light_gray_concrete replace
fill ~129 ~120 ~642 ~159 ~120 ~642 minecraft:light_gray_concrete replace
fill ~85 ~120 ~644 ~85 ~120 ~645 minecraft:light_gray_concrete replace
fill ~84 ~120 ~646 ~86 ~120 ~646 minecraft:light_gray_concrete replace
fill ~124 ~120 ~648 ~124 ~120 ~649 minecraft:light_gray_concrete replace
fill ~123 ~120 ~650 ~153 ~120 ~650 minecraft:light_gray_concrete replace
fill ~127 ~120 ~656 ~127 ~120 ~657 minecraft:light_gray_concrete replace
fill ~126 ~120 ~658 ~156 ~120 ~658 minecraft:light_gray_concrete replace
setblock ~106 ~121 ~380 minecraft:light_gray_concrete replace
setblock ~111 ~121 ~382 minecraft:light_gray_concrete replace
setblock ~113 ~121 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~121 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~121 ~496 minecraft:light_gray_concrete replace
setblock ~79 ~121 ~500 minecraft:light_gray_concrete replace
setblock ~91 ~121 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~121 ~508 minecraft:light_gray_concrete replace
setblock ~109 ~121 ~512 minecraft:light_gray_concrete replace
setblock ~103 ~121 ~516 minecraft:light_gray_concrete replace
setblock ~104 ~121 ~518 minecraft:light_gray_concrete replace
setblock ~106 ~121 ~518 minecraft:light_gray_concrete replace
setblock ~103 ~121 ~520 minecraft:light_gray_concrete replace
setblock ~100 ~121 ~524 minecraft:light_gray_concrete replace
setblock ~100 ~121 ~528 minecraft:light_gray_concrete replace
setblock ~100 ~121 ~532 minecraft:light_gray_concrete replace
setblock ~97 ~121 ~536 minecraft:light_gray_concrete replace
setblock ~97 ~121 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~121 ~556 minecraft:light_gray_concrete replace
setblock ~114 ~121 ~558 minecraft:light_gray_concrete replace
setblock ~116 ~121 ~558 minecraft:light_gray_concrete replace
setblock ~103 ~121 ~560 minecraft:light_gray_concrete replace
setblock ~109 ~121 ~572 minecraft:light_gray_concrete replace
setblock ~111 ~121 ~574 minecraft:light_gray_concrete replace
setblock ~113 ~121 ~574 minecraft:light_gray_concrete replace
setblock ~121 ~121 ~588 minecraft:light_gray_concrete replace
setblock ~132 ~121 ~590 minecraft:light_gray_concrete replace
setblock ~134 ~121 ~590 minecraft:light_gray_concrete replace
setblock ~118 ~121 ~592 minecraft:light_gray_concrete replace
setblock ~126 ~121 ~594 minecraft:light_gray_concrete replace
setblock ~128 ~121 ~594 minecraft:light_gray_concrete replace
setblock ~115 ~121 ~596 minecraft:light_gray_concrete replace
setblock ~128 ~121 ~598 minecraft:light_gray_concrete replace
setblock ~130 ~121 ~598 minecraft:light_gray_concrete replace
setblock ~115 ~121 ~600 minecraft:light_gray_concrete replace
setblock ~121 ~121 ~602 minecraft:light_gray_concrete replace
setblock ~123 ~121 ~602 minecraft:light_gray_concrete replace
setblock ~112 ~121 ~604 minecraft:light_gray_concrete replace
setblock ~117 ~121 ~606 minecraft:light_gray_concrete replace
setblock ~119 ~121 ~606 minecraft:light_gray_concrete replace
setblock ~121 ~121 ~616 minecraft:light_gray_concrete replace
setblock ~137 ~121 ~618 minecraft:light_gray_concrete replace
setblock ~139 ~121 ~618 minecraft:light_gray_concrete replace
setblock ~118 ~121 ~620 minecraft:light_gray_concrete replace
setblock ~129 ~121 ~622 minecraft:light_gray_concrete replace
setblock ~131 ~121 ~622 minecraft:light_gray_concrete replace
setblock ~130 ~121 ~640 minecraft:light_gray_concrete replace
setblock ~133 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~135 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~150 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~152 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~121 ~644 minecraft:light_gray_concrete replace
setblock ~124 ~121 ~648 minecraft:light_gray_concrete replace
setblock ~127 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~129 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~144 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~146 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~121 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~121 ~658 minecraft:light_gray_concrete replace
setblock ~132 ~121 ~658 minecraft:light_gray_concrete replace
setblock ~147 ~121 ~658 minecraft:light_gray_concrete replace
setblock ~149 ~121 ~658 minecraft:light_gray_concrete replace
fill ~105 ~122 ~380 ~105 ~122 ~384 minecraft:light_gray_concrete replace
fill ~81 ~122 ~392 ~81 ~122 ~396 minecraft:light_gray_concrete replace
fill ~87 ~122 ~496 ~87 ~122 ~500 minecraft:light_gray_concrete replace
fill ~78 ~122 ~500 ~78 ~122 ~504 minecraft:light_gray_concrete replace
fill ~90 ~122 ~504 ~90 ~122 ~508 minecraft:light_gray_concrete replace
fill ~93 ~122 ~508 ~93 ~122 ~512 minecraft:light_gray_concrete replace
fill ~108 ~122 ~512 ~108 ~122 ~576 minecraft:light_gray_concrete replace
fill ~102 ~122 ~516 ~102 ~122 ~564 minecraft:light_gray_concrete replace
fill ~99 ~122 ~524 ~99 ~122 ~536 minecraft:light_gray_concrete replace
fill ~96 ~122 ~536 ~96 ~122 ~544 minecraft:light_gray_concrete replace
fill ~120 ~122 ~588 ~120 ~122 ~620 minecraft:light_gray_concrete replace
fill ~117 ~122 ~592 ~117 ~122 ~624 minecraft:light_gray_concrete replace
fill ~114 ~122 ~596 ~114 ~122 ~604 minecraft:light_gray_concrete replace
fill ~111 ~122 ~604 ~111 ~122 ~608 minecraft:light_gray_concrete replace
fill ~129 ~122 ~640 ~129 ~122 ~644 minecraft:light_gray_concrete replace
fill ~84 ~122 ~644 ~84 ~122 ~648 minecraft:light_gray_concrete replace
fill ~123 ~122 ~648 ~123 ~122 ~652 minecraft:light_gray_concrete replace
fill ~126 ~122 ~656 ~126 ~122 ~660 minecraft:light_gray_concrete replace
setblock ~105 ~123 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~123 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~123 ~501 minecraft:light_gray_concrete replace
setblock ~78 ~123 ~505 minecraft:light_gray_concrete replace
setblock ~90 ~123 ~509 minecraft:light_gray_concrete replace
setblock ~109 ~123 ~512 minecraft:light_gray_concrete replace
setblock ~93 ~123 ~513 minecraft:light_gray_concrete replace
setblock ~103 ~123 ~516 minecraft:light_gray_concrete replace
setblock ~103 ~123 ~520 minecraft:light_gray_concrete replace
setblock ~100 ~123 ~524 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~525 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~527 minecraft:light_gray_concrete replace
setblock ~100 ~123 ~528 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~529 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~531 minecraft:light_gray_concrete replace
setblock ~100 ~123 ~532 minecraft:light_gray_concrete replace
setblock ~99 ~123 ~535 minecraft:light_gray_concrete replace
setblock ~97 ~123 ~536 minecraft:light_gray_concrete replace
setblock ~99 ~123 ~537 minecraft:light_gray_concrete replace
setblock ~97 ~123 ~540 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~541 minecraft:light_gray_concrete replace
setblock ~96 ~123 ~543 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~543 minecraft:light_gray_concrete replace
setblock ~96 ~123 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~547 minecraft:light_gray_concrete replace
setblock ~109 ~123 ~556 minecraft:light_gray_concrete replace
setblock ~103 ~123 ~560 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~565 minecraft:light_gray_concrete replace
setblock ~109 ~123 ~572 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~577 minecraft:light_gray_concrete replace
setblock ~121 ~123 ~588 minecraft:light_gray_concrete replace
setblock ~118 ~123 ~592 minecraft:light_gray_concrete replace
setblock ~115 ~123 ~596 minecraft:light_gray_concrete replace
setblock ~115 ~123 ~600 minecraft:light_gray_concrete replace
setblock ~120 ~123 ~601 minecraft:light_gray_concrete replace
setblock ~114 ~123 ~603 minecraft:light_gray_concrete replace
setblock ~120 ~123 ~603 minecraft:light_gray_concrete replace
setblock ~112 ~123 ~604 minecraft:light_gray_concrete replace
setblock ~114 ~123 ~605 minecraft:light_gray_concrete replace
setblock ~117 ~123 ~605 minecraft:light_gray_concrete replace
setblock ~117 ~123 ~607 minecraft:light_gray_concrete replace
setblock ~111 ~123 ~609 minecraft:light_gray_concrete replace
setblock ~121 ~123 ~616 minecraft:light_gray_concrete replace
setblock ~118 ~123 ~620 minecraft:light_gray_concrete replace
setblock ~120 ~123 ~621 minecraft:light_gray_concrete replace
setblock ~117 ~123 ~625 minecraft:light_gray_concrete replace
setblock ~129 ~123 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~123 ~649 minecraft:light_gray_concrete replace
setblock ~123 ~123 ~653 minecraft:light_gray_concrete replace
setblock ~126 ~123 ~661 minecraft:light_gray_concrete replace
fill ~105 ~124 ~386 ~119 ~124 ~386 minecraft:light_gray_concrete replace
fill ~118 ~124 ~387 ~118 ~124 ~388 minecraft:light_gray_concrete replace
fill ~81 ~124 ~398 ~83 ~124 ~398 minecraft:light_gray_concrete replace
fill ~82 ~124 ~399 ~82 ~124 ~400 minecraft:light_gray_concrete replace
fill ~87 ~124 ~502 ~89 ~124 ~502 minecraft:light_gray_concrete replace
fill ~88 ~124 ~503 ~88 ~124 ~504 minecraft:light_gray_concrete replace
fill ~78 ~124 ~506 ~80 ~124 ~506 minecraft:light_gray_concrete replace
fill ~79 ~124 ~507 ~79 ~124 ~508 minecraft:light_gray_concrete replace
fill ~90 ~124 ~510 ~92 ~124 ~510 minecraft:light_gray_concrete replace
fill ~91 ~124 ~511 ~91 ~124 ~512 minecraft:light_gray_concrete replace
fill ~93 ~124 ~514 ~122 ~124 ~514 minecraft:light_gray_concrete replace
fill ~94 ~124 ~515 ~94 ~124 ~516 minecraft:light_gray_concrete replace
fill ~97 ~124 ~515 ~97 ~124 ~516 minecraft:light_gray_concrete replace
fill ~100 ~124 ~515 ~100 ~124 ~516 minecraft:light_gray_concrete replace
fill ~103 ~124 ~515 ~103 ~124 ~516 minecraft:light_gray_concrete replace
fill ~106 ~124 ~515 ~106 ~124 ~516 minecraft:light_gray_concrete replace
fill ~109 ~124 ~515 ~109 ~124 ~516 minecraft:light_gray_concrete replace
fill ~112 ~124 ~515 ~112 ~124 ~516 minecraft:light_gray_concrete replace
fill ~121 ~124 ~515 ~121 ~124 ~516 minecraft:light_gray_concrete replace
fill ~93 ~124 ~538 ~128 ~124 ~538 minecraft:light_gray_concrete replace
fill ~94 ~124 ~539 ~94 ~124 ~540 minecraft:light_gray_concrete replace
fill ~100 ~124 ~539 ~100 ~124 ~540 minecraft:light_gray_concrete replace
fill ~103 ~124 ~539 ~103 ~124 ~540 minecraft:light_gray_concrete replace
fill ~106 ~124 ~539 ~106 ~124 ~540 minecraft:light_gray_concrete replace
fill ~112 ~124 ~539 ~112 ~124 ~540 minecraft:light_gray_concrete replace
fill ~115 ~124 ~539 ~115 ~124 ~540 minecraft:light_gray_concrete replace
fill ~127 ~124 ~539 ~127 ~124 ~540 minecraft:light_gray_concrete replace
fill ~93 ~124 ~546 ~125 ~124 ~546 minecraft:light_gray_concrete replace
fill ~94 ~124 ~547 ~94 ~124 ~548 minecraft:light_gray_concrete replace
fill ~97 ~124 ~547 ~97 ~124 ~548 minecraft:light_gray_concrete replace
fill ~103 ~124 ~547 ~103 ~124 ~548 minecraft:light_gray_concrete replace
fill ~109 ~124 ~547 ~109 ~124 ~548 minecraft:light_gray_concrete replace
fill ~115 ~124 ~547 ~115 ~124 ~548 minecraft:light_gray_concrete replace
fill ~124 ~124 ~547 ~124 ~124 ~548 minecraft:light_gray_concrete replace
fill ~96 ~124 ~566 ~128 ~124 ~566 minecraft:light_gray_concrete replace
fill ~97 ~124 ~567 ~97 ~124 ~568 minecraft:light_gray_concrete replace
fill ~100 ~124 ~567 ~100 ~124 ~568 minecraft:light_gray_concrete replace
fill ~106 ~124 ~567 ~106 ~124 ~568 minecraft:light_gray_concrete replace
fill ~112 ~124 ~567 ~112 ~124 ~568 minecraft:light_gray_concrete replace
fill ~115 ~124 ~567 ~115 ~124 ~568 minecraft:light_gray_concrete replace
fill ~121 ~124 ~567 ~121 ~124 ~568 minecraft:light_gray_concrete replace
fill ~127 ~124 ~567 ~127 ~124 ~568 minecraft:light_gray_concrete replace
fill ~108 ~124 ~578 ~161 ~124 ~578 minecraft:light_gray_concrete replace
fill ~130 ~124 ~579 ~130 ~124 ~580 minecraft:light_gray_concrete replace
fill ~133 ~124 ~579 ~133 ~124 ~580 minecraft:light_gray_concrete replace
fill ~136 ~124 ~579 ~136 ~124 ~580 minecraft:light_gray_concrete replace
fill ~139 ~124 ~579 ~139 ~124 ~580 minecraft:light_gray_concrete replace
fill ~142 ~124 ~579 ~142 ~124 ~580 minecraft:light_gray_concrete replace
fill ~145 ~124 ~579 ~145 ~124 ~580 minecraft:light_gray_concrete replace
fill ~148 ~124 ~579 ~148 ~124 ~580 minecraft:light_gray_concrete replace
fill ~160 ~124 ~579 ~160 ~124 ~580 minecraft:light_gray_concrete replace
fill ~114 ~124 ~606 ~164 ~124 ~606 minecraft:light_gray_concrete replace
fill ~130 ~124 ~607 ~130 ~124 ~608 minecraft:light_gray_concrete replace
fill ~136 ~124 ~607 ~136 ~124 ~608 minecraft:light_gray_concrete replace
fill ~139 ~124 ~607 ~139 ~124 ~608 minecraft:light_gray_concrete replace
fill ~142 ~124 ~607 ~142 ~124 ~608 minecraft:light_gray_concrete replace
fill ~148 ~124 ~607 ~148 ~124 ~608 minecraft:light_gray_concrete replace
fill ~151 ~124 ~607 ~151 ~124 ~608 minecraft:light_gray_concrete replace
fill ~163 ~124 ~607 ~163 ~124 ~608 minecraft:light_gray_concrete replace
fill ~111 ~124 ~610 ~158 ~124 ~610 minecraft:light_gray_concrete replace
fill ~130 ~124 ~611 ~130 ~124 ~612 minecraft:light_gray_concrete replace
fill ~133 ~124 ~611 ~133 ~124 ~612 minecraft:light_gray_concrete replace
fill ~139 ~124 ~611 ~139 ~124 ~612 minecraft:light_gray_concrete replace
fill ~145 ~124 ~611 ~145 ~124 ~612 minecraft:light_gray_concrete replace
fill ~151 ~124 ~611 ~151 ~124 ~612 minecraft:light_gray_concrete replace
fill ~157 ~124 ~611 ~157 ~124 ~612 minecraft:light_gray_concrete replace
fill ~120 ~124 ~622 ~155 ~124 ~622 minecraft:light_gray_concrete replace
fill ~154 ~124 ~623 ~154 ~124 ~624 minecraft:light_gray_concrete replace
fill ~117 ~124 ~626 ~164 ~124 ~626 minecraft:light_gray_concrete replace
fill ~133 ~124 ~627 ~133 ~124 ~628 minecraft:light_gray_concrete replace
fill ~136 ~124 ~627 ~136 ~124 ~628 minecraft:light_gray_concrete replace
fill ~142 ~124 ~627 ~142 ~124 ~628 minecraft:light_gray_concrete replace
fill ~148 ~124 ~627 ~148 ~124 ~628 minecraft:light_gray_concrete replace
fill ~151 ~124 ~627 ~151 ~124 ~628 minecraft:light_gray_concrete replace
fill ~160 ~124 ~627 ~160 ~124 ~628 minecraft:light_gray_concrete replace
fill ~163 ~124 ~627 ~163 ~124 ~628 minecraft:light_gray_concrete replace
fill ~129 ~124 ~646 ~173 ~124 ~646 minecraft:light_gray_concrete replace
fill ~172 ~124 ~647 ~172 ~124 ~648 minecraft:light_gray_concrete replace
fill ~84 ~124 ~650 ~86 ~124 ~650 minecraft:light_gray_concrete replace
fill ~85 ~124 ~651 ~85 ~124 ~652 minecraft:light_gray_concrete replace
fill ~123 ~124 ~654 ~167 ~124 ~654 minecraft:light_gray_concrete replace
fill ~166 ~124 ~655 ~166 ~124 ~656 minecraft:light_gray_concrete replace
fill ~126 ~124 ~662 ~170 ~124 ~662 minecraft:light_gray_concrete replace
fill ~169 ~124 ~663 ~169 ~124 ~664 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~386 minecraft:light_gray_concrete replace
setblock ~114 ~125 ~386 minecraft:light_gray_concrete replace
setblock ~118 ~125 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~125 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~125 ~504 minecraft:light_gray_concrete replace
setblock ~79 ~125 ~508 minecraft:light_gray_concrete replace
setblock ~91 ~125 ~512 minecraft:light_gray_concrete replace
setblock ~94 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~97 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~100 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~103 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~106 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~109 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~94 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~100 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~103 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~106 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~94 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~97 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~97 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~106 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~578 minecraft:light_gray_concrete replace
setblock ~117 ~125 ~578 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~139 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~142 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~160 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~129 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~144 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~146 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~139 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~142 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~148 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~163 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~118 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~120 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~135 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~137 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~145 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~151 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~157 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~132 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~147 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~149 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~154 ~125 ~624 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~129 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~144 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~146 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~148 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~151 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~160 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~163 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~138 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~153 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~155 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~172 ~125 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~125 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~132 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~147 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~149 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~166 ~125 ~656 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~135 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~150 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~152 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~169 ~125 ~664 minecraft:light_gray_concrete replace
fill ~117 ~126 ~384 ~117 ~126 ~388 minecraft:light_gray_concrete replace
fill ~81 ~126 ~396 ~81 ~126 ~400 minecraft:light_gray_concrete replace
fill ~87 ~126 ~472 ~87 ~126 ~504 minecraft:light_gray_concrete replace
fill ~78 ~126 ~476 ~78 ~126 ~508 minecraft:light_gray_concrete replace
fill ~90 ~126 ~480 ~90 ~126 ~512 minecraft:light_gray_concrete replace
fill ~120 ~126 ~484 ~120 ~126 ~568 minecraft:light_gray_concrete replace
fill ~111 ~126 ~488 ~111 ~126 ~568 minecraft:light_gray_concrete replace
fill ~108 ~126 ~492 ~108 ~126 ~548 minecraft:light_gray_concrete replace
fill ~105 ~126 ~496 ~105 ~126 ~568 minecraft:light_gray_concrete replace
fill ~102 ~126 ~500 ~102 ~126 ~548 minecraft:light_gray_concrete replace
fill ~99 ~126 ~504 ~99 ~126 ~568 minecraft:light_gray_concrete replace
fill ~96 ~126 ~508 ~96 ~126 ~568 minecraft:light_gray_concrete replace
fill ~93 ~126 ~512 ~93 ~126 ~548 minecraft:light_gray_concrete replace
fill ~126 ~126 ~532 ~126 ~126 ~568 minecraft:light_gray_concrete replace
fill ~114 ~126 ~536 ~114 ~126 ~568 minecraft:light_gray_concrete replace
fill ~123 ~126 ~544 ~123 ~126 ~548 minecraft:light_gray_concrete replace
fill ~159 ~126 ~548 ~159 ~126 ~628 minecraft:light_gray_concrete replace
fill ~147 ~126 ~552 ~147 ~126 ~628 minecraft:light_gray_concrete replace
fill ~144 ~126 ~556 ~144 ~126 ~612 minecraft:light_gray_concrete replace
fill ~141 ~126 ~560 ~141 ~126 ~628 minecraft:light_gray_concrete replace
fill ~138 ~126 ~564 ~138 ~126 ~612 minecraft:light_gray_concrete replace
fill ~135 ~126 ~568 ~135 ~126 ~628 minecraft:light_gray_concrete replace
fill ~132 ~126 ~572 ~132 ~126 ~628 minecraft:light_gray_concrete replace
fill ~129 ~126 ~576 ~129 ~126 ~612 minecraft:light_gray_concrete replace
fill ~162 ~126 ~600 ~162 ~126 ~628 minecraft:light_gray_concrete replace
fill ~150 ~126 ~604 ~150 ~126 ~628 minecraft:light_gray_concrete replace
fill ~156 ~126 ~608 ~156 ~126 ~612 minecraft:light_gray_concrete replace
fill ~153 ~126 ~620 ~153 ~126 ~624 minecraft:light_gray_concrete replace
fill ~171 ~126 ~644 ~171 ~126 ~648 minecraft:light_gray_concrete replace
fill ~84 ~126 ~648 ~84 ~126 ~652 minecraft:light_gray_concrete replace
fill ~165 ~126 ~652 ~165 ~126 ~656 minecraft:light_gray_concrete replace
fill ~168 ~126 ~660 ~168 ~126 ~664 minecraft:light_gray_concrete replace
setblock ~117 ~127 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~127 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~471 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~473 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~475 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~475 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~477 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~479 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~479 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~481 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~483 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~483 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~487 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~489 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~489 minecraft:light_gray_concrete replace
setblock ~87 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~491 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~493 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~493 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~493 minecraft:light_gray_concrete replace
setblock ~78 ~127 ~495 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~495 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~497 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~497 minecraft:light_gray_concrete replace
setblock ~90 ~127 ~499 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~499 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~501 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~501 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~503 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~503 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~503 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~505 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~507 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~509 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~511 minecraft:light_gray_concrete replace
setblock ~97 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~103 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~127 ~516 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~517 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~517 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~517 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~519 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~519 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~519 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~521 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~521 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~523 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~525 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~525 minecraft:light_gray_concrete replace
setblock ~126 ~127 ~531 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~533 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~533 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~533 minecraft:light_gray_concrete replace
setblock ~93 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~102 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~108 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~114 ~127 ~535 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~537 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~537 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~539 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~539 minecraft:light_gray_concrete replace
setblock ~100 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~115 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~127 ~127 ~540 minecraft:light_gray_concrete replace
setblock ~123 ~127 ~543 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~547 minecraft:light_gray_concrete replace
setblock ~94 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~127 ~548 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~549 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~551 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~551 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~114 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~126 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~553 minecraft:light_gray_concrete replace
setblock ~96 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~99 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~105 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~111 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~114 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~120 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~126 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~557 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~559 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~563 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~565 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~567 minecraft:light_gray_concrete replace
setblock ~100 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~106 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~127 ~127 ~568 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~569 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~571 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~573 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~575 minecraft:light_gray_concrete replace
setblock ~133 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~139 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~160 ~127 ~580 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~581 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~583 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~597 minecraft:light_gray_concrete replace
setblock ~129 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~138 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~144 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~599 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~601 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~603 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~605 minecraft:light_gray_concrete replace
setblock ~156 ~127 ~607 minecraft:light_gray_concrete replace
setblock ~136 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~148 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~163 ~127 ~608 minecraft:light_gray_concrete replace
setblock ~130 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~145 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~157 ~127 ~612 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~147 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~613 minecraft:light_gray_concrete replace
setblock ~132 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~135 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~141 ~127 ~615 minecraft:light_gray_concrete replace
