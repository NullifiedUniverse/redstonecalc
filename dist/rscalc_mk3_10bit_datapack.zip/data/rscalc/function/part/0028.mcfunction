fill ~189 ~151 ~294 ~189 ~151 ~302 minecraft:redstone_wire replace
setblock ~231 ~151 ~294 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~151 ~296 ~186 ~151 ~302 minecraft:redstone_wire replace
fill ~231 ~151 ~296 ~231 ~151 ~308 minecraft:redstone_wire replace
fill ~183 ~151 ~300 ~183 ~151 ~302 minecraft:redstone_wire replace
setblock ~180 ~151 ~304 minecraft:redstone_wire replace
setblock ~183 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~305 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~306 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~151 ~306 ~180 ~151 ~318 minecraft:redstone_wire replace
fill ~183 ~151 ~306 ~183 ~151 ~318 minecraft:redstone_wire replace
fill ~186 ~151 ~306 ~186 ~151 ~318 minecraft:redstone_wire replace
fill ~189 ~151 ~306 ~189 ~151 ~318 minecraft:redstone_wire replace
fill ~192 ~151 ~306 ~192 ~151 ~318 minecraft:redstone_wire replace
fill ~195 ~151 ~306 ~195 ~151 ~318 minecraft:redstone_wire replace
fill ~198 ~151 ~306 ~198 ~151 ~318 minecraft:redstone_wire replace
fill ~201 ~151 ~306 ~201 ~151 ~318 minecraft:redstone_wire replace
fill ~204 ~151 ~306 ~204 ~151 ~318 minecraft:redstone_wire replace
fill ~207 ~151 ~306 ~207 ~151 ~318 minecraft:redstone_wire replace
fill ~210 ~151 ~306 ~210 ~151 ~318 minecraft:redstone_wire replace
fill ~213 ~151 ~306 ~213 ~151 ~318 minecraft:redstone_wire replace
fill ~216 ~151 ~306 ~216 ~151 ~318 minecraft:redstone_wire replace
fill ~219 ~151 ~306 ~219 ~151 ~318 minecraft:redstone_wire replace
fill ~222 ~151 ~306 ~222 ~151 ~318 minecraft:redstone_wire replace
fill ~225 ~151 ~306 ~225 ~151 ~318 minecraft:redstone_wire replace
fill ~228 ~151 ~306 ~228 ~151 ~318 minecraft:redstone_wire replace
fill ~81 ~151 ~308 ~81 ~151 ~320 minecraft:redstone_wire replace
setblock ~177 ~151 ~308 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~151 ~310 ~177 ~151 ~318 minecraft:redstone_wire replace
setblock ~231 ~151 ~310 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~151 ~312 ~174 ~151 ~318 minecraft:redstone_wire replace
fill ~231 ~151 ~312 ~231 ~151 ~324 minecraft:redstone_wire replace
fill ~171 ~151 ~316 ~171 ~151 ~318 minecraft:redstone_wire replace
setblock ~168 ~151 ~320 minecraft:redstone_wire replace
setblock ~171 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~321 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~322 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~151 ~322 ~168 ~151 ~334 minecraft:redstone_wire replace
fill ~171 ~151 ~322 ~171 ~151 ~334 minecraft:redstone_wire replace
fill ~174 ~151 ~322 ~174 ~151 ~334 minecraft:redstone_wire replace
fill ~177 ~151 ~322 ~177 ~151 ~334 minecraft:redstone_wire replace
fill ~180 ~151 ~322 ~180 ~151 ~334 minecraft:redstone_wire replace
fill ~183 ~151 ~322 ~183 ~151 ~334 minecraft:redstone_wire replace
fill ~186 ~151 ~322 ~186 ~151 ~334 minecraft:redstone_wire replace
fill ~189 ~151 ~322 ~189 ~151 ~334 minecraft:redstone_wire replace
fill ~192 ~151 ~322 ~192 ~151 ~334 minecraft:redstone_wire replace
fill ~195 ~151 ~322 ~195 ~151 ~334 minecraft:redstone_wire replace
fill ~198 ~151 ~322 ~198 ~151 ~334 minecraft:redstone_wire replace
fill ~201 ~151 ~322 ~201 ~151 ~334 minecraft:redstone_wire replace
fill ~204 ~151 ~322 ~204 ~151 ~334 minecraft:redstone_wire replace
fill ~207 ~151 ~322 ~207 ~151 ~334 minecraft:redstone_wire replace
fill ~210 ~151 ~322 ~210 ~151 ~334 minecraft:redstone_wire replace
fill ~213 ~151 ~322 ~213 ~151 ~334 minecraft:redstone_wire replace
fill ~216 ~151 ~322 ~216 ~151 ~334 minecraft:redstone_wire replace
fill ~219 ~151 ~322 ~219 ~151 ~334 minecraft:redstone_wire replace
fill ~222 ~151 ~322 ~222 ~151 ~334 minecraft:redstone_wire replace
fill ~225 ~151 ~322 ~225 ~151 ~334 minecraft:redstone_wire replace
fill ~228 ~151 ~322 ~228 ~151 ~334 minecraft:redstone_wire replace
fill ~81 ~151 ~324 ~81 ~151 ~336 minecraft:redstone_wire replace
setblock ~165 ~151 ~324 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~151 ~326 ~165 ~151 ~334 minecraft:redstone_wire replace
setblock ~231 ~151 ~326 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~151 ~328 ~162 ~151 ~334 minecraft:redstone_wire replace
fill ~231 ~151 ~328 ~231 ~151 ~340 minecraft:redstone_wire replace
fill ~159 ~151 ~332 ~159 ~151 ~334 minecraft:redstone_wire replace
setblock ~156 ~151 ~336 minecraft:redstone_wire replace
setblock ~159 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~337 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~338 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~151 ~338 ~156 ~151 ~350 minecraft:redstone_wire replace
fill ~159 ~151 ~338 ~159 ~151 ~350 minecraft:redstone_wire replace
fill ~162 ~151 ~338 ~162 ~151 ~350 minecraft:redstone_wire replace
fill ~165 ~151 ~338 ~165 ~151 ~350 minecraft:redstone_wire replace
fill ~168 ~151 ~338 ~168 ~151 ~350 minecraft:redstone_wire replace
fill ~171 ~151 ~338 ~171 ~151 ~350 minecraft:redstone_wire replace
fill ~174 ~151 ~338 ~174 ~151 ~350 minecraft:redstone_wire replace
fill ~177 ~151 ~338 ~177 ~151 ~350 minecraft:redstone_wire replace
fill ~180 ~151 ~338 ~180 ~151 ~350 minecraft:redstone_wire replace
fill ~183 ~151 ~338 ~183 ~151 ~350 minecraft:redstone_wire replace
fill ~186 ~151 ~338 ~186 ~151 ~350 minecraft:redstone_wire replace
fill ~189 ~151 ~338 ~189 ~151 ~350 minecraft:redstone_wire replace
fill ~192 ~151 ~338 ~192 ~151 ~350 minecraft:redstone_wire replace
fill ~195 ~151 ~338 ~195 ~151 ~350 minecraft:redstone_wire replace
fill ~198 ~151 ~338 ~198 ~151 ~350 minecraft:redstone_wire replace
fill ~201 ~151 ~338 ~201 ~151 ~350 minecraft:redstone_wire replace
fill ~204 ~151 ~338 ~204 ~151 ~350 minecraft:redstone_wire replace
fill ~207 ~151 ~338 ~207 ~151 ~350 minecraft:redstone_wire replace
fill ~210 ~151 ~338 ~210 ~151 ~350 minecraft:redstone_wire replace
fill ~213 ~151 ~338 ~213 ~151 ~350 minecraft:redstone_wire replace
fill ~216 ~151 ~338 ~216 ~151 ~350 minecraft:redstone_wire replace
fill ~219 ~151 ~338 ~219 ~151 ~350 minecraft:redstone_wire replace
fill ~222 ~151 ~338 ~222 ~151 ~350 minecraft:redstone_wire replace
fill ~225 ~151 ~338 ~225 ~151 ~350 minecraft:redstone_wire replace
fill ~228 ~151 ~338 ~228 ~151 ~350 minecraft:redstone_wire replace
fill ~81 ~151 ~340 ~81 ~151 ~352 minecraft:redstone_wire replace
setblock ~153 ~151 ~340 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~151 ~342 ~153 ~151 ~350 minecraft:redstone_wire replace
setblock ~231 ~151 ~342 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~151 ~344 ~150 ~151 ~350 minecraft:redstone_wire replace
fill ~231 ~151 ~344 ~231 ~151 ~356 minecraft:redstone_wire replace
fill ~147 ~151 ~348 ~147 ~151 ~350 minecraft:redstone_wire replace
setblock ~144 ~151 ~352 minecraft:redstone_wire replace
setblock ~147 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~353 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~354 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~151 ~354 ~144 ~151 ~366 minecraft:redstone_wire replace
fill ~147 ~151 ~354 ~147 ~151 ~366 minecraft:redstone_wire replace
fill ~150 ~151 ~354 ~150 ~151 ~366 minecraft:redstone_wire replace
fill ~153 ~151 ~354 ~153 ~151 ~366 minecraft:redstone_wire replace
fill ~156 ~151 ~354 ~156 ~151 ~366 minecraft:redstone_wire replace
fill ~159 ~151 ~354 ~159 ~151 ~366 minecraft:redstone_wire replace
fill ~162 ~151 ~354 ~162 ~151 ~366 minecraft:redstone_wire replace
fill ~165 ~151 ~354 ~165 ~151 ~366 minecraft:redstone_wire replace
fill ~168 ~151 ~354 ~168 ~151 ~366 minecraft:redstone_wire replace
fill ~171 ~151 ~354 ~171 ~151 ~366 minecraft:redstone_wire replace
fill ~174 ~151 ~354 ~174 ~151 ~366 minecraft:redstone_wire replace
fill ~177 ~151 ~354 ~177 ~151 ~366 minecraft:redstone_wire replace
fill ~180 ~151 ~354 ~180 ~151 ~366 minecraft:redstone_wire replace
fill ~183 ~151 ~354 ~183 ~151 ~366 minecraft:redstone_wire replace
fill ~186 ~151 ~354 ~186 ~151 ~366 minecraft:redstone_wire replace
fill ~189 ~151 ~354 ~189 ~151 ~366 minecraft:redstone_wire replace
fill ~192 ~151 ~354 ~192 ~151 ~366 minecraft:redstone_wire replace
fill ~195 ~151 ~354 ~195 ~151 ~366 minecraft:redstone_wire replace
fill ~198 ~151 ~354 ~198 ~151 ~366 minecraft:redstone_wire replace
fill ~201 ~151 ~354 ~201 ~151 ~366 minecraft:redstone_wire replace
fill ~204 ~151 ~354 ~204 ~151 ~366 minecraft:redstone_wire replace
fill ~207 ~151 ~354 ~207 ~151 ~366 minecraft:redstone_wire replace
fill ~210 ~151 ~354 ~210 ~151 ~366 minecraft:redstone_wire replace
fill ~213 ~151 ~354 ~213 ~151 ~366 minecraft:redstone_wire replace
fill ~216 ~151 ~354 ~216 ~151 ~366 minecraft:redstone_wire replace
fill ~219 ~151 ~354 ~219 ~151 ~366 minecraft:redstone_wire replace
fill ~222 ~151 ~354 ~222 ~151 ~366 minecraft:redstone_wire replace
fill ~225 ~151 ~354 ~225 ~151 ~366 minecraft:redstone_wire replace
fill ~228 ~151 ~354 ~228 ~151 ~366 minecraft:redstone_wire replace
fill ~81 ~151 ~356 ~81 ~151 ~368 minecraft:redstone_wire replace
setblock ~141 ~151 ~356 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~151 ~358 ~141 ~151 ~366 minecraft:redstone_wire replace
setblock ~231 ~151 ~358 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~151 ~360 ~138 ~151 ~366 minecraft:redstone_wire replace
fill ~231 ~151 ~360 ~231 ~151 ~372 minecraft:redstone_wire replace
fill ~135 ~151 ~364 ~135 ~151 ~366 minecraft:redstone_wire replace
setblock ~132 ~151 ~368 minecraft:redstone_wire replace
setblock ~135 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~369 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~370 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~151 ~370 ~132 ~151 ~382 minecraft:redstone_wire replace
fill ~135 ~151 ~370 ~135 ~151 ~382 minecraft:redstone_wire replace
fill ~138 ~151 ~370 ~138 ~151 ~382 minecraft:redstone_wire replace
fill ~141 ~151 ~370 ~141 ~151 ~382 minecraft:redstone_wire replace
fill ~144 ~151 ~370 ~144 ~151 ~382 minecraft:redstone_wire replace
fill ~147 ~151 ~370 ~147 ~151 ~382 minecraft:redstone_wire replace
fill ~150 ~151 ~370 ~150 ~151 ~382 minecraft:redstone_wire replace
fill ~153 ~151 ~370 ~153 ~151 ~382 minecraft:redstone_wire replace
fill ~156 ~151 ~370 ~156 ~151 ~382 minecraft:redstone_wire replace
fill ~159 ~151 ~370 ~159 ~151 ~382 minecraft:redstone_wire replace
fill ~162 ~151 ~370 ~162 ~151 ~382 minecraft:redstone_wire replace
fill ~165 ~151 ~370 ~165 ~151 ~382 minecraft:redstone_wire replace
fill ~168 ~151 ~370 ~168 ~151 ~382 minecraft:redstone_wire replace
fill ~171 ~151 ~370 ~171 ~151 ~382 minecraft:redstone_wire replace
fill ~174 ~151 ~370 ~174 ~151 ~382 minecraft:redstone_wire replace
fill ~177 ~151 ~370 ~177 ~151 ~382 minecraft:redstone_wire replace
fill ~180 ~151 ~370 ~180 ~151 ~382 minecraft:redstone_wire replace
fill ~183 ~151 ~370 ~183 ~151 ~382 minecraft:redstone_wire replace
fill ~186 ~151 ~370 ~186 ~151 ~382 minecraft:redstone_wire replace
fill ~189 ~151 ~370 ~189 ~151 ~382 minecraft:redstone_wire replace
fill ~192 ~151 ~370 ~192 ~151 ~382 minecraft:redstone_wire replace
fill ~195 ~151 ~370 ~195 ~151 ~382 minecraft:redstone_wire replace
fill ~198 ~151 ~370 ~198 ~151 ~382 minecraft:redstone_wire replace
fill ~201 ~151 ~370 ~201 ~151 ~382 minecraft:redstone_wire replace
fill ~204 ~151 ~370 ~204 ~151 ~382 minecraft:redstone_wire replace
fill ~207 ~151 ~370 ~207 ~151 ~382 minecraft:redstone_wire replace
fill ~210 ~151 ~370 ~210 ~151 ~382 minecraft:redstone_wire replace
fill ~213 ~151 ~370 ~213 ~151 ~382 minecraft:redstone_wire replace
fill ~216 ~151 ~370 ~216 ~151 ~382 minecraft:redstone_wire replace
fill ~219 ~151 ~370 ~219 ~151 ~382 minecraft:redstone_wire replace
fill ~222 ~151 ~370 ~222 ~151 ~382 minecraft:redstone_wire replace
fill ~225 ~151 ~370 ~225 ~151 ~382 minecraft:redstone_wire replace
fill ~228 ~151 ~370 ~228 ~151 ~382 minecraft:redstone_wire replace
fill ~81 ~151 ~372 ~81 ~151 ~384 minecraft:redstone_wire replace
setblock ~129 ~151 ~372 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~151 ~374 ~129 ~151 ~382 minecraft:redstone_wire replace
setblock ~231 ~151 ~374 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~151 ~376 ~126 ~151 ~382 minecraft:redstone_wire replace
fill ~231 ~151 ~376 ~231 ~151 ~388 minecraft:redstone_wire replace
fill ~123 ~151 ~380 ~123 ~151 ~382 minecraft:redstone_wire replace
setblock ~120 ~151 ~384 minecraft:redstone_wire replace
setblock ~123 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~386 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~151 ~386 ~120 ~151 ~398 minecraft:redstone_wire replace
fill ~123 ~151 ~386 ~123 ~151 ~398 minecraft:redstone_wire replace
fill ~126 ~151 ~386 ~126 ~151 ~398 minecraft:redstone_wire replace
fill ~129 ~151 ~386 ~129 ~151 ~398 minecraft:redstone_wire replace
fill ~132 ~151 ~386 ~132 ~151 ~398 minecraft:redstone_wire replace
fill ~135 ~151 ~386 ~135 ~151 ~398 minecraft:redstone_wire replace
fill ~138 ~151 ~386 ~138 ~151 ~398 minecraft:redstone_wire replace
fill ~141 ~151 ~386 ~141 ~151 ~398 minecraft:redstone_wire replace
fill ~144 ~151 ~386 ~144 ~151 ~398 minecraft:redstone_wire replace
fill ~147 ~151 ~386 ~147 ~151 ~398 minecraft:redstone_wire replace
fill ~150 ~151 ~386 ~150 ~151 ~398 minecraft:redstone_wire replace
fill ~153 ~151 ~386 ~153 ~151 ~398 minecraft:redstone_wire replace
fill ~156 ~151 ~386 ~156 ~151 ~398 minecraft:redstone_wire replace
fill ~159 ~151 ~386 ~159 ~151 ~398 minecraft:redstone_wire replace
fill ~162 ~151 ~386 ~162 ~151 ~398 minecraft:redstone_wire replace
fill ~165 ~151 ~386 ~165 ~151 ~398 minecraft:redstone_wire replace
fill ~168 ~151 ~386 ~168 ~151 ~398 minecraft:redstone_wire replace
fill ~171 ~151 ~386 ~171 ~151 ~398 minecraft:redstone_wire replace
fill ~174 ~151 ~386 ~174 ~151 ~398 minecraft:redstone_wire replace
fill ~177 ~151 ~386 ~177 ~151 ~398 minecraft:redstone_wire replace
fill ~180 ~151 ~386 ~180 ~151 ~398 minecraft:redstone_wire replace
fill ~183 ~151 ~386 ~183 ~151 ~398 minecraft:redstone_wire replace
fill ~186 ~151 ~386 ~186 ~151 ~398 minecraft:redstone_wire replace
fill ~189 ~151 ~386 ~189 ~151 ~398 minecraft:redstone_wire replace
fill ~192 ~151 ~386 ~192 ~151 ~398 minecraft:redstone_wire replace
fill ~195 ~151 ~386 ~195 ~151 ~398 minecraft:redstone_wire replace
fill ~198 ~151 ~386 ~198 ~151 ~398 minecraft:redstone_wire replace
fill ~201 ~151 ~386 ~201 ~151 ~398 minecraft:redstone_wire replace
fill ~204 ~151 ~386 ~204 ~151 ~398 minecraft:redstone_wire replace
fill ~207 ~151 ~386 ~207 ~151 ~398 minecraft:redstone_wire replace
fill ~210 ~151 ~386 ~210 ~151 ~398 minecraft:redstone_wire replace
fill ~213 ~151 ~386 ~213 ~151 ~398 minecraft:redstone_wire replace
fill ~216 ~151 ~386 ~216 ~151 ~398 minecraft:redstone_wire replace
fill ~219 ~151 ~386 ~219 ~151 ~398 minecraft:redstone_wire replace
fill ~222 ~151 ~386 ~222 ~151 ~398 minecraft:redstone_wire replace
fill ~225 ~151 ~386 ~225 ~151 ~398 minecraft:redstone_wire replace
fill ~228 ~151 ~386 ~228 ~151 ~398 minecraft:redstone_wire replace
fill ~81 ~151 ~388 ~81 ~151 ~400 minecraft:redstone_wire replace
setblock ~117 ~151 ~388 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~151 ~390 ~117 ~151 ~398 minecraft:redstone_wire replace
fill ~114 ~151 ~392 ~114 ~151 ~398 minecraft:redstone_wire replace
fill ~111 ~151 ~396 ~111 ~151 ~398 minecraft:redstone_wire replace
setblock ~108 ~151 ~400 minecraft:redstone_wire replace
setblock ~111 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~151 ~402 ~108 ~151 ~414 minecraft:redstone_wire replace
fill ~111 ~151 ~402 ~111 ~151 ~414 minecraft:redstone_wire replace
fill ~114 ~151 ~402 ~114 ~151 ~414 minecraft:redstone_wire replace
fill ~117 ~151 ~402 ~117 ~151 ~414 minecraft:redstone_wire replace
fill ~120 ~151 ~402 ~120 ~151 ~414 minecraft:redstone_wire replace
fill ~123 ~151 ~402 ~123 ~151 ~414 minecraft:redstone_wire replace
fill ~126 ~151 ~402 ~126 ~151 ~414 minecraft:redstone_wire replace
fill ~129 ~151 ~402 ~129 ~151 ~414 minecraft:redstone_wire replace
fill ~132 ~151 ~402 ~132 ~151 ~414 minecraft:redstone_wire replace
fill ~135 ~151 ~402 ~135 ~151 ~414 minecraft:redstone_wire replace
fill ~138 ~151 ~402 ~138 ~151 ~414 minecraft:redstone_wire replace
fill ~141 ~151 ~402 ~141 ~151 ~414 minecraft:redstone_wire replace
fill ~144 ~151 ~402 ~144 ~151 ~414 minecraft:redstone_wire replace
fill ~147 ~151 ~402 ~147 ~151 ~414 minecraft:redstone_wire replace
fill ~150 ~151 ~402 ~150 ~151 ~414 minecraft:redstone_wire replace
fill ~153 ~151 ~402 ~153 ~151 ~414 minecraft:redstone_wire replace
fill ~156 ~151 ~402 ~156 ~151 ~414 minecraft:redstone_wire replace
fill ~159 ~151 ~402 ~159 ~151 ~414 minecraft:redstone_wire replace
fill ~162 ~151 ~402 ~162 ~151 ~414 minecraft:redstone_wire replace
fill ~165 ~151 ~402 ~165 ~151 ~414 minecraft:redstone_wire replace
fill ~168 ~151 ~402 ~168 ~151 ~414 minecraft:redstone_wire replace
fill ~171 ~151 ~402 ~171 ~151 ~414 minecraft:redstone_wire replace
fill ~174 ~151 ~402 ~174 ~151 ~414 minecraft:redstone_wire replace
fill ~177 ~151 ~402 ~177 ~151 ~414 minecraft:redstone_wire replace
fill ~180 ~151 ~402 ~180 ~151 ~414 minecraft:redstone_wire replace
fill ~183 ~151 ~402 ~183 ~151 ~414 minecraft:redstone_wire replace
fill ~186 ~151 ~402 ~186 ~151 ~414 minecraft:redstone_wire replace
fill ~189 ~151 ~402 ~189 ~151 ~414 minecraft:redstone_wire replace
fill ~192 ~151 ~402 ~192 ~151 ~414 minecraft:redstone_wire replace
fill ~195 ~151 ~402 ~195 ~151 ~414 minecraft:redstone_wire replace
fill ~198 ~151 ~402 ~198 ~151 ~414 minecraft:redstone_wire replace
fill ~201 ~151 ~402 ~201 ~151 ~414 minecraft:redstone_wire replace
fill ~204 ~151 ~402 ~204 ~151 ~414 minecraft:redstone_wire replace
fill ~207 ~151 ~402 ~207 ~151 ~414 minecraft:redstone_wire replace
fill ~210 ~151 ~402 ~210 ~151 ~414 minecraft:redstone_wire replace
fill ~213 ~151 ~402 ~213 ~151 ~414 minecraft:redstone_wire replace
fill ~216 ~151 ~402 ~216 ~151 ~414 minecraft:redstone_wire replace
fill ~219 ~151 ~402 ~219 ~151 ~414 minecraft:redstone_wire replace
fill ~222 ~151 ~402 ~222 ~151 ~414 minecraft:redstone_wire replace
fill ~225 ~151 ~402 ~225 ~151 ~414 minecraft:redstone_wire replace
fill ~228 ~151 ~402 ~228 ~151 ~414 minecraft:redstone_wire replace
setblock ~105 ~151 ~404 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~151 ~406 ~105 ~151 ~414 minecraft:redstone_wire replace
fill ~102 ~151 ~408 ~102 ~151 ~414 minecraft:redstone_wire replace
fill ~99 ~151 ~412 ~99 ~151 ~414 minecraft:redstone_wire replace
setblock ~96 ~151 ~416 minecraft:redstone_wire replace
setblock ~99 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~151 ~418 ~96 ~151 ~430 minecraft:redstone_wire replace
fill ~99 ~151 ~418 ~99 ~151 ~430 minecraft:redstone_wire replace
fill ~102 ~151 ~418 ~102 ~151 ~430 minecraft:redstone_wire replace
fill ~105 ~151 ~418 ~105 ~151 ~430 minecraft:redstone_wire replace
fill ~108 ~151 ~418 ~108 ~151 ~430 minecraft:redstone_wire replace
fill ~111 ~151 ~418 ~111 ~151 ~430 minecraft:redstone_wire replace
fill ~114 ~151 ~418 ~114 ~151 ~430 minecraft:redstone_wire replace
fill ~117 ~151 ~418 ~117 ~151 ~430 minecraft:redstone_wire replace
fill ~120 ~151 ~418 ~120 ~151 ~430 minecraft:redstone_wire replace
fill ~123 ~151 ~418 ~123 ~151 ~430 minecraft:redstone_wire replace
fill ~126 ~151 ~418 ~126 ~151 ~430 minecraft:redstone_wire replace
fill ~129 ~151 ~418 ~129 ~151 ~430 minecraft:redstone_wire replace
fill ~132 ~151 ~418 ~132 ~151 ~430 minecraft:redstone_wire replace
fill ~135 ~151 ~418 ~135 ~151 ~430 minecraft:redstone_wire replace
fill ~138 ~151 ~418 ~138 ~151 ~430 minecraft:redstone_wire replace
fill ~141 ~151 ~418 ~141 ~151 ~430 minecraft:redstone_wire replace
fill ~144 ~151 ~418 ~144 ~151 ~430 minecraft:redstone_wire replace
fill ~147 ~151 ~418 ~147 ~151 ~430 minecraft:redstone_wire replace
fill ~150 ~151 ~418 ~150 ~151 ~430 minecraft:redstone_wire replace
fill ~153 ~151 ~418 ~153 ~151 ~430 minecraft:redstone_wire replace
fill ~156 ~151 ~418 ~156 ~151 ~430 minecraft:redstone_wire replace
fill ~159 ~151 ~418 ~159 ~151 ~430 minecraft:redstone_wire replace
fill ~162 ~151 ~418 ~162 ~151 ~430 minecraft:redstone_wire replace
fill ~165 ~151 ~418 ~165 ~151 ~430 minecraft:redstone_wire replace
fill ~168 ~151 ~418 ~168 ~151 ~430 minecraft:redstone_wire replace
fill ~171 ~151 ~418 ~171 ~151 ~430 minecraft:redstone_wire replace
fill ~174 ~151 ~418 ~174 ~151 ~430 minecraft:redstone_wire replace
fill ~177 ~151 ~418 ~177 ~151 ~430 minecraft:redstone_wire replace
fill ~180 ~151 ~418 ~180 ~151 ~430 minecraft:redstone_wire replace
fill ~183 ~151 ~418 ~183 ~151 ~430 minecraft:redstone_wire replace
fill ~186 ~151 ~418 ~186 ~151 ~430 minecraft:redstone_wire replace
fill ~189 ~151 ~418 ~189 ~151 ~430 minecraft:redstone_wire replace
fill ~192 ~151 ~418 ~192 ~151 ~430 minecraft:redstone_wire replace
fill ~195 ~151 ~418 ~195 ~151 ~430 minecraft:redstone_wire replace
fill ~198 ~151 ~418 ~198 ~151 ~430 minecraft:redstone_wire replace
fill ~201 ~151 ~418 ~201 ~151 ~430 minecraft:redstone_wire replace
fill ~204 ~151 ~418 ~204 ~151 ~430 minecraft:redstone_wire replace
fill ~207 ~151 ~418 ~207 ~151 ~430 minecraft:redstone_wire replace
fill ~210 ~151 ~418 ~210 ~151 ~430 minecraft:redstone_wire replace
fill ~213 ~151 ~418 ~213 ~151 ~430 minecraft:redstone_wire replace
fill ~216 ~151 ~418 ~216 ~151 ~430 minecraft:redstone_wire replace
fill ~219 ~151 ~418 ~219 ~151 ~430 minecraft:redstone_wire replace
fill ~222 ~151 ~418 ~222 ~151 ~430 minecraft:redstone_wire replace
fill ~225 ~151 ~418 ~225 ~151 ~430 minecraft:redstone_wire replace
fill ~228 ~151 ~418 ~228 ~151 ~430 minecraft:redstone_wire replace
setblock ~93 ~151 ~420 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~151 ~422 ~93 ~151 ~430 minecraft:redstone_wire replace
fill ~90 ~151 ~424 ~90 ~151 ~430 minecraft:redstone_wire replace
fill ~87 ~151 ~428 ~87 ~151 ~430 minecraft:redstone_wire replace
setblock ~84 ~151 ~432 minecraft:redstone_wire replace
setblock ~87 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~84 ~151 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~434 ~84 ~151 ~446 minecraft:redstone_wire replace
fill ~87 ~151 ~434 ~87 ~151 ~446 minecraft:redstone_wire replace
fill ~90 ~151 ~434 ~90 ~151 ~446 minecraft:redstone_wire replace
fill ~93 ~151 ~434 ~93 ~151 ~446 minecraft:redstone_wire replace
fill ~96 ~151 ~434 ~96 ~151 ~446 minecraft:redstone_wire replace
fill ~99 ~151 ~434 ~99 ~151 ~446 minecraft:redstone_wire replace
fill ~102 ~151 ~434 ~102 ~151 ~446 minecraft:redstone_wire replace
fill ~105 ~151 ~434 ~105 ~151 ~446 minecraft:redstone_wire replace
fill ~108 ~151 ~434 ~108 ~151 ~446 minecraft:redstone_wire replace
fill ~111 ~151 ~434 ~111 ~151 ~446 minecraft:redstone_wire replace
fill ~114 ~151 ~434 ~114 ~151 ~446 minecraft:redstone_wire replace
fill ~117 ~151 ~434 ~117 ~151 ~446 minecraft:redstone_wire replace
fill ~120 ~151 ~434 ~120 ~151 ~446 minecraft:redstone_wire replace
fill ~123 ~151 ~434 ~123 ~151 ~446 minecraft:redstone_wire replace
fill ~126 ~151 ~434 ~126 ~151 ~446 minecraft:redstone_wire replace
fill ~129 ~151 ~434 ~129 ~151 ~446 minecraft:redstone_wire replace
fill ~132 ~151 ~434 ~132 ~151 ~446 minecraft:redstone_wire replace
fill ~135 ~151 ~434 ~135 ~151 ~446 minecraft:redstone_wire replace
fill ~138 ~151 ~434 ~138 ~151 ~446 minecraft:redstone_wire replace
fill ~141 ~151 ~434 ~141 ~151 ~446 minecraft:redstone_wire replace
fill ~144 ~151 ~434 ~144 ~151 ~446 minecraft:redstone_wire replace
fill ~147 ~151 ~434 ~147 ~151 ~446 minecraft:redstone_wire replace
fill ~150 ~151 ~434 ~150 ~151 ~446 minecraft:redstone_wire replace
fill ~153 ~151 ~434 ~153 ~151 ~446 minecraft:redstone_wire replace
fill ~156 ~151 ~434 ~156 ~151 ~446 minecraft:redstone_wire replace
fill ~159 ~151 ~434 ~159 ~151 ~446 minecraft:redstone_wire replace
fill ~162 ~151 ~434 ~162 ~151 ~446 minecraft:redstone_wire replace
fill ~165 ~151 ~434 ~165 ~151 ~446 minecraft:redstone_wire replace
fill ~168 ~151 ~434 ~168 ~151 ~446 minecraft:redstone_wire replace
fill ~171 ~151 ~434 ~171 ~151 ~446 minecraft:redstone_wire replace
fill ~174 ~151 ~434 ~174 ~151 ~446 minecraft:redstone_wire replace
fill ~177 ~151 ~434 ~177 ~151 ~446 minecraft:redstone_wire replace
fill ~180 ~151 ~434 ~180 ~151 ~446 minecraft:redstone_wire replace
fill ~183 ~151 ~434 ~183 ~151 ~446 minecraft:redstone_wire replace
fill ~186 ~151 ~434 ~186 ~151 ~446 minecraft:redstone_wire replace
fill ~189 ~151 ~434 ~189 ~151 ~446 minecraft:redstone_wire replace
fill ~192 ~151 ~434 ~192 ~151 ~446 minecraft:redstone_wire replace
fill ~195 ~151 ~434 ~195 ~151 ~446 minecraft:redstone_wire replace
fill ~198 ~151 ~434 ~198 ~151 ~446 minecraft:redstone_wire replace
fill ~201 ~151 ~434 ~201 ~151 ~446 minecraft:redstone_wire replace
fill ~204 ~151 ~434 ~204 ~151 ~446 minecraft:redstone_wire replace
fill ~207 ~151 ~434 ~207 ~151 ~446 minecraft:redstone_wire replace
fill ~210 ~151 ~434 ~210 ~151 ~446 minecraft:redstone_wire replace
fill ~213 ~151 ~434 ~213 ~151 ~446 minecraft:redstone_wire replace
fill ~216 ~151 ~434 ~216 ~151 ~446 minecraft:redstone_wire replace
fill ~219 ~151 ~434 ~219 ~151 ~446 minecraft:redstone_wire replace
fill ~222 ~151 ~434 ~222 ~151 ~446 minecraft:redstone_wire replace
fill ~225 ~151 ~434 ~225 ~151 ~446 minecraft:redstone_wire replace
fill ~228 ~151 ~434 ~228 ~151 ~446 minecraft:redstone_wire replace
setblock ~84 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~151 ~448 ~78 ~151 ~452 minecraft:redstone_wire replace
fill ~84 ~151 ~448 ~84 ~151 ~460 minecraft:redstone_wire replace
fill ~87 ~151 ~448 ~87 ~151 ~460 minecraft:redstone_wire replace
fill ~90 ~151 ~448 ~90 ~151 ~460 minecraft:redstone_wire replace
fill ~93 ~151 ~448 ~93 ~151 ~460 minecraft:redstone_wire replace
fill ~96 ~151 ~448 ~96 ~151 ~460 minecraft:redstone_wire replace
fill ~99 ~151 ~448 ~99 ~151 ~460 minecraft:redstone_wire replace
fill ~102 ~151 ~448 ~102 ~151 ~460 minecraft:redstone_wire replace
fill ~105 ~151 ~448 ~105 ~151 ~460 minecraft:redstone_wire replace
fill ~108 ~151 ~448 ~108 ~151 ~460 minecraft:redstone_wire replace
fill ~111 ~151 ~448 ~111 ~151 ~460 minecraft:redstone_wire replace
fill ~114 ~151 ~448 ~114 ~151 ~460 minecraft:redstone_wire replace
fill ~117 ~151 ~448 ~117 ~151 ~460 minecraft:redstone_wire replace
fill ~120 ~151 ~448 ~120 ~151 ~460 minecraft:redstone_wire replace
fill ~123 ~151 ~448 ~123 ~151 ~460 minecraft:redstone_wire replace
fill ~126 ~151 ~448 ~126 ~151 ~460 minecraft:redstone_wire replace
fill ~129 ~151 ~448 ~129 ~151 ~460 minecraft:redstone_wire replace
fill ~132 ~151 ~448 ~132 ~151 ~460 minecraft:redstone_wire replace
fill ~135 ~151 ~448 ~135 ~151 ~460 minecraft:redstone_wire replace
fill ~138 ~151 ~448 ~138 ~151 ~460 minecraft:redstone_wire replace
fill ~141 ~151 ~448 ~141 ~151 ~460 minecraft:redstone_wire replace
fill ~144 ~151 ~448 ~144 ~151 ~460 minecraft:redstone_wire replace
fill ~147 ~151 ~448 ~147 ~151 ~460 minecraft:redstone_wire replace
fill ~150 ~151 ~448 ~150 ~151 ~460 minecraft:redstone_wire replace
fill ~153 ~151 ~448 ~153 ~151 ~460 minecraft:redstone_wire replace
fill ~156 ~151 ~448 ~156 ~151 ~460 minecraft:redstone_wire replace
fill ~159 ~151 ~448 ~159 ~151 ~460 minecraft:redstone_wire replace
fill ~162 ~151 ~448 ~162 ~151 ~460 minecraft:redstone_wire replace
fill ~165 ~151 ~448 ~165 ~151 ~460 minecraft:redstone_wire replace
fill ~168 ~151 ~448 ~168 ~151 ~460 minecraft:redstone_wire replace
fill ~171 ~151 ~448 ~171 ~151 ~460 minecraft:redstone_wire replace
fill ~174 ~151 ~448 ~174 ~151 ~460 minecraft:redstone_wire replace
fill ~177 ~151 ~448 ~177 ~151 ~460 minecraft:redstone_wire replace
fill ~180 ~151 ~448 ~180 ~151 ~460 minecraft:redstone_wire replace
fill ~183 ~151 ~448 ~183 ~151 ~460 minecraft:redstone_wire replace
fill ~186 ~151 ~448 ~186 ~151 ~460 minecraft:redstone_wire replace
fill ~189 ~151 ~448 ~189 ~151 ~460 minecraft:redstone_wire replace
fill ~192 ~151 ~448 ~192 ~151 ~460 minecraft:redstone_wire replace
fill ~195 ~151 ~448 ~195 ~151 ~460 minecraft:redstone_wire replace
fill ~198 ~151 ~448 ~198 ~151 ~460 minecraft:redstone_wire replace
fill ~201 ~151 ~448 ~201 ~151 ~460 minecraft:redstone_wire replace
fill ~204 ~151 ~448 ~204 ~151 ~460 minecraft:redstone_wire replace
fill ~207 ~151 ~448 ~207 ~151 ~460 minecraft:redstone_wire replace
fill ~210 ~151 ~448 ~210 ~151 ~460 minecraft:redstone_wire replace
fill ~213 ~151 ~448 ~213 ~151 ~460 minecraft:redstone_wire replace
fill ~216 ~151 ~448 ~216 ~151 ~460 minecraft:redstone_wire replace
fill ~219 ~151 ~448 ~219 ~151 ~460 minecraft:redstone_wire replace
fill ~222 ~151 ~448 ~222 ~151 ~460 minecraft:redstone_wire replace
fill ~225 ~151 ~448 ~225 ~151 ~460 minecraft:redstone_wire replace
fill ~228 ~151 ~448 ~228 ~151 ~460 minecraft:redstone_wire replace
setblock ~84 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~464 ~84 ~151 ~476 minecraft:redstone_wire replace
fill ~87 ~151 ~464 ~87 ~151 ~476 minecraft:redstone_wire replace
fill ~90 ~151 ~464 ~90 ~151 ~476 minecraft:redstone_wire replace
fill ~93 ~151 ~464 ~93 ~151 ~476 minecraft:redstone_wire replace
fill ~96 ~151 ~464 ~96 ~151 ~476 minecraft:redstone_wire replace
fill ~99 ~151 ~464 ~99 ~151 ~476 minecraft:redstone_wire replace
fill ~102 ~151 ~464 ~102 ~151 ~476 minecraft:redstone_wire replace
fill ~105 ~151 ~464 ~105 ~151 ~476 minecraft:redstone_wire replace
fill ~108 ~151 ~464 ~108 ~151 ~476 minecraft:redstone_wire replace
fill ~111 ~151 ~464 ~111 ~151 ~476 minecraft:redstone_wire replace
fill ~114 ~151 ~464 ~114 ~151 ~476 minecraft:redstone_wire replace
fill ~117 ~151 ~464 ~117 ~151 ~476 minecraft:redstone_wire replace
fill ~120 ~151 ~464 ~120 ~151 ~476 minecraft:redstone_wire replace
fill ~123 ~151 ~464 ~123 ~151 ~476 minecraft:redstone_wire replace
fill ~126 ~151 ~464 ~126 ~151 ~476 minecraft:redstone_wire replace
fill ~129 ~151 ~464 ~129 ~151 ~476 minecraft:redstone_wire replace
fill ~132 ~151 ~464 ~132 ~151 ~476 minecraft:redstone_wire replace
fill ~135 ~151 ~464 ~135 ~151 ~476 minecraft:redstone_wire replace
fill ~138 ~151 ~464 ~138 ~151 ~476 minecraft:redstone_wire replace
fill ~141 ~151 ~464 ~141 ~151 ~476 minecraft:redstone_wire replace
fill ~144 ~151 ~464 ~144 ~151 ~476 minecraft:redstone_wire replace
fill ~147 ~151 ~464 ~147 ~151 ~476 minecraft:redstone_wire replace
fill ~150 ~151 ~464 ~150 ~151 ~476 minecraft:redstone_wire replace
fill ~153 ~151 ~464 ~153 ~151 ~476 minecraft:redstone_wire replace
fill ~156 ~151 ~464 ~156 ~151 ~476 minecraft:redstone_wire replace
fill ~159 ~151 ~464 ~159 ~151 ~476 minecraft:redstone_wire replace
fill ~162 ~151 ~464 ~162 ~151 ~476 minecraft:redstone_wire replace
fill ~165 ~151 ~464 ~165 ~151 ~476 minecraft:redstone_wire replace
fill ~168 ~151 ~464 ~168 ~151 ~476 minecraft:redstone_wire replace
fill ~171 ~151 ~464 ~171 ~151 ~476 minecraft:redstone_wire replace
fill ~174 ~151 ~464 ~174 ~151 ~476 minecraft:redstone_wire replace
fill ~177 ~151 ~464 ~177 ~151 ~476 minecraft:redstone_wire replace
fill ~180 ~151 ~464 ~180 ~151 ~476 minecraft:redstone_wire replace
fill ~183 ~151 ~464 ~183 ~151 ~476 minecraft:redstone_wire replace
fill ~186 ~151 ~464 ~186 ~151 ~476 minecraft:redstone_wire replace
fill ~189 ~151 ~464 ~189 ~151 ~476 minecraft:redstone_wire replace
fill ~192 ~151 ~464 ~192 ~151 ~476 minecraft:redstone_wire replace
fill ~195 ~151 ~464 ~195 ~151 ~476 minecraft:redstone_wire replace
fill ~198 ~151 ~464 ~198 ~151 ~476 minecraft:redstone_wire replace
fill ~201 ~151 ~464 ~201 ~151 ~476 minecraft:redstone_wire replace
fill ~204 ~151 ~464 ~204 ~151 ~476 minecraft:redstone_wire replace
fill ~207 ~151 ~464 ~207 ~151 ~476 minecraft:redstone_wire replace
fill ~210 ~151 ~464 ~210 ~151 ~476 minecraft:redstone_wire replace
fill ~213 ~151 ~464 ~213 ~151 ~476 minecraft:redstone_wire replace
fill ~216 ~151 ~464 ~216 ~151 ~476 minecraft:redstone_wire replace
fill ~219 ~151 ~464 ~219 ~151 ~476 minecraft:redstone_wire replace
fill ~222 ~151 ~464 ~222 ~151 ~476 minecraft:redstone_wire replace
fill ~225 ~151 ~464 ~225 ~151 ~476 minecraft:redstone_wire replace
fill ~228 ~151 ~464 ~228 ~151 ~476 minecraft:redstone_wire replace
setblock ~246 ~151 ~476 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~84 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~478 ~246 ~151 ~486 minecraft:redstone_wire replace
fill ~84 ~151 ~480 ~84 ~151 ~492 minecraft:redstone_wire replace
fill ~87 ~151 ~480 ~87 ~151 ~492 minecraft:redstone_wire replace
fill ~90 ~151 ~480 ~90 ~151 ~492 minecraft:redstone_wire replace
fill ~93 ~151 ~480 ~93 ~151 ~492 minecraft:redstone_wire replace
fill ~96 ~151 ~480 ~96 ~151 ~492 minecraft:redstone_wire replace
fill ~99 ~151 ~480 ~99 ~151 ~492 minecraft:redstone_wire replace
fill ~102 ~151 ~480 ~102 ~151 ~492 minecraft:redstone_wire replace
fill ~105 ~151 ~480 ~105 ~151 ~492 minecraft:redstone_wire replace
fill ~108 ~151 ~480 ~108 ~151 ~492 minecraft:redstone_wire replace
fill ~111 ~151 ~480 ~111 ~151 ~492 minecraft:redstone_wire replace
fill ~114 ~151 ~480 ~114 ~151 ~492 minecraft:redstone_wire replace
fill ~117 ~151 ~480 ~117 ~151 ~492 minecraft:redstone_wire replace
fill ~120 ~151 ~480 ~120 ~151 ~492 minecraft:redstone_wire replace
fill ~123 ~151 ~480 ~123 ~151 ~492 minecraft:redstone_wire replace
fill ~126 ~151 ~480 ~126 ~151 ~492 minecraft:redstone_wire replace
fill ~129 ~151 ~480 ~129 ~151 ~492 minecraft:redstone_wire replace
fill ~132 ~151 ~480 ~132 ~151 ~492 minecraft:redstone_wire replace
fill ~135 ~151 ~480 ~135 ~151 ~492 minecraft:redstone_wire replace
fill ~138 ~151 ~480 ~138 ~151 ~492 minecraft:redstone_wire replace
fill ~141 ~151 ~480 ~141 ~151 ~492 minecraft:redstone_wire replace
fill ~144 ~151 ~480 ~144 ~151 ~492 minecraft:redstone_wire replace
fill ~147 ~151 ~480 ~147 ~151 ~492 minecraft:redstone_wire replace
fill ~150 ~151 ~480 ~150 ~151 ~492 minecraft:redstone_wire replace
fill ~153 ~151 ~480 ~153 ~151 ~492 minecraft:redstone_wire replace
fill ~156 ~151 ~480 ~156 ~151 ~492 minecraft:redstone_wire replace
fill ~159 ~151 ~480 ~159 ~151 ~492 minecraft:redstone_wire replace
fill ~162 ~151 ~480 ~162 ~151 ~492 minecraft:redstone_wire replace
fill ~165 ~151 ~480 ~165 ~151 ~492 minecraft:redstone_wire replace
fill ~168 ~151 ~480 ~168 ~151 ~492 minecraft:redstone_wire replace
fill ~171 ~151 ~480 ~171 ~151 ~492 minecraft:redstone_wire replace
fill ~174 ~151 ~480 ~174 ~151 ~492 minecraft:redstone_wire replace
fill ~177 ~151 ~480 ~177 ~151 ~492 minecraft:redstone_wire replace
fill ~180 ~151 ~480 ~180 ~151 ~492 minecraft:redstone_wire replace
fill ~183 ~151 ~480 ~183 ~151 ~492 minecraft:redstone_wire replace
fill ~186 ~151 ~480 ~186 ~151 ~492 minecraft:redstone_wire replace
fill ~189 ~151 ~480 ~189 ~151 ~492 minecraft:redstone_wire replace
fill ~192 ~151 ~480 ~192 ~151 ~492 minecraft:redstone_wire replace
fill ~195 ~151 ~480 ~195 ~151 ~492 minecraft:redstone_wire replace
fill ~198 ~151 ~480 ~198 ~151 ~492 minecraft:redstone_wire replace
fill ~201 ~151 ~480 ~201 ~151 ~492 minecraft:redstone_wire replace
fill ~204 ~151 ~480 ~204 ~151 ~492 minecraft:redstone_wire replace
fill ~207 ~151 ~480 ~207 ~151 ~492 minecraft:redstone_wire replace
fill ~210 ~151 ~480 ~210 ~151 ~492 minecraft:redstone_wire replace
fill ~213 ~151 ~480 ~213 ~151 ~492 minecraft:redstone_wire replace
fill ~216 ~151 ~480 ~216 ~151 ~492 minecraft:redstone_wire replace
fill ~219 ~151 ~480 ~219 ~151 ~492 minecraft:redstone_wire replace
fill ~222 ~151 ~480 ~222 ~151 ~492 minecraft:redstone_wire replace
fill ~225 ~151 ~480 ~225 ~151 ~492 minecraft:redstone_wire replace
fill ~228 ~151 ~480 ~228 ~151 ~492 minecraft:redstone_wire replace
fill ~234 ~151 ~480 ~234 ~151 ~484 minecraft:redstone_wire replace
setblock ~246 ~151 ~488 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~490 ~246 ~151 ~502 minecraft:redstone_wire replace
setblock ~84 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~496 ~84 ~151 ~508 minecraft:redstone_wire replace
fill ~87 ~151 ~496 ~87 ~151 ~508 minecraft:redstone_wire replace
fill ~90 ~151 ~496 ~90 ~151 ~508 minecraft:redstone_wire replace
fill ~93 ~151 ~496 ~93 ~151 ~508 minecraft:redstone_wire replace
fill ~96 ~151 ~496 ~96 ~151 ~508 minecraft:redstone_wire replace
fill ~99 ~151 ~496 ~99 ~151 ~508 minecraft:redstone_wire replace
fill ~102 ~151 ~496 ~102 ~151 ~508 minecraft:redstone_wire replace
fill ~105 ~151 ~496 ~105 ~151 ~508 minecraft:redstone_wire replace
fill ~108 ~151 ~496 ~108 ~151 ~508 minecraft:redstone_wire replace
fill ~111 ~151 ~496 ~111 ~151 ~508 minecraft:redstone_wire replace
fill ~114 ~151 ~496 ~114 ~151 ~508 minecraft:redstone_wire replace
fill ~117 ~151 ~496 ~117 ~151 ~508 minecraft:redstone_wire replace
fill ~120 ~151 ~496 ~120 ~151 ~508 minecraft:redstone_wire replace
fill ~123 ~151 ~496 ~123 ~151 ~508 minecraft:redstone_wire replace
fill ~126 ~151 ~496 ~126 ~151 ~508 minecraft:redstone_wire replace
fill ~129 ~151 ~496 ~129 ~151 ~508 minecraft:redstone_wire replace
fill ~132 ~151 ~496 ~132 ~151 ~508 minecraft:redstone_wire replace
fill ~135 ~151 ~496 ~135 ~151 ~508 minecraft:redstone_wire replace
fill ~138 ~151 ~496 ~138 ~151 ~508 minecraft:redstone_wire replace
fill ~141 ~151 ~496 ~141 ~151 ~508 minecraft:redstone_wire replace
fill ~144 ~151 ~496 ~144 ~151 ~508 minecraft:redstone_wire replace
fill ~147 ~151 ~496 ~147 ~151 ~508 minecraft:redstone_wire replace
fill ~150 ~151 ~496 ~150 ~151 ~508 minecraft:redstone_wire replace
fill ~153 ~151 ~496 ~153 ~151 ~508 minecraft:redstone_wire replace
fill ~156 ~151 ~496 ~156 ~151 ~508 minecraft:redstone_wire replace
fill ~159 ~151 ~496 ~159 ~151 ~508 minecraft:redstone_wire replace
fill ~162 ~151 ~496 ~162 ~151 ~508 minecraft:redstone_wire replace
fill ~165 ~151 ~496 ~165 ~151 ~508 minecraft:redstone_wire replace
fill ~168 ~151 ~496 ~168 ~151 ~508 minecraft:redstone_wire replace
fill ~171 ~151 ~496 ~171 ~151 ~508 minecraft:redstone_wire replace
fill ~174 ~151 ~496 ~174 ~151 ~508 minecraft:redstone_wire replace
fill ~177 ~151 ~496 ~177 ~151 ~508 minecraft:redstone_wire replace
fill ~180 ~151 ~496 ~180 ~151 ~508 minecraft:redstone_wire replace
fill ~183 ~151 ~496 ~183 ~151 ~508 minecraft:redstone_wire replace
fill ~186 ~151 ~496 ~186 ~151 ~508 minecraft:redstone_wire replace
fill ~189 ~151 ~496 ~189 ~151 ~508 minecraft:redstone_wire replace
fill ~192 ~151 ~496 ~192 ~151 ~508 minecraft:redstone_wire replace
fill ~195 ~151 ~496 ~195 ~151 ~508 minecraft:redstone_wire replace
fill ~198 ~151 ~496 ~198 ~151 ~508 minecraft:redstone_wire replace
fill ~201 ~151 ~496 ~201 ~151 ~508 minecraft:redstone_wire replace
fill ~204 ~151 ~496 ~204 ~151 ~508 minecraft:redstone_wire replace
fill ~207 ~151 ~496 ~207 ~151 ~508 minecraft:redstone_wire replace
fill ~210 ~151 ~496 ~210 ~151 ~508 minecraft:redstone_wire replace
fill ~213 ~151 ~496 ~213 ~151 ~508 minecraft:redstone_wire replace
fill ~216 ~151 ~496 ~216 ~151 ~508 minecraft:redstone_wire replace
fill ~219 ~151 ~496 ~219 ~151 ~508 minecraft:redstone_wire replace
fill ~222 ~151 ~496 ~222 ~151 ~508 minecraft:redstone_wire replace
fill ~225 ~151 ~496 ~225 ~151 ~508 minecraft:redstone_wire replace
fill ~228 ~151 ~496 ~228 ~151 ~508 minecraft:redstone_wire replace
fill ~240 ~151 ~500 ~240 ~151 ~504 minecraft:redstone_wire replace
setblock ~246 ~151 ~503 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~504 ~246 ~151 ~516 minecraft:redstone_wire replace
setblock ~84 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~512 ~84 ~151 ~524 minecraft:redstone_wire replace
fill ~87 ~151 ~512 ~87 ~151 ~524 minecraft:redstone_wire replace
fill ~90 ~151 ~512 ~90 ~151 ~524 minecraft:redstone_wire replace
fill ~93 ~151 ~512 ~93 ~151 ~524 minecraft:redstone_wire replace
fill ~96 ~151 ~512 ~96 ~151 ~524 minecraft:redstone_wire replace
fill ~99 ~151 ~512 ~99 ~151 ~524 minecraft:redstone_wire replace
fill ~102 ~151 ~512 ~102 ~151 ~524 minecraft:redstone_wire replace
fill ~105 ~151 ~512 ~105 ~151 ~524 minecraft:redstone_wire replace
fill ~108 ~151 ~512 ~108 ~151 ~524 minecraft:redstone_wire replace
fill ~111 ~151 ~512 ~111 ~151 ~524 minecraft:redstone_wire replace
fill ~114 ~151 ~512 ~114 ~151 ~524 minecraft:redstone_wire replace
fill ~117 ~151 ~512 ~117 ~151 ~524 minecraft:redstone_wire replace
fill ~120 ~151 ~512 ~120 ~151 ~524 minecraft:redstone_wire replace
fill ~123 ~151 ~512 ~123 ~151 ~524 minecraft:redstone_wire replace
fill ~126 ~151 ~512 ~126 ~151 ~524 minecraft:redstone_wire replace
fill ~129 ~151 ~512 ~129 ~151 ~524 minecraft:redstone_wire replace
fill ~132 ~151 ~512 ~132 ~151 ~524 minecraft:redstone_wire replace
fill ~135 ~151 ~512 ~135 ~151 ~524 minecraft:redstone_wire replace
fill ~138 ~151 ~512 ~138 ~151 ~524 minecraft:redstone_wire replace
fill ~141 ~151 ~512 ~141 ~151 ~524 minecraft:redstone_wire replace
fill ~144 ~151 ~512 ~144 ~151 ~524 minecraft:redstone_wire replace
fill ~147 ~151 ~512 ~147 ~151 ~524 minecraft:redstone_wire replace
fill ~150 ~151 ~512 ~150 ~151 ~524 minecraft:redstone_wire replace
fill ~153 ~151 ~512 ~153 ~151 ~524 minecraft:redstone_wire replace
fill ~156 ~151 ~512 ~156 ~151 ~524 minecraft:redstone_wire replace
fill ~159 ~151 ~512 ~159 ~151 ~524 minecraft:redstone_wire replace
fill ~162 ~151 ~512 ~162 ~151 ~524 minecraft:redstone_wire replace
fill ~165 ~151 ~512 ~165 ~151 ~524 minecraft:redstone_wire replace
fill ~168 ~151 ~512 ~168 ~151 ~524 minecraft:redstone_wire replace
fill ~171 ~151 ~512 ~171 ~151 ~524 minecraft:redstone_wire replace
fill ~174 ~151 ~512 ~174 ~151 ~524 minecraft:redstone_wire replace
fill ~177 ~151 ~512 ~177 ~151 ~524 minecraft:redstone_wire replace
fill ~180 ~151 ~512 ~180 ~151 ~524 minecraft:redstone_wire replace
fill ~183 ~151 ~512 ~183 ~151 ~524 minecraft:redstone_wire replace
fill ~186 ~151 ~512 ~186 ~151 ~524 minecraft:redstone_wire replace
fill ~189 ~151 ~512 ~189 ~151 ~524 minecraft:redstone_wire replace
fill ~192 ~151 ~512 ~192 ~151 ~524 minecraft:redstone_wire replace
fill ~195 ~151 ~512 ~195 ~151 ~524 minecraft:redstone_wire replace
fill ~198 ~151 ~512 ~198 ~151 ~524 minecraft:redstone_wire replace
fill ~201 ~151 ~512 ~201 ~151 ~524 minecraft:redstone_wire replace
fill ~204 ~151 ~512 ~204 ~151 ~524 minecraft:redstone_wire replace
fill ~207 ~151 ~512 ~207 ~151 ~524 minecraft:redstone_wire replace
fill ~210 ~151 ~512 ~210 ~151 ~524 minecraft:redstone_wire replace
fill ~213 ~151 ~512 ~213 ~151 ~524 minecraft:redstone_wire replace
fill ~216 ~151 ~512 ~216 ~151 ~524 minecraft:redstone_wire replace
fill ~219 ~151 ~512 ~219 ~151 ~524 minecraft:redstone_wire replace
fill ~222 ~151 ~512 ~222 ~151 ~524 minecraft:redstone_wire replace
fill ~225 ~151 ~512 ~225 ~151 ~524 minecraft:redstone_wire replace
fill ~228 ~151 ~512 ~228 ~151 ~524 minecraft:redstone_wire replace
fill ~237 ~151 ~512 ~237 ~151 ~516 minecraft:redstone_wire replace
setblock ~246 ~151 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~520 ~246 ~151 ~532 minecraft:redstone_wire replace
setblock ~84 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~528 ~84 ~151 ~540 minecraft:redstone_wire replace
fill ~87 ~151 ~528 ~87 ~151 ~540 minecraft:redstone_wire replace
fill ~90 ~151 ~528 ~90 ~151 ~540 minecraft:redstone_wire replace
fill ~93 ~151 ~528 ~93 ~151 ~540 minecraft:redstone_wire replace
fill ~96 ~151 ~528 ~96 ~151 ~540 minecraft:redstone_wire replace
fill ~99 ~151 ~528 ~99 ~151 ~540 minecraft:redstone_wire replace
fill ~102 ~151 ~528 ~102 ~151 ~540 minecraft:redstone_wire replace
fill ~105 ~151 ~528 ~105 ~151 ~540 minecraft:redstone_wire replace
fill ~108 ~151 ~528 ~108 ~151 ~540 minecraft:redstone_wire replace
fill ~111 ~151 ~528 ~111 ~151 ~540 minecraft:redstone_wire replace
fill ~114 ~151 ~528 ~114 ~151 ~540 minecraft:redstone_wire replace
fill ~117 ~151 ~528 ~117 ~151 ~540 minecraft:redstone_wire replace
fill ~120 ~151 ~528 ~120 ~151 ~540 minecraft:redstone_wire replace
fill ~123 ~151 ~528 ~123 ~151 ~540 minecraft:redstone_wire replace
fill ~126 ~151 ~528 ~126 ~151 ~540 minecraft:redstone_wire replace
fill ~129 ~151 ~528 ~129 ~151 ~540 minecraft:redstone_wire replace
fill ~132 ~151 ~528 ~132 ~151 ~540 minecraft:redstone_wire replace
fill ~135 ~151 ~528 ~135 ~151 ~540 minecraft:redstone_wire replace
fill ~138 ~151 ~528 ~138 ~151 ~540 minecraft:redstone_wire replace
fill ~141 ~151 ~528 ~141 ~151 ~540 minecraft:redstone_wire replace
fill ~144 ~151 ~528 ~144 ~151 ~540 minecraft:redstone_wire replace
fill ~147 ~151 ~528 ~147 ~151 ~540 minecraft:redstone_wire replace
fill ~150 ~151 ~528 ~150 ~151 ~540 minecraft:redstone_wire replace
fill ~153 ~151 ~528 ~153 ~151 ~540 minecraft:redstone_wire replace
fill ~156 ~151 ~528 ~156 ~151 ~540 minecraft:redstone_wire replace
fill ~159 ~151 ~528 ~159 ~151 ~540 minecraft:redstone_wire replace
fill ~162 ~151 ~528 ~162 ~151 ~540 minecraft:redstone_wire replace
fill ~165 ~151 ~528 ~165 ~151 ~540 minecraft:redstone_wire replace
fill ~168 ~151 ~528 ~168 ~151 ~540 minecraft:redstone_wire replace
fill ~171 ~151 ~528 ~171 ~151 ~540 minecraft:redstone_wire replace
fill ~174 ~151 ~528 ~174 ~151 ~540 minecraft:redstone_wire replace
fill ~177 ~151 ~528 ~177 ~151 ~540 minecraft:redstone_wire replace
fill ~180 ~151 ~528 ~180 ~151 ~540 minecraft:redstone_wire replace
fill ~183 ~151 ~528 ~183 ~151 ~540 minecraft:redstone_wire replace
fill ~186 ~151 ~528 ~186 ~151 ~540 minecraft:redstone_wire replace
fill ~189 ~151 ~528 ~189 ~151 ~540 minecraft:redstone_wire replace
fill ~192 ~151 ~528 ~192 ~151 ~540 minecraft:redstone_wire replace
fill ~195 ~151 ~528 ~195 ~151 ~540 minecraft:redstone_wire replace
fill ~198 ~151 ~528 ~198 ~151 ~540 minecraft:redstone_wire replace
fill ~201 ~151 ~528 ~201 ~151 ~540 minecraft:redstone_wire replace
fill ~204 ~151 ~528 ~204 ~151 ~540 minecraft:redstone_wire replace
fill ~207 ~151 ~528 ~207 ~151 ~540 minecraft:redstone_wire replace
fill ~210 ~151 ~528 ~210 ~151 ~540 minecraft:redstone_wire replace
fill ~213 ~151 ~528 ~213 ~151 ~540 minecraft:redstone_wire replace
fill ~216 ~151 ~528 ~216 ~151 ~540 minecraft:redstone_wire replace
fill ~219 ~151 ~528 ~219 ~151 ~540 minecraft:redstone_wire replace
fill ~222 ~151 ~528 ~222 ~151 ~540 minecraft:redstone_wire replace
fill ~225 ~151 ~528 ~225 ~151 ~540 minecraft:redstone_wire replace
fill ~228 ~151 ~528 ~228 ~151 ~540 minecraft:redstone_wire replace
setblock ~246 ~151 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~151 ~536 ~243 ~151 ~540 minecraft:redstone_wire replace
fill ~246 ~151 ~536 ~246 ~151 ~548 minecraft:redstone_wire replace
setblock ~255 ~151 ~540 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~84 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~255 ~151 ~542 ~255 ~151 ~548 minecraft:redstone_wire replace
fill ~84 ~151 ~544 ~84 ~151 ~556 minecraft:redstone_wire replace
fill ~87 ~151 ~544 ~87 ~151 ~556 minecraft:redstone_wire replace
fill ~90 ~151 ~544 ~90 ~151 ~556 minecraft:redstone_wire replace
fill ~93 ~151 ~544 ~93 ~151 ~556 minecraft:redstone_wire replace
fill ~96 ~151 ~544 ~96 ~151 ~556 minecraft:redstone_wire replace
fill ~99 ~151 ~544 ~99 ~151 ~556 minecraft:redstone_wire replace
fill ~102 ~151 ~544 ~102 ~151 ~556 minecraft:redstone_wire replace
fill ~105 ~151 ~544 ~105 ~151 ~556 minecraft:redstone_wire replace
fill ~108 ~151 ~544 ~108 ~151 ~556 minecraft:redstone_wire replace
fill ~111 ~151 ~544 ~111 ~151 ~556 minecraft:redstone_wire replace
fill ~114 ~151 ~544 ~114 ~151 ~556 minecraft:redstone_wire replace
fill ~117 ~151 ~544 ~117 ~151 ~556 minecraft:redstone_wire replace
fill ~120 ~151 ~544 ~120 ~151 ~556 minecraft:redstone_wire replace
fill ~123 ~151 ~544 ~123 ~151 ~556 minecraft:redstone_wire replace
fill ~126 ~151 ~544 ~126 ~151 ~556 minecraft:redstone_wire replace
fill ~129 ~151 ~544 ~129 ~151 ~556 minecraft:redstone_wire replace
fill ~132 ~151 ~544 ~132 ~151 ~556 minecraft:redstone_wire replace
fill ~135 ~151 ~544 ~135 ~151 ~556 minecraft:redstone_wire replace
fill ~138 ~151 ~544 ~138 ~151 ~556 minecraft:redstone_wire replace
fill ~141 ~151 ~544 ~141 ~151 ~556 minecraft:redstone_wire replace
fill ~144 ~151 ~544 ~144 ~151 ~556 minecraft:redstone_wire replace
fill ~147 ~151 ~544 ~147 ~151 ~556 minecraft:redstone_wire replace
fill ~150 ~151 ~544 ~150 ~151 ~556 minecraft:redstone_wire replace
fill ~153 ~151 ~544 ~153 ~151 ~556 minecraft:redstone_wire replace
fill ~156 ~151 ~544 ~156 ~151 ~556 minecraft:redstone_wire replace
fill ~159 ~151 ~544 ~159 ~151 ~556 minecraft:redstone_wire replace
fill ~162 ~151 ~544 ~162 ~151 ~556 minecraft:redstone_wire replace
fill ~165 ~151 ~544 ~165 ~151 ~556 minecraft:redstone_wire replace
fill ~168 ~151 ~544 ~168 ~151 ~556 minecraft:redstone_wire replace
fill ~171 ~151 ~544 ~171 ~151 ~556 minecraft:redstone_wire replace
fill ~174 ~151 ~544 ~174 ~151 ~556 minecraft:redstone_wire replace
fill ~177 ~151 ~544 ~177 ~151 ~556 minecraft:redstone_wire replace
fill ~180 ~151 ~544 ~180 ~151 ~556 minecraft:redstone_wire replace
fill ~183 ~151 ~544 ~183 ~151 ~556 minecraft:redstone_wire replace
fill ~186 ~151 ~544 ~186 ~151 ~556 minecraft:redstone_wire replace
fill ~189 ~151 ~544 ~189 ~151 ~556 minecraft:redstone_wire replace
fill ~192 ~151 ~544 ~192 ~151 ~556 minecraft:redstone_wire replace
fill ~195 ~151 ~544 ~195 ~151 ~556 minecraft:redstone_wire replace
fill ~198 ~151 ~544 ~198 ~151 ~556 minecraft:redstone_wire replace
fill ~201 ~151 ~544 ~201 ~151 ~556 minecraft:redstone_wire replace
fill ~204 ~151 ~544 ~204 ~151 ~556 minecraft:redstone_wire replace
fill ~207 ~151 ~544 ~207 ~151 ~556 minecraft:redstone_wire replace
fill ~210 ~151 ~544 ~210 ~151 ~556 minecraft:redstone_wire replace
fill ~213 ~151 ~544 ~213 ~151 ~556 minecraft:redstone_wire replace
fill ~216 ~151 ~544 ~216 ~151 ~556 minecraft:redstone_wire replace
fill ~219 ~151 ~544 ~219 ~151 ~556 minecraft:redstone_wire replace
fill ~222 ~151 ~544 ~222 ~151 ~556 minecraft:redstone_wire replace
fill ~225 ~151 ~544 ~225 ~151 ~556 minecraft:redstone_wire replace
fill ~228 ~151 ~544 ~228 ~151 ~556 minecraft:redstone_wire replace
fill ~249 ~151 ~544 ~249 ~151 ~548 minecraft:redstone_wire replace
setblock ~246 ~151 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~552 ~246 ~151 ~564 minecraft:redstone_wire replace
fill ~255 ~151 ~552 ~255 ~151 ~564 minecraft:redstone_wire replace
setblock ~84 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~560 ~84 ~151 ~572 minecraft:redstone_wire replace
fill ~87 ~151 ~560 ~87 ~151 ~572 minecraft:redstone_wire replace
fill ~90 ~151 ~560 ~90 ~151 ~572 minecraft:redstone_wire replace
fill ~93 ~151 ~560 ~93 ~151 ~572 minecraft:redstone_wire replace
fill ~96 ~151 ~560 ~96 ~151 ~572 minecraft:redstone_wire replace
fill ~99 ~151 ~560 ~99 ~151 ~572 minecraft:redstone_wire replace
fill ~102 ~151 ~560 ~102 ~151 ~572 minecraft:redstone_wire replace
fill ~105 ~151 ~560 ~105 ~151 ~572 minecraft:redstone_wire replace
fill ~108 ~151 ~560 ~108 ~151 ~572 minecraft:redstone_wire replace
fill ~111 ~151 ~560 ~111 ~151 ~572 minecraft:redstone_wire replace
fill ~114 ~151 ~560 ~114 ~151 ~572 minecraft:redstone_wire replace
fill ~117 ~151 ~560 ~117 ~151 ~572 minecraft:redstone_wire replace
fill ~120 ~151 ~560 ~120 ~151 ~572 minecraft:redstone_wire replace
fill ~123 ~151 ~560 ~123 ~151 ~572 minecraft:redstone_wire replace
fill ~126 ~151 ~560 ~126 ~151 ~572 minecraft:redstone_wire replace
fill ~129 ~151 ~560 ~129 ~151 ~572 minecraft:redstone_wire replace
fill ~132 ~151 ~560 ~132 ~151 ~572 minecraft:redstone_wire replace
fill ~135 ~151 ~560 ~135 ~151 ~572 minecraft:redstone_wire replace
fill ~138 ~151 ~560 ~138 ~151 ~572 minecraft:redstone_wire replace
fill ~141 ~151 ~560 ~141 ~151 ~572 minecraft:redstone_wire replace
fill ~144 ~151 ~560 ~144 ~151 ~572 minecraft:redstone_wire replace
fill ~147 ~151 ~560 ~147 ~151 ~572 minecraft:redstone_wire replace
fill ~150 ~151 ~560 ~150 ~151 ~572 minecraft:redstone_wire replace
fill ~153 ~151 ~560 ~153 ~151 ~572 minecraft:redstone_wire replace
fill ~156 ~151 ~560 ~156 ~151 ~572 minecraft:redstone_wire replace
fill ~159 ~151 ~560 ~159 ~151 ~572 minecraft:redstone_wire replace
fill ~162 ~151 ~560 ~162 ~151 ~572 minecraft:redstone_wire replace
fill ~165 ~151 ~560 ~165 ~151 ~572 minecraft:redstone_wire replace
fill ~168 ~151 ~560 ~168 ~151 ~572 minecraft:redstone_wire replace
fill ~171 ~151 ~560 ~171 ~151 ~572 minecraft:redstone_wire replace
fill ~174 ~151 ~560 ~174 ~151 ~572 minecraft:redstone_wire replace
fill ~177 ~151 ~560 ~177 ~151 ~572 minecraft:redstone_wire replace
fill ~180 ~151 ~560 ~180 ~151 ~572 minecraft:redstone_wire replace
fill ~183 ~151 ~560 ~183 ~151 ~572 minecraft:redstone_wire replace
fill ~186 ~151 ~560 ~186 ~151 ~572 minecraft:redstone_wire replace
fill ~189 ~151 ~560 ~189 ~151 ~572 minecraft:redstone_wire replace
fill ~192 ~151 ~560 ~192 ~151 ~572 minecraft:redstone_wire replace
fill ~195 ~151 ~560 ~195 ~151 ~572 minecraft:redstone_wire replace
fill ~198 ~151 ~560 ~198 ~151 ~572 minecraft:redstone_wire replace
fill ~201 ~151 ~560 ~201 ~151 ~572 minecraft:redstone_wire replace
fill ~204 ~151 ~560 ~204 ~151 ~572 minecraft:redstone_wire replace
fill ~207 ~151 ~560 ~207 ~151 ~572 minecraft:redstone_wire replace
fill ~210 ~151 ~560 ~210 ~151 ~572 minecraft:redstone_wire replace
fill ~213 ~151 ~560 ~213 ~151 ~572 minecraft:redstone_wire replace
fill ~216 ~151 ~560 ~216 ~151 ~572 minecraft:redstone_wire replace
fill ~219 ~151 ~560 ~219 ~151 ~572 minecraft:redstone_wire replace
fill ~222 ~151 ~560 ~222 ~151 ~572 minecraft:redstone_wire replace
fill ~225 ~151 ~560 ~225 ~151 ~572 minecraft:redstone_wire replace
fill ~228 ~151 ~560 ~228 ~151 ~572 minecraft:redstone_wire replace
setblock ~246 ~151 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~568 ~246 ~151 ~580 minecraft:redstone_wire replace
fill ~255 ~151 ~568 ~255 ~151 ~580 minecraft:redstone_wire replace
fill ~258 ~151 ~568 ~258 ~151 ~572 minecraft:redstone_wire replace
setblock ~84 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~576 ~84 ~151 ~588 minecraft:redstone_wire replace
fill ~87 ~151 ~576 ~87 ~151 ~588 minecraft:redstone_wire replace
fill ~90 ~151 ~576 ~90 ~151 ~588 minecraft:redstone_wire replace
fill ~93 ~151 ~576 ~93 ~151 ~588 minecraft:redstone_wire replace
fill ~96 ~151 ~576 ~96 ~151 ~588 minecraft:redstone_wire replace
fill ~99 ~151 ~576 ~99 ~151 ~588 minecraft:redstone_wire replace
fill ~102 ~151 ~576 ~102 ~151 ~588 minecraft:redstone_wire replace
fill ~105 ~151 ~576 ~105 ~151 ~588 minecraft:redstone_wire replace
fill ~108 ~151 ~576 ~108 ~151 ~588 minecraft:redstone_wire replace
fill ~111 ~151 ~576 ~111 ~151 ~588 minecraft:redstone_wire replace
fill ~114 ~151 ~576 ~114 ~151 ~588 minecraft:redstone_wire replace
fill ~117 ~151 ~576 ~117 ~151 ~588 minecraft:redstone_wire replace
fill ~120 ~151 ~576 ~120 ~151 ~588 minecraft:redstone_wire replace
fill ~123 ~151 ~576 ~123 ~151 ~588 minecraft:redstone_wire replace
fill ~126 ~151 ~576 ~126 ~151 ~588 minecraft:redstone_wire replace
fill ~129 ~151 ~576 ~129 ~151 ~588 minecraft:redstone_wire replace
fill ~132 ~151 ~576 ~132 ~151 ~588 minecraft:redstone_wire replace
fill ~135 ~151 ~576 ~135 ~151 ~588 minecraft:redstone_wire replace
fill ~138 ~151 ~576 ~138 ~151 ~588 minecraft:redstone_wire replace
fill ~141 ~151 ~576 ~141 ~151 ~588 minecraft:redstone_wire replace
fill ~144 ~151 ~576 ~144 ~151 ~588 minecraft:redstone_wire replace
fill ~147 ~151 ~576 ~147 ~151 ~588 minecraft:redstone_wire replace
fill ~150 ~151 ~576 ~150 ~151 ~588 minecraft:redstone_wire replace
fill ~153 ~151 ~576 ~153 ~151 ~588 minecraft:redstone_wire replace
fill ~156 ~151 ~576 ~156 ~151 ~588 minecraft:redstone_wire replace
fill ~159 ~151 ~576 ~159 ~151 ~588 minecraft:redstone_wire replace
fill ~162 ~151 ~576 ~162 ~151 ~588 minecraft:redstone_wire replace
fill ~165 ~151 ~576 ~165 ~151 ~588 minecraft:redstone_wire replace
fill ~168 ~151 ~576 ~168 ~151 ~588 minecraft:redstone_wire replace
fill ~171 ~151 ~576 ~171 ~151 ~588 minecraft:redstone_wire replace
fill ~174 ~151 ~576 ~174 ~151 ~588 minecraft:redstone_wire replace
fill ~177 ~151 ~576 ~177 ~151 ~588 minecraft:redstone_wire replace
fill ~180 ~151 ~576 ~180 ~151 ~588 minecraft:redstone_wire replace
fill ~183 ~151 ~576 ~183 ~151 ~588 minecraft:redstone_wire replace
fill ~186 ~151 ~576 ~186 ~151 ~588 minecraft:redstone_wire replace
fill ~189 ~151 ~576 ~189 ~151 ~588 minecraft:redstone_wire replace
fill ~192 ~151 ~576 ~192 ~151 ~588 minecraft:redstone_wire replace
fill ~195 ~151 ~576 ~195 ~151 ~588 minecraft:redstone_wire replace
fill ~198 ~151 ~576 ~198 ~151 ~588 minecraft:redstone_wire replace
fill ~201 ~151 ~576 ~201 ~151 ~588 minecraft:redstone_wire replace
fill ~204 ~151 ~576 ~204 ~151 ~588 minecraft:redstone_wire replace
fill ~207 ~151 ~576 ~207 ~151 ~588 minecraft:redstone_wire replace
fill ~210 ~151 ~576 ~210 ~151 ~588 minecraft:redstone_wire replace
fill ~213 ~151 ~576 ~213 ~151 ~588 minecraft:redstone_wire replace
fill ~216 ~151 ~576 ~216 ~151 ~588 minecraft:redstone_wire replace
fill ~219 ~151 ~576 ~219 ~151 ~588 minecraft:redstone_wire replace
fill ~222 ~151 ~576 ~222 ~151 ~588 minecraft:redstone_wire replace
fill ~225 ~151 ~576 ~225 ~151 ~588 minecraft:redstone_wire replace
fill ~228 ~151 ~576 ~228 ~151 ~588 minecraft:redstone_wire replace
fill ~252 ~151 ~576 ~252 ~151 ~580 minecraft:redstone_wire replace
setblock ~246 ~151 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~584 ~246 ~151 ~596 minecraft:redstone_wire replace
fill ~255 ~151 ~584 ~255 ~151 ~596 minecraft:redstone_wire replace
setblock ~84 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~592 ~84 ~151 ~604 minecraft:redstone_wire replace
fill ~87 ~151 ~592 ~87 ~151 ~604 minecraft:redstone_wire replace
fill ~90 ~151 ~592 ~90 ~151 ~604 minecraft:redstone_wire replace
fill ~93 ~151 ~592 ~93 ~151 ~604 minecraft:redstone_wire replace
fill ~96 ~151 ~592 ~96 ~151 ~604 minecraft:redstone_wire replace
fill ~99 ~151 ~592 ~99 ~151 ~604 minecraft:redstone_wire replace
fill ~102 ~151 ~592 ~102 ~151 ~604 minecraft:redstone_wire replace
fill ~105 ~151 ~592 ~105 ~151 ~604 minecraft:redstone_wire replace
fill ~108 ~151 ~592 ~108 ~151 ~604 minecraft:redstone_wire replace
fill ~111 ~151 ~592 ~111 ~151 ~604 minecraft:redstone_wire replace
fill ~114 ~151 ~592 ~114 ~151 ~604 minecraft:redstone_wire replace
fill ~117 ~151 ~592 ~117 ~151 ~604 minecraft:redstone_wire replace
fill ~120 ~151 ~592 ~120 ~151 ~604 minecraft:redstone_wire replace
fill ~123 ~151 ~592 ~123 ~151 ~604 minecraft:redstone_wire replace
fill ~126 ~151 ~592 ~126 ~151 ~604 minecraft:redstone_wire replace
fill ~129 ~151 ~592 ~129 ~151 ~604 minecraft:redstone_wire replace
fill ~132 ~151 ~592 ~132 ~151 ~604 minecraft:redstone_wire replace
fill ~135 ~151 ~592 ~135 ~151 ~604 minecraft:redstone_wire replace
fill ~138 ~151 ~592 ~138 ~151 ~604 minecraft:redstone_wire replace
fill ~141 ~151 ~592 ~141 ~151 ~604 minecraft:redstone_wire replace
fill ~144 ~151 ~592 ~144 ~151 ~604 minecraft:redstone_wire replace
fill ~147 ~151 ~592 ~147 ~151 ~604 minecraft:redstone_wire replace
fill ~150 ~151 ~592 ~150 ~151 ~604 minecraft:redstone_wire replace
fill ~153 ~151 ~592 ~153 ~151 ~604 minecraft:redstone_wire replace
fill ~156 ~151 ~592 ~156 ~151 ~604 minecraft:redstone_wire replace
fill ~159 ~151 ~592 ~159 ~151 ~604 minecraft:redstone_wire replace
fill ~162 ~151 ~592 ~162 ~151 ~604 minecraft:redstone_wire replace
fill ~165 ~151 ~592 ~165 ~151 ~604 minecraft:redstone_wire replace
fill ~168 ~151 ~592 ~168 ~151 ~604 minecraft:redstone_wire replace
fill ~171 ~151 ~592 ~171 ~151 ~604 minecraft:redstone_wire replace
fill ~174 ~151 ~592 ~174 ~151 ~604 minecraft:redstone_wire replace
fill ~177 ~151 ~592 ~177 ~151 ~604 minecraft:redstone_wire replace
fill ~180 ~151 ~592 ~180 ~151 ~604 minecraft:redstone_wire replace
fill ~183 ~151 ~592 ~183 ~151 ~604 minecraft:redstone_wire replace
fill ~186 ~151 ~592 ~186 ~151 ~604 minecraft:redstone_wire replace
fill ~189 ~151 ~592 ~189 ~151 ~604 minecraft:redstone_wire replace
fill ~192 ~151 ~592 ~192 ~151 ~604 minecraft:redstone_wire replace
fill ~195 ~151 ~592 ~195 ~151 ~604 minecraft:redstone_wire replace
fill ~198 ~151 ~592 ~198 ~151 ~604 minecraft:redstone_wire replace
fill ~201 ~151 ~592 ~201 ~151 ~604 minecraft:redstone_wire replace
fill ~204 ~151 ~592 ~204 ~151 ~604 minecraft:redstone_wire replace
fill ~207 ~151 ~592 ~207 ~151 ~604 minecraft:redstone_wire replace
fill ~210 ~151 ~592 ~210 ~151 ~604 minecraft:redstone_wire replace
fill ~213 ~151 ~592 ~213 ~151 ~604 minecraft:redstone_wire replace
fill ~216 ~151 ~592 ~216 ~151 ~604 minecraft:redstone_wire replace
fill ~219 ~151 ~592 ~219 ~151 ~604 minecraft:redstone_wire replace
fill ~222 ~151 ~592 ~222 ~151 ~604 minecraft:redstone_wire replace
fill ~225 ~151 ~592 ~225 ~151 ~604 minecraft:redstone_wire replace
fill ~228 ~151 ~592 ~228 ~151 ~604 minecraft:redstone_wire replace
setblock ~246 ~151 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~600 ~246 ~151 ~612 minecraft:redstone_wire replace
fill ~255 ~151 ~600 ~255 ~151 ~612 minecraft:redstone_wire replace
setblock ~267 ~151 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~151 ~602 ~267 ~151 ~608 minecraft:redstone_wire replace
fill ~264 ~151 ~604 ~264 ~151 ~608 minecraft:redstone_wire replace
setblock ~84 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~608 ~84 ~151 ~620 minecraft:redstone_wire replace
fill ~87 ~151 ~608 ~87 ~151 ~620 minecraft:redstone_wire replace
fill ~90 ~151 ~608 ~90 ~151 ~620 minecraft:redstone_wire replace
fill ~93 ~151 ~608 ~93 ~151 ~620 minecraft:redstone_wire replace
fill ~96 ~151 ~608 ~96 ~151 ~620 minecraft:redstone_wire replace
fill ~99 ~151 ~608 ~99 ~151 ~620 minecraft:redstone_wire replace
fill ~102 ~151 ~608 ~102 ~151 ~620 minecraft:redstone_wire replace
fill ~105 ~151 ~608 ~105 ~151 ~620 minecraft:redstone_wire replace
fill ~108 ~151 ~608 ~108 ~151 ~620 minecraft:redstone_wire replace
fill ~111 ~151 ~608 ~111 ~151 ~620 minecraft:redstone_wire replace
fill ~114 ~151 ~608 ~114 ~151 ~620 minecraft:redstone_wire replace
fill ~117 ~151 ~608 ~117 ~151 ~620 minecraft:redstone_wire replace
fill ~120 ~151 ~608 ~120 ~151 ~620 minecraft:redstone_wire replace
fill ~123 ~151 ~608 ~123 ~151 ~620 minecraft:redstone_wire replace
fill ~126 ~151 ~608 ~126 ~151 ~620 minecraft:redstone_wire replace
fill ~129 ~151 ~608 ~129 ~151 ~620 minecraft:redstone_wire replace
fill ~132 ~151 ~608 ~132 ~151 ~620 minecraft:redstone_wire replace
fill ~135 ~151 ~608 ~135 ~151 ~620 minecraft:redstone_wire replace
fill ~138 ~151 ~608 ~138 ~151 ~620 minecraft:redstone_wire replace
fill ~141 ~151 ~608 ~141 ~151 ~620 minecraft:redstone_wire replace
fill ~144 ~151 ~608 ~144 ~151 ~620 minecraft:redstone_wire replace
fill ~147 ~151 ~608 ~147 ~151 ~620 minecraft:redstone_wire replace
fill ~150 ~151 ~608 ~150 ~151 ~620 minecraft:redstone_wire replace
fill ~153 ~151 ~608 ~153 ~151 ~620 minecraft:redstone_wire replace
fill ~156 ~151 ~608 ~156 ~151 ~620 minecraft:redstone_wire replace
fill ~159 ~151 ~608 ~159 ~151 ~620 minecraft:redstone_wire replace
fill ~162 ~151 ~608 ~162 ~151 ~620 minecraft:redstone_wire replace
fill ~165 ~151 ~608 ~165 ~151 ~620 minecraft:redstone_wire replace
fill ~168 ~151 ~608 ~168 ~151 ~620 minecraft:redstone_wire replace
fill ~171 ~151 ~608 ~171 ~151 ~620 minecraft:redstone_wire replace
fill ~174 ~151 ~608 ~174 ~151 ~620 minecraft:redstone_wire replace
fill ~177 ~151 ~608 ~177 ~151 ~620 minecraft:redstone_wire replace
fill ~180 ~151 ~608 ~180 ~151 ~620 minecraft:redstone_wire replace
fill ~183 ~151 ~608 ~183 ~151 ~620 minecraft:redstone_wire replace
fill ~186 ~151 ~608 ~186 ~151 ~620 minecraft:redstone_wire replace
fill ~189 ~151 ~608 ~189 ~151 ~620 minecraft:redstone_wire replace
fill ~192 ~151 ~608 ~192 ~151 ~620 minecraft:redstone_wire replace
fill ~195 ~151 ~608 ~195 ~151 ~620 minecraft:redstone_wire replace
fill ~198 ~151 ~608 ~198 ~151 ~620 minecraft:redstone_wire replace
fill ~201 ~151 ~608 ~201 ~151 ~620 minecraft:redstone_wire replace
fill ~204 ~151 ~608 ~204 ~151 ~620 minecraft:redstone_wire replace
fill ~207 ~151 ~608 ~207 ~151 ~620 minecraft:redstone_wire replace
fill ~210 ~151 ~608 ~210 ~151 ~620 minecraft:redstone_wire replace
fill ~213 ~151 ~608 ~213 ~151 ~620 minecraft:redstone_wire replace
fill ~216 ~151 ~608 ~216 ~151 ~620 minecraft:redstone_wire replace
fill ~219 ~151 ~608 ~219 ~151 ~620 minecraft:redstone_wire replace
fill ~222 ~151 ~608 ~222 ~151 ~620 minecraft:redstone_wire replace
fill ~225 ~151 ~608 ~225 ~151 ~620 minecraft:redstone_wire replace
fill ~228 ~151 ~608 ~228 ~151 ~620 minecraft:redstone_wire replace
fill ~261 ~151 ~608 ~261 ~151 ~612 minecraft:redstone_wire replace
setblock ~84 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~624 ~84 ~151 ~636 minecraft:redstone_wire replace
fill ~87 ~151 ~624 ~87 ~151 ~636 minecraft:redstone_wire replace
fill ~90 ~151 ~624 ~90 ~151 ~636 minecraft:redstone_wire replace
fill ~93 ~151 ~624 ~93 ~151 ~636 minecraft:redstone_wire replace
fill ~96 ~151 ~624 ~96 ~151 ~636 minecraft:redstone_wire replace
fill ~99 ~151 ~624 ~99 ~151 ~636 minecraft:redstone_wire replace
fill ~102 ~151 ~624 ~102 ~151 ~636 minecraft:redstone_wire replace
fill ~105 ~151 ~624 ~105 ~151 ~636 minecraft:redstone_wire replace
fill ~108 ~151 ~624 ~108 ~151 ~636 minecraft:redstone_wire replace
fill ~111 ~151 ~624 ~111 ~151 ~636 minecraft:redstone_wire replace
fill ~114 ~151 ~624 ~114 ~151 ~636 minecraft:redstone_wire replace
fill ~117 ~151 ~624 ~117 ~151 ~636 minecraft:redstone_wire replace
fill ~120 ~151 ~624 ~120 ~151 ~636 minecraft:redstone_wire replace
fill ~123 ~151 ~624 ~123 ~151 ~636 minecraft:redstone_wire replace
fill ~126 ~151 ~624 ~126 ~151 ~636 minecraft:redstone_wire replace
fill ~129 ~151 ~624 ~129 ~151 ~636 minecraft:redstone_wire replace
fill ~132 ~151 ~624 ~132 ~151 ~636 minecraft:redstone_wire replace
fill ~135 ~151 ~624 ~135 ~151 ~636 minecraft:redstone_wire replace
fill ~138 ~151 ~624 ~138 ~151 ~636 minecraft:redstone_wire replace
fill ~141 ~151 ~624 ~141 ~151 ~636 minecraft:redstone_wire replace
fill ~144 ~151 ~624 ~144 ~151 ~636 minecraft:redstone_wire replace
fill ~147 ~151 ~624 ~147 ~151 ~636 minecraft:redstone_wire replace
fill ~150 ~151 ~624 ~150 ~151 ~636 minecraft:redstone_wire replace
fill ~153 ~151 ~624 ~153 ~151 ~636 minecraft:redstone_wire replace
fill ~156 ~151 ~624 ~156 ~151 ~636 minecraft:redstone_wire replace
fill ~159 ~151 ~624 ~159 ~151 ~636 minecraft:redstone_wire replace
fill ~162 ~151 ~624 ~162 ~151 ~636 minecraft:redstone_wire replace
fill ~165 ~151 ~624 ~165 ~151 ~636 minecraft:redstone_wire replace
fill ~168 ~151 ~624 ~168 ~151 ~636 minecraft:redstone_wire replace
fill ~171 ~151 ~624 ~171 ~151 ~636 minecraft:redstone_wire replace
fill ~174 ~151 ~624 ~174 ~151 ~636 minecraft:redstone_wire replace
fill ~177 ~151 ~624 ~177 ~151 ~636 minecraft:redstone_wire replace
fill ~180 ~151 ~624 ~180 ~151 ~636 minecraft:redstone_wire replace
fill ~183 ~151 ~624 ~183 ~151 ~636 minecraft:redstone_wire replace
fill ~186 ~151 ~624 ~186 ~151 ~636 minecraft:redstone_wire replace
fill ~189 ~151 ~624 ~189 ~151 ~636 minecraft:redstone_wire replace
fill ~192 ~151 ~624 ~192 ~151 ~636 minecraft:redstone_wire replace
fill ~195 ~151 ~624 ~195 ~151 ~636 minecraft:redstone_wire replace
fill ~198 ~151 ~624 ~198 ~151 ~636 minecraft:redstone_wire replace
fill ~201 ~151 ~624 ~201 ~151 ~636 minecraft:redstone_wire replace
fill ~204 ~151 ~624 ~204 ~151 ~636 minecraft:redstone_wire replace
fill ~207 ~151 ~624 ~207 ~151 ~636 minecraft:redstone_wire replace
fill ~210 ~151 ~624 ~210 ~151 ~636 minecraft:redstone_wire replace
fill ~213 ~151 ~624 ~213 ~151 ~636 minecraft:redstone_wire replace
fill ~216 ~151 ~624 ~216 ~151 ~636 minecraft:redstone_wire replace
fill ~219 ~151 ~624 ~219 ~151 ~636 minecraft:redstone_wire replace
fill ~222 ~151 ~624 ~222 ~151 ~636 minecraft:redstone_wire replace
fill ~225 ~151 ~624 ~225 ~151 ~636 minecraft:redstone_wire replace
fill ~228 ~151 ~624 ~228 ~151 ~636 minecraft:redstone_wire replace
setblock ~84 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~640 ~84 ~151 ~652 minecraft:redstone_wire replace
fill ~87 ~151 ~640 ~87 ~151 ~652 minecraft:redstone_wire replace
fill ~90 ~151 ~640 ~90 ~151 ~652 minecraft:redstone_wire replace
fill ~93 ~151 ~640 ~93 ~151 ~652 minecraft:redstone_wire replace
fill ~96 ~151 ~640 ~96 ~151 ~652 minecraft:redstone_wire replace
fill ~99 ~151 ~640 ~99 ~151 ~652 minecraft:redstone_wire replace
fill ~102 ~151 ~640 ~102 ~151 ~652 minecraft:redstone_wire replace
fill ~105 ~151 ~640 ~105 ~151 ~652 minecraft:redstone_wire replace
fill ~108 ~151 ~640 ~108 ~151 ~652 minecraft:redstone_wire replace
fill ~111 ~151 ~640 ~111 ~151 ~652 minecraft:redstone_wire replace
fill ~114 ~151 ~640 ~114 ~151 ~652 minecraft:redstone_wire replace
fill ~117 ~151 ~640 ~117 ~151 ~652 minecraft:redstone_wire replace
fill ~120 ~151 ~640 ~120 ~151 ~652 minecraft:redstone_wire replace
fill ~123 ~151 ~640 ~123 ~151 ~652 minecraft:redstone_wire replace
fill ~126 ~151 ~640 ~126 ~151 ~652 minecraft:redstone_wire replace
fill ~129 ~151 ~640 ~129 ~151 ~652 minecraft:redstone_wire replace
fill ~132 ~151 ~640 ~132 ~151 ~652 minecraft:redstone_wire replace
fill ~135 ~151 ~640 ~135 ~151 ~652 minecraft:redstone_wire replace
fill ~138 ~151 ~640 ~138 ~151 ~652 minecraft:redstone_wire replace
fill ~141 ~151 ~640 ~141 ~151 ~652 minecraft:redstone_wire replace
fill ~144 ~151 ~640 ~144 ~151 ~652 minecraft:redstone_wire replace
fill ~147 ~151 ~640 ~147 ~151 ~652 minecraft:redstone_wire replace
fill ~150 ~151 ~640 ~150 ~151 ~652 minecraft:redstone_wire replace
fill ~153 ~151 ~640 ~153 ~151 ~652 minecraft:redstone_wire replace
fill ~156 ~151 ~640 ~156 ~151 ~652 minecraft:redstone_wire replace
fill ~159 ~151 ~640 ~159 ~151 ~652 minecraft:redstone_wire replace
fill ~162 ~151 ~640 ~162 ~151 ~652 minecraft:redstone_wire replace
fill ~165 ~151 ~640 ~165 ~151 ~652 minecraft:redstone_wire replace
fill ~168 ~151 ~640 ~168 ~151 ~652 minecraft:redstone_wire replace
fill ~171 ~151 ~640 ~171 ~151 ~652 minecraft:redstone_wire replace
fill ~174 ~151 ~640 ~174 ~151 ~652 minecraft:redstone_wire replace
fill ~177 ~151 ~640 ~177 ~151 ~652 minecraft:redstone_wire replace
fill ~180 ~151 ~640 ~180 ~151 ~652 minecraft:redstone_wire replace
fill ~183 ~151 ~640 ~183 ~151 ~652 minecraft:redstone_wire replace
fill ~186 ~151 ~640 ~186 ~151 ~652 minecraft:redstone_wire replace
fill ~189 ~151 ~640 ~189 ~151 ~652 minecraft:redstone_wire replace
fill ~192 ~151 ~640 ~192 ~151 ~652 minecraft:redstone_wire replace
fill ~195 ~151 ~640 ~195 ~151 ~652 minecraft:redstone_wire replace
fill ~198 ~151 ~640 ~198 ~151 ~652 minecraft:redstone_wire replace
fill ~201 ~151 ~640 ~201 ~151 ~652 minecraft:redstone_wire replace
fill ~204 ~151 ~640 ~204 ~151 ~652 minecraft:redstone_wire replace
fill ~207 ~151 ~640 ~207 ~151 ~652 minecraft:redstone_wire replace
fill ~210 ~151 ~640 ~210 ~151 ~652 minecraft:redstone_wire replace
fill ~213 ~151 ~640 ~213 ~151 ~652 minecraft:redstone_wire replace
fill ~216 ~151 ~640 ~216 ~151 ~652 minecraft:redstone_wire replace
fill ~219 ~151 ~640 ~219 ~151 ~652 minecraft:redstone_wire replace
fill ~222 ~151 ~640 ~222 ~151 ~652 minecraft:redstone_wire replace
fill ~225 ~151 ~640 ~225 ~151 ~652 minecraft:redstone_wire replace
fill ~228 ~151 ~640 ~228 ~151 ~652 minecraft:redstone_wire replace
fill ~276 ~151 ~644 ~276 ~151 ~648 minecraft:redstone_wire replace
fill ~270 ~151 ~652 ~270 ~151 ~656 minecraft:redstone_wire replace
fill ~273 ~151 ~660 ~273 ~151 ~664 minecraft:redstone_wire replace
setblock ~231 ~152 ~231 minecraft:redstone_wire replace
setblock ~81 ~152 ~235 minecraft:redstone_wire replace
setblock ~228 ~152 ~239 minecraft:redstone_wire replace
setblock ~225 ~152 ~243 minecraft:redstone_wire replace
setblock ~222 ~152 ~247 minecraft:redstone_wire replace
setblock ~219 ~152 ~251 minecraft:redstone_wire replace
setblock ~216 ~152 ~255 minecraft:redstone_wire replace
setblock ~213 ~152 ~259 minecraft:redstone_wire replace
setblock ~210 ~152 ~263 minecraft:redstone_wire replace
setblock ~207 ~152 ~267 minecraft:redstone_wire replace
setblock ~204 ~152 ~271 minecraft:redstone_wire replace
setblock ~201 ~152 ~275 minecraft:redstone_wire replace
setblock ~198 ~152 ~279 minecraft:redstone_wire replace
setblock ~195 ~152 ~283 minecraft:redstone_wire replace
setblock ~192 ~152 ~287 minecraft:redstone_wire replace
setblock ~189 ~152 ~291 minecraft:redstone_wire replace
setblock ~186 ~152 ~295 minecraft:redstone_wire replace
setblock ~183 ~152 ~299 minecraft:redstone_wire replace
setblock ~180 ~152 ~303 minecraft:redstone_wire replace
setblock ~177 ~152 ~307 minecraft:redstone_wire replace
setblock ~174 ~152 ~311 minecraft:redstone_wire replace
