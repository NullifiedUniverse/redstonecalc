fill ~96 ~64 ~506 ~108 ~64 ~506 minecraft:light_gray_concrete replace
fill ~100 ~64 ~508 ~100 ~64 ~509 minecraft:light_gray_concrete replace
fill ~99 ~64 ~510 ~129 ~64 ~510 minecraft:light_gray_concrete replace
fill ~103 ~64 ~512 ~103 ~64 ~513 minecraft:light_gray_concrete replace
fill ~102 ~64 ~514 ~150 ~64 ~514 minecraft:light_gray_concrete replace
fill ~106 ~64 ~516 ~106 ~64 ~517 minecraft:light_gray_concrete replace
fill ~105 ~64 ~518 ~174 ~64 ~518 minecraft:light_gray_concrete replace
fill ~127 ~64 ~520 ~127 ~64 ~521 minecraft:light_gray_concrete replace
fill ~126 ~64 ~522 ~201 ~64 ~522 minecraft:light_gray_concrete replace
fill ~97 ~64 ~544 ~97 ~64 ~545 minecraft:light_gray_concrete replace
fill ~96 ~64 ~546 ~105 ~64 ~546 minecraft:light_gray_concrete replace
fill ~100 ~64 ~548 ~100 ~64 ~549 minecraft:light_gray_concrete replace
fill ~99 ~64 ~550 ~126 ~64 ~550 minecraft:light_gray_concrete replace
fill ~103 ~64 ~552 ~103 ~64 ~553 minecraft:light_gray_concrete replace
fill ~102 ~64 ~554 ~144 ~64 ~554 minecraft:light_gray_concrete replace
fill ~106 ~64 ~556 ~106 ~64 ~557 minecraft:light_gray_concrete replace
fill ~105 ~64 ~558 ~171 ~64 ~558 minecraft:light_gray_concrete replace
fill ~121 ~64 ~560 ~121 ~64 ~561 minecraft:light_gray_concrete replace
fill ~120 ~64 ~562 ~195 ~64 ~562 minecraft:light_gray_concrete replace
fill ~97 ~64 ~584 ~97 ~64 ~585 minecraft:light_gray_concrete replace
fill ~96 ~64 ~586 ~99 ~64 ~586 minecraft:light_gray_concrete replace
fill ~100 ~64 ~588 ~100 ~64 ~589 minecraft:light_gray_concrete replace
fill ~99 ~64 ~590 ~123 ~64 ~590 minecraft:light_gray_concrete replace
fill ~103 ~64 ~592 ~103 ~64 ~593 minecraft:light_gray_concrete replace
fill ~102 ~64 ~594 ~141 ~64 ~594 minecraft:light_gray_concrete replace
fill ~106 ~64 ~596 ~106 ~64 ~597 minecraft:light_gray_concrete replace
fill ~105 ~64 ~598 ~168 ~64 ~598 minecraft:light_gray_concrete replace
fill ~118 ~64 ~600 ~118 ~64 ~601 minecraft:light_gray_concrete replace
fill ~117 ~64 ~602 ~192 ~64 ~602 minecraft:light_gray_concrete replace
fill ~85 ~64 ~604 ~85 ~64 ~605 minecraft:light_gray_concrete replace
fill ~84 ~64 ~606 ~86 ~64 ~606 minecraft:light_gray_concrete replace
fill ~88 ~64 ~608 ~88 ~64 ~609 minecraft:light_gray_concrete replace
fill ~87 ~64 ~610 ~89 ~64 ~610 minecraft:light_gray_concrete replace
fill ~91 ~64 ~612 ~91 ~64 ~613 minecraft:light_gray_concrete replace
fill ~90 ~64 ~614 ~92 ~64 ~614 minecraft:light_gray_concrete replace
fill ~94 ~64 ~616 ~94 ~64 ~617 minecraft:light_gray_concrete replace
fill ~93 ~64 ~618 ~95 ~64 ~618 minecraft:light_gray_concrete replace
fill ~97 ~64 ~620 ~97 ~64 ~621 minecraft:light_gray_concrete replace
fill ~96 ~64 ~622 ~98 ~64 ~622 minecraft:light_gray_concrete replace
fill ~100 ~64 ~624 ~100 ~64 ~625 minecraft:light_gray_concrete replace
fill ~99 ~64 ~626 ~117 ~64 ~626 minecraft:light_gray_concrete replace
fill ~103 ~64 ~628 ~103 ~64 ~629 minecraft:light_gray_concrete replace
fill ~102 ~64 ~630 ~147 ~64 ~630 minecraft:light_gray_concrete replace
fill ~106 ~64 ~632 ~106 ~64 ~633 minecraft:light_gray_concrete replace
fill ~105 ~64 ~634 ~159 ~64 ~634 minecraft:light_gray_concrete replace
fill ~109 ~64 ~636 ~109 ~64 ~637 minecraft:light_gray_concrete replace
fill ~108 ~64 ~638 ~180 ~64 ~638 minecraft:light_gray_concrete replace
fill ~124 ~64 ~640 ~124 ~64 ~641 minecraft:light_gray_concrete replace
fill ~123 ~64 ~642 ~198 ~64 ~642 minecraft:light_gray_concrete replace
fill ~139 ~64 ~644 ~139 ~64 ~645 minecraft:light_gray_concrete replace
fill ~138 ~64 ~646 ~216 ~64 ~646 minecraft:light_gray_concrete replace
fill ~79 ~64 ~648 ~79 ~64 ~649 minecraft:light_gray_concrete replace
fill ~78 ~64 ~650 ~80 ~64 ~650 minecraft:light_gray_concrete replace
fill ~112 ~64 ~652 ~112 ~64 ~653 minecraft:light_gray_concrete replace
fill ~111 ~64 ~654 ~183 ~64 ~654 minecraft:light_gray_concrete replace
fill ~136 ~64 ~656 ~136 ~64 ~657 minecraft:light_gray_concrete replace
fill ~135 ~64 ~658 ~213 ~64 ~658 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~324 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~340 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~342 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~342 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~356 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~118 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~135 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~150 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~152 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~372 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~111 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~128 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~376 minecraft:light_gray_concrete replace
setblock ~149 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~151 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~166 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~168 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~183 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~185 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~200 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~202 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~380 minecraft:light_gray_concrete replace
setblock ~142 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~159 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~161 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~176 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~178 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~193 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~195 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~384 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~143 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~160 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~175 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~177 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~388 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~137 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~154 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~171 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~173 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~82 ~65 ~392 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~428 minecraft:light_gray_concrete replace
setblock ~105 ~65 ~430 minecraft:light_gray_concrete replace
setblock ~107 ~65 ~430 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~432 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~111 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~128 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~436 minecraft:light_gray_concrete replace
setblock ~113 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~130 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~132 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~147 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~149 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~440 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~464 minecraft:light_gray_concrete replace
setblock ~102 ~65 ~466 minecraft:light_gray_concrete replace
setblock ~104 ~65 ~466 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~468 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~123 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~125 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~472 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~112 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~127 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~129 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~146 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~476 minecraft:light_gray_concrete replace
setblock ~117 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~119 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~134 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~136 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~151 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~153 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~168 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~170 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~130 ~65 ~480 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~146 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~161 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~163 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~178 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~180 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~195 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~197 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~504 minecraft:light_gray_concrete replace
setblock ~99 ~65 ~506 minecraft:light_gray_concrete replace
setblock ~101 ~65 ~506 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~508 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~105 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~512 minecraft:light_gray_concrete replace
setblock ~107 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~143 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~516 minecraft:light_gray_concrete replace
setblock ~114 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~131 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~148 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~150 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~165 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~167 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~127 ~65 ~520 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~143 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~160 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~175 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~177 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~192 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~194 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~544 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~548 minecraft:light_gray_concrete replace
setblock ~117 ~65 ~550 minecraft:light_gray_concrete replace
setblock ~119 ~65 ~550 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~552 minecraft:light_gray_concrete replace
setblock ~104 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~136 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~138 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~556 minecraft:light_gray_concrete replace
setblock ~111 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~113 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~128 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~130 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~145 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~147 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~162 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~164 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~121 ~65 ~560 minecraft:light_gray_concrete replace
setblock ~135 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~137 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~152 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~154 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~169 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~171 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~186 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~188 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~584 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~588 minecraft:light_gray_concrete replace
setblock ~114 ~65 ~590 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~590 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~592 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~117 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~132 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~134 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~596 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~125 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~127 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~142 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~159 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~161 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~118 ~65 ~600 minecraft:light_gray_concrete replace
setblock ~132 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~134 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~149 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~151 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~166 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~168 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~183 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~185 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~85 ~65 ~604 minecraft:light_gray_concrete replace
setblock ~88 ~65 ~608 minecraft:light_gray_concrete replace
setblock ~91 ~65 ~612 minecraft:light_gray_concrete replace
setblock ~94 ~65 ~616 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~620 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~624 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~626 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~626 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~628 minecraft:light_gray_concrete replace
setblock ~104 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~121 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~123 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~138 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~140 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~632 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~118 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~135 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~150 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~152 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~636 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~137 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~154 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~171 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~173 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~640 minecraft:light_gray_concrete replace
setblock ~138 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~140 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~155 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~157 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~172 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~174 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~189 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~191 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~644 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~173 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~175 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~190 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~192 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~207 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~209 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~79 ~65 ~648 minecraft:light_gray_concrete replace
setblock ~112 ~65 ~652 minecraft:light_gray_concrete replace
setblock ~123 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~125 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~140 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~142 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~157 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~159 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~174 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~176 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~136 ~65 ~656 minecraft:light_gray_concrete replace
setblock ~153 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~155 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~170 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~172 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~187 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~189 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~204 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~206 ~65 ~658 minecraft:light_gray_concrete replace
fill ~96 ~66 ~324 ~96 ~66 ~624 minecraft:light_gray_concrete replace
fill ~99 ~66 ~340 ~99 ~66 ~628 minecraft:light_gray_concrete replace
fill ~105 ~66 ~356 ~105 ~66 ~636 minecraft:light_gray_concrete replace
fill ~102 ~66 ~372 ~102 ~66 ~632 minecraft:light_gray_concrete replace
fill ~132 ~66 ~376 ~132 ~66 ~384 minecraft:light_gray_concrete replace
fill ~114 ~66 ~384 ~114 ~66 ~392 minecraft:light_gray_concrete replace
fill ~81 ~66 ~392 ~81 ~66 ~396 minecraft:light_gray_concrete replace
fill ~129 ~66 ~480 ~129 ~66 ~484 minecraft:light_gray_concrete replace
fill ~126 ~66 ~520 ~126 ~66 ~524 minecraft:light_gray_concrete replace
fill ~120 ~66 ~560 ~120 ~66 ~564 minecraft:light_gray_concrete replace
fill ~117 ~66 ~600 ~117 ~66 ~604 minecraft:light_gray_concrete replace
fill ~84 ~66 ~604 ~84 ~66 ~608 minecraft:light_gray_concrete replace
fill ~87 ~66 ~608 ~87 ~66 ~612 minecraft:light_gray_concrete replace
fill ~90 ~66 ~612 ~90 ~66 ~616 minecraft:light_gray_concrete replace
fill ~93 ~66 ~616 ~93 ~66 ~620 minecraft:light_gray_concrete replace
fill ~108 ~66 ~636 ~108 ~66 ~640 minecraft:light_gray_concrete replace
fill ~123 ~66 ~640 ~123 ~66 ~644 minecraft:light_gray_concrete replace
fill ~138 ~66 ~644 ~138 ~66 ~648 minecraft:light_gray_concrete replace
fill ~78 ~66 ~648 ~78 ~66 ~652 minecraft:light_gray_concrete replace
fill ~111 ~66 ~652 ~111 ~66 ~656 minecraft:light_gray_concrete replace
fill ~135 ~66 ~656 ~135 ~66 ~660 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~324 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~337 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~339 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~340 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~353 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~353 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~355 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~355 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~356 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~369 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~369 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~369 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~371 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~371 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~371 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~372 minecraft:light_gray_concrete replace
setblock ~133 ~67 ~376 minecraft:light_gray_concrete replace
setblock ~133 ~67 ~380 minecraft:light_gray_concrete replace
setblock ~132 ~67 ~383 minecraft:light_gray_concrete replace
setblock ~115 ~67 ~384 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~132 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~115 ~67 ~388 minecraft:light_gray_concrete replace
setblock ~114 ~67 ~391 minecraft:light_gray_concrete replace
setblock ~82 ~67 ~392 minecraft:light_gray_concrete replace
setblock ~114 ~67 ~393 minecraft:light_gray_concrete replace
setblock ~81 ~67 ~397 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~428 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~432 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~433 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~433 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~433 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~435 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~435 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~435 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~436 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~440 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~447 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~451 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~451 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~451 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~463 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~464 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~465 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~467 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~467 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~468 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~472 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~476 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~479 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~479 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~483 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~483 minecraft:light_gray_concrete replace
setblock ~129 ~67 ~485 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~495 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~495 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~499 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~499 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~508 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~511 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~511 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~512 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~513 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~513 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~513 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~515 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~516 minecraft:light_gray_concrete replace
setblock ~126 ~67 ~525 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~527 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~527 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~527 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~531 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~543 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~543 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~544 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~545 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~545 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~547 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~552 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~556 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~557 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~559 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~559 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~559 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~561 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~561 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~561 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~563 minecraft:light_gray_concrete replace
setblock ~120 ~67 ~565 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~573 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~575 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~577 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~579 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~584 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~588 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~589 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~591 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~591 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~592 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~593 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~593 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~595 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~596 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~605 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~605 minecraft:light_gray_concrete replace
setblock ~117 ~67 ~605 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~607 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~607 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~607 minecraft:light_gray_concrete replace
setblock ~84 ~67 ~609 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~609 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~609 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~611 minecraft:light_gray_concrete replace
setblock ~87 ~67 ~613 minecraft:light_gray_concrete replace
setblock ~90 ~67 ~617 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~620 minecraft:light_gray_concrete replace
setblock ~93 ~67 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~623 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~624 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~625 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~625 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~627 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~628 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~629 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~631 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~632 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~633 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~635 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~637 minecraft:light_gray_concrete replace
setblock ~108 ~67 ~641 minecraft:light_gray_concrete replace
setblock ~123 ~67 ~645 minecraft:light_gray_concrete replace
setblock ~138 ~67 ~649 minecraft:light_gray_concrete replace
setblock ~78 ~67 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~67 ~657 minecraft:light_gray_concrete replace
setblock ~135 ~67 ~661 minecraft:light_gray_concrete replace
fill ~132 ~68 ~386 ~134 ~68 ~386 minecraft:light_gray_concrete replace
fill ~133 ~68 ~387 ~133 ~68 ~388 minecraft:light_gray_concrete replace
fill ~114 ~68 ~394 ~116 ~68 ~394 minecraft:light_gray_concrete replace
fill ~115 ~68 ~395 ~115 ~68 ~396 minecraft:light_gray_concrete replace
fill ~81 ~68 ~398 ~86 ~68 ~398 minecraft:light_gray_concrete replace
fill ~85 ~68 ~399 ~85 ~68 ~400 minecraft:light_gray_concrete replace
fill ~126 ~68 ~486 ~129 ~68 ~486 minecraft:light_gray_concrete replace
fill ~127 ~68 ~487 ~127 ~68 ~488 minecraft:light_gray_concrete replace
fill ~123 ~68 ~526 ~126 ~68 ~526 minecraft:light_gray_concrete replace
fill ~124 ~68 ~527 ~124 ~68 ~528 minecraft:light_gray_concrete replace
fill ~120 ~68 ~566 ~122 ~68 ~566 minecraft:light_gray_concrete replace
fill ~121 ~68 ~567 ~121 ~68 ~568 minecraft:light_gray_concrete replace
fill ~117 ~68 ~606 ~119 ~68 ~606 minecraft:light_gray_concrete replace
fill ~118 ~68 ~607 ~118 ~68 ~608 minecraft:light_gray_concrete replace
fill ~84 ~68 ~610 ~89 ~68 ~610 minecraft:light_gray_concrete replace
fill ~88 ~68 ~611 ~88 ~68 ~612 minecraft:light_gray_concrete replace
fill ~87 ~68 ~614 ~92 ~68 ~614 minecraft:light_gray_concrete replace
fill ~91 ~68 ~615 ~91 ~68 ~616 minecraft:light_gray_concrete replace
fill ~90 ~68 ~618 ~95 ~68 ~618 minecraft:light_gray_concrete replace
fill ~94 ~68 ~619 ~94 ~68 ~620 minecraft:light_gray_concrete replace
fill ~93 ~68 ~622 ~98 ~68 ~622 minecraft:light_gray_concrete replace
fill ~97 ~68 ~623 ~97 ~68 ~624 minecraft:light_gray_concrete replace
fill ~96 ~68 ~626 ~101 ~68 ~626 minecraft:light_gray_concrete replace
fill ~100 ~68 ~627 ~100 ~68 ~628 minecraft:light_gray_concrete replace
fill ~99 ~68 ~630 ~104 ~68 ~630 minecraft:light_gray_concrete replace
fill ~103 ~68 ~631 ~103 ~68 ~632 minecraft:light_gray_concrete replace
fill ~78 ~68 ~634 ~131 ~68 ~634 minecraft:light_gray_concrete replace
fill ~79 ~68 ~635 ~79 ~68 ~636 minecraft:light_gray_concrete replace
fill ~130 ~68 ~635 ~130 ~68 ~636 minecraft:light_gray_concrete replace
fill ~105 ~68 ~638 ~107 ~68 ~638 minecraft:light_gray_concrete replace
fill ~106 ~68 ~639 ~106 ~68 ~640 minecraft:light_gray_concrete replace
fill ~108 ~68 ~642 ~110 ~68 ~642 minecraft:light_gray_concrete replace
fill ~109 ~68 ~643 ~109 ~68 ~644 minecraft:light_gray_concrete replace
fill ~114 ~68 ~646 ~134 ~68 ~646 minecraft:light_gray_concrete replace
fill ~115 ~68 ~647 ~115 ~68 ~648 minecraft:light_gray_concrete replace
fill ~133 ~68 ~647 ~133 ~68 ~648 minecraft:light_gray_concrete replace
fill ~138 ~68 ~650 ~140 ~68 ~650 minecraft:light_gray_concrete replace
fill ~139 ~68 ~651 ~139 ~68 ~652 minecraft:light_gray_concrete replace
fill ~78 ~68 ~654 ~83 ~68 ~654 minecraft:light_gray_concrete replace
fill ~82 ~68 ~655 ~82 ~68 ~656 minecraft:light_gray_concrete replace
fill ~111 ~68 ~658 ~113 ~68 ~658 minecraft:light_gray_concrete replace
fill ~112 ~68 ~659 ~112 ~68 ~660 minecraft:light_gray_concrete replace
fill ~135 ~68 ~662 ~137 ~68 ~662 minecraft:light_gray_concrete replace
fill ~136 ~68 ~663 ~136 ~68 ~664 minecraft:light_gray_concrete replace
setblock ~133 ~69 ~388 minecraft:light_gray_concrete replace
setblock ~115 ~69 ~396 minecraft:light_gray_concrete replace
setblock ~85 ~69 ~400 minecraft:light_gray_concrete replace
setblock ~127 ~69 ~488 minecraft:light_gray_concrete replace
setblock ~124 ~69 ~528 minecraft:light_gray_concrete replace
setblock ~121 ~69 ~568 minecraft:light_gray_concrete replace
setblock ~118 ~69 ~608 minecraft:light_gray_concrete replace
setblock ~88 ~69 ~612 minecraft:light_gray_concrete replace
setblock ~91 ~69 ~616 minecraft:light_gray_concrete replace
setblock ~94 ~69 ~620 minecraft:light_gray_concrete replace
setblock ~97 ~69 ~624 minecraft:light_gray_concrete replace
setblock ~100 ~69 ~628 minecraft:light_gray_concrete replace
setblock ~103 ~69 ~632 minecraft:light_gray_concrete replace
setblock ~87 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~89 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~115 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~117 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~79 ~69 ~636 minecraft:light_gray_concrete replace
setblock ~130 ~69 ~636 minecraft:light_gray_concrete replace
setblock ~106 ~69 ~640 minecraft:light_gray_concrete replace
setblock ~109 ~69 ~644 minecraft:light_gray_concrete replace
setblock ~130 ~69 ~646 minecraft:light_gray_concrete replace
setblock ~132 ~69 ~646 minecraft:light_gray_concrete replace
setblock ~115 ~69 ~648 minecraft:light_gray_concrete replace
setblock ~133 ~69 ~648 minecraft:light_gray_concrete replace
setblock ~139 ~69 ~652 minecraft:light_gray_concrete replace
setblock ~82 ~69 ~656 minecraft:light_gray_concrete replace
setblock ~112 ~69 ~660 minecraft:light_gray_concrete replace
setblock ~136 ~69 ~664 minecraft:light_gray_concrete replace
