fill ~396 ~36 ~650 ~399 ~36 ~650 minecraft:light_gray_concrete replace
fill ~397 ~36 ~651 ~397 ~36 ~652 minecraft:light_gray_concrete replace
fill ~96 ~36 ~654 ~101 ~36 ~654 minecraft:light_gray_concrete replace
fill ~100 ~36 ~655 ~100 ~36 ~656 minecraft:light_gray_concrete replace
fill ~372 ~36 ~658 ~375 ~36 ~658 minecraft:light_gray_concrete replace
fill ~373 ~36 ~659 ~373 ~36 ~660 minecraft:light_gray_concrete replace
fill ~393 ~36 ~662 ~396 ~36 ~662 minecraft:light_gray_concrete replace
fill ~394 ~36 ~663 ~394 ~36 ~664 minecraft:light_gray_concrete replace
setblock ~151 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~153 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~168 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~170 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~201 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~203 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~218 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~220 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~235 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~237 ~37 ~14 minecraft:light_gray_concrete replace
setblock ~148 ~37 ~16 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~16 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~16 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~201 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~203 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~217 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~219 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~234 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~236 ~37 ~22 minecraft:light_gray_concrete replace
setblock ~178 ~37 ~24 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~24 minecraft:light_gray_concrete replace
setblock ~250 ~37 ~32 minecraft:light_gray_concrete replace
setblock ~260 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~262 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~276 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~278 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~292 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~294 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~307 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~309 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~324 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~326 ~37 ~46 minecraft:light_gray_concrete replace
setblock ~259 ~37 ~48 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~48 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~48 minecraft:light_gray_concrete replace
setblock ~321 ~37 ~54 minecraft:light_gray_concrete replace
setblock ~323 ~37 ~54 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~56 minecraft:light_gray_concrete replace
setblock ~334 ~37 ~56 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~64 minecraft:light_gray_concrete replace
setblock ~349 ~37 ~80 minecraft:light_gray_concrete replace
setblock ~94 ~37 ~264 minecraft:light_gray_concrete replace
setblock ~124 ~37 ~268 minecraft:light_gray_concrete replace
setblock ~106 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~108 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~123 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~125 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~140 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~142 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~158 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~160 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~177 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~192 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~194 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~209 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~243 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~245 ~37 ~270 minecraft:light_gray_concrete replace
setblock ~94 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~127 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~272 minecraft:light_gray_concrete replace
setblock ~149 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~151 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~166 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~168 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~192 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~194 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~209 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~274 minecraft:light_gray_concrete replace
setblock ~148 ~37 ~276 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~276 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~276 minecraft:light_gray_concrete replace
setblock ~109 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~111 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~141 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~143 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~169 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~171 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~188 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~203 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~205 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~220 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~222 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~237 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~239 ~37 ~278 minecraft:light_gray_concrete replace
setblock ~97 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~127 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~280 minecraft:light_gray_concrete replace
setblock ~121 ~37 ~284 minecraft:light_gray_concrete replace
setblock ~151 ~37 ~288 minecraft:light_gray_concrete replace
setblock ~125 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~127 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~142 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~144 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~159 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~161 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~181 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~183 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~198 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~200 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~215 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~217 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~232 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~234 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~249 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~251 ~37 ~290 minecraft:light_gray_concrete replace
setblock ~121 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~148 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~292 minecraft:light_gray_concrete replace
setblock ~181 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~183 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~198 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~200 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~243 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~245 ~37 ~294 minecraft:light_gray_concrete replace
setblock ~178 ~37 ~296 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~296 minecraft:light_gray_concrete replace
setblock ~154 ~37 ~298 minecraft:light_gray_concrete replace
setblock ~156 ~37 ~298 minecraft:light_gray_concrete replace
setblock ~157 ~37 ~300 minecraft:light_gray_concrete replace
setblock ~174 ~37 ~302 minecraft:light_gray_concrete replace
setblock ~176 ~37 ~302 minecraft:light_gray_concrete replace
setblock ~181 ~37 ~304 minecraft:light_gray_concrete replace
setblock ~169 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~171 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~186 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~188 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~214 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~216 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~231 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~233 ~37 ~306 minecraft:light_gray_concrete replace
setblock ~157 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~175 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~178 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~184 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~308 minecraft:light_gray_concrete replace
setblock ~250 ~37 ~312 minecraft:light_gray_concrete replace
setblock ~187 ~37 ~316 minecraft:light_gray_concrete replace
setblock ~192 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~194 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~209 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~228 ~37 ~318 minecraft:light_gray_concrete replace
setblock ~187 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~244 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~247 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~250 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~320 minecraft:light_gray_concrete replace
setblock ~256 ~37 ~324 minecraft:light_gray_concrete replace
setblock ~202 ~37 ~328 minecraft:light_gray_concrete replace
setblock ~223 ~37 ~332 minecraft:light_gray_concrete replace
setblock ~204 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~206 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~221 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~223 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~238 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~240 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~252 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~254 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~269 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~334 minecraft:light_gray_concrete replace
setblock ~202 ~37 ~336 minecraft:light_gray_concrete replace
setblock ~280 ~37 ~336 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~273 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~288 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~290 ~37 ~338 minecraft:light_gray_concrete replace
setblock ~259 ~37 ~340 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~340 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~340 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~344 minecraft:light_gray_concrete replace
setblock ~262 ~37 ~348 minecraft:light_gray_concrete replace
setblock ~234 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~236 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~251 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~253 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~268 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~270 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~294 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~296 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~311 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~313 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~328 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~330 ~37 ~350 minecraft:light_gray_concrete replace
setblock ~226 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~259 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~298 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~352 minecraft:light_gray_concrete replace
setblock ~323 ~37 ~354 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~354 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~356 minecraft:light_gray_concrete replace
setblock ~334 ~37 ~356 minecraft:light_gray_concrete replace
setblock ~265 ~37 ~360 minecraft:light_gray_concrete replace
setblock ~269 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~286 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~288 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~303 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~305 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~327 ~37 ~362 minecraft:light_gray_concrete replace
setblock ~265 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~322 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~334 ~37 ~364 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~368 minecraft:light_gray_concrete replace
setblock ~337 ~37 ~372 minecraft:light_gray_concrete replace
setblock ~331 ~37 ~374 minecraft:light_gray_concrete replace
setblock ~333 ~37 ~374 minecraft:light_gray_concrete replace
setblock ~313 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~316 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~319 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~325 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~340 ~37 ~376 minecraft:light_gray_concrete replace
setblock ~328 ~37 ~380 minecraft:light_gray_concrete replace
setblock ~340 ~37 ~384 minecraft:light_gray_concrete replace
setblock ~286 ~37 ~388 minecraft:light_gray_concrete replace
setblock ~296 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~298 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~313 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~315 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~339 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~341 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~356 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~358 ~37 ~390 minecraft:light_gray_concrete replace
setblock ~286 ~37 ~392 minecraft:light_gray_concrete replace
setblock ~364 ~37 ~392 minecraft:light_gray_concrete replace
setblock ~349 ~37 ~396 minecraft:light_gray_concrete replace
setblock ~385 ~37 ~400 minecraft:light_gray_concrete replace
setblock ~352 ~37 ~404 minecraft:light_gray_concrete replace
setblock ~373 ~37 ~406 minecraft:light_gray_concrete replace
setblock ~375 ~37 ~406 minecraft:light_gray_concrete replace
setblock ~346 ~37 ~408 minecraft:light_gray_concrete replace
setblock ~349 ~37 ~408 minecraft:light_gray_concrete replace
setblock ~376 ~37 ~408 minecraft:light_gray_concrete replace
setblock ~376 ~37 ~412 minecraft:light_gray_concrete replace
setblock ~91 ~37 ~416 minecraft:light_gray_concrete replace
setblock ~118 ~37 ~420 minecraft:light_gray_concrete replace
setblock ~145 ~37 ~424 minecraft:light_gray_concrete replace
setblock ~193 ~37 ~428 minecraft:light_gray_concrete replace
setblock ~214 ~37 ~432 minecraft:light_gray_concrete replace
setblock ~238 ~37 ~436 minecraft:light_gray_concrete replace
setblock ~283 ~37 ~440 minecraft:light_gray_concrete replace
setblock ~307 ~37 ~444 minecraft:light_gray_concrete replace
setblock ~343 ~37 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~37 ~452 minecraft:light_gray_concrete replace
setblock ~115 ~37 ~456 minecraft:light_gray_concrete replace
setblock ~142 ~37 ~460 minecraft:light_gray_concrete replace
setblock ~190 ~37 ~464 minecraft:light_gray_concrete replace
setblock ~211 ~37 ~468 minecraft:light_gray_concrete replace
setblock ~235 ~37 ~472 minecraft:light_gray_concrete replace
setblock ~277 ~37 ~476 minecraft:light_gray_concrete replace
setblock ~304 ~37 ~480 minecraft:light_gray_concrete replace
setblock ~367 ~37 ~484 minecraft:light_gray_concrete replace
setblock ~391 ~37 ~488 minecraft:light_gray_concrete replace
setblock ~85 ~37 ~492 minecraft:light_gray_concrete replace
setblock ~112 ~37 ~496 minecraft:light_gray_concrete replace
setblock ~139 ~37 ~500 minecraft:light_gray_concrete replace
setblock ~172 ~37 ~504 minecraft:light_gray_concrete replace
setblock ~208 ~37 ~508 minecraft:light_gray_concrete replace
setblock ~232 ~37 ~512 minecraft:light_gray_concrete replace
setblock ~274 ~37 ~516 minecraft:light_gray_concrete replace
setblock ~301 ~37 ~520 minecraft:light_gray_concrete replace
setblock ~361 ~37 ~524 minecraft:light_gray_concrete replace
setblock ~388 ~37 ~528 minecraft:light_gray_concrete replace
setblock ~82 ~37 ~532 minecraft:light_gray_concrete replace
setblock ~109 ~37 ~536 minecraft:light_gray_concrete replace
setblock ~136 ~37 ~540 minecraft:light_gray_concrete replace
setblock ~166 ~37 ~544 minecraft:light_gray_concrete replace
setblock ~205 ~37 ~548 minecraft:light_gray_concrete replace
setblock ~229 ~37 ~552 minecraft:light_gray_concrete replace
setblock ~271 ~37 ~556 minecraft:light_gray_concrete replace
setblock ~292 ~37 ~560 minecraft:light_gray_concrete replace
setblock ~358 ~37 ~564 minecraft:light_gray_concrete replace
setblock ~382 ~37 ~568 minecraft:light_gray_concrete replace
setblock ~79 ~37 ~572 minecraft:light_gray_concrete replace
setblock ~106 ~37 ~576 minecraft:light_gray_concrete replace
setblock ~133 ~37 ~580 minecraft:light_gray_concrete replace
setblock ~163 ~37 ~584 minecraft:light_gray_concrete replace
setblock ~199 ~37 ~588 minecraft:light_gray_concrete replace
setblock ~220 ~37 ~592 minecraft:light_gray_concrete replace
setblock ~268 ~37 ~596 minecraft:light_gray_concrete replace
setblock ~289 ~37 ~600 minecraft:light_gray_concrete replace
setblock ~355 ~37 ~604 minecraft:light_gray_concrete replace
setblock ~379 ~37 ~608 minecraft:light_gray_concrete replace
setblock ~103 ~37 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~37 ~616 minecraft:light_gray_concrete replace
setblock ~160 ~37 ~620 minecraft:light_gray_concrete replace
setblock ~196 ~37 ~624 minecraft:light_gray_concrete replace
setblock ~217 ~37 ~628 minecraft:light_gray_concrete replace
setblock ~241 ~37 ~632 minecraft:light_gray_concrete replace
setblock ~295 ~37 ~636 minecraft:light_gray_concrete replace
setblock ~310 ~37 ~640 minecraft:light_gray_concrete replace
setblock ~370 ~37 ~644 minecraft:light_gray_concrete replace
setblock ~169 ~37 ~648 minecraft:light_gray_concrete replace
setblock ~397 ~37 ~652 minecraft:light_gray_concrete replace
setblock ~100 ~37 ~656 minecraft:light_gray_concrete replace
setblock ~373 ~37 ~660 minecraft:light_gray_concrete replace
setblock ~394 ~37 ~664 minecraft:light_gray_concrete replace
fill ~243 ~38 ~4 ~243 ~38 ~320 minecraft:light_gray_concrete replace
fill ~174 ~38 ~8 ~174 ~38 ~308 minecraft:light_gray_concrete replace
fill ~147 ~38 ~12 ~147 ~38 ~292 minecraft:light_gray_concrete replace
fill ~246 ~38 ~16 ~246 ~38 ~320 minecraft:light_gray_concrete replace
fill ~177 ~38 ~20 ~177 ~38 ~308 minecraft:light_gray_concrete replace
fill ~249 ~38 ~28 ~249 ~38 ~320 minecraft:light_gray_concrete replace
fill ~330 ~38 ~36 ~330 ~38 ~364 minecraft:light_gray_concrete replace
fill ~315 ~38 ~40 ~315 ~38 ~376 minecraft:light_gray_concrete replace
fill ~258 ~38 ~44 ~258 ~38 ~352 minecraft:light_gray_concrete replace
fill ~333 ~38 ~48 ~333 ~38 ~364 minecraft:light_gray_concrete replace
fill ~318 ~38 ~52 ~318 ~38 ~376 minecraft:light_gray_concrete replace
fill ~324 ~38 ~60 ~324 ~38 ~376 minecraft:light_gray_concrete replace
fill ~348 ~38 ~76 ~348 ~38 ~408 minecraft:light_gray_concrete replace
fill ~93 ~38 ~248 ~93 ~38 ~272 minecraft:light_gray_concrete replace
fill ~123 ~38 ~252 ~123 ~38 ~268 minecraft:light_gray_concrete replace
fill ~252 ~38 ~256 ~252 ~38 ~320 minecraft:light_gray_concrete replace
fill ~183 ~38 ~260 ~183 ~38 ~308 minecraft:light_gray_concrete replace
fill ~153 ~38 ~264 ~153 ~38 ~292 minecraft:light_gray_concrete replace
fill ~126 ~38 ~268 ~126 ~38 ~280 minecraft:light_gray_concrete replace
fill ~96 ~38 ~276 ~96 ~38 ~280 minecraft:light_gray_concrete replace
fill ~120 ~38 ~280 ~120 ~38 ~292 minecraft:light_gray_concrete replace
fill ~150 ~38 ~284 ~150 ~38 ~288 minecraft:light_gray_concrete replace
fill ~156 ~38 ~296 ~156 ~38 ~308 minecraft:light_gray_concrete replace
fill ~180 ~38 ~300 ~180 ~38 ~304 minecraft:light_gray_concrete replace
fill ~186 ~38 ~312 ~186 ~38 ~320 minecraft:light_gray_concrete replace
fill ~255 ~38 ~320 ~255 ~38 ~324 minecraft:light_gray_concrete replace
fill ~201 ~38 ~324 ~201 ~38 ~336 minecraft:light_gray_concrete replace
fill ~222 ~38 ~328 ~222 ~38 ~332 minecraft:light_gray_concrete replace
fill ~279 ~38 ~332 ~279 ~38 ~336 minecraft:light_gray_concrete replace
fill ~225 ~38 ~340 ~225 ~38 ~352 minecraft:light_gray_concrete replace
fill ~261 ~38 ~344 ~261 ~38 ~348 minecraft:light_gray_concrete replace
fill ~297 ~38 ~348 ~297 ~38 ~352 minecraft:light_gray_concrete replace
fill ~264 ~38 ~356 ~264 ~38 ~364 minecraft:light_gray_concrete replace
fill ~321 ~38 ~360 ~321 ~38 ~364 minecraft:light_gray_concrete replace
fill ~336 ~38 ~364 ~336 ~38 ~372 minecraft:light_gray_concrete replace
fill ~339 ~38 ~368 ~339 ~38 ~384 minecraft:light_gray_concrete replace
fill ~312 ~38 ~372 ~312 ~38 ~376 minecraft:light_gray_concrete replace
fill ~327 ~38 ~376 ~327 ~38 ~380 minecraft:light_gray_concrete replace
fill ~285 ~38 ~384 ~285 ~38 ~392 minecraft:light_gray_concrete replace
fill ~363 ~38 ~388 ~363 ~38 ~392 minecraft:light_gray_concrete replace
fill ~384 ~38 ~392 ~384 ~38 ~400 minecraft:light_gray_concrete replace
fill ~351 ~38 ~396 ~351 ~38 ~404 minecraft:light_gray_concrete replace
fill ~375 ~38 ~400 ~375 ~38 ~412 minecraft:light_gray_concrete replace
fill ~345 ~38 ~404 ~345 ~38 ~408 minecraft:light_gray_concrete replace
fill ~90 ~38 ~412 ~90 ~38 ~416 minecraft:light_gray_concrete replace
fill ~117 ~38 ~416 ~117 ~38 ~420 minecraft:light_gray_concrete replace
fill ~144 ~38 ~420 ~144 ~38 ~424 minecraft:light_gray_concrete replace
fill ~192 ~38 ~424 ~192 ~38 ~428 minecraft:light_gray_concrete replace
fill ~213 ~38 ~428 ~213 ~38 ~432 minecraft:light_gray_concrete replace
fill ~237 ~38 ~432 ~237 ~38 ~436 minecraft:light_gray_concrete replace
fill ~282 ~38 ~436 ~282 ~38 ~440 minecraft:light_gray_concrete replace
fill ~306 ~38 ~440 ~306 ~38 ~444 minecraft:light_gray_concrete replace
fill ~342 ~38 ~444 ~342 ~38 ~448 minecraft:light_gray_concrete replace
fill ~87 ~38 ~448 ~87 ~38 ~452 minecraft:light_gray_concrete replace
fill ~114 ~38 ~452 ~114 ~38 ~456 minecraft:light_gray_concrete replace
fill ~141 ~38 ~456 ~141 ~38 ~460 minecraft:light_gray_concrete replace
fill ~189 ~38 ~460 ~189 ~38 ~464 minecraft:light_gray_concrete replace
fill ~210 ~38 ~464 ~210 ~38 ~468 minecraft:light_gray_concrete replace
fill ~234 ~38 ~468 ~234 ~38 ~472 minecraft:light_gray_concrete replace
fill ~276 ~38 ~472 ~276 ~38 ~476 minecraft:light_gray_concrete replace
fill ~303 ~38 ~476 ~303 ~38 ~480 minecraft:light_gray_concrete replace
fill ~366 ~38 ~480 ~366 ~38 ~484 minecraft:light_gray_concrete replace
fill ~390 ~38 ~484 ~390 ~38 ~488 minecraft:light_gray_concrete replace
fill ~84 ~38 ~488 ~84 ~38 ~492 minecraft:light_gray_concrete replace
fill ~111 ~38 ~492 ~111 ~38 ~496 minecraft:light_gray_concrete replace
fill ~138 ~38 ~496 ~138 ~38 ~500 minecraft:light_gray_concrete replace
fill ~171 ~38 ~500 ~171 ~38 ~504 minecraft:light_gray_concrete replace
fill ~207 ~38 ~504 ~207 ~38 ~508 minecraft:light_gray_concrete replace
fill ~231 ~38 ~508 ~231 ~38 ~512 minecraft:light_gray_concrete replace
fill ~273 ~38 ~512 ~273 ~38 ~516 minecraft:light_gray_concrete replace
fill ~300 ~38 ~516 ~300 ~38 ~520 minecraft:light_gray_concrete replace
fill ~360 ~38 ~520 ~360 ~38 ~524 minecraft:light_gray_concrete replace
fill ~387 ~38 ~524 ~387 ~38 ~528 minecraft:light_gray_concrete replace
fill ~81 ~38 ~528 ~81 ~38 ~532 minecraft:light_gray_concrete replace
fill ~108 ~38 ~532 ~108 ~38 ~536 minecraft:light_gray_concrete replace
fill ~135 ~38 ~536 ~135 ~38 ~540 minecraft:light_gray_concrete replace
fill ~165 ~38 ~540 ~165 ~38 ~544 minecraft:light_gray_concrete replace
fill ~204 ~38 ~544 ~204 ~38 ~548 minecraft:light_gray_concrete replace
fill ~228 ~38 ~548 ~228 ~38 ~552 minecraft:light_gray_concrete replace
fill ~270 ~38 ~552 ~270 ~38 ~556 minecraft:light_gray_concrete replace
fill ~291 ~38 ~556 ~291 ~38 ~560 minecraft:light_gray_concrete replace
fill ~357 ~38 ~560 ~357 ~38 ~564 minecraft:light_gray_concrete replace
fill ~381 ~38 ~564 ~381 ~38 ~568 minecraft:light_gray_concrete replace
fill ~78 ~38 ~568 ~78 ~38 ~572 minecraft:light_gray_concrete replace
fill ~105 ~38 ~572 ~105 ~38 ~576 minecraft:light_gray_concrete replace
fill ~132 ~38 ~576 ~132 ~38 ~580 minecraft:light_gray_concrete replace
fill ~162 ~38 ~580 ~162 ~38 ~584 minecraft:light_gray_concrete replace
fill ~198 ~38 ~584 ~198 ~38 ~588 minecraft:light_gray_concrete replace
fill ~219 ~38 ~588 ~219 ~38 ~592 minecraft:light_gray_concrete replace
fill ~267 ~38 ~592 ~267 ~38 ~596 minecraft:light_gray_concrete replace
fill ~288 ~38 ~596 ~288 ~38 ~600 minecraft:light_gray_concrete replace
fill ~354 ~38 ~600 ~354 ~38 ~604 minecraft:light_gray_concrete replace
fill ~378 ~38 ~604 ~378 ~38 ~608 minecraft:light_gray_concrete replace
fill ~102 ~38 ~608 ~102 ~38 ~612 minecraft:light_gray_concrete replace
fill ~129 ~38 ~612 ~129 ~38 ~616 minecraft:light_gray_concrete replace
fill ~159 ~38 ~616 ~159 ~38 ~620 minecraft:light_gray_concrete replace
fill ~195 ~38 ~620 ~195 ~38 ~624 minecraft:light_gray_concrete replace
fill ~216 ~38 ~624 ~216 ~38 ~628 minecraft:light_gray_concrete replace
fill ~240 ~38 ~628 ~240 ~38 ~632 minecraft:light_gray_concrete replace
fill ~294 ~38 ~632 ~294 ~38 ~636 minecraft:light_gray_concrete replace
fill ~309 ~38 ~636 ~309 ~38 ~640 minecraft:light_gray_concrete replace
fill ~369 ~38 ~640 ~369 ~38 ~644 minecraft:light_gray_concrete replace
fill ~168 ~38 ~644 ~168 ~38 ~648 minecraft:light_gray_concrete replace
fill ~396 ~38 ~648 ~396 ~38 ~652 minecraft:light_gray_concrete replace
fill ~99 ~38 ~652 ~99 ~38 ~656 minecraft:light_gray_concrete replace
fill ~372 ~38 ~656 ~372 ~38 ~660 minecraft:light_gray_concrete replace
fill ~393 ~38 ~660 ~393 ~38 ~664 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~3 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~5 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~7 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~7 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~9 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~11 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~13 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~15 minecraft:light_gray_concrete replace
setblock ~148 ~39 ~16 minecraft:light_gray_concrete replace
setblock ~175 ~39 ~16 minecraft:light_gray_concrete replace
setblock ~244 ~39 ~16 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~19 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~19 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~21 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~23 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~23 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~23 minecraft:light_gray_concrete replace
setblock ~178 ~39 ~24 minecraft:light_gray_concrete replace
setblock ~247 ~39 ~24 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~27 minecraft:light_gray_concrete replace
setblock ~250 ~39 ~32 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~33 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~35 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~35 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~35 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~37 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~39 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~41 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~43 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~43 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~45 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~47 minecraft:light_gray_concrete replace
setblock ~259 ~39 ~48 minecraft:light_gray_concrete replace
setblock ~316 ~39 ~48 minecraft:light_gray_concrete replace
setblock ~331 ~39 ~48 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~49 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~49 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~51 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~53 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~55 minecraft:light_gray_concrete replace
setblock ~319 ~39 ~56 minecraft:light_gray_concrete replace
setblock ~334 ~39 ~56 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~57 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~59 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~59 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~59 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~61 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~63 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~63 minecraft:light_gray_concrete replace
setblock ~325 ~39 ~64 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~65 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~65 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~67 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~67 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~67 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~69 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~71 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~73 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~73 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~75 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~77 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~77 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~77 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~79 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~79 minecraft:light_gray_concrete replace
setblock ~349 ~39 ~80 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~81 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~81 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~83 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~83 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~83 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~85 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~87 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~89 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~89 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~91 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~93 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~95 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~95 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~97 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~97 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~99 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~99 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~99 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~101 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~103 minecraft:light_gray_concrete replace
setblock ~177 ~39 ~105 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~105 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~324 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~107 minecraft:light_gray_concrete replace
setblock ~315 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~318 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~348 ~39 ~109 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~111 minecraft:light_gray_concrete replace
setblock ~333 ~39 ~111 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~113 minecraft:light_gray_concrete replace
setblock ~330 ~39 ~113 minecraft:light_gray_concrete replace
setblock ~246 ~39 ~115 minecraft:light_gray_concrete replace
setblock ~249 ~39 ~115 minecraft:light_gray_concrete replace
setblock ~258 ~39 ~115 minecraft:light_gray_concrete replace
setblock ~147 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~174 ~39 ~117 minecraft:light_gray_concrete replace
setblock ~243 ~39 ~117 minecraft:light_gray_concrete replace
