setblock ~160 ~21 ~179 minecraft:redstone_wire replace
setblock ~159 ~21 ~182 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~21 ~182 ~171 ~21 ~182 minecraft:redstone_wire replace
setblock ~160 ~21 ~183 minecraft:redstone_wire replace
fill ~201 ~21 ~186 ~207 ~21 ~186 minecraft:redstone_wire replace
setblock ~202 ~21 ~187 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~21 ~190 ~192 ~21 ~190 minecraft:redstone_wire replace
setblock ~190 ~21 ~191 minecraft:redstone_wire replace
fill ~192 ~21 ~194 ~195 ~21 ~194 minecraft:redstone_wire replace
setblock ~193 ~21 ~195 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~21 ~198 ~198 ~21 ~198 minecraft:redstone_wire replace
setblock ~196 ~21 ~199 minecraft:redstone_wire replace
fill ~195 ~21 ~202 ~201 ~21 ~202 minecraft:redstone_wire replace
setblock ~196 ~21 ~203 minecraft:redstone_wire replace
fill ~216 ~21 ~206 ~219 ~21 ~206 minecraft:redstone_wire replace
setblock ~217 ~21 ~207 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~21 ~210 ~213 ~21 ~210 minecraft:redstone_wire replace
setblock ~211 ~21 ~211 minecraft:redstone_wire replace
fill ~213 ~21 ~214 ~216 ~21 ~214 minecraft:redstone_wire replace
setblock ~214 ~21 ~215 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~21 ~218 ~222 ~21 ~218 minecraft:redstone_wire replace
setblock ~220 ~21 ~219 minecraft:redstone_wire replace
fill ~219 ~21 ~222 ~225 ~21 ~222 minecraft:redstone_wire replace
setblock ~220 ~21 ~223 minecraft:redstone_wire replace
fill ~243 ~21 ~226 ~252 ~21 ~226 minecraft:redstone_wire replace
setblock ~244 ~21 ~227 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~21 ~230 ~255 ~21 ~230 minecraft:redstone_wire replace
setblock ~247 ~21 ~231 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~21 ~234 ~267 ~21 ~234 minecraft:redstone_wire replace
setblock ~259 ~21 ~235 minecraft:redstone_wire replace
fill ~267 ~21 ~238 ~276 ~21 ~238 minecraft:redstone_wire replace
setblock ~268 ~21 ~239 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~21 ~242 ~279 ~21 ~242 minecraft:redstone_wire replace
setblock ~271 ~21 ~243 minecraft:redstone_wire replace
fill ~270 ~21 ~246 ~271 ~21 ~246 minecraft:redstone_wire replace
setblock ~273 ~21 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~21 ~246 ~282 ~21 ~246 minecraft:redstone_wire replace
setblock ~271 ~21 ~247 minecraft:redstone_wire replace
fill ~228 ~21 ~250 ~234 ~21 ~250 minecraft:redstone_wire replace
setblock ~229 ~21 ~251 minecraft:redstone_wire replace
fill ~234 ~21 ~254 ~240 ~21 ~254 minecraft:redstone_wire replace
setblock ~235 ~21 ~255 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~21 ~258 ~243 ~21 ~258 minecraft:redstone_wire replace
setblock ~238 ~21 ~259 minecraft:redstone_wire replace
fill ~237 ~21 ~262 ~246 ~21 ~262 minecraft:redstone_wire replace
setblock ~238 ~21 ~263 minecraft:redstone_wire replace
fill ~252 ~21 ~266 ~261 ~21 ~266 minecraft:redstone_wire replace
setblock ~253 ~21 ~267 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~21 ~270 ~273 ~21 ~270 minecraft:redstone_wire replace
setblock ~265 ~21 ~271 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~21 ~274 ~288 ~21 ~274 minecraft:redstone_wire replace
setblock ~277 ~21 ~275 minecraft:redstone_wire replace
fill ~279 ~21 ~278 ~291 ~21 ~278 minecraft:redstone_wire replace
setblock ~280 ~21 ~279 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~21 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~21 ~282 ~294 ~21 ~282 minecraft:redstone_wire replace
setblock ~283 ~21 ~283 minecraft:redstone_wire replace
fill ~282 ~21 ~286 ~286 ~21 ~286 minecraft:redstone_wire replace
setblock ~288 ~21 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~21 ~286 ~297 ~21 ~286 minecraft:redstone_wire replace
setblock ~283 ~21 ~287 minecraft:redstone_wire replace
fill ~135 ~21 ~290 ~146 ~21 ~290 minecraft:redstone_wire replace
setblock ~148 ~21 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~21 ~290 ~163 ~21 ~290 minecraft:redstone_wire replace
setblock ~164 ~21 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~21 ~290 ~189 ~21 ~290 minecraft:redstone_wire replace
setblock ~191 ~21 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~21 ~290 ~206 ~21 ~290 minecraft:redstone_wire replace
setblock ~136 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~21 ~291 minecraft:redstone_wire replace
setblock ~166 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~21 ~291 minecraft:redstone_wire replace
setblock ~178 ~21 ~291 minecraft:redstone_wire replace
setblock ~184 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~21 ~291 minecraft:redstone_wire replace
setblock ~205 ~21 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~21 ~294 ~139 ~21 ~294 minecraft:redstone_wire replace
setblock ~141 ~21 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~21 ~294 ~156 ~21 ~294 minecraft:redstone_wire replace
setblock ~158 ~21 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~21 ~294 ~173 ~21 ~294 minecraft:redstone_wire replace
setblock ~174 ~21 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~21 ~294 ~185 ~21 ~294 minecraft:redstone_wire replace
setblock ~186 ~21 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~21 ~294 ~200 ~21 ~294 minecraft:redstone_wire replace
setblock ~202 ~21 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~21 ~294 ~206 ~21 ~294 minecraft:redstone_wire replace
setblock ~136 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~21 ~295 minecraft:redstone_wire replace
setblock ~166 ~21 ~295 minecraft:redstone_wire replace
setblock ~172 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~21 ~295 minecraft:redstone_wire replace
setblock ~187 ~21 ~295 minecraft:redstone_wire replace
setblock ~205 ~21 ~295 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~21 ~298 ~164 ~21 ~298 minecraft:redstone_wire replace
setblock ~165 ~21 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~21 ~298 ~178 ~21 ~298 minecraft:redstone_wire replace
setblock ~179 ~21 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~21 ~298 ~193 ~21 ~298 minecraft:redstone_wire replace
setblock ~195 ~21 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~197 ~21 ~298 ~206 ~21 ~298 minecraft:redstone_wire replace
setblock ~163 ~21 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~21 ~299 minecraft:redstone_wire replace
setblock ~172 ~21 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~21 ~299 minecraft:redstone_wire replace
setblock ~184 ~21 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~21 ~299 minecraft:redstone_wire replace
setblock ~205 ~21 ~299 minecraft:redstone_wire replace
fill ~285 ~21 ~302 ~287 ~21 ~302 minecraft:redstone_wire replace
setblock ~288 ~21 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~21 ~302 ~300 ~21 ~302 minecraft:redstone_wire replace
setblock ~286 ~21 ~303 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~21 ~306 ~228 ~21 ~306 minecraft:redstone_wire replace
setblock ~223 ~21 ~307 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~79 ~22 ~12 minecraft:redstone_wire replace
setblock ~103 ~22 ~16 minecraft:redstone_wire replace
setblock ~91 ~22 ~20 minecraft:redstone_wire replace
setblock ~109 ~22 ~24 minecraft:redstone_wire replace
setblock ~106 ~22 ~28 minecraft:redstone_wire replace
setblock ~124 ~22 ~32 minecraft:redstone_wire replace
setblock ~127 ~22 ~36 minecraft:redstone_wire replace
setblock ~145 ~22 ~40 minecraft:redstone_wire replace
setblock ~151 ~22 ~44 minecraft:redstone_wire replace
setblock ~169 ~22 ~48 minecraft:redstone_wire replace
setblock ~175 ~22 ~52 minecraft:redstone_wire replace
setblock ~199 ~22 ~56 minecraft:redstone_wire replace
setblock ~208 ~22 ~60 minecraft:redstone_wire replace
setblock ~232 ~22 ~64 minecraft:redstone_wire replace
setblock ~241 ~22 ~68 minecraft:redstone_wire replace
setblock ~256 ~22 ~72 minecraft:redstone_wire replace
setblock ~226 ~22 ~76 minecraft:redstone_wire replace
setblock ~262 ~22 ~80 minecraft:redstone_wire replace
setblock ~250 ~22 ~84 minecraft:redstone_wire replace
setblock ~274 ~22 ~88 minecraft:redstone_wire replace
setblock ~82 ~22 ~92 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~22 ~96 minecraft:redstone_wire replace
setblock ~88 ~22 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~22 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~22 ~108 minecraft:redstone_wire replace
setblock ~94 ~22 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~22 ~116 minecraft:redstone_wire replace
setblock ~100 ~22 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~22 ~124 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~22 ~128 minecraft:redstone_wire replace
setblock ~112 ~22 ~132 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~22 ~136 minecraft:redstone_wire replace
setblock ~118 ~22 ~140 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~22 ~144 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~22 ~148 minecraft:redstone_wire replace
setblock ~130 ~22 ~152 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~22 ~156 minecraft:redstone_wire replace
setblock ~142 ~22 ~160 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~22 ~164 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~22 ~168 minecraft:redstone_wire replace
setblock ~154 ~22 ~172 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~22 ~176 minecraft:redstone_wire replace
setblock ~160 ~22 ~180 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~22 ~184 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~22 ~188 minecraft:redstone_wire replace
setblock ~190 ~22 ~192 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~22 ~196 minecraft:redstone_wire replace
setblock ~196 ~22 ~200 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~22 ~204 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~22 ~208 minecraft:redstone_wire replace
setblock ~211 ~22 ~212 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~22 ~216 minecraft:redstone_wire replace
setblock ~220 ~22 ~220 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~22 ~224 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~22 ~228 minecraft:redstone_wire replace
setblock ~247 ~22 ~232 minecraft:redstone_wire replace
setblock ~259 ~22 ~236 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~22 ~240 minecraft:redstone_wire replace
setblock ~271 ~22 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~22 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~22 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~22 ~256 minecraft:redstone_wire replace
setblock ~238 ~22 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~22 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~22 ~268 minecraft:redstone_wire replace
setblock ~265 ~22 ~272 minecraft:redstone_wire replace
setblock ~277 ~22 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~22 ~280 minecraft:redstone_wire replace
setblock ~283 ~22 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~22 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~22 ~292 minecraft:redstone_wire replace
setblock ~163 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~22 ~292 minecraft:redstone_wire replace
setblock ~172 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~22 ~292 minecraft:redstone_wire replace
setblock ~187 ~22 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~22 ~292 minecraft:redstone_wire replace
setblock ~136 ~22 ~296 minecraft:redstone_wire replace
setblock ~163 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~22 ~296 minecraft:redstone_wire replace
setblock ~178 ~22 ~296 minecraft:redstone_wire replace
setblock ~184 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~22 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~22 ~296 minecraft:redstone_wire replace
setblock ~163 ~22 ~300 minecraft:redstone_wire replace
setblock ~166 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~22 ~300 minecraft:redstone_wire replace
setblock ~178 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~22 ~300 minecraft:redstone_wire replace
setblock ~187 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~22 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~22 ~304 minecraft:redstone_wire replace
setblock ~223 ~22 ~308 minecraft:redstone_wire replace
fill ~78 ~23 ~8 ~78 ~23 ~12 minecraft:redstone_wire replace
fill ~102 ~23 ~12 ~102 ~23 ~16 minecraft:redstone_wire replace
fill ~90 ~23 ~16 ~90 ~23 ~20 minecraft:redstone_wire replace
fill ~108 ~23 ~20 ~108 ~23 ~24 minecraft:redstone_wire replace
fill ~105 ~23 ~24 ~105 ~23 ~28 minecraft:redstone_wire replace
fill ~123 ~23 ~28 ~123 ~23 ~32 minecraft:redstone_wire replace
fill ~126 ~23 ~32 ~126 ~23 ~36 minecraft:redstone_wire replace
fill ~144 ~23 ~36 ~144 ~23 ~40 minecraft:redstone_wire replace
fill ~150 ~23 ~40 ~150 ~23 ~44 minecraft:redstone_wire replace
fill ~168 ~23 ~44 ~168 ~23 ~48 minecraft:redstone_wire replace
fill ~174 ~23 ~48 ~174 ~23 ~52 minecraft:redstone_wire replace
fill ~198 ~23 ~52 ~198 ~23 ~56 minecraft:redstone_wire replace
fill ~207 ~23 ~56 ~207 ~23 ~60 minecraft:redstone_wire replace
fill ~231 ~23 ~60 ~231 ~23 ~64 minecraft:redstone_wire replace
fill ~240 ~23 ~64 ~240 ~23 ~68 minecraft:redstone_wire replace
fill ~255 ~23 ~68 ~255 ~23 ~72 minecraft:redstone_wire replace
fill ~225 ~23 ~72 ~225 ~23 ~76 minecraft:redstone_wire replace
fill ~261 ~23 ~76 ~261 ~23 ~80 minecraft:redstone_wire replace
fill ~249 ~23 ~80 ~249 ~23 ~84 minecraft:redstone_wire replace
fill ~273 ~23 ~84 ~273 ~23 ~88 minecraft:redstone_wire replace
fill ~81 ~23 ~88 ~81 ~23 ~92 minecraft:redstone_wire replace
fill ~84 ~23 ~92 ~84 ~23 ~96 minecraft:redstone_wire replace
setblock ~87 ~23 ~96 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~23 ~98 ~87 ~23 ~104 minecraft:redstone_wire replace
fill ~120 ~23 ~104 ~120 ~23 ~108 minecraft:redstone_wire replace
fill ~93 ~23 ~108 ~93 ~23 ~112 minecraft:redstone_wire replace
fill ~96 ~23 ~112 ~96 ~23 ~116 minecraft:redstone_wire replace
setblock ~99 ~23 ~116 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~23 ~118 ~99 ~23 ~124 minecraft:redstone_wire replace
fill ~132 ~23 ~124 ~132 ~23 ~128 minecraft:redstone_wire replace
fill ~111 ~23 ~128 ~111 ~23 ~132 minecraft:redstone_wire replace
fill ~114 ~23 ~132 ~114 ~23 ~136 minecraft:redstone_wire replace
setblock ~117 ~23 ~136 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~23 ~138 ~117 ~23 ~144 minecraft:redstone_wire replace
fill ~147 ~23 ~144 ~147 ~23 ~148 minecraft:redstone_wire replace
fill ~129 ~23 ~148 ~129 ~23 ~152 minecraft:redstone_wire replace
fill ~138 ~23 ~152 ~138 ~23 ~156 minecraft:redstone_wire replace
setblock ~141 ~23 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~23 ~158 ~141 ~23 ~164 minecraft:redstone_wire replace
setblock ~180 ~23 ~160 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~23 ~162 ~180 ~23 ~168 minecraft:redstone_wire replace
setblock ~153 ~23 ~164 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~23 ~166 ~153 ~23 ~172 minecraft:redstone_wire replace
setblock ~156 ~23 ~168 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~23 ~170 ~156 ~23 ~176 minecraft:redstone_wire replace
setblock ~159 ~23 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~23 ~174 ~159 ~23 ~184 minecraft:redstone_wire replace
setblock ~201 ~23 ~176 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~23 ~178 ~201 ~23 ~188 minecraft:redstone_wire replace
setblock ~189 ~23 ~180 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~23 ~182 ~189 ~23 ~192 minecraft:redstone_wire replace
setblock ~192 ~23 ~184 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~23 ~186 ~192 ~23 ~196 minecraft:redstone_wire replace
setblock ~195 ~23 ~188 minecraft:redstone_wire replace
setblock ~195 ~23 ~190 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~23 ~192 ~195 ~23 ~204 minecraft:redstone_wire replace
setblock ~216 ~23 ~192 minecraft:redstone_wire replace
setblock ~216 ~23 ~194 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~23 ~196 minecraft:redstone_wire replace
fill ~216 ~23 ~196 ~216 ~23 ~208 minecraft:redstone_wire replace
setblock ~210 ~23 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~23 ~200 ~210 ~23 ~212 minecraft:redstone_wire replace
setblock ~213 ~23 ~200 minecraft:redstone_wire replace
setblock ~213 ~23 ~202 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~213 ~23 ~204 ~213 ~23 ~216 minecraft:redstone_wire replace
fill ~219 ~23 ~204 ~219 ~23 ~208 minecraft:redstone_wire replace
fill ~243 ~23 ~208 ~243 ~23 ~212 minecraft:redstone_wire replace
setblock ~219 ~23 ~210 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~219 ~23 ~212 ~219 ~23 ~224 minecraft:redstone_wire replace
fill ~246 ~23 ~212 ~246 ~23 ~216 minecraft:redstone_wire replace
setblock ~243 ~23 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~23 ~216 ~243 ~23 ~228 minecraft:redstone_wire replace
fill ~258 ~23 ~216 ~258 ~23 ~220 minecraft:redstone_wire replace
setblock ~246 ~23 ~218 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~23 ~220 ~246 ~23 ~232 minecraft:redstone_wire replace
fill ~267 ~23 ~220 ~267 ~23 ~224 minecraft:redstone_wire replace
setblock ~258 ~23 ~222 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~23 ~224 ~258 ~23 ~236 minecraft:redstone_wire replace
setblock ~270 ~23 ~224 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~267 ~23 ~226 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~23 ~226 ~270 ~23 ~232 minecraft:redstone_wire replace
setblock ~228 ~23 ~228 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~23 ~228 ~267 ~23 ~240 minecraft:redstone_wire replace
fill ~228 ~23 ~230 ~228 ~23 ~236 minecraft:redstone_wire replace
setblock ~234 ~23 ~232 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~234 ~23 ~234 ~234 ~23 ~240 minecraft:redstone_wire replace
setblock ~270 ~23 ~234 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~237 ~23 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~23 ~236 ~270 ~23 ~248 minecraft:redstone_wire replace
setblock ~228 ~23 ~238 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~23 ~238 ~237 ~23 ~248 minecraft:redstone_wire replace
fill ~228 ~23 ~240 ~228 ~23 ~252 minecraft:redstone_wire replace
setblock ~252 ~23 ~240 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~234 ~23 ~242 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~23 ~242 ~252 ~23 ~252 minecraft:redstone_wire replace
fill ~234 ~23 ~244 ~234 ~23 ~256 minecraft:redstone_wire replace
setblock ~264 ~23 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~23 ~246 ~264 ~23 ~256 minecraft:redstone_wire replace
setblock ~276 ~23 ~248 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~237 ~23 ~250 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~23 ~250 ~276 ~23 ~260 minecraft:redstone_wire replace
fill ~237 ~23 ~252 ~237 ~23 ~264 minecraft:redstone_wire replace
setblock ~279 ~23 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~23 ~254 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~23 ~254 ~279 ~23 ~264 minecraft:redstone_wire replace
fill ~252 ~23 ~256 ~252 ~23 ~268 minecraft:redstone_wire replace
setblock ~282 ~23 ~256 minecraft:redstone_wire replace
setblock ~264 ~23 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~282 ~23 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~23 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~23 ~260 ~264 ~23 ~272 minecraft:redstone_wire replace
fill ~282 ~23 ~260 ~282 ~23 ~272 minecraft:redstone_wire replace
fill ~204 ~23 ~262 ~204 ~23 ~268 minecraft:redstone_wire replace
setblock ~276 ~23 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~23 ~264 ~186 ~23 ~268 minecraft:redstone_wire replace
fill ~276 ~23 ~264 ~276 ~23 ~276 minecraft:redstone_wire replace
setblock ~279 ~23 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~23 ~268 minecraft:redstone_wire replace
fill ~279 ~23 ~268 ~279 ~23 ~280 minecraft:redstone_wire replace
setblock ~183 ~23 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~23 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~23 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~23 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~23 ~272 ~183 ~23 ~284 minecraft:redstone_wire replace
fill ~186 ~23 ~272 ~186 ~23 ~284 minecraft:redstone_wire replace
fill ~204 ~23 ~272 ~204 ~23 ~284 minecraft:redstone_wire replace
fill ~177 ~23 ~274 ~177 ~23 ~284 minecraft:redstone_wire replace
setblock ~282 ~23 ~274 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~23 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~23 ~276 ~282 ~23 ~288 minecraft:redstone_wire replace
fill ~171 ~23 ~278 ~171 ~23 ~284 minecraft:redstone_wire replace
fill ~165 ~23 ~280 ~165 ~23 ~284 minecraft:redstone_wire replace
setblock ~162 ~23 ~284 minecraft:redstone_wire replace
setblock ~162 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~23 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~23 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~23 ~288 ~162 ~23 ~300 minecraft:redstone_wire replace
fill ~165 ~23 ~288 ~165 ~23 ~300 minecraft:redstone_wire replace
fill ~171 ~23 ~288 ~171 ~23 ~300 minecraft:redstone_wire replace
fill ~177 ~23 ~288 ~177 ~23 ~300 minecraft:redstone_wire replace
fill ~183 ~23 ~288 ~183 ~23 ~300 minecraft:redstone_wire replace
fill ~186 ~23 ~288 ~186 ~23 ~300 minecraft:redstone_wire replace
fill ~204 ~23 ~288 ~204 ~23 ~300 minecraft:redstone_wire replace
fill ~135 ~23 ~290 ~135 ~23 ~296 minecraft:redstone_wire replace
fill ~285 ~23 ~300 ~285 ~23 ~304 minecraft:redstone_wire replace
fill ~222 ~23 ~304 ~222 ~23 ~308 minecraft:redstone_wire replace
setblock ~78 ~24 ~7 minecraft:redstone_wire replace
setblock ~102 ~24 ~11 minecraft:redstone_wire replace
setblock ~90 ~24 ~15 minecraft:redstone_wire replace
setblock ~108 ~24 ~19 minecraft:redstone_wire replace
setblock ~105 ~24 ~23 minecraft:redstone_wire replace
setblock ~123 ~24 ~27 minecraft:redstone_wire replace
setblock ~126 ~24 ~31 minecraft:redstone_wire replace
setblock ~144 ~24 ~35 minecraft:redstone_wire replace
setblock ~150 ~24 ~39 minecraft:redstone_wire replace
setblock ~168 ~24 ~43 minecraft:redstone_wire replace
setblock ~174 ~24 ~47 minecraft:redstone_wire replace
setblock ~198 ~24 ~51 minecraft:redstone_wire replace
setblock ~207 ~24 ~55 minecraft:redstone_wire replace
setblock ~231 ~24 ~59 minecraft:redstone_wire replace
setblock ~240 ~24 ~63 minecraft:redstone_wire replace
setblock ~255 ~24 ~67 minecraft:redstone_wire replace
setblock ~225 ~24 ~71 minecraft:redstone_wire replace
setblock ~261 ~24 ~75 minecraft:redstone_wire replace
setblock ~249 ~24 ~79 minecraft:redstone_wire replace
setblock ~273 ~24 ~83 minecraft:redstone_wire replace
setblock ~81 ~24 ~87 minecraft:redstone_wire replace
setblock ~84 ~24 ~91 minecraft:redstone_wire replace
setblock ~87 ~24 ~95 minecraft:redstone_wire replace
setblock ~120 ~24 ~103 minecraft:redstone_wire replace
setblock ~93 ~24 ~107 minecraft:redstone_wire replace
setblock ~96 ~24 ~111 minecraft:redstone_wire replace
setblock ~99 ~24 ~115 minecraft:redstone_wire replace
setblock ~132 ~24 ~123 minecraft:redstone_wire replace
setblock ~111 ~24 ~127 minecraft:redstone_wire replace
setblock ~114 ~24 ~131 minecraft:redstone_wire replace
setblock ~117 ~24 ~135 minecraft:redstone_wire replace
setblock ~147 ~24 ~143 minecraft:redstone_wire replace
setblock ~129 ~24 ~147 minecraft:redstone_wire replace
setblock ~138 ~24 ~151 minecraft:redstone_wire replace
setblock ~141 ~24 ~155 minecraft:redstone_wire replace
setblock ~180 ~24 ~159 minecraft:redstone_wire replace
setblock ~153 ~24 ~163 minecraft:redstone_wire replace
setblock ~156 ~24 ~167 minecraft:redstone_wire replace
setblock ~159 ~24 ~171 minecraft:redstone_wire replace
setblock ~201 ~24 ~175 minecraft:redstone_wire replace
setblock ~189 ~24 ~179 minecraft:redstone_wire replace
setblock ~192 ~24 ~183 minecraft:redstone_wire replace
setblock ~195 ~24 ~187 minecraft:redstone_wire replace
setblock ~216 ~24 ~191 minecraft:redstone_wire replace
setblock ~210 ~24 ~195 minecraft:redstone_wire replace
setblock ~213 ~24 ~199 minecraft:redstone_wire replace
setblock ~219 ~24 ~203 minecraft:redstone_wire replace
setblock ~243 ~24 ~207 minecraft:redstone_wire replace
setblock ~246 ~24 ~211 minecraft:redstone_wire replace
setblock ~258 ~24 ~215 minecraft:redstone_wire replace
setblock ~267 ~24 ~219 minecraft:redstone_wire replace
setblock ~270 ~24 ~223 minecraft:redstone_wire replace
setblock ~228 ~24 ~227 minecraft:redstone_wire replace
setblock ~234 ~24 ~231 minecraft:redstone_wire replace
setblock ~237 ~24 ~235 minecraft:redstone_wire replace
setblock ~252 ~24 ~239 minecraft:redstone_wire replace
setblock ~264 ~24 ~243 minecraft:redstone_wire replace
setblock ~276 ~24 ~247 minecraft:redstone_wire replace
setblock ~279 ~24 ~251 minecraft:redstone_wire replace
setblock ~282 ~24 ~255 minecraft:redstone_wire replace
setblock ~204 ~24 ~259 minecraft:redstone_wire replace
setblock ~186 ~24 ~263 minecraft:redstone_wire replace
setblock ~183 ~24 ~267 minecraft:redstone_wire replace
setblock ~177 ~24 ~271 minecraft:redstone_wire replace
setblock ~171 ~24 ~275 minecraft:redstone_wire replace
setblock ~165 ~24 ~279 minecraft:redstone_wire replace
setblock ~162 ~24 ~283 minecraft:redstone_wire replace
setblock ~135 ~24 ~287 minecraft:redstone_wire replace
setblock ~285 ~24 ~299 minecraft:redstone_wire replace
setblock ~222 ~24 ~303 minecraft:redstone_wire replace
setblock ~79 ~25 ~5 minecraft:redstone_wire replace
fill ~78 ~25 ~6 ~80 ~25 ~6 minecraft:redstone_wire replace
setblock ~97 ~25 ~9 minecraft:redstone_wire replace
setblock ~127 ~25 ~9 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~25 ~10 ~108 ~25 ~10 minecraft:redstone_wire replace
setblock ~110 ~25 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~25 ~10 ~125 ~25 ~10 minecraft:redstone_wire replace
setblock ~126 ~25 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~25 ~10 ~128 ~25 ~10 minecraft:redstone_wire replace
setblock ~100 ~25 ~13 minecraft:redstone_wire replace
fill ~90 ~25 ~14 ~96 ~25 ~14 minecraft:redstone_wire replace
setblock ~98 ~25 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~100 ~25 ~14 ~101 ~25 ~14 minecraft:redstone_wire replace
setblock ~91 ~25 ~17 minecraft:redstone_wire replace
setblock ~115 ~25 ~17 minecraft:redstone_wire replace
setblock ~154 ~25 ~17 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~25 ~18 ~98 ~25 ~18 minecraft:redstone_wire replace
setblock ~100 ~25 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~25 ~18 ~113 ~25 ~18 minecraft:redstone_wire replace
setblock ~114 ~25 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~25 ~18 ~127 ~25 ~18 minecraft:redstone_wire replace
setblock ~129 ~25 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~131 ~25 ~18 ~143 ~25 ~18 minecraft:redstone_wire replace
setblock ~145 ~25 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~25 ~18 ~155 ~25 ~18 minecraft:redstone_wire replace
setblock ~118 ~25 ~21 minecraft:redstone_wire replace
fill ~105 ~25 ~22 ~111 ~25 ~22 minecraft:redstone_wire replace
setblock ~113 ~25 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~25 ~22 ~119 ~25 ~22 minecraft:redstone_wire replace
setblock ~112 ~25 ~25 minecraft:redstone_wire replace
setblock ~142 ~25 ~25 minecraft:redstone_wire replace
setblock ~178 ~25 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~25 ~26 ~113 ~25 ~26 minecraft:redstone_wire replace
setblock ~115 ~25 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~25 ~26 ~129 ~25 ~26 minecraft:redstone_wire replace
setblock ~131 ~25 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~25 ~26 ~146 ~25 ~26 minecraft:redstone_wire replace
setblock ~148 ~25 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~25 ~26 ~163 ~25 ~26 minecraft:redstone_wire replace
setblock ~165 ~25 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~167 ~25 ~26 ~179 ~25 ~26 minecraft:redstone_wire replace
setblock ~145 ~25 ~29 minecraft:redstone_wire replace
fill ~126 ~25 ~30 ~132 ~25 ~30 minecraft:redstone_wire replace
setblock ~134 ~25 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~25 ~30 ~146 ~25 ~30 minecraft:redstone_wire replace
setblock ~139 ~25 ~33 minecraft:redstone_wire replace
setblock ~175 ~25 ~33 minecraft:redstone_wire replace
setblock ~208 ~25 ~33 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~25 ~34 ~150 ~25 ~34 minecraft:redstone_wire replace
setblock ~152 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~154 ~25 ~34 ~167 ~25 ~34 minecraft:redstone_wire replace
setblock ~169 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~25 ~34 ~184 ~25 ~34 minecraft:redstone_wire replace
setblock ~186 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~188 ~25 ~34 ~201 ~25 ~34 minecraft:redstone_wire replace
setblock ~203 ~25 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~25 ~34 ~209 ~25 ~34 minecraft:redstone_wire replace
setblock ~187 ~25 ~37 minecraft:redstone_wire replace
fill ~150 ~25 ~38 ~156 ~25 ~38 minecraft:redstone_wire replace
setblock ~158 ~25 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~25 ~38 ~173 ~25 ~38 minecraft:redstone_wire replace
setblock ~175 ~25 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~25 ~38 ~188 ~25 ~38 minecraft:redstone_wire replace
setblock ~172 ~25 ~41 minecraft:redstone_wire replace
setblock ~202 ~25 ~41 minecraft:redstone_wire replace
setblock ~226 ~25 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~25 ~42 ~173 ~25 ~42 minecraft:redstone_wire replace
setblock ~175 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~25 ~42 ~189 ~25 ~42 minecraft:redstone_wire replace
setblock ~191 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~25 ~42 ~205 ~25 ~42 minecraft:redstone_wire replace
setblock ~207 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~209 ~25 ~42 ~221 ~25 ~42 minecraft:redstone_wire replace
setblock ~223 ~25 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~25 ~42 ~227 ~25 ~42 minecraft:redstone_wire replace
setblock ~205 ~25 ~45 minecraft:redstone_wire replace
fill ~174 ~25 ~46 ~180 ~25 ~46 minecraft:redstone_wire replace
setblock ~182 ~25 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~184 ~25 ~46 ~197 ~25 ~46 minecraft:redstone_wire replace
setblock ~199 ~25 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~201 ~25 ~46 ~206 ~25 ~46 minecraft:redstone_wire replace
setblock ~199 ~25 ~49 minecraft:redstone_wire replace
setblock ~238 ~25 ~49 minecraft:redstone_wire replace
setblock ~250 ~25 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~25 ~50 ~204 ~25 ~50 minecraft:redstone_wire replace
setblock ~206 ~25 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~25 ~50 ~221 ~25 ~50 minecraft:redstone_wire replace
setblock ~223 ~25 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~25 ~50 ~238 ~25 ~50 minecraft:redstone_wire replace
setblock ~239 ~25 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~25 ~50 ~251 ~25 ~50 minecraft:redstone_wire replace
setblock ~241 ~25 ~53 minecraft:redstone_wire replace
fill ~207 ~25 ~54 ~213 ~25 ~54 minecraft:redstone_wire replace
setblock ~215 ~25 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~25 ~54 ~230 ~25 ~54 minecraft:redstone_wire replace
setblock ~232 ~25 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~25 ~54 ~242 ~25 ~54 minecraft:redstone_wire replace
setblock ~235 ~25 ~57 minecraft:redstone_wire replace
setblock ~283 ~25 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~25 ~57 minecraft:redstone_wire replace
fill ~231 ~25 ~58 ~237 ~25 ~58 minecraft:redstone_wire replace
setblock ~239 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~25 ~58 ~254 ~25 ~58 minecraft:redstone_wire replace
setblock ~256 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~258 ~25 ~58 ~271 ~25 ~58 minecraft:redstone_wire replace
setblock ~273 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~275 ~25 ~58 ~288 ~25 ~58 minecraft:redstone_wire replace
setblock ~290 ~25 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~58 ~293 ~25 ~58 minecraft:redstone_wire replace
setblock ~262 ~25 ~61 minecraft:redstone_wire replace
setblock ~271 ~25 ~61 minecraft:redstone_wire replace
setblock ~301 ~25 ~61 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~240 ~25 ~62 ~246 ~25 ~62 minecraft:redstone_wire replace
setblock ~248 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~25 ~62 ~263 ~25 ~62 minecraft:redstone_wire replace
setblock ~265 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~25 ~62 ~280 ~25 ~62 minecraft:redstone_wire replace
setblock ~282 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~284 ~25 ~62 ~297 ~25 ~62 minecraft:redstone_wire replace
setblock ~299 ~25 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~25 ~62 ~302 ~25 ~62 minecraft:redstone_wire replace
setblock ~316 ~25 ~65 minecraft:redstone_wire replace
fill ~255 ~25 ~66 ~261 ~25 ~66 minecraft:redstone_wire replace
setblock ~263 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~25 ~66 ~278 ~25 ~66 minecraft:redstone_wire replace
setblock ~280 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~25 ~66 ~295 ~25 ~66 minecraft:redstone_wire replace
setblock ~297 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~299 ~25 ~66 ~312 ~25 ~66 minecraft:redstone_wire replace
setblock ~314 ~25 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~316 ~25 ~66 ~317 ~25 ~66 minecraft:redstone_wire replace
setblock ~265 ~25 ~69 minecraft:redstone_wire replace
fill ~225 ~25 ~70 ~231 ~25 ~70 minecraft:redstone_wire replace
setblock ~233 ~25 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~25 ~70 ~248 ~25 ~70 minecraft:redstone_wire replace
setblock ~250 ~25 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~25 ~70 ~265 ~25 ~70 minecraft:redstone_wire replace
setblock ~266 ~25 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~310 ~25 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~25 ~73 minecraft:redstone_wire replace
setblock ~337 ~25 ~73 minecraft:redstone_wire replace
fill ~261 ~25 ~74 ~267 ~25 ~74 minecraft:redstone_wire replace
setblock ~269 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~271 ~25 ~74 ~284 ~25 ~74 minecraft:redstone_wire replace
setblock ~286 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~25 ~74 ~301 ~25 ~74 minecraft:redstone_wire replace
setblock ~303 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~305 ~25 ~74 ~318 ~25 ~74 minecraft:redstone_wire replace
setblock ~320 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~322 ~25 ~74 ~335 ~25 ~74 minecraft:redstone_wire replace
setblock ~336 ~25 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~25 ~74 ~338 ~25 ~74 minecraft:redstone_wire replace
setblock ~280 ~25 ~77 minecraft:redstone_wire replace
setblock ~328 ~25 ~77 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~25 ~78 ~255 ~25 ~78 minecraft:redstone_wire replace
setblock ~257 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~25 ~78 ~272 ~25 ~78 minecraft:redstone_wire replace
setblock ~274 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~25 ~78 ~289 ~25 ~78 minecraft:redstone_wire replace
setblock ~291 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~293 ~25 ~78 ~306 ~25 ~78 minecraft:redstone_wire replace
setblock ~308 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~25 ~78 ~323 ~25 ~78 minecraft:redstone_wire replace
setblock ~325 ~25 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~25 ~78 ~329 ~25 ~78 minecraft:redstone_wire replace
setblock ~343 ~25 ~81 minecraft:redstone_wire replace
fill ~273 ~25 ~82 ~279 ~25 ~82 minecraft:redstone_wire replace
setblock ~281 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~25 ~82 ~296 ~25 ~82 minecraft:redstone_wire replace
setblock ~298 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~25 ~82 ~313 ~25 ~82 minecraft:redstone_wire replace
setblock ~315 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~25 ~82 ~330 ~25 ~82 minecraft:redstone_wire replace
setblock ~332 ~25 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~25 ~82 ~344 ~25 ~82 minecraft:redstone_wire replace
setblock ~82 ~25 ~85 minecraft:redstone_wire replace
fill ~81 ~25 ~86 ~83 ~25 ~86 minecraft:redstone_wire replace
setblock ~85 ~25 ~89 minecraft:redstone_wire replace
fill ~84 ~25 ~90 ~86 ~25 ~90 minecraft:redstone_wire replace
setblock ~88 ~25 ~93 minecraft:redstone_wire replace
fill ~87 ~25 ~94 ~89 ~25 ~94 minecraft:redstone_wire replace
setblock ~133 ~25 ~101 minecraft:redstone_wire replace
setblock ~136 ~25 ~101 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~25 ~102 ~126 ~25 ~102 minecraft:redstone_wire replace
setblock ~128 ~25 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~25 ~102 ~137 ~25 ~102 minecraft:redstone_wire replace
setblock ~103 ~25 ~105 minecraft:redstone_wire replace
fill ~93 ~25 ~106 ~99 ~25 ~106 minecraft:redstone_wire replace
setblock ~101 ~25 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~25 ~106 ~104 ~25 ~106 minecraft:redstone_wire replace
setblock ~106 ~25 ~109 minecraft:redstone_wire replace
fill ~96 ~25 ~110 ~102 ~25 ~110 minecraft:redstone_wire replace
setblock ~104 ~25 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~25 ~110 ~107 ~25 ~110 minecraft:redstone_wire replace
setblock ~109 ~25 ~113 minecraft:redstone_wire replace
fill ~99 ~25 ~114 ~110 ~25 ~114 minecraft:redstone_wire replace
setblock ~157 ~25 ~121 minecraft:redstone_wire replace
setblock ~160 ~25 ~121 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~25 ~122 ~138 ~25 ~122 minecraft:redstone_wire replace
setblock ~140 ~25 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~25 ~122 ~155 ~25 ~122 minecraft:redstone_wire replace
setblock ~156 ~25 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~25 ~122 ~161 ~25 ~122 minecraft:redstone_wire replace
setblock ~121 ~25 ~125 minecraft:redstone_wire replace
fill ~111 ~25 ~126 ~117 ~25 ~126 minecraft:redstone_wire replace
setblock ~119 ~25 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~25 ~126 ~122 ~25 ~126 minecraft:redstone_wire replace
setblock ~124 ~25 ~129 minecraft:redstone_wire replace
fill ~114 ~25 ~130 ~120 ~25 ~130 minecraft:redstone_wire replace
setblock ~122 ~25 ~130 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~25 ~130 ~125 ~25 ~130 minecraft:redstone_wire replace
setblock ~130 ~25 ~133 minecraft:redstone_wire replace
fill ~117 ~25 ~134 ~128 ~25 ~134 minecraft:redstone_wire replace
setblock ~129 ~25 ~134 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~25 ~134 ~131 ~25 ~134 minecraft:redstone_wire replace
setblock ~181 ~25 ~141 minecraft:redstone_wire replace
setblock ~184 ~25 ~141 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~25 ~142 ~153 ~25 ~142 minecraft:redstone_wire replace
setblock ~155 ~25 ~142 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~25 ~142 ~170 ~25 ~142 minecraft:redstone_wire replace
setblock ~172 ~25 ~142 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~25 ~142 ~185 ~25 ~142 minecraft:redstone_wire replace
setblock ~151 ~25 ~145 minecraft:redstone_wire replace
fill ~129 ~25 ~146 ~135 ~25 ~146 minecraft:redstone_wire replace
setblock ~137 ~25 ~146 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~25 ~146 ~152 ~25 ~146 minecraft:redstone_wire replace
setblock ~166 ~25 ~149 minecraft:redstone_wire replace
fill ~138 ~25 ~150 ~144 ~25 ~150 minecraft:redstone_wire replace
setblock ~146 ~25 ~150 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~25 ~150 ~161 ~25 ~150 minecraft:redstone_wire replace
setblock ~163 ~25 ~150 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~25 ~150 ~167 ~25 ~150 minecraft:redstone_wire replace
setblock ~169 ~25 ~153 minecraft:redstone_wire replace
fill ~141 ~25 ~154 ~153 ~25 ~154 minecraft:redstone_wire replace
setblock ~155 ~25 ~154 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~25 ~154 ~170 ~25 ~154 minecraft:redstone_wire replace
setblock ~211 ~25 ~157 minecraft:redstone_wire replace
setblock ~214 ~25 ~157 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~25 ~158 ~192 ~25 ~158 minecraft:redstone_wire replace
setblock ~194 ~25 ~158 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~25 ~158 ~209 ~25 ~158 minecraft:redstone_wire replace
setblock ~210 ~25 ~158 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~25 ~158 ~215 ~25 ~158 minecraft:redstone_wire replace
setblock ~190 ~25 ~161 minecraft:redstone_wire replace
fill ~153 ~25 ~162 ~165 ~25 ~162 minecraft:redstone_wire replace
setblock ~167 ~25 ~162 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~25 ~162 ~182 ~25 ~162 minecraft:redstone_wire replace
setblock ~184 ~25 ~162 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~25 ~162 ~191 ~25 ~162 minecraft:redstone_wire replace
setblock ~193 ~25 ~165 minecraft:redstone_wire replace
fill ~156 ~25 ~166 ~168 ~25 ~166 minecraft:redstone_wire replace
setblock ~170 ~25 ~166 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~25 ~166 ~185 ~25 ~166 minecraft:redstone_wire replace
setblock ~187 ~25 ~166 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~25 ~166 ~194 ~25 ~166 minecraft:redstone_wire replace
setblock ~196 ~25 ~169 minecraft:redstone_wire replace
fill ~159 ~25 ~170 ~171 ~25 ~170 minecraft:redstone_wire replace
setblock ~173 ~25 ~170 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~25 ~170 ~188 ~25 ~170 minecraft:redstone_wire replace
setblock ~190 ~25 ~170 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~25 ~170 ~197 ~25 ~170 minecraft:redstone_wire replace
setblock ~229 ~25 ~173 minecraft:redstone_wire replace
setblock ~232 ~25 ~173 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~25 ~174 ~213 ~25 ~174 minecraft:redstone_wire replace
setblock ~215 ~25 ~174 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~25 ~174 ~230 ~25 ~174 minecraft:redstone_wire replace
setblock ~231 ~25 ~174 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~25 ~174 ~233 ~25 ~174 minecraft:redstone_wire replace
setblock ~217 ~25 ~177 minecraft:redstone_wire replace
fill ~189 ~25 ~178 ~201 ~25 ~178 minecraft:redstone_wire replace
setblock ~203 ~25 ~178 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~25 ~178 ~218 ~25 ~178 minecraft:redstone_wire replace
setblock ~220 ~25 ~181 minecraft:redstone_wire replace
fill ~192 ~25 ~182 ~204 ~25 ~182 minecraft:redstone_wire replace
setblock ~206 ~25 ~182 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~25 ~182 ~221 ~25 ~182 minecraft:redstone_wire replace
setblock ~223 ~25 ~185 minecraft:redstone_wire replace
fill ~195 ~25 ~186 ~206 ~25 ~186 minecraft:redstone_wire replace
setblock ~208 ~25 ~186 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~25 ~186 ~223 ~25 ~186 minecraft:redstone_wire replace
setblock ~224 ~25 ~186 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~253 ~25 ~189 minecraft:redstone_wire replace
setblock ~256 ~25 ~189 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~25 ~190 ~227 ~25 ~190 minecraft:redstone_wire replace
setblock ~229 ~25 ~190 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~231 ~25 ~190 ~244 ~25 ~190 minecraft:redstone_wire replace
setblock ~246 ~25 ~190 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~248 ~25 ~190 ~257 ~25 ~190 minecraft:redstone_wire replace
setblock ~244 ~25 ~193 minecraft:redstone_wire replace
fill ~210 ~25 ~194 ~221 ~25 ~194 minecraft:redstone_wire replace
setblock ~223 ~25 ~194 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~25 ~194 ~238 ~25 ~194 minecraft:redstone_wire replace
setblock ~240 ~25 ~194 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~242 ~25 ~194 ~245 ~25 ~194 minecraft:redstone_wire replace
setblock ~247 ~25 ~197 minecraft:redstone_wire replace
fill ~213 ~25 ~198 ~224 ~25 ~198 minecraft:redstone_wire replace
setblock ~226 ~25 ~198 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~25 ~198 ~241 ~25 ~198 minecraft:redstone_wire replace
setblock ~243 ~25 ~198 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~25 ~198 ~248 ~25 ~198 minecraft:redstone_wire replace
setblock ~259 ~25 ~201 minecraft:redstone_wire replace
fill ~219 ~25 ~202 ~226 ~25 ~202 minecraft:redstone_wire replace
setblock ~228 ~25 ~202 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~25 ~202 ~243 ~25 ~202 minecraft:redstone_wire replace
setblock ~245 ~25 ~202 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~25 ~202 ~260 ~25 ~202 minecraft:redstone_wire replace
setblock ~286 ~25 ~205 minecraft:redstone_wire replace
setblock ~289 ~25 ~205 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~25 ~206 ~250 ~25 ~206 minecraft:redstone_wire replace
setblock ~252 ~25 ~206 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~254 ~25 ~206 ~267 ~25 ~206 minecraft:redstone_wire replace
setblock ~269 ~25 ~206 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~271 ~25 ~206 ~284 ~25 ~206 minecraft:redstone_wire replace
setblock ~285 ~25 ~206 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~25 ~206 ~290 ~25 ~206 minecraft:redstone_wire replace
setblock ~295 ~25 ~209 minecraft:redstone_wire replace
setblock ~298 ~25 ~209 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~25 ~210 ~253 ~25 ~210 minecraft:redstone_wire replace
setblock ~255 ~25 ~210 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~257 ~25 ~210 ~270 ~25 ~210 minecraft:redstone_wire replace
setblock ~272 ~25 ~210 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~274 ~25 ~210 ~287 ~25 ~210 minecraft:redstone_wire replace
setblock ~289 ~25 ~210 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~25 ~210 ~299 ~25 ~210 minecraft:redstone_wire replace
setblock ~319 ~25 ~213 minecraft:redstone_wire replace
fill ~258 ~25 ~214 ~265 ~25 ~214 minecraft:redstone_wire replace
setblock ~267 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~25 ~214 ~282 ~25 ~214 minecraft:redstone_wire replace
setblock ~284 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~25 ~214 ~299 ~25 ~214 minecraft:redstone_wire replace
setblock ~301 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~25 ~214 ~316 ~25 ~214 minecraft:redstone_wire replace
setblock ~317 ~25 ~214 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~25 ~214 ~320 ~25 ~214 minecraft:redstone_wire replace
setblock ~331 ~25 ~217 minecraft:redstone_wire replace
fill ~267 ~25 ~218 ~274 ~25 ~218 minecraft:redstone_wire replace
setblock ~276 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~278 ~25 ~218 ~291 ~25 ~218 minecraft:redstone_wire replace
setblock ~293 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~25 ~218 ~308 ~25 ~218 minecraft:redstone_wire replace
setblock ~310 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~25 ~218 ~325 ~25 ~218 minecraft:redstone_wire replace
setblock ~327 ~25 ~218 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~25 ~218 ~332 ~25 ~218 minecraft:redstone_wire replace
setblock ~334 ~25 ~221 minecraft:redstone_wire replace
fill ~270 ~25 ~222 ~281 ~25 ~222 minecraft:redstone_wire replace
setblock ~283 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~25 ~222 ~297 ~25 ~222 minecraft:redstone_wire replace
setblock ~299 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~25 ~222 ~313 ~25 ~222 minecraft:redstone_wire replace
setblock ~315 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~25 ~222 ~329 ~25 ~222 minecraft:redstone_wire replace
setblock ~331 ~25 ~222 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~333 ~25 ~222 ~335 ~25 ~222 minecraft:redstone_wire replace
setblock ~268 ~25 ~225 minecraft:redstone_wire replace
fill ~228 ~25 ~226 ~240 ~25 ~226 minecraft:redstone_wire replace
setblock ~242 ~25 ~226 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~25 ~226 ~257 ~25 ~226 minecraft:redstone_wire replace
setblock ~259 ~25 ~226 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~25 ~226 ~269 ~25 ~226 minecraft:redstone_wire replace
setblock ~274 ~25 ~229 minecraft:redstone_wire replace
fill ~234 ~25 ~230 ~246 ~25 ~230 minecraft:redstone_wire replace
setblock ~248 ~25 ~230 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~25 ~230 ~263 ~25 ~230 minecraft:redstone_wire replace
setblock ~265 ~25 ~230 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~25 ~230 ~275 ~25 ~230 minecraft:redstone_wire replace
setblock ~277 ~25 ~233 minecraft:redstone_wire replace
fill ~237 ~25 ~234 ~249 ~25 ~234 minecraft:redstone_wire replace
setblock ~251 ~25 ~234 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~25 ~234 ~266 ~25 ~234 minecraft:redstone_wire replace
setblock ~268 ~25 ~234 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~25 ~234 ~278 ~25 ~234 minecraft:redstone_wire replace
setblock ~304 ~25 ~237 minecraft:redstone_wire replace
setblock ~307 ~25 ~237 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~25 ~238 ~264 ~25 ~238 minecraft:redstone_wire replace
setblock ~266 ~25 ~238 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~25 ~238 ~281 ~25 ~238 minecraft:redstone_wire replace
setblock ~283 ~25 ~238 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~25 ~238 ~298 ~25 ~238 minecraft:redstone_wire replace
setblock ~300 ~25 ~238 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~25 ~238 ~308 ~25 ~238 minecraft:redstone_wire replace
setblock ~322 ~25 ~241 minecraft:redstone_wire replace
setblock ~325 ~25 ~241 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~25 ~242 ~276 ~25 ~242 minecraft:redstone_wire replace
setblock ~278 ~25 ~242 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~25 ~242 ~293 ~25 ~242 minecraft:redstone_wire replace
setblock ~295 ~25 ~242 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~25 ~242 ~310 ~25 ~242 minecraft:redstone_wire replace
setblock ~312 ~25 ~242 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~25 ~242 ~326 ~25 ~242 minecraft:redstone_wire replace
setblock ~346 ~25 ~245 minecraft:redstone_wire replace
fill ~276 ~25 ~246 ~288 ~25 ~246 minecraft:redstone_wire replace
setblock ~290 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~246 ~305 ~25 ~246 minecraft:redstone_wire replace
setblock ~307 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~25 ~246 ~322 ~25 ~246 minecraft:redstone_wire replace
setblock ~324 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~326 ~25 ~246 ~339 ~25 ~246 minecraft:redstone_wire replace
setblock ~341 ~25 ~246 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~343 ~25 ~246 ~347 ~25 ~246 minecraft:redstone_wire replace
setblock ~349 ~25 ~249 minecraft:redstone_wire replace
fill ~279 ~25 ~250 ~291 ~25 ~250 minecraft:redstone_wire replace
setblock ~293 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~25 ~250 ~308 ~25 ~250 minecraft:redstone_wire replace
setblock ~310 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~25 ~250 ~325 ~25 ~250 minecraft:redstone_wire replace
setblock ~327 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~25 ~250 ~342 ~25 ~250 minecraft:redstone_wire replace
setblock ~344 ~25 ~250 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~346 ~25 ~250 ~350 ~25 ~250 minecraft:redstone_wire replace
setblock ~352 ~25 ~253 minecraft:redstone_wire replace
fill ~282 ~25 ~254 ~293 ~25 ~254 minecraft:redstone_wire replace
setblock ~295 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~25 ~254 ~310 ~25 ~254 minecraft:redstone_wire replace
setblock ~312 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~25 ~254 ~327 ~25 ~254 minecraft:redstone_wire replace
setblock ~329 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~25 ~254 ~344 ~25 ~254 minecraft:redstone_wire replace
setblock ~346 ~25 ~254 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~25 ~254 ~353 ~25 ~254 minecraft:redstone_wire replace
setblock ~133 ~25 ~257 minecraft:redstone_wire replace
setblock ~136 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~25 ~257 minecraft:redstone_wire replace
setblock ~157 ~25 ~257 minecraft:redstone_wire replace
setblock ~160 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~25 ~257 minecraft:redstone_wire replace
setblock ~184 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~25 ~257 minecraft:redstone_wire replace
setblock ~214 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~229 ~25 ~257 minecraft:redstone_wire replace
setblock ~232 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~25 ~257 minecraft:redstone_wire replace
setblock ~256 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~25 ~257 minecraft:redstone_wire replace
setblock ~289 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~25 ~257 minecraft:redstone_wire replace
setblock ~298 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~25 ~257 minecraft:redstone_wire replace
setblock ~307 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~25 ~257 minecraft:redstone_wire replace
setblock ~325 ~25 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~25 ~258 ~142 ~25 ~258 minecraft:redstone_wire replace
setblock ~144 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~25 ~258 ~158 ~25 ~258 minecraft:redstone_wire replace
setblock ~159 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~25 ~258 ~173 ~25 ~258 minecraft:redstone_wire replace
setblock ~175 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~25 ~258 ~189 ~25 ~258 minecraft:redstone_wire replace
setblock ~191 ~25 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~25 ~258 ~216 ~25 ~258 minecraft:redstone_wire replace
setblock ~218 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~25 ~258 ~233 ~25 ~258 minecraft:redstone_wire replace
setblock ~235 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~25 ~258 ~250 ~25 ~258 minecraft:redstone_wire replace
setblock ~251 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~25 ~258 ~265 ~25 ~258 minecraft:redstone_wire replace
setblock ~267 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~25 ~258 ~282 ~25 ~258 minecraft:redstone_wire replace
setblock ~284 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~25 ~258 ~299 ~25 ~258 minecraft:redstone_wire replace
setblock ~301 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~25 ~258 ~316 ~25 ~258 minecraft:redstone_wire replace
setblock ~318 ~25 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~320 ~25 ~258 ~326 ~25 ~258 minecraft:redstone_wire replace
setblock ~91 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~172 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~199 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~235 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~280 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~25 ~261 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~25 ~262 ~92 ~25 ~262 minecraft:redstone_wire replace
setblock ~93 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~25 ~262 ~107 ~25 ~262 minecraft:redstone_wire replace
setblock ~109 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~25 ~262 ~124 ~25 ~262 minecraft:redstone_wire replace
setblock ~126 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~25 ~262 ~141 ~25 ~262 minecraft:redstone_wire replace
setblock ~143 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~25 ~262 ~158 ~25 ~262 minecraft:redstone_wire replace
setblock ~160 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~25 ~262 ~175 ~25 ~262 minecraft:redstone_wire replace
setblock ~177 ~25 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~25 ~262 ~192 ~25 ~262 minecraft:redstone_wire replace
setblock ~194 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~25 ~262 ~208 ~25 ~262 minecraft:redstone_wire replace
setblock ~210 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~25 ~262 ~224 ~25 ~262 minecraft:redstone_wire replace
setblock ~226 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~25 ~262 ~240 ~25 ~262 minecraft:redstone_wire replace
setblock ~242 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~25 ~262 ~256 ~25 ~262 minecraft:redstone_wire replace
setblock ~258 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~260 ~25 ~262 ~272 ~25 ~262 minecraft:redstone_wire replace
setblock ~274 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~25 ~262 ~288 ~25 ~262 minecraft:redstone_wire replace
setblock ~290 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~262 ~304 ~25 ~262 minecraft:redstone_wire replace
setblock ~306 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~308 ~25 ~262 ~320 ~25 ~262 minecraft:redstone_wire replace
setblock ~322 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~324 ~25 ~262 ~336 ~25 ~262 minecraft:redstone_wire replace
setblock ~338 ~25 ~262 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~340 ~25 ~262 ~341 ~25 ~262 minecraft:redstone_wire replace
setblock ~88 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~109 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~196 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~25 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~25 ~266 ~91 ~25 ~266 minecraft:redstone_wire replace
setblock ~93 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~25 ~266 ~107 ~25 ~266 minecraft:redstone_wire replace
setblock ~108 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~25 ~266 ~121 ~25 ~266 minecraft:redstone_wire replace
setblock ~123 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~25 ~266 ~137 ~25 ~266 minecraft:redstone_wire replace
setblock ~139 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~25 ~266 ~153 ~25 ~266 minecraft:redstone_wire replace
setblock ~155 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~25 ~266 ~169 ~25 ~266 minecraft:redstone_wire replace
setblock ~171 ~25 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~25 ~266 ~194 ~25 ~266 minecraft:redstone_wire replace
setblock ~195 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~25 ~266 ~209 ~25 ~266 minecraft:redstone_wire replace
setblock ~211 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~25 ~266 ~226 ~25 ~266 minecraft:redstone_wire replace
setblock ~228 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~25 ~266 ~243 ~25 ~266 minecraft:redstone_wire replace
setblock ~245 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~25 ~266 ~260 ~25 ~266 minecraft:redstone_wire replace
setblock ~262 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~25 ~266 ~277 ~25 ~266 minecraft:redstone_wire replace
setblock ~278 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~25 ~266 ~292 ~25 ~266 minecraft:redstone_wire replace
setblock ~294 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~25 ~266 ~309 ~25 ~266 minecraft:redstone_wire replace
setblock ~311 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~313 ~25 ~266 ~326 ~25 ~266 minecraft:redstone_wire replace
setblock ~328 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~25 ~266 ~343 ~25 ~266 minecraft:redstone_wire replace
setblock ~345 ~25 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~347 ~25 ~266 ~353 ~25 ~266 minecraft:redstone_wire replace
setblock ~85 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~106 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~124 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~166 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~193 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~247 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~274 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~25 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~25 ~270 ~93 ~25 ~270 minecraft:redstone_wire replace
setblock ~95 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~25 ~270 ~110 ~25 ~270 minecraft:redstone_wire replace
setblock ~112 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~25 ~270 ~127 ~25 ~270 minecraft:redstone_wire replace
setblock ~129 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~25 ~270 ~144 ~25 ~270 minecraft:redstone_wire replace
setblock ~146 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~25 ~270 ~161 ~25 ~270 minecraft:redstone_wire replace
setblock ~163 ~25 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~25 ~270 ~189 ~25 ~270 minecraft:redstone_wire replace
setblock ~191 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~25 ~270 ~206 ~25 ~270 minecraft:redstone_wire replace
setblock ~208 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~25 ~270 ~223 ~25 ~270 minecraft:redstone_wire replace
setblock ~225 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~227 ~25 ~270 ~240 ~25 ~270 minecraft:redstone_wire replace
setblock ~242 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~25 ~270 ~257 ~25 ~270 minecraft:redstone_wire replace
setblock ~259 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~25 ~270 ~274 ~25 ~270 minecraft:redstone_wire replace
setblock ~275 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~25 ~270 ~289 ~25 ~270 minecraft:redstone_wire replace
setblock ~291 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~293 ~25 ~270 ~306 ~25 ~270 minecraft:redstone_wire replace
setblock ~308 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~25 ~270 ~323 ~25 ~270 minecraft:redstone_wire replace
setblock ~325 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~25 ~270 ~340 ~25 ~270 minecraft:redstone_wire replace
setblock ~342 ~25 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~25 ~270 ~350 ~25 ~270 minecraft:redstone_wire replace
setblock ~82 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~103 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~121 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~151 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~268 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~319 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~346 ~25 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~25 ~274 ~87 ~25 ~274 minecraft:redstone_wire replace
setblock ~89 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~91 ~25 ~274 ~104 ~25 ~274 minecraft:redstone_wire replace
setblock ~106 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~25 ~274 ~121 ~25 ~274 minecraft:redstone_wire replace
setblock ~123 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~25 ~274 ~138 ~25 ~274 minecraft:redstone_wire replace
setblock ~140 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~25 ~274 ~155 ~25 ~274 minecraft:redstone_wire replace
setblock ~157 ~25 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~25 ~274 ~183 ~25 ~274 minecraft:redstone_wire replace
setblock ~185 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~25 ~274 ~200 ~25 ~274 minecraft:redstone_wire replace
setblock ~202 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~25 ~274 ~217 ~25 ~274 minecraft:redstone_wire replace
setblock ~218 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~219 ~25 ~274 ~232 ~25 ~274 minecraft:redstone_wire replace
setblock ~234 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~236 ~25 ~274 ~249 ~25 ~274 minecraft:redstone_wire replace
setblock ~251 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~25 ~274 ~266 ~25 ~274 minecraft:redstone_wire replace
setblock ~267 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~25 ~274 ~281 ~25 ~274 minecraft:redstone_wire replace
setblock ~283 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~25 ~274 ~298 ~25 ~274 minecraft:redstone_wire replace
setblock ~300 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~25 ~274 ~315 ~25 ~274 minecraft:redstone_wire replace
setblock ~317 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~319 ~25 ~274 ~332 ~25 ~274 minecraft:redstone_wire replace
setblock ~334 ~25 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~336 ~25 ~274 ~347 ~25 ~274 minecraft:redstone_wire replace
setblock ~79 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~100 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~118 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~145 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~205 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~241 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~265 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~343 ~25 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~25 ~278 ~86 ~25 ~278 minecraft:redstone_wire replace
setblock ~88 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~25 ~278 ~103 ~25 ~278 minecraft:redstone_wire replace
setblock ~105 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~25 ~278 ~120 ~25 ~278 minecraft:redstone_wire replace
setblock ~122 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~25 ~278 ~137 ~25 ~278 minecraft:redstone_wire replace
setblock ~139 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~25 ~278 ~154 ~25 ~278 minecraft:redstone_wire replace
setblock ~156 ~25 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~25 ~278 ~171 ~25 ~278 minecraft:redstone_wire replace
setblock ~173 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~25 ~278 ~187 ~25 ~278 minecraft:redstone_wire replace
setblock ~188 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~25 ~278 ~201 ~25 ~278 minecraft:redstone_wire replace
setblock ~203 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~25 ~278 ~217 ~25 ~278 minecraft:redstone_wire replace
setblock ~219 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~25 ~278 ~233 ~25 ~278 minecraft:redstone_wire replace
setblock ~235 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~25 ~278 ~249 ~25 ~278 minecraft:redstone_wire replace
setblock ~251 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~25 ~278 ~265 ~25 ~278 minecraft:redstone_wire replace
setblock ~266 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~25 ~278 ~279 ~25 ~278 minecraft:redstone_wire replace
setblock ~281 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~25 ~278 ~295 ~25 ~278 minecraft:redstone_wire replace
setblock ~297 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~299 ~25 ~278 ~311 ~25 ~278 minecraft:redstone_wire replace
setblock ~313 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~25 ~278 ~327 ~25 ~278 minecraft:redstone_wire replace
setblock ~329 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~25 ~278 ~343 ~25 ~278 minecraft:redstone_wire replace
setblock ~344 ~25 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~94 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~97 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~175 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~271 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~25 ~281 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~25 ~282 ~98 ~25 ~282 minecraft:redstone_wire replace
setblock ~100 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~25 ~282 ~115 ~25 ~282 minecraft:redstone_wire replace
setblock ~116 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~25 ~282 ~130 ~25 ~282 minecraft:redstone_wire replace
setblock ~132 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~25 ~282 ~147 ~25 ~282 minecraft:redstone_wire replace
setblock ~149 ~25 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~25 ~282 ~173 ~25 ~282 minecraft:redstone_wire replace
setblock ~174 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~25 ~282 ~188 ~25 ~282 minecraft:redstone_wire replace
setblock ~190 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~25 ~282 ~205 ~25 ~282 minecraft:redstone_wire replace
setblock ~207 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~209 ~25 ~282 ~222 ~25 ~282 minecraft:redstone_wire replace
setblock ~224 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~25 ~282 ~239 ~25 ~282 minecraft:redstone_wire replace
setblock ~241 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~243 ~25 ~282 ~256 ~25 ~282 minecraft:redstone_wire replace
setblock ~258 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~260 ~25 ~282 ~273 ~25 ~282 minecraft:redstone_wire replace
setblock ~275 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~277 ~25 ~282 ~290 ~25 ~282 minecraft:redstone_wire replace
setblock ~291 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~25 ~282 ~305 ~25 ~282 minecraft:redstone_wire replace
setblock ~307 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~25 ~282 ~322 ~25 ~282 minecraft:redstone_wire replace
setblock ~324 ~25 ~282 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~326 ~25 ~282 ~338 ~25 ~282 minecraft:redstone_wire replace
setblock ~163 ~25 ~285 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~25 ~286 ~147 ~25 ~286 minecraft:redstone_wire replace
setblock ~149 ~25 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~151 ~25 ~286 ~164 ~25 ~286 minecraft:redstone_wire replace
setblock ~358 ~25 ~297 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~25 ~298 ~291 ~25 ~298 minecraft:redstone_wire replace
setblock ~293 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~25 ~298 ~308 ~25 ~298 minecraft:redstone_wire replace
setblock ~310 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~25 ~298 ~325 ~25 ~298 minecraft:redstone_wire replace
setblock ~327 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~25 ~298 ~342 ~25 ~298 minecraft:redstone_wire replace
setblock ~344 ~25 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~346 ~25 ~298 ~359 ~25 ~298 minecraft:redstone_wire replace
setblock ~94 ~25 ~301 minecraft:redstone_wire replace
setblock ~340 ~25 ~301 minecraft:redstone_wire replace
setblock ~355 ~25 ~301 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~25 ~302 ~95 ~25 ~302 minecraft:redstone_wire replace
setblock ~96 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~25 ~302 ~110 ~25 ~302 minecraft:redstone_wire replace
setblock ~112 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~25 ~302 ~127 ~25 ~302 minecraft:redstone_wire replace
setblock ~129 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~25 ~302 ~144 ~25 ~302 minecraft:redstone_wire replace
setblock ~146 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~25 ~302 ~161 ~25 ~302 minecraft:redstone_wire replace
setblock ~163 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~25 ~302 ~178 ~25 ~302 minecraft:redstone_wire replace
setblock ~180 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~25 ~302 ~195 ~25 ~302 minecraft:redstone_wire replace
setblock ~197 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~25 ~302 ~212 ~25 ~302 minecraft:redstone_wire replace
setblock ~214 ~25 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~25 ~302 ~228 ~25 ~302 minecraft:redstone_wire replace
setblock ~230 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~25 ~302 ~245 ~25 ~302 minecraft:redstone_wire replace
setblock ~247 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~25 ~302 ~262 ~25 ~302 minecraft:redstone_wire replace
setblock ~264 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~266 ~25 ~302 ~279 ~25 ~302 minecraft:redstone_wire replace
setblock ~281 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~25 ~302 ~296 ~25 ~302 minecraft:redstone_wire replace
setblock ~298 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~25 ~302 ~313 ~25 ~302 minecraft:redstone_wire replace
setblock ~315 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~25 ~302 ~330 ~25 ~302 minecraft:redstone_wire replace
setblock ~332 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~25 ~302 ~347 ~25 ~302 minecraft:redstone_wire replace
setblock ~349 ~25 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~25 ~302 ~356 ~25 ~302 minecraft:redstone_wire replace
setblock ~79 ~26 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~26 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~26 ~8 minecraft:redstone_wire replace
setblock ~100 ~26 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~26 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~26 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~26 ~16 minecraft:redstone_wire replace
setblock ~118 ~26 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~26 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~26 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~26 ~24 minecraft:redstone_wire replace
setblock ~145 ~26 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~26 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~26 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~26 ~32 minecraft:redstone_wire replace
setblock ~187 ~26 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~26 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~26 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~26 ~40 minecraft:redstone_wire replace
setblock ~205 ~26 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~26 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~26 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~26 ~48 minecraft:redstone_wire replace
setblock ~241 ~26 ~52 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~26 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~26 ~56 minecraft:redstone_wire replace
setblock ~292 ~26 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~26 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~26 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~26 ~60 minecraft:redstone_wire replace
setblock ~316 ~26 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~26 ~68 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~26 ~72 minecraft:redstone_wire replace
setblock ~313 ~26 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~26 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~26 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~26 ~76 minecraft:redstone_wire replace
setblock ~343 ~26 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~26 ~84 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~26 ~88 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~26 ~92 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~26 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~26 ~100 minecraft:redstone_wire replace
setblock ~103 ~26 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~26 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~26 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~26 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~26 ~120 minecraft:redstone_wire replace
setblock ~121 ~26 ~124 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~26 ~128 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~26 ~132 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~26 ~140 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~26 ~140 minecraft:redstone_wire replace
setblock ~151 ~26 ~144 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~26 ~148 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~26 ~152 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~26 ~156 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~26 ~156 minecraft:redstone_wire replace
setblock ~190 ~26 ~160 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~26 ~164 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~26 ~168 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~26 ~172 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~26 ~172 minecraft:redstone_wire replace
setblock ~217 ~26 ~176 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~26 ~180 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~26 ~184 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~26 ~188 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~26 ~188 minecraft:redstone_wire replace
setblock ~244 ~26 ~192 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~26 ~196 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~26 ~200 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~26 ~204 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~26 ~204 minecraft:redstone_wire replace
setblock ~295 ~26 ~208 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~26 ~208 minecraft:redstone_wire replace
setblock ~319 ~26 ~212 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~26 ~216 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~26 ~220 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~26 ~224 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~26 ~228 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~26 ~232 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~26 ~236 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~26 ~236 minecraft:redstone_wire replace
setblock ~322 ~26 ~240 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~26 ~240 minecraft:redstone_wire replace
setblock ~346 ~26 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~26 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~26 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~26 ~256 minecraft:redstone_wire replace
setblock ~148 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~26 ~256 minecraft:redstone_wire replace
setblock ~181 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~26 ~256 minecraft:redstone_wire replace
setblock ~211 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~26 ~256 minecraft:redstone_wire replace
setblock ~229 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~26 ~256 minecraft:redstone_wire replace
setblock ~253 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~26 ~256 minecraft:redstone_wire replace
setblock ~286 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~26 ~256 minecraft:redstone_wire replace
setblock ~295 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~26 ~256 minecraft:redstone_wire replace
setblock ~304 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~26 ~256 minecraft:redstone_wire replace
setblock ~322 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~26 ~256 minecraft:redstone_wire replace
setblock ~91 ~26 ~260 minecraft:redstone_wire replace
setblock ~112 ~26 ~260 minecraft:redstone_wire replace
setblock ~139 ~26 ~260 minecraft:redstone_wire replace
setblock ~172 ~26 ~260 minecraft:redstone_wire replace
setblock ~199 ~26 ~260 minecraft:redstone_wire replace
setblock ~235 ~26 ~260 minecraft:redstone_wire replace
setblock ~262 ~26 ~260 minecraft:redstone_wire replace
setblock ~280 ~26 ~260 minecraft:redstone_wire replace
setblock ~313 ~26 ~260 minecraft:redstone_wire replace
setblock ~340 ~26 ~260 minecraft:redstone_wire replace
setblock ~88 ~26 ~264 minecraft:redstone_wire replace
setblock ~109 ~26 ~264 minecraft:redstone_wire replace
setblock ~130 ~26 ~264 minecraft:redstone_wire replace
setblock ~169 ~26 ~264 minecraft:redstone_wire replace
setblock ~196 ~26 ~264 minecraft:redstone_wire replace
setblock ~223 ~26 ~264 minecraft:redstone_wire replace
setblock ~259 ~26 ~264 minecraft:redstone_wire replace
setblock ~277 ~26 ~264 minecraft:redstone_wire replace
setblock ~334 ~26 ~264 minecraft:redstone_wire replace
setblock ~352 ~26 ~264 minecraft:redstone_wire replace
setblock ~85 ~26 ~268 minecraft:redstone_wire replace
setblock ~106 ~26 ~268 minecraft:redstone_wire replace
setblock ~124 ~26 ~268 minecraft:redstone_wire replace
setblock ~166 ~26 ~268 minecraft:redstone_wire replace
setblock ~193 ~26 ~268 minecraft:redstone_wire replace
setblock ~220 ~26 ~268 minecraft:redstone_wire replace
setblock ~247 ~26 ~268 minecraft:redstone_wire replace
setblock ~274 ~26 ~268 minecraft:redstone_wire replace
setblock ~331 ~26 ~268 minecraft:redstone_wire replace
setblock ~349 ~26 ~268 minecraft:redstone_wire replace
setblock ~82 ~26 ~272 minecraft:redstone_wire replace
setblock ~103 ~26 ~272 minecraft:redstone_wire replace
setblock ~121 ~26 ~272 minecraft:redstone_wire replace
setblock ~151 ~26 ~272 minecraft:redstone_wire replace
setblock ~190 ~26 ~272 minecraft:redstone_wire replace
setblock ~217 ~26 ~272 minecraft:redstone_wire replace
setblock ~244 ~26 ~272 minecraft:redstone_wire replace
setblock ~268 ~26 ~272 minecraft:redstone_wire replace
setblock ~319 ~26 ~272 minecraft:redstone_wire replace
setblock ~346 ~26 ~272 minecraft:redstone_wire replace
setblock ~79 ~26 ~276 minecraft:redstone_wire replace
setblock ~100 ~26 ~276 minecraft:redstone_wire replace
setblock ~118 ~26 ~276 minecraft:redstone_wire replace
setblock ~145 ~26 ~276 minecraft:redstone_wire replace
setblock ~187 ~26 ~276 minecraft:redstone_wire replace
setblock ~205 ~26 ~276 minecraft:redstone_wire replace
setblock ~241 ~26 ~276 minecraft:redstone_wire replace
setblock ~265 ~26 ~276 minecraft:redstone_wire replace
setblock ~316 ~26 ~276 minecraft:redstone_wire replace
setblock ~343 ~26 ~276 minecraft:redstone_wire replace
setblock ~94 ~26 ~280 minecraft:redstone_wire replace
setblock ~97 ~26 ~280 minecraft:redstone_wire replace
setblock ~115 ~26 ~280 minecraft:redstone_wire replace
setblock ~142 ~26 ~280 minecraft:redstone_wire replace
setblock ~175 ~26 ~280 minecraft:redstone_wire replace
setblock ~202 ~26 ~280 minecraft:redstone_wire replace
setblock ~238 ~26 ~280 minecraft:redstone_wire replace
setblock ~271 ~26 ~280 minecraft:redstone_wire replace
setblock ~292 ~26 ~280 minecraft:redstone_wire replace
setblock ~337 ~26 ~280 minecraft:redstone_wire replace
setblock ~163 ~26 ~284 minecraft:redstone_wire replace
setblock ~358 ~26 ~296 minecraft:redstone_wire replace
setblock ~94 ~26 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~26 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~26 ~300 minecraft:redstone_wire replace
fill ~78 ~27 ~4 ~78 ~27 ~16 minecraft:redstone_wire replace
fill ~96 ~27 ~8 ~96 ~27 ~20 minecraft:redstone_wire replace
fill ~126 ~27 ~8 ~126 ~27 ~12 minecraft:redstone_wire replace
fill ~99 ~27 ~12 ~99 ~27 ~24 minecraft:redstone_wire replace
fill ~90 ~27 ~16 ~90 ~27 ~28 minecraft:redstone_wire replace
fill ~114 ~27 ~16 ~114 ~27 ~28 minecraft:redstone_wire replace
fill ~153 ~27 ~16 ~153 ~27 ~20 minecraft:redstone_wire replace
setblock ~78 ~27 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~20 ~78 ~27 ~32 minecraft:redstone_wire replace
fill ~117 ~27 ~20 ~117 ~27 ~32 minecraft:redstone_wire replace
setblock ~96 ~27 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~24 ~96 ~27 ~36 minecraft:redstone_wire replace
fill ~111 ~27 ~24 ~111 ~27 ~36 minecraft:redstone_wire replace
fill ~141 ~27 ~24 ~141 ~27 ~36 minecraft:redstone_wire replace
fill ~177 ~27 ~24 ~177 ~27 ~28 minecraft:redstone_wire replace
setblock ~99 ~27 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~28 ~99 ~27 ~40 minecraft:redstone_wire replace
fill ~144 ~27 ~28 ~144 ~27 ~40 minecraft:redstone_wire replace
setblock ~90 ~27 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~32 ~90 ~27 ~44 minecraft:redstone_wire replace
fill ~114 ~27 ~32 ~114 ~27 ~44 minecraft:redstone_wire replace
fill ~138 ~27 ~32 ~138 ~27 ~44 minecraft:redstone_wire replace
fill ~174 ~27 ~32 ~174 ~27 ~44 minecraft:redstone_wire replace
fill ~207 ~27 ~32 ~207 ~27 ~36 minecraft:redstone_wire replace
setblock ~78 ~27 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~36 ~78 ~27 ~48 minecraft:redstone_wire replace
fill ~117 ~27 ~36 ~117 ~27 ~48 minecraft:redstone_wire replace
fill ~186 ~27 ~36 ~186 ~27 ~48 minecraft:redstone_wire replace
setblock ~96 ~27 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~40 ~96 ~27 ~52 minecraft:redstone_wire replace
fill ~111 ~27 ~40 ~111 ~27 ~52 minecraft:redstone_wire replace
fill ~141 ~27 ~40 ~141 ~27 ~52 minecraft:redstone_wire replace
fill ~171 ~27 ~40 ~171 ~27 ~52 minecraft:redstone_wire replace
fill ~201 ~27 ~40 ~201 ~27 ~52 minecraft:redstone_wire replace
fill ~225 ~27 ~40 ~225 ~27 ~44 minecraft:redstone_wire replace
setblock ~99 ~27 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~44 ~99 ~27 ~56 minecraft:redstone_wire replace
fill ~144 ~27 ~44 ~144 ~27 ~56 minecraft:redstone_wire replace
fill ~204 ~27 ~44 ~204 ~27 ~56 minecraft:redstone_wire replace
setblock ~90 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~48 ~90 ~27 ~60 minecraft:redstone_wire replace
fill ~114 ~27 ~48 ~114 ~27 ~60 minecraft:redstone_wire replace
fill ~138 ~27 ~48 ~138 ~27 ~60 minecraft:redstone_wire replace
fill ~174 ~27 ~48 ~174 ~27 ~60 minecraft:redstone_wire replace
fill ~198 ~27 ~48 ~198 ~27 ~60 minecraft:redstone_wire replace
fill ~237 ~27 ~48 ~237 ~27 ~60 minecraft:redstone_wire replace
fill ~249 ~27 ~48 ~249 ~27 ~52 minecraft:redstone_wire replace
setblock ~78 ~27 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~52 ~78 ~27 ~64 minecraft:redstone_wire replace
fill ~117 ~27 ~52 ~117 ~27 ~64 minecraft:redstone_wire replace
fill ~186 ~27 ~52 ~186 ~27 ~64 minecraft:redstone_wire replace
fill ~240 ~27 ~52 ~240 ~27 ~64 minecraft:redstone_wire replace
setblock ~96 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~56 ~96 ~27 ~68 minecraft:redstone_wire replace
fill ~111 ~27 ~56 ~111 ~27 ~68 minecraft:redstone_wire replace
fill ~141 ~27 ~56 ~141 ~27 ~68 minecraft:redstone_wire replace
fill ~171 ~27 ~56 ~171 ~27 ~68 minecraft:redstone_wire replace
fill ~201 ~27 ~56 ~201 ~27 ~68 minecraft:redstone_wire replace
fill ~234 ~27 ~56 ~234 ~27 ~68 minecraft:redstone_wire replace
fill ~282 ~27 ~56 ~282 ~27 ~60 minecraft:redstone_wire replace
fill ~291 ~27 ~56 ~291 ~27 ~68 minecraft:redstone_wire replace
setblock ~99 ~27 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~60 ~99 ~27 ~72 minecraft:redstone_wire replace
fill ~144 ~27 ~60 ~144 ~27 ~72 minecraft:redstone_wire replace
fill ~204 ~27 ~60 ~204 ~27 ~72 minecraft:redstone_wire replace
fill ~261 ~27 ~60 ~261 ~27 ~72 minecraft:redstone_wire replace
fill ~270 ~27 ~60 ~270 ~27 ~72 minecraft:redstone_wire replace
fill ~300 ~27 ~60 ~300 ~27 ~64 minecraft:redstone_wire replace
setblock ~90 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~64 ~90 ~27 ~76 minecraft:redstone_wire replace
fill ~114 ~27 ~64 ~114 ~27 ~76 minecraft:redstone_wire replace
fill ~138 ~27 ~64 ~138 ~27 ~76 minecraft:redstone_wire replace
fill ~174 ~27 ~64 ~174 ~27 ~76 minecraft:redstone_wire replace
fill ~198 ~27 ~64 ~198 ~27 ~76 minecraft:redstone_wire replace
fill ~237 ~27 ~64 ~237 ~27 ~76 minecraft:redstone_wire replace
fill ~315 ~27 ~64 ~315 ~27 ~76 minecraft:redstone_wire replace
setblock ~78 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~68 ~78 ~27 ~80 minecraft:redstone_wire replace
fill ~117 ~27 ~68 ~117 ~27 ~80 minecraft:redstone_wire replace
fill ~186 ~27 ~68 ~186 ~27 ~80 minecraft:redstone_wire replace
fill ~240 ~27 ~68 ~240 ~27 ~80 minecraft:redstone_wire replace
fill ~264 ~27 ~68 ~264 ~27 ~80 minecraft:redstone_wire replace
setblock ~96 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~72 ~96 ~27 ~84 minecraft:redstone_wire replace
fill ~111 ~27 ~72 ~111 ~27 ~84 minecraft:redstone_wire replace
fill ~141 ~27 ~72 ~141 ~27 ~84 minecraft:redstone_wire replace
fill ~171 ~27 ~72 ~171 ~27 ~84 minecraft:redstone_wire replace
fill ~201 ~27 ~72 ~201 ~27 ~84 minecraft:redstone_wire replace
fill ~234 ~27 ~72 ~234 ~27 ~84 minecraft:redstone_wire replace
fill ~291 ~27 ~72 ~291 ~27 ~84 minecraft:redstone_wire replace
fill ~309 ~27 ~72 ~309 ~27 ~76 minecraft:redstone_wire replace
fill ~312 ~27 ~72 ~312 ~27 ~84 minecraft:redstone_wire replace
fill ~336 ~27 ~72 ~336 ~27 ~84 minecraft:redstone_wire replace
setblock ~99 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~76 ~99 ~27 ~88 minecraft:redstone_wire replace
fill ~144 ~27 ~76 ~144 ~27 ~88 minecraft:redstone_wire replace
fill ~204 ~27 ~76 ~204 ~27 ~88 minecraft:redstone_wire replace
fill ~261 ~27 ~76 ~261 ~27 ~88 minecraft:redstone_wire replace
fill ~270 ~27 ~76 ~270 ~27 ~88 minecraft:redstone_wire replace
fill ~279 ~27 ~76 ~279 ~27 ~88 minecraft:redstone_wire replace
fill ~327 ~27 ~76 ~327 ~27 ~80 minecraft:redstone_wire replace
setblock ~90 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~80 ~90 ~27 ~92 minecraft:redstone_wire replace
fill ~114 ~27 ~80 ~114 ~27 ~92 minecraft:redstone_wire replace
fill ~138 ~27 ~80 ~138 ~27 ~92 minecraft:redstone_wire replace
fill ~174 ~27 ~80 ~174 ~27 ~92 minecraft:redstone_wire replace
fill ~198 ~27 ~80 ~198 ~27 ~92 minecraft:redstone_wire replace
fill ~237 ~27 ~80 ~237 ~27 ~92 minecraft:redstone_wire replace
fill ~315 ~27 ~80 ~315 ~27 ~92 minecraft:redstone_wire replace
fill ~342 ~27 ~80 ~342 ~27 ~92 minecraft:redstone_wire replace
setblock ~78 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~84 ~78 ~27 ~96 minecraft:redstone_wire replace
fill ~81 ~27 ~84 ~81 ~27 ~96 minecraft:redstone_wire replace
fill ~117 ~27 ~84 ~117 ~27 ~96 minecraft:redstone_wire replace
fill ~186 ~27 ~84 ~186 ~27 ~96 minecraft:redstone_wire replace
fill ~240 ~27 ~84 ~240 ~27 ~96 minecraft:redstone_wire replace
fill ~264 ~27 ~84 ~264 ~27 ~96 minecraft:redstone_wire replace
setblock ~96 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~88 ~84 ~27 ~100 minecraft:redstone_wire replace
fill ~96 ~27 ~88 ~96 ~27 ~100 minecraft:redstone_wire replace
fill ~111 ~27 ~88 ~111 ~27 ~100 minecraft:redstone_wire replace
fill ~141 ~27 ~88 ~141 ~27 ~100 minecraft:redstone_wire replace
fill ~171 ~27 ~88 ~171 ~27 ~100 minecraft:redstone_wire replace
fill ~201 ~27 ~88 ~201 ~27 ~100 minecraft:redstone_wire replace
fill ~234 ~27 ~88 ~234 ~27 ~100 minecraft:redstone_wire replace
fill ~291 ~27 ~88 ~291 ~27 ~100 minecraft:redstone_wire replace
fill ~312 ~27 ~88 ~312 ~27 ~100 minecraft:redstone_wire replace
fill ~336 ~27 ~88 ~336 ~27 ~100 minecraft:redstone_wire replace
setblock ~99 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~92 ~87 ~27 ~104 minecraft:redstone_wire replace
fill ~99 ~27 ~92 ~99 ~27 ~104 minecraft:redstone_wire replace
fill ~144 ~27 ~92 ~144 ~27 ~104 minecraft:redstone_wire replace
fill ~204 ~27 ~92 ~204 ~27 ~104 minecraft:redstone_wire replace
fill ~261 ~27 ~92 ~261 ~27 ~104 minecraft:redstone_wire replace
fill ~270 ~27 ~92 ~270 ~27 ~104 minecraft:redstone_wire replace
fill ~279 ~27 ~92 ~279 ~27 ~104 minecraft:redstone_wire replace
setblock ~90 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~96 ~90 ~27 ~108 minecraft:redstone_wire replace
fill ~114 ~27 ~96 ~114 ~27 ~108 minecraft:redstone_wire replace
fill ~138 ~27 ~96 ~138 ~27 ~108 minecraft:redstone_wire replace
fill ~174 ~27 ~96 ~174 ~27 ~108 minecraft:redstone_wire replace
fill ~198 ~27 ~96 ~198 ~27 ~108 minecraft:redstone_wire replace
fill ~237 ~27 ~96 ~237 ~27 ~108 minecraft:redstone_wire replace
fill ~315 ~27 ~96 ~315 ~27 ~108 minecraft:redstone_wire replace
fill ~342 ~27 ~96 ~342 ~27 ~108 minecraft:redstone_wire replace
setblock ~78 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~100 ~78 ~27 ~112 minecraft:redstone_wire replace
fill ~81 ~27 ~100 ~81 ~27 ~112 minecraft:redstone_wire replace
fill ~117 ~27 ~100 ~117 ~27 ~112 minecraft:redstone_wire replace
fill ~132 ~27 ~100 ~132 ~27 ~112 minecraft:redstone_wire replace
fill ~135 ~27 ~100 ~135 ~27 ~112 minecraft:redstone_wire replace
fill ~186 ~27 ~100 ~186 ~27 ~112 minecraft:redstone_wire replace
fill ~240 ~27 ~100 ~240 ~27 ~112 minecraft:redstone_wire replace
fill ~264 ~27 ~100 ~264 ~27 ~112 minecraft:redstone_wire replace
setblock ~84 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~104 ~84 ~27 ~116 minecraft:redstone_wire replace
fill ~96 ~27 ~104 ~96 ~27 ~116 minecraft:redstone_wire replace
fill ~102 ~27 ~104 ~102 ~27 ~116 minecraft:redstone_wire replace
fill ~111 ~27 ~104 ~111 ~27 ~116 minecraft:redstone_wire replace
fill ~141 ~27 ~104 ~141 ~27 ~116 minecraft:redstone_wire replace
fill ~171 ~27 ~104 ~171 ~27 ~116 minecraft:redstone_wire replace
fill ~201 ~27 ~104 ~201 ~27 ~116 minecraft:redstone_wire replace
fill ~234 ~27 ~104 ~234 ~27 ~116 minecraft:redstone_wire replace
fill ~291 ~27 ~104 ~291 ~27 ~116 minecraft:redstone_wire replace
fill ~312 ~27 ~104 ~312 ~27 ~116 minecraft:redstone_wire replace
fill ~336 ~27 ~104 ~336 ~27 ~116 minecraft:redstone_wire replace
setblock ~87 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~108 ~87 ~27 ~120 minecraft:redstone_wire replace
fill ~99 ~27 ~108 ~99 ~27 ~120 minecraft:redstone_wire replace
fill ~105 ~27 ~108 ~105 ~27 ~120 minecraft:redstone_wire replace
fill ~144 ~27 ~108 ~144 ~27 ~120 minecraft:redstone_wire replace
fill ~204 ~27 ~108 ~204 ~27 ~120 minecraft:redstone_wire replace
fill ~261 ~27 ~108 ~261 ~27 ~120 minecraft:redstone_wire replace
fill ~270 ~27 ~108 ~270 ~27 ~120 minecraft:redstone_wire replace
fill ~279 ~27 ~108 ~279 ~27 ~120 minecraft:redstone_wire replace
setblock ~90 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~112 ~90 ~27 ~124 minecraft:redstone_wire replace
fill ~108 ~27 ~112 ~108 ~27 ~124 minecraft:redstone_wire replace
fill ~114 ~27 ~112 ~114 ~27 ~124 minecraft:redstone_wire replace
fill ~138 ~27 ~112 ~138 ~27 ~124 minecraft:redstone_wire replace
fill ~174 ~27 ~112 ~174 ~27 ~124 minecraft:redstone_wire replace
fill ~198 ~27 ~112 ~198 ~27 ~124 minecraft:redstone_wire replace
fill ~237 ~27 ~112 ~237 ~27 ~124 minecraft:redstone_wire replace
fill ~315 ~27 ~112 ~315 ~27 ~124 minecraft:redstone_wire replace
fill ~342 ~27 ~112 ~342 ~27 ~124 minecraft:redstone_wire replace
setblock ~78 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~116 ~78 ~27 ~128 minecraft:redstone_wire replace
fill ~81 ~27 ~116 ~81 ~27 ~128 minecraft:redstone_wire replace
fill ~117 ~27 ~116 ~117 ~27 ~128 minecraft:redstone_wire replace
fill ~132 ~27 ~116 ~132 ~27 ~128 minecraft:redstone_wire replace
fill ~135 ~27 ~116 ~135 ~27 ~128 minecraft:redstone_wire replace
fill ~186 ~27 ~116 ~186 ~27 ~128 minecraft:redstone_wire replace
fill ~240 ~27 ~116 ~240 ~27 ~128 minecraft:redstone_wire replace
fill ~264 ~27 ~116 ~264 ~27 ~128 minecraft:redstone_wire replace
setblock ~84 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~120 ~84 ~27 ~132 minecraft:redstone_wire replace
fill ~96 ~27 ~120 ~96 ~27 ~132 minecraft:redstone_wire replace
fill ~102 ~27 ~120 ~102 ~27 ~132 minecraft:redstone_wire replace
fill ~111 ~27 ~120 ~111 ~27 ~132 minecraft:redstone_wire replace
fill ~141 ~27 ~120 ~141 ~27 ~132 minecraft:redstone_wire replace
fill ~156 ~27 ~120 ~156 ~27 ~132 minecraft:redstone_wire replace
fill ~159 ~27 ~120 ~159 ~27 ~132 minecraft:redstone_wire replace
fill ~171 ~27 ~120 ~171 ~27 ~132 minecraft:redstone_wire replace
fill ~201 ~27 ~120 ~201 ~27 ~132 minecraft:redstone_wire replace
fill ~234 ~27 ~120 ~234 ~27 ~132 minecraft:redstone_wire replace
fill ~291 ~27 ~120 ~291 ~27 ~132 minecraft:redstone_wire replace
fill ~312 ~27 ~120 ~312 ~27 ~132 minecraft:redstone_wire replace
fill ~336 ~27 ~120 ~336 ~27 ~132 minecraft:redstone_wire replace
setblock ~87 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~124 ~87 ~27 ~136 minecraft:redstone_wire replace
fill ~99 ~27 ~124 ~99 ~27 ~136 minecraft:redstone_wire replace
fill ~105 ~27 ~124 ~105 ~27 ~136 minecraft:redstone_wire replace
fill ~120 ~27 ~124 ~120 ~27 ~136 minecraft:redstone_wire replace
fill ~144 ~27 ~124 ~144 ~27 ~136 minecraft:redstone_wire replace
fill ~204 ~27 ~124 ~204 ~27 ~136 minecraft:redstone_wire replace
fill ~261 ~27 ~124 ~261 ~27 ~136 minecraft:redstone_wire replace
fill ~270 ~27 ~124 ~270 ~27 ~136 minecraft:redstone_wire replace
fill ~279 ~27 ~124 ~279 ~27 ~136 minecraft:redstone_wire replace
setblock ~90 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~128 ~90 ~27 ~140 minecraft:redstone_wire replace
fill ~108 ~27 ~128 ~108 ~27 ~140 minecraft:redstone_wire replace
fill ~114 ~27 ~128 ~114 ~27 ~140 minecraft:redstone_wire replace
fill ~123 ~27 ~128 ~123 ~27 ~140 minecraft:redstone_wire replace
fill ~138 ~27 ~128 ~138 ~27 ~140 minecraft:redstone_wire replace
fill ~174 ~27 ~128 ~174 ~27 ~140 minecraft:redstone_wire replace
fill ~198 ~27 ~128 ~198 ~27 ~140 minecraft:redstone_wire replace
fill ~237 ~27 ~128 ~237 ~27 ~140 minecraft:redstone_wire replace
fill ~315 ~27 ~128 ~315 ~27 ~140 minecraft:redstone_wire replace
fill ~342 ~27 ~128 ~342 ~27 ~140 minecraft:redstone_wire replace
setblock ~78 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~132 ~78 ~27 ~144 minecraft:redstone_wire replace
fill ~81 ~27 ~132 ~81 ~27 ~144 minecraft:redstone_wire replace
fill ~117 ~27 ~132 ~117 ~27 ~144 minecraft:redstone_wire replace
fill ~129 ~27 ~132 ~129 ~27 ~144 minecraft:redstone_wire replace
fill ~132 ~27 ~132 ~132 ~27 ~144 minecraft:redstone_wire replace
fill ~135 ~27 ~132 ~135 ~27 ~144 minecraft:redstone_wire replace
fill ~186 ~27 ~132 ~186 ~27 ~144 minecraft:redstone_wire replace
fill ~240 ~27 ~132 ~240 ~27 ~144 minecraft:redstone_wire replace
fill ~264 ~27 ~132 ~264 ~27 ~144 minecraft:redstone_wire replace
setblock ~84 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~136 ~84 ~27 ~148 minecraft:redstone_wire replace
fill ~96 ~27 ~136 ~96 ~27 ~148 minecraft:redstone_wire replace
fill ~102 ~27 ~136 ~102 ~27 ~148 minecraft:redstone_wire replace
fill ~111 ~27 ~136 ~111 ~27 ~148 minecraft:redstone_wire replace
fill ~141 ~27 ~136 ~141 ~27 ~148 minecraft:redstone_wire replace
fill ~156 ~27 ~136 ~156 ~27 ~148 minecraft:redstone_wire replace
fill ~159 ~27 ~136 ~159 ~27 ~148 minecraft:redstone_wire replace
fill ~171 ~27 ~136 ~171 ~27 ~148 minecraft:redstone_wire replace
fill ~201 ~27 ~136 ~201 ~27 ~148 minecraft:redstone_wire replace
fill ~234 ~27 ~136 ~234 ~27 ~148 minecraft:redstone_wire replace
fill ~291 ~27 ~136 ~291 ~27 ~148 minecraft:redstone_wire replace
fill ~312 ~27 ~136 ~312 ~27 ~148 minecraft:redstone_wire replace
fill ~336 ~27 ~136 ~336 ~27 ~148 minecraft:redstone_wire replace
setblock ~87 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~140 ~87 ~27 ~152 minecraft:redstone_wire replace
fill ~99 ~27 ~140 ~99 ~27 ~152 minecraft:redstone_wire replace
fill ~105 ~27 ~140 ~105 ~27 ~152 minecraft:redstone_wire replace
fill ~120 ~27 ~140 ~120 ~27 ~152 minecraft:redstone_wire replace
fill ~144 ~27 ~140 ~144 ~27 ~152 minecraft:redstone_wire replace
fill ~180 ~27 ~140 ~180 ~27 ~152 minecraft:redstone_wire replace
fill ~183 ~27 ~140 ~183 ~27 ~152 minecraft:redstone_wire replace
fill ~204 ~27 ~140 ~204 ~27 ~152 minecraft:redstone_wire replace
fill ~261 ~27 ~140 ~261 ~27 ~152 minecraft:redstone_wire replace
fill ~270 ~27 ~140 ~270 ~27 ~152 minecraft:redstone_wire replace
fill ~279 ~27 ~140 ~279 ~27 ~152 minecraft:redstone_wire replace
setblock ~90 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~144 ~90 ~27 ~156 minecraft:redstone_wire replace
fill ~108 ~27 ~144 ~108 ~27 ~156 minecraft:redstone_wire replace
fill ~114 ~27 ~144 ~114 ~27 ~156 minecraft:redstone_wire replace
fill ~123 ~27 ~144 ~123 ~27 ~156 minecraft:redstone_wire replace
fill ~138 ~27 ~144 ~138 ~27 ~156 minecraft:redstone_wire replace
fill ~150 ~27 ~144 ~150 ~27 ~156 minecraft:redstone_wire replace
fill ~174 ~27 ~144 ~174 ~27 ~156 minecraft:redstone_wire replace
fill ~198 ~27 ~144 ~198 ~27 ~156 minecraft:redstone_wire replace
fill ~237 ~27 ~144 ~237 ~27 ~156 minecraft:redstone_wire replace
fill ~315 ~27 ~144 ~315 ~27 ~156 minecraft:redstone_wire replace
fill ~342 ~27 ~144 ~342 ~27 ~156 minecraft:redstone_wire replace
setblock ~78 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~148 ~78 ~27 ~160 minecraft:redstone_wire replace
fill ~81 ~27 ~148 ~81 ~27 ~160 minecraft:redstone_wire replace
fill ~117 ~27 ~148 ~117 ~27 ~160 minecraft:redstone_wire replace
fill ~129 ~27 ~148 ~129 ~27 ~160 minecraft:redstone_wire replace
fill ~132 ~27 ~148 ~132 ~27 ~160 minecraft:redstone_wire replace
fill ~135 ~27 ~148 ~135 ~27 ~160 minecraft:redstone_wire replace
fill ~165 ~27 ~148 ~165 ~27 ~160 minecraft:redstone_wire replace
fill ~186 ~27 ~148 ~186 ~27 ~160 minecraft:redstone_wire replace
fill ~240 ~27 ~148 ~240 ~27 ~160 minecraft:redstone_wire replace
fill ~264 ~27 ~148 ~264 ~27 ~160 minecraft:redstone_wire replace
setblock ~84 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~152 ~84 ~27 ~164 minecraft:redstone_wire replace
fill ~96 ~27 ~152 ~96 ~27 ~164 minecraft:redstone_wire replace
fill ~102 ~27 ~152 ~102 ~27 ~164 minecraft:redstone_wire replace
fill ~111 ~27 ~152 ~111 ~27 ~164 minecraft:redstone_wire replace
fill ~141 ~27 ~152 ~141 ~27 ~164 minecraft:redstone_wire replace
fill ~156 ~27 ~152 ~156 ~27 ~164 minecraft:redstone_wire replace
fill ~159 ~27 ~152 ~159 ~27 ~164 minecraft:redstone_wire replace
fill ~168 ~27 ~152 ~168 ~27 ~164 minecraft:redstone_wire replace
fill ~171 ~27 ~152 ~171 ~27 ~164 minecraft:redstone_wire replace
fill ~201 ~27 ~152 ~201 ~27 ~164 minecraft:redstone_wire replace
fill ~234 ~27 ~152 ~234 ~27 ~164 minecraft:redstone_wire replace
fill ~291 ~27 ~152 ~291 ~27 ~164 minecraft:redstone_wire replace
fill ~312 ~27 ~152 ~312 ~27 ~164 minecraft:redstone_wire replace
fill ~336 ~27 ~152 ~336 ~27 ~164 minecraft:redstone_wire replace
setblock ~87 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~156 ~87 ~27 ~168 minecraft:redstone_wire replace
fill ~99 ~27 ~156 ~99 ~27 ~168 minecraft:redstone_wire replace
fill ~105 ~27 ~156 ~105 ~27 ~168 minecraft:redstone_wire replace
fill ~120 ~27 ~156 ~120 ~27 ~168 minecraft:redstone_wire replace
fill ~144 ~27 ~156 ~144 ~27 ~168 minecraft:redstone_wire replace
fill ~180 ~27 ~156 ~180 ~27 ~168 minecraft:redstone_wire replace
fill ~183 ~27 ~156 ~183 ~27 ~168 minecraft:redstone_wire replace
fill ~204 ~27 ~156 ~204 ~27 ~168 minecraft:redstone_wire replace
fill ~210 ~27 ~156 ~210 ~27 ~168 minecraft:redstone_wire replace
fill ~213 ~27 ~156 ~213 ~27 ~168 minecraft:redstone_wire replace
fill ~261 ~27 ~156 ~261 ~27 ~168 minecraft:redstone_wire replace
fill ~270 ~27 ~156 ~270 ~27 ~168 minecraft:redstone_wire replace
fill ~279 ~27 ~156 ~279 ~27 ~168 minecraft:redstone_wire replace
setblock ~90 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~160 ~90 ~27 ~172 minecraft:redstone_wire replace
fill ~108 ~27 ~160 ~108 ~27 ~172 minecraft:redstone_wire replace
fill ~114 ~27 ~160 ~114 ~27 ~172 minecraft:redstone_wire replace
fill ~123 ~27 ~160 ~123 ~27 ~172 minecraft:redstone_wire replace
fill ~138 ~27 ~160 ~138 ~27 ~172 minecraft:redstone_wire replace
fill ~150 ~27 ~160 ~150 ~27 ~172 minecraft:redstone_wire replace
fill ~174 ~27 ~160 ~174 ~27 ~172 minecraft:redstone_wire replace
fill ~189 ~27 ~160 ~189 ~27 ~172 minecraft:redstone_wire replace
fill ~198 ~27 ~160 ~198 ~27 ~172 minecraft:redstone_wire replace
fill ~237 ~27 ~160 ~237 ~27 ~172 minecraft:redstone_wire replace
fill ~315 ~27 ~160 ~315 ~27 ~172 minecraft:redstone_wire replace
fill ~342 ~27 ~160 ~342 ~27 ~172 minecraft:redstone_wire replace
setblock ~78 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~164 ~78 ~27 ~176 minecraft:redstone_wire replace
fill ~81 ~27 ~164 ~81 ~27 ~176 minecraft:redstone_wire replace
fill ~117 ~27 ~164 ~117 ~27 ~176 minecraft:redstone_wire replace
fill ~129 ~27 ~164 ~129 ~27 ~176 minecraft:redstone_wire replace
fill ~132 ~27 ~164 ~132 ~27 ~176 minecraft:redstone_wire replace
fill ~135 ~27 ~164 ~135 ~27 ~176 minecraft:redstone_wire replace
fill ~165 ~27 ~164 ~165 ~27 ~176 minecraft:redstone_wire replace
fill ~186 ~27 ~164 ~186 ~27 ~176 minecraft:redstone_wire replace
fill ~192 ~27 ~164 ~192 ~27 ~176 minecraft:redstone_wire replace
fill ~240 ~27 ~164 ~240 ~27 ~176 minecraft:redstone_wire replace
fill ~264 ~27 ~164 ~264 ~27 ~176 minecraft:redstone_wire replace
setblock ~84 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~168 ~84 ~27 ~180 minecraft:redstone_wire replace
fill ~96 ~27 ~168 ~96 ~27 ~180 minecraft:redstone_wire replace
fill ~102 ~27 ~168 ~102 ~27 ~180 minecraft:redstone_wire replace
fill ~111 ~27 ~168 ~111 ~27 ~180 minecraft:redstone_wire replace
fill ~141 ~27 ~168 ~141 ~27 ~180 minecraft:redstone_wire replace
fill ~156 ~27 ~168 ~156 ~27 ~180 minecraft:redstone_wire replace
fill ~159 ~27 ~168 ~159 ~27 ~180 minecraft:redstone_wire replace
fill ~168 ~27 ~168 ~168 ~27 ~180 minecraft:redstone_wire replace
fill ~171 ~27 ~168 ~171 ~27 ~180 minecraft:redstone_wire replace
fill ~195 ~27 ~168 ~195 ~27 ~180 minecraft:redstone_wire replace
fill ~201 ~27 ~168 ~201 ~27 ~180 minecraft:redstone_wire replace
fill ~234 ~27 ~168 ~234 ~27 ~180 minecraft:redstone_wire replace
fill ~291 ~27 ~168 ~291 ~27 ~180 minecraft:redstone_wire replace
fill ~312 ~27 ~168 ~312 ~27 ~180 minecraft:redstone_wire replace
fill ~336 ~27 ~168 ~336 ~27 ~180 minecraft:redstone_wire replace
setblock ~87 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~172 ~87 ~27 ~184 minecraft:redstone_wire replace
fill ~99 ~27 ~172 ~99 ~27 ~184 minecraft:redstone_wire replace
fill ~105 ~27 ~172 ~105 ~27 ~184 minecraft:redstone_wire replace
fill ~120 ~27 ~172 ~120 ~27 ~184 minecraft:redstone_wire replace
fill ~144 ~27 ~172 ~144 ~27 ~184 minecraft:redstone_wire replace
fill ~180 ~27 ~172 ~180 ~27 ~184 minecraft:redstone_wire replace
fill ~183 ~27 ~172 ~183 ~27 ~184 minecraft:redstone_wire replace
fill ~204 ~27 ~172 ~204 ~27 ~184 minecraft:redstone_wire replace
fill ~210 ~27 ~172 ~210 ~27 ~184 minecraft:redstone_wire replace
fill ~213 ~27 ~172 ~213 ~27 ~184 minecraft:redstone_wire replace
fill ~228 ~27 ~172 ~228 ~27 ~184 minecraft:redstone_wire replace
fill ~231 ~27 ~172 ~231 ~27 ~184 minecraft:redstone_wire replace
fill ~261 ~27 ~172 ~261 ~27 ~184 minecraft:redstone_wire replace
fill ~270 ~27 ~172 ~270 ~27 ~184 minecraft:redstone_wire replace
fill ~279 ~27 ~172 ~279 ~27 ~184 minecraft:redstone_wire replace
setblock ~90 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~176 ~90 ~27 ~188 minecraft:redstone_wire replace
fill ~108 ~27 ~176 ~108 ~27 ~188 minecraft:redstone_wire replace
fill ~114 ~27 ~176 ~114 ~27 ~188 minecraft:redstone_wire replace
fill ~123 ~27 ~176 ~123 ~27 ~188 minecraft:redstone_wire replace
fill ~138 ~27 ~176 ~138 ~27 ~188 minecraft:redstone_wire replace
fill ~150 ~27 ~176 ~150 ~27 ~188 minecraft:redstone_wire replace
fill ~174 ~27 ~176 ~174 ~27 ~188 minecraft:redstone_wire replace
fill ~189 ~27 ~176 ~189 ~27 ~188 minecraft:redstone_wire replace
fill ~198 ~27 ~176 ~198 ~27 ~188 minecraft:redstone_wire replace
fill ~216 ~27 ~176 ~216 ~27 ~188 minecraft:redstone_wire replace
fill ~237 ~27 ~176 ~237 ~27 ~188 minecraft:redstone_wire replace
