setblock ~90 ~59 ~521 minecraft:light_gray_concrete replace
setblock ~177 ~59 ~521 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~524 minecraft:light_gray_concrete replace
setblock ~201 ~59 ~525 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~527 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~528 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~529 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~529 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~531 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~532 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~533 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~535 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~535 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~536 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~537 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~540 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~543 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~545 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~545 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~545 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~547 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~547 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~549 minecraft:light_gray_concrete replace
setblock ~102 ~59 ~549 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~551 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~551 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~553 minecraft:light_gray_concrete replace
setblock ~123 ~59 ~553 minecraft:light_gray_concrete replace
setblock ~144 ~59 ~557 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~559 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~174 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~563 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~563 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~564 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~565 minecraft:light_gray_concrete replace
setblock ~195 ~59 ~565 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~567 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~567 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~568 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~569 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~572 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~576 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~577 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~577 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~579 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~579 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~580 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~581 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~583 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~583 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~585 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~589 minecraft:light_gray_concrete replace
setblock ~96 ~59 ~589 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~591 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~593 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~593 minecraft:light_gray_concrete replace
setblock ~120 ~59 ~593 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~595 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~595 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~597 minecraft:light_gray_concrete replace
setblock ~141 ~59 ~597 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~599 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~599 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~601 minecraft:light_gray_concrete replace
setblock ~171 ~59 ~601 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~604 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~605 minecraft:light_gray_concrete replace
setblock ~192 ~59 ~605 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~607 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~607 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~608 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~609 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~609 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~611 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~612 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~613 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~615 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~616 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~617 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~621 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~625 minecraft:light_gray_concrete replace
setblock ~93 ~59 ~625 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~627 minecraft:light_gray_concrete replace
setblock ~114 ~59 ~629 minecraft:light_gray_concrete replace
setblock ~147 ~59 ~633 minecraft:light_gray_concrete replace
setblock ~159 ~59 ~637 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~641 minecraft:light_gray_concrete replace
setblock ~183 ~59 ~641 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~643 minecraft:light_gray_concrete replace
setblock ~132 ~59 ~645 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~648 minecraft:light_gray_concrete replace
setblock ~210 ~59 ~649 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~651 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~653 minecraft:light_gray_concrete replace
setblock ~186 ~59 ~657 minecraft:light_gray_concrete replace
setblock ~207 ~59 ~661 minecraft:light_gray_concrete replace
fill ~99 ~60 ~330 ~104 ~60 ~330 minecraft:light_gray_concrete replace
fill ~103 ~60 ~331 ~103 ~60 ~332 minecraft:light_gray_concrete replace
fill ~117 ~60 ~346 ~122 ~60 ~346 minecraft:light_gray_concrete replace
fill ~121 ~60 ~347 ~121 ~60 ~348 minecraft:light_gray_concrete replace
fill ~162 ~60 ~362 ~164 ~60 ~362 minecraft:light_gray_concrete replace
fill ~163 ~60 ~363 ~163 ~60 ~364 minecraft:light_gray_concrete replace
fill ~138 ~60 ~378 ~140 ~60 ~378 minecraft:light_gray_concrete replace
fill ~139 ~60 ~379 ~139 ~60 ~380 minecraft:light_gray_concrete replace
fill ~186 ~60 ~394 ~212 ~60 ~394 minecraft:light_gray_concrete replace
fill ~187 ~60 ~395 ~187 ~60 ~396 minecraft:light_gray_concrete replace
fill ~190 ~60 ~395 ~190 ~60 ~396 minecraft:light_gray_concrete replace
fill ~208 ~60 ~395 ~208 ~60 ~396 minecraft:light_gray_concrete replace
fill ~211 ~60 ~395 ~211 ~60 ~396 minecraft:light_gray_concrete replace
fill ~81 ~60 ~398 ~212 ~60 ~398 minecraft:light_gray_concrete replace
fill ~82 ~60 ~399 ~82 ~60 ~400 minecraft:light_gray_concrete replace
fill ~208 ~60 ~399 ~208 ~60 ~400 minecraft:light_gray_concrete replace
fill ~211 ~60 ~399 ~211 ~60 ~400 minecraft:light_gray_concrete replace
fill ~186 ~60 ~402 ~191 ~60 ~402 minecraft:light_gray_concrete replace
fill ~187 ~60 ~403 ~187 ~60 ~404 minecraft:light_gray_concrete replace
fill ~190 ~60 ~403 ~190 ~60 ~404 minecraft:light_gray_concrete replace
fill ~111 ~60 ~434 ~116 ~60 ~434 minecraft:light_gray_concrete replace
fill ~115 ~60 ~435 ~115 ~60 ~436 minecraft:light_gray_concrete replace
fill ~135 ~60 ~438 ~137 ~60 ~438 minecraft:light_gray_concrete replace
fill ~136 ~60 ~439 ~136 ~60 ~440 minecraft:light_gray_concrete replace
fill ~156 ~60 ~442 ~158 ~60 ~442 minecraft:light_gray_concrete replace
fill ~157 ~60 ~443 ~157 ~60 ~444 minecraft:light_gray_concrete replace
fill ~165 ~60 ~446 ~167 ~60 ~446 minecraft:light_gray_concrete replace
fill ~166 ~60 ~447 ~166 ~60 ~448 minecraft:light_gray_concrete replace
fill ~108 ~60 ~470 ~113 ~60 ~470 minecraft:light_gray_concrete replace
fill ~112 ~60 ~471 ~112 ~60 ~472 minecraft:light_gray_concrete replace
fill ~129 ~60 ~474 ~134 ~60 ~474 minecraft:light_gray_concrete replace
fill ~133 ~60 ~475 ~133 ~60 ~476 minecraft:light_gray_concrete replace
fill ~153 ~60 ~478 ~155 ~60 ~478 minecraft:light_gray_concrete replace
fill ~154 ~60 ~479 ~154 ~60 ~480 minecraft:light_gray_concrete replace
fill ~177 ~60 ~482 ~180 ~60 ~482 minecraft:light_gray_concrete replace
fill ~178 ~60 ~483 ~178 ~60 ~484 minecraft:light_gray_concrete replace
fill ~204 ~60 ~486 ~206 ~60 ~486 minecraft:light_gray_concrete replace
fill ~205 ~60 ~487 ~205 ~60 ~488 minecraft:light_gray_concrete replace
fill ~105 ~60 ~510 ~110 ~60 ~510 minecraft:light_gray_concrete replace
fill ~109 ~60 ~511 ~109 ~60 ~512 minecraft:light_gray_concrete replace
fill ~126 ~60 ~514 ~131 ~60 ~514 minecraft:light_gray_concrete replace
fill ~130 ~60 ~515 ~130 ~60 ~516 minecraft:light_gray_concrete replace
fill ~150 ~60 ~518 ~152 ~60 ~518 minecraft:light_gray_concrete replace
fill ~151 ~60 ~519 ~151 ~60 ~520 minecraft:light_gray_concrete replace
fill ~174 ~60 ~522 ~177 ~60 ~522 minecraft:light_gray_concrete replace
fill ~175 ~60 ~523 ~175 ~60 ~524 minecraft:light_gray_concrete replace
fill ~201 ~60 ~526 ~203 ~60 ~526 minecraft:light_gray_concrete replace
fill ~202 ~60 ~527 ~202 ~60 ~528 minecraft:light_gray_concrete replace
fill ~102 ~60 ~550 ~107 ~60 ~550 minecraft:light_gray_concrete replace
fill ~106 ~60 ~551 ~106 ~60 ~552 minecraft:light_gray_concrete replace
fill ~123 ~60 ~554 ~128 ~60 ~554 minecraft:light_gray_concrete replace
fill ~127 ~60 ~555 ~127 ~60 ~556 minecraft:light_gray_concrete replace
fill ~144 ~60 ~558 ~146 ~60 ~558 minecraft:light_gray_concrete replace
fill ~145 ~60 ~559 ~145 ~60 ~560 minecraft:light_gray_concrete replace
fill ~171 ~60 ~562 ~174 ~60 ~562 minecraft:light_gray_concrete replace
fill ~172 ~60 ~563 ~172 ~60 ~564 minecraft:light_gray_concrete replace
fill ~195 ~60 ~566 ~197 ~60 ~566 minecraft:light_gray_concrete replace
fill ~196 ~60 ~567 ~196 ~60 ~568 minecraft:light_gray_concrete replace
fill ~96 ~60 ~590 ~101 ~60 ~590 minecraft:light_gray_concrete replace
fill ~100 ~60 ~591 ~100 ~60 ~592 minecraft:light_gray_concrete replace
fill ~120 ~60 ~594 ~125 ~60 ~594 minecraft:light_gray_concrete replace
fill ~124 ~60 ~595 ~124 ~60 ~596 minecraft:light_gray_concrete replace
fill ~141 ~60 ~598 ~143 ~60 ~598 minecraft:light_gray_concrete replace
fill ~142 ~60 ~599 ~142 ~60 ~600 minecraft:light_gray_concrete replace
fill ~168 ~60 ~602 ~171 ~60 ~602 minecraft:light_gray_concrete replace
fill ~169 ~60 ~603 ~169 ~60 ~604 minecraft:light_gray_concrete replace
fill ~192 ~60 ~606 ~194 ~60 ~606 minecraft:light_gray_concrete replace
fill ~193 ~60 ~607 ~193 ~60 ~608 minecraft:light_gray_concrete replace
fill ~81 ~60 ~610 ~86 ~60 ~610 minecraft:light_gray_concrete replace
fill ~85 ~60 ~611 ~85 ~60 ~612 minecraft:light_gray_concrete replace
fill ~84 ~60 ~614 ~89 ~60 ~614 minecraft:light_gray_concrete replace
fill ~88 ~60 ~615 ~88 ~60 ~616 minecraft:light_gray_concrete replace
fill ~87 ~60 ~618 ~92 ~60 ~618 minecraft:light_gray_concrete replace
fill ~91 ~60 ~619 ~91 ~60 ~620 minecraft:light_gray_concrete replace
fill ~90 ~60 ~622 ~95 ~60 ~622 minecraft:light_gray_concrete replace
fill ~94 ~60 ~623 ~94 ~60 ~624 minecraft:light_gray_concrete replace
fill ~93 ~60 ~626 ~98 ~60 ~626 minecraft:light_gray_concrete replace
fill ~97 ~60 ~627 ~97 ~60 ~628 minecraft:light_gray_concrete replace
fill ~114 ~60 ~630 ~119 ~60 ~630 minecraft:light_gray_concrete replace
fill ~118 ~60 ~631 ~118 ~60 ~632 minecraft:light_gray_concrete replace
fill ~147 ~60 ~634 ~149 ~60 ~634 minecraft:light_gray_concrete replace
fill ~148 ~60 ~635 ~148 ~60 ~636 minecraft:light_gray_concrete replace
fill ~159 ~60 ~638 ~161 ~60 ~638 minecraft:light_gray_concrete replace
fill ~160 ~60 ~639 ~160 ~60 ~640 minecraft:light_gray_concrete replace
fill ~180 ~60 ~642 ~183 ~60 ~642 minecraft:light_gray_concrete replace
fill ~181 ~60 ~643 ~181 ~60 ~644 minecraft:light_gray_concrete replace
fill ~81 ~60 ~646 ~200 ~60 ~646 minecraft:light_gray_concrete replace
fill ~82 ~60 ~647 ~82 ~60 ~648 minecraft:light_gray_concrete replace
fill ~103 ~60 ~647 ~103 ~60 ~648 minecraft:light_gray_concrete replace
fill ~121 ~60 ~647 ~121 ~60 ~648 minecraft:light_gray_concrete replace
fill ~139 ~60 ~647 ~139 ~60 ~648 minecraft:light_gray_concrete replace
fill ~163 ~60 ~647 ~163 ~60 ~648 minecraft:light_gray_concrete replace
fill ~199 ~60 ~647 ~199 ~60 ~648 minecraft:light_gray_concrete replace
fill ~210 ~60 ~650 ~218 ~60 ~650 minecraft:light_gray_concrete replace
fill ~217 ~60 ~651 ~217 ~60 ~652 minecraft:light_gray_concrete replace
fill ~78 ~60 ~654 ~80 ~60 ~654 minecraft:light_gray_concrete replace
fill ~79 ~60 ~655 ~79 ~60 ~656 minecraft:light_gray_concrete replace
fill ~183 ~60 ~658 ~186 ~60 ~658 minecraft:light_gray_concrete replace
fill ~184 ~60 ~659 ~184 ~60 ~660 minecraft:light_gray_concrete replace
fill ~207 ~60 ~662 ~215 ~60 ~662 minecraft:light_gray_concrete replace
fill ~214 ~60 ~663 ~214 ~60 ~664 minecraft:light_gray_concrete replace
setblock ~103 ~61 ~332 minecraft:light_gray_concrete replace
setblock ~121 ~61 ~348 minecraft:light_gray_concrete replace
setblock ~163 ~61 ~364 minecraft:light_gray_concrete replace
setblock ~139 ~61 ~380 minecraft:light_gray_concrete replace
setblock ~187 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~190 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~208 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~211 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~91 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~93 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~108 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~110 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~125 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~127 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~142 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~144 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~159 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~161 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~175 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~177 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~192 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~194 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~82 ~61 ~400 minecraft:light_gray_concrete replace
setblock ~208 ~61 ~400 minecraft:light_gray_concrete replace
setblock ~211 ~61 ~400 minecraft:light_gray_concrete replace
setblock ~187 ~61 ~404 minecraft:light_gray_concrete replace
setblock ~190 ~61 ~404 minecraft:light_gray_concrete replace
setblock ~115 ~61 ~436 minecraft:light_gray_concrete replace
setblock ~136 ~61 ~440 minecraft:light_gray_concrete replace
setblock ~157 ~61 ~444 minecraft:light_gray_concrete replace
setblock ~166 ~61 ~448 minecraft:light_gray_concrete replace
setblock ~112 ~61 ~472 minecraft:light_gray_concrete replace
setblock ~133 ~61 ~476 minecraft:light_gray_concrete replace
setblock ~154 ~61 ~480 minecraft:light_gray_concrete replace
setblock ~178 ~61 ~484 minecraft:light_gray_concrete replace
setblock ~205 ~61 ~488 minecraft:light_gray_concrete replace
setblock ~109 ~61 ~512 minecraft:light_gray_concrete replace
setblock ~130 ~61 ~516 minecraft:light_gray_concrete replace
setblock ~151 ~61 ~520 minecraft:light_gray_concrete replace
setblock ~175 ~61 ~524 minecraft:light_gray_concrete replace
setblock ~202 ~61 ~528 minecraft:light_gray_concrete replace
setblock ~106 ~61 ~552 minecraft:light_gray_concrete replace
setblock ~127 ~61 ~556 minecraft:light_gray_concrete replace
setblock ~145 ~61 ~560 minecraft:light_gray_concrete replace
setblock ~172 ~61 ~564 minecraft:light_gray_concrete replace
setblock ~196 ~61 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~61 ~592 minecraft:light_gray_concrete replace
setblock ~124 ~61 ~596 minecraft:light_gray_concrete replace
setblock ~142 ~61 ~600 minecraft:light_gray_concrete replace
setblock ~169 ~61 ~604 minecraft:light_gray_concrete replace
setblock ~193 ~61 ~608 minecraft:light_gray_concrete replace
setblock ~85 ~61 ~612 minecraft:light_gray_concrete replace
setblock ~88 ~61 ~616 minecraft:light_gray_concrete replace
setblock ~91 ~61 ~620 minecraft:light_gray_concrete replace
setblock ~94 ~61 ~624 minecraft:light_gray_concrete replace
setblock ~97 ~61 ~628 minecraft:light_gray_concrete replace
setblock ~118 ~61 ~632 minecraft:light_gray_concrete replace
setblock ~148 ~61 ~636 minecraft:light_gray_concrete replace
setblock ~160 ~61 ~640 minecraft:light_gray_concrete replace
setblock ~181 ~61 ~644 minecraft:light_gray_concrete replace
setblock ~89 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~91 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~106 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~108 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~123 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~125 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~152 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~154 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~168 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~170 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~184 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~186 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~82 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~103 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~121 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~139 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~163 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~199 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~217 ~61 ~652 minecraft:light_gray_concrete replace
setblock ~79 ~61 ~656 minecraft:light_gray_concrete replace
setblock ~184 ~61 ~660 minecraft:light_gray_concrete replace
setblock ~214 ~61 ~664 minecraft:light_gray_concrete replace
fill ~102 ~62 ~328 ~102 ~62 ~648 minecraft:light_gray_concrete replace
fill ~120 ~62 ~344 ~120 ~62 ~648 minecraft:light_gray_concrete replace
fill ~162 ~62 ~360 ~162 ~62 ~648 minecraft:light_gray_concrete replace
fill ~138 ~62 ~376 ~138 ~62 ~648 minecraft:light_gray_concrete replace
fill ~210 ~62 ~380 ~210 ~62 ~400 minecraft:light_gray_concrete replace
fill ~207 ~62 ~384 ~207 ~62 ~400 minecraft:light_gray_concrete replace
fill ~189 ~62 ~388 ~189 ~62 ~404 minecraft:light_gray_concrete replace
fill ~186 ~62 ~392 ~186 ~62 ~404 minecraft:light_gray_concrete replace
fill ~81 ~62 ~396 ~81 ~62 ~648 minecraft:light_gray_concrete replace
fill ~114 ~62 ~432 ~114 ~62 ~436 minecraft:light_gray_concrete replace
fill ~135 ~62 ~436 ~135 ~62 ~440 minecraft:light_gray_concrete replace
fill ~156 ~62 ~440 ~156 ~62 ~444 minecraft:light_gray_concrete replace
fill ~165 ~62 ~444 ~165 ~62 ~448 minecraft:light_gray_concrete replace
fill ~111 ~62 ~468 ~111 ~62 ~472 minecraft:light_gray_concrete replace
fill ~132 ~62 ~472 ~132 ~62 ~476 minecraft:light_gray_concrete replace
fill ~153 ~62 ~476 ~153 ~62 ~480 minecraft:light_gray_concrete replace
fill ~177 ~62 ~480 ~177 ~62 ~484 minecraft:light_gray_concrete replace
fill ~204 ~62 ~484 ~204 ~62 ~488 minecraft:light_gray_concrete replace
fill ~108 ~62 ~508 ~108 ~62 ~512 minecraft:light_gray_concrete replace
fill ~129 ~62 ~512 ~129 ~62 ~516 minecraft:light_gray_concrete replace
fill ~150 ~62 ~516 ~150 ~62 ~520 minecraft:light_gray_concrete replace
fill ~174 ~62 ~520 ~174 ~62 ~524 minecraft:light_gray_concrete replace
fill ~201 ~62 ~524 ~201 ~62 ~528 minecraft:light_gray_concrete replace
fill ~105 ~62 ~548 ~105 ~62 ~552 minecraft:light_gray_concrete replace
fill ~126 ~62 ~552 ~126 ~62 ~556 minecraft:light_gray_concrete replace
fill ~144 ~62 ~556 ~144 ~62 ~560 minecraft:light_gray_concrete replace
fill ~171 ~62 ~560 ~171 ~62 ~564 minecraft:light_gray_concrete replace
fill ~195 ~62 ~564 ~195 ~62 ~568 minecraft:light_gray_concrete replace
fill ~99 ~62 ~588 ~99 ~62 ~592 minecraft:light_gray_concrete replace
fill ~123 ~62 ~592 ~123 ~62 ~596 minecraft:light_gray_concrete replace
fill ~141 ~62 ~596 ~141 ~62 ~600 minecraft:light_gray_concrete replace
fill ~168 ~62 ~600 ~168 ~62 ~604 minecraft:light_gray_concrete replace
fill ~192 ~62 ~604 ~192 ~62 ~608 minecraft:light_gray_concrete replace
fill ~84 ~62 ~608 ~84 ~62 ~612 minecraft:light_gray_concrete replace
fill ~87 ~62 ~612 ~87 ~62 ~616 minecraft:light_gray_concrete replace
fill ~90 ~62 ~616 ~90 ~62 ~620 minecraft:light_gray_concrete replace
fill ~93 ~62 ~620 ~93 ~62 ~624 minecraft:light_gray_concrete replace
fill ~96 ~62 ~624 ~96 ~62 ~628 minecraft:light_gray_concrete replace
fill ~117 ~62 ~628 ~117 ~62 ~632 minecraft:light_gray_concrete replace
fill ~147 ~62 ~632 ~147 ~62 ~636 minecraft:light_gray_concrete replace
fill ~159 ~62 ~636 ~159 ~62 ~640 minecraft:light_gray_concrete replace
fill ~180 ~62 ~640 ~180 ~62 ~644 minecraft:light_gray_concrete replace
fill ~198 ~62 ~644 ~198 ~62 ~648 minecraft:light_gray_concrete replace
fill ~216 ~62 ~648 ~216 ~62 ~652 minecraft:light_gray_concrete replace
fill ~78 ~62 ~652 ~78 ~62 ~656 minecraft:light_gray_concrete replace
fill ~183 ~62 ~656 ~183 ~62 ~660 minecraft:light_gray_concrete replace
fill ~213 ~62 ~660 ~213 ~62 ~664 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~327 minecraft:light_gray_concrete replace
setblock ~103 ~63 ~332 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~343 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~345 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~347 minecraft:light_gray_concrete replace
setblock ~121 ~63 ~348 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~359 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~361 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~361 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~363 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~363 minecraft:light_gray_concrete replace
setblock ~163 ~63 ~364 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~375 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~377 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~377 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~377 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~210 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~139 ~63 ~380 minecraft:light_gray_concrete replace
setblock ~207 ~63 ~383 minecraft:light_gray_concrete replace
setblock ~207 ~63 ~385 minecraft:light_gray_concrete replace
setblock ~210 ~63 ~385 minecraft:light_gray_concrete replace
setblock ~189 ~63 ~387 minecraft:light_gray_concrete replace
setblock ~207 ~63 ~387 minecraft:light_gray_concrete replace
setblock ~210 ~63 ~387 minecraft:light_gray_concrete replace
setblock ~189 ~63 ~389 minecraft:light_gray_concrete replace
setblock ~186 ~63 ~391 minecraft:light_gray_concrete replace
setblock ~189 ~63 ~391 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~186 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~190 ~63 ~396 minecraft:light_gray_concrete replace
setblock ~211 ~63 ~396 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~397 minecraft:light_gray_concrete replace
setblock ~82 ~63 ~400 minecraft:light_gray_concrete replace
setblock ~208 ~63 ~400 minecraft:light_gray_concrete replace
setblock ~187 ~63 ~404 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~63 ~431 minecraft:light_gray_concrete replace
setblock ~135 ~63 ~435 minecraft:light_gray_concrete replace
setblock ~156 ~63 ~439 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~165 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~111 ~63 ~467 minecraft:light_gray_concrete replace
setblock ~132 ~63 ~471 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~153 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~177 ~63 ~479 minecraft:light_gray_concrete replace
setblock ~204 ~63 ~483 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~108 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~129 ~63 ~511 minecraft:light_gray_concrete replace
setblock ~150 ~63 ~515 minecraft:light_gray_concrete replace
setblock ~174 ~63 ~519 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~201 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~105 ~63 ~547 minecraft:light_gray_concrete replace
setblock ~126 ~63 ~551 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~171 ~63 ~559 minecraft:light_gray_concrete replace
setblock ~195 ~63 ~563 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~99 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~123 ~63 ~591 minecraft:light_gray_concrete replace
setblock ~141 ~63 ~595 minecraft:light_gray_concrete replace
setblock ~168 ~63 ~599 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~192 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~84 ~63 ~607 minecraft:light_gray_concrete replace
setblock ~87 ~63 ~611 minecraft:light_gray_concrete replace
setblock ~90 ~63 ~615 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~93 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~96 ~63 ~623 minecraft:light_gray_concrete replace
setblock ~117 ~63 ~627 minecraft:light_gray_concrete replace
setblock ~147 ~63 ~631 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~159 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~180 ~63 ~639 minecraft:light_gray_concrete replace
setblock ~198 ~63 ~643 minecraft:light_gray_concrete replace
setblock ~216 ~63 ~647 minecraft:light_gray_concrete replace
setblock ~78 ~63 ~651 minecraft:light_gray_concrete replace
setblock ~183 ~63 ~655 minecraft:light_gray_concrete replace
setblock ~213 ~63 ~659 minecraft:light_gray_concrete replace
fill ~97 ~64 ~324 ~97 ~64 ~325 minecraft:light_gray_concrete replace
fill ~96 ~64 ~326 ~102 ~64 ~326 minecraft:light_gray_concrete replace
fill ~100 ~64 ~340 ~100 ~64 ~341 minecraft:light_gray_concrete replace
fill ~99 ~64 ~342 ~120 ~64 ~342 minecraft:light_gray_concrete replace
fill ~106 ~64 ~356 ~106 ~64 ~357 minecraft:light_gray_concrete replace
fill ~105 ~64 ~358 ~162 ~64 ~358 minecraft:light_gray_concrete replace
fill ~103 ~64 ~372 ~103 ~64 ~373 minecraft:light_gray_concrete replace
fill ~102 ~64 ~374 ~138 ~64 ~374 minecraft:light_gray_concrete replace
fill ~133 ~64 ~376 ~133 ~64 ~377 minecraft:light_gray_concrete replace
fill ~132 ~64 ~378 ~210 ~64 ~378 minecraft:light_gray_concrete replace
fill ~133 ~64 ~380 ~133 ~64 ~381 minecraft:light_gray_concrete replace
fill ~132 ~64 ~382 ~207 ~64 ~382 minecraft:light_gray_concrete replace
fill ~115 ~64 ~384 ~115 ~64 ~385 minecraft:light_gray_concrete replace
fill ~114 ~64 ~386 ~189 ~64 ~386 minecraft:light_gray_concrete replace
fill ~115 ~64 ~388 ~115 ~64 ~389 minecraft:light_gray_concrete replace
fill ~114 ~64 ~390 ~186 ~64 ~390 minecraft:light_gray_concrete replace
fill ~82 ~64 ~392 ~82 ~64 ~393 minecraft:light_gray_concrete replace
fill ~81 ~64 ~394 ~83 ~64 ~394 minecraft:light_gray_concrete replace
fill ~97 ~64 ~428 ~97 ~64 ~429 minecraft:light_gray_concrete replace
fill ~96 ~64 ~430 ~114 ~64 ~430 minecraft:light_gray_concrete replace
fill ~100 ~64 ~432 ~100 ~64 ~433 minecraft:light_gray_concrete replace
fill ~99 ~64 ~434 ~135 ~64 ~434 minecraft:light_gray_concrete replace
fill ~103 ~64 ~436 ~103 ~64 ~437 minecraft:light_gray_concrete replace
fill ~102 ~64 ~438 ~156 ~64 ~438 minecraft:light_gray_concrete replace
fill ~106 ~64 ~440 ~106 ~64 ~441 minecraft:light_gray_concrete replace
fill ~105 ~64 ~442 ~165 ~64 ~442 minecraft:light_gray_concrete replace
fill ~97 ~64 ~464 ~97 ~64 ~465 minecraft:light_gray_concrete replace
fill ~96 ~64 ~466 ~111 ~64 ~466 minecraft:light_gray_concrete replace
fill ~100 ~64 ~468 ~100 ~64 ~469 minecraft:light_gray_concrete replace
fill ~99 ~64 ~470 ~132 ~64 ~470 minecraft:light_gray_concrete replace
fill ~103 ~64 ~472 ~103 ~64 ~473 minecraft:light_gray_concrete replace
fill ~102 ~64 ~474 ~153 ~64 ~474 minecraft:light_gray_concrete replace
fill ~106 ~64 ~476 ~106 ~64 ~477 minecraft:light_gray_concrete replace
fill ~105 ~64 ~478 ~177 ~64 ~478 minecraft:light_gray_concrete replace
fill ~130 ~64 ~480 ~130 ~64 ~481 minecraft:light_gray_concrete replace
fill ~129 ~64 ~482 ~204 ~64 ~482 minecraft:light_gray_concrete replace
fill ~97 ~64 ~504 ~97 ~64 ~505 minecraft:light_gray_concrete replace
