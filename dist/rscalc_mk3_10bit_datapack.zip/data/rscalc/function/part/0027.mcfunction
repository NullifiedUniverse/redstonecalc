fill ~150 ~135 ~548 ~150 ~135 ~560 minecraft:redstone_wire replace
setblock ~129 ~135 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~135 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~550 ~129 ~135 ~562 minecraft:redstone_wire replace
fill ~135 ~135 ~550 ~135 ~135 ~562 minecraft:redstone_wire replace
fill ~144 ~135 ~550 ~144 ~135 ~562 minecraft:redstone_wire replace
setblock ~126 ~135 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~135 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~135 ~554 ~126 ~135 ~566 minecraft:redstone_wire replace
fill ~132 ~135 ~554 ~132 ~135 ~566 minecraft:redstone_wire replace
setblock ~141 ~135 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~135 ~556 ~141 ~135 ~568 minecraft:redstone_wire replace
setblock ~153 ~135 ~560 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~135 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~135 ~562 ~153 ~135 ~568 minecraft:redstone_wire replace
setblock ~129 ~135 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~135 ~564 ~138 ~135 ~576 minecraft:redstone_wire replace
setblock ~144 ~135 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~135 ~564 minecraft:redstone_wire replace
fill ~150 ~135 ~564 ~150 ~135 ~576 minecraft:redstone_wire replace
setblock ~147 ~135 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~566 ~129 ~135 ~578 minecraft:redstone_wire replace
fill ~135 ~135 ~566 ~135 ~135 ~578 minecraft:redstone_wire replace
fill ~144 ~135 ~566 ~144 ~135 ~578 minecraft:redstone_wire replace
fill ~147 ~135 ~566 ~147 ~135 ~578 minecraft:redstone_wire replace
setblock ~126 ~135 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~135 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~135 ~568 ~126 ~135 ~580 minecraft:redstone_wire replace
fill ~132 ~135 ~568 ~132 ~135 ~580 minecraft:redstone_wire replace
fill ~156 ~135 ~576 ~156 ~135 ~578 minecraft:redstone_wire replace
setblock ~138 ~135 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~135 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~580 ~129 ~135 ~592 minecraft:redstone_wire replace
fill ~135 ~135 ~580 ~135 ~135 ~592 minecraft:redstone_wire replace
fill ~138 ~135 ~580 ~138 ~135 ~592 minecraft:redstone_wire replace
fill ~144 ~135 ~580 ~144 ~135 ~592 minecraft:redstone_wire replace
fill ~147 ~135 ~580 ~147 ~135 ~592 minecraft:redstone_wire replace
fill ~150 ~135 ~580 ~150 ~135 ~592 minecraft:redstone_wire replace
fill ~156 ~135 ~580 ~156 ~135 ~592 minecraft:redstone_wire replace
setblock ~129 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~135 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~135 ~596 ~129 ~135 ~608 minecraft:redstone_wire replace
fill ~135 ~135 ~596 ~135 ~135 ~608 minecraft:redstone_wire replace
fill ~138 ~135 ~596 ~138 ~135 ~608 minecraft:redstone_wire replace
fill ~144 ~135 ~596 ~144 ~135 ~608 minecraft:redstone_wire replace
fill ~147 ~135 ~596 ~147 ~135 ~608 minecraft:redstone_wire replace
fill ~150 ~135 ~596 ~150 ~135 ~608 minecraft:redstone_wire replace
fill ~156 ~135 ~596 ~156 ~135 ~608 minecraft:redstone_wire replace
fill ~162 ~135 ~608 ~162 ~135 ~612 minecraft:redstone_wire replace
fill ~159 ~135 ~620 ~159 ~135 ~624 minecraft:redstone_wire replace
fill ~171 ~135 ~644 ~171 ~135 ~648 minecraft:redstone_wire replace
fill ~84 ~135 ~648 ~84 ~135 ~652 minecraft:redstone_wire replace
fill ~165 ~135 ~652 ~165 ~135 ~656 minecraft:redstone_wire replace
fill ~168 ~135 ~660 ~168 ~135 ~664 minecraft:redstone_wire replace
setblock ~114 ~136 ~383 minecraft:redstone_wire replace
setblock ~81 ~136 ~395 minecraft:redstone_wire replace
setblock ~87 ~136 ~443 minecraft:redstone_wire replace
setblock ~78 ~136 ~447 minecraft:redstone_wire replace
setblock ~117 ~136 ~451 minecraft:redstone_wire replace
setblock ~108 ~136 ~455 minecraft:redstone_wire replace
setblock ~105 ~136 ~459 minecraft:redstone_wire replace
setblock ~102 ~136 ~463 minecraft:redstone_wire replace
setblock ~99 ~136 ~467 minecraft:redstone_wire replace
setblock ~96 ~136 ~471 minecraft:redstone_wire replace
setblock ~93 ~136 ~475 minecraft:redstone_wire replace
setblock ~90 ~136 ~479 minecraft:redstone_wire replace
setblock ~123 ~136 ~495 minecraft:redstone_wire replace
setblock ~111 ~136 ~499 minecraft:redstone_wire replace
setblock ~120 ~136 ~511 minecraft:redstone_wire replace
setblock ~150 ~136 ~515 minecraft:redstone_wire replace
setblock ~144 ~136 ~519 minecraft:redstone_wire replace
setblock ~141 ~136 ~523 minecraft:redstone_wire replace
setblock ~138 ~136 ~527 minecraft:redstone_wire replace
setblock ~135 ~136 ~531 minecraft:redstone_wire replace
setblock ~132 ~136 ~535 minecraft:redstone_wire replace
setblock ~129 ~136 ~539 minecraft:redstone_wire replace
setblock ~126 ~136 ~543 minecraft:redstone_wire replace
setblock ~153 ~136 ~559 minecraft:redstone_wire replace
setblock ~147 ~136 ~563 minecraft:redstone_wire replace
setblock ~156 ~136 ~575 minecraft:redstone_wire replace
setblock ~162 ~136 ~607 minecraft:redstone_wire replace
setblock ~159 ~136 ~619 minecraft:redstone_wire replace
setblock ~171 ~136 ~643 minecraft:redstone_wire replace
setblock ~84 ~136 ~647 minecraft:redstone_wire replace
setblock ~165 ~136 ~651 minecraft:redstone_wire replace
setblock ~168 ~136 ~659 minecraft:redstone_wire replace
setblock ~100 ~137 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~137 ~382 ~104 ~137 ~382 minecraft:redstone_wire replace
setblock ~106 ~137 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~137 ~382 ~114 ~137 ~382 minecraft:redstone_wire replace
setblock ~82 ~137 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~137 ~394 ~83 ~137 ~394 minecraft:redstone_wire replace
setblock ~88 ~137 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~137 ~442 ~89 ~137 ~442 minecraft:redstone_wire replace
setblock ~79 ~137 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~137 ~446 ~80 ~137 ~446 minecraft:redstone_wire replace
setblock ~103 ~137 ~449 minecraft:redstone_wire replace
fill ~102 ~137 ~450 ~103 ~137 ~450 minecraft:redstone_wire replace
setblock ~104 ~137 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~137 ~450 ~117 ~137 ~450 minecraft:redstone_wire replace
setblock ~97 ~137 ~453 minecraft:redstone_wire replace
fill ~96 ~137 ~454 ~97 ~137 ~454 minecraft:redstone_wire replace
setblock ~99 ~137 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~137 ~454 ~108 ~137 ~454 minecraft:redstone_wire replace
setblock ~97 ~137 ~457 minecraft:redstone_wire replace
fill ~96 ~137 ~458 ~105 ~137 ~458 minecraft:redstone_wire replace
setblock ~94 ~137 ~461 minecraft:redstone_wire replace
fill ~93 ~137 ~462 ~102 ~137 ~462 minecraft:redstone_wire replace
setblock ~94 ~137 ~465 minecraft:redstone_wire replace
fill ~93 ~137 ~466 ~99 ~137 ~466 minecraft:redstone_wire replace
setblock ~94 ~137 ~469 minecraft:redstone_wire replace
fill ~93 ~137 ~470 ~96 ~137 ~470 minecraft:redstone_wire replace
setblock ~91 ~137 ~473 minecraft:redstone_wire replace
fill ~90 ~137 ~474 ~93 ~137 ~474 minecraft:redstone_wire replace
setblock ~91 ~137 ~477 minecraft:redstone_wire replace
fill ~90 ~137 ~478 ~92 ~137 ~478 minecraft:redstone_wire replace
setblock ~103 ~137 ~493 minecraft:redstone_wire replace
fill ~102 ~137 ~494 ~107 ~137 ~494 minecraft:redstone_wire replace
setblock ~109 ~137 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~137 ~494 ~123 ~137 ~494 minecraft:redstone_wire replace
setblock ~97 ~137 ~497 minecraft:redstone_wire replace
fill ~96 ~137 ~498 ~97 ~137 ~498 minecraft:redstone_wire replace
setblock ~98 ~137 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~137 ~498 ~111 ~137 ~498 minecraft:redstone_wire replace
setblock ~103 ~137 ~509 minecraft:redstone_wire replace
fill ~102 ~137 ~510 ~104 ~137 ~510 minecraft:redstone_wire replace
setblock ~106 ~137 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~137 ~510 ~120 ~137 ~510 minecraft:redstone_wire replace
setblock ~115 ~137 ~513 minecraft:redstone_wire replace
fill ~114 ~137 ~514 ~118 ~137 ~514 minecraft:redstone_wire replace
setblock ~120 ~137 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~137 ~514 ~135 ~137 ~514 minecraft:redstone_wire replace
setblock ~137 ~137 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~137 ~514 ~150 ~137 ~514 minecraft:redstone_wire replace
setblock ~112 ~137 ~517 minecraft:redstone_wire replace
fill ~111 ~137 ~518 ~113 ~137 ~518 minecraft:redstone_wire replace
setblock ~114 ~137 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~137 ~518 ~128 ~137 ~518 minecraft:redstone_wire replace
setblock ~130 ~137 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~137 ~518 ~144 ~137 ~518 minecraft:redstone_wire replace
setblock ~112 ~137 ~521 minecraft:redstone_wire replace
setblock ~111 ~137 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~137 ~522 ~125 ~137 ~522 minecraft:redstone_wire replace
setblock ~127 ~137 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~137 ~522 ~141 ~137 ~522 minecraft:redstone_wire replace
setblock ~109 ~137 ~525 minecraft:redstone_wire replace
fill ~108 ~137 ~526 ~110 ~137 ~526 minecraft:redstone_wire replace
setblock ~111 ~137 ~526 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~137 ~526 ~125 ~137 ~526 minecraft:redstone_wire replace
setblock ~127 ~137 ~526 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~137 ~526 ~138 ~137 ~526 minecraft:redstone_wire replace
setblock ~109 ~137 ~529 minecraft:redstone_wire replace
fill ~108 ~137 ~530 ~120 ~137 ~530 minecraft:redstone_wire replace
setblock ~122 ~137 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~137 ~530 ~135 ~137 ~530 minecraft:redstone_wire replace
setblock ~109 ~137 ~533 minecraft:redstone_wire replace
fill ~108 ~137 ~534 ~117 ~137 ~534 minecraft:redstone_wire replace
setblock ~119 ~137 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~137 ~534 ~132 ~137 ~534 minecraft:redstone_wire replace
setblock ~106 ~137 ~537 minecraft:redstone_wire replace
fill ~105 ~137 ~538 ~113 ~137 ~538 minecraft:redstone_wire replace
setblock ~115 ~137 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~137 ~538 ~129 ~137 ~538 minecraft:redstone_wire replace
setblock ~106 ~137 ~541 minecraft:redstone_wire replace
fill ~105 ~137 ~542 ~117 ~137 ~542 minecraft:redstone_wire replace
setblock ~119 ~137 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~137 ~542 ~126 ~137 ~542 minecraft:redstone_wire replace
setblock ~115 ~137 ~557 minecraft:redstone_wire replace
fill ~114 ~137 ~558 ~120 ~137 ~558 minecraft:redstone_wire replace
setblock ~122 ~137 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~137 ~558 ~137 ~137 ~558 minecraft:redstone_wire replace
setblock ~139 ~137 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~137 ~558 ~153 ~137 ~558 minecraft:redstone_wire replace
setblock ~112 ~137 ~561 minecraft:redstone_wire replace
fill ~111 ~137 ~562 ~115 ~137 ~562 minecraft:redstone_wire replace
setblock ~117 ~137 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~137 ~562 ~132 ~137 ~562 minecraft:redstone_wire replace
setblock ~134 ~137 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~137 ~562 ~147 ~137 ~562 minecraft:redstone_wire replace
setblock ~115 ~137 ~573 minecraft:redstone_wire replace
fill ~114 ~137 ~574 ~126 ~137 ~574 minecraft:redstone_wire replace
setblock ~128 ~137 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~137 ~574 ~143 ~137 ~574 minecraft:redstone_wire replace
setblock ~145 ~137 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~137 ~574 ~156 ~137 ~574 minecraft:redstone_wire replace
setblock ~121 ~137 ~605 minecraft:redstone_wire replace
fill ~120 ~137 ~606 ~121 ~137 ~606 minecraft:redstone_wire replace
setblock ~123 ~137 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~137 ~606 ~137 ~137 ~606 minecraft:redstone_wire replace
setblock ~139 ~137 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~137 ~606 ~153 ~137 ~606 minecraft:redstone_wire replace
setblock ~155 ~137 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~137 ~606 ~162 ~137 ~606 minecraft:redstone_wire replace
setblock ~118 ~137 ~617 minecraft:redstone_wire replace
fill ~117 ~137 ~618 ~118 ~137 ~618 minecraft:redstone_wire replace
setblock ~120 ~137 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~137 ~618 ~134 ~137 ~618 minecraft:redstone_wire replace
setblock ~136 ~137 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~137 ~618 ~150 ~137 ~618 minecraft:redstone_wire replace
setblock ~152 ~137 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~137 ~618 ~159 ~137 ~618 minecraft:redstone_wire replace
setblock ~130 ~137 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~137 ~642 ~130 ~137 ~642 minecraft:redstone_wire replace
setblock ~132 ~137 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~137 ~642 ~146 ~137 ~642 minecraft:redstone_wire replace
setblock ~148 ~137 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~137 ~642 ~162 ~137 ~642 minecraft:redstone_wire replace
setblock ~164 ~137 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~137 ~642 ~171 ~137 ~642 minecraft:redstone_wire replace
setblock ~85 ~137 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~137 ~646 ~86 ~137 ~646 minecraft:redstone_wire replace
setblock ~124 ~137 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~137 ~650 ~124 ~137 ~650 minecraft:redstone_wire replace
setblock ~126 ~137 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~137 ~650 ~140 ~137 ~650 minecraft:redstone_wire replace
setblock ~142 ~137 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~137 ~650 ~156 ~137 ~650 minecraft:redstone_wire replace
setblock ~158 ~137 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~137 ~650 ~165 ~137 ~650 minecraft:redstone_wire replace
setblock ~127 ~137 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~137 ~658 ~127 ~137 ~658 minecraft:redstone_wire replace
setblock ~129 ~137 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~137 ~658 ~143 ~137 ~658 minecraft:redstone_wire replace
setblock ~145 ~137 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~137 ~658 ~159 ~137 ~658 minecraft:redstone_wire replace
setblock ~161 ~137 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~137 ~658 ~168 ~137 ~658 minecraft:redstone_wire replace
setblock ~100 ~138 ~380 minecraft:redstone_wire replace
setblock ~82 ~138 ~392 minecraft:redstone_wire replace
setblock ~88 ~138 ~440 minecraft:redstone_wire replace
setblock ~79 ~138 ~444 minecraft:redstone_wire replace
setblock ~103 ~138 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~138 ~452 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~138 ~456 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~138 ~460 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~138 ~464 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~138 ~468 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~138 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~138 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~138 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~138 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~138 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~138 ~512 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~138 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~138 ~520 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~138 ~524 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~138 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~138 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~138 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~138 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~138 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~138 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~138 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~138 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~138 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~138 ~640 minecraft:redstone_wire replace
setblock ~85 ~138 ~644 minecraft:redstone_wire replace
setblock ~124 ~138 ~648 minecraft:redstone_wire replace
setblock ~127 ~138 ~656 minecraft:redstone_wire replace
fill ~99 ~139 ~380 ~99 ~139 ~384 minecraft:redstone_wire replace
fill ~81 ~139 ~392 ~81 ~139 ~396 minecraft:redstone_wire replace
fill ~87 ~139 ~440 ~87 ~139 ~444 minecraft:redstone_wire replace
fill ~78 ~139 ~444 ~78 ~139 ~448 minecraft:redstone_wire replace
fill ~102 ~139 ~448 ~102 ~139 ~460 minecraft:redstone_wire replace
fill ~96 ~139 ~452 ~96 ~139 ~464 minecraft:redstone_wire replace
fill ~93 ~139 ~460 ~93 ~139 ~470 minecraft:redstone_wire replace
setblock ~102 ~139 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~464 ~102 ~139 ~476 minecraft:redstone_wire replace
setblock ~96 ~139 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~139 ~468 ~96 ~139 ~480 minecraft:redstone_wire replace
fill ~90 ~139 ~472 ~90 ~139 ~478 minecraft:redstone_wire replace
setblock ~93 ~139 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~139 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~139 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~480 ~102 ~139 ~492 minecraft:redstone_wire replace
setblock ~96 ~139 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~139 ~484 ~96 ~139 ~496 minecraft:redstone_wire replace
setblock ~102 ~139 ~493 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~494 ~102 ~139 ~506 minecraft:redstone_wire replace
setblock ~96 ~139 ~497 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~139 ~498 ~96 ~139 ~500 minecraft:redstone_wire replace
setblock ~102 ~139 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~139 ~508 ~102 ~139 ~512 minecraft:redstone_wire replace
fill ~114 ~139 ~512 ~114 ~139 ~524 minecraft:redstone_wire replace
fill ~111 ~139 ~516 ~111 ~139 ~528 minecraft:redstone_wire replace
fill ~108 ~139 ~524 ~108 ~139 ~534 minecraft:redstone_wire replace
setblock ~114 ~139 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~528 ~114 ~139 ~540 minecraft:redstone_wire replace
setblock ~111 ~139 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~139 ~532 ~111 ~139 ~544 minecraft:redstone_wire replace
fill ~105 ~139 ~536 ~105 ~139 ~542 minecraft:redstone_wire replace
setblock ~108 ~139 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~139 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~139 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~544 ~114 ~139 ~556 minecraft:redstone_wire replace
setblock ~111 ~139 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~139 ~548 ~111 ~139 ~560 minecraft:redstone_wire replace
setblock ~114 ~139 ~557 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~558 ~114 ~139 ~570 minecraft:redstone_wire replace
setblock ~111 ~139 ~561 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~139 ~562 ~111 ~139 ~564 minecraft:redstone_wire replace
setblock ~114 ~139 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~139 ~572 ~114 ~139 ~576 minecraft:redstone_wire replace
fill ~120 ~139 ~604 ~120 ~139 ~608 minecraft:redstone_wire replace
fill ~117 ~139 ~616 ~117 ~139 ~620 minecraft:redstone_wire replace
fill ~129 ~139 ~640 ~129 ~139 ~644 minecraft:redstone_wire replace
fill ~84 ~139 ~644 ~84 ~139 ~648 minecraft:redstone_wire replace
fill ~123 ~139 ~648 ~123 ~139 ~652 minecraft:redstone_wire replace
fill ~126 ~139 ~656 ~126 ~139 ~660 minecraft:redstone_wire replace
setblock ~99 ~140 ~385 minecraft:redstone_wire replace
setblock ~81 ~140 ~397 minecraft:redstone_wire replace
setblock ~87 ~140 ~445 minecraft:redstone_wire replace
setblock ~78 ~140 ~449 minecraft:redstone_wire replace
setblock ~93 ~140 ~473 minecraft:redstone_wire replace
setblock ~90 ~140 ~481 minecraft:redstone_wire replace
setblock ~96 ~140 ~501 minecraft:redstone_wire replace
setblock ~102 ~140 ~513 minecraft:redstone_wire replace
setblock ~108 ~140 ~537 minecraft:redstone_wire replace
setblock ~105 ~140 ~545 minecraft:redstone_wire replace
setblock ~111 ~140 ~565 minecraft:redstone_wire replace
setblock ~114 ~140 ~577 minecraft:redstone_wire replace
setblock ~120 ~140 ~609 minecraft:redstone_wire replace
setblock ~117 ~140 ~621 minecraft:redstone_wire replace
setblock ~129 ~140 ~645 minecraft:redstone_wire replace
setblock ~84 ~140 ~649 minecraft:redstone_wire replace
setblock ~123 ~140 ~653 minecraft:redstone_wire replace
setblock ~126 ~140 ~661 minecraft:redstone_wire replace
fill ~99 ~141 ~386 ~105 ~141 ~386 minecraft:redstone_wire replace
setblock ~107 ~141 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~141 ~386 ~113 ~141 ~386 minecraft:redstone_wire replace
setblock ~112 ~141 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~141 ~398 ~83 ~141 ~398 minecraft:redstone_wire replace
setblock ~82 ~141 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~141 ~446 ~92 ~141 ~446 minecraft:redstone_wire replace
setblock ~93 ~141 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~141 ~446 ~106 ~141 ~446 minecraft:redstone_wire replace
setblock ~107 ~141 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~108 ~141 ~446 ~116 ~141 ~446 minecraft:redstone_wire replace
setblock ~88 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~141 ~447 minecraft:redstone_wire replace
setblock ~94 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~141 ~447 minecraft:redstone_wire replace
setblock ~100 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~141 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~141 ~447 minecraft:redstone_wire replace
setblock ~115 ~141 ~447 minecraft:redstone_wire replace
fill ~78 ~141 ~450 ~80 ~141 ~450 minecraft:redstone_wire replace
setblock ~79 ~141 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~141 ~474 ~104 ~141 ~474 minecraft:redstone_wire replace
setblock ~105 ~141 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~141 ~474 ~118 ~141 ~474 minecraft:redstone_wire replace
setblock ~119 ~141 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~141 ~474 ~122 ~141 ~474 minecraft:redstone_wire replace
setblock ~88 ~141 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~141 ~475 minecraft:redstone_wire replace
setblock ~97 ~141 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~141 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~141 ~475 minecraft:redstone_wire replace
setblock ~109 ~141 ~475 minecraft:redstone_wire replace
setblock ~121 ~141 ~475 minecraft:redstone_wire replace
fill ~87 ~141 ~482 ~101 ~141 ~482 minecraft:redstone_wire replace
setblock ~102 ~141 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~141 ~482 ~115 ~141 ~482 minecraft:redstone_wire replace
setblock ~116 ~141 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~117 ~141 ~482 ~119 ~141 ~482 minecraft:redstone_wire replace
setblock ~88 ~141 ~483 minecraft:redstone_wire replace
setblock ~91 ~141 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~141 ~483 minecraft:redstone_wire replace
setblock ~103 ~141 ~483 minecraft:redstone_wire replace
setblock ~109 ~141 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~141 ~483 minecraft:redstone_wire replace
fill ~90 ~141 ~502 ~104 ~141 ~502 minecraft:redstone_wire replace
setblock ~105 ~141 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~141 ~502 ~118 ~141 ~502 minecraft:redstone_wire replace
setblock ~119 ~141 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~141 ~502 ~122 ~141 ~502 minecraft:redstone_wire replace
setblock ~91 ~141 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~141 ~503 minecraft:redstone_wire replace
setblock ~100 ~141 ~503 minecraft:redstone_wire replace
setblock ~106 ~141 ~503 minecraft:redstone_wire replace
setblock ~109 ~141 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~141 ~503 minecraft:redstone_wire replace
setblock ~121 ~141 ~503 minecraft:redstone_wire replace
fill ~102 ~141 ~514 ~108 ~141 ~514 minecraft:redstone_wire replace
setblock ~110 ~141 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~141 ~514 ~125 ~141 ~514 minecraft:redstone_wire replace
setblock ~126 ~141 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~141 ~514 ~140 ~141 ~514 minecraft:redstone_wire replace
setblock ~141 ~141 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~141 ~514 ~149 ~141 ~514 minecraft:redstone_wire replace
setblock ~124 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~141 ~515 minecraft:redstone_wire replace
setblock ~130 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~141 ~515 minecraft:redstone_wire replace
setblock ~136 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~141 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~141 ~515 minecraft:redstone_wire replace
setblock ~148 ~141 ~515 minecraft:redstone_wire replace
fill ~108 ~141 ~538 ~120 ~141 ~538 minecraft:redstone_wire replace
setblock ~122 ~141 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~141 ~538 ~137 ~141 ~538 minecraft:redstone_wire replace
setblock ~139 ~141 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~141 ~538 ~154 ~141 ~538 minecraft:redstone_wire replace
setblock ~155 ~141 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~124 ~141 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~141 ~539 minecraft:redstone_wire replace
setblock ~133 ~141 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~141 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~141 ~539 minecraft:redstone_wire replace
setblock ~145 ~141 ~539 minecraft:redstone_wire replace
setblock ~154 ~141 ~539 minecraft:redstone_wire replace
fill ~105 ~141 ~546 ~117 ~141 ~546 minecraft:redstone_wire replace
setblock ~119 ~141 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~141 ~546 ~134 ~141 ~546 minecraft:redstone_wire replace
setblock ~136 ~141 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~138 ~141 ~546 ~151 ~141 ~546 minecraft:redstone_wire replace
setblock ~152 ~141 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~124 ~141 ~547 minecraft:redstone_wire replace
setblock ~127 ~141 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~141 ~547 minecraft:redstone_wire replace
setblock ~139 ~141 ~547 minecraft:redstone_wire replace
setblock ~145 ~141 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~141 ~547 minecraft:redstone_wire replace
fill ~111 ~141 ~566 ~120 ~141 ~566 minecraft:redstone_wire replace
setblock ~122 ~141 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~141 ~566 ~137 ~141 ~566 minecraft:redstone_wire replace
setblock ~139 ~141 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~141 ~566 ~154 ~141 ~566 minecraft:redstone_wire replace
setblock ~155 ~141 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~127 ~141 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~141 ~567 minecraft:redstone_wire replace
setblock ~136 ~141 ~567 minecraft:redstone_wire replace
setblock ~142 ~141 ~567 minecraft:redstone_wire replace
setblock ~145 ~141 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~141 ~567 minecraft:redstone_wire replace
setblock ~154 ~141 ~567 minecraft:redstone_wire replace
fill ~114 ~141 ~578 ~120 ~141 ~578 minecraft:redstone_wire replace
setblock ~122 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~141 ~578 ~137 ~141 ~578 minecraft:redstone_wire replace
setblock ~139 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~141 ~578 ~154 ~141 ~578 minecraft:redstone_wire replace
setblock ~155 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~141 ~578 ~169 ~141 ~578 minecraft:redstone_wire replace
setblock ~170 ~141 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~141 ~578 ~173 ~141 ~578 minecraft:redstone_wire replace
setblock ~157 ~141 ~579 minecraft:redstone_wire replace
setblock ~160 ~141 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~141 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~141 ~579 minecraft:redstone_wire replace
setblock ~172 ~141 ~579 minecraft:redstone_wire replace
fill ~120 ~141 ~610 ~126 ~141 ~610 minecraft:redstone_wire replace
setblock ~128 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~141 ~610 ~143 ~141 ~610 minecraft:redstone_wire replace
setblock ~145 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~141 ~610 ~160 ~141 ~610 minecraft:redstone_wire replace
setblock ~161 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~141 ~610 ~175 ~141 ~610 minecraft:redstone_wire replace
setblock ~176 ~141 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~160 ~141 ~611 minecraft:redstone_wire replace
setblock ~163 ~141 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~141 ~611 minecraft:redstone_wire replace
setblock ~169 ~141 ~611 minecraft:redstone_wire replace
setblock ~175 ~141 ~611 minecraft:redstone_wire replace
fill ~117 ~141 ~622 ~123 ~141 ~622 minecraft:redstone_wire replace
setblock ~125 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~141 ~622 ~140 ~141 ~622 minecraft:redstone_wire replace
setblock ~142 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~141 ~622 ~157 ~141 ~622 minecraft:redstone_wire replace
setblock ~158 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~141 ~622 ~172 ~141 ~622 minecraft:redstone_wire replace
setblock ~173 ~141 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~141 ~622 ~176 ~141 ~622 minecraft:redstone_wire replace
setblock ~157 ~141 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~141 ~623 minecraft:redstone_wire replace
setblock ~163 ~141 ~623 minecraft:redstone_wire replace
setblock ~166 ~141 ~623 minecraft:redstone_wire replace
setblock ~169 ~141 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~141 ~623 minecraft:redstone_wire replace
setblock ~175 ~141 ~623 minecraft:redstone_wire replace
fill ~129 ~141 ~646 ~135 ~141 ~646 minecraft:redstone_wire replace
setblock ~137 ~141 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~141 ~646 ~152 ~141 ~646 minecraft:redstone_wire replace
setblock ~154 ~141 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~141 ~646 ~169 ~141 ~646 minecraft:redstone_wire replace
setblock ~171 ~141 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~141 ~646 ~185 ~141 ~646 minecraft:redstone_wire replace
setblock ~184 ~141 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~141 ~650 ~86 ~141 ~650 minecraft:redstone_wire replace
setblock ~85 ~141 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~141 ~654 ~129 ~141 ~654 minecraft:redstone_wire replace
setblock ~131 ~141 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~141 ~654 ~146 ~141 ~654 minecraft:redstone_wire replace
setblock ~148 ~141 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~141 ~654 ~163 ~141 ~654 minecraft:redstone_wire replace
setblock ~165 ~141 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~167 ~141 ~654 ~179 ~141 ~654 minecraft:redstone_wire replace
setblock ~178 ~141 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~141 ~662 ~132 ~141 ~662 minecraft:redstone_wire replace
setblock ~134 ~141 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~141 ~662 ~149 ~141 ~662 minecraft:redstone_wire replace
setblock ~151 ~141 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~141 ~662 ~166 ~141 ~662 minecraft:redstone_wire replace
setblock ~168 ~141 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~170 ~141 ~662 ~182 ~141 ~662 minecraft:redstone_wire replace
setblock ~181 ~141 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~142 ~388 minecraft:redstone_wire replace
setblock ~82 ~142 ~400 minecraft:redstone_wire replace
setblock ~88 ~142 ~448 minecraft:redstone_wire replace
setblock ~91 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~142 ~448 minecraft:redstone_wire replace
setblock ~97 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~142 ~448 minecraft:redstone_wire replace
setblock ~103 ~142 ~448 minecraft:redstone_wire replace
setblock ~106 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~142 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~142 ~452 minecraft:redstone_wire replace
setblock ~88 ~142 ~476 minecraft:redstone_wire replace
setblock ~94 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~142 ~476 minecraft:redstone_wire replace
setblock ~100 ~142 ~476 minecraft:redstone_wire replace
setblock ~106 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~142 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~142 ~484 minecraft:redstone_wire replace
setblock ~97 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~142 ~484 minecraft:redstone_wire replace
setblock ~118 ~142 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~142 ~504 minecraft:redstone_wire replace
setblock ~94 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~142 ~504 minecraft:redstone_wire replace
setblock ~115 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~142 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~142 ~516 minecraft:redstone_wire replace
setblock ~127 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~142 ~516 minecraft:redstone_wire replace
setblock ~133 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~142 ~516 minecraft:redstone_wire replace
setblock ~139 ~142 ~516 minecraft:redstone_wire replace
setblock ~142 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~142 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~142 ~540 minecraft:redstone_wire replace
setblock ~130 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~142 ~540 minecraft:redstone_wire replace
setblock ~136 ~142 ~540 minecraft:redstone_wire replace
setblock ~142 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~142 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~142 ~548 minecraft:redstone_wire replace
setblock ~133 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~142 ~548 minecraft:redstone_wire replace
setblock ~151 ~142 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~142 ~568 minecraft:redstone_wire replace
setblock ~130 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~142 ~568 minecraft:redstone_wire replace
setblock ~148 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~142 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~142 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~142 ~580 minecraft:redstone_wire replace
setblock ~163 ~142 ~580 minecraft:redstone_wire replace
setblock ~166 ~142 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~142 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~142 ~612 minecraft:redstone_wire replace
setblock ~166 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~142 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~142 ~624 minecraft:redstone_wire replace
setblock ~160 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~142 ~624 minecraft:redstone_wire replace
setblock ~172 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~142 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~142 ~648 minecraft:redstone_wire replace
setblock ~85 ~142 ~652 minecraft:redstone_wire replace
setblock ~178 ~142 ~656 minecraft:redstone_wire replace
setblock ~181 ~142 ~664 minecraft:redstone_wire replace
fill ~111 ~143 ~384 ~111 ~143 ~388 minecraft:redstone_wire replace
fill ~81 ~143 ~396 ~81 ~143 ~400 minecraft:redstone_wire replace
setblock ~114 ~143 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~418 ~114 ~143 ~424 minecraft:redstone_wire replace
fill ~105 ~143 ~420 ~105 ~143 ~426 minecraft:redstone_wire replace
setblock ~102 ~143 ~424 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~143 ~426 ~102 ~143 ~436 minecraft:redstone_wire replace
setblock ~114 ~143 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~428 minecraft:redstone_wire replace
setblock ~105 ~143 ~428 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~428 ~114 ~143 ~440 minecraft:redstone_wire replace
setblock ~99 ~143 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~143 ~430 ~99 ~143 ~442 minecraft:redstone_wire replace
fill ~105 ~143 ~430 ~105 ~143 ~442 minecraft:redstone_wire replace
fill ~96 ~143 ~432 ~96 ~143 ~436 minecraft:redstone_wire replace
fill ~93 ~143 ~436 ~93 ~143 ~442 minecraft:redstone_wire replace
setblock ~96 ~143 ~438 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~143 ~438 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~143 ~440 minecraft:redstone_wire replace
fill ~96 ~143 ~440 ~96 ~143 ~452 minecraft:redstone_wire replace
fill ~102 ~143 ~440 ~102 ~143 ~452 minecraft:redstone_wire replace
setblock ~90 ~143 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~444 ~90 ~143 ~456 minecraft:redstone_wire replace
setblock ~93 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~444 ~114 ~143 ~456 minecraft:redstone_wire replace
fill ~87 ~143 ~446 ~87 ~143 ~452 minecraft:redstone_wire replace
fill ~93 ~143 ~446 ~93 ~143 ~458 minecraft:redstone_wire replace
fill ~99 ~143 ~446 ~99 ~143 ~458 minecraft:redstone_wire replace
fill ~105 ~143 ~446 ~105 ~143 ~458 minecraft:redstone_wire replace
fill ~78 ~143 ~448 ~78 ~143 ~452 minecraft:redstone_wire replace
setblock ~87 ~143 ~454 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~143 ~454 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~143 ~454 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~143 ~456 ~87 ~143 ~468 minecraft:redstone_wire replace
fill ~96 ~143 ~456 ~96 ~143 ~468 minecraft:redstone_wire replace
fill ~102 ~143 ~456 ~102 ~143 ~468 minecraft:redstone_wire replace
setblock ~90 ~143 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~460 ~90 ~143 ~472 minecraft:redstone_wire replace
setblock ~93 ~143 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~460 ~114 ~143 ~472 minecraft:redstone_wire replace
fill ~93 ~143 ~462 ~93 ~143 ~474 minecraft:redstone_wire replace
fill ~99 ~143 ~462 ~99 ~143 ~474 minecraft:redstone_wire replace
fill ~105 ~143 ~462 ~105 ~143 ~474 minecraft:redstone_wire replace
fill ~120 ~143 ~468 ~120 ~143 ~474 minecraft:redstone_wire replace
setblock ~87 ~143 ~470 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~143 ~470 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~143 ~470 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~143 ~472 ~87 ~143 ~484 minecraft:redstone_wire replace
fill ~96 ~143 ~472 ~96 ~143 ~484 minecraft:redstone_wire replace
fill ~102 ~143 ~472 ~102 ~143 ~484 minecraft:redstone_wire replace
fill ~108 ~143 ~472 ~108 ~143 ~474 minecraft:redstone_wire replace
setblock ~90 ~143 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~476 ~90 ~143 ~488 minecraft:redstone_wire replace
fill ~93 ~143 ~476 ~93 ~143 ~488 minecraft:redstone_wire replace
fill ~99 ~143 ~476 ~99 ~143 ~488 minecraft:redstone_wire replace
fill ~105 ~143 ~476 ~105 ~143 ~488 minecraft:redstone_wire replace
fill ~108 ~143 ~476 ~108 ~143 ~488 minecraft:redstone_wire replace
fill ~114 ~143 ~476 ~114 ~143 ~488 minecraft:redstone_wire replace
fill ~120 ~143 ~476 ~120 ~143 ~488 minecraft:redstone_wire replace
fill ~117 ~143 ~480 ~117 ~143 ~484 minecraft:redstone_wire replace
fill ~147 ~143 ~484 ~147 ~143 ~488 minecraft:redstone_wire replace
fill ~141 ~143 ~488 ~141 ~143 ~490 minecraft:redstone_wire replace
setblock ~90 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~492 ~90 ~143 ~504 minecraft:redstone_wire replace
fill ~93 ~143 ~492 ~93 ~143 ~504 minecraft:redstone_wire replace
fill ~99 ~143 ~492 ~99 ~143 ~504 minecraft:redstone_wire replace
fill ~105 ~143 ~492 ~105 ~143 ~504 minecraft:redstone_wire replace
fill ~108 ~143 ~492 ~108 ~143 ~504 minecraft:redstone_wire replace
fill ~114 ~143 ~492 ~114 ~143 ~504 minecraft:redstone_wire replace
fill ~120 ~143 ~492 ~120 ~143 ~504 minecraft:redstone_wire replace
setblock ~138 ~143 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~143 ~492 ~147 ~143 ~504 minecraft:redstone_wire replace
fill ~138 ~143 ~494 ~138 ~143 ~500 minecraft:redstone_wire replace
fill ~141 ~143 ~494 ~141 ~143 ~506 minecraft:redstone_wire replace
setblock ~135 ~143 ~496 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~143 ~498 ~135 ~143 ~506 minecraft:redstone_wire replace
setblock ~132 ~143 ~500 minecraft:redstone_wire replace
setblock ~132 ~143 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~143 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~143 ~504 ~129 ~143 ~506 minecraft:redstone_wire replace
fill ~132 ~143 ~504 ~132 ~143 ~516 minecraft:redstone_wire replace
fill ~138 ~143 ~504 ~138 ~143 ~516 minecraft:redstone_wire replace
setblock ~147 ~143 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~143 ~508 ~147 ~143 ~520 minecraft:redstone_wire replace
fill ~126 ~143 ~510 ~126 ~143 ~520 minecraft:redstone_wire replace
fill ~129 ~143 ~510 ~129 ~143 ~522 minecraft:redstone_wire replace
fill ~135 ~143 ~510 ~135 ~143 ~522 minecraft:redstone_wire replace
fill ~141 ~143 ~510 ~141 ~143 ~522 minecraft:redstone_wire replace
fill ~123 ~143 ~512 ~123 ~143 ~516 minecraft:redstone_wire replace
setblock ~123 ~143 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~143 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~143 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~143 ~520 ~123 ~143 ~532 minecraft:redstone_wire replace
fill ~132 ~143 ~520 ~132 ~143 ~532 minecraft:redstone_wire replace
fill ~138 ~143 ~520 ~138 ~143 ~532 minecraft:redstone_wire replace
setblock ~126 ~143 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~143 ~524 ~126 ~143 ~536 minecraft:redstone_wire replace
setblock ~129 ~143 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~143 ~524 ~147 ~143 ~536 minecraft:redstone_wire replace
fill ~129 ~143 ~526 ~129 ~143 ~538 minecraft:redstone_wire replace
fill ~135 ~143 ~526 ~135 ~143 ~538 minecraft:redstone_wire replace
fill ~141 ~143 ~526 ~141 ~143 ~538 minecraft:redstone_wire replace
fill ~153 ~143 ~532 ~153 ~143 ~538 minecraft:redstone_wire replace
setblock ~123 ~143 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~143 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~143 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~143 ~536 ~123 ~143 ~548 minecraft:redstone_wire replace
fill ~132 ~143 ~536 ~132 ~143 ~548 minecraft:redstone_wire replace
fill ~138 ~143 ~536 ~138 ~143 ~548 minecraft:redstone_wire replace
fill ~144 ~143 ~536 ~144 ~143 ~538 minecraft:redstone_wire replace
setblock ~126 ~143 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~143 ~540 ~126 ~143 ~552 minecraft:redstone_wire replace
fill ~129 ~143 ~540 ~129 ~143 ~552 minecraft:redstone_wire replace
fill ~135 ~143 ~540 ~135 ~143 ~552 minecraft:redstone_wire replace
fill ~141 ~143 ~540 ~141 ~143 ~552 minecraft:redstone_wire replace
fill ~144 ~143 ~540 ~144 ~143 ~552 minecraft:redstone_wire replace
fill ~147 ~143 ~540 ~147 ~143 ~552 minecraft:redstone_wire replace
fill ~153 ~143 ~540 ~153 ~143 ~552 minecraft:redstone_wire replace
fill ~150 ~143 ~544 ~150 ~143 ~548 minecraft:redstone_wire replace
setblock ~126 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~143 ~556 ~126 ~143 ~568 minecraft:redstone_wire replace
fill ~129 ~143 ~556 ~129 ~143 ~568 minecraft:redstone_wire replace
fill ~135 ~143 ~556 ~135 ~143 ~568 minecraft:redstone_wire replace
fill ~141 ~143 ~556 ~141 ~143 ~568 minecraft:redstone_wire replace
fill ~144 ~143 ~556 ~144 ~143 ~568 minecraft:redstone_wire replace
fill ~147 ~143 ~556 ~147 ~143 ~568 minecraft:redstone_wire replace
fill ~153 ~143 ~556 ~153 ~143 ~568 minecraft:redstone_wire replace
fill ~171 ~143 ~560 ~171 ~143 ~562 minecraft:redstone_wire replace
setblock ~165 ~143 ~564 minecraft:redstone_wire replace
setblock ~171 ~143 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~143 ~566 ~171 ~143 ~578 minecraft:redstone_wire replace
setblock ~162 ~143 ~568 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~143 ~568 ~165 ~143 ~580 minecraft:redstone_wire replace
fill ~162 ~143 ~570 ~162 ~143 ~580 minecraft:redstone_wire replace
setblock ~159 ~143 ~572 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~143 ~574 ~159 ~143 ~580 minecraft:redstone_wire replace
fill ~156 ~143 ~576 ~156 ~143 ~578 minecraft:redstone_wire replace
setblock ~156 ~143 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~143 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~143 ~580 ~156 ~143 ~592 minecraft:redstone_wire replace
fill ~171 ~143 ~580 ~171 ~143 ~592 minecraft:redstone_wire replace
setblock ~159 ~143 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~143 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~143 ~582 ~159 ~143 ~594 minecraft:redstone_wire replace
fill ~162 ~143 ~582 ~162 ~143 ~594 minecraft:redstone_wire replace
fill ~165 ~143 ~582 ~165 ~143 ~594 minecraft:redstone_wire replace
setblock ~156 ~143 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~143 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~143 ~596 ~156 ~143 ~608 minecraft:redstone_wire replace
setblock ~159 ~143 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~143 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~143 ~596 ~171 ~143 ~608 minecraft:redstone_wire replace
fill ~159 ~143 ~598 ~159 ~143 ~610 minecraft:redstone_wire replace
fill ~162 ~143 ~598 ~162 ~143 ~610 minecraft:redstone_wire replace
fill ~165 ~143 ~598 ~165 ~143 ~610 minecraft:redstone_wire replace
fill ~174 ~143 ~604 ~174 ~143 ~610 minecraft:redstone_wire replace
fill ~168 ~143 ~608 ~168 ~143 ~610 minecraft:redstone_wire replace
setblock ~156 ~143 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~143 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~143 ~612 ~156 ~143 ~624 minecraft:redstone_wire replace
fill ~159 ~143 ~612 ~159 ~143 ~624 minecraft:redstone_wire replace
fill ~162 ~143 ~612 ~162 ~143 ~624 minecraft:redstone_wire replace
fill ~165 ~143 ~612 ~165 ~143 ~624 minecraft:redstone_wire replace
fill ~168 ~143 ~612 ~168 ~143 ~624 minecraft:redstone_wire replace
fill ~171 ~143 ~612 ~171 ~143 ~624 minecraft:redstone_wire replace
fill ~174 ~143 ~612 ~174 ~143 ~624 minecraft:redstone_wire replace
fill ~183 ~143 ~644 ~183 ~143 ~648 minecraft:redstone_wire replace
fill ~84 ~143 ~648 ~84 ~143 ~652 minecraft:redstone_wire replace
fill ~177 ~143 ~652 ~177 ~143 ~656 minecraft:redstone_wire replace
fill ~180 ~143 ~660 ~180 ~143 ~664 minecraft:redstone_wire replace
setblock ~111 ~144 ~383 minecraft:redstone_wire replace
setblock ~81 ~144 ~395 minecraft:redstone_wire replace
setblock ~114 ~144 ~415 minecraft:redstone_wire replace
setblock ~105 ~144 ~419 minecraft:redstone_wire replace
setblock ~102 ~144 ~423 minecraft:redstone_wire replace
setblock ~99 ~144 ~427 minecraft:redstone_wire replace
setblock ~96 ~144 ~431 minecraft:redstone_wire replace
setblock ~93 ~144 ~435 minecraft:redstone_wire replace
setblock ~90 ~144 ~439 minecraft:redstone_wire replace
setblock ~87 ~144 ~443 minecraft:redstone_wire replace
setblock ~78 ~144 ~447 minecraft:redstone_wire replace
setblock ~120 ~144 ~467 minecraft:redstone_wire replace
setblock ~108 ~144 ~471 minecraft:redstone_wire replace
setblock ~117 ~144 ~479 minecraft:redstone_wire replace
setblock ~147 ~144 ~483 minecraft:redstone_wire replace
setblock ~141 ~144 ~487 minecraft:redstone_wire replace
setblock ~138 ~144 ~491 minecraft:redstone_wire replace
setblock ~135 ~144 ~495 minecraft:redstone_wire replace
setblock ~132 ~144 ~499 minecraft:redstone_wire replace
setblock ~129 ~144 ~503 minecraft:redstone_wire replace
setblock ~126 ~144 ~507 minecraft:redstone_wire replace
setblock ~123 ~144 ~511 minecraft:redstone_wire replace
setblock ~153 ~144 ~531 minecraft:redstone_wire replace
setblock ~144 ~144 ~535 minecraft:redstone_wire replace
setblock ~150 ~144 ~543 minecraft:redstone_wire replace
setblock ~171 ~144 ~559 minecraft:redstone_wire replace
setblock ~165 ~144 ~563 minecraft:redstone_wire replace
setblock ~162 ~144 ~567 minecraft:redstone_wire replace
setblock ~159 ~144 ~571 minecraft:redstone_wire replace
setblock ~156 ~144 ~575 minecraft:redstone_wire replace
setblock ~174 ~144 ~603 minecraft:redstone_wire replace
setblock ~168 ~144 ~607 minecraft:redstone_wire replace
setblock ~183 ~144 ~643 minecraft:redstone_wire replace
setblock ~84 ~144 ~647 minecraft:redstone_wire replace
setblock ~177 ~144 ~651 minecraft:redstone_wire replace
setblock ~180 ~144 ~659 minecraft:redstone_wire replace
setblock ~97 ~145 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~145 ~382 ~101 ~145 ~382 minecraft:redstone_wire replace
setblock ~103 ~145 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~145 ~382 ~111 ~145 ~382 minecraft:redstone_wire replace
setblock ~82 ~145 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~145 ~394 ~83 ~145 ~394 minecraft:redstone_wire replace
setblock ~100 ~145 ~413 minecraft:redstone_wire replace
fill ~99 ~145 ~414 ~100 ~145 ~414 minecraft:redstone_wire replace
setblock ~101 ~145 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~145 ~414 ~114 ~145 ~414 minecraft:redstone_wire replace
setblock ~94 ~145 ~417 minecraft:redstone_wire replace
fill ~93 ~145 ~418 ~96 ~145 ~418 minecraft:redstone_wire replace
setblock ~98 ~145 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~145 ~418 ~105 ~145 ~418 minecraft:redstone_wire replace
setblock ~94 ~145 ~421 minecraft:redstone_wire replace
fill ~93 ~145 ~422 ~102 ~145 ~422 minecraft:redstone_wire replace
setblock ~91 ~145 ~425 minecraft:redstone_wire replace
fill ~90 ~145 ~426 ~99 ~145 ~426 minecraft:redstone_wire replace
setblock ~91 ~145 ~429 minecraft:redstone_wire replace
fill ~90 ~145 ~430 ~96 ~145 ~430 minecraft:redstone_wire replace
setblock ~88 ~145 ~433 minecraft:redstone_wire replace
setblock ~87 ~145 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~145 ~434 ~93 ~145 ~434 minecraft:redstone_wire replace
setblock ~88 ~145 ~437 minecraft:redstone_wire replace
fill ~87 ~145 ~438 ~90 ~145 ~438 minecraft:redstone_wire replace
setblock ~88 ~145 ~441 minecraft:redstone_wire replace
fill ~87 ~145 ~442 ~89 ~145 ~442 minecraft:redstone_wire replace
setblock ~79 ~145 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~145 ~446 ~80 ~145 ~446 minecraft:redstone_wire replace
setblock ~100 ~145 ~465 minecraft:redstone_wire replace
fill ~99 ~145 ~466 ~111 ~145 ~466 minecraft:redstone_wire replace
setblock ~113 ~145 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~145 ~466 ~120 ~145 ~466 minecraft:redstone_wire replace
setblock ~94 ~145 ~469 minecraft:redstone_wire replace
fill ~93 ~145 ~470 ~95 ~145 ~470 minecraft:redstone_wire replace
setblock ~97 ~145 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~145 ~470 ~108 ~145 ~470 minecraft:redstone_wire replace
setblock ~100 ~145 ~477 minecraft:redstone_wire replace
fill ~99 ~145 ~478 ~107 ~145 ~478 minecraft:redstone_wire replace
setblock ~109 ~145 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~145 ~478 ~117 ~145 ~478 minecraft:redstone_wire replace
setblock ~112 ~145 ~481 minecraft:redstone_wire replace
fill ~111 ~145 ~482 ~119 ~145 ~482 minecraft:redstone_wire replace
setblock ~121 ~145 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~145 ~482 ~136 ~145 ~482 minecraft:redstone_wire replace
setblock ~138 ~145 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~145 ~482 ~147 ~145 ~482 minecraft:redstone_wire replace
setblock ~109 ~145 ~485 minecraft:redstone_wire replace
fill ~108 ~145 ~486 ~111 ~145 ~486 minecraft:redstone_wire replace
setblock ~113 ~145 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~145 ~486 ~128 ~145 ~486 minecraft:redstone_wire replace
setblock ~130 ~145 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~145 ~486 ~141 ~145 ~486 minecraft:redstone_wire replace
setblock ~109 ~145 ~489 minecraft:redstone_wire replace
setblock ~108 ~145 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~145 ~490 ~122 ~145 ~490 minecraft:redstone_wire replace
setblock ~124 ~145 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~145 ~490 ~138 ~145 ~490 minecraft:redstone_wire replace
setblock ~106 ~145 ~493 minecraft:redstone_wire replace
setblock ~105 ~145 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~145 ~494 ~119 ~145 ~494 minecraft:redstone_wire replace
setblock ~121 ~145 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~145 ~494 ~135 ~145 ~494 minecraft:redstone_wire replace
setblock ~106 ~145 ~497 minecraft:redstone_wire replace
fill ~105 ~145 ~498 ~117 ~145 ~498 minecraft:redstone_wire replace
setblock ~119 ~145 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~145 ~498 ~132 ~145 ~498 minecraft:redstone_wire replace
setblock ~103 ~145 ~501 minecraft:redstone_wire replace
setblock ~102 ~145 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~145 ~502 ~116 ~145 ~502 minecraft:redstone_wire replace
setblock ~118 ~145 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~145 ~502 ~129 ~145 ~502 minecraft:redstone_wire replace
setblock ~103 ~145 ~505 minecraft:redstone_wire replace
fill ~102 ~145 ~506 ~110 ~145 ~506 minecraft:redstone_wire replace
setblock ~112 ~145 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~145 ~506 ~126 ~145 ~506 minecraft:redstone_wire replace
setblock ~103 ~145 ~509 minecraft:redstone_wire replace
fill ~102 ~145 ~510 ~113 ~145 ~510 minecraft:redstone_wire replace
setblock ~115 ~145 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~145 ~510 ~123 ~145 ~510 minecraft:redstone_wire replace
setblock ~112 ~145 ~529 minecraft:redstone_wire replace
fill ~111 ~145 ~530 ~112 ~145 ~530 minecraft:redstone_wire replace
setblock ~113 ~145 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~145 ~530 ~127 ~145 ~530 minecraft:redstone_wire replace
setblock ~129 ~145 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~145 ~530 ~144 ~145 ~530 minecraft:redstone_wire replace
setblock ~146 ~145 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~145 ~530 ~153 ~145 ~530 minecraft:redstone_wire replace
setblock ~109 ~145 ~533 minecraft:redstone_wire replace
fill ~108 ~145 ~534 ~114 ~145 ~534 minecraft:redstone_wire replace
setblock ~116 ~145 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~145 ~534 ~131 ~145 ~534 minecraft:redstone_wire replace
setblock ~133 ~145 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~145 ~534 ~144 ~145 ~534 minecraft:redstone_wire replace
setblock ~112 ~145 ~541 minecraft:redstone_wire replace
fill ~111 ~145 ~542 ~123 ~145 ~542 minecraft:redstone_wire replace
setblock ~125 ~145 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~145 ~542 ~140 ~145 ~542 minecraft:redstone_wire replace
setblock ~142 ~145 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~145 ~542 ~150 ~145 ~542 minecraft:redstone_wire replace
setblock ~124 ~145 ~557 minecraft:redstone_wire replace
fill ~123 ~145 ~558 ~124 ~145 ~558 minecraft:redstone_wire replace
setblock ~126 ~145 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~145 ~558 ~141 ~145 ~558 minecraft:redstone_wire replace
setblock ~143 ~145 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~145 ~558 ~158 ~145 ~558 minecraft:redstone_wire replace
setblock ~160 ~145 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~145 ~558 ~171 ~145 ~558 minecraft:redstone_wire replace
setblock ~121 ~145 ~561 minecraft:redstone_wire replace
fill ~120 ~145 ~562 ~133 ~145 ~562 minecraft:redstone_wire replace
setblock ~135 ~145 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~145 ~562 ~150 ~145 ~562 minecraft:redstone_wire replace
setblock ~152 ~145 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~145 ~562 ~165 ~145 ~562 minecraft:redstone_wire replace
setblock ~118 ~145 ~565 minecraft:redstone_wire replace
fill ~117 ~145 ~566 ~129 ~145 ~566 minecraft:redstone_wire replace
setblock ~131 ~145 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~145 ~566 ~146 ~145 ~566 minecraft:redstone_wire replace
setblock ~148 ~145 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~145 ~566 ~162 ~145 ~566 minecraft:redstone_wire replace
setblock ~115 ~145 ~569 minecraft:redstone_wire replace
fill ~114 ~145 ~570 ~126 ~145 ~570 minecraft:redstone_wire replace
setblock ~128 ~145 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~145 ~570 ~143 ~145 ~570 minecraft:redstone_wire replace
setblock ~145 ~145 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~145 ~570 ~159 ~145 ~570 minecraft:redstone_wire replace
setblock ~115 ~145 ~573 minecraft:redstone_wire replace
fill ~114 ~145 ~574 ~126 ~145 ~574 minecraft:redstone_wire replace
setblock ~128 ~145 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~145 ~574 ~143 ~145 ~574 minecraft:redstone_wire replace
setblock ~145 ~145 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~145 ~574 ~156 ~145 ~574 minecraft:redstone_wire replace
setblock ~124 ~145 ~601 minecraft:redstone_wire replace
fill ~123 ~145 ~602 ~131 ~145 ~602 minecraft:redstone_wire replace
setblock ~133 ~145 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~145 ~602 ~148 ~145 ~602 minecraft:redstone_wire replace
setblock ~150 ~145 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~145 ~602 ~165 ~145 ~602 minecraft:redstone_wire replace
setblock ~167 ~145 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~145 ~602 ~174 ~145 ~602 minecraft:redstone_wire replace
setblock ~121 ~145 ~605 minecraft:redstone_wire replace
fill ~120 ~145 ~606 ~121 ~145 ~606 minecraft:redstone_wire replace
setblock ~123 ~145 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~145 ~606 ~138 ~145 ~606 minecraft:redstone_wire replace
setblock ~140 ~145 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~145 ~606 ~155 ~145 ~606 minecraft:redstone_wire replace
setblock ~157 ~145 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~145 ~606 ~168 ~145 ~606 minecraft:redstone_wire replace
setblock ~133 ~145 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~145 ~642 ~139 ~145 ~642 minecraft:redstone_wire replace
setblock ~141 ~145 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~145 ~642 ~156 ~145 ~642 minecraft:redstone_wire replace
setblock ~158 ~145 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~145 ~642 ~173 ~145 ~642 minecraft:redstone_wire replace
setblock ~175 ~145 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~145 ~642 ~183 ~145 ~642 minecraft:redstone_wire replace
setblock ~85 ~145 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~145 ~646 ~86 ~145 ~646 minecraft:redstone_wire replace
setblock ~127 ~145 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~145 ~650 ~133 ~145 ~650 minecraft:redstone_wire replace
setblock ~135 ~145 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~145 ~650 ~150 ~145 ~650 minecraft:redstone_wire replace
setblock ~152 ~145 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~145 ~650 ~167 ~145 ~650 minecraft:redstone_wire replace
setblock ~169 ~145 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~145 ~650 ~177 ~145 ~650 minecraft:redstone_wire replace
setblock ~130 ~145 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~145 ~658 ~136 ~145 ~658 minecraft:redstone_wire replace
setblock ~138 ~145 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~145 ~658 ~153 ~145 ~658 minecraft:redstone_wire replace
setblock ~155 ~145 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~145 ~658 ~170 ~145 ~658 minecraft:redstone_wire replace
setblock ~172 ~145 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~145 ~658 ~180 ~145 ~658 minecraft:redstone_wire replace
setblock ~97 ~146 ~380 minecraft:redstone_wire replace
setblock ~82 ~146 ~392 minecraft:redstone_wire replace
setblock ~100 ~146 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~146 ~416 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~146 ~420 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~146 ~424 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~146 ~428 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~146 ~432 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~146 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~146 ~440 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~146 ~444 minecraft:redstone_wire replace
setblock ~100 ~146 ~464 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~146 ~468 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~146 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~146 ~480 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~146 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~146 ~488 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~146 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~146 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~146 ~500 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~146 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~146 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~146 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~146 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~146 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~146 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~146 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~146 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~146 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~146 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~146 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~146 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~146 ~640 minecraft:redstone_wire replace
setblock ~85 ~146 ~644 minecraft:redstone_wire replace
setblock ~127 ~146 ~648 minecraft:redstone_wire replace
setblock ~130 ~146 ~656 minecraft:redstone_wire replace
fill ~96 ~147 ~380 ~96 ~147 ~384 minecraft:redstone_wire replace
fill ~81 ~147 ~392 ~81 ~147 ~396 minecraft:redstone_wire replace
fill ~99 ~147 ~412 ~99 ~147 ~424 minecraft:redstone_wire replace
fill ~93 ~147 ~416 ~93 ~147 ~428 minecraft:redstone_wire replace
fill ~90 ~147 ~424 ~90 ~147 ~430 minecraft:redstone_wire replace
setblock ~99 ~147 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~428 ~99 ~147 ~440 minecraft:redstone_wire replace
setblock ~93 ~147 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~147 ~432 ~87 ~147 ~442 minecraft:redstone_wire replace
setblock ~90 ~147 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~147 ~432 ~93 ~147 ~444 minecraft:redstone_wire replace
setblock ~99 ~147 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~147 ~444 ~78 ~147 ~448 minecraft:redstone_wire replace
setblock ~87 ~147 ~444 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~444 ~99 ~147 ~456 minecraft:redstone_wire replace
setblock ~93 ~147 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~147 ~448 ~93 ~147 ~460 minecraft:redstone_wire replace
setblock ~99 ~147 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~460 ~99 ~147 ~472 minecraft:redstone_wire replace
setblock ~93 ~147 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~147 ~464 ~93 ~147 ~470 minecraft:redstone_wire replace
setblock ~93 ~147 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~147 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~476 ~99 ~147 ~480 minecraft:redstone_wire replace
fill ~111 ~147 ~480 ~111 ~147 ~492 minecraft:redstone_wire replace
fill ~108 ~147 ~484 ~108 ~147 ~496 minecraft:redstone_wire replace
fill ~105 ~147 ~492 ~105 ~147 ~498 minecraft:redstone_wire replace
setblock ~111 ~147 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~496 ~111 ~147 ~508 minecraft:redstone_wire replace
setblock ~108 ~147 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~147 ~500 ~102 ~147 ~510 minecraft:redstone_wire replace
setblock ~105 ~147 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~147 ~500 ~108 ~147 ~512 minecraft:redstone_wire replace
setblock ~111 ~147 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~147 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~512 ~111 ~147 ~524 minecraft:redstone_wire replace
setblock ~108 ~147 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~147 ~516 ~108 ~147 ~528 minecraft:redstone_wire replace
setblock ~111 ~147 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~528 ~111 ~147 ~540 minecraft:redstone_wire replace
setblock ~108 ~147 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~147 ~532 ~108 ~147 ~536 minecraft:redstone_wire replace
setblock ~111 ~147 ~541 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~542 ~111 ~147 ~544 minecraft:redstone_wire replace
fill ~123 ~147 ~556 ~123 ~147 ~568 minecraft:redstone_wire replace
fill ~120 ~147 ~560 ~120 ~147 ~572 minecraft:redstone_wire replace
fill ~117 ~147 ~564 ~117 ~147 ~568 minecraft:redstone_wire replace
fill ~114 ~147 ~568 ~114 ~147 ~574 minecraft:redstone_wire replace
setblock ~123 ~147 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~147 ~572 ~123 ~147 ~584 minecraft:redstone_wire replace
setblock ~120 ~147 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~147 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~147 ~576 ~120 ~147 ~588 minecraft:redstone_wire replace
setblock ~123 ~147 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~147 ~588 ~123 ~147 ~600 minecraft:redstone_wire replace
setblock ~120 ~147 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~147 ~592 ~120 ~147 ~604 minecraft:redstone_wire replace
setblock ~123 ~147 ~601 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~147 ~602 ~123 ~147 ~604 minecraft:redstone_wire replace
setblock ~120 ~147 ~605 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~147 ~606 ~120 ~147 ~608 minecraft:redstone_wire replace
fill ~132 ~147 ~640 ~132 ~147 ~644 minecraft:redstone_wire replace
fill ~84 ~147 ~644 ~84 ~147 ~648 minecraft:redstone_wire replace
fill ~126 ~147 ~648 ~126 ~147 ~652 minecraft:redstone_wire replace
fill ~129 ~147 ~656 ~129 ~147 ~660 minecraft:redstone_wire replace
setblock ~96 ~148 ~385 minecraft:redstone_wire replace
setblock ~81 ~148 ~397 minecraft:redstone_wire replace
setblock ~90 ~148 ~433 minecraft:redstone_wire replace
setblock ~87 ~148 ~445 minecraft:redstone_wire replace
setblock ~78 ~148 ~449 minecraft:redstone_wire replace
setblock ~93 ~148 ~473 minecraft:redstone_wire replace
setblock ~99 ~148 ~481 minecraft:redstone_wire replace
setblock ~105 ~148 ~501 minecraft:redstone_wire replace
setblock ~102 ~148 ~513 minecraft:redstone_wire replace
setblock ~108 ~148 ~537 minecraft:redstone_wire replace
setblock ~111 ~148 ~545 minecraft:redstone_wire replace
setblock ~117 ~148 ~569 minecraft:redstone_wire replace
setblock ~114 ~148 ~577 minecraft:redstone_wire replace
setblock ~123 ~148 ~605 minecraft:redstone_wire replace
setblock ~120 ~148 ~609 minecraft:redstone_wire replace
setblock ~132 ~148 ~645 minecraft:redstone_wire replace
setblock ~84 ~148 ~649 minecraft:redstone_wire replace
setblock ~126 ~148 ~653 minecraft:redstone_wire replace
setblock ~129 ~148 ~661 minecraft:redstone_wire replace
fill ~96 ~149 ~386 ~102 ~149 ~386 minecraft:redstone_wire replace
setblock ~104 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~149 ~386 ~119 ~149 ~386 minecraft:redstone_wire replace
setblock ~121 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~149 ~386 ~136 ~149 ~386 minecraft:redstone_wire replace
setblock ~138 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~140 ~149 ~386 ~153 ~149 ~386 minecraft:redstone_wire replace
setblock ~155 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~149 ~386 ~170 ~149 ~386 minecraft:redstone_wire replace
setblock ~172 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~149 ~386 ~187 ~149 ~386 minecraft:redstone_wire replace
setblock ~189 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~191 ~149 ~386 ~204 ~149 ~386 minecraft:redstone_wire replace
setblock ~206 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~149 ~386 ~221 ~149 ~386 minecraft:redstone_wire replace
setblock ~223 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~149 ~386 ~233 ~149 ~386 minecraft:redstone_wire replace
setblock ~232 ~149 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~149 ~398 ~83 ~149 ~398 minecraft:redstone_wire replace
setblock ~82 ~149 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~149 ~434 ~101 ~149 ~434 minecraft:redstone_wire replace
setblock ~102 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~149 ~434 ~115 ~149 ~434 minecraft:redstone_wire replace
setblock ~116 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~117 ~149 ~434 ~130 ~149 ~434 minecraft:redstone_wire replace
setblock ~131 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~132 ~149 ~434 ~145 ~149 ~434 minecraft:redstone_wire replace
setblock ~146 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~149 ~434 ~160 ~149 ~434 minecraft:redstone_wire replace
setblock ~161 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~149 ~434 ~175 ~149 ~434 minecraft:redstone_wire replace
setblock ~176 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~149 ~434 ~190 ~149 ~434 minecraft:redstone_wire replace
setblock ~191 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~149 ~434 ~205 ~149 ~434 minecraft:redstone_wire replace
setblock ~206 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~207 ~149 ~434 ~220 ~149 ~434 minecraft:redstone_wire replace
setblock ~221 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~222 ~149 ~434 ~230 ~149 ~434 minecraft:redstone_wire replace
setblock ~85 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~149 ~435 minecraft:redstone_wire replace
setblock ~106 ~149 ~435 minecraft:redstone_wire replace
setblock ~109 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~149 ~435 minecraft:redstone_wire replace
setblock ~130 ~149 ~435 minecraft:redstone_wire replace
setblock ~133 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~149 ~435 minecraft:redstone_wire replace
setblock ~157 ~149 ~435 minecraft:redstone_wire replace
setblock ~160 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~175 ~149 ~435 minecraft:redstone_wire replace
setblock ~178 ~149 ~435 minecraft:redstone_wire replace
setblock ~181 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~190 ~149 ~435 minecraft:redstone_wire replace
setblock ~193 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~202 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~205 ~149 ~435 minecraft:redstone_wire replace
setblock ~208 ~149 ~435 minecraft:redstone_wire replace
setblock ~211 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~217 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~220 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~226 ~149 ~435 minecraft:redstone_wire replace
setblock ~229 ~149 ~435 minecraft:redstone_wire replace
fill ~84 ~149 ~446 ~98 ~149 ~446 minecraft:redstone_wire replace
setblock ~99 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~100 ~149 ~446 ~112 ~149 ~446 minecraft:redstone_wire replace
setblock ~113 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~114 ~149 ~446 ~127 ~149 ~446 minecraft:redstone_wire replace
setblock ~128 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~129 ~149 ~446 ~142 ~149 ~446 minecraft:redstone_wire replace
setblock ~143 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~149 ~446 ~157 ~149 ~446 minecraft:redstone_wire replace
setblock ~158 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~149 ~446 ~172 ~149 ~446 minecraft:redstone_wire replace
setblock ~173 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~149 ~446 ~187 ~149 ~446 minecraft:redstone_wire replace
setblock ~188 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~149 ~446 ~202 ~149 ~446 minecraft:redstone_wire replace
setblock ~203 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~149 ~446 ~217 ~149 ~446 minecraft:redstone_wire replace
setblock ~218 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~219 ~149 ~446 ~230 ~149 ~446 minecraft:redstone_wire replace
setblock ~85 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~447 minecraft:redstone_wire replace
setblock ~91 ~149 ~447 minecraft:redstone_wire replace
setblock ~94 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~149 ~447 minecraft:redstone_wire replace
setblock ~100 ~149 ~447 minecraft:redstone_wire replace
setblock ~103 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~149 ~447 minecraft:redstone_wire replace
setblock ~118 ~149 ~447 minecraft:redstone_wire replace
setblock ~121 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~149 ~447 minecraft:redstone_wire replace
setblock ~127 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~149 ~447 minecraft:redstone_wire replace
setblock ~142 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~149 ~447 minecraft:redstone_wire replace
setblock ~151 ~149 ~447 minecraft:redstone_wire replace
setblock ~154 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~447 minecraft:redstone_wire replace
setblock ~166 ~149 ~447 minecraft:redstone_wire replace
setblock ~169 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~149 ~447 minecraft:redstone_wire replace
setblock ~175 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~447 minecraft:redstone_wire replace
setblock ~187 ~149 ~447 minecraft:redstone_wire replace
setblock ~190 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~202 ~149 ~447 minecraft:redstone_wire replace
setblock ~205 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~208 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~211 ~149 ~447 minecraft:redstone_wire replace
setblock ~214 ~149 ~447 minecraft:redstone_wire replace
setblock ~217 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~220 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~149 ~447 minecraft:redstone_wire replace
setblock ~226 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~149 ~450 ~80 ~149 ~450 minecraft:redstone_wire replace
setblock ~79 ~149 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~149 ~474 ~104 ~149 ~474 minecraft:redstone_wire replace
setblock ~105 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~149 ~474 ~118 ~149 ~474 minecraft:redstone_wire replace
setblock ~119 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~149 ~474 ~133 ~149 ~474 minecraft:redstone_wire replace
setblock ~134 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~474 ~148 ~149 ~474 minecraft:redstone_wire replace
setblock ~149 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~149 ~474 ~163 ~149 ~474 minecraft:redstone_wire replace
setblock ~164 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~149 ~474 ~178 ~149 ~474 minecraft:redstone_wire replace
setblock ~179 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~180 ~149 ~474 ~193 ~149 ~474 minecraft:redstone_wire replace
setblock ~194 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~149 ~474 ~208 ~149 ~474 minecraft:redstone_wire replace
setblock ~209 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~149 ~474 ~223 ~149 ~474 minecraft:redstone_wire replace
setblock ~224 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~149 ~474 ~230 ~149 ~474 minecraft:redstone_wire replace
setblock ~85 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~149 ~475 minecraft:redstone_wire replace
setblock ~97 ~149 ~475 minecraft:redstone_wire replace
setblock ~100 ~149 ~475 minecraft:redstone_wire replace
setblock ~103 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~149 ~475 minecraft:redstone_wire replace
setblock ~124 ~149 ~475 minecraft:redstone_wire replace
setblock ~127 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~149 ~475 minecraft:redstone_wire replace
setblock ~145 ~149 ~475 minecraft:redstone_wire replace
setblock ~148 ~149 ~475 minecraft:redstone_wire replace
setblock ~151 ~149 ~475 minecraft:redstone_wire replace
setblock ~154 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~149 ~475 minecraft:redstone_wire replace
setblock ~172 ~149 ~475 minecraft:redstone_wire replace
setblock ~175 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~149 ~475 minecraft:redstone_wire replace
setblock ~190 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~475 minecraft:redstone_wire replace
setblock ~199 ~149 ~475 minecraft:redstone_wire replace
setblock ~202 ~149 ~475 minecraft:redstone_wire replace
setblock ~205 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~208 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~211 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~217 ~149 ~475 minecraft:redstone_wire replace
setblock ~220 ~149 ~475 minecraft:redstone_wire replace
setblock ~223 ~149 ~475 minecraft:redstone_wire replace
setblock ~226 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~149 ~482 ~105 ~149 ~482 minecraft:redstone_wire replace
setblock ~107 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~149 ~482 ~122 ~149 ~482 minecraft:redstone_wire replace
setblock ~124 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~149 ~482 ~139 ~149 ~482 minecraft:redstone_wire replace
setblock ~141 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~143 ~149 ~482 ~156 ~149 ~482 minecraft:redstone_wire replace
setblock ~158 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~149 ~482 ~173 ~149 ~482 minecraft:redstone_wire replace
setblock ~175 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~149 ~482 ~190 ~149 ~482 minecraft:redstone_wire replace
setblock ~192 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~149 ~482 ~207 ~149 ~482 minecraft:redstone_wire replace
setblock ~209 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~149 ~482 ~224 ~149 ~482 minecraft:redstone_wire replace
setblock ~226 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~149 ~482 ~241 ~149 ~482 minecraft:redstone_wire replace
setblock ~243 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~149 ~482 ~248 ~149 ~482 minecraft:redstone_wire replace
setblock ~235 ~149 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~149 ~502 ~117 ~149 ~502 minecraft:redstone_wire replace
setblock ~119 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~149 ~502 ~134 ~149 ~502 minecraft:redstone_wire replace
setblock ~136 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~138 ~149 ~502 ~151 ~149 ~502 minecraft:redstone_wire replace
setblock ~153 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~155 ~149 ~502 ~168 ~149 ~502 minecraft:redstone_wire replace
setblock ~170 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~149 ~502 ~185 ~149 ~502 minecraft:redstone_wire replace
setblock ~187 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~149 ~502 ~202 ~149 ~502 minecraft:redstone_wire replace
setblock ~204 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~206 ~149 ~502 ~219 ~149 ~502 minecraft:redstone_wire replace
setblock ~221 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~149 ~502 ~236 ~149 ~502 minecraft:redstone_wire replace
setblock ~238 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~149 ~502 ~248 ~149 ~502 minecraft:redstone_wire replace
setblock ~241 ~149 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~149 ~514 ~114 ~149 ~514 minecraft:redstone_wire replace
setblock ~116 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~149 ~514 ~131 ~149 ~514 minecraft:redstone_wire replace
setblock ~133 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~514 ~148 ~149 ~514 minecraft:redstone_wire replace
setblock ~150 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~152 ~149 ~514 ~165 ~149 ~514 minecraft:redstone_wire replace
setblock ~167 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~149 ~514 ~182 ~149 ~514 minecraft:redstone_wire replace
setblock ~184 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~149 ~514 ~199 ~149 ~514 minecraft:redstone_wire replace
setblock ~201 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~203 ~149 ~514 ~216 ~149 ~514 minecraft:redstone_wire replace
setblock ~218 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~149 ~514 ~233 ~149 ~514 minecraft:redstone_wire replace
setblock ~235 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~149 ~514 ~248 ~149 ~514 minecraft:redstone_wire replace
setblock ~238 ~149 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~149 ~538 ~114 ~149 ~538 minecraft:redstone_wire replace
setblock ~116 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~149 ~538 ~131 ~149 ~538 minecraft:redstone_wire replace
setblock ~133 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~538 ~148 ~149 ~538 minecraft:redstone_wire replace
setblock ~150 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~152 ~149 ~538 ~165 ~149 ~538 minecraft:redstone_wire replace
setblock ~167 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~149 ~538 ~182 ~149 ~538 minecraft:redstone_wire replace
setblock ~184 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~149 ~538 ~199 ~149 ~538 minecraft:redstone_wire replace
setblock ~201 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~203 ~149 ~538 ~216 ~149 ~538 minecraft:redstone_wire replace
setblock ~218 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~149 ~538 ~233 ~149 ~538 minecraft:redstone_wire replace
setblock ~235 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~149 ~538 ~248 ~149 ~538 minecraft:redstone_wire replace
setblock ~244 ~149 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~149 ~546 ~120 ~149 ~546 minecraft:redstone_wire replace
setblock ~122 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~149 ~546 ~137 ~149 ~546 minecraft:redstone_wire replace
setblock ~139 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~149 ~546 ~154 ~149 ~546 minecraft:redstone_wire replace
setblock ~156 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~158 ~149 ~546 ~171 ~149 ~546 minecraft:redstone_wire replace
setblock ~173 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~149 ~546 ~188 ~149 ~546 minecraft:redstone_wire replace
setblock ~190 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~149 ~546 ~205 ~149 ~546 minecraft:redstone_wire replace
setblock ~207 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~209 ~149 ~546 ~222 ~149 ~546 minecraft:redstone_wire replace
setblock ~224 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~149 ~546 ~239 ~149 ~546 minecraft:redstone_wire replace
setblock ~241 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~243 ~149 ~546 ~256 ~149 ~546 minecraft:redstone_wire replace
setblock ~257 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~247 ~149 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~250 ~149 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~149 ~570 ~123 ~149 ~570 minecraft:redstone_wire replace
setblock ~125 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~149 ~570 ~140 ~149 ~570 minecraft:redstone_wire replace
setblock ~142 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~149 ~570 ~157 ~149 ~570 minecraft:redstone_wire replace
setblock ~159 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~161 ~149 ~570 ~174 ~149 ~570 minecraft:redstone_wire replace
setblock ~176 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~149 ~570 ~191 ~149 ~570 minecraft:redstone_wire replace
setblock ~193 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~149 ~570 ~208 ~149 ~570 minecraft:redstone_wire replace
setblock ~210 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~149 ~570 ~225 ~149 ~570 minecraft:redstone_wire replace
setblock ~227 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~149 ~570 ~242 ~149 ~570 minecraft:redstone_wire replace
setblock ~244 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~246 ~149 ~570 ~259 ~149 ~570 minecraft:redstone_wire replace
setblock ~260 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~247 ~149 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~259 ~149 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~149 ~578 ~126 ~149 ~578 minecraft:redstone_wire replace
setblock ~128 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~149 ~578 ~143 ~149 ~578 minecraft:redstone_wire replace
setblock ~145 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~149 ~578 ~160 ~149 ~578 minecraft:redstone_wire replace
setblock ~162 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~164 ~149 ~578 ~177 ~149 ~578 minecraft:redstone_wire replace
setblock ~179 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~181 ~149 ~578 ~194 ~149 ~578 minecraft:redstone_wire replace
setblock ~196 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~198 ~149 ~578 ~211 ~149 ~578 minecraft:redstone_wire replace
setblock ~213 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~215 ~149 ~578 ~228 ~149 ~578 minecraft:redstone_wire replace
setblock ~230 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~149 ~578 ~245 ~149 ~578 minecraft:redstone_wire replace
setblock ~246 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~149 ~578 ~257 ~149 ~578 minecraft:redstone_wire replace
setblock ~247 ~149 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~253 ~149 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~149 ~606 ~132 ~149 ~606 minecraft:redstone_wire replace
setblock ~134 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~149 ~606 ~149 ~149 ~606 minecraft:redstone_wire replace
setblock ~151 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~149 ~606 ~166 ~149 ~606 minecraft:redstone_wire replace
setblock ~168 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~170 ~149 ~606 ~183 ~149 ~606 minecraft:redstone_wire replace
setblock ~185 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~149 ~606 ~200 ~149 ~606 minecraft:redstone_wire replace
setblock ~202 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~149 ~606 ~217 ~149 ~606 minecraft:redstone_wire replace
setblock ~219 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~149 ~606 ~234 ~149 ~606 minecraft:redstone_wire replace
setblock ~236 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~149 ~606 ~251 ~149 ~606 minecraft:redstone_wire replace
setblock ~253 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~149 ~606 ~268 ~149 ~606 minecraft:redstone_wire replace
setblock ~269 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~247 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~265 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~268 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~149 ~610 ~129 ~149 ~610 minecraft:redstone_wire replace
setblock ~131 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~149 ~610 ~146 ~149 ~610 minecraft:redstone_wire replace
setblock ~148 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~149 ~610 ~163 ~149 ~610 minecraft:redstone_wire replace
setblock ~165 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~167 ~149 ~610 ~180 ~149 ~610 minecraft:redstone_wire replace
setblock ~182 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~184 ~149 ~610 ~197 ~149 ~610 minecraft:redstone_wire replace
setblock ~199 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~201 ~149 ~610 ~214 ~149 ~610 minecraft:redstone_wire replace
setblock ~216 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~218 ~149 ~610 ~231 ~149 ~610 minecraft:redstone_wire replace
setblock ~233 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~149 ~610 ~248 ~149 ~610 minecraft:redstone_wire replace
setblock ~250 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~149 ~610 ~263 ~149 ~610 minecraft:redstone_wire replace
setblock ~247 ~149 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~262 ~149 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~149 ~646 ~138 ~149 ~646 minecraft:redstone_wire replace
setblock ~140 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~149 ~646 ~155 ~149 ~646 minecraft:redstone_wire replace
setblock ~157 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~149 ~646 ~172 ~149 ~646 minecraft:redstone_wire replace
setblock ~174 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~176 ~149 ~646 ~189 ~149 ~646 minecraft:redstone_wire replace
setblock ~191 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~149 ~646 ~206 ~149 ~646 minecraft:redstone_wire replace
setblock ~208 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~149 ~646 ~223 ~149 ~646 minecraft:redstone_wire replace
setblock ~225 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~227 ~149 ~646 ~240 ~149 ~646 minecraft:redstone_wire replace
setblock ~242 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~149 ~646 ~257 ~149 ~646 minecraft:redstone_wire replace
setblock ~259 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~149 ~646 ~274 ~149 ~646 minecraft:redstone_wire replace
setblock ~275 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~149 ~646 ~278 ~149 ~646 minecraft:redstone_wire replace
setblock ~277 ~149 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~149 ~650 ~89 ~149 ~650 minecraft:redstone_wire replace
setblock ~90 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~91 ~149 ~650 ~103 ~149 ~650 minecraft:redstone_wire replace
setblock ~104 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~105 ~149 ~650 ~118 ~149 ~650 minecraft:redstone_wire replace
setblock ~119 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~149 ~650 ~133 ~149 ~650 minecraft:redstone_wire replace
setblock ~134 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~650 ~148 ~149 ~650 minecraft:redstone_wire replace
setblock ~149 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~149 ~650 ~163 ~149 ~650 minecraft:redstone_wire replace
setblock ~164 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~149 ~650 ~178 ~149 ~650 minecraft:redstone_wire replace
setblock ~179 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~180 ~149 ~650 ~193 ~149 ~650 minecraft:redstone_wire replace
setblock ~194 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~149 ~650 ~208 ~149 ~650 minecraft:redstone_wire replace
setblock ~209 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~149 ~650 ~223 ~149 ~650 minecraft:redstone_wire replace
setblock ~224 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~149 ~650 ~230 ~149 ~650 minecraft:redstone_wire replace
setblock ~85 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~149 ~651 minecraft:redstone_wire replace
setblock ~94 ~149 ~651 minecraft:redstone_wire replace
setblock ~97 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~149 ~651 minecraft:redstone_wire replace
setblock ~103 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~149 ~651 minecraft:redstone_wire replace
setblock ~109 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~651 minecraft:redstone_wire replace
setblock ~115 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~149 ~651 minecraft:redstone_wire replace
setblock ~121 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~149 ~651 minecraft:redstone_wire replace
setblock ~127 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~149 ~651 minecraft:redstone_wire replace
setblock ~133 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~651 minecraft:redstone_wire replace
setblock ~139 ~149 ~651 minecraft:redstone_wire replace
setblock ~142 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~149 ~651 minecraft:redstone_wire replace
setblock ~148 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~149 ~651 minecraft:redstone_wire replace
setblock ~154 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~149 ~651 minecraft:redstone_wire replace
setblock ~160 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~149 ~651 minecraft:redstone_wire replace
setblock ~169 ~149 ~651 minecraft:redstone_wire replace
setblock ~172 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~175 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~149 ~651 minecraft:redstone_wire replace
setblock ~181 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~190 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~149 ~651 minecraft:redstone_wire replace
setblock ~202 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~205 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~208 ~149 ~651 minecraft:redstone_wire replace
setblock ~211 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~149 ~651 minecraft:redstone_wire replace
setblock ~217 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~220 ~149 ~651 minecraft:redstone_wire replace
setblock ~223 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~226 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~149 ~651 minecraft:redstone_wire replace
fill ~126 ~149 ~654 ~132 ~149 ~654 minecraft:redstone_wire replace
setblock ~134 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~149 ~654 ~149 ~149 ~654 minecraft:redstone_wire replace
setblock ~151 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~149 ~654 ~166 ~149 ~654 minecraft:redstone_wire replace
setblock ~168 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~170 ~149 ~654 ~183 ~149 ~654 minecraft:redstone_wire replace
setblock ~185 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~149 ~654 ~200 ~149 ~654 minecraft:redstone_wire replace
setblock ~202 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~149 ~654 ~217 ~149 ~654 minecraft:redstone_wire replace
setblock ~219 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~149 ~654 ~234 ~149 ~654 minecraft:redstone_wire replace
setblock ~236 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~149 ~654 ~251 ~149 ~654 minecraft:redstone_wire replace
setblock ~253 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~149 ~654 ~268 ~149 ~654 minecraft:redstone_wire replace
setblock ~269 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~149 ~654 ~272 ~149 ~654 minecraft:redstone_wire replace
setblock ~271 ~149 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~149 ~662 ~135 ~149 ~662 minecraft:redstone_wire replace
setblock ~137 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~149 ~662 ~152 ~149 ~662 minecraft:redstone_wire replace
setblock ~154 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~149 ~662 ~169 ~149 ~662 minecraft:redstone_wire replace
setblock ~171 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~149 ~662 ~186 ~149 ~662 minecraft:redstone_wire replace
setblock ~188 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~190 ~149 ~662 ~203 ~149 ~662 minecraft:redstone_wire replace
setblock ~205 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~207 ~149 ~662 ~220 ~149 ~662 minecraft:redstone_wire replace
setblock ~222 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~224 ~149 ~662 ~237 ~149 ~662 minecraft:redstone_wire replace
setblock ~239 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~149 ~662 ~254 ~149 ~662 minecraft:redstone_wire replace
setblock ~256 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~258 ~149 ~662 ~271 ~149 ~662 minecraft:redstone_wire replace
setblock ~272 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~149 ~662 ~275 ~149 ~662 minecraft:redstone_wire replace
setblock ~274 ~149 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~232 ~150 ~388 minecraft:redstone_wire replace
setblock ~82 ~150 ~400 minecraft:redstone_wire replace
setblock ~85 ~150 ~436 minecraft:redstone_wire replace
setblock ~88 ~150 ~436 minecraft:redstone_wire replace
setblock ~91 ~150 ~436 minecraft:redstone_wire replace
setblock ~94 ~150 ~436 minecraft:redstone_wire replace
setblock ~97 ~150 ~436 minecraft:redstone_wire replace
setblock ~100 ~150 ~436 minecraft:redstone_wire replace
setblock ~103 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~150 ~436 minecraft:redstone_wire replace
setblock ~112 ~150 ~436 minecraft:redstone_wire replace
setblock ~115 ~150 ~436 minecraft:redstone_wire replace
setblock ~118 ~150 ~436 minecraft:redstone_wire replace
setblock ~121 ~150 ~436 minecraft:redstone_wire replace
setblock ~124 ~150 ~436 minecraft:redstone_wire replace
setblock ~127 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~150 ~436 minecraft:redstone_wire replace
setblock ~136 ~150 ~436 minecraft:redstone_wire replace
setblock ~139 ~150 ~436 minecraft:redstone_wire replace
setblock ~142 ~150 ~436 minecraft:redstone_wire replace
setblock ~145 ~150 ~436 minecraft:redstone_wire replace
setblock ~148 ~150 ~436 minecraft:redstone_wire replace
setblock ~151 ~150 ~436 minecraft:redstone_wire replace
setblock ~154 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~150 ~436 minecraft:redstone_wire replace
setblock ~163 ~150 ~436 minecraft:redstone_wire replace
setblock ~166 ~150 ~436 minecraft:redstone_wire replace
setblock ~169 ~150 ~436 minecraft:redstone_wire replace
setblock ~172 ~150 ~436 minecraft:redstone_wire replace
setblock ~175 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~150 ~436 minecraft:redstone_wire replace
setblock ~184 ~150 ~436 minecraft:redstone_wire replace
setblock ~187 ~150 ~436 minecraft:redstone_wire replace
setblock ~190 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~150 ~436 minecraft:redstone_wire replace
setblock ~196 ~150 ~436 minecraft:redstone_wire replace
setblock ~199 ~150 ~436 minecraft:redstone_wire replace
setblock ~202 ~150 ~436 minecraft:redstone_wire replace
setblock ~205 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~150 ~436 minecraft:redstone_wire replace
setblock ~214 ~150 ~436 minecraft:redstone_wire replace
setblock ~217 ~150 ~436 minecraft:redstone_wire replace
setblock ~220 ~150 ~436 minecraft:redstone_wire replace
setblock ~223 ~150 ~436 minecraft:redstone_wire replace
setblock ~226 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~150 ~448 minecraft:redstone_wire replace
setblock ~88 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~150 ~448 minecraft:redstone_wire replace
setblock ~97 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~150 ~448 minecraft:redstone_wire replace
setblock ~106 ~150 ~448 minecraft:redstone_wire replace
setblock ~109 ~150 ~448 minecraft:redstone_wire replace
setblock ~112 ~150 ~448 minecraft:redstone_wire replace
setblock ~115 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~150 ~448 minecraft:redstone_wire replace
setblock ~124 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~150 ~448 minecraft:redstone_wire replace
setblock ~130 ~150 ~448 minecraft:redstone_wire replace
setblock ~133 ~150 ~448 minecraft:redstone_wire replace
setblock ~136 ~150 ~448 minecraft:redstone_wire replace
setblock ~139 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~150 ~448 minecraft:redstone_wire replace
setblock ~145 ~150 ~448 minecraft:redstone_wire replace
setblock ~148 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~150 ~448 minecraft:redstone_wire replace
setblock ~157 ~150 ~448 minecraft:redstone_wire replace
setblock ~160 ~150 ~448 minecraft:redstone_wire replace
setblock ~163 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~150 ~448 minecraft:redstone_wire replace
setblock ~172 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~150 ~448 minecraft:redstone_wire replace
setblock ~178 ~150 ~448 minecraft:redstone_wire replace
setblock ~181 ~150 ~448 minecraft:redstone_wire replace
setblock ~184 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~150 ~448 minecraft:redstone_wire replace
setblock ~193 ~150 ~448 minecraft:redstone_wire replace
setblock ~196 ~150 ~448 minecraft:redstone_wire replace
setblock ~199 ~150 ~448 minecraft:redstone_wire replace
setblock ~202 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~150 ~448 minecraft:redstone_wire replace
setblock ~208 ~150 ~448 minecraft:redstone_wire replace
setblock ~211 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~150 ~448 minecraft:redstone_wire replace
setblock ~220 ~150 ~448 minecraft:redstone_wire replace
setblock ~223 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~150 ~448 minecraft:redstone_wire replace
setblock ~229 ~150 ~448 minecraft:redstone_wire replace
setblock ~79 ~150 ~452 minecraft:redstone_wire replace
setblock ~85 ~150 ~476 minecraft:redstone_wire replace
setblock ~88 ~150 ~476 minecraft:redstone_wire replace
setblock ~91 ~150 ~476 minecraft:redstone_wire replace
setblock ~94 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~150 ~476 minecraft:redstone_wire replace
setblock ~106 ~150 ~476 minecraft:redstone_wire replace
setblock ~109 ~150 ~476 minecraft:redstone_wire replace
setblock ~112 ~150 ~476 minecraft:redstone_wire replace
setblock ~115 ~150 ~476 minecraft:redstone_wire replace
setblock ~118 ~150 ~476 minecraft:redstone_wire replace
setblock ~121 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~150 ~476 minecraft:redstone_wire replace
setblock ~130 ~150 ~476 minecraft:redstone_wire replace
setblock ~133 ~150 ~476 minecraft:redstone_wire replace
setblock ~136 ~150 ~476 minecraft:redstone_wire replace
setblock ~139 ~150 ~476 minecraft:redstone_wire replace
setblock ~142 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~150 ~476 minecraft:redstone_wire replace
setblock ~157 ~150 ~476 minecraft:redstone_wire replace
setblock ~160 ~150 ~476 minecraft:redstone_wire replace
setblock ~163 ~150 ~476 minecraft:redstone_wire replace
setblock ~166 ~150 ~476 minecraft:redstone_wire replace
setblock ~169 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~150 ~476 minecraft:redstone_wire replace
setblock ~178 ~150 ~476 minecraft:redstone_wire replace
setblock ~181 ~150 ~476 minecraft:redstone_wire replace
setblock ~184 ~150 ~476 minecraft:redstone_wire replace
setblock ~187 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~150 ~476 minecraft:redstone_wire replace
setblock ~193 ~150 ~476 minecraft:redstone_wire replace
setblock ~196 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~150 ~476 minecraft:redstone_wire replace
setblock ~208 ~150 ~476 minecraft:redstone_wire replace
setblock ~211 ~150 ~476 minecraft:redstone_wire replace
setblock ~214 ~150 ~476 minecraft:redstone_wire replace
setblock ~217 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~150 ~476 minecraft:redstone_wire replace
setblock ~229 ~150 ~476 minecraft:redstone_wire replace
setblock ~235 ~150 ~484 minecraft:redstone_wire replace
setblock ~247 ~150 ~484 minecraft:redstone_wire replace
setblock ~241 ~150 ~504 minecraft:redstone_wire replace
setblock ~247 ~150 ~504 minecraft:redstone_wire replace
setblock ~238 ~150 ~516 minecraft:redstone_wire replace
setblock ~247 ~150 ~516 minecraft:redstone_wire replace
setblock ~244 ~150 ~540 minecraft:redstone_wire replace
setblock ~247 ~150 ~540 minecraft:redstone_wire replace
setblock ~247 ~150 ~548 minecraft:redstone_wire replace
setblock ~250 ~150 ~548 minecraft:redstone_wire replace
setblock ~256 ~150 ~548 minecraft:redstone_wire replace
setblock ~247 ~150 ~572 minecraft:redstone_wire replace
setblock ~256 ~150 ~572 minecraft:redstone_wire replace
setblock ~259 ~150 ~572 minecraft:redstone_wire replace
setblock ~247 ~150 ~580 minecraft:redstone_wire replace
setblock ~253 ~150 ~580 minecraft:redstone_wire replace
setblock ~256 ~150 ~580 minecraft:redstone_wire replace
setblock ~247 ~150 ~608 minecraft:redstone_wire replace
setblock ~256 ~150 ~608 minecraft:redstone_wire replace
setblock ~265 ~150 ~608 minecraft:redstone_wire replace
setblock ~268 ~150 ~608 minecraft:redstone_wire replace
setblock ~247 ~150 ~612 minecraft:redstone_wire replace
setblock ~256 ~150 ~612 minecraft:redstone_wire replace
setblock ~262 ~150 ~612 minecraft:redstone_wire replace
setblock ~277 ~150 ~648 minecraft:redstone_wire replace
setblock ~85 ~150 ~652 minecraft:redstone_wire replace
setblock ~88 ~150 ~652 minecraft:redstone_wire replace
setblock ~91 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~150 ~652 minecraft:redstone_wire replace
setblock ~100 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~150 ~652 minecraft:redstone_wire replace
setblock ~106 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~150 ~652 minecraft:redstone_wire replace
setblock ~112 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~150 ~652 minecraft:redstone_wire replace
setblock ~118 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~150 ~652 minecraft:redstone_wire replace
setblock ~124 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~150 ~652 minecraft:redstone_wire replace
setblock ~130 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~150 ~652 minecraft:redstone_wire replace
setblock ~136 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~150 ~652 minecraft:redstone_wire replace
setblock ~145 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~150 ~652 minecraft:redstone_wire replace
setblock ~151 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~150 ~652 minecraft:redstone_wire replace
setblock ~157 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~150 ~652 minecraft:redstone_wire replace
setblock ~163 ~150 ~652 minecraft:redstone_wire replace
setblock ~166 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~150 ~652 minecraft:redstone_wire replace
setblock ~175 ~150 ~652 minecraft:redstone_wire replace
setblock ~178 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~150 ~652 minecraft:redstone_wire replace
setblock ~184 ~150 ~652 minecraft:redstone_wire replace
setblock ~187 ~150 ~652 minecraft:redstone_wire replace
setblock ~190 ~150 ~652 minecraft:redstone_wire replace
setblock ~193 ~150 ~652 minecraft:redstone_wire replace
setblock ~196 ~150 ~652 minecraft:redstone_wire replace
setblock ~199 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~150 ~652 minecraft:redstone_wire replace
setblock ~205 ~150 ~652 minecraft:redstone_wire replace
setblock ~208 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~150 ~652 minecraft:redstone_wire replace
setblock ~214 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~150 ~652 minecraft:redstone_wire replace
setblock ~220 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~150 ~652 minecraft:redstone_wire replace
setblock ~226 ~150 ~652 minecraft:redstone_wire replace
setblock ~229 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~150 ~656 minecraft:redstone_wire replace
setblock ~274 ~150 ~664 minecraft:redstone_wire replace
setblock ~231 ~151 ~232 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~151 ~234 ~231 ~151 ~244 minecraft:redstone_wire replace
fill ~81 ~151 ~236 ~81 ~151 ~240 minecraft:redstone_wire replace
setblock ~228 ~151 ~240 minecraft:redstone_wire replace
setblock ~228 ~151 ~241 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~242 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~151 ~242 ~228 ~151 ~254 minecraft:redstone_wire replace
fill ~81 ~151 ~244 ~81 ~151 ~256 minecraft:redstone_wire replace
setblock ~225 ~151 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~225 ~151 ~246 ~225 ~151 ~254 minecraft:redstone_wire replace
setblock ~231 ~151 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~222 ~151 ~248 ~222 ~151 ~254 minecraft:redstone_wire replace
fill ~231 ~151 ~248 ~231 ~151 ~260 minecraft:redstone_wire replace
fill ~219 ~151 ~252 ~219 ~151 ~254 minecraft:redstone_wire replace
setblock ~216 ~151 ~256 minecraft:redstone_wire replace
setblock ~219 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~151 ~258 ~216 ~151 ~270 minecraft:redstone_wire replace
fill ~219 ~151 ~258 ~219 ~151 ~270 minecraft:redstone_wire replace
fill ~222 ~151 ~258 ~222 ~151 ~270 minecraft:redstone_wire replace
fill ~225 ~151 ~258 ~225 ~151 ~270 minecraft:redstone_wire replace
fill ~228 ~151 ~258 ~228 ~151 ~270 minecraft:redstone_wire replace
fill ~81 ~151 ~260 ~81 ~151 ~272 minecraft:redstone_wire replace
setblock ~213 ~151 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~213 ~151 ~262 ~213 ~151 ~270 minecraft:redstone_wire replace
setblock ~231 ~151 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~151 ~264 ~210 ~151 ~270 minecraft:redstone_wire replace
fill ~231 ~151 ~264 ~231 ~151 ~276 minecraft:redstone_wire replace
fill ~207 ~151 ~268 ~207 ~151 ~270 minecraft:redstone_wire replace
setblock ~204 ~151 ~272 minecraft:redstone_wire replace
setblock ~207 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~274 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~151 ~274 ~204 ~151 ~286 minecraft:redstone_wire replace
fill ~207 ~151 ~274 ~207 ~151 ~286 minecraft:redstone_wire replace
fill ~210 ~151 ~274 ~210 ~151 ~286 minecraft:redstone_wire replace
fill ~213 ~151 ~274 ~213 ~151 ~286 minecraft:redstone_wire replace
fill ~216 ~151 ~274 ~216 ~151 ~286 minecraft:redstone_wire replace
fill ~219 ~151 ~274 ~219 ~151 ~286 minecraft:redstone_wire replace
fill ~222 ~151 ~274 ~222 ~151 ~286 minecraft:redstone_wire replace
fill ~225 ~151 ~274 ~225 ~151 ~286 minecraft:redstone_wire replace
fill ~228 ~151 ~274 ~228 ~151 ~286 minecraft:redstone_wire replace
fill ~81 ~151 ~276 ~81 ~151 ~288 minecraft:redstone_wire replace
setblock ~201 ~151 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~151 ~278 ~201 ~151 ~286 minecraft:redstone_wire replace
setblock ~231 ~151 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~151 ~280 ~198 ~151 ~286 minecraft:redstone_wire replace
fill ~231 ~151 ~280 ~231 ~151 ~292 minecraft:redstone_wire replace
fill ~195 ~151 ~284 ~195 ~151 ~286 minecraft:redstone_wire replace
setblock ~192 ~151 ~288 minecraft:redstone_wire replace
setblock ~195 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~289 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~290 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~151 ~290 ~192 ~151 ~302 minecraft:redstone_wire replace
fill ~195 ~151 ~290 ~195 ~151 ~302 minecraft:redstone_wire replace
fill ~198 ~151 ~290 ~198 ~151 ~302 minecraft:redstone_wire replace
fill ~201 ~151 ~290 ~201 ~151 ~302 minecraft:redstone_wire replace
fill ~204 ~151 ~290 ~204 ~151 ~302 minecraft:redstone_wire replace
fill ~207 ~151 ~290 ~207 ~151 ~302 minecraft:redstone_wire replace
fill ~210 ~151 ~290 ~210 ~151 ~302 minecraft:redstone_wire replace
fill ~213 ~151 ~290 ~213 ~151 ~302 minecraft:redstone_wire replace
fill ~216 ~151 ~290 ~216 ~151 ~302 minecraft:redstone_wire replace
fill ~219 ~151 ~290 ~219 ~151 ~302 minecraft:redstone_wire replace
fill ~222 ~151 ~290 ~222 ~151 ~302 minecraft:redstone_wire replace
fill ~225 ~151 ~290 ~225 ~151 ~302 minecraft:redstone_wire replace
fill ~228 ~151 ~290 ~228 ~151 ~302 minecraft:redstone_wire replace
fill ~81 ~151 ~292 ~81 ~151 ~304 minecraft:redstone_wire replace
setblock ~189 ~151 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
