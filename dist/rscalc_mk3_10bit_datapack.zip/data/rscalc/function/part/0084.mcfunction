fill ~162 ~65 ~598 ~168 ~65 ~598 minecraft:redstone_wire replace
setblock ~118 ~65 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~65 ~602 ~131 ~65 ~602 minecraft:redstone_wire replace
setblock ~133 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~65 ~602 ~148 ~65 ~602 minecraft:redstone_wire replace
setblock ~150 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~65 ~602 ~165 ~65 ~602 minecraft:redstone_wire replace
setblock ~167 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~65 ~602 ~182 ~65 ~602 minecraft:redstone_wire replace
setblock ~184 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~65 ~602 ~192 ~65 ~602 minecraft:redstone_wire replace
setblock ~85 ~65 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~65 ~606 ~86 ~65 ~606 minecraft:redstone_wire replace
setblock ~88 ~65 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~65 ~610 ~89 ~65 ~610 minecraft:redstone_wire replace
setblock ~91 ~65 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~65 ~614 ~92 ~65 ~614 minecraft:redstone_wire replace
setblock ~94 ~65 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~65 ~618 ~95 ~65 ~618 minecraft:redstone_wire replace
setblock ~97 ~65 ~621 minecraft:redstone_wire replace
fill ~96 ~65 ~622 ~98 ~65 ~622 minecraft:redstone_wire replace
setblock ~100 ~65 ~625 minecraft:redstone_wire replace
fill ~99 ~65 ~626 ~107 ~65 ~626 minecraft:redstone_wire replace
setblock ~109 ~65 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~65 ~626 ~117 ~65 ~626 minecraft:redstone_wire replace
setblock ~103 ~65 ~629 minecraft:redstone_wire replace
fill ~102 ~65 ~630 ~103 ~65 ~630 minecraft:redstone_wire replace
setblock ~105 ~65 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~65 ~630 ~120 ~65 ~630 minecraft:redstone_wire replace
setblock ~122 ~65 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~65 ~630 ~137 ~65 ~630 minecraft:redstone_wire replace
setblock ~139 ~65 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~65 ~630 ~147 ~65 ~630 minecraft:redstone_wire replace
setblock ~106 ~65 ~633 minecraft:redstone_wire replace
fill ~105 ~65 ~634 ~115 ~65 ~634 minecraft:redstone_wire replace
setblock ~117 ~65 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~65 ~634 ~132 ~65 ~634 minecraft:redstone_wire replace
setblock ~134 ~65 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~65 ~634 ~149 ~65 ~634 minecraft:redstone_wire replace
setblock ~151 ~65 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~65 ~634 ~159 ~65 ~634 minecraft:redstone_wire replace
setblock ~109 ~65 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~65 ~638 ~119 ~65 ~638 minecraft:redstone_wire replace
setblock ~121 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~638 ~136 ~65 ~638 minecraft:redstone_wire replace
setblock ~138 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~65 ~638 ~153 ~65 ~638 minecraft:redstone_wire replace
setblock ~155 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~65 ~638 ~170 ~65 ~638 minecraft:redstone_wire replace
setblock ~172 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~65 ~638 ~180 ~65 ~638 minecraft:redstone_wire replace
setblock ~124 ~65 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~65 ~642 ~137 ~65 ~642 minecraft:redstone_wire replace
setblock ~139 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~65 ~642 ~154 ~65 ~642 minecraft:redstone_wire replace
setblock ~156 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~65 ~642 ~171 ~65 ~642 minecraft:redstone_wire replace
setblock ~173 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~65 ~642 ~188 ~65 ~642 minecraft:redstone_wire replace
setblock ~190 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~65 ~642 ~198 ~65 ~642 minecraft:redstone_wire replace
setblock ~139 ~65 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~65 ~646 ~140 ~65 ~646 minecraft:redstone_wire replace
setblock ~141 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~65 ~646 ~155 ~65 ~646 minecraft:redstone_wire replace
setblock ~157 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~65 ~646 ~172 ~65 ~646 minecraft:redstone_wire replace
setblock ~174 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~65 ~646 ~189 ~65 ~646 minecraft:redstone_wire replace
setblock ~191 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~65 ~646 ~206 ~65 ~646 minecraft:redstone_wire replace
setblock ~208 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~65 ~646 ~216 ~65 ~646 minecraft:redstone_wire replace
setblock ~79 ~65 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~65 ~650 ~80 ~65 ~650 minecraft:redstone_wire replace
setblock ~112 ~65 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~65 ~654 ~122 ~65 ~654 minecraft:redstone_wire replace
setblock ~124 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~65 ~654 ~139 ~65 ~654 minecraft:redstone_wire replace
setblock ~141 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~65 ~654 ~156 ~65 ~654 minecraft:redstone_wire replace
setblock ~158 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~65 ~654 ~173 ~65 ~654 minecraft:redstone_wire replace
setblock ~175 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~65 ~654 ~183 ~65 ~654 minecraft:redstone_wire replace
setblock ~136 ~65 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~65 ~658 ~137 ~65 ~658 minecraft:redstone_wire replace
setblock ~138 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~65 ~658 ~152 ~65 ~658 minecraft:redstone_wire replace
setblock ~154 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~65 ~658 ~169 ~65 ~658 minecraft:redstone_wire replace
setblock ~171 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~65 ~658 ~186 ~65 ~658 minecraft:redstone_wire replace
setblock ~188 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~65 ~658 ~203 ~65 ~658 minecraft:redstone_wire replace
setblock ~205 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~65 ~658 ~213 ~65 ~658 minecraft:redstone_wire replace
setblock ~97 ~66 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~66 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~66 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~66 ~384 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~66 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~66 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~66 ~428 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~432 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~440 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~66 ~464 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~468 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~66 ~480 minecraft:redstone_wire replace
setblock ~97 ~66 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~512 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~66 ~520 minecraft:redstone_wire replace
setblock ~97 ~66 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~66 ~560 minecraft:redstone_wire replace
setblock ~97 ~66 ~584 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~66 ~600 minecraft:redstone_wire replace
setblock ~85 ~66 ~604 minecraft:redstone_wire replace
setblock ~88 ~66 ~608 minecraft:redstone_wire replace
setblock ~91 ~66 ~612 minecraft:redstone_wire replace
setblock ~94 ~66 ~616 minecraft:redstone_wire replace
setblock ~97 ~66 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~66 ~636 minecraft:redstone_wire replace
setblock ~124 ~66 ~640 minecraft:redstone_wire replace
setblock ~139 ~66 ~644 minecraft:redstone_wire replace
setblock ~79 ~66 ~648 minecraft:redstone_wire replace
setblock ~112 ~66 ~652 minecraft:redstone_wire replace
setblock ~136 ~66 ~656 minecraft:redstone_wire replace
fill ~96 ~67 ~324 ~96 ~67 ~336 minecraft:redstone_wire replace
setblock ~96 ~67 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~340 ~96 ~67 ~352 minecraft:redstone_wire replace
fill ~99 ~67 ~340 ~99 ~67 ~352 minecraft:redstone_wire replace
setblock ~96 ~67 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~356 ~96 ~67 ~368 minecraft:redstone_wire replace
fill ~99 ~67 ~356 ~99 ~67 ~368 minecraft:redstone_wire replace
fill ~105 ~67 ~356 ~105 ~67 ~368 minecraft:redstone_wire replace
setblock ~96 ~67 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~372 ~96 ~67 ~384 minecraft:redstone_wire replace
fill ~99 ~67 ~372 ~99 ~67 ~384 minecraft:redstone_wire replace
fill ~102 ~67 ~372 ~102 ~67 ~384 minecraft:redstone_wire replace
fill ~105 ~67 ~372 ~105 ~67 ~384 minecraft:redstone_wire replace
fill ~132 ~67 ~376 ~132 ~67 ~382 minecraft:redstone_wire replace
fill ~114 ~67 ~384 ~114 ~67 ~390 minecraft:redstone_wire replace
setblock ~132 ~67 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~388 ~96 ~67 ~400 minecraft:redstone_wire replace
fill ~99 ~67 ~388 ~99 ~67 ~400 minecraft:redstone_wire replace
fill ~102 ~67 ~388 ~102 ~67 ~400 minecraft:redstone_wire replace
fill ~105 ~67 ~388 ~105 ~67 ~400 minecraft:redstone_wire replace
fill ~81 ~67 ~392 ~81 ~67 ~396 minecraft:redstone_wire replace
setblock ~114 ~67 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~404 ~96 ~67 ~416 minecraft:redstone_wire replace
fill ~99 ~67 ~404 ~99 ~67 ~416 minecraft:redstone_wire replace
fill ~102 ~67 ~404 ~102 ~67 ~416 minecraft:redstone_wire replace
fill ~105 ~67 ~404 ~105 ~67 ~416 minecraft:redstone_wire replace
setblock ~96 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~420 ~96 ~67 ~432 minecraft:redstone_wire replace
fill ~99 ~67 ~420 ~99 ~67 ~432 minecraft:redstone_wire replace
fill ~102 ~67 ~420 ~102 ~67 ~432 minecraft:redstone_wire replace
fill ~105 ~67 ~420 ~105 ~67 ~432 minecraft:redstone_wire replace
setblock ~99 ~67 ~433 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~434 ~99 ~67 ~446 minecraft:redstone_wire replace
setblock ~102 ~67 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~436 ~96 ~67 ~448 minecraft:redstone_wire replace
fill ~102 ~67 ~436 ~102 ~67 ~448 minecraft:redstone_wire replace
fill ~105 ~67 ~436 ~105 ~67 ~448 minecraft:redstone_wire replace
setblock ~99 ~67 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~450 ~99 ~67 ~462 minecraft:redstone_wire replace
setblock ~102 ~67 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~452 ~96 ~67 ~464 minecraft:redstone_wire replace
fill ~102 ~67 ~452 ~102 ~67 ~464 minecraft:redstone_wire replace
fill ~105 ~67 ~452 ~105 ~67 ~464 minecraft:redstone_wire replace
setblock ~99 ~67 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~465 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~466 ~96 ~67 ~478 minecraft:redstone_wire replace
fill ~99 ~67 ~466 ~99 ~67 ~478 minecraft:redstone_wire replace
setblock ~102 ~67 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~468 ~102 ~67 ~480 minecraft:redstone_wire replace
fill ~105 ~67 ~468 ~105 ~67 ~480 minecraft:redstone_wire replace
setblock ~96 ~67 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~67 ~480 ~129 ~67 ~484 minecraft:redstone_wire replace
fill ~96 ~67 ~482 ~96 ~67 ~494 minecraft:redstone_wire replace
fill ~99 ~67 ~482 ~99 ~67 ~494 minecraft:redstone_wire replace
setblock ~102 ~67 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~484 ~102 ~67 ~496 minecraft:redstone_wire replace
fill ~105 ~67 ~484 ~105 ~67 ~496 minecraft:redstone_wire replace
setblock ~96 ~67 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~498 ~96 ~67 ~510 minecraft:redstone_wire replace
fill ~99 ~67 ~498 ~99 ~67 ~510 minecraft:redstone_wire replace
setblock ~102 ~67 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~500 ~102 ~67 ~512 minecraft:redstone_wire replace
fill ~105 ~67 ~500 ~105 ~67 ~512 minecraft:redstone_wire replace
setblock ~96 ~67 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~513 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~514 ~96 ~67 ~526 minecraft:redstone_wire replace
fill ~99 ~67 ~514 ~99 ~67 ~526 minecraft:redstone_wire replace
fill ~102 ~67 ~514 ~102 ~67 ~526 minecraft:redstone_wire replace
setblock ~105 ~67 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~516 ~105 ~67 ~528 minecraft:redstone_wire replace
fill ~126 ~67 ~520 ~126 ~67 ~524 minecraft:redstone_wire replace
setblock ~96 ~67 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~530 ~96 ~67 ~542 minecraft:redstone_wire replace
fill ~99 ~67 ~530 ~99 ~67 ~542 minecraft:redstone_wire replace
fill ~102 ~67 ~530 ~102 ~67 ~542 minecraft:redstone_wire replace
setblock ~105 ~67 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~532 ~105 ~67 ~544 minecraft:redstone_wire replace
setblock ~96 ~67 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~544 ~96 ~67 ~556 minecraft:redstone_wire replace
setblock ~99 ~67 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~546 ~99 ~67 ~558 minecraft:redstone_wire replace
fill ~102 ~67 ~546 ~102 ~67 ~558 minecraft:redstone_wire replace
setblock ~105 ~67 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~548 ~105 ~67 ~560 minecraft:redstone_wire replace
setblock ~96 ~67 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~560 ~96 ~67 ~572 minecraft:redstone_wire replace
setblock ~99 ~67 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~67 ~560 ~120 ~67 ~564 minecraft:redstone_wire replace
fill ~99 ~67 ~562 ~99 ~67 ~574 minecraft:redstone_wire replace
fill ~102 ~67 ~562 ~102 ~67 ~574 minecraft:redstone_wire replace
setblock ~105 ~67 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~564 ~105 ~67 ~576 minecraft:redstone_wire replace
setblock ~96 ~67 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~576 ~96 ~67 ~588 minecraft:redstone_wire replace
setblock ~99 ~67 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~578 ~99 ~67 ~590 minecraft:redstone_wire replace
fill ~102 ~67 ~578 ~102 ~67 ~590 minecraft:redstone_wire replace
setblock ~105 ~67 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~580 ~105 ~67 ~592 minecraft:redstone_wire replace
setblock ~96 ~67 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~592 ~96 ~67 ~604 minecraft:redstone_wire replace
setblock ~99 ~67 ~592 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~592 ~102 ~67 ~604 minecraft:redstone_wire replace
fill ~99 ~67 ~594 ~99 ~67 ~606 minecraft:redstone_wire replace
setblock ~105 ~67 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~596 ~105 ~67 ~608 minecraft:redstone_wire replace
fill ~117 ~67 ~600 ~117 ~67 ~604 minecraft:redstone_wire replace
fill ~84 ~67 ~604 ~84 ~67 ~608 minecraft:redstone_wire replace
setblock ~96 ~67 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~67 ~608 ~87 ~67 ~612 minecraft:redstone_wire replace
fill ~96 ~67 ~608 ~96 ~67 ~620 minecraft:redstone_wire replace
setblock ~99 ~67 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~608 ~102 ~67 ~620 minecraft:redstone_wire replace
fill ~99 ~67 ~610 ~99 ~67 ~622 minecraft:redstone_wire replace
setblock ~105 ~67 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~67 ~612 ~90 ~67 ~616 minecraft:redstone_wire replace
fill ~105 ~67 ~612 ~105 ~67 ~624 minecraft:redstone_wire replace
fill ~93 ~67 ~616 ~93 ~67 ~620 minecraft:redstone_wire replace
setblock ~96 ~67 ~621 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~622 ~96 ~67 ~624 minecraft:redstone_wire replace
setblock ~102 ~67 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~624 ~99 ~67 ~628 minecraft:redstone_wire replace
fill ~102 ~67 ~624 ~102 ~67 ~630 minecraft:redstone_wire replace
setblock ~105 ~67 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~628 ~105 ~67 ~634 minecraft:redstone_wire replace
setblock ~102 ~67 ~632 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~636 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~67 ~636 ~108 ~67 ~640 minecraft:redstone_wire replace
fill ~123 ~67 ~640 ~123 ~67 ~644 minecraft:redstone_wire replace
fill ~138 ~67 ~644 ~138 ~67 ~648 minecraft:redstone_wire replace
fill ~78 ~67 ~648 ~78 ~67 ~652 minecraft:redstone_wire replace
fill ~111 ~67 ~652 ~111 ~67 ~656 minecraft:redstone_wire replace
fill ~135 ~67 ~656 ~135 ~67 ~660 minecraft:redstone_wire replace
setblock ~132 ~68 ~385 minecraft:redstone_wire replace
setblock ~114 ~68 ~393 minecraft:redstone_wire replace
setblock ~81 ~68 ~397 minecraft:redstone_wire replace
setblock ~129 ~68 ~485 minecraft:redstone_wire replace
setblock ~126 ~68 ~525 minecraft:redstone_wire replace
setblock ~120 ~68 ~565 minecraft:redstone_wire replace
setblock ~117 ~68 ~605 minecraft:redstone_wire replace
setblock ~84 ~68 ~609 minecraft:redstone_wire replace
setblock ~87 ~68 ~613 minecraft:redstone_wire replace
setblock ~90 ~68 ~617 minecraft:redstone_wire replace
setblock ~93 ~68 ~621 minecraft:redstone_wire replace
setblock ~96 ~68 ~625 minecraft:redstone_wire replace
setblock ~99 ~68 ~629 minecraft:redstone_wire replace
setblock ~102 ~68 ~633 minecraft:redstone_wire replace
setblock ~105 ~68 ~637 minecraft:redstone_wire replace
setblock ~108 ~68 ~641 minecraft:redstone_wire replace
setblock ~123 ~68 ~645 minecraft:redstone_wire replace
setblock ~138 ~68 ~649 minecraft:redstone_wire replace
setblock ~78 ~68 ~653 minecraft:redstone_wire replace
setblock ~111 ~68 ~657 minecraft:redstone_wire replace
setblock ~135 ~68 ~661 minecraft:redstone_wire replace
fill ~132 ~69 ~386 ~134 ~69 ~386 minecraft:redstone_wire replace
setblock ~133 ~69 ~387 minecraft:redstone_wire replace
fill ~114 ~69 ~394 ~116 ~69 ~394 minecraft:redstone_wire replace
setblock ~115 ~69 ~395 minecraft:redstone_wire replace
fill ~81 ~69 ~398 ~86 ~69 ~398 minecraft:redstone_wire replace
setblock ~85 ~69 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~69 ~486 ~129 ~69 ~486 minecraft:redstone_wire replace
setblock ~127 ~69 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~69 ~526 ~126 ~69 ~526 minecraft:redstone_wire replace
setblock ~124 ~69 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~69 ~566 ~122 ~69 ~566 minecraft:redstone_wire replace
setblock ~121 ~69 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~69 ~606 ~119 ~69 ~606 minecraft:redstone_wire replace
setblock ~118 ~69 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~69 ~610 ~89 ~69 ~610 minecraft:redstone_wire replace
setblock ~88 ~69 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~69 ~614 ~92 ~69 ~614 minecraft:redstone_wire replace
setblock ~91 ~69 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~69 ~618 ~95 ~69 ~618 minecraft:redstone_wire replace
setblock ~94 ~69 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~69 ~622 ~98 ~69 ~622 minecraft:redstone_wire replace
setblock ~97 ~69 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~69 ~626 ~101 ~69 ~626 minecraft:redstone_wire replace
setblock ~100 ~69 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~69 ~630 ~104 ~69 ~630 minecraft:redstone_wire replace
setblock ~103 ~69 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~69 ~634 ~86 ~69 ~634 minecraft:redstone_wire replace
setblock ~88 ~69 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~69 ~634 ~114 ~69 ~634 minecraft:redstone_wire replace
setblock ~116 ~69 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~69 ~634 ~131 ~69 ~634 minecraft:redstone_wire replace
setblock ~79 ~69 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~69 ~635 minecraft:redstone_wire replace
fill ~105 ~69 ~638 ~107 ~69 ~638 minecraft:redstone_wire replace
setblock ~106 ~69 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~69 ~642 ~110 ~69 ~642 minecraft:redstone_wire replace
setblock ~109 ~69 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~69 ~646 ~115 ~69 ~646 minecraft:redstone_wire replace
setblock ~116 ~69 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~69 ~646 ~129 ~69 ~646 minecraft:redstone_wire replace
setblock ~131 ~69 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~69 ~646 ~134 ~69 ~646 minecraft:redstone_wire replace
setblock ~115 ~69 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~69 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~69 ~650 ~140 ~69 ~650 minecraft:redstone_wire replace
setblock ~139 ~69 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~69 ~654 ~83 ~69 ~654 minecraft:redstone_wire replace
setblock ~82 ~69 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~69 ~658 ~113 ~69 ~658 minecraft:redstone_wire replace
setblock ~112 ~69 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~69 ~662 ~137 ~69 ~662 minecraft:redstone_wire replace
setblock ~136 ~69 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~70 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~70 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~70 ~400 minecraft:redstone_wire replace
setblock ~127 ~70 ~488 minecraft:redstone_wire replace
setblock ~124 ~70 ~528 minecraft:redstone_wire replace
setblock ~121 ~70 ~568 minecraft:redstone_wire replace
setblock ~118 ~70 ~608 minecraft:redstone_wire replace
setblock ~88 ~70 ~612 minecraft:redstone_wire replace
setblock ~91 ~70 ~616 minecraft:redstone_wire replace
setblock ~94 ~70 ~620 minecraft:redstone_wire replace
setblock ~97 ~70 ~624 minecraft:redstone_wire replace
setblock ~100 ~70 ~628 minecraft:redstone_wire replace
setblock ~103 ~70 ~632 minecraft:redstone_wire replace
setblock ~79 ~70 ~636 minecraft:redstone_wire replace
setblock ~130 ~70 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~70 ~640 minecraft:redstone_wire replace
setblock ~109 ~70 ~644 minecraft:redstone_wire replace
setblock ~115 ~70 ~648 minecraft:redstone_wire replace
setblock ~133 ~70 ~648 minecraft:redstone_wire replace
setblock ~139 ~70 ~652 minecraft:redstone_wire replace
setblock ~82 ~70 ~656 minecraft:redstone_wire replace
setblock ~112 ~70 ~660 minecraft:redstone_wire replace
setblock ~136 ~70 ~664 minecraft:redstone_wire replace
setblock ~132 ~71 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~71 ~386 ~132 ~71 ~392 minecraft:redstone_wire replace
fill ~114 ~71 ~392 ~114 ~71 ~394 minecraft:redstone_wire replace
setblock ~132 ~71 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~71 ~395 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~71 ~396 ~84 ~71 ~400 minecraft:redstone_wire replace
fill ~114 ~71 ~396 ~114 ~71 ~408 minecraft:redstone_wire replace
fill ~132 ~71 ~396 ~132 ~71 ~408 minecraft:redstone_wire replace
setblock ~114 ~71 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~412 ~114 ~71 ~424 minecraft:redstone_wire replace
fill ~132 ~71 ~412 ~132 ~71 ~424 minecraft:redstone_wire replace
setblock ~114 ~71 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~428 ~114 ~71 ~440 minecraft:redstone_wire replace
fill ~132 ~71 ~428 ~132 ~71 ~440 minecraft:redstone_wire replace
setblock ~114 ~71 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~444 ~114 ~71 ~456 minecraft:redstone_wire replace
fill ~132 ~71 ~444 ~132 ~71 ~456 minecraft:redstone_wire replace
setblock ~114 ~71 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~460 ~114 ~71 ~472 minecraft:redstone_wire replace
fill ~132 ~71 ~460 ~132 ~71 ~472 minecraft:redstone_wire replace
setblock ~114 ~71 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~476 ~114 ~71 ~488 minecraft:redstone_wire replace
fill ~132 ~71 ~476 ~132 ~71 ~488 minecraft:redstone_wire replace
fill ~126 ~71 ~484 ~126 ~71 ~488 minecraft:redstone_wire replace
setblock ~114 ~71 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~492 ~114 ~71 ~504 minecraft:redstone_wire replace
fill ~132 ~71 ~492 ~132 ~71 ~504 minecraft:redstone_wire replace
setblock ~114 ~71 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~508 ~114 ~71 ~520 minecraft:redstone_wire replace
fill ~132 ~71 ~508 ~132 ~71 ~520 minecraft:redstone_wire replace
setblock ~114 ~71 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~524 ~114 ~71 ~536 minecraft:redstone_wire replace
fill ~123 ~71 ~524 ~123 ~71 ~528 minecraft:redstone_wire replace
fill ~132 ~71 ~524 ~132 ~71 ~536 minecraft:redstone_wire replace
setblock ~114 ~71 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~540 ~114 ~71 ~552 minecraft:redstone_wire replace
fill ~132 ~71 ~540 ~132 ~71 ~552 minecraft:redstone_wire replace
setblock ~114 ~71 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~556 ~114 ~71 ~568 minecraft:redstone_wire replace
fill ~132 ~71 ~556 ~132 ~71 ~568 minecraft:redstone_wire replace
fill ~120 ~71 ~564 ~120 ~71 ~568 minecraft:redstone_wire replace
setblock ~114 ~71 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~572 ~114 ~71 ~584 minecraft:redstone_wire replace
fill ~132 ~71 ~572 ~132 ~71 ~584 minecraft:redstone_wire replace
setblock ~114 ~71 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~588 ~114 ~71 ~600 minecraft:redstone_wire replace
fill ~132 ~71 ~588 ~132 ~71 ~600 minecraft:redstone_wire replace
setblock ~117 ~71 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~71 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~71 ~602 ~117 ~71 ~608 minecraft:redstone_wire replace
setblock ~132 ~71 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~71 ~604 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~604 ~114 ~71 ~616 minecraft:redstone_wire replace
fill ~132 ~71 ~604 ~132 ~71 ~616 minecraft:redstone_wire replace
fill ~87 ~71 ~606 ~87 ~71 ~612 minecraft:redstone_wire replace
setblock ~90 ~71 ~608 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~71 ~610 ~90 ~71 ~616 minecraft:redstone_wire replace
setblock ~93 ~71 ~612 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~71 ~614 ~93 ~71 ~620 minecraft:redstone_wire replace
setblock ~96 ~71 ~616 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~71 ~618 ~96 ~71 ~624 minecraft:redstone_wire replace
setblock ~114 ~71 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~71 ~620 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~620 ~114 ~71 ~632 minecraft:redstone_wire replace
fill ~132 ~71 ~620 ~132 ~71 ~632 minecraft:redstone_wire replace
fill ~99 ~71 ~622 ~99 ~71 ~628 minecraft:redstone_wire replace
setblock ~102 ~71 ~624 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~71 ~626 ~102 ~71 ~632 minecraft:redstone_wire replace
setblock ~129 ~71 ~628 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~71 ~630 ~129 ~71 ~636 minecraft:redstone_wire replace
fill ~78 ~71 ~632 ~78 ~71 ~636 minecraft:redstone_wire replace
setblock ~114 ~71 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~71 ~636 ~105 ~71 ~640 minecraft:redstone_wire replace
fill ~114 ~71 ~636 ~114 ~71 ~648 minecraft:redstone_wire replace
fill ~132 ~71 ~636 ~132 ~71 ~648 minecraft:redstone_wire replace
fill ~108 ~71 ~640 ~108 ~71 ~644 minecraft:redstone_wire replace
fill ~138 ~71 ~648 ~138 ~71 ~652 minecraft:redstone_wire replace
fill ~81 ~71 ~652 ~81 ~71 ~656 minecraft:redstone_wire replace
fill ~111 ~71 ~656 ~111 ~71 ~660 minecraft:redstone_wire replace
fill ~135 ~71 ~660 ~135 ~71 ~664 minecraft:redstone_wire replace
setblock ~132 ~72 ~383 minecraft:redstone_wire replace
setblock ~114 ~72 ~391 minecraft:redstone_wire replace
setblock ~84 ~72 ~395 minecraft:redstone_wire replace
setblock ~126 ~72 ~483 minecraft:redstone_wire replace
setblock ~123 ~72 ~523 minecraft:redstone_wire replace
setblock ~120 ~72 ~563 minecraft:redstone_wire replace
setblock ~117 ~72 ~599 minecraft:redstone_wire replace
setblock ~87 ~72 ~603 minecraft:redstone_wire replace
setblock ~90 ~72 ~607 minecraft:redstone_wire replace
setblock ~93 ~72 ~611 minecraft:redstone_wire replace
setblock ~96 ~72 ~615 minecraft:redstone_wire replace
setblock ~99 ~72 ~619 minecraft:redstone_wire replace
setblock ~102 ~72 ~623 minecraft:redstone_wire replace
setblock ~129 ~72 ~627 minecraft:redstone_wire replace
setblock ~78 ~72 ~631 minecraft:redstone_wire replace
setblock ~105 ~72 ~635 minecraft:redstone_wire replace
setblock ~108 ~72 ~639 minecraft:redstone_wire replace
setblock ~138 ~72 ~647 minecraft:redstone_wire replace
setblock ~81 ~72 ~651 minecraft:redstone_wire replace
setblock ~111 ~72 ~655 minecraft:redstone_wire replace
setblock ~135 ~72 ~659 minecraft:redstone_wire replace
setblock ~115 ~73 ~381 minecraft:redstone_wire replace
fill ~114 ~73 ~382 ~116 ~73 ~382 minecraft:redstone_wire replace
setblock ~118 ~73 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~73 ~382 ~132 ~73 ~382 minecraft:redstone_wire replace
setblock ~109 ~73 ~389 minecraft:redstone_wire replace
fill ~108 ~73 ~390 ~114 ~73 ~390 minecraft:redstone_wire replace
setblock ~85 ~73 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~73 ~394 ~86 ~73 ~394 minecraft:redstone_wire replace
setblock ~109 ~73 ~481 minecraft:redstone_wire replace
fill ~108 ~73 ~482 ~116 ~73 ~482 minecraft:redstone_wire replace
setblock ~118 ~73 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~73 ~482 ~126 ~73 ~482 minecraft:redstone_wire replace
setblock ~109 ~73 ~521 minecraft:redstone_wire replace
fill ~108 ~73 ~522 ~113 ~73 ~522 minecraft:redstone_wire replace
setblock ~115 ~73 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~73 ~522 ~123 ~73 ~522 minecraft:redstone_wire replace
setblock ~109 ~73 ~561 minecraft:redstone_wire replace
fill ~108 ~73 ~562 ~110 ~73 ~562 minecraft:redstone_wire replace
setblock ~112 ~73 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~73 ~562 ~120 ~73 ~562 minecraft:redstone_wire replace
setblock ~109 ~73 ~597 minecraft:redstone_wire replace
fill ~108 ~73 ~598 ~117 ~73 ~598 minecraft:redstone_wire replace
setblock ~88 ~73 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~73 ~602 ~89 ~73 ~602 minecraft:redstone_wire replace
setblock ~91 ~73 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~73 ~606 ~92 ~73 ~606 minecraft:redstone_wire replace
setblock ~94 ~73 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~73 ~610 ~95 ~73 ~610 minecraft:redstone_wire replace
setblock ~97 ~73 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~73 ~614 ~98 ~73 ~614 minecraft:redstone_wire replace
setblock ~100 ~73 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~73 ~618 ~101 ~73 ~618 minecraft:redstone_wire replace
setblock ~103 ~73 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~73 ~622 ~104 ~73 ~622 minecraft:redstone_wire replace
setblock ~112 ~73 ~625 minecraft:redstone_wire replace
fill ~111 ~73 ~626 ~113 ~73 ~626 minecraft:redstone_wire replace
setblock ~115 ~73 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~73 ~626 ~129 ~73 ~626 minecraft:redstone_wire replace
setblock ~79 ~73 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~73 ~630 ~80 ~73 ~630 minecraft:redstone_wire replace
setblock ~106 ~73 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~73 ~634 ~107 ~73 ~634 minecraft:redstone_wire replace
setblock ~109 ~73 ~637 minecraft:redstone_wire replace
fill ~108 ~73 ~638 ~110 ~73 ~638 minecraft:redstone_wire replace
setblock ~121 ~73 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~73 ~646 ~128 ~73 ~646 minecraft:redstone_wire replace
setblock ~130 ~73 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~73 ~646 ~138 ~73 ~646 minecraft:redstone_wire replace
setblock ~82 ~73 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~73 ~650 ~83 ~73 ~650 minecraft:redstone_wire replace
setblock ~109 ~73 ~653 minecraft:redstone_wire replace
fill ~108 ~73 ~654 ~111 ~73 ~654 minecraft:redstone_wire replace
setblock ~118 ~73 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~73 ~658 ~125 ~73 ~658 minecraft:redstone_wire replace
setblock ~127 ~73 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~73 ~658 ~135 ~73 ~658 minecraft:redstone_wire replace
setblock ~115 ~74 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~74 ~392 minecraft:redstone_wire replace
setblock ~109 ~74 ~480 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~520 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~74 ~600 minecraft:redstone_wire replace
setblock ~91 ~74 ~604 minecraft:redstone_wire replace
setblock ~94 ~74 ~608 minecraft:redstone_wire replace
setblock ~97 ~74 ~612 minecraft:redstone_wire replace
setblock ~100 ~74 ~616 minecraft:redstone_wire replace
setblock ~103 ~74 ~620 minecraft:redstone_wire replace
setblock ~112 ~74 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~74 ~628 minecraft:redstone_wire replace
setblock ~106 ~74 ~632 minecraft:redstone_wire replace
setblock ~109 ~74 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~74 ~644 minecraft:redstone_wire replace
setblock ~82 ~74 ~648 minecraft:redstone_wire replace
setblock ~109 ~74 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~74 ~656 minecraft:redstone_wire replace
fill ~114 ~75 ~380 ~114 ~75 ~384 minecraft:redstone_wire replace
