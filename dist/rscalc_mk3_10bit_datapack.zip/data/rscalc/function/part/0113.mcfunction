setblock ~480 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~30 ~446 ~169 ~40 minecraft:redstone_wire replace
fill ~452 ~169 ~30 ~452 ~169 ~40 minecraft:redstone_wire replace
fill ~454 ~169 ~30 ~454 ~169 ~40 minecraft:redstone_wire replace
fill ~464 ~169 ~30 ~464 ~169 ~40 minecraft:redstone_wire replace
fill ~466 ~169 ~30 ~466 ~169 ~40 minecraft:redstone_wire replace
fill ~468 ~169 ~30 ~468 ~169 ~40 minecraft:redstone_wire replace
fill ~478 ~169 ~30 ~478 ~169 ~40 minecraft:redstone_wire replace
fill ~480 ~169 ~30 ~480 ~169 ~40 minecraft:redstone_wire replace
fill ~488 ~169 ~30 ~488 ~169 ~40 minecraft:redstone_wire replace
fill ~490 ~169 ~30 ~490 ~169 ~40 minecraft:redstone_wire replace
fill ~498 ~169 ~30 ~498 ~169 ~40 minecraft:redstone_wire replace
setblock ~440 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~34 ~440 ~169 ~44 minecraft:redstone_wire replace
fill ~444 ~169 ~34 ~444 ~169 ~44 minecraft:redstone_wire replace
fill ~448 ~169 ~34 ~448 ~169 ~44 minecraft:redstone_wire replace
fill ~458 ~169 ~34 ~458 ~169 ~44 minecraft:redstone_wire replace
fill ~460 ~169 ~34 ~460 ~169 ~44 minecraft:redstone_wire replace
fill ~472 ~169 ~34 ~472 ~169 ~44 minecraft:redstone_wire replace
fill ~474 ~169 ~34 ~474 ~169 ~44 minecraft:redstone_wire replace
fill ~482 ~169 ~34 ~482 ~169 ~44 minecraft:redstone_wire replace
fill ~484 ~169 ~34 ~484 ~169 ~44 minecraft:redstone_wire replace
fill ~494 ~169 ~34 ~494 ~169 ~44 minecraft:redstone_wire replace
setblock ~442 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~38 ~442 ~169 ~48 minecraft:redstone_wire replace
fill ~450 ~169 ~38 ~450 ~169 ~48 minecraft:redstone_wire replace
fill ~456 ~169 ~38 ~456 ~169 ~48 minecraft:redstone_wire replace
fill ~462 ~169 ~38 ~462 ~169 ~48 minecraft:redstone_wire replace
fill ~470 ~169 ~38 ~470 ~169 ~48 minecraft:redstone_wire replace
fill ~476 ~169 ~38 ~476 ~169 ~48 minecraft:redstone_wire replace
fill ~486 ~169 ~38 ~486 ~169 ~48 minecraft:redstone_wire replace
fill ~492 ~169 ~38 ~492 ~169 ~48 minecraft:redstone_wire replace
fill ~496 ~169 ~38 ~496 ~169 ~48 minecraft:redstone_wire replace
fill ~500 ~169 ~38 ~500 ~169 ~48 minecraft:redstone_wire replace
fill ~502 ~169 ~38 ~502 ~169 ~48 minecraft:redstone_wire replace
setblock ~446 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~42 ~446 ~169 ~52 minecraft:redstone_wire replace
fill ~452 ~169 ~42 ~452 ~169 ~52 minecraft:redstone_wire replace
fill ~454 ~169 ~42 ~454 ~169 ~52 minecraft:redstone_wire replace
fill ~464 ~169 ~42 ~464 ~169 ~52 minecraft:redstone_wire replace
fill ~466 ~169 ~42 ~466 ~169 ~52 minecraft:redstone_wire replace
fill ~468 ~169 ~42 ~468 ~169 ~52 minecraft:redstone_wire replace
fill ~478 ~169 ~42 ~478 ~169 ~52 minecraft:redstone_wire replace
fill ~480 ~169 ~42 ~480 ~169 ~52 minecraft:redstone_wire replace
fill ~488 ~169 ~42 ~488 ~169 ~52 minecraft:redstone_wire replace
fill ~490 ~169 ~42 ~490 ~169 ~52 minecraft:redstone_wire replace
fill ~498 ~169 ~42 ~498 ~169 ~52 minecraft:redstone_wire replace
setblock ~440 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~46 ~440 ~169 ~56 minecraft:redstone_wire replace
fill ~444 ~169 ~46 ~444 ~169 ~56 minecraft:redstone_wire replace
fill ~448 ~169 ~46 ~448 ~169 ~56 minecraft:redstone_wire replace
fill ~458 ~169 ~46 ~458 ~169 ~56 minecraft:redstone_wire replace
fill ~460 ~169 ~46 ~460 ~169 ~56 minecraft:redstone_wire replace
fill ~472 ~169 ~46 ~472 ~169 ~56 minecraft:redstone_wire replace
fill ~474 ~169 ~46 ~474 ~169 ~56 minecraft:redstone_wire replace
fill ~482 ~169 ~46 ~482 ~169 ~56 minecraft:redstone_wire replace
fill ~484 ~169 ~46 ~484 ~169 ~56 minecraft:redstone_wire replace
fill ~494 ~169 ~46 ~494 ~169 ~56 minecraft:redstone_wire replace
setblock ~442 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~50 ~442 ~169 ~60 minecraft:redstone_wire replace
fill ~450 ~169 ~50 ~450 ~169 ~60 minecraft:redstone_wire replace
fill ~456 ~169 ~50 ~456 ~169 ~60 minecraft:redstone_wire replace
fill ~462 ~169 ~50 ~462 ~169 ~60 minecraft:redstone_wire replace
fill ~470 ~169 ~50 ~470 ~169 ~60 minecraft:redstone_wire replace
fill ~476 ~169 ~50 ~476 ~169 ~60 minecraft:redstone_wire replace
fill ~486 ~169 ~50 ~486 ~169 ~60 minecraft:redstone_wire replace
fill ~492 ~169 ~50 ~492 ~169 ~60 minecraft:redstone_wire replace
fill ~496 ~169 ~50 ~496 ~169 ~60 minecraft:redstone_wire replace
fill ~500 ~169 ~50 ~500 ~169 ~60 minecraft:redstone_wire replace
fill ~502 ~169 ~50 ~502 ~169 ~60 minecraft:redstone_wire replace
setblock ~446 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~54 ~446 ~169 ~64 minecraft:redstone_wire replace
fill ~452 ~169 ~54 ~452 ~169 ~64 minecraft:redstone_wire replace
fill ~454 ~169 ~54 ~454 ~169 ~64 minecraft:redstone_wire replace
fill ~464 ~169 ~54 ~464 ~169 ~64 minecraft:redstone_wire replace
fill ~466 ~169 ~54 ~466 ~169 ~64 minecraft:redstone_wire replace
fill ~468 ~169 ~54 ~468 ~169 ~64 minecraft:redstone_wire replace
fill ~478 ~169 ~54 ~478 ~169 ~64 minecraft:redstone_wire replace
fill ~480 ~169 ~54 ~480 ~169 ~64 minecraft:redstone_wire replace
fill ~488 ~169 ~54 ~488 ~169 ~64 minecraft:redstone_wire replace
fill ~490 ~169 ~54 ~490 ~169 ~64 minecraft:redstone_wire replace
fill ~498 ~169 ~54 ~498 ~169 ~64 minecraft:redstone_wire replace
setblock ~440 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~58 ~440 ~169 ~68 minecraft:redstone_wire replace
fill ~444 ~169 ~58 ~444 ~169 ~68 minecraft:redstone_wire replace
fill ~448 ~169 ~58 ~448 ~169 ~68 minecraft:redstone_wire replace
fill ~458 ~169 ~58 ~458 ~169 ~68 minecraft:redstone_wire replace
fill ~460 ~169 ~58 ~460 ~169 ~68 minecraft:redstone_wire replace
fill ~472 ~169 ~58 ~472 ~169 ~68 minecraft:redstone_wire replace
fill ~474 ~169 ~58 ~474 ~169 ~68 minecraft:redstone_wire replace
fill ~482 ~169 ~58 ~482 ~169 ~68 minecraft:redstone_wire replace
fill ~484 ~169 ~58 ~484 ~169 ~68 minecraft:redstone_wire replace
fill ~494 ~169 ~58 ~494 ~169 ~68 minecraft:redstone_wire replace
setblock ~442 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~62 ~442 ~169 ~72 minecraft:redstone_wire replace
fill ~450 ~169 ~62 ~450 ~169 ~72 minecraft:redstone_wire replace
fill ~456 ~169 ~62 ~456 ~169 ~72 minecraft:redstone_wire replace
fill ~462 ~169 ~62 ~462 ~169 ~72 minecraft:redstone_wire replace
fill ~470 ~169 ~62 ~470 ~169 ~72 minecraft:redstone_wire replace
fill ~476 ~169 ~62 ~476 ~169 ~72 minecraft:redstone_wire replace
fill ~486 ~169 ~62 ~486 ~169 ~72 minecraft:redstone_wire replace
fill ~492 ~169 ~62 ~492 ~169 ~72 minecraft:redstone_wire replace
fill ~496 ~169 ~62 ~496 ~169 ~72 minecraft:redstone_wire replace
fill ~500 ~169 ~62 ~500 ~169 ~72 minecraft:redstone_wire replace
fill ~502 ~169 ~62 ~502 ~169 ~72 minecraft:redstone_wire replace
setblock ~446 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~66 ~446 ~169 ~76 minecraft:redstone_wire replace
fill ~452 ~169 ~66 ~452 ~169 ~76 minecraft:redstone_wire replace
fill ~454 ~169 ~66 ~454 ~169 ~76 minecraft:redstone_wire replace
fill ~464 ~169 ~66 ~464 ~169 ~76 minecraft:redstone_wire replace
fill ~466 ~169 ~66 ~466 ~169 ~76 minecraft:redstone_wire replace
fill ~468 ~169 ~66 ~468 ~169 ~76 minecraft:redstone_wire replace
fill ~478 ~169 ~66 ~478 ~169 ~76 minecraft:redstone_wire replace
fill ~480 ~169 ~66 ~480 ~169 ~76 minecraft:redstone_wire replace
fill ~488 ~169 ~66 ~488 ~169 ~76 minecraft:redstone_wire replace
fill ~490 ~169 ~66 ~490 ~169 ~76 minecraft:redstone_wire replace
fill ~498 ~169 ~66 ~498 ~169 ~76 minecraft:redstone_wire replace
setblock ~440 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~70 ~440 ~169 ~80 minecraft:redstone_wire replace
fill ~444 ~169 ~70 ~444 ~169 ~80 minecraft:redstone_wire replace
fill ~448 ~169 ~70 ~448 ~169 ~80 minecraft:redstone_wire replace
fill ~458 ~169 ~70 ~458 ~169 ~80 minecraft:redstone_wire replace
fill ~460 ~169 ~70 ~460 ~169 ~80 minecraft:redstone_wire replace
fill ~472 ~169 ~70 ~472 ~169 ~80 minecraft:redstone_wire replace
fill ~474 ~169 ~70 ~474 ~169 ~80 minecraft:redstone_wire replace
fill ~482 ~169 ~70 ~482 ~169 ~80 minecraft:redstone_wire replace
fill ~484 ~169 ~70 ~484 ~169 ~80 minecraft:redstone_wire replace
fill ~494 ~169 ~70 ~494 ~169 ~80 minecraft:redstone_wire replace
setblock ~442 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~74 ~442 ~169 ~84 minecraft:redstone_wire replace
fill ~450 ~169 ~74 ~450 ~169 ~84 minecraft:redstone_wire replace
fill ~456 ~169 ~74 ~456 ~169 ~84 minecraft:redstone_wire replace
fill ~462 ~169 ~74 ~462 ~169 ~84 minecraft:redstone_wire replace
fill ~470 ~169 ~74 ~470 ~169 ~84 minecraft:redstone_wire replace
fill ~476 ~169 ~74 ~476 ~169 ~84 minecraft:redstone_wire replace
fill ~486 ~169 ~74 ~486 ~169 ~84 minecraft:redstone_wire replace
fill ~492 ~169 ~74 ~492 ~169 ~84 minecraft:redstone_wire replace
fill ~496 ~169 ~74 ~496 ~169 ~84 minecraft:redstone_wire replace
fill ~500 ~169 ~74 ~500 ~169 ~84 minecraft:redstone_wire replace
fill ~502 ~169 ~74 ~502 ~169 ~84 minecraft:redstone_wire replace
setblock ~446 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~78 ~446 ~169 ~88 minecraft:redstone_wire replace
fill ~452 ~169 ~78 ~452 ~169 ~88 minecraft:redstone_wire replace
fill ~454 ~169 ~78 ~454 ~169 ~88 minecraft:redstone_wire replace
fill ~464 ~169 ~78 ~464 ~169 ~88 minecraft:redstone_wire replace
fill ~466 ~169 ~78 ~466 ~169 ~88 minecraft:redstone_wire replace
fill ~468 ~169 ~78 ~468 ~169 ~88 minecraft:redstone_wire replace
fill ~478 ~169 ~78 ~478 ~169 ~88 minecraft:redstone_wire replace
fill ~480 ~169 ~78 ~480 ~169 ~88 minecraft:redstone_wire replace
fill ~488 ~169 ~78 ~488 ~169 ~88 minecraft:redstone_wire replace
fill ~490 ~169 ~78 ~490 ~169 ~88 minecraft:redstone_wire replace
fill ~498 ~169 ~78 ~498 ~169 ~88 minecraft:redstone_wire replace
setblock ~440 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~82 ~440 ~169 ~92 minecraft:redstone_wire replace
fill ~444 ~169 ~82 ~444 ~169 ~92 minecraft:redstone_wire replace
fill ~448 ~169 ~82 ~448 ~169 ~92 minecraft:redstone_wire replace
fill ~458 ~169 ~82 ~458 ~169 ~92 minecraft:redstone_wire replace
fill ~460 ~169 ~82 ~460 ~169 ~92 minecraft:redstone_wire replace
fill ~472 ~169 ~82 ~472 ~169 ~92 minecraft:redstone_wire replace
fill ~474 ~169 ~82 ~474 ~169 ~92 minecraft:redstone_wire replace
fill ~482 ~169 ~82 ~482 ~169 ~92 minecraft:redstone_wire replace
fill ~484 ~169 ~82 ~484 ~169 ~92 minecraft:redstone_wire replace
fill ~494 ~169 ~82 ~494 ~169 ~92 minecraft:redstone_wire replace
setblock ~442 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~86 ~442 ~169 ~96 minecraft:redstone_wire replace
fill ~450 ~169 ~86 ~450 ~169 ~96 minecraft:redstone_wire replace
fill ~456 ~169 ~86 ~456 ~169 ~96 minecraft:redstone_wire replace
fill ~462 ~169 ~86 ~462 ~169 ~96 minecraft:redstone_wire replace
fill ~470 ~169 ~86 ~470 ~169 ~96 minecraft:redstone_wire replace
fill ~476 ~169 ~86 ~476 ~169 ~96 minecraft:redstone_wire replace
fill ~486 ~169 ~86 ~486 ~169 ~96 minecraft:redstone_wire replace
fill ~492 ~169 ~86 ~492 ~169 ~96 minecraft:redstone_wire replace
fill ~496 ~169 ~86 ~496 ~169 ~96 minecraft:redstone_wire replace
fill ~500 ~169 ~86 ~500 ~169 ~96 minecraft:redstone_wire replace
fill ~502 ~169 ~86 ~502 ~169 ~96 minecraft:redstone_wire replace
setblock ~446 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~90 ~446 ~169 ~100 minecraft:redstone_wire replace
fill ~452 ~169 ~90 ~452 ~169 ~100 minecraft:redstone_wire replace
fill ~454 ~169 ~90 ~454 ~169 ~100 minecraft:redstone_wire replace
fill ~464 ~169 ~90 ~464 ~169 ~100 minecraft:redstone_wire replace
fill ~466 ~169 ~90 ~466 ~169 ~100 minecraft:redstone_wire replace
fill ~468 ~169 ~90 ~468 ~169 ~100 minecraft:redstone_wire replace
fill ~478 ~169 ~90 ~478 ~169 ~100 minecraft:redstone_wire replace
fill ~480 ~169 ~90 ~480 ~169 ~100 minecraft:redstone_wire replace
fill ~488 ~169 ~90 ~488 ~169 ~100 minecraft:redstone_wire replace
fill ~490 ~169 ~90 ~490 ~169 ~100 minecraft:redstone_wire replace
fill ~498 ~169 ~90 ~498 ~169 ~100 minecraft:redstone_wire replace
setblock ~440 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~94 ~440 ~169 ~104 minecraft:redstone_wire replace
fill ~444 ~169 ~94 ~444 ~169 ~104 minecraft:redstone_wire replace
fill ~448 ~169 ~94 ~448 ~169 ~104 minecraft:redstone_wire replace
fill ~458 ~169 ~94 ~458 ~169 ~104 minecraft:redstone_wire replace
fill ~460 ~169 ~94 ~460 ~169 ~104 minecraft:redstone_wire replace
fill ~472 ~169 ~94 ~472 ~169 ~104 minecraft:redstone_wire replace
fill ~474 ~169 ~94 ~474 ~169 ~104 minecraft:redstone_wire replace
fill ~482 ~169 ~94 ~482 ~169 ~104 minecraft:redstone_wire replace
fill ~484 ~169 ~94 ~484 ~169 ~104 minecraft:redstone_wire replace
fill ~494 ~169 ~94 ~494 ~169 ~104 minecraft:redstone_wire replace
setblock ~442 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~98 ~442 ~169 ~108 minecraft:redstone_wire replace
fill ~450 ~169 ~98 ~450 ~169 ~108 minecraft:redstone_wire replace
fill ~456 ~169 ~98 ~456 ~169 ~108 minecraft:redstone_wire replace
fill ~462 ~169 ~98 ~462 ~169 ~108 minecraft:redstone_wire replace
fill ~470 ~169 ~98 ~470 ~169 ~108 minecraft:redstone_wire replace
fill ~476 ~169 ~98 ~476 ~169 ~108 minecraft:redstone_wire replace
fill ~486 ~169 ~98 ~486 ~169 ~108 minecraft:redstone_wire replace
fill ~492 ~169 ~98 ~492 ~169 ~108 minecraft:redstone_wire replace
fill ~496 ~169 ~98 ~496 ~169 ~108 minecraft:redstone_wire replace
fill ~500 ~169 ~98 ~500 ~169 ~108 minecraft:redstone_wire replace
fill ~502 ~169 ~98 ~502 ~169 ~108 minecraft:redstone_wire replace
setblock ~446 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~102 ~446 ~169 ~112 minecraft:redstone_wire replace
fill ~452 ~169 ~102 ~452 ~169 ~112 minecraft:redstone_wire replace
fill ~454 ~169 ~102 ~454 ~169 ~112 minecraft:redstone_wire replace
fill ~464 ~169 ~102 ~464 ~169 ~112 minecraft:redstone_wire replace
fill ~466 ~169 ~102 ~466 ~169 ~112 minecraft:redstone_wire replace
fill ~468 ~169 ~102 ~468 ~169 ~112 minecraft:redstone_wire replace
fill ~478 ~169 ~102 ~478 ~169 ~112 minecraft:redstone_wire replace
fill ~480 ~169 ~102 ~480 ~169 ~112 minecraft:redstone_wire replace
fill ~488 ~169 ~102 ~488 ~169 ~112 minecraft:redstone_wire replace
fill ~490 ~169 ~102 ~490 ~169 ~112 minecraft:redstone_wire replace
fill ~498 ~169 ~102 ~498 ~169 ~112 minecraft:redstone_wire replace
setblock ~440 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~106 ~440 ~169 ~116 minecraft:redstone_wire replace
fill ~444 ~169 ~106 ~444 ~169 ~116 minecraft:redstone_wire replace
fill ~448 ~169 ~106 ~448 ~169 ~116 minecraft:redstone_wire replace
fill ~458 ~169 ~106 ~458 ~169 ~116 minecraft:redstone_wire replace
fill ~460 ~169 ~106 ~460 ~169 ~116 minecraft:redstone_wire replace
fill ~472 ~169 ~106 ~472 ~169 ~116 minecraft:redstone_wire replace
fill ~474 ~169 ~106 ~474 ~169 ~116 minecraft:redstone_wire replace
fill ~482 ~169 ~106 ~482 ~169 ~116 minecraft:redstone_wire replace
fill ~484 ~169 ~106 ~484 ~169 ~116 minecraft:redstone_wire replace
fill ~494 ~169 ~106 ~494 ~169 ~116 minecraft:redstone_wire replace
setblock ~442 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~110 ~442 ~169 ~120 minecraft:redstone_wire replace
fill ~450 ~169 ~110 ~450 ~169 ~120 minecraft:redstone_wire replace
fill ~456 ~169 ~110 ~456 ~169 ~120 minecraft:redstone_wire replace
fill ~462 ~169 ~110 ~462 ~169 ~120 minecraft:redstone_wire replace
fill ~470 ~169 ~110 ~470 ~169 ~120 minecraft:redstone_wire replace
fill ~476 ~169 ~110 ~476 ~169 ~120 minecraft:redstone_wire replace
fill ~486 ~169 ~110 ~486 ~169 ~120 minecraft:redstone_wire replace
fill ~492 ~169 ~110 ~492 ~169 ~120 minecraft:redstone_wire replace
fill ~496 ~169 ~110 ~496 ~169 ~120 minecraft:redstone_wire replace
fill ~500 ~169 ~110 ~500 ~169 ~120 minecraft:redstone_wire replace
fill ~502 ~169 ~110 ~502 ~169 ~120 minecraft:redstone_wire replace
setblock ~446 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~114 ~446 ~169 ~124 minecraft:redstone_wire replace
fill ~452 ~169 ~114 ~452 ~169 ~124 minecraft:redstone_wire replace
fill ~454 ~169 ~114 ~454 ~169 ~124 minecraft:redstone_wire replace
fill ~464 ~169 ~114 ~464 ~169 ~124 minecraft:redstone_wire replace
fill ~466 ~169 ~114 ~466 ~169 ~124 minecraft:redstone_wire replace
fill ~468 ~169 ~114 ~468 ~169 ~124 minecraft:redstone_wire replace
fill ~478 ~169 ~114 ~478 ~169 ~124 minecraft:redstone_wire replace
fill ~480 ~169 ~114 ~480 ~169 ~124 minecraft:redstone_wire replace
fill ~488 ~169 ~114 ~488 ~169 ~124 minecraft:redstone_wire replace
fill ~490 ~169 ~114 ~490 ~169 ~124 minecraft:redstone_wire replace
fill ~498 ~169 ~114 ~498 ~169 ~124 minecraft:redstone_wire replace
setblock ~440 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~118 ~440 ~169 ~128 minecraft:redstone_wire replace
fill ~444 ~169 ~118 ~444 ~169 ~128 minecraft:redstone_wire replace
fill ~448 ~169 ~118 ~448 ~169 ~128 minecraft:redstone_wire replace
fill ~458 ~169 ~118 ~458 ~169 ~128 minecraft:redstone_wire replace
fill ~460 ~169 ~118 ~460 ~169 ~128 minecraft:redstone_wire replace
fill ~472 ~169 ~118 ~472 ~169 ~128 minecraft:redstone_wire replace
fill ~474 ~169 ~118 ~474 ~169 ~128 minecraft:redstone_wire replace
fill ~482 ~169 ~118 ~482 ~169 ~128 minecraft:redstone_wire replace
fill ~484 ~169 ~118 ~484 ~169 ~128 minecraft:redstone_wire replace
fill ~494 ~169 ~118 ~494 ~169 ~128 minecraft:redstone_wire replace
setblock ~442 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~121 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~122 ~442 ~169 ~132 minecraft:redstone_wire replace
fill ~450 ~169 ~122 ~450 ~169 ~132 minecraft:redstone_wire replace
fill ~456 ~169 ~122 ~456 ~169 ~132 minecraft:redstone_wire replace
fill ~462 ~169 ~122 ~462 ~169 ~132 minecraft:redstone_wire replace
fill ~470 ~169 ~122 ~470 ~169 ~132 minecraft:redstone_wire replace
fill ~476 ~169 ~122 ~476 ~169 ~132 minecraft:redstone_wire replace
fill ~486 ~169 ~122 ~486 ~169 ~132 minecraft:redstone_wire replace
fill ~492 ~169 ~122 ~492 ~169 ~132 minecraft:redstone_wire replace
fill ~496 ~169 ~122 ~496 ~169 ~132 minecraft:redstone_wire replace
fill ~500 ~169 ~122 ~500 ~169 ~132 minecraft:redstone_wire replace
fill ~502 ~169 ~122 ~502 ~169 ~132 minecraft:redstone_wire replace
setblock ~446 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~125 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~126 ~446 ~169 ~136 minecraft:redstone_wire replace
fill ~452 ~169 ~126 ~452 ~169 ~136 minecraft:redstone_wire replace
fill ~454 ~169 ~126 ~454 ~169 ~136 minecraft:redstone_wire replace
fill ~464 ~169 ~126 ~464 ~169 ~136 minecraft:redstone_wire replace
fill ~466 ~169 ~126 ~466 ~169 ~136 minecraft:redstone_wire replace
fill ~468 ~169 ~126 ~468 ~169 ~136 minecraft:redstone_wire replace
fill ~478 ~169 ~126 ~478 ~169 ~136 minecraft:redstone_wire replace
fill ~480 ~169 ~126 ~480 ~169 ~136 minecraft:redstone_wire replace
fill ~488 ~169 ~126 ~488 ~169 ~136 minecraft:redstone_wire replace
fill ~490 ~169 ~126 ~490 ~169 ~136 minecraft:redstone_wire replace
fill ~498 ~169 ~126 ~498 ~169 ~136 minecraft:redstone_wire replace
setblock ~440 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~129 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~130 ~440 ~169 ~140 minecraft:redstone_wire replace
fill ~444 ~169 ~130 ~444 ~169 ~140 minecraft:redstone_wire replace
fill ~448 ~169 ~130 ~448 ~169 ~140 minecraft:redstone_wire replace
fill ~458 ~169 ~130 ~458 ~169 ~140 minecraft:redstone_wire replace
fill ~460 ~169 ~130 ~460 ~169 ~140 minecraft:redstone_wire replace
fill ~472 ~169 ~130 ~472 ~169 ~140 minecraft:redstone_wire replace
fill ~474 ~169 ~130 ~474 ~169 ~140 minecraft:redstone_wire replace
fill ~482 ~169 ~130 ~482 ~169 ~140 minecraft:redstone_wire replace
fill ~484 ~169 ~130 ~484 ~169 ~140 minecraft:redstone_wire replace
fill ~494 ~169 ~130 ~494 ~169 ~140 minecraft:redstone_wire replace
setblock ~442 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~486 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~496 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~133 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~134 ~442 ~169 ~144 minecraft:redstone_wire replace
fill ~450 ~169 ~134 ~450 ~169 ~144 minecraft:redstone_wire replace
fill ~456 ~169 ~134 ~456 ~169 ~144 minecraft:redstone_wire replace
fill ~462 ~169 ~134 ~462 ~169 ~144 minecraft:redstone_wire replace
fill ~470 ~169 ~134 ~470 ~169 ~144 minecraft:redstone_wire replace
fill ~476 ~169 ~134 ~476 ~169 ~144 minecraft:redstone_wire replace
fill ~486 ~169 ~134 ~486 ~169 ~144 minecraft:redstone_wire replace
fill ~492 ~169 ~134 ~492 ~169 ~144 minecraft:redstone_wire replace
fill ~496 ~169 ~134 ~496 ~169 ~144 minecraft:redstone_wire replace
fill ~500 ~169 ~134 ~500 ~169 ~144 minecraft:redstone_wire replace
fill ~502 ~169 ~134 ~502 ~169 ~144 minecraft:redstone_wire replace
setblock ~446 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~488 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~490 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~498 ~169 ~137 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~138 ~446 ~169 ~148 minecraft:redstone_wire replace
fill ~452 ~169 ~138 ~452 ~169 ~148 minecraft:redstone_wire replace
fill ~454 ~169 ~138 ~454 ~169 ~148 minecraft:redstone_wire replace
fill ~464 ~169 ~138 ~464 ~169 ~148 minecraft:redstone_wire replace
fill ~466 ~169 ~138 ~466 ~169 ~148 minecraft:redstone_wire replace
fill ~468 ~169 ~138 ~468 ~169 ~148 minecraft:redstone_wire replace
fill ~478 ~169 ~138 ~478 ~169 ~148 minecraft:redstone_wire replace
fill ~480 ~169 ~138 ~480 ~169 ~148 minecraft:redstone_wire replace
fill ~488 ~169 ~138 ~488 ~169 ~148 minecraft:redstone_wire replace
fill ~490 ~169 ~138 ~490 ~169 ~148 minecraft:redstone_wire replace
fill ~498 ~169 ~138 ~498 ~169 ~148 minecraft:redstone_wire replace
setblock ~440 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~482 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~484 ~169 ~141 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
