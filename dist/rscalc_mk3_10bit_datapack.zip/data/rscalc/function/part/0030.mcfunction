setblock ~177 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~488 ~108 ~155 ~500 minecraft:redstone_wire replace
fill ~111 ~155 ~488 ~111 ~155 ~500 minecraft:redstone_wire replace
fill ~114 ~155 ~488 ~114 ~155 ~500 minecraft:redstone_wire replace
fill ~117 ~155 ~488 ~117 ~155 ~500 minecraft:redstone_wire replace
fill ~120 ~155 ~488 ~120 ~155 ~500 minecraft:redstone_wire replace
fill ~123 ~155 ~488 ~123 ~155 ~500 minecraft:redstone_wire replace
fill ~126 ~155 ~488 ~126 ~155 ~500 minecraft:redstone_wire replace
fill ~129 ~155 ~488 ~129 ~155 ~500 minecraft:redstone_wire replace
fill ~132 ~155 ~488 ~132 ~155 ~500 minecraft:redstone_wire replace
fill ~135 ~155 ~488 ~135 ~155 ~500 minecraft:redstone_wire replace
fill ~138 ~155 ~488 ~138 ~155 ~500 minecraft:redstone_wire replace
fill ~141 ~155 ~488 ~141 ~155 ~500 minecraft:redstone_wire replace
fill ~144 ~155 ~488 ~144 ~155 ~500 minecraft:redstone_wire replace
fill ~147 ~155 ~488 ~147 ~155 ~500 minecraft:redstone_wire replace
fill ~150 ~155 ~488 ~150 ~155 ~500 minecraft:redstone_wire replace
fill ~153 ~155 ~488 ~153 ~155 ~500 minecraft:redstone_wire replace
fill ~156 ~155 ~488 ~156 ~155 ~500 minecraft:redstone_wire replace
fill ~159 ~155 ~488 ~159 ~155 ~500 minecraft:redstone_wire replace
fill ~162 ~155 ~488 ~162 ~155 ~500 minecraft:redstone_wire replace
fill ~165 ~155 ~488 ~165 ~155 ~500 minecraft:redstone_wire replace
fill ~168 ~155 ~488 ~168 ~155 ~500 minecraft:redstone_wire replace
fill ~171 ~155 ~488 ~171 ~155 ~500 minecraft:redstone_wire replace
fill ~174 ~155 ~488 ~174 ~155 ~500 minecraft:redstone_wire replace
fill ~177 ~155 ~488 ~177 ~155 ~500 minecraft:redstone_wire replace
fill ~180 ~155 ~488 ~180 ~155 ~500 minecraft:redstone_wire replace
fill ~183 ~155 ~488 ~183 ~155 ~500 minecraft:redstone_wire replace
fill ~186 ~155 ~488 ~186 ~155 ~500 minecraft:redstone_wire replace
fill ~189 ~155 ~488 ~189 ~155 ~500 minecraft:redstone_wire replace
fill ~192 ~155 ~488 ~192 ~155 ~500 minecraft:redstone_wire replace
fill ~195 ~155 ~488 ~195 ~155 ~500 minecraft:redstone_wire replace
fill ~198 ~155 ~488 ~198 ~155 ~500 minecraft:redstone_wire replace
fill ~201 ~155 ~488 ~201 ~155 ~500 minecraft:redstone_wire replace
fill ~204 ~155 ~488 ~204 ~155 ~500 minecraft:redstone_wire replace
fill ~207 ~155 ~488 ~207 ~155 ~500 minecraft:redstone_wire replace
fill ~210 ~155 ~488 ~210 ~155 ~500 minecraft:redstone_wire replace
fill ~213 ~155 ~488 ~213 ~155 ~500 minecraft:redstone_wire replace
fill ~216 ~155 ~488 ~216 ~155 ~500 minecraft:redstone_wire replace
fill ~219 ~155 ~488 ~219 ~155 ~500 minecraft:redstone_wire replace
fill ~222 ~155 ~488 ~222 ~155 ~500 minecraft:redstone_wire replace
fill ~225 ~155 ~488 ~225 ~155 ~500 minecraft:redstone_wire replace
fill ~228 ~155 ~488 ~228 ~155 ~500 minecraft:redstone_wire replace
fill ~231 ~155 ~488 ~231 ~155 ~500 minecraft:redstone_wire replace
fill ~234 ~155 ~488 ~234 ~155 ~500 minecraft:redstone_wire replace
fill ~237 ~155 ~488 ~237 ~155 ~500 minecraft:redstone_wire replace
fill ~240 ~155 ~488 ~240 ~155 ~500 minecraft:redstone_wire replace
fill ~243 ~155 ~488 ~243 ~155 ~500 minecraft:redstone_wire replace
fill ~246 ~155 ~488 ~246 ~155 ~500 minecraft:redstone_wire replace
fill ~249 ~155 ~488 ~249 ~155 ~500 minecraft:redstone_wire replace
fill ~252 ~155 ~488 ~252 ~155 ~500 minecraft:redstone_wire replace
setblock ~108 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~504 ~108 ~155 ~516 minecraft:redstone_wire replace
fill ~111 ~155 ~504 ~111 ~155 ~516 minecraft:redstone_wire replace
fill ~114 ~155 ~504 ~114 ~155 ~516 minecraft:redstone_wire replace
fill ~117 ~155 ~504 ~117 ~155 ~516 minecraft:redstone_wire replace
fill ~120 ~155 ~504 ~120 ~155 ~516 minecraft:redstone_wire replace
fill ~123 ~155 ~504 ~123 ~155 ~516 minecraft:redstone_wire replace
fill ~126 ~155 ~504 ~126 ~155 ~516 minecraft:redstone_wire replace
fill ~129 ~155 ~504 ~129 ~155 ~516 minecraft:redstone_wire replace
fill ~132 ~155 ~504 ~132 ~155 ~516 minecraft:redstone_wire replace
fill ~135 ~155 ~504 ~135 ~155 ~516 minecraft:redstone_wire replace
fill ~138 ~155 ~504 ~138 ~155 ~516 minecraft:redstone_wire replace
fill ~141 ~155 ~504 ~141 ~155 ~516 minecraft:redstone_wire replace
fill ~144 ~155 ~504 ~144 ~155 ~516 minecraft:redstone_wire replace
fill ~147 ~155 ~504 ~147 ~155 ~516 minecraft:redstone_wire replace
fill ~150 ~155 ~504 ~150 ~155 ~516 minecraft:redstone_wire replace
fill ~153 ~155 ~504 ~153 ~155 ~516 minecraft:redstone_wire replace
fill ~156 ~155 ~504 ~156 ~155 ~516 minecraft:redstone_wire replace
fill ~159 ~155 ~504 ~159 ~155 ~516 minecraft:redstone_wire replace
fill ~162 ~155 ~504 ~162 ~155 ~516 minecraft:redstone_wire replace
fill ~165 ~155 ~504 ~165 ~155 ~516 minecraft:redstone_wire replace
fill ~168 ~155 ~504 ~168 ~155 ~516 minecraft:redstone_wire replace
fill ~171 ~155 ~504 ~171 ~155 ~516 minecraft:redstone_wire replace
fill ~174 ~155 ~504 ~174 ~155 ~516 minecraft:redstone_wire replace
fill ~177 ~155 ~504 ~177 ~155 ~516 minecraft:redstone_wire replace
fill ~180 ~155 ~504 ~180 ~155 ~516 minecraft:redstone_wire replace
fill ~183 ~155 ~504 ~183 ~155 ~516 minecraft:redstone_wire replace
fill ~186 ~155 ~504 ~186 ~155 ~516 minecraft:redstone_wire replace
fill ~189 ~155 ~504 ~189 ~155 ~516 minecraft:redstone_wire replace
fill ~192 ~155 ~504 ~192 ~155 ~516 minecraft:redstone_wire replace
fill ~195 ~155 ~504 ~195 ~155 ~516 minecraft:redstone_wire replace
fill ~198 ~155 ~504 ~198 ~155 ~516 minecraft:redstone_wire replace
fill ~201 ~155 ~504 ~201 ~155 ~516 minecraft:redstone_wire replace
fill ~204 ~155 ~504 ~204 ~155 ~516 minecraft:redstone_wire replace
fill ~207 ~155 ~504 ~207 ~155 ~516 minecraft:redstone_wire replace
fill ~210 ~155 ~504 ~210 ~155 ~516 minecraft:redstone_wire replace
fill ~213 ~155 ~504 ~213 ~155 ~516 minecraft:redstone_wire replace
fill ~216 ~155 ~504 ~216 ~155 ~516 minecraft:redstone_wire replace
fill ~219 ~155 ~504 ~219 ~155 ~516 minecraft:redstone_wire replace
fill ~222 ~155 ~504 ~222 ~155 ~516 minecraft:redstone_wire replace
fill ~225 ~155 ~504 ~225 ~155 ~516 minecraft:redstone_wire replace
fill ~228 ~155 ~504 ~228 ~155 ~516 minecraft:redstone_wire replace
fill ~231 ~155 ~504 ~231 ~155 ~516 minecraft:redstone_wire replace
fill ~234 ~155 ~504 ~234 ~155 ~516 minecraft:redstone_wire replace
fill ~237 ~155 ~504 ~237 ~155 ~516 minecraft:redstone_wire replace
fill ~240 ~155 ~504 ~240 ~155 ~516 minecraft:redstone_wire replace
fill ~243 ~155 ~504 ~243 ~155 ~516 minecraft:redstone_wire replace
fill ~246 ~155 ~504 ~246 ~155 ~516 minecraft:redstone_wire replace
fill ~249 ~155 ~504 ~249 ~155 ~516 minecraft:redstone_wire replace
fill ~252 ~155 ~504 ~252 ~155 ~516 minecraft:redstone_wire replace
setblock ~108 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~520 ~108 ~155 ~532 minecraft:redstone_wire replace
fill ~111 ~155 ~520 ~111 ~155 ~532 minecraft:redstone_wire replace
fill ~114 ~155 ~520 ~114 ~155 ~532 minecraft:redstone_wire replace
fill ~117 ~155 ~520 ~117 ~155 ~532 minecraft:redstone_wire replace
fill ~120 ~155 ~520 ~120 ~155 ~532 minecraft:redstone_wire replace
fill ~123 ~155 ~520 ~123 ~155 ~532 minecraft:redstone_wire replace
fill ~126 ~155 ~520 ~126 ~155 ~532 minecraft:redstone_wire replace
fill ~129 ~155 ~520 ~129 ~155 ~532 minecraft:redstone_wire replace
fill ~132 ~155 ~520 ~132 ~155 ~532 minecraft:redstone_wire replace
fill ~135 ~155 ~520 ~135 ~155 ~532 minecraft:redstone_wire replace
fill ~138 ~155 ~520 ~138 ~155 ~532 minecraft:redstone_wire replace
fill ~141 ~155 ~520 ~141 ~155 ~532 minecraft:redstone_wire replace
fill ~144 ~155 ~520 ~144 ~155 ~532 minecraft:redstone_wire replace
fill ~147 ~155 ~520 ~147 ~155 ~532 minecraft:redstone_wire replace
fill ~150 ~155 ~520 ~150 ~155 ~532 minecraft:redstone_wire replace
fill ~153 ~155 ~520 ~153 ~155 ~532 minecraft:redstone_wire replace
fill ~156 ~155 ~520 ~156 ~155 ~532 minecraft:redstone_wire replace
fill ~159 ~155 ~520 ~159 ~155 ~532 minecraft:redstone_wire replace
fill ~162 ~155 ~520 ~162 ~155 ~532 minecraft:redstone_wire replace
fill ~165 ~155 ~520 ~165 ~155 ~532 minecraft:redstone_wire replace
fill ~168 ~155 ~520 ~168 ~155 ~532 minecraft:redstone_wire replace
fill ~171 ~155 ~520 ~171 ~155 ~532 minecraft:redstone_wire replace
fill ~174 ~155 ~520 ~174 ~155 ~532 minecraft:redstone_wire replace
fill ~177 ~155 ~520 ~177 ~155 ~532 minecraft:redstone_wire replace
fill ~180 ~155 ~520 ~180 ~155 ~532 minecraft:redstone_wire replace
fill ~183 ~155 ~520 ~183 ~155 ~532 minecraft:redstone_wire replace
fill ~186 ~155 ~520 ~186 ~155 ~532 minecraft:redstone_wire replace
fill ~189 ~155 ~520 ~189 ~155 ~532 minecraft:redstone_wire replace
fill ~192 ~155 ~520 ~192 ~155 ~532 minecraft:redstone_wire replace
fill ~195 ~155 ~520 ~195 ~155 ~532 minecraft:redstone_wire replace
fill ~198 ~155 ~520 ~198 ~155 ~532 minecraft:redstone_wire replace
fill ~201 ~155 ~520 ~201 ~155 ~532 minecraft:redstone_wire replace
fill ~204 ~155 ~520 ~204 ~155 ~532 minecraft:redstone_wire replace
fill ~207 ~155 ~520 ~207 ~155 ~532 minecraft:redstone_wire replace
fill ~210 ~155 ~520 ~210 ~155 ~532 minecraft:redstone_wire replace
fill ~213 ~155 ~520 ~213 ~155 ~532 minecraft:redstone_wire replace
fill ~216 ~155 ~520 ~216 ~155 ~532 minecraft:redstone_wire replace
fill ~219 ~155 ~520 ~219 ~155 ~532 minecraft:redstone_wire replace
fill ~222 ~155 ~520 ~222 ~155 ~532 minecraft:redstone_wire replace
fill ~225 ~155 ~520 ~225 ~155 ~532 minecraft:redstone_wire replace
fill ~228 ~155 ~520 ~228 ~155 ~532 minecraft:redstone_wire replace
fill ~231 ~155 ~520 ~231 ~155 ~532 minecraft:redstone_wire replace
fill ~234 ~155 ~520 ~234 ~155 ~532 minecraft:redstone_wire replace
fill ~237 ~155 ~520 ~237 ~155 ~532 minecraft:redstone_wire replace
fill ~240 ~155 ~520 ~240 ~155 ~532 minecraft:redstone_wire replace
fill ~243 ~155 ~520 ~243 ~155 ~532 minecraft:redstone_wire replace
fill ~246 ~155 ~520 ~246 ~155 ~532 minecraft:redstone_wire replace
fill ~249 ~155 ~520 ~249 ~155 ~532 minecraft:redstone_wire replace
fill ~252 ~155 ~520 ~252 ~155 ~532 minecraft:redstone_wire replace
setblock ~108 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~534 ~108 ~155 ~536 minecraft:redstone_wire replace
fill ~111 ~155 ~534 ~111 ~155 ~540 minecraft:redstone_wire replace
fill ~114 ~155 ~534 ~114 ~155 ~542 minecraft:redstone_wire replace
fill ~117 ~155 ~534 ~117 ~155 ~546 minecraft:redstone_wire replace
fill ~120 ~155 ~534 ~120 ~155 ~546 minecraft:redstone_wire replace
fill ~123 ~155 ~534 ~123 ~155 ~546 minecraft:redstone_wire replace
fill ~126 ~155 ~534 ~126 ~155 ~546 minecraft:redstone_wire replace
fill ~129 ~155 ~534 ~129 ~155 ~546 minecraft:redstone_wire replace
fill ~132 ~155 ~534 ~132 ~155 ~546 minecraft:redstone_wire replace
fill ~135 ~155 ~534 ~135 ~155 ~546 minecraft:redstone_wire replace
fill ~138 ~155 ~534 ~138 ~155 ~546 minecraft:redstone_wire replace
fill ~141 ~155 ~534 ~141 ~155 ~546 minecraft:redstone_wire replace
fill ~144 ~155 ~534 ~144 ~155 ~546 minecraft:redstone_wire replace
fill ~147 ~155 ~534 ~147 ~155 ~546 minecraft:redstone_wire replace
fill ~150 ~155 ~534 ~150 ~155 ~546 minecraft:redstone_wire replace
fill ~153 ~155 ~534 ~153 ~155 ~546 minecraft:redstone_wire replace
fill ~156 ~155 ~534 ~156 ~155 ~546 minecraft:redstone_wire replace
fill ~159 ~155 ~534 ~159 ~155 ~546 minecraft:redstone_wire replace
fill ~162 ~155 ~534 ~162 ~155 ~546 minecraft:redstone_wire replace
fill ~165 ~155 ~534 ~165 ~155 ~546 minecraft:redstone_wire replace
fill ~168 ~155 ~534 ~168 ~155 ~546 minecraft:redstone_wire replace
fill ~171 ~155 ~534 ~171 ~155 ~546 minecraft:redstone_wire replace
fill ~174 ~155 ~534 ~174 ~155 ~546 minecraft:redstone_wire replace
fill ~177 ~155 ~534 ~177 ~155 ~546 minecraft:redstone_wire replace
fill ~180 ~155 ~534 ~180 ~155 ~546 minecraft:redstone_wire replace
fill ~183 ~155 ~534 ~183 ~155 ~546 minecraft:redstone_wire replace
fill ~186 ~155 ~534 ~186 ~155 ~546 minecraft:redstone_wire replace
fill ~189 ~155 ~534 ~189 ~155 ~546 minecraft:redstone_wire replace
fill ~192 ~155 ~534 ~192 ~155 ~546 minecraft:redstone_wire replace
fill ~195 ~155 ~534 ~195 ~155 ~546 minecraft:redstone_wire replace
fill ~198 ~155 ~534 ~198 ~155 ~546 minecraft:redstone_wire replace
fill ~201 ~155 ~534 ~201 ~155 ~546 minecraft:redstone_wire replace
fill ~204 ~155 ~534 ~204 ~155 ~546 minecraft:redstone_wire replace
fill ~207 ~155 ~534 ~207 ~155 ~546 minecraft:redstone_wire replace
fill ~210 ~155 ~534 ~210 ~155 ~546 minecraft:redstone_wire replace
fill ~213 ~155 ~534 ~213 ~155 ~546 minecraft:redstone_wire replace
fill ~216 ~155 ~534 ~216 ~155 ~546 minecraft:redstone_wire replace
fill ~219 ~155 ~534 ~219 ~155 ~546 minecraft:redstone_wire replace
fill ~222 ~155 ~534 ~222 ~155 ~546 minecraft:redstone_wire replace
fill ~225 ~155 ~534 ~225 ~155 ~546 minecraft:redstone_wire replace
fill ~228 ~155 ~534 ~228 ~155 ~546 minecraft:redstone_wire replace
fill ~231 ~155 ~534 ~231 ~155 ~546 minecraft:redstone_wire replace
fill ~234 ~155 ~534 ~234 ~155 ~546 minecraft:redstone_wire replace
fill ~237 ~155 ~534 ~237 ~155 ~546 minecraft:redstone_wire replace
fill ~240 ~155 ~534 ~240 ~155 ~546 minecraft:redstone_wire replace
fill ~243 ~155 ~534 ~243 ~155 ~546 minecraft:redstone_wire replace
fill ~246 ~155 ~534 ~246 ~155 ~546 minecraft:redstone_wire replace
fill ~249 ~155 ~534 ~249 ~155 ~546 minecraft:redstone_wire replace
fill ~252 ~155 ~534 ~252 ~155 ~546 minecraft:redstone_wire replace
fill ~255 ~155 ~536 ~255 ~155 ~548 minecraft:redstone_wire replace
fill ~258 ~155 ~536 ~258 ~155 ~548 minecraft:redstone_wire replace
fill ~261 ~155 ~536 ~261 ~155 ~548 minecraft:redstone_wire replace
fill ~264 ~155 ~536 ~264 ~155 ~548 minecraft:redstone_wire replace
fill ~267 ~155 ~536 ~267 ~155 ~548 minecraft:redstone_wire replace
fill ~270 ~155 ~536 ~270 ~155 ~548 minecraft:redstone_wire replace
fill ~273 ~155 ~536 ~273 ~155 ~548 minecraft:redstone_wire replace
fill ~276 ~155 ~536 ~276 ~155 ~548 minecraft:redstone_wire replace
fill ~279 ~155 ~536 ~279 ~155 ~548 minecraft:redstone_wire replace
fill ~282 ~155 ~536 ~282 ~155 ~548 minecraft:redstone_wire replace
fill ~285 ~155 ~536 ~285 ~155 ~548 minecraft:redstone_wire replace
fill ~288 ~155 ~536 ~288 ~155 ~548 minecraft:redstone_wire replace
fill ~291 ~155 ~536 ~291 ~155 ~548 minecraft:redstone_wire replace
fill ~294 ~155 ~536 ~294 ~155 ~548 minecraft:redstone_wire replace
fill ~297 ~155 ~536 ~297 ~155 ~548 minecraft:redstone_wire replace
fill ~300 ~155 ~536 ~300 ~155 ~548 minecraft:redstone_wire replace
fill ~303 ~155 ~536 ~303 ~155 ~548 minecraft:redstone_wire replace
fill ~306 ~155 ~536 ~306 ~155 ~548 minecraft:redstone_wire replace
fill ~309 ~155 ~536 ~309 ~155 ~548 minecraft:redstone_wire replace
fill ~312 ~155 ~536 ~312 ~155 ~548 minecraft:redstone_wire replace
fill ~315 ~155 ~536 ~315 ~155 ~548 minecraft:redstone_wire replace
fill ~318 ~155 ~536 ~318 ~155 ~548 minecraft:redstone_wire replace
fill ~321 ~155 ~536 ~321 ~155 ~548 minecraft:redstone_wire replace
fill ~324 ~155 ~536 ~324 ~155 ~548 minecraft:redstone_wire replace
fill ~327 ~155 ~536 ~327 ~155 ~548 minecraft:redstone_wire replace
fill ~330 ~155 ~536 ~330 ~155 ~548 minecraft:redstone_wire replace
fill ~333 ~155 ~536 ~333 ~155 ~548 minecraft:redstone_wire replace
fill ~336 ~155 ~536 ~336 ~155 ~548 minecraft:redstone_wire replace
fill ~339 ~155 ~536 ~339 ~155 ~548 minecraft:redstone_wire replace
fill ~342 ~155 ~536 ~342 ~155 ~548 minecraft:redstone_wire replace
fill ~345 ~155 ~536 ~345 ~155 ~548 minecraft:redstone_wire replace
fill ~348 ~155 ~536 ~348 ~155 ~548 minecraft:redstone_wire replace
fill ~351 ~155 ~536 ~351 ~155 ~548 minecraft:redstone_wire replace
fill ~354 ~155 ~536 ~354 ~155 ~548 minecraft:redstone_wire replace
fill ~357 ~155 ~536 ~357 ~155 ~548 minecraft:redstone_wire replace
fill ~360 ~155 ~536 ~360 ~155 ~548 minecraft:redstone_wire replace
fill ~363 ~155 ~536 ~363 ~155 ~548 minecraft:redstone_wire replace
fill ~366 ~155 ~536 ~366 ~155 ~548 minecraft:redstone_wire replace
fill ~369 ~155 ~536 ~369 ~155 ~548 minecraft:redstone_wire replace
fill ~372 ~155 ~536 ~372 ~155 ~548 minecraft:redstone_wire replace
fill ~375 ~155 ~536 ~375 ~155 ~548 minecraft:redstone_wire replace
fill ~378 ~155 ~536 ~378 ~155 ~548 minecraft:redstone_wire replace
fill ~381 ~155 ~536 ~381 ~155 ~548 minecraft:redstone_wire replace
fill ~384 ~155 ~536 ~384 ~155 ~548 minecraft:redstone_wire replace
fill ~387 ~155 ~536 ~387 ~155 ~548 minecraft:redstone_wire replace
fill ~390 ~155 ~536 ~390 ~155 ~548 minecraft:redstone_wire replace
fill ~393 ~155 ~536 ~393 ~155 ~548 minecraft:redstone_wire replace
fill ~396 ~155 ~536 ~396 ~155 ~548 minecraft:redstone_wire replace
fill ~399 ~155 ~536 ~399 ~155 ~548 minecraft:redstone_wire replace
setblock ~114 ~155 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~548 minecraft:redstone_wire replace
setblock ~120 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~155 ~550 ~120 ~155 ~552 minecraft:redstone_wire replace
fill ~123 ~155 ~550 ~123 ~155 ~556 minecraft:redstone_wire replace
fill ~126 ~155 ~550 ~126 ~155 ~558 minecraft:redstone_wire replace
fill ~129 ~155 ~550 ~129 ~155 ~562 minecraft:redstone_wire replace
fill ~132 ~155 ~550 ~132 ~155 ~562 minecraft:redstone_wire replace
fill ~135 ~155 ~550 ~135 ~155 ~562 minecraft:redstone_wire replace
fill ~138 ~155 ~550 ~138 ~155 ~562 minecraft:redstone_wire replace
fill ~141 ~155 ~550 ~141 ~155 ~562 minecraft:redstone_wire replace
fill ~144 ~155 ~550 ~144 ~155 ~562 minecraft:redstone_wire replace
fill ~147 ~155 ~550 ~147 ~155 ~562 minecraft:redstone_wire replace
fill ~150 ~155 ~550 ~150 ~155 ~562 minecraft:redstone_wire replace
fill ~153 ~155 ~550 ~153 ~155 ~562 minecraft:redstone_wire replace
fill ~156 ~155 ~550 ~156 ~155 ~562 minecraft:redstone_wire replace
fill ~159 ~155 ~550 ~159 ~155 ~562 minecraft:redstone_wire replace
fill ~162 ~155 ~550 ~162 ~155 ~562 minecraft:redstone_wire replace
fill ~165 ~155 ~550 ~165 ~155 ~562 minecraft:redstone_wire replace
fill ~168 ~155 ~550 ~168 ~155 ~562 minecraft:redstone_wire replace
fill ~171 ~155 ~550 ~171 ~155 ~562 minecraft:redstone_wire replace
fill ~174 ~155 ~550 ~174 ~155 ~562 minecraft:redstone_wire replace
fill ~177 ~155 ~550 ~177 ~155 ~562 minecraft:redstone_wire replace
fill ~180 ~155 ~550 ~180 ~155 ~562 minecraft:redstone_wire replace
fill ~183 ~155 ~550 ~183 ~155 ~562 minecraft:redstone_wire replace
fill ~186 ~155 ~550 ~186 ~155 ~562 minecraft:redstone_wire replace
fill ~189 ~155 ~550 ~189 ~155 ~562 minecraft:redstone_wire replace
fill ~192 ~155 ~550 ~192 ~155 ~562 minecraft:redstone_wire replace
fill ~195 ~155 ~550 ~195 ~155 ~562 minecraft:redstone_wire replace
fill ~198 ~155 ~550 ~198 ~155 ~562 minecraft:redstone_wire replace
fill ~201 ~155 ~550 ~201 ~155 ~562 minecraft:redstone_wire replace
fill ~204 ~155 ~550 ~204 ~155 ~562 minecraft:redstone_wire replace
fill ~207 ~155 ~550 ~207 ~155 ~562 minecraft:redstone_wire replace
fill ~210 ~155 ~550 ~210 ~155 ~562 minecraft:redstone_wire replace
fill ~213 ~155 ~550 ~213 ~155 ~562 minecraft:redstone_wire replace
fill ~216 ~155 ~550 ~216 ~155 ~562 minecraft:redstone_wire replace
fill ~219 ~155 ~550 ~219 ~155 ~562 minecraft:redstone_wire replace
fill ~222 ~155 ~550 ~222 ~155 ~562 minecraft:redstone_wire replace
fill ~225 ~155 ~550 ~225 ~155 ~562 minecraft:redstone_wire replace
fill ~228 ~155 ~550 ~228 ~155 ~562 minecraft:redstone_wire replace
fill ~231 ~155 ~550 ~231 ~155 ~562 minecraft:redstone_wire replace
fill ~234 ~155 ~550 ~234 ~155 ~562 minecraft:redstone_wire replace
fill ~237 ~155 ~550 ~237 ~155 ~562 minecraft:redstone_wire replace
fill ~240 ~155 ~550 ~240 ~155 ~562 minecraft:redstone_wire replace
fill ~243 ~155 ~550 ~243 ~155 ~562 minecraft:redstone_wire replace
fill ~246 ~155 ~550 ~246 ~155 ~562 minecraft:redstone_wire replace
fill ~249 ~155 ~550 ~249 ~155 ~562 minecraft:redstone_wire replace
fill ~252 ~155 ~550 ~252 ~155 ~562 minecraft:redstone_wire replace
setblock ~255 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~155 ~552 ~255 ~155 ~564 minecraft:redstone_wire replace
fill ~258 ~155 ~552 ~258 ~155 ~564 minecraft:redstone_wire replace
fill ~261 ~155 ~552 ~261 ~155 ~564 minecraft:redstone_wire replace
fill ~264 ~155 ~552 ~264 ~155 ~564 minecraft:redstone_wire replace
fill ~267 ~155 ~552 ~267 ~155 ~564 minecraft:redstone_wire replace
fill ~270 ~155 ~552 ~270 ~155 ~564 minecraft:redstone_wire replace
fill ~273 ~155 ~552 ~273 ~155 ~564 minecraft:redstone_wire replace
fill ~276 ~155 ~552 ~276 ~155 ~564 minecraft:redstone_wire replace
fill ~279 ~155 ~552 ~279 ~155 ~564 minecraft:redstone_wire replace
fill ~282 ~155 ~552 ~282 ~155 ~564 minecraft:redstone_wire replace
fill ~285 ~155 ~552 ~285 ~155 ~564 minecraft:redstone_wire replace
fill ~288 ~155 ~552 ~288 ~155 ~564 minecraft:redstone_wire replace
fill ~291 ~155 ~552 ~291 ~155 ~564 minecraft:redstone_wire replace
fill ~294 ~155 ~552 ~294 ~155 ~564 minecraft:redstone_wire replace
fill ~297 ~155 ~552 ~297 ~155 ~564 minecraft:redstone_wire replace
fill ~300 ~155 ~552 ~300 ~155 ~564 minecraft:redstone_wire replace
fill ~303 ~155 ~552 ~303 ~155 ~564 minecraft:redstone_wire replace
fill ~306 ~155 ~552 ~306 ~155 ~564 minecraft:redstone_wire replace
fill ~309 ~155 ~552 ~309 ~155 ~564 minecraft:redstone_wire replace
fill ~312 ~155 ~552 ~312 ~155 ~564 minecraft:redstone_wire replace
fill ~315 ~155 ~552 ~315 ~155 ~564 minecraft:redstone_wire replace
fill ~318 ~155 ~552 ~318 ~155 ~564 minecraft:redstone_wire replace
fill ~321 ~155 ~552 ~321 ~155 ~564 minecraft:redstone_wire replace
fill ~324 ~155 ~552 ~324 ~155 ~564 minecraft:redstone_wire replace
fill ~327 ~155 ~552 ~327 ~155 ~564 minecraft:redstone_wire replace
fill ~330 ~155 ~552 ~330 ~155 ~564 minecraft:redstone_wire replace
fill ~333 ~155 ~552 ~333 ~155 ~564 minecraft:redstone_wire replace
fill ~336 ~155 ~552 ~336 ~155 ~564 minecraft:redstone_wire replace
fill ~339 ~155 ~552 ~339 ~155 ~564 minecraft:redstone_wire replace
fill ~342 ~155 ~552 ~342 ~155 ~564 minecraft:redstone_wire replace
fill ~345 ~155 ~552 ~345 ~155 ~564 minecraft:redstone_wire replace
fill ~348 ~155 ~552 ~348 ~155 ~564 minecraft:redstone_wire replace
fill ~351 ~155 ~552 ~351 ~155 ~564 minecraft:redstone_wire replace
fill ~354 ~155 ~552 ~354 ~155 ~564 minecraft:redstone_wire replace
fill ~357 ~155 ~552 ~357 ~155 ~564 minecraft:redstone_wire replace
fill ~360 ~155 ~552 ~360 ~155 ~564 minecraft:redstone_wire replace
fill ~363 ~155 ~552 ~363 ~155 ~564 minecraft:redstone_wire replace
fill ~366 ~155 ~552 ~366 ~155 ~564 minecraft:redstone_wire replace
fill ~369 ~155 ~552 ~369 ~155 ~564 minecraft:redstone_wire replace
fill ~372 ~155 ~552 ~372 ~155 ~564 minecraft:redstone_wire replace
fill ~375 ~155 ~552 ~375 ~155 ~564 minecraft:redstone_wire replace
fill ~378 ~155 ~552 ~378 ~155 ~564 minecraft:redstone_wire replace
fill ~381 ~155 ~552 ~381 ~155 ~564 minecraft:redstone_wire replace
fill ~384 ~155 ~552 ~384 ~155 ~564 minecraft:redstone_wire replace
fill ~387 ~155 ~552 ~387 ~155 ~564 minecraft:redstone_wire replace
fill ~390 ~155 ~552 ~390 ~155 ~564 minecraft:redstone_wire replace
fill ~393 ~155 ~552 ~393 ~155 ~564 minecraft:redstone_wire replace
fill ~396 ~155 ~552 ~396 ~155 ~564 minecraft:redstone_wire replace
fill ~399 ~155 ~552 ~399 ~155 ~564 minecraft:redstone_wire replace
setblock ~126 ~155 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~564 minecraft:redstone_wire replace
setblock ~132 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~565 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~155 ~566 ~132 ~155 ~568 minecraft:redstone_wire replace
fill ~135 ~155 ~566 ~135 ~155 ~572 minecraft:redstone_wire replace
fill ~138 ~155 ~566 ~138 ~155 ~574 minecraft:redstone_wire replace
fill ~141 ~155 ~566 ~141 ~155 ~578 minecraft:redstone_wire replace
fill ~144 ~155 ~566 ~144 ~155 ~578 minecraft:redstone_wire replace
fill ~147 ~155 ~566 ~147 ~155 ~578 minecraft:redstone_wire replace
fill ~150 ~155 ~566 ~150 ~155 ~578 minecraft:redstone_wire replace
fill ~153 ~155 ~566 ~153 ~155 ~578 minecraft:redstone_wire replace
fill ~156 ~155 ~566 ~156 ~155 ~578 minecraft:redstone_wire replace
fill ~159 ~155 ~566 ~159 ~155 ~578 minecraft:redstone_wire replace
fill ~162 ~155 ~566 ~162 ~155 ~578 minecraft:redstone_wire replace
fill ~165 ~155 ~566 ~165 ~155 ~578 minecraft:redstone_wire replace
fill ~168 ~155 ~566 ~168 ~155 ~578 minecraft:redstone_wire replace
fill ~171 ~155 ~566 ~171 ~155 ~578 minecraft:redstone_wire replace
fill ~174 ~155 ~566 ~174 ~155 ~578 minecraft:redstone_wire replace
fill ~177 ~155 ~566 ~177 ~155 ~578 minecraft:redstone_wire replace
fill ~180 ~155 ~566 ~180 ~155 ~578 minecraft:redstone_wire replace
fill ~183 ~155 ~566 ~183 ~155 ~578 minecraft:redstone_wire replace
fill ~186 ~155 ~566 ~186 ~155 ~578 minecraft:redstone_wire replace
fill ~189 ~155 ~566 ~189 ~155 ~578 minecraft:redstone_wire replace
fill ~192 ~155 ~566 ~192 ~155 ~578 minecraft:redstone_wire replace
fill ~195 ~155 ~566 ~195 ~155 ~578 minecraft:redstone_wire replace
fill ~198 ~155 ~566 ~198 ~155 ~578 minecraft:redstone_wire replace
fill ~201 ~155 ~566 ~201 ~155 ~578 minecraft:redstone_wire replace
fill ~204 ~155 ~566 ~204 ~155 ~578 minecraft:redstone_wire replace
fill ~207 ~155 ~566 ~207 ~155 ~578 minecraft:redstone_wire replace
fill ~210 ~155 ~566 ~210 ~155 ~578 minecraft:redstone_wire replace
fill ~213 ~155 ~566 ~213 ~155 ~578 minecraft:redstone_wire replace
fill ~216 ~155 ~566 ~216 ~155 ~578 minecraft:redstone_wire replace
fill ~219 ~155 ~566 ~219 ~155 ~578 minecraft:redstone_wire replace
fill ~222 ~155 ~566 ~222 ~155 ~578 minecraft:redstone_wire replace
fill ~225 ~155 ~566 ~225 ~155 ~578 minecraft:redstone_wire replace
fill ~228 ~155 ~566 ~228 ~155 ~578 minecraft:redstone_wire replace
fill ~231 ~155 ~566 ~231 ~155 ~578 minecraft:redstone_wire replace
fill ~234 ~155 ~566 ~234 ~155 ~578 minecraft:redstone_wire replace
fill ~237 ~155 ~566 ~237 ~155 ~578 minecraft:redstone_wire replace
fill ~240 ~155 ~566 ~240 ~155 ~578 minecraft:redstone_wire replace
fill ~243 ~155 ~566 ~243 ~155 ~578 minecraft:redstone_wire replace
fill ~246 ~155 ~566 ~246 ~155 ~578 minecraft:redstone_wire replace
fill ~249 ~155 ~566 ~249 ~155 ~578 minecraft:redstone_wire replace
fill ~252 ~155 ~566 ~252 ~155 ~578 minecraft:redstone_wire replace
fill ~255 ~155 ~566 ~255 ~155 ~578 minecraft:redstone_wire replace
fill ~258 ~155 ~566 ~258 ~155 ~578 minecraft:redstone_wire replace
fill ~261 ~155 ~566 ~261 ~155 ~578 minecraft:redstone_wire replace
fill ~264 ~155 ~566 ~264 ~155 ~578 minecraft:redstone_wire replace
fill ~267 ~155 ~566 ~267 ~155 ~578 minecraft:redstone_wire replace
fill ~270 ~155 ~566 ~270 ~155 ~578 minecraft:redstone_wire replace
fill ~273 ~155 ~566 ~273 ~155 ~578 minecraft:redstone_wire replace
fill ~276 ~155 ~566 ~276 ~155 ~578 minecraft:redstone_wire replace
fill ~279 ~155 ~566 ~279 ~155 ~578 minecraft:redstone_wire replace
fill ~282 ~155 ~566 ~282 ~155 ~578 minecraft:redstone_wire replace
fill ~285 ~155 ~566 ~285 ~155 ~578 minecraft:redstone_wire replace
fill ~288 ~155 ~566 ~288 ~155 ~578 minecraft:redstone_wire replace
fill ~291 ~155 ~566 ~291 ~155 ~578 minecraft:redstone_wire replace
fill ~294 ~155 ~566 ~294 ~155 ~578 minecraft:redstone_wire replace
fill ~297 ~155 ~566 ~297 ~155 ~578 minecraft:redstone_wire replace
fill ~300 ~155 ~566 ~300 ~155 ~578 minecraft:redstone_wire replace
fill ~303 ~155 ~566 ~303 ~155 ~578 minecraft:redstone_wire replace
fill ~306 ~155 ~566 ~306 ~155 ~578 minecraft:redstone_wire replace
fill ~309 ~155 ~566 ~309 ~155 ~578 minecraft:redstone_wire replace
fill ~312 ~155 ~566 ~312 ~155 ~578 minecraft:redstone_wire replace
fill ~315 ~155 ~566 ~315 ~155 ~578 minecraft:redstone_wire replace
fill ~318 ~155 ~566 ~318 ~155 ~578 minecraft:redstone_wire replace
fill ~321 ~155 ~566 ~321 ~155 ~578 minecraft:redstone_wire replace
fill ~324 ~155 ~566 ~324 ~155 ~578 minecraft:redstone_wire replace
fill ~327 ~155 ~566 ~327 ~155 ~578 minecraft:redstone_wire replace
fill ~330 ~155 ~566 ~330 ~155 ~578 minecraft:redstone_wire replace
fill ~333 ~155 ~566 ~333 ~155 ~578 minecraft:redstone_wire replace
fill ~336 ~155 ~566 ~336 ~155 ~578 minecraft:redstone_wire replace
fill ~339 ~155 ~566 ~339 ~155 ~578 minecraft:redstone_wire replace
fill ~342 ~155 ~566 ~342 ~155 ~578 minecraft:redstone_wire replace
fill ~345 ~155 ~566 ~345 ~155 ~578 minecraft:redstone_wire replace
fill ~348 ~155 ~566 ~348 ~155 ~578 minecraft:redstone_wire replace
fill ~351 ~155 ~566 ~351 ~155 ~578 minecraft:redstone_wire replace
fill ~354 ~155 ~566 ~354 ~155 ~578 minecraft:redstone_wire replace
fill ~357 ~155 ~566 ~357 ~155 ~578 minecraft:redstone_wire replace
fill ~360 ~155 ~566 ~360 ~155 ~578 minecraft:redstone_wire replace
fill ~363 ~155 ~566 ~363 ~155 ~578 minecraft:redstone_wire replace
fill ~366 ~155 ~566 ~366 ~155 ~578 minecraft:redstone_wire replace
fill ~369 ~155 ~566 ~369 ~155 ~578 minecraft:redstone_wire replace
fill ~372 ~155 ~566 ~372 ~155 ~578 minecraft:redstone_wire replace
fill ~375 ~155 ~566 ~375 ~155 ~578 minecraft:redstone_wire replace
fill ~378 ~155 ~566 ~378 ~155 ~578 minecraft:redstone_wire replace
fill ~381 ~155 ~566 ~381 ~155 ~578 minecraft:redstone_wire replace
fill ~384 ~155 ~566 ~384 ~155 ~578 minecraft:redstone_wire replace
fill ~387 ~155 ~566 ~387 ~155 ~578 minecraft:redstone_wire replace
fill ~390 ~155 ~566 ~390 ~155 ~578 minecraft:redstone_wire replace
fill ~393 ~155 ~566 ~393 ~155 ~578 minecraft:redstone_wire replace
fill ~396 ~155 ~566 ~396 ~155 ~578 minecraft:redstone_wire replace
fill ~399 ~155 ~566 ~399 ~155 ~578 minecraft:redstone_wire replace
setblock ~138 ~155 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~580 minecraft:redstone_wire replace
setblock ~144 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~155 ~582 ~144 ~155 ~584 minecraft:redstone_wire replace
fill ~147 ~155 ~582 ~147 ~155 ~588 minecraft:redstone_wire replace
fill ~150 ~155 ~582 ~150 ~155 ~590 minecraft:redstone_wire replace
fill ~153 ~155 ~582 ~153 ~155 ~594 minecraft:redstone_wire replace
fill ~156 ~155 ~582 ~156 ~155 ~594 minecraft:redstone_wire replace
fill ~159 ~155 ~582 ~159 ~155 ~594 minecraft:redstone_wire replace
fill ~162 ~155 ~582 ~162 ~155 ~594 minecraft:redstone_wire replace
fill ~165 ~155 ~582 ~165 ~155 ~594 minecraft:redstone_wire replace
fill ~168 ~155 ~582 ~168 ~155 ~594 minecraft:redstone_wire replace
fill ~171 ~155 ~582 ~171 ~155 ~594 minecraft:redstone_wire replace
fill ~174 ~155 ~582 ~174 ~155 ~594 minecraft:redstone_wire replace
fill ~177 ~155 ~582 ~177 ~155 ~594 minecraft:redstone_wire replace
fill ~180 ~155 ~582 ~180 ~155 ~594 minecraft:redstone_wire replace
fill ~183 ~155 ~582 ~183 ~155 ~594 minecraft:redstone_wire replace
fill ~186 ~155 ~582 ~186 ~155 ~594 minecraft:redstone_wire replace
fill ~189 ~155 ~582 ~189 ~155 ~594 minecraft:redstone_wire replace
fill ~192 ~155 ~582 ~192 ~155 ~594 minecraft:redstone_wire replace
fill ~195 ~155 ~582 ~195 ~155 ~594 minecraft:redstone_wire replace
fill ~198 ~155 ~582 ~198 ~155 ~594 minecraft:redstone_wire replace
fill ~201 ~155 ~582 ~201 ~155 ~594 minecraft:redstone_wire replace
fill ~204 ~155 ~582 ~204 ~155 ~594 minecraft:redstone_wire replace
fill ~207 ~155 ~582 ~207 ~155 ~594 minecraft:redstone_wire replace
fill ~210 ~155 ~582 ~210 ~155 ~594 minecraft:redstone_wire replace
fill ~213 ~155 ~582 ~213 ~155 ~594 minecraft:redstone_wire replace
fill ~216 ~155 ~582 ~216 ~155 ~594 minecraft:redstone_wire replace
fill ~219 ~155 ~582 ~219 ~155 ~594 minecraft:redstone_wire replace
fill ~222 ~155 ~582 ~222 ~155 ~594 minecraft:redstone_wire replace
fill ~225 ~155 ~582 ~225 ~155 ~594 minecraft:redstone_wire replace
fill ~228 ~155 ~582 ~228 ~155 ~594 minecraft:redstone_wire replace
fill ~231 ~155 ~582 ~231 ~155 ~594 minecraft:redstone_wire replace
fill ~234 ~155 ~582 ~234 ~155 ~594 minecraft:redstone_wire replace
fill ~237 ~155 ~582 ~237 ~155 ~594 minecraft:redstone_wire replace
fill ~240 ~155 ~582 ~240 ~155 ~594 minecraft:redstone_wire replace
fill ~243 ~155 ~582 ~243 ~155 ~594 minecraft:redstone_wire replace
fill ~246 ~155 ~582 ~246 ~155 ~594 minecraft:redstone_wire replace
fill ~249 ~155 ~582 ~249 ~155 ~594 minecraft:redstone_wire replace
fill ~252 ~155 ~582 ~252 ~155 ~594 minecraft:redstone_wire replace
fill ~255 ~155 ~582 ~255 ~155 ~594 minecraft:redstone_wire replace
fill ~258 ~155 ~582 ~258 ~155 ~594 minecraft:redstone_wire replace
fill ~261 ~155 ~582 ~261 ~155 ~594 minecraft:redstone_wire replace
fill ~264 ~155 ~582 ~264 ~155 ~594 minecraft:redstone_wire replace
fill ~267 ~155 ~582 ~267 ~155 ~594 minecraft:redstone_wire replace
fill ~270 ~155 ~582 ~270 ~155 ~594 minecraft:redstone_wire replace
fill ~273 ~155 ~582 ~273 ~155 ~594 minecraft:redstone_wire replace
fill ~276 ~155 ~582 ~276 ~155 ~594 minecraft:redstone_wire replace
fill ~279 ~155 ~582 ~279 ~155 ~594 minecraft:redstone_wire replace
fill ~282 ~155 ~582 ~282 ~155 ~594 minecraft:redstone_wire replace
fill ~285 ~155 ~582 ~285 ~155 ~594 minecraft:redstone_wire replace
fill ~288 ~155 ~582 ~288 ~155 ~594 minecraft:redstone_wire replace
fill ~291 ~155 ~582 ~291 ~155 ~594 minecraft:redstone_wire replace
fill ~294 ~155 ~582 ~294 ~155 ~594 minecraft:redstone_wire replace
fill ~297 ~155 ~582 ~297 ~155 ~594 minecraft:redstone_wire replace
fill ~300 ~155 ~582 ~300 ~155 ~594 minecraft:redstone_wire replace
fill ~303 ~155 ~582 ~303 ~155 ~594 minecraft:redstone_wire replace
fill ~306 ~155 ~582 ~306 ~155 ~594 minecraft:redstone_wire replace
fill ~309 ~155 ~582 ~309 ~155 ~594 minecraft:redstone_wire replace
fill ~312 ~155 ~582 ~312 ~155 ~594 minecraft:redstone_wire replace
fill ~315 ~155 ~582 ~315 ~155 ~594 minecraft:redstone_wire replace
fill ~318 ~155 ~582 ~318 ~155 ~594 minecraft:redstone_wire replace
fill ~321 ~155 ~582 ~321 ~155 ~594 minecraft:redstone_wire replace
fill ~324 ~155 ~582 ~324 ~155 ~594 minecraft:redstone_wire replace
fill ~327 ~155 ~582 ~327 ~155 ~594 minecraft:redstone_wire replace
fill ~330 ~155 ~582 ~330 ~155 ~594 minecraft:redstone_wire replace
fill ~333 ~155 ~582 ~333 ~155 ~594 minecraft:redstone_wire replace
fill ~336 ~155 ~582 ~336 ~155 ~594 minecraft:redstone_wire replace
fill ~339 ~155 ~582 ~339 ~155 ~594 minecraft:redstone_wire replace
fill ~342 ~155 ~582 ~342 ~155 ~594 minecraft:redstone_wire replace
fill ~345 ~155 ~582 ~345 ~155 ~594 minecraft:redstone_wire replace
fill ~348 ~155 ~582 ~348 ~155 ~594 minecraft:redstone_wire replace
fill ~351 ~155 ~582 ~351 ~155 ~594 minecraft:redstone_wire replace
fill ~354 ~155 ~582 ~354 ~155 ~594 minecraft:redstone_wire replace
fill ~357 ~155 ~582 ~357 ~155 ~594 minecraft:redstone_wire replace
fill ~360 ~155 ~582 ~360 ~155 ~594 minecraft:redstone_wire replace
fill ~363 ~155 ~582 ~363 ~155 ~594 minecraft:redstone_wire replace
fill ~366 ~155 ~582 ~366 ~155 ~594 minecraft:redstone_wire replace
fill ~369 ~155 ~582 ~369 ~155 ~594 minecraft:redstone_wire replace
fill ~372 ~155 ~582 ~372 ~155 ~594 minecraft:redstone_wire replace
fill ~375 ~155 ~582 ~375 ~155 ~594 minecraft:redstone_wire replace
fill ~378 ~155 ~582 ~378 ~155 ~594 minecraft:redstone_wire replace
fill ~381 ~155 ~582 ~381 ~155 ~594 minecraft:redstone_wire replace
fill ~384 ~155 ~582 ~384 ~155 ~594 minecraft:redstone_wire replace
fill ~387 ~155 ~582 ~387 ~155 ~594 minecraft:redstone_wire replace
fill ~390 ~155 ~582 ~390 ~155 ~594 minecraft:redstone_wire replace
fill ~393 ~155 ~582 ~393 ~155 ~594 minecraft:redstone_wire replace
fill ~396 ~155 ~582 ~396 ~155 ~594 minecraft:redstone_wire replace
fill ~399 ~155 ~582 ~399 ~155 ~594 minecraft:redstone_wire replace
setblock ~150 ~155 ~592 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~596 minecraft:redstone_wire replace
setblock ~156 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~596 ~402 ~155 ~608 minecraft:redstone_wire replace
fill ~405 ~155 ~596 ~405 ~155 ~608 minecraft:redstone_wire replace
fill ~408 ~155 ~596 ~408 ~155 ~608 minecraft:redstone_wire replace
fill ~411 ~155 ~596 ~411 ~155 ~608 minecraft:redstone_wire replace
fill ~414 ~155 ~596 ~414 ~155 ~608 minecraft:redstone_wire replace
fill ~417 ~155 ~596 ~417 ~155 ~608 minecraft:redstone_wire replace
fill ~420 ~155 ~596 ~420 ~155 ~608 minecraft:redstone_wire replace
fill ~423 ~155 ~596 ~423 ~155 ~608 minecraft:redstone_wire replace
fill ~156 ~155 ~598 ~156 ~155 ~600 minecraft:redstone_wire replace
fill ~159 ~155 ~598 ~159 ~155 ~604 minecraft:redstone_wire replace
fill ~162 ~155 ~598 ~162 ~155 ~606 minecraft:redstone_wire replace
fill ~165 ~155 ~598 ~165 ~155 ~610 minecraft:redstone_wire replace
fill ~168 ~155 ~598 ~168 ~155 ~610 minecraft:redstone_wire replace
fill ~171 ~155 ~598 ~171 ~155 ~610 minecraft:redstone_wire replace
fill ~174 ~155 ~598 ~174 ~155 ~610 minecraft:redstone_wire replace
fill ~177 ~155 ~598 ~177 ~155 ~610 minecraft:redstone_wire replace
fill ~180 ~155 ~598 ~180 ~155 ~610 minecraft:redstone_wire replace
fill ~183 ~155 ~598 ~183 ~155 ~610 minecraft:redstone_wire replace
fill ~186 ~155 ~598 ~186 ~155 ~610 minecraft:redstone_wire replace
fill ~189 ~155 ~598 ~189 ~155 ~610 minecraft:redstone_wire replace
fill ~192 ~155 ~598 ~192 ~155 ~610 minecraft:redstone_wire replace
fill ~195 ~155 ~598 ~195 ~155 ~610 minecraft:redstone_wire replace
fill ~198 ~155 ~598 ~198 ~155 ~610 minecraft:redstone_wire replace
fill ~201 ~155 ~598 ~201 ~155 ~610 minecraft:redstone_wire replace
fill ~204 ~155 ~598 ~204 ~155 ~610 minecraft:redstone_wire replace
fill ~207 ~155 ~598 ~207 ~155 ~610 minecraft:redstone_wire replace
fill ~210 ~155 ~598 ~210 ~155 ~610 minecraft:redstone_wire replace
fill ~213 ~155 ~598 ~213 ~155 ~610 minecraft:redstone_wire replace
fill ~216 ~155 ~598 ~216 ~155 ~610 minecraft:redstone_wire replace
fill ~219 ~155 ~598 ~219 ~155 ~610 minecraft:redstone_wire replace
fill ~222 ~155 ~598 ~222 ~155 ~610 minecraft:redstone_wire replace
fill ~225 ~155 ~598 ~225 ~155 ~610 minecraft:redstone_wire replace
fill ~228 ~155 ~598 ~228 ~155 ~610 minecraft:redstone_wire replace
fill ~231 ~155 ~598 ~231 ~155 ~610 minecraft:redstone_wire replace
fill ~234 ~155 ~598 ~234 ~155 ~610 minecraft:redstone_wire replace
fill ~237 ~155 ~598 ~237 ~155 ~610 minecraft:redstone_wire replace
fill ~240 ~155 ~598 ~240 ~155 ~610 minecraft:redstone_wire replace
fill ~243 ~155 ~598 ~243 ~155 ~610 minecraft:redstone_wire replace
fill ~246 ~155 ~598 ~246 ~155 ~610 minecraft:redstone_wire replace
fill ~249 ~155 ~598 ~249 ~155 ~610 minecraft:redstone_wire replace
fill ~252 ~155 ~598 ~252 ~155 ~610 minecraft:redstone_wire replace
fill ~255 ~155 ~598 ~255 ~155 ~610 minecraft:redstone_wire replace
fill ~258 ~155 ~598 ~258 ~155 ~610 minecraft:redstone_wire replace
fill ~261 ~155 ~598 ~261 ~155 ~610 minecraft:redstone_wire replace
fill ~264 ~155 ~598 ~264 ~155 ~610 minecraft:redstone_wire replace
fill ~267 ~155 ~598 ~267 ~155 ~610 minecraft:redstone_wire replace
fill ~270 ~155 ~598 ~270 ~155 ~610 minecraft:redstone_wire replace
fill ~273 ~155 ~598 ~273 ~155 ~610 minecraft:redstone_wire replace
fill ~276 ~155 ~598 ~276 ~155 ~610 minecraft:redstone_wire replace
fill ~279 ~155 ~598 ~279 ~155 ~610 minecraft:redstone_wire replace
fill ~282 ~155 ~598 ~282 ~155 ~610 minecraft:redstone_wire replace
fill ~285 ~155 ~598 ~285 ~155 ~610 minecraft:redstone_wire replace
fill ~288 ~155 ~598 ~288 ~155 ~610 minecraft:redstone_wire replace
fill ~291 ~155 ~598 ~291 ~155 ~610 minecraft:redstone_wire replace
fill ~294 ~155 ~598 ~294 ~155 ~610 minecraft:redstone_wire replace
fill ~297 ~155 ~598 ~297 ~155 ~610 minecraft:redstone_wire replace
fill ~300 ~155 ~598 ~300 ~155 ~610 minecraft:redstone_wire replace
fill ~303 ~155 ~598 ~303 ~155 ~610 minecraft:redstone_wire replace
fill ~306 ~155 ~598 ~306 ~155 ~610 minecraft:redstone_wire replace
fill ~309 ~155 ~598 ~309 ~155 ~610 minecraft:redstone_wire replace
fill ~312 ~155 ~598 ~312 ~155 ~610 minecraft:redstone_wire replace
fill ~315 ~155 ~598 ~315 ~155 ~610 minecraft:redstone_wire replace
fill ~318 ~155 ~598 ~318 ~155 ~610 minecraft:redstone_wire replace
fill ~321 ~155 ~598 ~321 ~155 ~610 minecraft:redstone_wire replace
fill ~324 ~155 ~598 ~324 ~155 ~610 minecraft:redstone_wire replace
fill ~327 ~155 ~598 ~327 ~155 ~610 minecraft:redstone_wire replace
fill ~330 ~155 ~598 ~330 ~155 ~610 minecraft:redstone_wire replace
fill ~333 ~155 ~598 ~333 ~155 ~610 minecraft:redstone_wire replace
fill ~336 ~155 ~598 ~336 ~155 ~610 minecraft:redstone_wire replace
fill ~339 ~155 ~598 ~339 ~155 ~610 minecraft:redstone_wire replace
fill ~342 ~155 ~598 ~342 ~155 ~610 minecraft:redstone_wire replace
fill ~345 ~155 ~598 ~345 ~155 ~610 minecraft:redstone_wire replace
fill ~348 ~155 ~598 ~348 ~155 ~610 minecraft:redstone_wire replace
fill ~351 ~155 ~598 ~351 ~155 ~610 minecraft:redstone_wire replace
fill ~354 ~155 ~598 ~354 ~155 ~610 minecraft:redstone_wire replace
fill ~357 ~155 ~598 ~357 ~155 ~610 minecraft:redstone_wire replace
fill ~360 ~155 ~598 ~360 ~155 ~610 minecraft:redstone_wire replace
fill ~363 ~155 ~598 ~363 ~155 ~610 minecraft:redstone_wire replace
fill ~366 ~155 ~598 ~366 ~155 ~610 minecraft:redstone_wire replace
fill ~369 ~155 ~598 ~369 ~155 ~610 minecraft:redstone_wire replace
fill ~372 ~155 ~598 ~372 ~155 ~610 minecraft:redstone_wire replace
fill ~375 ~155 ~598 ~375 ~155 ~610 minecraft:redstone_wire replace
fill ~378 ~155 ~598 ~378 ~155 ~610 minecraft:redstone_wire replace
fill ~381 ~155 ~598 ~381 ~155 ~610 minecraft:redstone_wire replace
fill ~384 ~155 ~598 ~384 ~155 ~610 minecraft:redstone_wire replace
fill ~387 ~155 ~598 ~387 ~155 ~610 minecraft:redstone_wire replace
fill ~390 ~155 ~598 ~390 ~155 ~610 minecraft:redstone_wire replace
fill ~393 ~155 ~598 ~393 ~155 ~610 minecraft:redstone_wire replace
fill ~396 ~155 ~598 ~396 ~155 ~610 minecraft:redstone_wire replace
fill ~399 ~155 ~598 ~399 ~155 ~610 minecraft:redstone_wire replace
setblock ~162 ~155 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~402 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~612 minecraft:redstone_wire replace
setblock ~168 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~612 ~402 ~155 ~624 minecraft:redstone_wire replace
fill ~405 ~155 ~612 ~405 ~155 ~624 minecraft:redstone_wire replace
fill ~408 ~155 ~612 ~408 ~155 ~624 minecraft:redstone_wire replace
fill ~411 ~155 ~612 ~411 ~155 ~624 minecraft:redstone_wire replace
fill ~414 ~155 ~612 ~414 ~155 ~624 minecraft:redstone_wire replace
fill ~417 ~155 ~612 ~417 ~155 ~624 minecraft:redstone_wire replace
fill ~420 ~155 ~612 ~420 ~155 ~624 minecraft:redstone_wire replace
fill ~423 ~155 ~612 ~423 ~155 ~624 minecraft:redstone_wire replace
fill ~168 ~155 ~614 ~168 ~155 ~616 minecraft:redstone_wire replace
fill ~171 ~155 ~614 ~171 ~155 ~620 minecraft:redstone_wire replace
fill ~174 ~155 ~614 ~174 ~155 ~622 minecraft:redstone_wire replace
fill ~177 ~155 ~614 ~177 ~155 ~626 minecraft:redstone_wire replace
fill ~180 ~155 ~614 ~180 ~155 ~626 minecraft:redstone_wire replace
fill ~183 ~155 ~614 ~183 ~155 ~626 minecraft:redstone_wire replace
fill ~186 ~155 ~614 ~186 ~155 ~626 minecraft:redstone_wire replace
fill ~189 ~155 ~614 ~189 ~155 ~626 minecraft:redstone_wire replace
fill ~192 ~155 ~614 ~192 ~155 ~626 minecraft:redstone_wire replace
fill ~195 ~155 ~614 ~195 ~155 ~626 minecraft:redstone_wire replace
fill ~198 ~155 ~614 ~198 ~155 ~626 minecraft:redstone_wire replace
fill ~201 ~155 ~614 ~201 ~155 ~626 minecraft:redstone_wire replace
fill ~204 ~155 ~614 ~204 ~155 ~626 minecraft:redstone_wire replace
fill ~207 ~155 ~614 ~207 ~155 ~626 minecraft:redstone_wire replace
fill ~210 ~155 ~614 ~210 ~155 ~626 minecraft:redstone_wire replace
fill ~213 ~155 ~614 ~213 ~155 ~626 minecraft:redstone_wire replace
fill ~216 ~155 ~614 ~216 ~155 ~626 minecraft:redstone_wire replace
fill ~219 ~155 ~614 ~219 ~155 ~626 minecraft:redstone_wire replace
fill ~222 ~155 ~614 ~222 ~155 ~626 minecraft:redstone_wire replace
fill ~225 ~155 ~614 ~225 ~155 ~626 minecraft:redstone_wire replace
fill ~228 ~155 ~614 ~228 ~155 ~626 minecraft:redstone_wire replace
fill ~231 ~155 ~614 ~231 ~155 ~626 minecraft:redstone_wire replace
fill ~234 ~155 ~614 ~234 ~155 ~626 minecraft:redstone_wire replace
fill ~237 ~155 ~614 ~237 ~155 ~626 minecraft:redstone_wire replace
fill ~240 ~155 ~614 ~240 ~155 ~626 minecraft:redstone_wire replace
fill ~243 ~155 ~614 ~243 ~155 ~626 minecraft:redstone_wire replace
fill ~246 ~155 ~614 ~246 ~155 ~626 minecraft:redstone_wire replace
fill ~249 ~155 ~614 ~249 ~155 ~626 minecraft:redstone_wire replace
fill ~252 ~155 ~614 ~252 ~155 ~626 minecraft:redstone_wire replace
fill ~255 ~155 ~614 ~255 ~155 ~626 minecraft:redstone_wire replace
fill ~258 ~155 ~614 ~258 ~155 ~626 minecraft:redstone_wire replace
fill ~261 ~155 ~614 ~261 ~155 ~626 minecraft:redstone_wire replace
fill ~264 ~155 ~614 ~264 ~155 ~626 minecraft:redstone_wire replace
fill ~267 ~155 ~614 ~267 ~155 ~626 minecraft:redstone_wire replace
fill ~270 ~155 ~614 ~270 ~155 ~626 minecraft:redstone_wire replace
fill ~273 ~155 ~614 ~273 ~155 ~626 minecraft:redstone_wire replace
fill ~276 ~155 ~614 ~276 ~155 ~626 minecraft:redstone_wire replace
fill ~279 ~155 ~614 ~279 ~155 ~626 minecraft:redstone_wire replace
fill ~282 ~155 ~614 ~282 ~155 ~626 minecraft:redstone_wire replace
fill ~285 ~155 ~614 ~285 ~155 ~626 minecraft:redstone_wire replace
fill ~288 ~155 ~614 ~288 ~155 ~626 minecraft:redstone_wire replace
fill ~291 ~155 ~614 ~291 ~155 ~626 minecraft:redstone_wire replace
fill ~294 ~155 ~614 ~294 ~155 ~626 minecraft:redstone_wire replace
fill ~297 ~155 ~614 ~297 ~155 ~626 minecraft:redstone_wire replace
fill ~300 ~155 ~614 ~300 ~155 ~626 minecraft:redstone_wire replace
fill ~303 ~155 ~614 ~303 ~155 ~626 minecraft:redstone_wire replace
fill ~306 ~155 ~614 ~306 ~155 ~626 minecraft:redstone_wire replace
fill ~309 ~155 ~614 ~309 ~155 ~626 minecraft:redstone_wire replace
fill ~312 ~155 ~614 ~312 ~155 ~626 minecraft:redstone_wire replace
fill ~315 ~155 ~614 ~315 ~155 ~626 minecraft:redstone_wire replace
fill ~318 ~155 ~614 ~318 ~155 ~626 minecraft:redstone_wire replace
fill ~321 ~155 ~614 ~321 ~155 ~626 minecraft:redstone_wire replace
fill ~324 ~155 ~614 ~324 ~155 ~626 minecraft:redstone_wire replace
fill ~327 ~155 ~614 ~327 ~155 ~626 minecraft:redstone_wire replace
fill ~330 ~155 ~614 ~330 ~155 ~626 minecraft:redstone_wire replace
fill ~333 ~155 ~614 ~333 ~155 ~626 minecraft:redstone_wire replace
fill ~336 ~155 ~614 ~336 ~155 ~626 minecraft:redstone_wire replace
fill ~339 ~155 ~614 ~339 ~155 ~626 minecraft:redstone_wire replace
fill ~342 ~155 ~614 ~342 ~155 ~626 minecraft:redstone_wire replace
fill ~345 ~155 ~614 ~345 ~155 ~626 minecraft:redstone_wire replace
fill ~348 ~155 ~614 ~348 ~155 ~626 minecraft:redstone_wire replace
fill ~351 ~155 ~614 ~351 ~155 ~626 minecraft:redstone_wire replace
fill ~354 ~155 ~614 ~354 ~155 ~626 minecraft:redstone_wire replace
fill ~357 ~155 ~614 ~357 ~155 ~626 minecraft:redstone_wire replace
fill ~360 ~155 ~614 ~360 ~155 ~626 minecraft:redstone_wire replace
fill ~363 ~155 ~614 ~363 ~155 ~626 minecraft:redstone_wire replace
fill ~366 ~155 ~614 ~366 ~155 ~626 minecraft:redstone_wire replace
fill ~369 ~155 ~614 ~369 ~155 ~626 minecraft:redstone_wire replace
fill ~372 ~155 ~614 ~372 ~155 ~626 minecraft:redstone_wire replace
fill ~375 ~155 ~614 ~375 ~155 ~626 minecraft:redstone_wire replace
fill ~378 ~155 ~614 ~378 ~155 ~626 minecraft:redstone_wire replace
fill ~381 ~155 ~614 ~381 ~155 ~626 minecraft:redstone_wire replace
fill ~384 ~155 ~614 ~384 ~155 ~626 minecraft:redstone_wire replace
fill ~387 ~155 ~614 ~387 ~155 ~626 minecraft:redstone_wire replace
fill ~390 ~155 ~614 ~390 ~155 ~626 minecraft:redstone_wire replace
fill ~393 ~155 ~614 ~393 ~155 ~626 minecraft:redstone_wire replace
fill ~396 ~155 ~614 ~396 ~155 ~626 minecraft:redstone_wire replace
fill ~399 ~155 ~614 ~399 ~155 ~626 minecraft:redstone_wire replace
setblock ~174 ~155 ~624 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~402 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~628 minecraft:redstone_wire replace
setblock ~180 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~628 ~402 ~155 ~640 minecraft:redstone_wire replace
fill ~405 ~155 ~628 ~405 ~155 ~640 minecraft:redstone_wire replace
fill ~408 ~155 ~628 ~408 ~155 ~640 minecraft:redstone_wire replace
fill ~411 ~155 ~628 ~411 ~155 ~640 minecraft:redstone_wire replace
fill ~414 ~155 ~628 ~414 ~155 ~640 minecraft:redstone_wire replace
fill ~417 ~155 ~628 ~417 ~155 ~640 minecraft:redstone_wire replace
fill ~420 ~155 ~628 ~420 ~155 ~640 minecraft:redstone_wire replace
fill ~423 ~155 ~628 ~423 ~155 ~640 minecraft:redstone_wire replace
fill ~180 ~155 ~630 ~180 ~155 ~632 minecraft:redstone_wire replace
fill ~183 ~155 ~630 ~183 ~155 ~636 minecraft:redstone_wire replace
fill ~186 ~155 ~630 ~186 ~155 ~638 minecraft:redstone_wire replace
fill ~189 ~155 ~630 ~189 ~155 ~642 minecraft:redstone_wire replace
fill ~192 ~155 ~630 ~192 ~155 ~642 minecraft:redstone_wire replace
fill ~195 ~155 ~630 ~195 ~155 ~642 minecraft:redstone_wire replace
fill ~198 ~155 ~630 ~198 ~155 ~642 minecraft:redstone_wire replace
fill ~201 ~155 ~630 ~201 ~155 ~642 minecraft:redstone_wire replace
fill ~204 ~155 ~630 ~204 ~155 ~642 minecraft:redstone_wire replace
fill ~207 ~155 ~630 ~207 ~155 ~642 minecraft:redstone_wire replace
fill ~210 ~155 ~630 ~210 ~155 ~642 minecraft:redstone_wire replace
fill ~213 ~155 ~630 ~213 ~155 ~642 minecraft:redstone_wire replace
fill ~216 ~155 ~630 ~216 ~155 ~642 minecraft:redstone_wire replace
fill ~219 ~155 ~630 ~219 ~155 ~642 minecraft:redstone_wire replace
fill ~222 ~155 ~630 ~222 ~155 ~642 minecraft:redstone_wire replace
fill ~225 ~155 ~630 ~225 ~155 ~642 minecraft:redstone_wire replace
fill ~228 ~155 ~630 ~228 ~155 ~642 minecraft:redstone_wire replace
fill ~231 ~155 ~630 ~231 ~155 ~642 minecraft:redstone_wire replace
fill ~234 ~155 ~630 ~234 ~155 ~642 minecraft:redstone_wire replace
fill ~237 ~155 ~630 ~237 ~155 ~642 minecraft:redstone_wire replace
fill ~240 ~155 ~630 ~240 ~155 ~642 minecraft:redstone_wire replace
fill ~243 ~155 ~630 ~243 ~155 ~642 minecraft:redstone_wire replace
fill ~246 ~155 ~630 ~246 ~155 ~642 minecraft:redstone_wire replace
fill ~249 ~155 ~630 ~249 ~155 ~642 minecraft:redstone_wire replace
fill ~252 ~155 ~630 ~252 ~155 ~642 minecraft:redstone_wire replace
fill ~255 ~155 ~630 ~255 ~155 ~642 minecraft:redstone_wire replace
fill ~258 ~155 ~630 ~258 ~155 ~642 minecraft:redstone_wire replace
fill ~261 ~155 ~630 ~261 ~155 ~642 minecraft:redstone_wire replace
fill ~264 ~155 ~630 ~264 ~155 ~642 minecraft:redstone_wire replace
fill ~267 ~155 ~630 ~267 ~155 ~642 minecraft:redstone_wire replace
fill ~270 ~155 ~630 ~270 ~155 ~642 minecraft:redstone_wire replace
fill ~273 ~155 ~630 ~273 ~155 ~642 minecraft:redstone_wire replace
fill ~276 ~155 ~630 ~276 ~155 ~642 minecraft:redstone_wire replace
fill ~279 ~155 ~630 ~279 ~155 ~642 minecraft:redstone_wire replace
fill ~282 ~155 ~630 ~282 ~155 ~642 minecraft:redstone_wire replace
fill ~285 ~155 ~630 ~285 ~155 ~642 minecraft:redstone_wire replace
fill ~288 ~155 ~630 ~288 ~155 ~642 minecraft:redstone_wire replace
fill ~291 ~155 ~630 ~291 ~155 ~642 minecraft:redstone_wire replace
fill ~294 ~155 ~630 ~294 ~155 ~642 minecraft:redstone_wire replace
fill ~297 ~155 ~630 ~297 ~155 ~642 minecraft:redstone_wire replace
fill ~300 ~155 ~630 ~300 ~155 ~642 minecraft:redstone_wire replace
fill ~303 ~155 ~630 ~303 ~155 ~642 minecraft:redstone_wire replace
fill ~306 ~155 ~630 ~306 ~155 ~642 minecraft:redstone_wire replace
fill ~309 ~155 ~630 ~309 ~155 ~642 minecraft:redstone_wire replace
fill ~312 ~155 ~630 ~312 ~155 ~642 minecraft:redstone_wire replace
fill ~315 ~155 ~630 ~315 ~155 ~642 minecraft:redstone_wire replace
fill ~318 ~155 ~630 ~318 ~155 ~642 minecraft:redstone_wire replace
fill ~321 ~155 ~630 ~321 ~155 ~642 minecraft:redstone_wire replace
fill ~324 ~155 ~630 ~324 ~155 ~642 minecraft:redstone_wire replace
fill ~327 ~155 ~630 ~327 ~155 ~642 minecraft:redstone_wire replace
fill ~330 ~155 ~630 ~330 ~155 ~642 minecraft:redstone_wire replace
fill ~333 ~155 ~630 ~333 ~155 ~642 minecraft:redstone_wire replace
fill ~336 ~155 ~630 ~336 ~155 ~642 minecraft:redstone_wire replace
fill ~339 ~155 ~630 ~339 ~155 ~642 minecraft:redstone_wire replace
fill ~342 ~155 ~630 ~342 ~155 ~642 minecraft:redstone_wire replace
fill ~345 ~155 ~630 ~345 ~155 ~642 minecraft:redstone_wire replace
fill ~348 ~155 ~630 ~348 ~155 ~642 minecraft:redstone_wire replace
fill ~351 ~155 ~630 ~351 ~155 ~642 minecraft:redstone_wire replace
fill ~354 ~155 ~630 ~354 ~155 ~642 minecraft:redstone_wire replace
fill ~357 ~155 ~630 ~357 ~155 ~642 minecraft:redstone_wire replace
fill ~360 ~155 ~630 ~360 ~155 ~642 minecraft:redstone_wire replace
fill ~363 ~155 ~630 ~363 ~155 ~642 minecraft:redstone_wire replace
fill ~366 ~155 ~630 ~366 ~155 ~642 minecraft:redstone_wire replace
fill ~369 ~155 ~630 ~369 ~155 ~642 minecraft:redstone_wire replace
fill ~372 ~155 ~630 ~372 ~155 ~642 minecraft:redstone_wire replace
fill ~375 ~155 ~630 ~375 ~155 ~642 minecraft:redstone_wire replace
fill ~378 ~155 ~630 ~378 ~155 ~642 minecraft:redstone_wire replace
fill ~381 ~155 ~630 ~381 ~155 ~642 minecraft:redstone_wire replace
fill ~384 ~155 ~630 ~384 ~155 ~642 minecraft:redstone_wire replace
fill ~387 ~155 ~630 ~387 ~155 ~642 minecraft:redstone_wire replace
fill ~390 ~155 ~630 ~390 ~155 ~642 minecraft:redstone_wire replace
fill ~393 ~155 ~630 ~393 ~155 ~642 minecraft:redstone_wire replace
fill ~396 ~155 ~630 ~396 ~155 ~642 minecraft:redstone_wire replace
fill ~399 ~155 ~630 ~399 ~155 ~642 minecraft:redstone_wire replace
setblock ~186 ~155 ~640 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~432 ~155 ~640 ~432 ~155 ~652 minecraft:redstone_wire replace
setblock ~402 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~644 minecraft:redstone_wire replace
setblock ~192 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~644 ~402 ~155 ~656 minecraft:redstone_wire replace
fill ~405 ~155 ~644 ~405 ~155 ~656 minecraft:redstone_wire replace
fill ~408 ~155 ~644 ~408 ~155 ~656 minecraft:redstone_wire replace
fill ~411 ~155 ~644 ~411 ~155 ~656 minecraft:redstone_wire replace
fill ~414 ~155 ~644 ~414 ~155 ~656 minecraft:redstone_wire replace
fill ~417 ~155 ~644 ~417 ~155 ~656 minecraft:redstone_wire replace
fill ~420 ~155 ~644 ~420 ~155 ~656 minecraft:redstone_wire replace
fill ~423 ~155 ~644 ~423 ~155 ~656 minecraft:redstone_wire replace
fill ~192 ~155 ~646 ~192 ~155 ~648 minecraft:redstone_wire replace
fill ~195 ~155 ~646 ~195 ~155 ~652 minecraft:redstone_wire replace
fill ~198 ~155 ~646 ~198 ~155 ~654 minecraft:redstone_wire replace
fill ~201 ~155 ~646 ~201 ~155 ~658 minecraft:redstone_wire replace
fill ~204 ~155 ~646 ~204 ~155 ~658 minecraft:redstone_wire replace
fill ~207 ~155 ~646 ~207 ~155 ~658 minecraft:redstone_wire replace
fill ~210 ~155 ~646 ~210 ~155 ~658 minecraft:redstone_wire replace
fill ~213 ~155 ~646 ~213 ~155 ~658 minecraft:redstone_wire replace
fill ~216 ~155 ~646 ~216 ~155 ~658 minecraft:redstone_wire replace
fill ~219 ~155 ~646 ~219 ~155 ~658 minecraft:redstone_wire replace
fill ~222 ~155 ~646 ~222 ~155 ~658 minecraft:redstone_wire replace
fill ~225 ~155 ~646 ~225 ~155 ~658 minecraft:redstone_wire replace
fill ~228 ~155 ~646 ~228 ~155 ~658 minecraft:redstone_wire replace
fill ~231 ~155 ~646 ~231 ~155 ~658 minecraft:redstone_wire replace
fill ~234 ~155 ~646 ~234 ~155 ~658 minecraft:redstone_wire replace
fill ~237 ~155 ~646 ~237 ~155 ~658 minecraft:redstone_wire replace
fill ~240 ~155 ~646 ~240 ~155 ~658 minecraft:redstone_wire replace
fill ~243 ~155 ~646 ~243 ~155 ~658 minecraft:redstone_wire replace
fill ~246 ~155 ~646 ~246 ~155 ~658 minecraft:redstone_wire replace
fill ~249 ~155 ~646 ~249 ~155 ~658 minecraft:redstone_wire replace
fill ~252 ~155 ~646 ~252 ~155 ~658 minecraft:redstone_wire replace
fill ~255 ~155 ~646 ~255 ~155 ~658 minecraft:redstone_wire replace
fill ~258 ~155 ~646 ~258 ~155 ~658 minecraft:redstone_wire replace
fill ~261 ~155 ~646 ~261 ~155 ~658 minecraft:redstone_wire replace
fill ~264 ~155 ~646 ~264 ~155 ~658 minecraft:redstone_wire replace
fill ~267 ~155 ~646 ~267 ~155 ~658 minecraft:redstone_wire replace
fill ~270 ~155 ~646 ~270 ~155 ~658 minecraft:redstone_wire replace
fill ~273 ~155 ~646 ~273 ~155 ~658 minecraft:redstone_wire replace
fill ~276 ~155 ~646 ~276 ~155 ~658 minecraft:redstone_wire replace
fill ~279 ~155 ~646 ~279 ~155 ~658 minecraft:redstone_wire replace
fill ~282 ~155 ~646 ~282 ~155 ~658 minecraft:redstone_wire replace
fill ~285 ~155 ~646 ~285 ~155 ~658 minecraft:redstone_wire replace
fill ~288 ~155 ~646 ~288 ~155 ~658 minecraft:redstone_wire replace
fill ~291 ~155 ~646 ~291 ~155 ~658 minecraft:redstone_wire replace
fill ~294 ~155 ~646 ~294 ~155 ~658 minecraft:redstone_wire replace
fill ~297 ~155 ~646 ~297 ~155 ~658 minecraft:redstone_wire replace
fill ~300 ~155 ~646 ~300 ~155 ~658 minecraft:redstone_wire replace
fill ~303 ~155 ~646 ~303 ~155 ~658 minecraft:redstone_wire replace
fill ~306 ~155 ~646 ~306 ~155 ~658 minecraft:redstone_wire replace
fill ~309 ~155 ~646 ~309 ~155 ~658 minecraft:redstone_wire replace
fill ~312 ~155 ~646 ~312 ~155 ~658 minecraft:redstone_wire replace
fill ~315 ~155 ~646 ~315 ~155 ~658 minecraft:redstone_wire replace
fill ~318 ~155 ~646 ~318 ~155 ~658 minecraft:redstone_wire replace
fill ~321 ~155 ~646 ~321 ~155 ~658 minecraft:redstone_wire replace
fill ~324 ~155 ~646 ~324 ~155 ~658 minecraft:redstone_wire replace
fill ~327 ~155 ~646 ~327 ~155 ~658 minecraft:redstone_wire replace
fill ~330 ~155 ~646 ~330 ~155 ~658 minecraft:redstone_wire replace
fill ~333 ~155 ~646 ~333 ~155 ~658 minecraft:redstone_wire replace
fill ~336 ~155 ~646 ~336 ~155 ~658 minecraft:redstone_wire replace
fill ~339 ~155 ~646 ~339 ~155 ~658 minecraft:redstone_wire replace
fill ~342 ~155 ~646 ~342 ~155 ~658 minecraft:redstone_wire replace
fill ~345 ~155 ~646 ~345 ~155 ~658 minecraft:redstone_wire replace
fill ~348 ~155 ~646 ~348 ~155 ~658 minecraft:redstone_wire replace
fill ~351 ~155 ~646 ~351 ~155 ~658 minecraft:redstone_wire replace
fill ~354 ~155 ~646 ~354 ~155 ~658 minecraft:redstone_wire replace
fill ~357 ~155 ~646 ~357 ~155 ~658 minecraft:redstone_wire replace
fill ~360 ~155 ~646 ~360 ~155 ~658 minecraft:redstone_wire replace
fill ~363 ~155 ~646 ~363 ~155 ~658 minecraft:redstone_wire replace
fill ~366 ~155 ~646 ~366 ~155 ~658 minecraft:redstone_wire replace
fill ~369 ~155 ~646 ~369 ~155 ~658 minecraft:redstone_wire replace
fill ~372 ~155 ~646 ~372 ~155 ~658 minecraft:redstone_wire replace
fill ~375 ~155 ~646 ~375 ~155 ~658 minecraft:redstone_wire replace
fill ~378 ~155 ~646 ~378 ~155 ~658 minecraft:redstone_wire replace
fill ~381 ~155 ~646 ~381 ~155 ~658 minecraft:redstone_wire replace
fill ~384 ~155 ~646 ~384 ~155 ~658 minecraft:redstone_wire replace
fill ~387 ~155 ~646 ~387 ~155 ~658 minecraft:redstone_wire replace
fill ~390 ~155 ~646 ~390 ~155 ~658 minecraft:redstone_wire replace
fill ~393 ~155 ~646 ~393 ~155 ~658 minecraft:redstone_wire replace
fill ~396 ~155 ~646 ~396 ~155 ~658 minecraft:redstone_wire replace
fill ~399 ~155 ~646 ~399 ~155 ~658 minecraft:redstone_wire replace
fill ~426 ~155 ~648 ~426 ~155 ~660 minecraft:redstone_wire replace
setblock ~432 ~155 ~654 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~656 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~656 ~429 ~155 ~668 minecraft:redstone_wire replace
fill ~432 ~155 ~656 ~432 ~155 ~668 minecraft:redstone_wire replace
setblock ~402 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~660 minecraft:redstone_wire replace
setblock ~204 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~660 ~402 ~155 ~672 minecraft:redstone_wire replace
fill ~405 ~155 ~660 ~405 ~155 ~672 minecraft:redstone_wire replace
fill ~408 ~155 ~660 ~408 ~155 ~672 minecraft:redstone_wire replace
fill ~411 ~155 ~660 ~411 ~155 ~672 minecraft:redstone_wire replace
fill ~414 ~155 ~660 ~414 ~155 ~672 minecraft:redstone_wire replace
fill ~417 ~155 ~660 ~417 ~155 ~672 minecraft:redstone_wire replace
fill ~420 ~155 ~660 ~420 ~155 ~672 minecraft:redstone_wire replace
fill ~423 ~155 ~660 ~423 ~155 ~672 minecraft:redstone_wire replace
fill ~204 ~155 ~662 ~204 ~155 ~664 minecraft:redstone_wire replace
fill ~207 ~155 ~662 ~207 ~155 ~668 minecraft:redstone_wire replace
fill ~210 ~155 ~662 ~210 ~155 ~670 minecraft:redstone_wire replace
fill ~213 ~155 ~662 ~213 ~155 ~674 minecraft:redstone_wire replace
fill ~216 ~155 ~662 ~216 ~155 ~674 minecraft:redstone_wire replace
fill ~219 ~155 ~662 ~219 ~155 ~674 minecraft:redstone_wire replace
fill ~222 ~155 ~662 ~222 ~155 ~674 minecraft:redstone_wire replace
fill ~225 ~155 ~662 ~225 ~155 ~674 minecraft:redstone_wire replace
fill ~228 ~155 ~662 ~228 ~155 ~674 minecraft:redstone_wire replace
fill ~231 ~155 ~662 ~231 ~155 ~674 minecraft:redstone_wire replace
fill ~234 ~155 ~662 ~234 ~155 ~674 minecraft:redstone_wire replace
fill ~237 ~155 ~662 ~237 ~155 ~674 minecraft:redstone_wire replace
fill ~240 ~155 ~662 ~240 ~155 ~674 minecraft:redstone_wire replace
fill ~243 ~155 ~662 ~243 ~155 ~674 minecraft:redstone_wire replace
fill ~246 ~155 ~662 ~246 ~155 ~674 minecraft:redstone_wire replace
fill ~249 ~155 ~662 ~249 ~155 ~674 minecraft:redstone_wire replace
fill ~252 ~155 ~662 ~252 ~155 ~674 minecraft:redstone_wire replace
fill ~255 ~155 ~662 ~255 ~155 ~674 minecraft:redstone_wire replace
fill ~258 ~155 ~662 ~258 ~155 ~674 minecraft:redstone_wire replace
fill ~261 ~155 ~662 ~261 ~155 ~674 minecraft:redstone_wire replace
fill ~264 ~155 ~662 ~264 ~155 ~674 minecraft:redstone_wire replace
fill ~267 ~155 ~662 ~267 ~155 ~674 minecraft:redstone_wire replace
fill ~270 ~155 ~662 ~270 ~155 ~674 minecraft:redstone_wire replace
fill ~273 ~155 ~662 ~273 ~155 ~674 minecraft:redstone_wire replace
fill ~276 ~155 ~662 ~276 ~155 ~674 minecraft:redstone_wire replace
fill ~279 ~155 ~662 ~279 ~155 ~674 minecraft:redstone_wire replace
fill ~282 ~155 ~662 ~282 ~155 ~674 minecraft:redstone_wire replace
fill ~285 ~155 ~662 ~285 ~155 ~674 minecraft:redstone_wire replace
fill ~288 ~155 ~662 ~288 ~155 ~674 minecraft:redstone_wire replace
fill ~291 ~155 ~662 ~291 ~155 ~674 minecraft:redstone_wire replace
fill ~294 ~155 ~662 ~294 ~155 ~674 minecraft:redstone_wire replace
fill ~297 ~155 ~662 ~297 ~155 ~674 minecraft:redstone_wire replace
fill ~300 ~155 ~662 ~300 ~155 ~674 minecraft:redstone_wire replace
fill ~303 ~155 ~662 ~303 ~155 ~674 minecraft:redstone_wire replace
fill ~306 ~155 ~662 ~306 ~155 ~674 minecraft:redstone_wire replace
fill ~309 ~155 ~662 ~309 ~155 ~674 minecraft:redstone_wire replace
fill ~312 ~155 ~662 ~312 ~155 ~674 minecraft:redstone_wire replace
fill ~315 ~155 ~662 ~315 ~155 ~674 minecraft:redstone_wire replace
fill ~318 ~155 ~662 ~318 ~155 ~674 minecraft:redstone_wire replace
fill ~321 ~155 ~662 ~321 ~155 ~674 minecraft:redstone_wire replace
fill ~324 ~155 ~662 ~324 ~155 ~674 minecraft:redstone_wire replace
fill ~327 ~155 ~662 ~327 ~155 ~674 minecraft:redstone_wire replace
fill ~330 ~155 ~662 ~330 ~155 ~674 minecraft:redstone_wire replace
fill ~333 ~155 ~662 ~333 ~155 ~674 minecraft:redstone_wire replace
fill ~336 ~155 ~662 ~336 ~155 ~674 minecraft:redstone_wire replace
fill ~339 ~155 ~662 ~339 ~155 ~674 minecraft:redstone_wire replace
fill ~342 ~155 ~662 ~342 ~155 ~674 minecraft:redstone_wire replace
fill ~345 ~155 ~662 ~345 ~155 ~674 minecraft:redstone_wire replace
fill ~348 ~155 ~662 ~348 ~155 ~674 minecraft:redstone_wire replace
fill ~351 ~155 ~662 ~351 ~155 ~674 minecraft:redstone_wire replace
fill ~354 ~155 ~662 ~354 ~155 ~674 minecraft:redstone_wire replace
fill ~357 ~155 ~662 ~357 ~155 ~674 minecraft:redstone_wire replace
fill ~360 ~155 ~662 ~360 ~155 ~674 minecraft:redstone_wire replace
fill ~363 ~155 ~662 ~363 ~155 ~674 minecraft:redstone_wire replace
fill ~366 ~155 ~662 ~366 ~155 ~674 minecraft:redstone_wire replace
fill ~369 ~155 ~662 ~369 ~155 ~674 minecraft:redstone_wire replace
fill ~372 ~155 ~662 ~372 ~155 ~674 minecraft:redstone_wire replace
fill ~375 ~155 ~662 ~375 ~155 ~674 minecraft:redstone_wire replace
fill ~378 ~155 ~662 ~378 ~155 ~674 minecraft:redstone_wire replace
fill ~381 ~155 ~662 ~381 ~155 ~674 minecraft:redstone_wire replace
fill ~384 ~155 ~662 ~384 ~155 ~674 minecraft:redstone_wire replace
fill ~387 ~155 ~662 ~387 ~155 ~674 minecraft:redstone_wire replace
fill ~390 ~155 ~662 ~390 ~155 ~674 minecraft:redstone_wire replace
fill ~393 ~155 ~662 ~393 ~155 ~674 minecraft:redstone_wire replace
fill ~396 ~155 ~662 ~396 ~155 ~674 minecraft:redstone_wire replace
fill ~399 ~155 ~662 ~399 ~155 ~674 minecraft:redstone_wire replace
setblock ~426 ~155 ~662 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~664 ~426 ~155 ~676 minecraft:redstone_wire replace
setblock ~429 ~155 ~670 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~670 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~672 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~672 ~429 ~155 ~684 minecraft:redstone_wire replace
fill ~432 ~155 ~672 ~432 ~155 ~684 minecraft:redstone_wire replace
setblock ~402 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~675 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~676 minecraft:redstone_wire replace
setblock ~216 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~676 ~402 ~155 ~688 minecraft:redstone_wire replace
fill ~405 ~155 ~676 ~405 ~155 ~688 minecraft:redstone_wire replace
fill ~408 ~155 ~676 ~408 ~155 ~688 minecraft:redstone_wire replace
fill ~411 ~155 ~676 ~411 ~155 ~688 minecraft:redstone_wire replace
fill ~414 ~155 ~676 ~414 ~155 ~688 minecraft:redstone_wire replace
fill ~417 ~155 ~676 ~417 ~155 ~688 minecraft:redstone_wire replace
fill ~420 ~155 ~676 ~420 ~155 ~688 minecraft:redstone_wire replace
fill ~423 ~155 ~676 ~423 ~155 ~688 minecraft:redstone_wire replace
fill ~216 ~155 ~678 ~216 ~155 ~680 minecraft:redstone_wire replace
fill ~219 ~155 ~678 ~219 ~155 ~684 minecraft:redstone_wire replace
fill ~222 ~155 ~678 ~222 ~155 ~686 minecraft:redstone_wire replace
fill ~225 ~155 ~678 ~225 ~155 ~690 minecraft:redstone_wire replace
fill ~228 ~155 ~678 ~228 ~155 ~690 minecraft:redstone_wire replace
fill ~231 ~155 ~678 ~231 ~155 ~690 minecraft:redstone_wire replace
fill ~234 ~155 ~678 ~234 ~155 ~690 minecraft:redstone_wire replace
fill ~237 ~155 ~678 ~237 ~155 ~690 minecraft:redstone_wire replace
fill ~240 ~155 ~678 ~240 ~155 ~690 minecraft:redstone_wire replace
fill ~243 ~155 ~678 ~243 ~155 ~690 minecraft:redstone_wire replace
fill ~246 ~155 ~678 ~246 ~155 ~690 minecraft:redstone_wire replace
fill ~249 ~155 ~678 ~249 ~155 ~690 minecraft:redstone_wire replace
fill ~252 ~155 ~678 ~252 ~155 ~690 minecraft:redstone_wire replace
fill ~255 ~155 ~678 ~255 ~155 ~690 minecraft:redstone_wire replace
fill ~258 ~155 ~678 ~258 ~155 ~690 minecraft:redstone_wire replace
fill ~261 ~155 ~678 ~261 ~155 ~690 minecraft:redstone_wire replace
fill ~264 ~155 ~678 ~264 ~155 ~690 minecraft:redstone_wire replace
fill ~267 ~155 ~678 ~267 ~155 ~690 minecraft:redstone_wire replace
fill ~270 ~155 ~678 ~270 ~155 ~690 minecraft:redstone_wire replace
fill ~273 ~155 ~678 ~273 ~155 ~690 minecraft:redstone_wire replace
fill ~276 ~155 ~678 ~276 ~155 ~690 minecraft:redstone_wire replace
fill ~279 ~155 ~678 ~279 ~155 ~690 minecraft:redstone_wire replace
fill ~282 ~155 ~678 ~282 ~155 ~690 minecraft:redstone_wire replace
fill ~285 ~155 ~678 ~285 ~155 ~690 minecraft:redstone_wire replace
fill ~288 ~155 ~678 ~288 ~155 ~690 minecraft:redstone_wire replace
fill ~291 ~155 ~678 ~291 ~155 ~690 minecraft:redstone_wire replace
fill ~294 ~155 ~678 ~294 ~155 ~690 minecraft:redstone_wire replace
fill ~297 ~155 ~678 ~297 ~155 ~690 minecraft:redstone_wire replace
fill ~300 ~155 ~678 ~300 ~155 ~690 minecraft:redstone_wire replace
fill ~303 ~155 ~678 ~303 ~155 ~690 minecraft:redstone_wire replace
fill ~306 ~155 ~678 ~306 ~155 ~690 minecraft:redstone_wire replace
fill ~309 ~155 ~678 ~309 ~155 ~690 minecraft:redstone_wire replace
fill ~312 ~155 ~678 ~312 ~155 ~690 minecraft:redstone_wire replace
fill ~315 ~155 ~678 ~315 ~155 ~690 minecraft:redstone_wire replace
fill ~318 ~155 ~678 ~318 ~155 ~690 minecraft:redstone_wire replace
fill ~321 ~155 ~678 ~321 ~155 ~690 minecraft:redstone_wire replace
fill ~324 ~155 ~678 ~324 ~155 ~690 minecraft:redstone_wire replace
fill ~327 ~155 ~678 ~327 ~155 ~690 minecraft:redstone_wire replace
fill ~330 ~155 ~678 ~330 ~155 ~690 minecraft:redstone_wire replace
fill ~333 ~155 ~678 ~333 ~155 ~690 minecraft:redstone_wire replace
fill ~336 ~155 ~678 ~336 ~155 ~690 minecraft:redstone_wire replace
fill ~339 ~155 ~678 ~339 ~155 ~690 minecraft:redstone_wire replace
fill ~342 ~155 ~678 ~342 ~155 ~690 minecraft:redstone_wire replace
fill ~345 ~155 ~678 ~345 ~155 ~690 minecraft:redstone_wire replace
fill ~348 ~155 ~678 ~348 ~155 ~690 minecraft:redstone_wire replace
fill ~351 ~155 ~678 ~351 ~155 ~690 minecraft:redstone_wire replace
fill ~354 ~155 ~678 ~354 ~155 ~690 minecraft:redstone_wire replace
fill ~357 ~155 ~678 ~357 ~155 ~690 minecraft:redstone_wire replace
fill ~360 ~155 ~678 ~360 ~155 ~690 minecraft:redstone_wire replace
fill ~363 ~155 ~678 ~363 ~155 ~690 minecraft:redstone_wire replace
fill ~366 ~155 ~678 ~366 ~155 ~690 minecraft:redstone_wire replace
fill ~369 ~155 ~678 ~369 ~155 ~690 minecraft:redstone_wire replace
fill ~372 ~155 ~678 ~372 ~155 ~690 minecraft:redstone_wire replace
fill ~375 ~155 ~678 ~375 ~155 ~690 minecraft:redstone_wire replace
fill ~378 ~155 ~678 ~378 ~155 ~690 minecraft:redstone_wire replace
fill ~381 ~155 ~678 ~381 ~155 ~690 minecraft:redstone_wire replace
fill ~384 ~155 ~678 ~384 ~155 ~690 minecraft:redstone_wire replace
fill ~387 ~155 ~678 ~387 ~155 ~690 minecraft:redstone_wire replace
fill ~390 ~155 ~678 ~390 ~155 ~690 minecraft:redstone_wire replace
fill ~393 ~155 ~678 ~393 ~155 ~690 minecraft:redstone_wire replace
fill ~396 ~155 ~678 ~396 ~155 ~690 minecraft:redstone_wire replace
fill ~399 ~155 ~678 ~399 ~155 ~690 minecraft:redstone_wire replace
setblock ~426 ~155 ~678 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~680 ~426 ~155 ~692 minecraft:redstone_wire replace
setblock ~429 ~155 ~686 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~686 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~688 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~688 ~429 ~155 ~700 minecraft:redstone_wire replace
fill ~432 ~155 ~688 ~432 ~155 ~700 minecraft:redstone_wire replace
setblock ~402 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~691 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~692 minecraft:redstone_wire replace
setblock ~228 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
