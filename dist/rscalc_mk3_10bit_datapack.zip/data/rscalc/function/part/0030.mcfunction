fill ~96 ~90 ~612 ~96 ~90 ~616 minecraft:light_gray_concrete replace
fill ~99 ~90 ~616 ~99 ~90 ~620 minecraft:light_gray_concrete replace
fill ~102 ~90 ~620 ~102 ~90 ~624 minecraft:light_gray_concrete replace
fill ~108 ~90 ~624 ~108 ~90 ~628 minecraft:light_gray_concrete replace
fill ~105 ~90 ~632 ~105 ~90 ~636 minecraft:light_gray_concrete replace
fill ~123 ~90 ~640 ~123 ~90 ~644 minecraft:light_gray_concrete replace
fill ~84 ~90 ~644 ~84 ~90 ~648 minecraft:light_gray_concrete replace
fill ~117 ~90 ~648 ~117 ~90 ~652 minecraft:light_gray_concrete replace
fill ~111 ~90 ~652 ~111 ~90 ~656 minecraft:light_gray_concrete replace
fill ~120 ~90 ~656 ~120 ~90 ~660 minecraft:light_gray_concrete replace
setblock ~114 ~91 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~91 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~91 ~601 minecraft:light_gray_concrete replace
setblock ~78 ~91 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~91 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~91 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~91 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~91 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~91 ~625 minecraft:light_gray_concrete replace
setblock ~108 ~91 ~629 minecraft:light_gray_concrete replace
setblock ~105 ~91 ~637 minecraft:light_gray_concrete replace
setblock ~123 ~91 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~91 ~649 minecraft:light_gray_concrete replace
setblock ~112 ~91 ~652 minecraft:light_gray_concrete replace
setblock ~117 ~91 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~91 ~657 minecraft:light_gray_concrete replace
setblock ~120 ~91 ~661 minecraft:light_gray_concrete replace
fill ~114 ~92 ~386 ~122 ~92 ~386 minecraft:light_gray_concrete replace
fill ~121 ~92 ~387 ~121 ~92 ~388 minecraft:light_gray_concrete replace
fill ~81 ~92 ~398 ~83 ~92 ~398 minecraft:light_gray_concrete replace
fill ~82 ~92 ~399 ~82 ~92 ~400 minecraft:light_gray_concrete replace
fill ~87 ~92 ~602 ~89 ~92 ~602 minecraft:light_gray_concrete replace
fill ~88 ~92 ~603 ~88 ~92 ~604 minecraft:light_gray_concrete replace
fill ~78 ~92 ~606 ~80 ~92 ~606 minecraft:light_gray_concrete replace
fill ~79 ~92 ~607 ~79 ~92 ~608 minecraft:light_gray_concrete replace
fill ~90 ~92 ~610 ~92 ~92 ~610 minecraft:light_gray_concrete replace
fill ~91 ~92 ~611 ~91 ~92 ~612 minecraft:light_gray_concrete replace
fill ~93 ~92 ~614 ~95 ~92 ~614 minecraft:light_gray_concrete replace
fill ~94 ~92 ~615 ~94 ~92 ~616 minecraft:light_gray_concrete replace
fill ~96 ~92 ~618 ~98 ~92 ~618 minecraft:light_gray_concrete replace
fill ~97 ~92 ~619 ~97 ~92 ~620 minecraft:light_gray_concrete replace
fill ~99 ~92 ~622 ~101 ~92 ~622 minecraft:light_gray_concrete replace
fill ~100 ~92 ~623 ~100 ~92 ~624 minecraft:light_gray_concrete replace
fill ~102 ~92 ~626 ~104 ~92 ~626 minecraft:light_gray_concrete replace
fill ~103 ~92 ~627 ~103 ~92 ~628 minecraft:light_gray_concrete replace
fill ~105 ~92 ~630 ~125 ~92 ~630 minecraft:light_gray_concrete replace
fill ~106 ~92 ~631 ~106 ~92 ~632 minecraft:light_gray_concrete replace
fill ~112 ~92 ~631 ~112 ~92 ~632 minecraft:light_gray_concrete replace
fill ~115 ~92 ~631 ~115 ~92 ~632 minecraft:light_gray_concrete replace
fill ~118 ~92 ~631 ~118 ~92 ~632 minecraft:light_gray_concrete replace
fill ~124 ~92 ~631 ~124 ~92 ~632 minecraft:light_gray_concrete replace
fill ~105 ~92 ~638 ~128 ~92 ~638 minecraft:light_gray_concrete replace
fill ~106 ~92 ~639 ~106 ~92 ~640 minecraft:light_gray_concrete replace
fill ~109 ~92 ~639 ~109 ~92 ~640 minecraft:light_gray_concrete replace
fill ~112 ~92 ~639 ~112 ~92 ~640 minecraft:light_gray_concrete replace
fill ~115 ~92 ~639 ~115 ~92 ~640 minecraft:light_gray_concrete replace
fill ~127 ~92 ~639 ~127 ~92 ~640 minecraft:light_gray_concrete replace
fill ~123 ~92 ~646 ~137 ~92 ~646 minecraft:light_gray_concrete replace
fill ~136 ~92 ~647 ~136 ~92 ~648 minecraft:light_gray_concrete replace
fill ~84 ~92 ~650 ~86 ~92 ~650 minecraft:light_gray_concrete replace
fill ~85 ~92 ~651 ~85 ~92 ~652 minecraft:light_gray_concrete replace
fill ~117 ~92 ~654 ~131 ~92 ~654 minecraft:light_gray_concrete replace
fill ~130 ~92 ~655 ~130 ~92 ~656 minecraft:light_gray_concrete replace
fill ~105 ~92 ~658 ~128 ~92 ~658 minecraft:light_gray_concrete replace
fill ~106 ~92 ~659 ~106 ~92 ~660 minecraft:light_gray_concrete replace
fill ~109 ~92 ~659 ~109 ~92 ~660 minecraft:light_gray_concrete replace
fill ~112 ~92 ~659 ~112 ~92 ~660 minecraft:light_gray_concrete replace
fill ~115 ~92 ~659 ~115 ~92 ~660 minecraft:light_gray_concrete replace
fill ~118 ~92 ~659 ~118 ~92 ~660 minecraft:light_gray_concrete replace
fill ~124 ~92 ~659 ~124 ~92 ~660 minecraft:light_gray_concrete replace
fill ~127 ~92 ~659 ~127 ~92 ~660 minecraft:light_gray_concrete replace
fill ~120 ~92 ~662 ~134 ~92 ~662 minecraft:light_gray_concrete replace
fill ~133 ~92 ~663 ~133 ~92 ~664 minecraft:light_gray_concrete replace
setblock ~121 ~93 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~93 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~93 ~604 minecraft:light_gray_concrete replace
setblock ~79 ~93 ~608 minecraft:light_gray_concrete replace
setblock ~91 ~93 ~612 minecraft:light_gray_concrete replace
setblock ~94 ~93 ~616 minecraft:light_gray_concrete replace
setblock ~97 ~93 ~620 minecraft:light_gray_concrete replace
setblock ~100 ~93 ~624 minecraft:light_gray_concrete replace
setblock ~103 ~93 ~628 minecraft:light_gray_concrete replace
setblock ~106 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~112 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~115 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~118 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~93 ~632 minecraft:light_gray_concrete replace
setblock ~106 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~109 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~112 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~115 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~127 ~93 ~640 minecraft:light_gray_concrete replace
setblock ~130 ~93 ~646 minecraft:light_gray_concrete replace
setblock ~132 ~93 ~646 minecraft:light_gray_concrete replace
setblock ~136 ~93 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~93 ~652 minecraft:light_gray_concrete replace
setblock ~124 ~93 ~654 minecraft:light_gray_concrete replace
setblock ~126 ~93 ~654 minecraft:light_gray_concrete replace
setblock ~130 ~93 ~656 minecraft:light_gray_concrete replace
setblock ~106 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~109 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~112 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~115 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~118 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~124 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~127 ~93 ~660 minecraft:light_gray_concrete replace
setblock ~127 ~93 ~662 minecraft:light_gray_concrete replace
setblock ~129 ~93 ~662 minecraft:light_gray_concrete replace
setblock ~133 ~93 ~664 minecraft:light_gray_concrete replace
fill ~120 ~94 ~384 ~120 ~94 ~388 minecraft:light_gray_concrete replace
fill ~81 ~94 ~396 ~81 ~94 ~400 minecraft:light_gray_concrete replace
fill ~87 ~94 ~584 ~87 ~94 ~604 minecraft:light_gray_concrete replace
fill ~78 ~94 ~588 ~78 ~94 ~608 minecraft:light_gray_concrete replace
fill ~90 ~94 ~592 ~90 ~94 ~612 minecraft:light_gray_concrete replace
fill ~93 ~94 ~596 ~93 ~94 ~616 minecraft:light_gray_concrete replace
fill ~96 ~94 ~600 ~96 ~94 ~620 minecraft:light_gray_concrete replace
fill ~99 ~94 ~604 ~99 ~94 ~624 minecraft:light_gray_concrete replace
fill ~102 ~94 ~608 ~102 ~94 ~628 minecraft:light_gray_concrete replace
fill ~123 ~94 ~612 ~123 ~94 ~660 minecraft:light_gray_concrete replace
fill ~117 ~94 ~616 ~117 ~94 ~660 minecraft:light_gray_concrete replace
fill ~114 ~94 ~620 ~114 ~94 ~660 minecraft:light_gray_concrete replace
fill ~111 ~94 ~624 ~111 ~94 ~660 minecraft:light_gray_concrete replace
fill ~105 ~94 ~628 ~105 ~94 ~660 minecraft:light_gray_concrete replace
fill ~126 ~94 ~632 ~126 ~94 ~660 minecraft:light_gray_concrete replace
fill ~108 ~94 ~636 ~108 ~94 ~660 minecraft:light_gray_concrete replace
fill ~135 ~94 ~644 ~135 ~94 ~648 minecraft:light_gray_concrete replace
fill ~84 ~94 ~648 ~84 ~94 ~652 minecraft:light_gray_concrete replace
fill ~129 ~94 ~652 ~129 ~94 ~656 minecraft:light_gray_concrete replace
fill ~132 ~94 ~660 ~132 ~94 ~664 minecraft:light_gray_concrete replace
setblock ~120 ~95 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~95 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~95 ~583 minecraft:light_gray_concrete replace
setblock ~78 ~95 ~587 minecraft:light_gray_concrete replace
setblock ~87 ~95 ~589 minecraft:light_gray_concrete replace
setblock ~87 ~95 ~591 minecraft:light_gray_concrete replace
setblock ~90 ~95 ~591 minecraft:light_gray_concrete replace
setblock ~78 ~95 ~593 minecraft:light_gray_concrete replace
setblock ~78 ~95 ~595 minecraft:light_gray_concrete replace
setblock ~93 ~95 ~595 minecraft:light_gray_concrete replace
setblock ~90 ~95 ~597 minecraft:light_gray_concrete replace
setblock ~90 ~95 ~599 minecraft:light_gray_concrete replace
setblock ~96 ~95 ~599 minecraft:light_gray_concrete replace
setblock ~93 ~95 ~601 minecraft:light_gray_concrete replace
setblock ~93 ~95 ~603 minecraft:light_gray_concrete replace
setblock ~99 ~95 ~603 minecraft:light_gray_concrete replace
setblock ~96 ~95 ~605 minecraft:light_gray_concrete replace
setblock ~96 ~95 ~607 minecraft:light_gray_concrete replace
setblock ~102 ~95 ~607 minecraft:light_gray_concrete replace
setblock ~99 ~95 ~609 minecraft:light_gray_concrete replace
setblock ~99 ~95 ~611 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~611 minecraft:light_gray_concrete replace
setblock ~102 ~95 ~613 minecraft:light_gray_concrete replace
setblock ~102 ~95 ~615 minecraft:light_gray_concrete replace
setblock ~117 ~95 ~615 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~615 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~617 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~619 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~621 minecraft:light_gray_concrete replace
setblock ~111 ~95 ~623 minecraft:light_gray_concrete replace
setblock ~105 ~95 ~627 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~631 minecraft:light_gray_concrete replace
setblock ~106 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~115 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~118 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~95 ~632 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~633 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~635 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~637 minecraft:light_gray_concrete replace
setblock ~109 ~95 ~640 minecraft:light_gray_concrete replace
setblock ~115 ~95 ~640 minecraft:light_gray_concrete replace
setblock ~127 ~95 ~640 minecraft:light_gray_concrete replace
setblock ~135 ~95 ~643 minecraft:light_gray_concrete replace
setblock ~105 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~111 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~117 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~105 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~108 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~111 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~114 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~117 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~123 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~126 ~95 ~647 minecraft:light_gray_concrete replace
setblock ~129 ~95 ~651 minecraft:light_gray_concrete replace
setblock ~132 ~95 ~659 minecraft:light_gray_concrete replace
setblock ~106 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~112 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~115 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~124 ~95 ~660 minecraft:light_gray_concrete replace
setblock ~127 ~95 ~660 minecraft:light_gray_concrete replace
fill ~115 ~96 ~380 ~115 ~96 ~381 minecraft:light_gray_concrete replace
fill ~114 ~96 ~382 ~120 ~96 ~382 minecraft:light_gray_concrete replace
fill ~82 ~96 ~392 ~82 ~96 ~393 minecraft:light_gray_concrete replace
fill ~81 ~96 ~394 ~83 ~96 ~394 minecraft:light_gray_concrete replace
fill ~88 ~96 ~580 ~88 ~96 ~581 minecraft:light_gray_concrete replace
fill ~87 ~96 ~582 ~89 ~96 ~582 minecraft:light_gray_concrete replace
fill ~79 ~96 ~584 ~79 ~96 ~585 minecraft:light_gray_concrete replace
fill ~78 ~96 ~586 ~80 ~96 ~586 minecraft:light_gray_concrete replace
fill ~91 ~96 ~588 ~91 ~96 ~589 minecraft:light_gray_concrete replace
fill ~90 ~96 ~590 ~92 ~96 ~590 minecraft:light_gray_concrete replace
fill ~94 ~96 ~592 ~94 ~96 ~593 minecraft:light_gray_concrete replace
fill ~93 ~96 ~594 ~95 ~96 ~594 minecraft:light_gray_concrete replace
fill ~97 ~96 ~596 ~97 ~96 ~597 minecraft:light_gray_concrete replace
fill ~96 ~96 ~598 ~98 ~96 ~598 minecraft:light_gray_concrete replace
fill ~100 ~96 ~600 ~100 ~96 ~601 minecraft:light_gray_concrete replace
fill ~99 ~96 ~602 ~101 ~96 ~602 minecraft:light_gray_concrete replace
fill ~103 ~96 ~604 ~103 ~96 ~605 minecraft:light_gray_concrete replace
fill ~102 ~96 ~606 ~104 ~96 ~606 minecraft:light_gray_concrete replace
fill ~118 ~96 ~608 ~118 ~96 ~609 minecraft:light_gray_concrete replace
fill ~117 ~96 ~610 ~123 ~96 ~610 minecraft:light_gray_concrete replace
fill ~112 ~96 ~612 ~112 ~96 ~613 minecraft:light_gray_concrete replace
fill ~111 ~96 ~614 ~117 ~96 ~614 minecraft:light_gray_concrete replace
fill ~112 ~96 ~616 ~112 ~96 ~617 minecraft:light_gray_concrete replace
fill ~111 ~96 ~618 ~114 ~96 ~618 minecraft:light_gray_concrete replace
fill ~109 ~96 ~620 ~109 ~96 ~621 minecraft:light_gray_concrete replace
fill ~108 ~96 ~622 ~111 ~96 ~622 minecraft:light_gray_concrete replace
fill ~106 ~96 ~624 ~106 ~96 ~625 minecraft:light_gray_concrete replace
fill ~105 ~96 ~626 ~107 ~96 ~626 minecraft:light_gray_concrete replace
fill ~118 ~96 ~628 ~118 ~96 ~629 minecraft:light_gray_concrete replace
fill ~117 ~96 ~630 ~126 ~96 ~630 minecraft:light_gray_concrete replace
fill ~106 ~96 ~632 ~106 ~96 ~633 minecraft:light_gray_concrete replace
fill ~105 ~96 ~634 ~108 ~96 ~634 minecraft:light_gray_concrete replace
fill ~127 ~96 ~640 ~127 ~96 ~641 minecraft:light_gray_concrete replace
fill ~126 ~96 ~642 ~135 ~96 ~642 minecraft:light_gray_concrete replace
fill ~85 ~96 ~644 ~85 ~96 ~645 minecraft:light_gray_concrete replace
fill ~84 ~96 ~646 ~86 ~96 ~646 minecraft:light_gray_concrete replace
fill ~121 ~96 ~648 ~121 ~96 ~649 minecraft:light_gray_concrete replace
fill ~120 ~96 ~650 ~129 ~96 ~650 minecraft:light_gray_concrete replace
fill ~124 ~96 ~656 ~124 ~96 ~657 minecraft:light_gray_concrete replace
fill ~123 ~96 ~658 ~132 ~96 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~97 ~380 minecraft:light_gray_concrete replace
setblock ~82 ~97 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~97 ~580 minecraft:light_gray_concrete replace
setblock ~79 ~97 ~584 minecraft:light_gray_concrete replace
setblock ~91 ~97 ~588 minecraft:light_gray_concrete replace
setblock ~94 ~97 ~592 minecraft:light_gray_concrete replace
setblock ~97 ~97 ~596 minecraft:light_gray_concrete replace
setblock ~100 ~97 ~600 minecraft:light_gray_concrete replace
setblock ~103 ~97 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~97 ~608 minecraft:light_gray_concrete replace
setblock ~112 ~97 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~97 ~616 minecraft:light_gray_concrete replace
setblock ~109 ~97 ~620 minecraft:light_gray_concrete replace
setblock ~106 ~97 ~624 minecraft:light_gray_concrete replace
setblock ~118 ~97 ~628 minecraft:light_gray_concrete replace
setblock ~106 ~97 ~632 minecraft:light_gray_concrete replace
setblock ~127 ~97 ~640 minecraft:light_gray_concrete replace
setblock ~85 ~97 ~644 minecraft:light_gray_concrete replace
setblock ~121 ~97 ~648 minecraft:light_gray_concrete replace
setblock ~124 ~97 ~656 minecraft:light_gray_concrete replace
fill ~114 ~98 ~380 ~114 ~98 ~384 minecraft:light_gray_concrete replace
fill ~81 ~98 ~392 ~81 ~98 ~396 minecraft:light_gray_concrete replace
fill ~87 ~98 ~580 ~87 ~98 ~584 minecraft:light_gray_concrete replace
fill ~78 ~98 ~584 ~78 ~98 ~588 minecraft:light_gray_concrete replace
fill ~90 ~98 ~588 ~90 ~98 ~592 minecraft:light_gray_concrete replace
fill ~93 ~98 ~592 ~93 ~98 ~596 minecraft:light_gray_concrete replace
fill ~96 ~98 ~596 ~96 ~98 ~600 minecraft:light_gray_concrete replace
fill ~99 ~98 ~600 ~99 ~98 ~604 minecraft:light_gray_concrete replace
fill ~102 ~98 ~604 ~102 ~98 ~608 minecraft:light_gray_concrete replace
fill ~117 ~98 ~608 ~117 ~98 ~632 minecraft:light_gray_concrete replace
fill ~111 ~98 ~612 ~111 ~98 ~620 minecraft:light_gray_concrete replace
fill ~108 ~98 ~620 ~108 ~98 ~624 minecraft:light_gray_concrete replace
fill ~105 ~98 ~624 ~105 ~98 ~636 minecraft:light_gray_concrete replace
fill ~126 ~98 ~640 ~126 ~98 ~644 minecraft:light_gray_concrete replace
fill ~84 ~98 ~644 ~84 ~98 ~648 minecraft:light_gray_concrete replace
fill ~120 ~98 ~648 ~120 ~98 ~652 minecraft:light_gray_concrete replace
fill ~123 ~98 ~656 ~123 ~98 ~660 minecraft:light_gray_concrete replace
setblock ~114 ~99 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~99 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~99 ~585 minecraft:light_gray_concrete replace
setblock ~78 ~99 ~589 minecraft:light_gray_concrete replace
setblock ~90 ~99 ~593 minecraft:light_gray_concrete replace
setblock ~93 ~99 ~597 minecraft:light_gray_concrete replace
setblock ~96 ~99 ~601 minecraft:light_gray_concrete replace
setblock ~99 ~99 ~605 minecraft:light_gray_concrete replace
setblock ~118 ~99 ~608 minecraft:light_gray_concrete replace
setblock ~102 ~99 ~609 minecraft:light_gray_concrete replace
setblock ~112 ~99 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~99 ~616 minecraft:light_gray_concrete replace
setblock ~111 ~99 ~619 minecraft:light_gray_concrete replace
setblock ~109 ~99 ~620 minecraft:light_gray_concrete replace
setblock ~111 ~99 ~621 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~621 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~623 minecraft:light_gray_concrete replace
setblock ~106 ~99 ~624 minecraft:light_gray_concrete replace
setblock ~108 ~99 ~625 minecraft:light_gray_concrete replace
setblock ~118 ~99 ~628 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~631 minecraft:light_gray_concrete replace
setblock ~106 ~99 ~632 minecraft:light_gray_concrete replace
setblock ~117 ~99 ~633 minecraft:light_gray_concrete replace
setblock ~105 ~99 ~635 minecraft:light_gray_concrete replace
setblock ~105 ~99 ~637 minecraft:light_gray_concrete replace
setblock ~126 ~99 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~99 ~649 minecraft:light_gray_concrete replace
setblock ~120 ~99 ~653 minecraft:light_gray_concrete replace
setblock ~123 ~99 ~661 minecraft:light_gray_concrete replace
fill ~114 ~100 ~386 ~128 ~100 ~386 minecraft:light_gray_concrete replace
fill ~127 ~100 ~387 ~127 ~100 ~388 minecraft:light_gray_concrete replace
fill ~81 ~100 ~398 ~83 ~100 ~398 minecraft:light_gray_concrete replace
fill ~82 ~100 ~399 ~82 ~100 ~400 minecraft:light_gray_concrete replace
fill ~87 ~100 ~586 ~89 ~100 ~586 minecraft:light_gray_concrete replace
fill ~88 ~100 ~587 ~88 ~100 ~588 minecraft:light_gray_concrete replace
fill ~78 ~100 ~590 ~80 ~100 ~590 minecraft:light_gray_concrete replace
fill ~79 ~100 ~591 ~79 ~100 ~592 minecraft:light_gray_concrete replace
fill ~90 ~100 ~594 ~92 ~100 ~594 minecraft:light_gray_concrete replace
fill ~91 ~100 ~595 ~91 ~100 ~596 minecraft:light_gray_concrete replace
fill ~93 ~100 ~598 ~95 ~100 ~598 minecraft:light_gray_concrete replace
fill ~94 ~100 ~599 ~94 ~100 ~600 minecraft:light_gray_concrete replace
fill ~96 ~100 ~602 ~98 ~100 ~602 minecraft:light_gray_concrete replace
fill ~97 ~100 ~603 ~97 ~100 ~604 minecraft:light_gray_concrete replace
fill ~99 ~100 ~606 ~101 ~100 ~606 minecraft:light_gray_concrete replace
fill ~100 ~100 ~607 ~100 ~100 ~608 minecraft:light_gray_concrete replace
fill ~102 ~100 ~610 ~131 ~100 ~610 minecraft:light_gray_concrete replace
fill ~103 ~100 ~611 ~103 ~100 ~612 minecraft:light_gray_concrete replace
fill ~106 ~100 ~611 ~106 ~100 ~612 minecraft:light_gray_concrete replace
fill ~109 ~100 ~611 ~109 ~100 ~612 minecraft:light_gray_concrete replace
fill ~112 ~100 ~611 ~112 ~100 ~612 minecraft:light_gray_concrete replace
fill ~115 ~100 ~611 ~115 ~100 ~612 minecraft:light_gray_concrete replace
fill ~118 ~100 ~611 ~118 ~100 ~612 minecraft:light_gray_concrete replace
fill ~121 ~100 ~611 ~121 ~100 ~612 minecraft:light_gray_concrete replace
fill ~130 ~100 ~611 ~130 ~100 ~612 minecraft:light_gray_concrete replace
fill ~105 ~100 ~622 ~137 ~100 ~622 minecraft:light_gray_concrete replace
fill ~106 ~100 ~623 ~106 ~100 ~624 minecraft:light_gray_concrete replace
fill ~112 ~100 ~623 ~112 ~100 ~624 minecraft:light_gray_concrete replace
fill ~115 ~100 ~623 ~115 ~100 ~624 minecraft:light_gray_concrete replace
fill ~121 ~100 ~623 ~121 ~100 ~624 minecraft:light_gray_concrete replace
fill ~124 ~100 ~623 ~124 ~100 ~624 minecraft:light_gray_concrete replace
fill ~130 ~100 ~623 ~130 ~100 ~624 minecraft:light_gray_concrete replace
fill ~136 ~100 ~623 ~136 ~100 ~624 minecraft:light_gray_concrete replace
fill ~102 ~100 ~626 ~134 ~100 ~626 minecraft:light_gray_concrete replace
fill ~103 ~100 ~627 ~103 ~100 ~628 minecraft:light_gray_concrete replace
fill ~109 ~100 ~627 ~109 ~100 ~628 minecraft:light_gray_concrete replace
fill ~112 ~100 ~627 ~112 ~100 ~628 minecraft:light_gray_concrete replace
fill ~118 ~100 ~627 ~118 ~100 ~628 minecraft:light_gray_concrete replace
fill ~124 ~100 ~627 ~124 ~100 ~628 minecraft:light_gray_concrete replace
fill ~133 ~100 ~627 ~133 ~100 ~628 minecraft:light_gray_concrete replace
fill ~117 ~100 ~634 ~140 ~100 ~634 minecraft:light_gray_concrete replace
fill ~139 ~100 ~635 ~139 ~100 ~636 minecraft:light_gray_concrete replace
fill ~102 ~100 ~638 ~137 ~100 ~638 minecraft:light_gray_concrete replace
fill ~103 ~100 ~639 ~103 ~100 ~640 minecraft:light_gray_concrete replace
fill ~106 ~100 ~639 ~106 ~100 ~640 minecraft:light_gray_concrete replace
fill ~109 ~100 ~639 ~109 ~100 ~640 minecraft:light_gray_concrete replace
fill ~115 ~100 ~639 ~115 ~100 ~640 minecraft:light_gray_concrete replace
fill ~121 ~100 ~639 ~121 ~100 ~640 minecraft:light_gray_concrete replace
fill ~124 ~100 ~639 ~124 ~100 ~640 minecraft:light_gray_concrete replace
fill ~136 ~100 ~639 ~136 ~100 ~640 minecraft:light_gray_concrete replace
fill ~126 ~100 ~646 ~149 ~100 ~646 minecraft:light_gray_concrete replace
fill ~148 ~100 ~647 ~148 ~100 ~648 minecraft:light_gray_concrete replace
fill ~84 ~100 ~650 ~86 ~100 ~650 minecraft:light_gray_concrete replace
fill ~85 ~100 ~651 ~85 ~100 ~652 minecraft:light_gray_concrete replace
fill ~120 ~100 ~654 ~143 ~100 ~654 minecraft:light_gray_concrete replace
fill ~142 ~100 ~655 ~142 ~100 ~656 minecraft:light_gray_concrete replace
fill ~123 ~100 ~662 ~146 ~100 ~662 minecraft:light_gray_concrete replace
fill ~145 ~100 ~663 ~145 ~100 ~664 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~386 minecraft:light_gray_concrete replace
setblock ~123 ~101 ~386 minecraft:light_gray_concrete replace
setblock ~127 ~101 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~101 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~101 ~588 minecraft:light_gray_concrete replace
setblock ~79 ~101 ~592 minecraft:light_gray_concrete replace
setblock ~91 ~101 ~596 minecraft:light_gray_concrete replace
setblock ~94 ~101 ~600 minecraft:light_gray_concrete replace
setblock ~97 ~101 ~604 minecraft:light_gray_concrete replace
setblock ~100 ~101 ~608 minecraft:light_gray_concrete replace
setblock ~103 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~106 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~118 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~612 minecraft:light_gray_concrete replace
setblock ~106 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~112 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~124 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~101 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~626 minecraft:light_gray_concrete replace
setblock ~117 ~101 ~626 minecraft:light_gray_concrete replace
setblock ~103 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~112 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~118 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~124 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~133 ~101 ~628 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~634 minecraft:light_gray_concrete replace
setblock ~132 ~101 ~634 minecraft:light_gray_concrete replace
setblock ~139 ~101 ~636 minecraft:light_gray_concrete replace
setblock ~118 ~101 ~638 minecraft:light_gray_concrete replace
setblock ~120 ~101 ~638 minecraft:light_gray_concrete replace
setblock ~103 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~106 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~109 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~115 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~121 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~136 ~101 ~640 minecraft:light_gray_concrete replace
setblock ~133 ~101 ~646 minecraft:light_gray_concrete replace
setblock ~135 ~101 ~646 minecraft:light_gray_concrete replace
setblock ~148 ~101 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~101 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~101 ~654 minecraft:light_gray_concrete replace
setblock ~129 ~101 ~654 minecraft:light_gray_concrete replace
setblock ~142 ~101 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~101 ~662 minecraft:light_gray_concrete replace
setblock ~132 ~101 ~662 minecraft:light_gray_concrete replace
setblock ~145 ~101 ~664 minecraft:light_gray_concrete replace
fill ~126 ~102 ~384 ~126 ~102 ~388 minecraft:light_gray_concrete replace
fill ~81 ~102 ~396 ~81 ~102 ~400 minecraft:light_gray_concrete replace
fill ~87 ~102 ~556 ~87 ~102 ~588 minecraft:light_gray_concrete replace
fill ~78 ~102 ~560 ~78 ~102 ~592 minecraft:light_gray_concrete replace
fill ~90 ~102 ~564 ~90 ~102 ~596 minecraft:light_gray_concrete replace
fill ~93 ~102 ~568 ~93 ~102 ~600 minecraft:light_gray_concrete replace
fill ~96 ~102 ~572 ~96 ~102 ~604 minecraft:light_gray_concrete replace
fill ~99 ~102 ~576 ~99 ~102 ~608 minecraft:light_gray_concrete replace
fill ~129 ~102 ~580 ~129 ~102 ~624 minecraft:light_gray_concrete replace
fill ~120 ~102 ~584 ~120 ~102 ~640 minecraft:light_gray_concrete replace
fill ~117 ~102 ~588 ~117 ~102 ~628 minecraft:light_gray_concrete replace
fill ~114 ~102 ~592 ~114 ~102 ~640 minecraft:light_gray_concrete replace
fill ~111 ~102 ~596 ~111 ~102 ~628 minecraft:light_gray_concrete replace
fill ~108 ~102 ~600 ~108 ~102 ~640 minecraft:light_gray_concrete replace
fill ~105 ~102 ~604 ~105 ~102 ~640 minecraft:light_gray_concrete replace
fill ~102 ~102 ~608 ~102 ~102 ~640 minecraft:light_gray_concrete replace
fill ~135 ~102 ~616 ~135 ~102 ~640 minecraft:light_gray_concrete replace
fill ~123 ~102 ~620 ~123 ~102 ~640 minecraft:light_gray_concrete replace
fill ~132 ~102 ~624 ~132 ~102 ~628 minecraft:light_gray_concrete replace
fill ~138 ~102 ~632 ~138 ~102 ~636 minecraft:light_gray_concrete replace
fill ~147 ~102 ~644 ~147 ~102 ~648 minecraft:light_gray_concrete replace
fill ~84 ~102 ~648 ~84 ~102 ~652 minecraft:light_gray_concrete replace
fill ~141 ~102 ~652 ~141 ~102 ~656 minecraft:light_gray_concrete replace
fill ~144 ~102 ~660 ~144 ~102 ~664 minecraft:light_gray_concrete replace
setblock ~126 ~103 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~103 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~555 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~557 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~559 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~559 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~561 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~563 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~563 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~565 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~567 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~567 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~569 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~571 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~571 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~573 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~573 minecraft:light_gray_concrete replace
setblock ~87 ~103 ~575 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~575 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~577 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~577 minecraft:light_gray_concrete replace
setblock ~78 ~103 ~579 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~579 minecraft:light_gray_concrete replace
setblock ~129 ~103 ~579 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~581 minecraft:light_gray_concrete replace
setblock ~90 ~103 ~583 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~583 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~585 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~585 minecraft:light_gray_concrete replace
setblock ~93 ~103 ~587 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~587 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~589 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~589 minecraft:light_gray_concrete replace
setblock ~96 ~103 ~591 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~591 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~593 minecraft:light_gray_concrete replace
setblock ~99 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~129 ~103 ~595 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~129 ~103 ~597 minecraft:light_gray_concrete replace
setblock ~108 ~103 ~599 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~599 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~599 minecraft:light_gray_concrete replace
setblock ~108 ~103 ~601 minecraft:light_gray_concrete replace
setblock ~105 ~103 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~103 ~607 minecraft:light_gray_concrete replace
setblock ~103 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~112 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~103 ~612 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~613 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~613 minecraft:light_gray_concrete replace
setblock ~111 ~103 ~615 minecraft:light_gray_concrete replace
setblock ~117 ~103 ~615 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~615 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~617 minecraft:light_gray_concrete replace
setblock ~123 ~103 ~619 minecraft:light_gray_concrete replace
setblock ~132 ~103 ~623 minecraft:light_gray_concrete replace
setblock ~106 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~115 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~121 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~130 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~103 ~624 minecraft:light_gray_concrete replace
setblock ~105 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~625 minecraft:light_gray_concrete replace
setblock ~105 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~114 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~120 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~135 ~103 ~627 minecraft:light_gray_concrete replace
setblock ~103 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~118 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~133 ~103 ~628 minecraft:light_gray_concrete replace
setblock ~138 ~103 ~631 minecraft:light_gray_concrete replace
setblock ~139 ~103 ~636 minecraft:light_gray_concrete replace
setblock ~115 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~121 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~136 ~103 ~640 minecraft:light_gray_concrete replace
setblock ~147 ~103 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~103 ~647 minecraft:light_gray_concrete replace
setblock ~141 ~103 ~651 minecraft:light_gray_concrete replace
setblock ~144 ~103 ~659 minecraft:light_gray_concrete replace
fill ~112 ~104 ~380 ~112 ~104 ~381 minecraft:light_gray_concrete replace
fill ~111 ~104 ~382 ~126 ~104 ~382 minecraft:light_gray_concrete replace
fill ~82 ~104 ~392 ~82 ~104 ~393 minecraft:light_gray_concrete replace
fill ~81 ~104 ~394 ~83 ~104 ~394 minecraft:light_gray_concrete replace
fill ~88 ~104 ~552 ~88 ~104 ~553 minecraft:light_gray_concrete replace
fill ~87 ~104 ~554 ~89 ~104 ~554 minecraft:light_gray_concrete replace
fill ~79 ~104 ~556 ~79 ~104 ~557 minecraft:light_gray_concrete replace
fill ~78 ~104 ~558 ~80 ~104 ~558 minecraft:light_gray_concrete replace
fill ~91 ~104 ~560 ~91 ~104 ~561 minecraft:light_gray_concrete replace
fill ~90 ~104 ~562 ~92 ~104 ~562 minecraft:light_gray_concrete replace
fill ~94 ~104 ~564 ~94 ~104 ~565 minecraft:light_gray_concrete replace
fill ~93 ~104 ~566 ~95 ~104 ~566 minecraft:light_gray_concrete replace
fill ~97 ~104 ~568 ~97 ~104 ~569 minecraft:light_gray_concrete replace
fill ~96 ~104 ~570 ~98 ~104 ~570 minecraft:light_gray_concrete replace
fill ~100 ~104 ~572 ~100 ~104 ~573 minecraft:light_gray_concrete replace
fill ~99 ~104 ~574 ~101 ~104 ~574 minecraft:light_gray_concrete replace
fill ~115 ~104 ~576 ~115 ~104 ~577 minecraft:light_gray_concrete replace
fill ~114 ~104 ~578 ~129 ~104 ~578 minecraft:light_gray_concrete replace
fill ~109 ~104 ~580 ~109 ~104 ~581 minecraft:light_gray_concrete replace
fill ~108 ~104 ~582 ~120 ~104 ~582 minecraft:light_gray_concrete replace
fill ~109 ~104 ~584 ~109 ~104 ~585 minecraft:light_gray_concrete replace
fill ~108 ~104 ~586 ~117 ~104 ~586 minecraft:light_gray_concrete replace
fill ~106 ~104 ~588 ~106 ~104 ~589 minecraft:light_gray_concrete replace
fill ~105 ~104 ~590 ~114 ~104 ~590 minecraft:light_gray_concrete replace
fill ~106 ~104 ~592 ~106 ~104 ~593 minecraft:light_gray_concrete replace
fill ~105 ~104 ~594 ~111 ~104 ~594 minecraft:light_gray_concrete replace
fill ~106 ~104 ~596 ~106 ~104 ~597 minecraft:light_gray_concrete replace
fill ~105 ~104 ~598 ~108 ~104 ~598 minecraft:light_gray_concrete replace
fill ~103 ~104 ~600 ~103 ~104 ~601 minecraft:light_gray_concrete replace
fill ~102 ~104 ~602 ~105 ~104 ~602 minecraft:light_gray_concrete replace
fill ~103 ~104 ~604 ~103 ~104 ~605 minecraft:light_gray_concrete replace
fill ~102 ~104 ~606 ~104 ~104 ~606 minecraft:light_gray_concrete replace
fill ~115 ~104 ~612 ~115 ~104 ~613 minecraft:light_gray_concrete replace
fill ~114 ~104 ~614 ~135 ~104 ~614 minecraft:light_gray_concrete replace
fill ~109 ~104 ~616 ~109 ~104 ~617 minecraft:light_gray_concrete replace
fill ~108 ~104 ~618 ~123 ~104 ~618 minecraft:light_gray_concrete replace
fill ~115 ~104 ~620 ~115 ~104 ~621 minecraft:light_gray_concrete replace
fill ~114 ~104 ~622 ~132 ~104 ~622 minecraft:light_gray_concrete replace
fill ~118 ~104 ~628 ~118 ~104 ~629 minecraft:light_gray_concrete replace
fill ~117 ~104 ~630 ~138 ~104 ~630 minecraft:light_gray_concrete replace
fill ~127 ~104 ~640 ~127 ~104 ~641 minecraft:light_gray_concrete replace
fill ~126 ~104 ~642 ~147 ~104 ~642 minecraft:light_gray_concrete replace
fill ~85 ~104 ~644 ~85 ~104 ~645 minecraft:light_gray_concrete replace
fill ~84 ~104 ~646 ~86 ~104 ~646 minecraft:light_gray_concrete replace
fill ~121 ~104 ~648 ~121 ~104 ~649 minecraft:light_gray_concrete replace
fill ~120 ~104 ~650 ~141 ~104 ~650 minecraft:light_gray_concrete replace
fill ~124 ~104 ~656 ~124 ~104 ~657 minecraft:light_gray_concrete replace
fill ~123 ~104 ~658 ~144 ~104 ~658 minecraft:light_gray_concrete replace
setblock ~112 ~105 ~380 minecraft:light_gray_concrete replace
setblock ~117 ~105 ~382 minecraft:light_gray_concrete replace
setblock ~119 ~105 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~105 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~105 ~552 minecraft:light_gray_concrete replace
setblock ~79 ~105 ~556 minecraft:light_gray_concrete replace
setblock ~91 ~105 ~560 minecraft:light_gray_concrete replace
setblock ~94 ~105 ~564 minecraft:light_gray_concrete replace
setblock ~97 ~105 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~105 ~572 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~576 minecraft:light_gray_concrete replace
setblock ~109 ~105 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~105 ~584 minecraft:light_gray_concrete replace
setblock ~106 ~105 ~588 minecraft:light_gray_concrete replace
setblock ~106 ~105 ~592 minecraft:light_gray_concrete replace
setblock ~106 ~105 ~596 minecraft:light_gray_concrete replace
setblock ~103 ~105 ~600 minecraft:light_gray_concrete replace
setblock ~103 ~105 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~612 minecraft:light_gray_concrete replace
setblock ~120 ~105 ~614 minecraft:light_gray_concrete replace
setblock ~122 ~105 ~614 minecraft:light_gray_concrete replace
setblock ~109 ~105 ~616 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~618 minecraft:light_gray_concrete replace
