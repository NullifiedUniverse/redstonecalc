fill ~240 ~35 ~32 ~240 ~35 ~44 minecraft:redstone_wire replace
fill ~258 ~35 ~32 ~258 ~35 ~44 minecraft:redstone_wire replace
setblock ~93 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~40 ~93 ~35 ~52 minecraft:redstone_wire replace
fill ~120 ~35 ~40 ~120 ~35 ~52 minecraft:redstone_wire replace
fill ~144 ~35 ~40 ~144 ~35 ~52 minecraft:redstone_wire replace
fill ~150 ~35 ~40 ~150 ~35 ~52 minecraft:redstone_wire replace
fill ~168 ~35 ~40 ~168 ~35 ~52 minecraft:redstone_wire replace
fill ~195 ~35 ~40 ~195 ~35 ~52 minecraft:redstone_wire replace
fill ~201 ~35 ~40 ~201 ~35 ~52 minecraft:redstone_wire replace
fill ~225 ~35 ~40 ~225 ~35 ~52 minecraft:redstone_wire replace
fill ~246 ~35 ~40 ~246 ~35 ~52 minecraft:redstone_wire replace
fill ~300 ~35 ~40 ~300 ~35 ~44 minecraft:redstone_wire replace
setblock ~117 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~48 ~117 ~35 ~60 minecraft:redstone_wire replace
fill ~141 ~35 ~48 ~141 ~35 ~60 minecraft:redstone_wire replace
fill ~171 ~35 ~48 ~171 ~35 ~60 minecraft:redstone_wire replace
fill ~174 ~35 ~48 ~174 ~35 ~60 minecraft:redstone_wire replace
fill ~228 ~35 ~48 ~228 ~35 ~60 minecraft:redstone_wire replace
fill ~240 ~35 ~48 ~240 ~35 ~60 minecraft:redstone_wire replace
fill ~258 ~35 ~48 ~258 ~35 ~60 minecraft:redstone_wire replace
fill ~261 ~35 ~48 ~261 ~35 ~60 minecraft:redstone_wire replace
fill ~282 ~35 ~48 ~282 ~35 ~60 minecraft:redstone_wire replace
fill ~330 ~35 ~48 ~330 ~35 ~52 minecraft:redstone_wire replace
setblock ~93 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~56 ~93 ~35 ~68 minecraft:redstone_wire replace
fill ~120 ~35 ~56 ~120 ~35 ~68 minecraft:redstone_wire replace
fill ~144 ~35 ~56 ~144 ~35 ~68 minecraft:redstone_wire replace
fill ~150 ~35 ~56 ~150 ~35 ~68 minecraft:redstone_wire replace
fill ~168 ~35 ~56 ~168 ~35 ~68 minecraft:redstone_wire replace
fill ~195 ~35 ~56 ~195 ~35 ~68 minecraft:redstone_wire replace
fill ~201 ~35 ~56 ~201 ~35 ~68 minecraft:redstone_wire replace
fill ~225 ~35 ~56 ~225 ~35 ~68 minecraft:redstone_wire replace
fill ~246 ~35 ~56 ~246 ~35 ~68 minecraft:redstone_wire replace
fill ~264 ~35 ~56 ~264 ~35 ~68 minecraft:redstone_wire replace
fill ~315 ~35 ~56 ~315 ~35 ~68 minecraft:redstone_wire replace
fill ~321 ~35 ~56 ~321 ~35 ~60 minecraft:redstone_wire replace
fill ~339 ~35 ~56 ~339 ~35 ~68 minecraft:redstone_wire replace
fill ~318 ~35 ~60 ~318 ~35 ~72 minecraft:redstone_wire replace
fill ~336 ~35 ~60 ~336 ~35 ~72 minecraft:redstone_wire replace
fill ~342 ~35 ~60 ~342 ~35 ~72 minecraft:redstone_wire replace
setblock ~117 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~64 ~117 ~35 ~76 minecraft:redstone_wire replace
fill ~141 ~35 ~64 ~141 ~35 ~76 minecraft:redstone_wire replace
fill ~171 ~35 ~64 ~171 ~35 ~76 minecraft:redstone_wire replace
fill ~174 ~35 ~64 ~174 ~35 ~76 minecraft:redstone_wire replace
fill ~228 ~35 ~64 ~228 ~35 ~76 minecraft:redstone_wire replace
fill ~240 ~35 ~64 ~240 ~35 ~76 minecraft:redstone_wire replace
fill ~258 ~35 ~64 ~258 ~35 ~76 minecraft:redstone_wire replace
fill ~261 ~35 ~64 ~261 ~35 ~76 minecraft:redstone_wire replace
fill ~282 ~35 ~64 ~282 ~35 ~76 minecraft:redstone_wire replace
setblock ~93 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~72 ~93 ~35 ~84 minecraft:redstone_wire replace
fill ~120 ~35 ~72 ~120 ~35 ~84 minecraft:redstone_wire replace
fill ~144 ~35 ~72 ~144 ~35 ~84 minecraft:redstone_wire replace
fill ~150 ~35 ~72 ~150 ~35 ~84 minecraft:redstone_wire replace
fill ~168 ~35 ~72 ~168 ~35 ~84 minecraft:redstone_wire replace
fill ~195 ~35 ~72 ~195 ~35 ~84 minecraft:redstone_wire replace
fill ~201 ~35 ~72 ~201 ~35 ~84 minecraft:redstone_wire replace
fill ~225 ~35 ~72 ~225 ~35 ~84 minecraft:redstone_wire replace
fill ~246 ~35 ~72 ~246 ~35 ~84 minecraft:redstone_wire replace
fill ~264 ~35 ~72 ~264 ~35 ~84 minecraft:redstone_wire replace
fill ~285 ~35 ~72 ~285 ~35 ~84 minecraft:redstone_wire replace
fill ~315 ~35 ~72 ~315 ~35 ~84 minecraft:redstone_wire replace
fill ~327 ~35 ~72 ~327 ~35 ~84 minecraft:redstone_wire replace
fill ~339 ~35 ~72 ~339 ~35 ~84 minecraft:redstone_wire replace
fill ~351 ~35 ~72 ~351 ~35 ~76 minecraft:redstone_wire replace
fill ~387 ~35 ~72 ~387 ~35 ~84 minecraft:redstone_wire replace
setblock ~318 ~35 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~76 ~318 ~35 ~88 minecraft:redstone_wire replace
fill ~336 ~35 ~76 ~336 ~35 ~88 minecraft:redstone_wire replace
fill ~342 ~35 ~76 ~342 ~35 ~88 minecraft:redstone_wire replace
fill ~354 ~35 ~76 ~354 ~35 ~88 minecraft:redstone_wire replace
fill ~360 ~35 ~76 ~360 ~35 ~88 minecraft:redstone_wire replace
fill ~378 ~35 ~76 ~378 ~35 ~88 minecraft:redstone_wire replace
setblock ~117 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~80 ~117 ~35 ~92 minecraft:redstone_wire replace
fill ~141 ~35 ~80 ~141 ~35 ~92 minecraft:redstone_wire replace
fill ~171 ~35 ~80 ~171 ~35 ~92 minecraft:redstone_wire replace
fill ~174 ~35 ~80 ~174 ~35 ~92 minecraft:redstone_wire replace
fill ~228 ~35 ~80 ~228 ~35 ~92 minecraft:redstone_wire replace
fill ~240 ~35 ~80 ~240 ~35 ~92 minecraft:redstone_wire replace
fill ~258 ~35 ~80 ~258 ~35 ~92 minecraft:redstone_wire replace
fill ~261 ~35 ~80 ~261 ~35 ~92 minecraft:redstone_wire replace
fill ~282 ~35 ~80 ~282 ~35 ~92 minecraft:redstone_wire replace
setblock ~93 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~88 ~93 ~35 ~100 minecraft:redstone_wire replace
fill ~120 ~35 ~88 ~120 ~35 ~100 minecraft:redstone_wire replace
fill ~144 ~35 ~88 ~144 ~35 ~100 minecraft:redstone_wire replace
fill ~150 ~35 ~88 ~150 ~35 ~100 minecraft:redstone_wire replace
fill ~168 ~35 ~88 ~168 ~35 ~100 minecraft:redstone_wire replace
fill ~195 ~35 ~88 ~195 ~35 ~100 minecraft:redstone_wire replace
fill ~201 ~35 ~88 ~201 ~35 ~100 minecraft:redstone_wire replace
fill ~225 ~35 ~88 ~225 ~35 ~100 minecraft:redstone_wire replace
fill ~246 ~35 ~88 ~246 ~35 ~100 minecraft:redstone_wire replace
fill ~264 ~35 ~88 ~264 ~35 ~100 minecraft:redstone_wire replace
fill ~285 ~35 ~88 ~285 ~35 ~100 minecraft:redstone_wire replace
fill ~315 ~35 ~88 ~315 ~35 ~100 minecraft:redstone_wire replace
fill ~327 ~35 ~88 ~327 ~35 ~100 minecraft:redstone_wire replace
fill ~339 ~35 ~88 ~339 ~35 ~100 minecraft:redstone_wire replace
fill ~387 ~35 ~88 ~387 ~35 ~100 minecraft:redstone_wire replace
setblock ~318 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~92 ~318 ~35 ~104 minecraft:redstone_wire replace
fill ~336 ~35 ~92 ~336 ~35 ~104 minecraft:redstone_wire replace
fill ~342 ~35 ~92 ~342 ~35 ~104 minecraft:redstone_wire replace
fill ~354 ~35 ~92 ~354 ~35 ~104 minecraft:redstone_wire replace
fill ~360 ~35 ~92 ~360 ~35 ~104 minecraft:redstone_wire replace
fill ~378 ~35 ~92 ~378 ~35 ~104 minecraft:redstone_wire replace
setblock ~117 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~96 ~117 ~35 ~108 minecraft:redstone_wire replace
fill ~141 ~35 ~96 ~141 ~35 ~108 minecraft:redstone_wire replace
fill ~171 ~35 ~96 ~171 ~35 ~108 minecraft:redstone_wire replace
fill ~174 ~35 ~96 ~174 ~35 ~108 minecraft:redstone_wire replace
fill ~228 ~35 ~96 ~228 ~35 ~108 minecraft:redstone_wire replace
fill ~240 ~35 ~96 ~240 ~35 ~108 minecraft:redstone_wire replace
fill ~258 ~35 ~96 ~258 ~35 ~108 minecraft:redstone_wire replace
fill ~261 ~35 ~96 ~261 ~35 ~108 minecraft:redstone_wire replace
fill ~282 ~35 ~96 ~282 ~35 ~108 minecraft:redstone_wire replace
setblock ~93 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~104 ~93 ~35 ~116 minecraft:redstone_wire replace
fill ~120 ~35 ~104 ~120 ~35 ~116 minecraft:redstone_wire replace
fill ~144 ~35 ~104 ~144 ~35 ~116 minecraft:redstone_wire replace
fill ~150 ~35 ~104 ~150 ~35 ~116 minecraft:redstone_wire replace
fill ~168 ~35 ~104 ~168 ~35 ~116 minecraft:redstone_wire replace
fill ~195 ~35 ~104 ~195 ~35 ~116 minecraft:redstone_wire replace
fill ~201 ~35 ~104 ~201 ~35 ~116 minecraft:redstone_wire replace
fill ~225 ~35 ~104 ~225 ~35 ~116 minecraft:redstone_wire replace
fill ~246 ~35 ~104 ~246 ~35 ~116 minecraft:redstone_wire replace
fill ~264 ~35 ~104 ~264 ~35 ~116 minecraft:redstone_wire replace
fill ~285 ~35 ~104 ~285 ~35 ~116 minecraft:redstone_wire replace
fill ~315 ~35 ~104 ~315 ~35 ~116 minecraft:redstone_wire replace
fill ~327 ~35 ~104 ~327 ~35 ~116 minecraft:redstone_wire replace
fill ~339 ~35 ~104 ~339 ~35 ~116 minecraft:redstone_wire replace
fill ~387 ~35 ~104 ~387 ~35 ~116 minecraft:redstone_wire replace
setblock ~318 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~108 ~318 ~35 ~120 minecraft:redstone_wire replace
fill ~336 ~35 ~108 ~336 ~35 ~120 minecraft:redstone_wire replace
fill ~342 ~35 ~108 ~342 ~35 ~120 minecraft:redstone_wire replace
fill ~354 ~35 ~108 ~354 ~35 ~120 minecraft:redstone_wire replace
fill ~360 ~35 ~108 ~360 ~35 ~120 minecraft:redstone_wire replace
fill ~378 ~35 ~108 ~378 ~35 ~120 minecraft:redstone_wire replace
setblock ~117 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~112 ~117 ~35 ~124 minecraft:redstone_wire replace
fill ~141 ~35 ~112 ~141 ~35 ~124 minecraft:redstone_wire replace
fill ~171 ~35 ~112 ~171 ~35 ~124 minecraft:redstone_wire replace
fill ~174 ~35 ~112 ~174 ~35 ~124 minecraft:redstone_wire replace
fill ~228 ~35 ~112 ~228 ~35 ~124 minecraft:redstone_wire replace
fill ~240 ~35 ~112 ~240 ~35 ~124 minecraft:redstone_wire replace
fill ~258 ~35 ~112 ~258 ~35 ~124 minecraft:redstone_wire replace
fill ~261 ~35 ~112 ~261 ~35 ~124 minecraft:redstone_wire replace
fill ~282 ~35 ~112 ~282 ~35 ~124 minecraft:redstone_wire replace
setblock ~93 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~120 ~93 ~35 ~132 minecraft:redstone_wire replace
fill ~120 ~35 ~120 ~120 ~35 ~132 minecraft:redstone_wire replace
fill ~144 ~35 ~120 ~144 ~35 ~132 minecraft:redstone_wire replace
fill ~150 ~35 ~120 ~150 ~35 ~132 minecraft:redstone_wire replace
fill ~168 ~35 ~120 ~168 ~35 ~132 minecraft:redstone_wire replace
fill ~195 ~35 ~120 ~195 ~35 ~132 minecraft:redstone_wire replace
fill ~201 ~35 ~120 ~201 ~35 ~132 minecraft:redstone_wire replace
fill ~225 ~35 ~120 ~225 ~35 ~132 minecraft:redstone_wire replace
fill ~246 ~35 ~120 ~246 ~35 ~132 minecraft:redstone_wire replace
fill ~264 ~35 ~120 ~264 ~35 ~132 minecraft:redstone_wire replace
fill ~285 ~35 ~120 ~285 ~35 ~132 minecraft:redstone_wire replace
fill ~315 ~35 ~120 ~315 ~35 ~132 minecraft:redstone_wire replace
fill ~327 ~35 ~120 ~327 ~35 ~132 minecraft:redstone_wire replace
fill ~339 ~35 ~120 ~339 ~35 ~132 minecraft:redstone_wire replace
fill ~387 ~35 ~120 ~387 ~35 ~132 minecraft:redstone_wire replace
setblock ~318 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~124 ~318 ~35 ~136 minecraft:redstone_wire replace
fill ~336 ~35 ~124 ~336 ~35 ~136 minecraft:redstone_wire replace
fill ~342 ~35 ~124 ~342 ~35 ~136 minecraft:redstone_wire replace
fill ~354 ~35 ~124 ~354 ~35 ~136 minecraft:redstone_wire replace
fill ~360 ~35 ~124 ~360 ~35 ~136 minecraft:redstone_wire replace
fill ~378 ~35 ~124 ~378 ~35 ~136 minecraft:redstone_wire replace
setblock ~117 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~128 ~117 ~35 ~140 minecraft:redstone_wire replace
fill ~141 ~35 ~128 ~141 ~35 ~140 minecraft:redstone_wire replace
fill ~171 ~35 ~128 ~171 ~35 ~140 minecraft:redstone_wire replace
fill ~174 ~35 ~128 ~174 ~35 ~140 minecraft:redstone_wire replace
fill ~228 ~35 ~128 ~228 ~35 ~140 minecraft:redstone_wire replace
fill ~240 ~35 ~128 ~240 ~35 ~140 minecraft:redstone_wire replace
fill ~258 ~35 ~128 ~258 ~35 ~140 minecraft:redstone_wire replace
fill ~261 ~35 ~128 ~261 ~35 ~140 minecraft:redstone_wire replace
fill ~282 ~35 ~128 ~282 ~35 ~140 minecraft:redstone_wire replace
setblock ~93 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~136 ~93 ~35 ~148 minecraft:redstone_wire replace
fill ~120 ~35 ~136 ~120 ~35 ~148 minecraft:redstone_wire replace
fill ~144 ~35 ~136 ~144 ~35 ~148 minecraft:redstone_wire replace
fill ~150 ~35 ~136 ~150 ~35 ~148 minecraft:redstone_wire replace
fill ~168 ~35 ~136 ~168 ~35 ~148 minecraft:redstone_wire replace
fill ~195 ~35 ~136 ~195 ~35 ~148 minecraft:redstone_wire replace
fill ~201 ~35 ~136 ~201 ~35 ~148 minecraft:redstone_wire replace
fill ~225 ~35 ~136 ~225 ~35 ~148 minecraft:redstone_wire replace
fill ~246 ~35 ~136 ~246 ~35 ~148 minecraft:redstone_wire replace
fill ~264 ~35 ~136 ~264 ~35 ~148 minecraft:redstone_wire replace
fill ~285 ~35 ~136 ~285 ~35 ~148 minecraft:redstone_wire replace
fill ~315 ~35 ~136 ~315 ~35 ~148 minecraft:redstone_wire replace
fill ~327 ~35 ~136 ~327 ~35 ~148 minecraft:redstone_wire replace
fill ~339 ~35 ~136 ~339 ~35 ~148 minecraft:redstone_wire replace
fill ~387 ~35 ~136 ~387 ~35 ~148 minecraft:redstone_wire replace
setblock ~318 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~140 ~318 ~35 ~152 minecraft:redstone_wire replace
fill ~336 ~35 ~140 ~336 ~35 ~152 minecraft:redstone_wire replace
fill ~342 ~35 ~140 ~342 ~35 ~152 minecraft:redstone_wire replace
fill ~354 ~35 ~140 ~354 ~35 ~152 minecraft:redstone_wire replace
fill ~360 ~35 ~140 ~360 ~35 ~152 minecraft:redstone_wire replace
fill ~378 ~35 ~140 ~378 ~35 ~152 minecraft:redstone_wire replace
setblock ~117 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~144 ~117 ~35 ~156 minecraft:redstone_wire replace
fill ~141 ~35 ~144 ~141 ~35 ~156 minecraft:redstone_wire replace
fill ~171 ~35 ~144 ~171 ~35 ~156 minecraft:redstone_wire replace
fill ~174 ~35 ~144 ~174 ~35 ~156 minecraft:redstone_wire replace
fill ~228 ~35 ~144 ~228 ~35 ~156 minecraft:redstone_wire replace
fill ~240 ~35 ~144 ~240 ~35 ~156 minecraft:redstone_wire replace
fill ~258 ~35 ~144 ~258 ~35 ~156 minecraft:redstone_wire replace
fill ~261 ~35 ~144 ~261 ~35 ~156 minecraft:redstone_wire replace
fill ~282 ~35 ~144 ~282 ~35 ~156 minecraft:redstone_wire replace
setblock ~93 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~152 ~93 ~35 ~164 minecraft:redstone_wire replace
fill ~120 ~35 ~152 ~120 ~35 ~164 minecraft:redstone_wire replace
fill ~144 ~35 ~152 ~144 ~35 ~164 minecraft:redstone_wire replace
fill ~150 ~35 ~152 ~150 ~35 ~164 minecraft:redstone_wire replace
fill ~168 ~35 ~152 ~168 ~35 ~164 minecraft:redstone_wire replace
fill ~195 ~35 ~152 ~195 ~35 ~164 minecraft:redstone_wire replace
fill ~201 ~35 ~152 ~201 ~35 ~164 minecraft:redstone_wire replace
fill ~225 ~35 ~152 ~225 ~35 ~164 minecraft:redstone_wire replace
fill ~246 ~35 ~152 ~246 ~35 ~164 minecraft:redstone_wire replace
fill ~264 ~35 ~152 ~264 ~35 ~164 minecraft:redstone_wire replace
fill ~285 ~35 ~152 ~285 ~35 ~164 minecraft:redstone_wire replace
fill ~315 ~35 ~152 ~315 ~35 ~164 minecraft:redstone_wire replace
fill ~327 ~35 ~152 ~327 ~35 ~164 minecraft:redstone_wire replace
fill ~339 ~35 ~152 ~339 ~35 ~164 minecraft:redstone_wire replace
fill ~387 ~35 ~152 ~387 ~35 ~164 minecraft:redstone_wire replace
setblock ~318 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~156 ~318 ~35 ~168 minecraft:redstone_wire replace
fill ~336 ~35 ~156 ~336 ~35 ~168 minecraft:redstone_wire replace
fill ~342 ~35 ~156 ~342 ~35 ~168 minecraft:redstone_wire replace
fill ~354 ~35 ~156 ~354 ~35 ~168 minecraft:redstone_wire replace
fill ~360 ~35 ~156 ~360 ~35 ~168 minecraft:redstone_wire replace
fill ~378 ~35 ~156 ~378 ~35 ~168 minecraft:redstone_wire replace
setblock ~117 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~160 ~117 ~35 ~172 minecraft:redstone_wire replace
fill ~141 ~35 ~160 ~141 ~35 ~172 minecraft:redstone_wire replace
fill ~171 ~35 ~160 ~171 ~35 ~172 minecraft:redstone_wire replace
fill ~174 ~35 ~160 ~174 ~35 ~172 minecraft:redstone_wire replace
fill ~228 ~35 ~160 ~228 ~35 ~172 minecraft:redstone_wire replace
fill ~240 ~35 ~160 ~240 ~35 ~172 minecraft:redstone_wire replace
fill ~258 ~35 ~160 ~258 ~35 ~172 minecraft:redstone_wire replace
fill ~261 ~35 ~160 ~261 ~35 ~172 minecraft:redstone_wire replace
fill ~282 ~35 ~160 ~282 ~35 ~172 minecraft:redstone_wire replace
setblock ~93 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~168 ~93 ~35 ~180 minecraft:redstone_wire replace
fill ~120 ~35 ~168 ~120 ~35 ~180 minecraft:redstone_wire replace
fill ~144 ~35 ~168 ~144 ~35 ~180 minecraft:redstone_wire replace
fill ~150 ~35 ~168 ~150 ~35 ~180 minecraft:redstone_wire replace
fill ~168 ~35 ~168 ~168 ~35 ~180 minecraft:redstone_wire replace
fill ~195 ~35 ~168 ~195 ~35 ~180 minecraft:redstone_wire replace
fill ~201 ~35 ~168 ~201 ~35 ~180 minecraft:redstone_wire replace
fill ~225 ~35 ~168 ~225 ~35 ~180 minecraft:redstone_wire replace
fill ~246 ~35 ~168 ~246 ~35 ~180 minecraft:redstone_wire replace
fill ~264 ~35 ~168 ~264 ~35 ~180 minecraft:redstone_wire replace
fill ~285 ~35 ~168 ~285 ~35 ~180 minecraft:redstone_wire replace
fill ~315 ~35 ~168 ~315 ~35 ~180 minecraft:redstone_wire replace
fill ~327 ~35 ~168 ~327 ~35 ~180 minecraft:redstone_wire replace
fill ~339 ~35 ~168 ~339 ~35 ~180 minecraft:redstone_wire replace
fill ~387 ~35 ~168 ~387 ~35 ~180 minecraft:redstone_wire replace
setblock ~318 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~172 ~318 ~35 ~184 minecraft:redstone_wire replace
fill ~336 ~35 ~172 ~336 ~35 ~184 minecraft:redstone_wire replace
fill ~342 ~35 ~172 ~342 ~35 ~184 minecraft:redstone_wire replace
fill ~354 ~35 ~172 ~354 ~35 ~184 minecraft:redstone_wire replace
fill ~360 ~35 ~172 ~360 ~35 ~184 minecraft:redstone_wire replace
fill ~378 ~35 ~172 ~378 ~35 ~184 minecraft:redstone_wire replace
setblock ~117 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~176 ~117 ~35 ~188 minecraft:redstone_wire replace
fill ~141 ~35 ~176 ~141 ~35 ~188 minecraft:redstone_wire replace
fill ~171 ~35 ~176 ~171 ~35 ~188 minecraft:redstone_wire replace
fill ~174 ~35 ~176 ~174 ~35 ~188 minecraft:redstone_wire replace
fill ~228 ~35 ~176 ~228 ~35 ~188 minecraft:redstone_wire replace
fill ~240 ~35 ~176 ~240 ~35 ~188 minecraft:redstone_wire replace
fill ~258 ~35 ~176 ~258 ~35 ~188 minecraft:redstone_wire replace
fill ~261 ~35 ~176 ~261 ~35 ~188 minecraft:redstone_wire replace
fill ~282 ~35 ~176 ~282 ~35 ~188 minecraft:redstone_wire replace
setblock ~93 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~184 ~93 ~35 ~196 minecraft:redstone_wire replace
fill ~120 ~35 ~184 ~120 ~35 ~196 minecraft:redstone_wire replace
fill ~144 ~35 ~184 ~144 ~35 ~196 minecraft:redstone_wire replace
fill ~150 ~35 ~184 ~150 ~35 ~196 minecraft:redstone_wire replace
fill ~168 ~35 ~184 ~168 ~35 ~196 minecraft:redstone_wire replace
fill ~195 ~35 ~184 ~195 ~35 ~196 minecraft:redstone_wire replace
fill ~201 ~35 ~184 ~201 ~35 ~196 minecraft:redstone_wire replace
fill ~225 ~35 ~184 ~225 ~35 ~196 minecraft:redstone_wire replace
fill ~246 ~35 ~184 ~246 ~35 ~196 minecraft:redstone_wire replace
fill ~264 ~35 ~184 ~264 ~35 ~196 minecraft:redstone_wire replace
fill ~285 ~35 ~184 ~285 ~35 ~196 minecraft:redstone_wire replace
fill ~315 ~35 ~184 ~315 ~35 ~196 minecraft:redstone_wire replace
fill ~327 ~35 ~184 ~327 ~35 ~196 minecraft:redstone_wire replace
fill ~339 ~35 ~184 ~339 ~35 ~196 minecraft:redstone_wire replace
fill ~387 ~35 ~184 ~387 ~35 ~196 minecraft:redstone_wire replace
setblock ~318 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~188 ~318 ~35 ~200 minecraft:redstone_wire replace
fill ~336 ~35 ~188 ~336 ~35 ~200 minecraft:redstone_wire replace
fill ~342 ~35 ~188 ~342 ~35 ~200 minecraft:redstone_wire replace
fill ~354 ~35 ~188 ~354 ~35 ~200 minecraft:redstone_wire replace
fill ~360 ~35 ~188 ~360 ~35 ~200 minecraft:redstone_wire replace
fill ~378 ~35 ~188 ~378 ~35 ~200 minecraft:redstone_wire replace
setblock ~117 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~35 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~192 ~117 ~35 ~204 minecraft:redstone_wire replace
fill ~141 ~35 ~192 ~141 ~35 ~204 minecraft:redstone_wire replace
fill ~171 ~35 ~192 ~171 ~35 ~204 minecraft:redstone_wire replace
fill ~174 ~35 ~192 ~174 ~35 ~204 minecraft:redstone_wire replace
fill ~228 ~35 ~192 ~228 ~35 ~204 minecraft:redstone_wire replace
fill ~240 ~35 ~192 ~240 ~35 ~204 minecraft:redstone_wire replace
fill ~258 ~35 ~192 ~258 ~35 ~204 minecraft:redstone_wire replace
fill ~261 ~35 ~192 ~261 ~35 ~204 minecraft:redstone_wire replace
fill ~282 ~35 ~192 ~282 ~35 ~204 minecraft:redstone_wire replace
setblock ~93 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~35 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~200 ~93 ~35 ~212 minecraft:redstone_wire replace
fill ~120 ~35 ~200 ~120 ~35 ~212 minecraft:redstone_wire replace
fill ~144 ~35 ~200 ~144 ~35 ~212 minecraft:redstone_wire replace
fill ~150 ~35 ~200 ~150 ~35 ~212 minecraft:redstone_wire replace
fill ~168 ~35 ~200 ~168 ~35 ~212 minecraft:redstone_wire replace
fill ~195 ~35 ~200 ~195 ~35 ~212 minecraft:redstone_wire replace
fill ~201 ~35 ~200 ~201 ~35 ~212 minecraft:redstone_wire replace
fill ~225 ~35 ~200 ~225 ~35 ~212 minecraft:redstone_wire replace
fill ~246 ~35 ~200 ~246 ~35 ~212 minecraft:redstone_wire replace
fill ~264 ~35 ~200 ~264 ~35 ~212 minecraft:redstone_wire replace
fill ~285 ~35 ~200 ~285 ~35 ~212 minecraft:redstone_wire replace
fill ~315 ~35 ~200 ~315 ~35 ~212 minecraft:redstone_wire replace
fill ~327 ~35 ~200 ~327 ~35 ~212 minecraft:redstone_wire replace
fill ~339 ~35 ~200 ~339 ~35 ~212 minecraft:redstone_wire replace
fill ~387 ~35 ~200 ~387 ~35 ~212 minecraft:redstone_wire replace
setblock ~318 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~35 ~204 ~318 ~35 ~216 minecraft:redstone_wire replace
fill ~336 ~35 ~204 ~336 ~35 ~216 minecraft:redstone_wire replace
fill ~342 ~35 ~204 ~342 ~35 ~216 minecraft:redstone_wire replace
fill ~354 ~35 ~204 ~354 ~35 ~216 minecraft:redstone_wire replace
fill ~360 ~35 ~204 ~360 ~35 ~216 minecraft:redstone_wire replace
fill ~378 ~35 ~204 ~378 ~35 ~216 minecraft:redstone_wire replace
setblock ~117 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~35 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
