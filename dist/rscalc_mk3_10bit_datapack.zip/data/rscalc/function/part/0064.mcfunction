fill ~273 ~27 ~228 ~273 ~27 ~240 minecraft:redstone_wire replace
fill ~318 ~27 ~228 ~318 ~27 ~240 minecraft:redstone_wire replace
setblock ~84 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~232 ~84 ~27 ~244 minecraft:redstone_wire replace
fill ~96 ~27 ~232 ~96 ~27 ~244 minecraft:redstone_wire replace
fill ~102 ~27 ~232 ~102 ~27 ~244 minecraft:redstone_wire replace
fill ~111 ~27 ~232 ~111 ~27 ~244 minecraft:redstone_wire replace
fill ~141 ~27 ~232 ~141 ~27 ~244 minecraft:redstone_wire replace
fill ~156 ~27 ~232 ~156 ~27 ~244 minecraft:redstone_wire replace
fill ~159 ~27 ~232 ~159 ~27 ~244 minecraft:redstone_wire replace
fill ~168 ~27 ~232 ~168 ~27 ~244 minecraft:redstone_wire replace
fill ~171 ~27 ~232 ~171 ~27 ~244 minecraft:redstone_wire replace
fill ~195 ~27 ~232 ~195 ~27 ~244 minecraft:redstone_wire replace
fill ~201 ~27 ~232 ~201 ~27 ~244 minecraft:redstone_wire replace
fill ~222 ~27 ~232 ~222 ~27 ~244 minecraft:redstone_wire replace
fill ~234 ~27 ~232 ~234 ~27 ~244 minecraft:redstone_wire replace
fill ~258 ~27 ~232 ~258 ~27 ~244 minecraft:redstone_wire replace
fill ~276 ~27 ~232 ~276 ~27 ~244 minecraft:redstone_wire replace
fill ~291 ~27 ~232 ~291 ~27 ~244 minecraft:redstone_wire replace
fill ~312 ~27 ~232 ~312 ~27 ~244 minecraft:redstone_wire replace
fill ~330 ~27 ~232 ~330 ~27 ~244 minecraft:redstone_wire replace
fill ~336 ~27 ~232 ~336 ~27 ~244 minecraft:redstone_wire replace
setblock ~87 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~27 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~236 ~87 ~27 ~248 minecraft:redstone_wire replace
fill ~99 ~27 ~236 ~99 ~27 ~248 minecraft:redstone_wire replace
fill ~105 ~27 ~236 ~105 ~27 ~248 minecraft:redstone_wire replace
fill ~120 ~27 ~236 ~120 ~27 ~248 minecraft:redstone_wire replace
fill ~144 ~27 ~236 ~144 ~27 ~248 minecraft:redstone_wire replace
fill ~180 ~27 ~236 ~180 ~27 ~248 minecraft:redstone_wire replace
fill ~183 ~27 ~236 ~183 ~27 ~248 minecraft:redstone_wire replace
fill ~204 ~27 ~236 ~204 ~27 ~248 minecraft:redstone_wire replace
fill ~210 ~27 ~236 ~210 ~27 ~248 minecraft:redstone_wire replace
fill ~213 ~27 ~236 ~213 ~27 ~248 minecraft:redstone_wire replace
fill ~228 ~27 ~236 ~228 ~27 ~248 minecraft:redstone_wire replace
fill ~231 ~27 ~236 ~231 ~27 ~248 minecraft:redstone_wire replace
fill ~252 ~27 ~236 ~252 ~27 ~248 minecraft:redstone_wire replace
fill ~255 ~27 ~236 ~255 ~27 ~248 minecraft:redstone_wire replace
fill ~261 ~27 ~236 ~261 ~27 ~248 minecraft:redstone_wire replace
fill ~270 ~27 ~236 ~270 ~27 ~248 minecraft:redstone_wire replace
fill ~279 ~27 ~236 ~279 ~27 ~248 minecraft:redstone_wire replace
fill ~285 ~27 ~236 ~285 ~27 ~248 minecraft:redstone_wire replace
fill ~288 ~27 ~236 ~288 ~27 ~248 minecraft:redstone_wire replace
fill ~303 ~27 ~236 ~303 ~27 ~248 minecraft:redstone_wire replace
fill ~306 ~27 ~236 ~306 ~27 ~248 minecraft:redstone_wire replace
fill ~333 ~27 ~236 ~333 ~27 ~248 minecraft:redstone_wire replace
setblock ~90 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~240 ~90 ~27 ~252 minecraft:redstone_wire replace
fill ~108 ~27 ~240 ~108 ~27 ~252 minecraft:redstone_wire replace
fill ~114 ~27 ~240 ~114 ~27 ~252 minecraft:redstone_wire replace
fill ~123 ~27 ~240 ~123 ~27 ~252 minecraft:redstone_wire replace
fill ~138 ~27 ~240 ~138 ~27 ~252 minecraft:redstone_wire replace
fill ~150 ~27 ~240 ~150 ~27 ~252 minecraft:redstone_wire replace
fill ~174 ~27 ~240 ~174 ~27 ~252 minecraft:redstone_wire replace
fill ~189 ~27 ~240 ~189 ~27 ~252 minecraft:redstone_wire replace
fill ~198 ~27 ~240 ~198 ~27 ~252 minecraft:redstone_wire replace
fill ~216 ~27 ~240 ~216 ~27 ~252 minecraft:redstone_wire replace
fill ~237 ~27 ~240 ~237 ~27 ~252 minecraft:redstone_wire replace
fill ~243 ~27 ~240 ~243 ~27 ~252 minecraft:redstone_wire replace
fill ~267 ~27 ~240 ~267 ~27 ~252 minecraft:redstone_wire replace
fill ~294 ~27 ~240 ~294 ~27 ~252 minecraft:redstone_wire replace
fill ~297 ~27 ~240 ~297 ~27 ~252 minecraft:redstone_wire replace
fill ~315 ~27 ~240 ~315 ~27 ~252 minecraft:redstone_wire replace
fill ~321 ~27 ~240 ~321 ~27 ~252 minecraft:redstone_wire replace
fill ~324 ~27 ~240 ~324 ~27 ~252 minecraft:redstone_wire replace
fill ~342 ~27 ~240 ~342 ~27 ~252 minecraft:redstone_wire replace
setblock ~78 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~244 ~78 ~27 ~256 minecraft:redstone_wire replace
fill ~81 ~27 ~244 ~81 ~27 ~256 minecraft:redstone_wire replace
fill ~117 ~27 ~244 ~117 ~27 ~256 minecraft:redstone_wire replace
fill ~129 ~27 ~244 ~129 ~27 ~256 minecraft:redstone_wire replace
fill ~132 ~27 ~244 ~132 ~27 ~256 minecraft:redstone_wire replace
fill ~135 ~27 ~244 ~135 ~27 ~256 minecraft:redstone_wire replace
fill ~165 ~27 ~244 ~165 ~27 ~256 minecraft:redstone_wire replace
fill ~186 ~27 ~244 ~186 ~27 ~256 minecraft:redstone_wire replace
fill ~192 ~27 ~244 ~192 ~27 ~256 minecraft:redstone_wire replace
fill ~219 ~27 ~244 ~219 ~27 ~256 minecraft:redstone_wire replace
fill ~240 ~27 ~244 ~240 ~27 ~256 minecraft:redstone_wire replace
fill ~246 ~27 ~244 ~246 ~27 ~256 minecraft:redstone_wire replace
fill ~264 ~27 ~244 ~264 ~27 ~256 minecraft:redstone_wire replace
fill ~273 ~27 ~244 ~273 ~27 ~256 minecraft:redstone_wire replace
fill ~318 ~27 ~244 ~318 ~27 ~256 minecraft:redstone_wire replace
fill ~345 ~27 ~244 ~345 ~27 ~256 minecraft:redstone_wire replace
setblock ~84 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~248 ~84 ~27 ~260 minecraft:redstone_wire replace
fill ~96 ~27 ~248 ~96 ~27 ~260 minecraft:redstone_wire replace
fill ~102 ~27 ~248 ~102 ~27 ~260 minecraft:redstone_wire replace
fill ~111 ~27 ~248 ~111 ~27 ~260 minecraft:redstone_wire replace
fill ~141 ~27 ~248 ~141 ~27 ~260 minecraft:redstone_wire replace
fill ~156 ~27 ~248 ~156 ~27 ~260 minecraft:redstone_wire replace
fill ~159 ~27 ~248 ~159 ~27 ~260 minecraft:redstone_wire replace
fill ~168 ~27 ~248 ~168 ~27 ~260 minecraft:redstone_wire replace
fill ~171 ~27 ~248 ~171 ~27 ~260 minecraft:redstone_wire replace
fill ~195 ~27 ~248 ~195 ~27 ~260 minecraft:redstone_wire replace
fill ~201 ~27 ~248 ~201 ~27 ~260 minecraft:redstone_wire replace
fill ~222 ~27 ~248 ~222 ~27 ~260 minecraft:redstone_wire replace
fill ~234 ~27 ~248 ~234 ~27 ~260 minecraft:redstone_wire replace
fill ~258 ~27 ~248 ~258 ~27 ~260 minecraft:redstone_wire replace
fill ~276 ~27 ~248 ~276 ~27 ~260 minecraft:redstone_wire replace
fill ~291 ~27 ~248 ~291 ~27 ~260 minecraft:redstone_wire replace
fill ~312 ~27 ~248 ~312 ~27 ~260 minecraft:redstone_wire replace
fill ~330 ~27 ~248 ~330 ~27 ~260 minecraft:redstone_wire replace
fill ~336 ~27 ~248 ~336 ~27 ~260 minecraft:redstone_wire replace
fill ~348 ~27 ~248 ~348 ~27 ~260 minecraft:redstone_wire replace
setblock ~87 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~27 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~252 ~87 ~27 ~264 minecraft:redstone_wire replace
fill ~99 ~27 ~252 ~99 ~27 ~264 minecraft:redstone_wire replace
fill ~105 ~27 ~252 ~105 ~27 ~264 minecraft:redstone_wire replace
fill ~120 ~27 ~252 ~120 ~27 ~264 minecraft:redstone_wire replace
fill ~144 ~27 ~252 ~144 ~27 ~264 minecraft:redstone_wire replace
fill ~180 ~27 ~252 ~180 ~27 ~264 minecraft:redstone_wire replace
fill ~183 ~27 ~252 ~183 ~27 ~264 minecraft:redstone_wire replace
fill ~204 ~27 ~252 ~204 ~27 ~264 minecraft:redstone_wire replace
fill ~210 ~27 ~252 ~210 ~27 ~264 minecraft:redstone_wire replace
fill ~213 ~27 ~252 ~213 ~27 ~264 minecraft:redstone_wire replace
fill ~228 ~27 ~252 ~228 ~27 ~264 minecraft:redstone_wire replace
fill ~231 ~27 ~252 ~231 ~27 ~264 minecraft:redstone_wire replace
fill ~252 ~27 ~252 ~252 ~27 ~264 minecraft:redstone_wire replace
fill ~255 ~27 ~252 ~255 ~27 ~264 minecraft:redstone_wire replace
fill ~261 ~27 ~252 ~261 ~27 ~264 minecraft:redstone_wire replace
fill ~270 ~27 ~252 ~270 ~27 ~264 minecraft:redstone_wire replace
fill ~279 ~27 ~252 ~279 ~27 ~264 minecraft:redstone_wire replace
fill ~285 ~27 ~252 ~285 ~27 ~264 minecraft:redstone_wire replace
fill ~288 ~27 ~252 ~288 ~27 ~264 minecraft:redstone_wire replace
fill ~303 ~27 ~252 ~303 ~27 ~264 minecraft:redstone_wire replace
fill ~306 ~27 ~252 ~306 ~27 ~264 minecraft:redstone_wire replace
fill ~333 ~27 ~252 ~333 ~27 ~264 minecraft:redstone_wire replace
fill ~351 ~27 ~252 ~351 ~27 ~264 minecraft:redstone_wire replace
setblock ~90 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~256 ~90 ~27 ~268 minecraft:redstone_wire replace
fill ~108 ~27 ~256 ~108 ~27 ~268 minecraft:redstone_wire replace
fill ~114 ~27 ~256 ~114 ~27 ~268 minecraft:redstone_wire replace
fill ~123 ~27 ~256 ~123 ~27 ~268 minecraft:redstone_wire replace
fill ~138 ~27 ~256 ~138 ~27 ~268 minecraft:redstone_wire replace
fill ~147 ~27 ~256 ~147 ~27 ~266 minecraft:redstone_wire replace
fill ~150 ~27 ~256 ~150 ~27 ~268 minecraft:redstone_wire replace
fill ~174 ~27 ~256 ~174 ~27 ~268 minecraft:redstone_wire replace
fill ~189 ~27 ~256 ~189 ~27 ~268 minecraft:redstone_wire replace
fill ~198 ~27 ~256 ~198 ~27 ~268 minecraft:redstone_wire replace
fill ~216 ~27 ~256 ~216 ~27 ~268 minecraft:redstone_wire replace
fill ~237 ~27 ~256 ~237 ~27 ~268 minecraft:redstone_wire replace
fill ~243 ~27 ~256 ~243 ~27 ~268 minecraft:redstone_wire replace
fill ~267 ~27 ~256 ~267 ~27 ~268 minecraft:redstone_wire replace
fill ~294 ~27 ~256 ~294 ~27 ~268 minecraft:redstone_wire replace
fill ~297 ~27 ~256 ~297 ~27 ~268 minecraft:redstone_wire replace
fill ~315 ~27 ~256 ~315 ~27 ~268 minecraft:redstone_wire replace
fill ~321 ~27 ~256 ~321 ~27 ~268 minecraft:redstone_wire replace
fill ~324 ~27 ~256 ~324 ~27 ~268 minecraft:redstone_wire replace
fill ~342 ~27 ~256 ~342 ~27 ~268 minecraft:redstone_wire replace
setblock ~132 ~27 ~257 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~257 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~27 ~258 ~132 ~27 ~260 minecraft:redstone_wire replace
fill ~135 ~27 ~258 ~135 ~27 ~264 minecraft:redstone_wire replace
setblock ~165 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~27 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~260 ~78 ~27 ~272 minecraft:redstone_wire replace
fill ~81 ~27 ~260 ~81 ~27 ~272 minecraft:redstone_wire replace
fill ~117 ~27 ~260 ~117 ~27 ~272 minecraft:redstone_wire replace
fill ~129 ~27 ~260 ~129 ~27 ~272 minecraft:redstone_wire replace
fill ~165 ~27 ~260 ~165 ~27 ~272 minecraft:redstone_wire replace
fill ~186 ~27 ~260 ~186 ~27 ~272 minecraft:redstone_wire replace
fill ~192 ~27 ~260 ~192 ~27 ~272 minecraft:redstone_wire replace
fill ~219 ~27 ~260 ~219 ~27 ~272 minecraft:redstone_wire replace
fill ~240 ~27 ~260 ~240 ~27 ~272 minecraft:redstone_wire replace
fill ~246 ~27 ~260 ~246 ~27 ~272 minecraft:redstone_wire replace
fill ~264 ~27 ~260 ~264 ~27 ~272 minecraft:redstone_wire replace
fill ~273 ~27 ~260 ~273 ~27 ~272 minecraft:redstone_wire replace
fill ~318 ~27 ~260 ~318 ~27 ~272 minecraft:redstone_wire replace
fill ~339 ~27 ~260 ~339 ~27 ~272 minecraft:redstone_wire replace
fill ~345 ~27 ~260 ~345 ~27 ~272 minecraft:redstone_wire replace
setblock ~111 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~262 ~111 ~27 ~274 minecraft:redstone_wire replace
setblock ~141 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~262 ~171 ~27 ~274 minecraft:redstone_wire replace
setblock ~195 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~262 ~234 ~27 ~274 minecraft:redstone_wire replace
setblock ~258 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~262 ~312 ~27 ~274 minecraft:redstone_wire replace
setblock ~330 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~264 ~84 ~27 ~276 minecraft:redstone_wire replace
fill ~96 ~27 ~264 ~96 ~27 ~276 minecraft:redstone_wire replace
fill ~102 ~27 ~264 ~102 ~27 ~276 minecraft:redstone_wire replace
fill ~141 ~27 ~264 ~141 ~27 ~276 minecraft:redstone_wire replace
fill ~156 ~27 ~264 ~156 ~27 ~270 minecraft:redstone_wire replace
fill ~159 ~27 ~264 ~159 ~27 ~274 minecraft:redstone_wire replace
fill ~168 ~27 ~264 ~168 ~27 ~276 minecraft:redstone_wire replace
fill ~195 ~27 ~264 ~195 ~27 ~276 minecraft:redstone_wire replace
fill ~201 ~27 ~264 ~201 ~27 ~276 minecraft:redstone_wire replace
fill ~222 ~27 ~264 ~222 ~27 ~276 minecraft:redstone_wire replace
fill ~258 ~27 ~264 ~258 ~27 ~276 minecraft:redstone_wire replace
fill ~276 ~27 ~264 ~276 ~27 ~276 minecraft:redstone_wire replace
fill ~291 ~27 ~264 ~291 ~27 ~276 minecraft:redstone_wire replace
fill ~330 ~27 ~264 ~330 ~27 ~276 minecraft:redstone_wire replace
fill ~336 ~27 ~264 ~336 ~27 ~276 minecraft:redstone_wire replace
fill ~348 ~27 ~264 ~348 ~27 ~276 minecraft:redstone_wire replace
setblock ~87 ~27 ~265 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~27 ~265 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~27 ~265 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~266 ~87 ~27 ~278 minecraft:redstone_wire replace
setblock ~99 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~266 ~333 ~27 ~278 minecraft:redstone_wire replace
fill ~351 ~27 ~266 ~351 ~27 ~278 minecraft:redstone_wire replace
fill ~99 ~27 ~268 ~99 ~27 ~280 minecraft:redstone_wire replace
fill ~105 ~27 ~268 ~105 ~27 ~280 minecraft:redstone_wire replace
fill ~120 ~27 ~268 ~120 ~27 ~280 minecraft:redstone_wire replace
fill ~144 ~27 ~268 ~144 ~27 ~280 minecraft:redstone_wire replace
setblock ~147 ~27 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~27 ~268 ~180 ~27 ~278 minecraft:redstone_wire replace
fill ~183 ~27 ~268 ~183 ~27 ~280 minecraft:redstone_wire replace
fill ~204 ~27 ~268 ~204 ~27 ~280 minecraft:redstone_wire replace
fill ~210 ~27 ~268 ~210 ~27 ~280 minecraft:redstone_wire replace
fill ~213 ~27 ~268 ~213 ~27 ~280 minecraft:redstone_wire replace
fill ~228 ~27 ~268 ~228 ~27 ~280 minecraft:redstone_wire replace
fill ~231 ~27 ~268 ~231 ~27 ~280 minecraft:redstone_wire replace
fill ~252 ~27 ~268 ~252 ~27 ~280 minecraft:redstone_wire replace
fill ~255 ~27 ~268 ~255 ~27 ~280 minecraft:redstone_wire replace
fill ~261 ~27 ~268 ~261 ~27 ~280 minecraft:redstone_wire replace
fill ~270 ~27 ~268 ~270 ~27 ~280 minecraft:redstone_wire replace
fill ~279 ~27 ~268 ~279 ~27 ~280 minecraft:redstone_wire replace
fill ~285 ~27 ~268 ~285 ~27 ~280 minecraft:redstone_wire replace
fill ~288 ~27 ~268 ~288 ~27 ~280 minecraft:redstone_wire replace
fill ~303 ~27 ~268 ~303 ~27 ~280 minecraft:redstone_wire replace
fill ~306 ~27 ~268 ~306 ~27 ~280 minecraft:redstone_wire replace
setblock ~123 ~27 ~269 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~270 ~123 ~27 ~282 minecraft:redstone_wire replace
setblock ~138 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~272 ~90 ~27 ~284 minecraft:redstone_wire replace
fill ~108 ~27 ~272 ~108 ~27 ~284 minecraft:redstone_wire replace
fill ~114 ~27 ~272 ~114 ~27 ~284 minecraft:redstone_wire replace
fill ~138 ~27 ~272 ~138 ~27 ~284 minecraft:redstone_wire replace
fill ~150 ~27 ~272 ~150 ~27 ~284 minecraft:redstone_wire replace
setblock ~156 ~27 ~272 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~27 ~272 ~174 ~27 ~284 minecraft:redstone_wire replace
fill ~189 ~27 ~272 ~189 ~27 ~284 minecraft:redstone_wire replace
fill ~198 ~27 ~272 ~198 ~27 ~284 minecraft:redstone_wire replace
fill ~216 ~27 ~272 ~216 ~27 ~284 minecraft:redstone_wire replace
fill ~237 ~27 ~272 ~237 ~27 ~284 minecraft:redstone_wire replace
fill ~243 ~27 ~272 ~243 ~27 ~284 minecraft:redstone_wire replace
fill ~267 ~27 ~272 ~267 ~27 ~284 minecraft:redstone_wire replace
fill ~294 ~27 ~272 ~294 ~27 ~284 minecraft:redstone_wire replace
fill ~297 ~27 ~272 ~297 ~27 ~284 minecraft:redstone_wire replace
fill ~315 ~27 ~272 ~315 ~27 ~284 minecraft:redstone_wire replace
fill ~321 ~27 ~272 ~321 ~27 ~284 minecraft:redstone_wire replace
fill ~324 ~27 ~272 ~324 ~27 ~284 minecraft:redstone_wire replace
fill ~342 ~27 ~272 ~342 ~27 ~284 minecraft:redstone_wire replace
setblock ~81 ~27 ~273 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~27 ~273 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~27 ~273 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~274 ~81 ~27 ~286 minecraft:redstone_wire replace
setblock ~117 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~274 ~318 ~27 ~286 minecraft:redstone_wire replace
setblock ~339 ~27 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~274 ~345 ~27 ~286 minecraft:redstone_wire replace
fill ~78 ~27 ~276 ~78 ~27 ~288 minecraft:redstone_wire replace
setblock ~111 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~27 ~276 ~117 ~27 ~288 minecraft:redstone_wire replace
fill ~129 ~27 ~276 ~129 ~27 ~288 minecraft:redstone_wire replace
setblock ~159 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~27 ~276 ~165 ~27 ~288 minecraft:redstone_wire replace
setblock ~171 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~276 ~186 ~27 ~288 minecraft:redstone_wire replace
fill ~192 ~27 ~276 ~192 ~27 ~288 minecraft:redstone_wire replace
fill ~219 ~27 ~276 ~219 ~27 ~288 minecraft:redstone_wire replace
setblock ~234 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~27 ~276 ~240 ~27 ~288 minecraft:redstone_wire replace
fill ~246 ~27 ~276 ~246 ~27 ~288 minecraft:redstone_wire replace
fill ~264 ~27 ~276 ~264 ~27 ~288 minecraft:redstone_wire replace
fill ~273 ~27 ~276 ~273 ~27 ~288 minecraft:redstone_wire replace
setblock ~312 ~27 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~276 ~339 ~27 ~288 minecraft:redstone_wire replace
setblock ~84 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~27 ~278 ~111 ~27 ~290 minecraft:redstone_wire replace
setblock ~141 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~27 ~278 ~171 ~27 ~290 minecraft:redstone_wire replace
setblock ~195 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~27 ~278 ~234 ~27 ~290 minecraft:redstone_wire replace
setblock ~258 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~27 ~278 ~312 ~27 ~290 minecraft:redstone_wire replace
setblock ~330 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~280 ~84 ~27 ~292 minecraft:redstone_wire replace
setblock ~87 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~280 ~93 ~27 ~292 minecraft:redstone_wire replace
fill ~96 ~27 ~280 ~96 ~27 ~292 minecraft:redstone_wire replace
fill ~102 ~27 ~280 ~102 ~27 ~292 minecraft:redstone_wire replace
fill ~141 ~27 ~280 ~141 ~27 ~292 minecraft:redstone_wire replace
fill ~168 ~27 ~280 ~168 ~27 ~292 minecraft:redstone_wire replace
setblock ~180 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~27 ~280 ~195 ~27 ~292 minecraft:redstone_wire replace
fill ~201 ~27 ~280 ~201 ~27 ~292 minecraft:redstone_wire replace
fill ~222 ~27 ~280 ~222 ~27 ~292 minecraft:redstone_wire replace
fill ~258 ~27 ~280 ~258 ~27 ~292 minecraft:redstone_wire replace
fill ~276 ~27 ~280 ~276 ~27 ~292 minecraft:redstone_wire replace
fill ~291 ~27 ~280 ~291 ~27 ~292 minecraft:redstone_wire replace
fill ~330 ~27 ~280 ~330 ~27 ~292 minecraft:redstone_wire replace
setblock ~333 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~27 ~280 ~336 ~27 ~292 minecraft:redstone_wire replace
fill ~348 ~27 ~280 ~348 ~27 ~292 minecraft:redstone_wire replace
setblock ~351 ~27 ~280 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~281 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~282 ~87 ~27 ~294 minecraft:redstone_wire replace
setblock ~99 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~282 ~270 ~27 ~294 minecraft:redstone_wire replace
setblock ~279 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~27 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~333 ~27 ~282 ~333 ~27 ~294 minecraft:redstone_wire replace
fill ~351 ~27 ~282 ~351 ~27 ~294 minecraft:redstone_wire replace
fill ~99 ~27 ~284 ~99 ~27 ~296 minecraft:redstone_wire replace
fill ~105 ~27 ~284 ~105 ~27 ~296 minecraft:redstone_wire replace
fill ~120 ~27 ~284 ~120 ~27 ~296 minecraft:redstone_wire replace
setblock ~123 ~27 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~284 ~144 ~27 ~296 minecraft:redstone_wire replace
fill ~162 ~27 ~284 ~162 ~27 ~296 minecraft:redstone_wire replace
setblock ~183 ~27 ~284 minecraft:redstone_wire replace
fill ~204 ~27 ~284 ~204 ~27 ~296 minecraft:redstone_wire replace
fill ~210 ~27 ~284 ~210 ~27 ~288 minecraft:redstone_wire replace
fill ~213 ~27 ~284 ~213 ~27 ~290 minecraft:redstone_wire replace
fill ~228 ~27 ~284 ~228 ~27 ~294 minecraft:redstone_wire replace
fill ~231 ~27 ~284 ~231 ~27 ~296 minecraft:redstone_wire replace
fill ~252 ~27 ~284 ~252 ~27 ~296 minecraft:redstone_wire replace
fill ~255 ~27 ~284 ~255 ~27 ~296 minecraft:redstone_wire replace
fill ~261 ~27 ~284 ~261 ~27 ~296 minecraft:redstone_wire replace
fill ~279 ~27 ~284 ~279 ~27 ~296 minecraft:redstone_wire replace
fill ~285 ~27 ~284 ~285 ~27 ~296 minecraft:redstone_wire replace
fill ~288 ~27 ~284 ~288 ~27 ~296 minecraft:redstone_wire replace
fill ~303 ~27 ~284 ~303 ~27 ~296 minecraft:redstone_wire replace
fill ~306 ~27 ~284 ~306 ~27 ~296 minecraft:redstone_wire replace
setblock ~90 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~27 ~286 ~123 ~27 ~298 minecraft:redstone_wire replace
setblock ~138 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~288 ~90 ~27 ~300 minecraft:redstone_wire replace
fill ~108 ~27 ~288 ~108 ~27 ~300 minecraft:redstone_wire replace
fill ~114 ~27 ~288 ~114 ~27 ~300 minecraft:redstone_wire replace
fill ~138 ~27 ~288 ~138 ~27 ~300 minecraft:redstone_wire replace
fill ~150 ~27 ~288 ~150 ~27 ~300 minecraft:redstone_wire replace
fill ~174 ~27 ~288 ~174 ~27 ~300 minecraft:redstone_wire replace
fill ~189 ~27 ~288 ~189 ~27 ~300 minecraft:redstone_wire replace
fill ~198 ~27 ~288 ~198 ~27 ~300 minecraft:redstone_wire replace
fill ~216 ~27 ~288 ~216 ~27 ~300 minecraft:redstone_wire replace
fill ~237 ~27 ~288 ~237 ~27 ~300 minecraft:redstone_wire replace
fill ~243 ~27 ~288 ~243 ~27 ~300 minecraft:redstone_wire replace
fill ~267 ~27 ~288 ~267 ~27 ~300 minecraft:redstone_wire replace
fill ~294 ~27 ~288 ~294 ~27 ~300 minecraft:redstone_wire replace
fill ~297 ~27 ~288 ~297 ~27 ~300 minecraft:redstone_wire replace
fill ~315 ~27 ~288 ~315 ~27 ~300 minecraft:redstone_wire replace
setblock ~318 ~27 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~27 ~288 ~321 ~27 ~300 minecraft:redstone_wire replace
fill ~324 ~27 ~288 ~324 ~27 ~300 minecraft:redstone_wire replace
fill ~342 ~27 ~288 ~342 ~27 ~300 minecraft:redstone_wire replace
setblock ~345 ~27 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~290 ~81 ~27 ~302 minecraft:redstone_wire replace
setblock ~117 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~290 ~318 ~27 ~302 minecraft:redstone_wire replace
setblock ~339 ~27 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~290 ~345 ~27 ~302 minecraft:redstone_wire replace
