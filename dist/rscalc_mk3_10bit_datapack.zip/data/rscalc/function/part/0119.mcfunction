setblock ~548 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~455 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~456 ~185 ~2 ~466 ~185 ~2 minecraft:redstone_wire replace
setblock ~467 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~468 ~185 ~2 ~478 ~185 ~2 minecraft:redstone_wire replace
setblock ~479 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~185 ~2 ~490 ~185 ~2 minecraft:redstone_wire replace
setblock ~491 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~185 ~2 ~502 ~185 ~2 minecraft:redstone_wire replace
setblock ~503 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~185 ~2 ~514 ~185 ~2 minecraft:redstone_wire replace
setblock ~515 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~185 ~2 ~526 ~185 ~2 minecraft:redstone_wire replace
setblock ~527 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~185 ~2 ~531 ~185 ~2 minecraft:redstone_wire replace
setblock ~465 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~466 ~185 ~4 ~476 ~185 ~4 minecraft:redstone_wire replace
setblock ~477 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~185 ~4 ~488 ~185 ~4 minecraft:redstone_wire replace
setblock ~489 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~185 ~4 ~500 ~185 ~4 minecraft:redstone_wire replace
setblock ~501 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~185 ~4 ~512 ~185 ~4 minecraft:redstone_wire replace
setblock ~513 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~185 ~4 ~524 ~185 ~4 minecraft:redstone_wire replace
setblock ~525 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~185 ~4 ~529 ~185 ~4 minecraft:redstone_wire replace
setblock ~457 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~185 ~6 ~468 ~185 ~6 minecraft:redstone_wire replace
setblock ~469 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~185 ~6 ~480 ~185 ~6 minecraft:redstone_wire replace
setblock ~481 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~185 ~6 ~492 ~185 ~6 minecraft:redstone_wire replace
setblock ~493 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~185 ~6 ~504 ~185 ~6 minecraft:redstone_wire replace
setblock ~505 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~185 ~6 ~516 ~185 ~6 minecraft:redstone_wire replace
setblock ~517 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~185 ~6 ~528 ~185 ~6 minecraft:redstone_wire replace
setblock ~529 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~185 ~6 ~533 ~185 ~6 minecraft:redstone_wire replace
setblock ~467 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~468 ~185 ~8 ~478 ~185 ~8 minecraft:redstone_wire replace
setblock ~479 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~185 ~8 ~490 ~185 ~8 minecraft:redstone_wire replace
setblock ~491 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~185 ~8 ~502 ~185 ~8 minecraft:redstone_wire replace
setblock ~503 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~185 ~8 ~514 ~185 ~8 minecraft:redstone_wire replace
setblock ~515 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~185 ~8 ~526 ~185 ~8 minecraft:redstone_wire replace
setblock ~527 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~185 ~8 ~531 ~185 ~8 minecraft:redstone_wire replace
setblock ~463 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~185 ~10 ~474 ~185 ~10 minecraft:redstone_wire replace
setblock ~475 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~185 ~10 ~486 ~185 ~10 minecraft:redstone_wire replace
setblock ~487 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~185 ~10 ~498 ~185 ~10 minecraft:redstone_wire replace
setblock ~499 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~185 ~10 ~510 ~185 ~10 minecraft:redstone_wire replace
setblock ~511 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~185 ~10 ~522 ~185 ~10 minecraft:redstone_wire replace
setblock ~523 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~185 ~10 ~529 ~185 ~10 minecraft:redstone_wire replace
setblock ~459 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~460 ~185 ~12 ~470 ~185 ~12 minecraft:redstone_wire replace
setblock ~471 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~472 ~185 ~12 ~482 ~185 ~12 minecraft:redstone_wire replace
setblock ~483 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~185 ~12 ~494 ~185 ~12 minecraft:redstone_wire replace
setblock ~495 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~185 ~12 ~506 ~185 ~12 minecraft:redstone_wire replace
setblock ~507 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~185 ~12 ~518 ~185 ~12 minecraft:redstone_wire replace
setblock ~519 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~185 ~12 ~530 ~185 ~12 minecraft:redstone_wire replace
setblock ~531 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~185 ~12 ~533 ~185 ~12 minecraft:redstone_wire replace
setblock ~461 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~462 ~185 ~14 ~472 ~185 ~14 minecraft:redstone_wire replace
setblock ~473 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~474 ~185 ~14 ~484 ~185 ~14 minecraft:redstone_wire replace
setblock ~485 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~185 ~14 ~496 ~185 ~14 minecraft:redstone_wire replace
setblock ~497 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~185 ~14 ~508 ~185 ~14 minecraft:redstone_wire replace
setblock ~509 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~185 ~14 ~520 ~185 ~14 minecraft:redstone_wire replace
setblock ~521 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~185 ~14 ~531 ~185 ~14 minecraft:redstone_wire replace
setblock ~440 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~441 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~442 ~189 ~2 ~452 ~189 ~2 minecraft:redstone_wire replace
setblock ~453 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~454 ~189 ~2 ~464 ~189 ~2 minecraft:redstone_wire replace
setblock ~465 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~466 ~189 ~2 ~476 ~189 ~2 minecraft:redstone_wire replace
setblock ~477 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~189 ~2 ~488 ~189 ~2 minecraft:redstone_wire replace
setblock ~489 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~189 ~2 ~500 ~189 ~2 minecraft:redstone_wire replace
setblock ~501 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~189 ~2 ~512 ~189 ~2 minecraft:redstone_wire replace
setblock ~513 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~189 ~2 ~523 ~189 ~2 minecraft:redstone_wire replace
setblock ~451 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~189 ~4 ~462 ~189 ~4 minecraft:redstone_wire replace
setblock ~463 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~189 ~4 ~474 ~189 ~4 minecraft:redstone_wire replace
setblock ~475 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~189 ~4 ~486 ~189 ~4 minecraft:redstone_wire replace
setblock ~487 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~189 ~4 ~498 ~189 ~4 minecraft:redstone_wire replace
setblock ~499 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~189 ~4 ~510 ~189 ~4 minecraft:redstone_wire replace
setblock ~511 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~189 ~4 ~521 ~189 ~4 minecraft:redstone_wire replace
setblock ~443 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~444 ~189 ~6 ~454 ~189 ~6 minecraft:redstone_wire replace
setblock ~455 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~456 ~189 ~6 ~466 ~189 ~6 minecraft:redstone_wire replace
setblock ~467 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~468 ~189 ~6 ~478 ~189 ~6 minecraft:redstone_wire replace
setblock ~479 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~189 ~6 ~490 ~189 ~6 minecraft:redstone_wire replace
setblock ~491 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~189 ~6 ~502 ~189 ~6 minecraft:redstone_wire replace
setblock ~503 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~189 ~6 ~514 ~189 ~6 minecraft:redstone_wire replace
setblock ~515 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~189 ~6 ~525 ~189 ~6 minecraft:redstone_wire replace
setblock ~453 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~454 ~189 ~8 ~464 ~189 ~8 minecraft:redstone_wire replace
setblock ~465 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~466 ~189 ~8 ~476 ~189 ~8 minecraft:redstone_wire replace
setblock ~477 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~189 ~8 ~488 ~189 ~8 minecraft:redstone_wire replace
setblock ~489 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~189 ~8 ~500 ~189 ~8 minecraft:redstone_wire replace
setblock ~501 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~189 ~8 ~512 ~189 ~8 minecraft:redstone_wire replace
setblock ~513 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~189 ~8 ~523 ~189 ~8 minecraft:redstone_wire replace
setblock ~449 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~450 ~189 ~10 ~460 ~189 ~10 minecraft:redstone_wire replace
setblock ~461 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~462 ~189 ~10 ~472 ~189 ~10 minecraft:redstone_wire replace
setblock ~473 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~474 ~189 ~10 ~484 ~189 ~10 minecraft:redstone_wire replace
setblock ~485 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~189 ~10 ~496 ~189 ~10 minecraft:redstone_wire replace
setblock ~497 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~189 ~10 ~508 ~189 ~10 minecraft:redstone_wire replace
setblock ~509 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~189 ~10 ~520 ~189 ~10 minecraft:redstone_wire replace
setblock ~521 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~445 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~189 ~12 ~456 ~189 ~12 minecraft:redstone_wire replace
setblock ~457 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~189 ~12 ~468 ~189 ~12 minecraft:redstone_wire replace
setblock ~469 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~189 ~12 ~480 ~189 ~12 minecraft:redstone_wire replace
setblock ~481 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~189 ~12 ~492 ~189 ~12 minecraft:redstone_wire replace
setblock ~493 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~189 ~12 ~504 ~189 ~12 minecraft:redstone_wire replace
setblock ~505 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~189 ~12 ~516 ~189 ~12 minecraft:redstone_wire replace
setblock ~517 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~189 ~12 ~525 ~189 ~12 minecraft:redstone_wire replace
setblock ~447 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~448 ~189 ~14 ~458 ~189 ~14 minecraft:redstone_wire replace
setblock ~459 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~460 ~189 ~14 ~470 ~189 ~14 minecraft:redstone_wire replace
setblock ~471 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~472 ~189 ~14 ~482 ~189 ~14 minecraft:redstone_wire replace
setblock ~483 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~189 ~14 ~494 ~189 ~14 minecraft:redstone_wire replace
setblock ~495 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~189 ~14 ~506 ~189 ~14 minecraft:redstone_wire replace
setblock ~507 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~189 ~14 ~518 ~189 ~14 minecraft:redstone_wire replace
setblock ~519 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~189 ~14 ~523 ~189 ~14 minecraft:redstone_wire replace
setblock ~524 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~192 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~192 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~192 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~192 ~14 minecraft:redstone_torch[lit=true] replace
fill ~523 ~194 ~2 ~525 ~194 ~2 minecraft:redstone_wire replace
fill ~531 ~194 ~2 ~533 ~194 ~2 minecraft:redstone_wire replace
fill ~539 ~194 ~2 ~541 ~194 ~2 minecraft:redstone_wire replace
fill ~547 ~194 ~2 ~549 ~194 ~2 minecraft:redstone_wire replace
fill ~522 ~194 ~3 ~522 ~194 ~7 minecraft:redstone_wire replace
fill ~526 ~194 ~3 ~526 ~194 ~7 minecraft:redstone_wire replace
fill ~530 ~194 ~3 ~530 ~194 ~7 minecraft:redstone_wire replace
fill ~534 ~194 ~3 ~534 ~194 ~7 minecraft:redstone_wire replace
fill ~538 ~194 ~3 ~538 ~194 ~7 minecraft:redstone_wire replace
fill ~542 ~194 ~3 ~542 ~194 ~7 minecraft:redstone_wire replace
fill ~546 ~194 ~3 ~546 ~194 ~7 minecraft:redstone_wire replace
fill ~550 ~194 ~3 ~550 ~194 ~7 minecraft:redstone_wire replace
fill ~523 ~194 ~8 ~525 ~194 ~8 minecraft:redstone_wire replace
fill ~531 ~194 ~8 ~533 ~194 ~8 minecraft:redstone_wire replace
fill ~539 ~194 ~8 ~541 ~194 ~8 minecraft:redstone_wire replace
fill ~547 ~194 ~8 ~549 ~194 ~8 minecraft:redstone_wire replace
fill ~522 ~194 ~9 ~522 ~194 ~13 minecraft:redstone_wire replace
fill ~526 ~194 ~9 ~526 ~194 ~13 minecraft:redstone_wire replace
fill ~530 ~194 ~9 ~530 ~194 ~13 minecraft:redstone_wire replace
fill ~534 ~194 ~9 ~534 ~194 ~13 minecraft:redstone_wire replace
fill ~538 ~194 ~9 ~538 ~194 ~13 minecraft:redstone_wire replace
fill ~542 ~194 ~9 ~542 ~194 ~13 minecraft:redstone_wire replace
fill ~546 ~194 ~9 ~546 ~194 ~13 minecraft:redstone_wire replace
fill ~550 ~194 ~9 ~550 ~194 ~13 minecraft:redstone_wire replace
fill ~523 ~194 ~14 ~525 ~194 ~14 minecraft:redstone_wire replace
fill ~531 ~194 ~14 ~533 ~194 ~14 minecraft:redstone_wire replace
fill ~539 ~194 ~14 ~541 ~194 ~14 minecraft:redstone_wire replace
fill ~547 ~194 ~14 ~549 ~194 ~14 minecraft:redstone_wire replace
