fill ~307 ~40 ~360 ~307 ~40 ~361 minecraft:light_gray_concrete replace
fill ~306 ~40 ~362 ~336 ~40 ~362 minecraft:light_gray_concrete replace
fill ~310 ~40 ~364 ~310 ~40 ~365 minecraft:light_gray_concrete replace
fill ~309 ~40 ~366 ~339 ~40 ~366 minecraft:light_gray_concrete replace
fill ~283 ~40 ~368 ~283 ~40 ~369 minecraft:light_gray_concrete replace
fill ~282 ~40 ~370 ~312 ~40 ~370 minecraft:light_gray_concrete replace
fill ~298 ~40 ~372 ~298 ~40 ~373 minecraft:light_gray_concrete replace
fill ~297 ~40 ~374 ~327 ~40 ~374 minecraft:light_gray_concrete replace
fill ~256 ~40 ~380 ~256 ~40 ~381 minecraft:light_gray_concrete replace
fill ~255 ~40 ~382 ~285 ~40 ~382 minecraft:light_gray_concrete replace
fill ~334 ~40 ~384 ~334 ~40 ~385 minecraft:light_gray_concrete replace
fill ~333 ~40 ~386 ~363 ~40 ~386 minecraft:light_gray_concrete replace
fill ~355 ~40 ~388 ~355 ~40 ~389 minecraft:light_gray_concrete replace
fill ~354 ~40 ~390 ~384 ~40 ~390 minecraft:light_gray_concrete replace
fill ~322 ~40 ~392 ~322 ~40 ~393 minecraft:light_gray_concrete replace
fill ~321 ~40 ~394 ~351 ~40 ~394 minecraft:light_gray_concrete replace
fill ~346 ~40 ~396 ~346 ~40 ~397 minecraft:light_gray_concrete replace
fill ~345 ~40 ~398 ~375 ~40 ~398 minecraft:light_gray_concrete replace
fill ~316 ~40 ~400 ~316 ~40 ~401 minecraft:light_gray_concrete replace
fill ~315 ~40 ~402 ~345 ~40 ~402 minecraft:light_gray_concrete replace
fill ~91 ~40 ~408 ~91 ~40 ~409 minecraft:light_gray_concrete replace
fill ~90 ~40 ~410 ~92 ~40 ~410 minecraft:light_gray_concrete replace
fill ~118 ~40 ~412 ~118 ~40 ~413 minecraft:light_gray_concrete replace
fill ~117 ~40 ~414 ~119 ~40 ~414 minecraft:light_gray_concrete replace
fill ~142 ~40 ~416 ~142 ~40 ~417 minecraft:light_gray_concrete replace
fill ~141 ~40 ~418 ~144 ~40 ~418 minecraft:light_gray_concrete replace
fill ~175 ~40 ~420 ~175 ~40 ~421 minecraft:light_gray_concrete replace
fill ~174 ~40 ~422 ~192 ~40 ~422 minecraft:light_gray_concrete replace
fill ~196 ~40 ~424 ~196 ~40 ~425 minecraft:light_gray_concrete replace
fill ~195 ~40 ~426 ~213 ~40 ~426 minecraft:light_gray_concrete replace
fill ~220 ~40 ~428 ~220 ~40 ~429 minecraft:light_gray_concrete replace
fill ~219 ~40 ~430 ~237 ~40 ~430 minecraft:light_gray_concrete replace
fill ~253 ~40 ~432 ~253 ~40 ~433 minecraft:light_gray_concrete replace
fill ~252 ~40 ~434 ~282 ~40 ~434 minecraft:light_gray_concrete replace
fill ~277 ~40 ~436 ~277 ~40 ~437 minecraft:light_gray_concrete replace
fill ~276 ~40 ~438 ~306 ~40 ~438 minecraft:light_gray_concrete replace
fill ~313 ~40 ~440 ~313 ~40 ~441 minecraft:light_gray_concrete replace
fill ~312 ~40 ~442 ~342 ~40 ~442 minecraft:light_gray_concrete replace
fill ~88 ~40 ~444 ~88 ~40 ~445 minecraft:light_gray_concrete replace
fill ~87 ~40 ~446 ~89 ~40 ~446 minecraft:light_gray_concrete replace
fill ~115 ~40 ~448 ~115 ~40 ~449 minecraft:light_gray_concrete replace
fill ~114 ~40 ~450 ~116 ~40 ~450 minecraft:light_gray_concrete replace
fill ~139 ~40 ~452 ~139 ~40 ~453 minecraft:light_gray_concrete replace
fill ~138 ~40 ~454 ~141 ~40 ~454 minecraft:light_gray_concrete replace
fill ~172 ~40 ~456 ~172 ~40 ~457 minecraft:light_gray_concrete replace
fill ~171 ~40 ~458 ~189 ~40 ~458 minecraft:light_gray_concrete replace
fill ~193 ~40 ~460 ~193 ~40 ~461 minecraft:light_gray_concrete replace
fill ~192 ~40 ~462 ~210 ~40 ~462 minecraft:light_gray_concrete replace
fill ~217 ~40 ~464 ~217 ~40 ~465 minecraft:light_gray_concrete replace
fill ~216 ~40 ~466 ~234 ~40 ~466 minecraft:light_gray_concrete replace
fill ~247 ~40 ~468 ~247 ~40 ~469 minecraft:light_gray_concrete replace
fill ~246 ~40 ~470 ~276 ~40 ~470 minecraft:light_gray_concrete replace
fill ~274 ~40 ~472 ~274 ~40 ~473 minecraft:light_gray_concrete replace
fill ~273 ~40 ~474 ~303 ~40 ~474 minecraft:light_gray_concrete replace
fill ~337 ~40 ~476 ~337 ~40 ~477 minecraft:light_gray_concrete replace
fill ~336 ~40 ~478 ~366 ~40 ~478 minecraft:light_gray_concrete replace
fill ~361 ~40 ~480 ~361 ~40 ~481 minecraft:light_gray_concrete replace
fill ~360 ~40 ~482 ~390 ~40 ~482 minecraft:light_gray_concrete replace
fill ~85 ~40 ~484 ~85 ~40 ~485 minecraft:light_gray_concrete replace
fill ~84 ~40 ~486 ~86 ~40 ~486 minecraft:light_gray_concrete replace
fill ~112 ~40 ~488 ~112 ~40 ~489 minecraft:light_gray_concrete replace
fill ~111 ~40 ~490 ~113 ~40 ~490 minecraft:light_gray_concrete replace
fill ~136 ~40 ~492 ~136 ~40 ~493 minecraft:light_gray_concrete replace
fill ~135 ~40 ~494 ~138 ~40 ~494 minecraft:light_gray_concrete replace
fill ~163 ~40 ~496 ~163 ~40 ~497 minecraft:light_gray_concrete replace
fill ~162 ~40 ~498 ~171 ~40 ~498 minecraft:light_gray_concrete replace
fill ~190 ~40 ~500 ~190 ~40 ~501 minecraft:light_gray_concrete replace
fill ~189 ~40 ~502 ~207 ~40 ~502 minecraft:light_gray_concrete replace
fill ~214 ~40 ~504 ~214 ~40 ~505 minecraft:light_gray_concrete replace
fill ~213 ~40 ~506 ~231 ~40 ~506 minecraft:light_gray_concrete replace
fill ~244 ~40 ~508 ~244 ~40 ~509 minecraft:light_gray_concrete replace
fill ~243 ~40 ~510 ~273 ~40 ~510 minecraft:light_gray_concrete replace
fill ~271 ~40 ~512 ~271 ~40 ~513 minecraft:light_gray_concrete replace
fill ~270 ~40 ~514 ~300 ~40 ~514 minecraft:light_gray_concrete replace
fill ~331 ~40 ~516 ~331 ~40 ~517 minecraft:light_gray_concrete replace
fill ~330 ~40 ~518 ~360 ~40 ~518 minecraft:light_gray_concrete replace
fill ~358 ~40 ~520 ~358 ~40 ~521 minecraft:light_gray_concrete replace
fill ~357 ~40 ~522 ~387 ~40 ~522 minecraft:light_gray_concrete replace
fill ~82 ~40 ~524 ~82 ~40 ~525 minecraft:light_gray_concrete replace
fill ~81 ~40 ~526 ~83 ~40 ~526 minecraft:light_gray_concrete replace
fill ~109 ~40 ~528 ~109 ~40 ~529 minecraft:light_gray_concrete replace
fill ~108 ~40 ~530 ~110 ~40 ~530 minecraft:light_gray_concrete replace
fill ~133 ~40 ~532 ~133 ~40 ~533 minecraft:light_gray_concrete replace
fill ~132 ~40 ~534 ~135 ~40 ~534 minecraft:light_gray_concrete replace
fill ~157 ~40 ~536 ~157 ~40 ~537 minecraft:light_gray_concrete replace
fill ~156 ~40 ~538 ~165 ~40 ~538 minecraft:light_gray_concrete replace
fill ~187 ~40 ~540 ~187 ~40 ~541 minecraft:light_gray_concrete replace
fill ~186 ~40 ~542 ~204 ~40 ~542 minecraft:light_gray_concrete replace
fill ~211 ~40 ~544 ~211 ~40 ~545 minecraft:light_gray_concrete replace
fill ~210 ~40 ~546 ~228 ~40 ~546 minecraft:light_gray_concrete replace
fill ~241 ~40 ~548 ~241 ~40 ~549 minecraft:light_gray_concrete replace
fill ~240 ~40 ~550 ~270 ~40 ~550 minecraft:light_gray_concrete replace
fill ~262 ~40 ~552 ~262 ~40 ~553 minecraft:light_gray_concrete replace
fill ~261 ~40 ~554 ~291 ~40 ~554 minecraft:light_gray_concrete replace
fill ~328 ~40 ~556 ~328 ~40 ~557 minecraft:light_gray_concrete replace
fill ~327 ~40 ~558 ~357 ~40 ~558 minecraft:light_gray_concrete replace
fill ~352 ~40 ~560 ~352 ~40 ~561 minecraft:light_gray_concrete replace
fill ~351 ~40 ~562 ~381 ~40 ~562 minecraft:light_gray_concrete replace
fill ~79 ~40 ~564 ~79 ~40 ~565 minecraft:light_gray_concrete replace
fill ~78 ~40 ~566 ~80 ~40 ~566 minecraft:light_gray_concrete replace
fill ~106 ~40 ~568 ~106 ~40 ~569 minecraft:light_gray_concrete replace
fill ~105 ~40 ~570 ~107 ~40 ~570 minecraft:light_gray_concrete replace
fill ~130 ~40 ~572 ~130 ~40 ~573 minecraft:light_gray_concrete replace
fill ~129 ~40 ~574 ~132 ~40 ~574 minecraft:light_gray_concrete replace
fill ~154 ~40 ~576 ~154 ~40 ~577 minecraft:light_gray_concrete replace
fill ~153 ~40 ~578 ~162 ~40 ~578 minecraft:light_gray_concrete replace
fill ~181 ~40 ~580 ~181 ~40 ~581 minecraft:light_gray_concrete replace
fill ~180 ~40 ~582 ~198 ~40 ~582 minecraft:light_gray_concrete replace
fill ~202 ~40 ~584 ~202 ~40 ~585 minecraft:light_gray_concrete replace
fill ~201 ~40 ~586 ~219 ~40 ~586 minecraft:light_gray_concrete replace
fill ~238 ~40 ~588 ~238 ~40 ~589 minecraft:light_gray_concrete replace
fill ~237 ~40 ~590 ~267 ~40 ~590 minecraft:light_gray_concrete replace
fill ~259 ~40 ~592 ~259 ~40 ~593 minecraft:light_gray_concrete replace
fill ~258 ~40 ~594 ~288 ~40 ~594 minecraft:light_gray_concrete replace
fill ~325 ~40 ~596 ~325 ~40 ~597 minecraft:light_gray_concrete replace
fill ~324 ~40 ~598 ~354 ~40 ~598 minecraft:light_gray_concrete replace
fill ~349 ~40 ~600 ~349 ~40 ~601 minecraft:light_gray_concrete replace
fill ~348 ~40 ~602 ~378 ~40 ~602 minecraft:light_gray_concrete replace
fill ~103 ~40 ~604 ~103 ~40 ~605 minecraft:light_gray_concrete replace
fill ~102 ~40 ~606 ~104 ~40 ~606 minecraft:light_gray_concrete replace
fill ~127 ~40 ~608 ~127 ~40 ~609 minecraft:light_gray_concrete replace
fill ~126 ~40 ~610 ~129 ~40 ~610 minecraft:light_gray_concrete replace
fill ~151 ~40 ~612 ~151 ~40 ~613 minecraft:light_gray_concrete replace
fill ~150 ~40 ~614 ~159 ~40 ~614 minecraft:light_gray_concrete replace
fill ~178 ~40 ~616 ~178 ~40 ~617 minecraft:light_gray_concrete replace
fill ~177 ~40 ~618 ~195 ~40 ~618 minecraft:light_gray_concrete replace
fill ~199 ~40 ~620 ~199 ~40 ~621 minecraft:light_gray_concrete replace
fill ~198 ~40 ~622 ~216 ~40 ~622 minecraft:light_gray_concrete replace
fill ~223 ~40 ~624 ~223 ~40 ~625 minecraft:light_gray_concrete replace
fill ~222 ~40 ~626 ~240 ~40 ~626 minecraft:light_gray_concrete replace
fill ~265 ~40 ~628 ~265 ~40 ~629 minecraft:light_gray_concrete replace
fill ~264 ~40 ~630 ~294 ~40 ~630 minecraft:light_gray_concrete replace
fill ~280 ~40 ~632 ~280 ~40 ~633 minecraft:light_gray_concrete replace
fill ~279 ~40 ~634 ~309 ~40 ~634 minecraft:light_gray_concrete replace
fill ~340 ~40 ~636 ~340 ~40 ~637 minecraft:light_gray_concrete replace
fill ~339 ~40 ~638 ~369 ~40 ~638 minecraft:light_gray_concrete replace
fill ~160 ~40 ~640 ~160 ~40 ~641 minecraft:light_gray_concrete replace
fill ~159 ~40 ~642 ~168 ~40 ~642 minecraft:light_gray_concrete replace
fill ~367 ~40 ~644 ~367 ~40 ~645 minecraft:light_gray_concrete replace
fill ~366 ~40 ~646 ~396 ~40 ~646 minecraft:light_gray_concrete replace
fill ~100 ~40 ~648 ~100 ~40 ~649 minecraft:light_gray_concrete replace
fill ~99 ~40 ~650 ~101 ~40 ~650 minecraft:light_gray_concrete replace
fill ~343 ~40 ~652 ~343 ~40 ~653 minecraft:light_gray_concrete replace
fill ~342 ~40 ~654 ~372 ~40 ~654 minecraft:light_gray_concrete replace
fill ~364 ~40 ~656 ~364 ~40 ~657 minecraft:light_gray_concrete replace
fill ~363 ~40 ~658 ~393 ~40 ~658 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~0 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~2 minecraft:light_gray_concrete replace
setblock ~231 ~41 ~2 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~4 minecraft:light_gray_concrete replace
setblock ~145 ~41 ~8 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~12 minecraft:light_gray_concrete replace
setblock ~234 ~41 ~14 minecraft:light_gray_concrete replace
setblock ~236 ~41 ~14 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~16 minecraft:light_gray_concrete replace
setblock ~168 ~41 ~18 minecraft:light_gray_concrete replace
setblock ~170 ~41 ~18 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~24 minecraft:light_gray_concrete replace
setblock ~240 ~41 ~26 minecraft:light_gray_concrete replace
setblock ~242 ~41 ~26 minecraft:light_gray_concrete replace
setblock ~301 ~41 ~32 minecraft:light_gray_concrete replace
setblock ~315 ~41 ~34 minecraft:light_gray_concrete replace
setblock ~317 ~41 ~34 minecraft:light_gray_concrete replace
setblock ~286 ~41 ~36 minecraft:light_gray_concrete replace
setblock ~303 ~41 ~38 minecraft:light_gray_concrete replace
setblock ~305 ~41 ~38 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~40 minecraft:light_gray_concrete replace
setblock ~233 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~235 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~250 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~252 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~304 ~41 ~44 minecraft:light_gray_concrete replace
setblock ~318 ~41 ~46 minecraft:light_gray_concrete replace
setblock ~320 ~41 ~46 minecraft:light_gray_concrete replace
setblock ~289 ~41 ~48 minecraft:light_gray_concrete replace
setblock ~293 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~295 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~310 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~312 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~295 ~41 ~56 minecraft:light_gray_concrete replace
setblock ~309 ~41 ~58 minecraft:light_gray_concrete replace
setblock ~311 ~41 ~58 minecraft:light_gray_concrete replace
setblock ~319 ~41 ~72 minecraft:light_gray_concrete replace
setblock ~335 ~41 ~74 minecraft:light_gray_concrete replace
setblock ~337 ~41 ~74 minecraft:light_gray_concrete replace
setblock ~94 ~41 ~244 minecraft:light_gray_concrete replace
setblock ~124 ~41 ~248 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~252 minecraft:light_gray_concrete replace
setblock ~227 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~244 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~246 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~256 minecraft:light_gray_concrete replace
setblock ~171 ~41 ~258 minecraft:light_gray_concrete replace
setblock ~173 ~41 ~258 minecraft:light_gray_concrete replace
setblock ~145 ~41 ~260 minecraft:light_gray_concrete replace
setblock ~124 ~41 ~264 minecraft:light_gray_concrete replace
setblock ~97 ~41 ~272 minecraft:light_gray_concrete replace
setblock ~121 ~41 ~276 minecraft:light_gray_concrete replace
setblock ~145 ~41 ~280 minecraft:light_gray_concrete replace
setblock ~148 ~41 ~292 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~296 minecraft:light_gray_concrete replace
setblock ~171 ~41 ~298 minecraft:light_gray_concrete replace
setblock ~173 ~41 ~298 minecraft:light_gray_concrete replace
setblock ~169 ~41 ~308 minecraft:light_gray_concrete replace
setblock ~171 ~41 ~310 minecraft:light_gray_concrete replace
setblock ~173 ~41 ~310 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~316 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~231 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~246 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~248 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~184 ~41 ~320 minecraft:light_gray_concrete replace
setblock ~186 ~41 ~322 minecraft:light_gray_concrete replace
setblock ~188 ~41 ~322 minecraft:light_gray_concrete replace
setblock ~205 ~41 ~324 minecraft:light_gray_concrete replace
setblock ~213 ~41 ~326 minecraft:light_gray_concrete replace
setblock ~215 ~41 ~326 minecraft:light_gray_concrete replace
setblock ~250 ~41 ~328 minecraft:light_gray_concrete replace
setblock ~253 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~255 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~270 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~272 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~208 ~41 ~336 minecraft:light_gray_concrete replace
setblock ~210 ~41 ~338 minecraft:light_gray_concrete replace
setblock ~212 ~41 ~338 minecraft:light_gray_concrete replace
setblock ~232 ~41 ~340 minecraft:light_gray_concrete replace
setblock ~235 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~237 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~252 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~254 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~268 ~41 ~344 minecraft:light_gray_concrete replace
setblock ~271 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~273 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~288 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~290 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~235 ~41 ~352 minecraft:light_gray_concrete replace
setblock ~249 ~41 ~354 minecraft:light_gray_concrete replace
setblock ~251 ~41 ~354 minecraft:light_gray_concrete replace
setblock ~292 ~41 ~356 minecraft:light_gray_concrete replace
setblock ~295 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~297 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~312 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~314 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~307 ~41 ~360 minecraft:light_gray_concrete replace
setblock ~321 ~41 ~362 minecraft:light_gray_concrete replace
setblock ~323 ~41 ~362 minecraft:light_gray_concrete replace
setblock ~310 ~41 ~364 minecraft:light_gray_concrete replace
setblock ~326 ~41 ~366 minecraft:light_gray_concrete replace
setblock ~328 ~41 ~366 minecraft:light_gray_concrete replace
setblock ~283 ~41 ~368 minecraft:light_gray_concrete replace
setblock ~286 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~288 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~303 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~305 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~298 ~41 ~372 minecraft:light_gray_concrete replace
setblock ~301 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~303 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~318 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~320 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~256 ~41 ~380 minecraft:light_gray_concrete replace
setblock ~270 ~41 ~382 minecraft:light_gray_concrete replace
setblock ~272 ~41 ~382 minecraft:light_gray_concrete replace
setblock ~334 ~41 ~384 minecraft:light_gray_concrete replace
setblock ~337 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~339 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~354 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~356 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~355 ~41 ~388 minecraft:light_gray_concrete replace
setblock ~369 ~41 ~390 minecraft:light_gray_concrete replace
setblock ~371 ~41 ~390 minecraft:light_gray_concrete replace
setblock ~322 ~41 ~392 minecraft:light_gray_concrete replace
setblock ~336 ~41 ~394 minecraft:light_gray_concrete replace
setblock ~338 ~41 ~394 minecraft:light_gray_concrete replace
setblock ~346 ~41 ~396 minecraft:light_gray_concrete replace
setblock ~360 ~41 ~398 minecraft:light_gray_concrete replace
setblock ~362 ~41 ~398 minecraft:light_gray_concrete replace
setblock ~316 ~41 ~400 minecraft:light_gray_concrete replace
setblock ~319 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~321 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~336 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~338 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~91 ~41 ~408 minecraft:light_gray_concrete replace
setblock ~118 ~41 ~412 minecraft:light_gray_concrete replace
setblock ~142 ~41 ~416 minecraft:light_gray_concrete replace
setblock ~175 ~41 ~420 minecraft:light_gray_concrete replace
setblock ~183 ~41 ~422 minecraft:light_gray_concrete replace
setblock ~185 ~41 ~422 minecraft:light_gray_concrete replace
setblock ~196 ~41 ~424 minecraft:light_gray_concrete replace
setblock ~204 ~41 ~426 minecraft:light_gray_concrete replace
setblock ~206 ~41 ~426 minecraft:light_gray_concrete replace
setblock ~220 ~41 ~428 minecraft:light_gray_concrete replace
setblock ~228 ~41 ~430 minecraft:light_gray_concrete replace
setblock ~230 ~41 ~430 minecraft:light_gray_concrete replace
setblock ~253 ~41 ~432 minecraft:light_gray_concrete replace
setblock ~256 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~258 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~273 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~275 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~277 ~41 ~436 minecraft:light_gray_concrete replace
setblock ~280 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~282 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~297 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~299 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~313 ~41 ~440 minecraft:light_gray_concrete replace
setblock ~316 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~318 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~333 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~335 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~88 ~41 ~444 minecraft:light_gray_concrete replace
setblock ~115 ~41 ~448 minecraft:light_gray_concrete replace
setblock ~139 ~41 ~452 minecraft:light_gray_concrete replace
setblock ~172 ~41 ~456 minecraft:light_gray_concrete replace
setblock ~180 ~41 ~458 minecraft:light_gray_concrete replace
setblock ~182 ~41 ~458 minecraft:light_gray_concrete replace
setblock ~193 ~41 ~460 minecraft:light_gray_concrete replace
setblock ~201 ~41 ~462 minecraft:light_gray_concrete replace
setblock ~203 ~41 ~462 minecraft:light_gray_concrete replace
setblock ~217 ~41 ~464 minecraft:light_gray_concrete replace
setblock ~225 ~41 ~466 minecraft:light_gray_concrete replace
setblock ~227 ~41 ~466 minecraft:light_gray_concrete replace
setblock ~247 ~41 ~468 minecraft:light_gray_concrete replace
setblock ~250 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~252 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~267 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~269 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~274 ~41 ~472 minecraft:light_gray_concrete replace
setblock ~277 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~279 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~294 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~296 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~337 ~41 ~476 minecraft:light_gray_concrete replace
setblock ~340 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~342 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~357 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~359 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~361 ~41 ~480 minecraft:light_gray_concrete replace
setblock ~364 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~366 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~381 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~383 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~85 ~41 ~484 minecraft:light_gray_concrete replace
setblock ~112 ~41 ~488 minecraft:light_gray_concrete replace
setblock ~136 ~41 ~492 minecraft:light_gray_concrete replace
setblock ~163 ~41 ~496 minecraft:light_gray_concrete replace
setblock ~190 ~41 ~500 minecraft:light_gray_concrete replace
setblock ~198 ~41 ~502 minecraft:light_gray_concrete replace
setblock ~200 ~41 ~502 minecraft:light_gray_concrete replace
setblock ~214 ~41 ~504 minecraft:light_gray_concrete replace
setblock ~222 ~41 ~506 minecraft:light_gray_concrete replace
setblock ~224 ~41 ~506 minecraft:light_gray_concrete replace
setblock ~244 ~41 ~508 minecraft:light_gray_concrete replace
setblock ~247 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~249 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~264 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~266 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~271 ~41 ~512 minecraft:light_gray_concrete replace
setblock ~274 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~276 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~291 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~293 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~331 ~41 ~516 minecraft:light_gray_concrete replace
setblock ~334 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~336 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~351 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~353 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~358 ~41 ~520 minecraft:light_gray_concrete replace
setblock ~361 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~363 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~378 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~380 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~82 ~41 ~524 minecraft:light_gray_concrete replace
setblock ~109 ~41 ~528 minecraft:light_gray_concrete replace
setblock ~133 ~41 ~532 minecraft:light_gray_concrete replace
setblock ~157 ~41 ~536 minecraft:light_gray_concrete replace
setblock ~187 ~41 ~540 minecraft:light_gray_concrete replace
setblock ~195 ~41 ~542 minecraft:light_gray_concrete replace
setblock ~197 ~41 ~542 minecraft:light_gray_concrete replace
setblock ~211 ~41 ~544 minecraft:light_gray_concrete replace
setblock ~219 ~41 ~546 minecraft:light_gray_concrete replace
setblock ~221 ~41 ~546 minecraft:light_gray_concrete replace
setblock ~241 ~41 ~548 minecraft:light_gray_concrete replace
setblock ~244 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~246 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~261 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~263 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~262 ~41 ~552 minecraft:light_gray_concrete replace
setblock ~265 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~267 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~282 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~284 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~328 ~41 ~556 minecraft:light_gray_concrete replace
setblock ~331 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~333 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~348 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~350 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~352 ~41 ~560 minecraft:light_gray_concrete replace
setblock ~355 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~357 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~372 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~374 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~79 ~41 ~564 minecraft:light_gray_concrete replace
setblock ~106 ~41 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~41 ~572 minecraft:light_gray_concrete replace
setblock ~154 ~41 ~576 minecraft:light_gray_concrete replace
setblock ~181 ~41 ~580 minecraft:light_gray_concrete replace
setblock ~189 ~41 ~582 minecraft:light_gray_concrete replace
setblock ~191 ~41 ~582 minecraft:light_gray_concrete replace
setblock ~202 ~41 ~584 minecraft:light_gray_concrete replace
setblock ~210 ~41 ~586 minecraft:light_gray_concrete replace
setblock ~212 ~41 ~586 minecraft:light_gray_concrete replace
setblock ~238 ~41 ~588 minecraft:light_gray_concrete replace
setblock ~241 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~243 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~258 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~260 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~259 ~41 ~592 minecraft:light_gray_concrete replace
setblock ~262 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~264 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~279 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~281 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~325 ~41 ~596 minecraft:light_gray_concrete replace
setblock ~328 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~330 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~345 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~347 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~349 ~41 ~600 minecraft:light_gray_concrete replace
setblock ~352 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~354 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~369 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~371 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~103 ~41 ~604 minecraft:light_gray_concrete replace
setblock ~127 ~41 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~41 ~612 minecraft:light_gray_concrete replace
setblock ~178 ~41 ~616 minecraft:light_gray_concrete replace
setblock ~186 ~41 ~618 minecraft:light_gray_concrete replace
setblock ~188 ~41 ~618 minecraft:light_gray_concrete replace
setblock ~199 ~41 ~620 minecraft:light_gray_concrete replace
setblock ~207 ~41 ~622 minecraft:light_gray_concrete replace
setblock ~209 ~41 ~622 minecraft:light_gray_concrete replace
setblock ~223 ~41 ~624 minecraft:light_gray_concrete replace
setblock ~231 ~41 ~626 minecraft:light_gray_concrete replace
setblock ~233 ~41 ~626 minecraft:light_gray_concrete replace
setblock ~265 ~41 ~628 minecraft:light_gray_concrete replace
setblock ~268 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~270 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~285 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~287 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~280 ~41 ~632 minecraft:light_gray_concrete replace
setblock ~283 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~285 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~300 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~302 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~340 ~41 ~636 minecraft:light_gray_concrete replace
setblock ~343 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~345 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~360 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~362 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~160 ~41 ~640 minecraft:light_gray_concrete replace
setblock ~367 ~41 ~644 minecraft:light_gray_concrete replace
setblock ~370 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~372 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~387 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~389 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~100 ~41 ~648 minecraft:light_gray_concrete replace
setblock ~343 ~41 ~652 minecraft:light_gray_concrete replace
setblock ~346 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~348 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~363 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~365 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~364 ~41 ~656 minecraft:light_gray_concrete replace
setblock ~367 ~41 ~658 minecraft:light_gray_concrete replace
setblock ~369 ~41 ~658 minecraft:light_gray_concrete replace
setblock ~384 ~41 ~658 minecraft:light_gray_concrete replace
setblock ~386 ~41 ~658 minecraft:light_gray_concrete replace
fill ~225 ~42 ~0 ~225 ~42 ~320 minecraft:light_gray_concrete replace
fill ~165 ~42 ~4 ~165 ~42 ~300 minecraft:light_gray_concrete replace
fill ~144 ~42 ~8 ~144 ~42 ~284 minecraft:light_gray_concrete replace
fill ~300 ~42 ~32 ~300 ~42 ~36 minecraft:light_gray_concrete replace
fill ~285 ~42 ~36 ~285 ~42 ~40 minecraft:light_gray_concrete replace
fill ~228 ~42 ~40 ~228 ~42 ~44 minecraft:light_gray_concrete replace
fill ~303 ~42 ~44 ~303 ~42 ~48 minecraft:light_gray_concrete replace
fill ~288 ~42 ~48 ~288 ~42 ~52 minecraft:light_gray_concrete replace
fill ~294 ~42 ~56 ~294 ~42 ~60 minecraft:light_gray_concrete replace
fill ~318 ~42 ~72 ~318 ~42 ~76 minecraft:light_gray_concrete replace
fill ~93 ~42 ~244 ~93 ~42 ~248 minecraft:light_gray_concrete replace
fill ~123 ~42 ~248 ~123 ~42 ~268 minecraft:light_gray_concrete replace
fill ~96 ~42 ~272 ~96 ~42 ~276 minecraft:light_gray_concrete replace
fill ~120 ~42 ~276 ~120 ~42 ~280 minecraft:light_gray_concrete replace
fill ~147 ~42 ~292 ~147 ~42 ~296 minecraft:light_gray_concrete replace
fill ~168 ~42 ~308 ~168 ~42 ~312 minecraft:light_gray_concrete replace
fill ~183 ~42 ~320 ~183 ~42 ~324 minecraft:light_gray_concrete replace
fill ~204 ~42 ~324 ~204 ~42 ~328 minecraft:light_gray_concrete replace
fill ~249 ~42 ~328 ~249 ~42 ~332 minecraft:light_gray_concrete replace
fill ~207 ~42 ~336 ~207 ~42 ~340 minecraft:light_gray_concrete replace
fill ~231 ~42 ~340 ~231 ~42 ~344 minecraft:light_gray_concrete replace
fill ~267 ~42 ~344 ~267 ~42 ~348 minecraft:light_gray_concrete replace
fill ~234 ~42 ~352 ~234 ~42 ~356 minecraft:light_gray_concrete replace
fill ~291 ~42 ~356 ~291 ~42 ~360 minecraft:light_gray_concrete replace
fill ~306 ~42 ~360 ~306 ~42 ~364 minecraft:light_gray_concrete replace
fill ~309 ~42 ~364 ~309 ~42 ~368 minecraft:light_gray_concrete replace
fill ~282 ~42 ~368 ~282 ~42 ~372 minecraft:light_gray_concrete replace
fill ~297 ~42 ~372 ~297 ~42 ~376 minecraft:light_gray_concrete replace
fill ~255 ~42 ~380 ~255 ~42 ~384 minecraft:light_gray_concrete replace
fill ~333 ~42 ~384 ~333 ~42 ~388 minecraft:light_gray_concrete replace
fill ~354 ~42 ~388 ~354 ~42 ~392 minecraft:light_gray_concrete replace
fill ~321 ~42 ~392 ~321 ~42 ~396 minecraft:light_gray_concrete replace
fill ~345 ~42 ~396 ~345 ~42 ~400 minecraft:light_gray_concrete replace
fill ~315 ~42 ~400 ~315 ~42 ~404 minecraft:light_gray_concrete replace
fill ~90 ~42 ~408 ~90 ~42 ~412 minecraft:light_gray_concrete replace
fill ~117 ~42 ~412 ~117 ~42 ~416 minecraft:light_gray_concrete replace
fill ~141 ~42 ~416 ~141 ~42 ~420 minecraft:light_gray_concrete replace
fill ~174 ~42 ~420 ~174 ~42 ~424 minecraft:light_gray_concrete replace
fill ~195 ~42 ~424 ~195 ~42 ~428 minecraft:light_gray_concrete replace
fill ~219 ~42 ~428 ~219 ~42 ~432 minecraft:light_gray_concrete replace
fill ~252 ~42 ~432 ~252 ~42 ~436 minecraft:light_gray_concrete replace
fill ~276 ~42 ~436 ~276 ~42 ~440 minecraft:light_gray_concrete replace
fill ~312 ~42 ~440 ~312 ~42 ~444 minecraft:light_gray_concrete replace
fill ~87 ~42 ~444 ~87 ~42 ~448 minecraft:light_gray_concrete replace
fill ~114 ~42 ~448 ~114 ~42 ~452 minecraft:light_gray_concrete replace
fill ~138 ~42 ~452 ~138 ~42 ~456 minecraft:light_gray_concrete replace
fill ~171 ~42 ~456 ~171 ~42 ~460 minecraft:light_gray_concrete replace
fill ~192 ~42 ~460 ~192 ~42 ~464 minecraft:light_gray_concrete replace
fill ~216 ~42 ~464 ~216 ~42 ~468 minecraft:light_gray_concrete replace
fill ~246 ~42 ~468 ~246 ~42 ~472 minecraft:light_gray_concrete replace
fill ~273 ~42 ~472 ~273 ~42 ~476 minecraft:light_gray_concrete replace
fill ~336 ~42 ~476 ~336 ~42 ~480 minecraft:light_gray_concrete replace
fill ~360 ~42 ~480 ~360 ~42 ~484 minecraft:light_gray_concrete replace
fill ~84 ~42 ~484 ~84 ~42 ~488 minecraft:light_gray_concrete replace
fill ~111 ~42 ~488 ~111 ~42 ~492 minecraft:light_gray_concrete replace
fill ~135 ~42 ~492 ~135 ~42 ~496 minecraft:light_gray_concrete replace
fill ~162 ~42 ~496 ~162 ~42 ~500 minecraft:light_gray_concrete replace
fill ~189 ~42 ~500 ~189 ~42 ~504 minecraft:light_gray_concrete replace
fill ~213 ~42 ~504 ~213 ~42 ~508 minecraft:light_gray_concrete replace
fill ~243 ~42 ~508 ~243 ~42 ~512 minecraft:light_gray_concrete replace
fill ~270 ~42 ~512 ~270 ~42 ~516 minecraft:light_gray_concrete replace
fill ~330 ~42 ~516 ~330 ~42 ~520 minecraft:light_gray_concrete replace
fill ~357 ~42 ~520 ~357 ~42 ~524 minecraft:light_gray_concrete replace
fill ~81 ~42 ~524 ~81 ~42 ~528 minecraft:light_gray_concrete replace
fill ~108 ~42 ~528 ~108 ~42 ~532 minecraft:light_gray_concrete replace
fill ~132 ~42 ~532 ~132 ~42 ~536 minecraft:light_gray_concrete replace
fill ~156 ~42 ~536 ~156 ~42 ~540 minecraft:light_gray_concrete replace
fill ~186 ~42 ~540 ~186 ~42 ~544 minecraft:light_gray_concrete replace
fill ~210 ~42 ~544 ~210 ~42 ~548 minecraft:light_gray_concrete replace
fill ~240 ~42 ~548 ~240 ~42 ~552 minecraft:light_gray_concrete replace
fill ~261 ~42 ~552 ~261 ~42 ~556 minecraft:light_gray_concrete replace
fill ~327 ~42 ~556 ~327 ~42 ~560 minecraft:light_gray_concrete replace
fill ~351 ~42 ~560 ~351 ~42 ~564 minecraft:light_gray_concrete replace
fill ~78 ~42 ~564 ~78 ~42 ~568 minecraft:light_gray_concrete replace
fill ~105 ~42 ~568 ~105 ~42 ~572 minecraft:light_gray_concrete replace
fill ~129 ~42 ~572 ~129 ~42 ~576 minecraft:light_gray_concrete replace
fill ~153 ~42 ~576 ~153 ~42 ~580 minecraft:light_gray_concrete replace
fill ~180 ~42 ~580 ~180 ~42 ~584 minecraft:light_gray_concrete replace
fill ~201 ~42 ~584 ~201 ~42 ~588 minecraft:light_gray_concrete replace
fill ~237 ~42 ~588 ~237 ~42 ~592 minecraft:light_gray_concrete replace
fill ~258 ~42 ~592 ~258 ~42 ~596 minecraft:light_gray_concrete replace
fill ~324 ~42 ~596 ~324 ~42 ~600 minecraft:light_gray_concrete replace
fill ~348 ~42 ~600 ~348 ~42 ~604 minecraft:light_gray_concrete replace
fill ~102 ~42 ~604 ~102 ~42 ~608 minecraft:light_gray_concrete replace
fill ~126 ~42 ~608 ~126 ~42 ~612 minecraft:light_gray_concrete replace
fill ~150 ~42 ~612 ~150 ~42 ~616 minecraft:light_gray_concrete replace
fill ~177 ~42 ~616 ~177 ~42 ~620 minecraft:light_gray_concrete replace
fill ~198 ~42 ~620 ~198 ~42 ~624 minecraft:light_gray_concrete replace
fill ~222 ~42 ~624 ~222 ~42 ~628 minecraft:light_gray_concrete replace
fill ~264 ~42 ~628 ~264 ~42 ~632 minecraft:light_gray_concrete replace
fill ~279 ~42 ~632 ~279 ~42 ~636 minecraft:light_gray_concrete replace
fill ~339 ~42 ~636 ~339 ~42 ~640 minecraft:light_gray_concrete replace
fill ~159 ~42 ~640 ~159 ~42 ~644 minecraft:light_gray_concrete replace
fill ~366 ~42 ~644 ~366 ~42 ~648 minecraft:light_gray_concrete replace
fill ~99 ~42 ~648 ~99 ~42 ~652 minecraft:light_gray_concrete replace
fill ~342 ~42 ~652 ~342 ~42 ~656 minecraft:light_gray_concrete replace
fill ~363 ~42 ~656 ~363 ~42 ~660 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~0 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~4 minecraft:light_gray_concrete replace
setblock ~145 ~43 ~8 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~12 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~16 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~21 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~23 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~24 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~27 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~29 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~31 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~33 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~37 minecraft:light_gray_concrete replace
setblock ~300 ~43 ~37 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~39 minecraft:light_gray_concrete replace
setblock ~285 ~43 ~41 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~43 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~45 minecraft:light_gray_concrete replace
setblock ~228 ~43 ~45 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~47 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~49 minecraft:light_gray_concrete replace
setblock ~303 ~43 ~49 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~53 minecraft:light_gray_concrete replace
setblock ~288 ~43 ~53 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~55 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~59 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~61 minecraft:light_gray_concrete replace
setblock ~294 ~43 ~61 minecraft:light_gray_concrete replace
