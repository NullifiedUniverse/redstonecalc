fill ~96 ~27 ~424 ~96 ~27 ~436 minecraft:redstone_wire replace
fill ~102 ~27 ~424 ~102 ~27 ~436 minecraft:redstone_wire replace
setblock ~105 ~27 ~424 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~27 ~424 ~141 ~27 ~436 minecraft:redstone_wire replace
fill ~201 ~27 ~424 ~201 ~27 ~436 minecraft:redstone_wire replace
setblock ~270 ~27 ~424 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~424 ~291 ~27 ~436 minecraft:redstone_wire replace
fill ~330 ~27 ~424 ~330 ~27 ~436 minecraft:redstone_wire replace
fill ~336 ~27 ~424 ~336 ~27 ~436 minecraft:redstone_wire replace
fill ~348 ~27 ~424 ~348 ~27 ~436 minecraft:redstone_wire replace
fill ~357 ~27 ~424 ~357 ~27 ~436 minecraft:redstone_wire replace
setblock ~99 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~426 ~270 ~27 ~438 minecraft:redstone_wire replace
setblock ~354 ~27 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~428 ~99 ~27 ~440 minecraft:redstone_wire replace
fill ~120 ~27 ~428 ~120 ~27 ~440 minecraft:redstone_wire replace
setblock ~123 ~27 ~428 minecraft:redstone_wire replace
fill ~144 ~27 ~428 ~144 ~27 ~440 minecraft:redstone_wire replace
fill ~162 ~27 ~428 ~162 ~27 ~440 minecraft:redstone_wire replace
fill ~204 ~27 ~428 ~204 ~27 ~440 minecraft:redstone_wire replace
fill ~354 ~27 ~428 ~354 ~27 ~440 minecraft:redstone_wire replace
setblock ~114 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~432 ~114 ~27 ~444 minecraft:redstone_wire replace
fill ~150 ~27 ~432 ~150 ~27 ~444 minecraft:redstone_wire replace
setblock ~165 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~27 ~432 ~174 ~27 ~444 minecraft:redstone_wire replace
fill ~189 ~27 ~432 ~189 ~27 ~444 minecraft:redstone_wire replace
fill ~216 ~27 ~432 ~216 ~27 ~444 minecraft:redstone_wire replace
fill ~237 ~27 ~432 ~237 ~27 ~444 minecraft:redstone_wire replace
fill ~243 ~27 ~432 ~243 ~27 ~444 minecraft:redstone_wire replace
fill ~267 ~27 ~432 ~267 ~27 ~444 minecraft:redstone_wire replace
fill ~315 ~27 ~432 ~315 ~27 ~444 minecraft:redstone_wire replace
setblock ~318 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~432 ~342 ~27 ~444 minecraft:redstone_wire replace
setblock ~345 ~27 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~434 ~81 ~27 ~446 minecraft:redstone_wire replace
setblock ~117 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~434 ~318 ~27 ~446 minecraft:redstone_wire replace
setblock ~339 ~27 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~434 ~345 ~27 ~446 minecraft:redstone_wire replace
fill ~78 ~27 ~436 ~78 ~27 ~448 minecraft:redstone_wire replace
fill ~117 ~27 ~436 ~117 ~27 ~448 minecraft:redstone_wire replace
fill ~186 ~27 ~436 ~186 ~27 ~448 minecraft:redstone_wire replace
setblock ~192 ~27 ~436 minecraft:redstone_wire replace
fill ~219 ~27 ~436 ~219 ~27 ~440 minecraft:redstone_wire replace
fill ~240 ~27 ~436 ~240 ~27 ~448 minecraft:redstone_wire replace
fill ~246 ~27 ~436 ~246 ~27 ~442 minecraft:redstone_wire replace
fill ~264 ~27 ~436 ~264 ~27 ~448 minecraft:redstone_wire replace
fill ~273 ~27 ~436 ~273 ~27 ~446 minecraft:redstone_wire replace
fill ~339 ~27 ~436 ~339 ~27 ~448 minecraft:redstone_wire replace
setblock ~93 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~440 ~93 ~27 ~452 minecraft:redstone_wire replace
fill ~96 ~27 ~440 ~96 ~27 ~452 minecraft:redstone_wire replace
fill ~102 ~27 ~440 ~102 ~27 ~452 minecraft:redstone_wire replace
fill ~141 ~27 ~440 ~141 ~27 ~452 minecraft:redstone_wire replace
fill ~201 ~27 ~440 ~201 ~27 ~452 minecraft:redstone_wire replace
setblock ~270 ~27 ~440 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~440 ~291 ~27 ~452 minecraft:redstone_wire replace
fill ~330 ~27 ~440 ~330 ~27 ~450 minecraft:redstone_wire replace
fill ~336 ~27 ~440 ~336 ~27 ~452 minecraft:redstone_wire replace
fill ~348 ~27 ~440 ~348 ~27 ~452 minecraft:redstone_wire replace
fill ~357 ~27 ~440 ~357 ~27 ~452 minecraft:redstone_wire replace
setblock ~99 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~442 ~270 ~27 ~454 minecraft:redstone_wire replace
setblock ~354 ~27 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~444 ~99 ~27 ~456 minecraft:redstone_wire replace
fill ~120 ~27 ~444 ~120 ~27 ~456 minecraft:redstone_wire replace
fill ~144 ~27 ~444 ~144 ~27 ~456 minecraft:redstone_wire replace
fill ~162 ~27 ~444 ~162 ~27 ~456 minecraft:redstone_wire replace
fill ~204 ~27 ~444 ~204 ~27 ~456 minecraft:redstone_wire replace
setblock ~246 ~27 ~444 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~444 ~354 ~27 ~456 minecraft:redstone_wire replace
setblock ~114 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~448 ~114 ~27 ~460 minecraft:redstone_wire replace
fill ~150 ~27 ~448 ~150 ~27 ~460 minecraft:redstone_wire replace
fill ~174 ~27 ~448 ~174 ~27 ~460 minecraft:redstone_wire replace
fill ~189 ~27 ~448 ~189 ~27 ~460 minecraft:redstone_wire replace
fill ~216 ~27 ~448 ~216 ~27 ~460 minecraft:redstone_wire replace
fill ~237 ~27 ~448 ~237 ~27 ~460 minecraft:redstone_wire replace
fill ~243 ~27 ~448 ~243 ~27 ~460 minecraft:redstone_wire replace
fill ~267 ~27 ~448 ~267 ~27 ~460 minecraft:redstone_wire replace
setblock ~273 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~27 ~448 ~315 ~27 ~460 minecraft:redstone_wire replace
setblock ~318 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~448 ~342 ~27 ~460 minecraft:redstone_wire replace
setblock ~345 ~27 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~27 ~450 ~81 ~27 ~458 minecraft:redstone_wire replace
setblock ~117 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~450 ~318 ~27 ~462 minecraft:redstone_wire replace
setblock ~339 ~27 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~450 ~345 ~27 ~462 minecraft:redstone_wire replace
fill ~78 ~27 ~452 ~78 ~27 ~464 minecraft:redstone_wire replace
fill ~117 ~27 ~452 ~117 ~27 ~464 minecraft:redstone_wire replace
fill ~186 ~27 ~452 ~186 ~27 ~464 minecraft:redstone_wire replace
fill ~240 ~27 ~452 ~240 ~27 ~464 minecraft:redstone_wire replace
fill ~264 ~27 ~452 ~264 ~27 ~464 minecraft:redstone_wire replace
setblock ~330 ~27 ~452 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~452 ~339 ~27 ~464 minecraft:redstone_wire replace
setblock ~93 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~456 ~93 ~27 ~468 minecraft:redstone_wire replace
fill ~96 ~27 ~456 ~96 ~27 ~468 minecraft:redstone_wire replace
fill ~102 ~27 ~456 ~102 ~27 ~462 minecraft:redstone_wire replace
fill ~141 ~27 ~456 ~141 ~27 ~468 minecraft:redstone_wire replace
fill ~201 ~27 ~456 ~201 ~27 ~468 minecraft:redstone_wire replace
setblock ~270 ~27 ~456 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~456 ~291 ~27 ~468 minecraft:redstone_wire replace
fill ~336 ~27 ~456 ~336 ~27 ~468 minecraft:redstone_wire replace
setblock ~348 ~27 ~456 minecraft:redstone_wire replace
fill ~357 ~27 ~456 ~357 ~27 ~468 minecraft:redstone_wire replace
setblock ~99 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~458 ~270 ~27 ~470 minecraft:redstone_wire replace
setblock ~354 ~27 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~460 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~460 ~99 ~27 ~472 minecraft:redstone_wire replace
fill ~120 ~27 ~460 ~120 ~27 ~466 minecraft:redstone_wire replace
fill ~144 ~27 ~460 ~144 ~27 ~472 minecraft:redstone_wire replace
fill ~162 ~27 ~460 ~162 ~27 ~472 minecraft:redstone_wire replace
fill ~204 ~27 ~460 ~204 ~27 ~472 minecraft:redstone_wire replace
fill ~354 ~27 ~460 ~354 ~27 ~472 minecraft:redstone_wire replace
setblock ~114 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~464 ~114 ~27 ~476 minecraft:redstone_wire replace
fill ~150 ~27 ~464 ~150 ~27 ~470 minecraft:redstone_wire replace
fill ~174 ~27 ~464 ~174 ~27 ~476 minecraft:redstone_wire replace
fill ~189 ~27 ~464 ~189 ~27 ~474 minecraft:redstone_wire replace
fill ~216 ~27 ~464 ~216 ~27 ~476 minecraft:redstone_wire replace
fill ~237 ~27 ~464 ~237 ~27 ~476 minecraft:redstone_wire replace
fill ~243 ~27 ~464 ~243 ~27 ~476 minecraft:redstone_wire replace
fill ~267 ~27 ~464 ~267 ~27 ~476 minecraft:redstone_wire replace
fill ~315 ~27 ~464 ~315 ~27 ~476 minecraft:redstone_wire replace
setblock ~318 ~27 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~464 ~342 ~27 ~476 minecraft:redstone_wire replace
setblock ~345 ~27 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~466 ~318 ~27 ~478 minecraft:redstone_wire replace
setblock ~339 ~27 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~466 ~345 ~27 ~478 minecraft:redstone_wire replace
fill ~78 ~27 ~468 ~78 ~27 ~480 minecraft:redstone_wire replace
fill ~117 ~27 ~468 ~117 ~27 ~480 minecraft:redstone_wire replace
setblock ~120 ~27 ~468 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~27 ~468 ~186 ~27 ~480 minecraft:redstone_wire replace
fill ~240 ~27 ~468 ~240 ~27 ~480 minecraft:redstone_wire replace
fill ~264 ~27 ~468 ~264 ~27 ~480 minecraft:redstone_wire replace
fill ~339 ~27 ~468 ~339 ~27 ~480 minecraft:redstone_wire replace
setblock ~93 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~472 ~93 ~27 ~484 minecraft:redstone_wire replace
fill ~96 ~27 ~472 ~96 ~27 ~484 minecraft:redstone_wire replace
fill ~141 ~27 ~472 ~141 ~27 ~484 minecraft:redstone_wire replace
setblock ~150 ~27 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~27 ~472 ~201 ~27 ~484 minecraft:redstone_wire replace
setblock ~270 ~27 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~472 ~291 ~27 ~484 minecraft:redstone_wire replace
fill ~336 ~27 ~472 ~336 ~27 ~484 minecraft:redstone_wire replace
fill ~357 ~27 ~472 ~357 ~27 ~484 minecraft:redstone_wire replace
setblock ~99 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~474 ~270 ~27 ~486 minecraft:redstone_wire replace
setblock ~354 ~27 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~476 ~99 ~27 ~488 minecraft:redstone_wire replace
fill ~144 ~27 ~476 ~144 ~27 ~488 minecraft:redstone_wire replace
fill ~162 ~27 ~476 ~162 ~27 ~488 minecraft:redstone_wire replace
setblock ~189 ~27 ~476 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~27 ~476 ~204 ~27 ~488 minecraft:redstone_wire replace
fill ~354 ~27 ~476 ~354 ~27 ~488 minecraft:redstone_wire replace
setblock ~114 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~480 ~114 ~27 ~492 minecraft:redstone_wire replace
fill ~174 ~27 ~480 ~174 ~27 ~492 minecraft:redstone_wire replace
setblock ~216 ~27 ~480 minecraft:redstone_wire replace
fill ~237 ~27 ~480 ~237 ~27 ~492 minecraft:redstone_wire replace
fill ~243 ~27 ~480 ~243 ~27 ~484 minecraft:redstone_wire replace
fill ~267 ~27 ~480 ~267 ~27 ~486 minecraft:redstone_wire replace
fill ~315 ~27 ~480 ~315 ~27 ~492 minecraft:redstone_wire replace
setblock ~318 ~27 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~27 ~480 ~342 ~27 ~492 minecraft:redstone_wire replace
setblock ~345 ~27 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~27 ~482 ~318 ~27 ~490 minecraft:redstone_wire replace
setblock ~339 ~27 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~27 ~482 ~345 ~27 ~494 minecraft:redstone_wire replace
fill ~78 ~27 ~484 ~78 ~27 ~496 minecraft:redstone_wire replace
fill ~117 ~27 ~484 ~117 ~27 ~496 minecraft:redstone_wire replace
fill ~186 ~27 ~484 ~186 ~27 ~496 minecraft:redstone_wire replace
fill ~240 ~27 ~484 ~240 ~27 ~496 minecraft:redstone_wire replace
fill ~264 ~27 ~484 ~264 ~27 ~496 minecraft:redstone_wire replace
fill ~339 ~27 ~484 ~339 ~27 ~496 minecraft:redstone_wire replace
setblock ~93 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~488 ~93 ~27 ~500 minecraft:redstone_wire replace
fill ~96 ~27 ~488 ~96 ~27 ~500 minecraft:redstone_wire replace
fill ~141 ~27 ~488 ~141 ~27 ~500 minecraft:redstone_wire replace
fill ~201 ~27 ~488 ~201 ~27 ~500 minecraft:redstone_wire replace
setblock ~267 ~27 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~488 ~291 ~27 ~500 minecraft:redstone_wire replace
fill ~336 ~27 ~488 ~336 ~27 ~500 minecraft:redstone_wire replace
fill ~357 ~27 ~488 ~357 ~27 ~500 minecraft:redstone_wire replace
setblock ~99 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~490 ~270 ~27 ~502 minecraft:redstone_wire replace
setblock ~354 ~27 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~492 ~99 ~27 ~502 minecraft:redstone_wire replace
fill ~144 ~27 ~492 ~144 ~27 ~504 minecraft:redstone_wire replace
fill ~162 ~27 ~492 ~162 ~27 ~504 minecraft:redstone_wire replace
fill ~204 ~27 ~492 ~204 ~27 ~504 minecraft:redstone_wire replace
setblock ~318 ~27 ~492 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~492 ~354 ~27 ~504 minecraft:redstone_wire replace
setblock ~114 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~27 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~496 ~114 ~27 ~508 minecraft:redstone_wire replace
fill ~174 ~27 ~496 ~174 ~27 ~508 minecraft:redstone_wire replace
fill ~237 ~27 ~496 ~237 ~27 ~508 minecraft:redstone_wire replace
fill ~315 ~27 ~496 ~315 ~27 ~508 minecraft:redstone_wire replace
fill ~342 ~27 ~496 ~342 ~27 ~508 minecraft:redstone_wire replace
setblock ~345 ~27 ~496 minecraft:redstone_wire replace
setblock ~78 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~27 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~27 ~500 minecraft:redstone_wire replace
fill ~117 ~27 ~500 ~117 ~27 ~506 minecraft:redstone_wire replace
fill ~186 ~27 ~500 ~186 ~27 ~512 minecraft:redstone_wire replace
fill ~240 ~27 ~500 ~240 ~27 ~512 minecraft:redstone_wire replace
fill ~264 ~27 ~500 ~264 ~27 ~512 minecraft:redstone_wire replace
fill ~339 ~27 ~500 ~339 ~27 ~512 minecraft:redstone_wire replace
setblock ~93 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~504 ~93 ~27 ~516 minecraft:redstone_wire replace
fill ~96 ~27 ~504 ~96 ~27 ~516 minecraft:redstone_wire replace
setblock ~99 ~27 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~27 ~504 ~141 ~27 ~516 minecraft:redstone_wire replace
fill ~201 ~27 ~504 ~201 ~27 ~516 minecraft:redstone_wire replace
setblock ~270 ~27 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~504 ~291 ~27 ~516 minecraft:redstone_wire replace
fill ~336 ~27 ~504 ~336 ~27 ~516 minecraft:redstone_wire replace
fill ~357 ~27 ~504 ~357 ~27 ~516 minecraft:redstone_wire replace
setblock ~144 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~506 ~270 ~27 ~518 minecraft:redstone_wire replace
setblock ~354 ~27 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~508 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~27 ~508 ~144 ~27 ~512 minecraft:redstone_wire replace
fill ~162 ~27 ~508 ~162 ~27 ~520 minecraft:redstone_wire replace
fill ~204 ~27 ~508 ~204 ~27 ~518 minecraft:redstone_wire replace
fill ~354 ~27 ~508 ~354 ~27 ~520 minecraft:redstone_wire replace
setblock ~114 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~512 ~114 ~27 ~524 minecraft:redstone_wire replace
fill ~174 ~27 ~512 ~174 ~27 ~524 minecraft:redstone_wire replace
fill ~237 ~27 ~512 ~237 ~27 ~524 minecraft:redstone_wire replace
fill ~315 ~27 ~512 ~315 ~27 ~524 minecraft:redstone_wire replace
fill ~342 ~27 ~512 ~342 ~27 ~524 minecraft:redstone_wire replace
setblock ~186 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~27 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~516 minecraft:redstone_wire replace
fill ~240 ~27 ~516 ~240 ~27 ~522 minecraft:redstone_wire replace
fill ~264 ~27 ~516 ~264 ~27 ~526 minecraft:redstone_wire replace
fill ~339 ~27 ~516 ~339 ~27 ~528 minecraft:redstone_wire replace
setblock ~93 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~520 ~93 ~27 ~532 minecraft:redstone_wire replace
fill ~96 ~27 ~520 ~96 ~27 ~532 minecraft:redstone_wire replace
fill ~141 ~27 ~520 ~141 ~27 ~532 minecraft:redstone_wire replace
fill ~201 ~27 ~520 ~201 ~27 ~532 minecraft:redstone_wire replace
setblock ~204 ~27 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~520 ~291 ~27 ~532 minecraft:redstone_wire replace
fill ~336 ~27 ~520 ~336 ~27 ~532 minecraft:redstone_wire replace
fill ~357 ~27 ~520 ~357 ~27 ~532 minecraft:redstone_wire replace
setblock ~162 ~27 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~522 ~270 ~27 ~534 minecraft:redstone_wire replace
setblock ~354 ~27 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~524 ~162 ~27 ~536 minecraft:redstone_wire replace
setblock ~240 ~27 ~524 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~524 ~354 ~27 ~536 minecraft:redstone_wire replace
setblock ~114 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~27 ~528 ~114 ~27 ~540 minecraft:redstone_wire replace
fill ~174 ~27 ~528 ~174 ~27 ~540 minecraft:redstone_wire replace
fill ~237 ~27 ~528 ~237 ~27 ~540 minecraft:redstone_wire replace
setblock ~264 ~27 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~27 ~528 ~315 ~27 ~532 minecraft:redstone_wire replace
fill ~342 ~27 ~528 ~342 ~27 ~534 minecraft:redstone_wire replace
setblock ~339 ~27 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~532 ~339 ~27 ~544 minecraft:redstone_wire replace
setblock ~93 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~536 ~93 ~27 ~548 minecraft:redstone_wire replace
fill ~96 ~27 ~536 ~96 ~27 ~540 minecraft:redstone_wire replace
fill ~141 ~27 ~536 ~141 ~27 ~546 minecraft:redstone_wire replace
fill ~201 ~27 ~536 ~201 ~27 ~548 minecraft:redstone_wire replace
setblock ~270 ~27 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~536 ~291 ~27 ~548 minecraft:redstone_wire replace
fill ~336 ~27 ~536 ~336 ~27 ~548 minecraft:redstone_wire replace
setblock ~342 ~27 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~27 ~536 ~357 ~27 ~548 minecraft:redstone_wire replace
setblock ~162 ~27 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~538 ~270 ~27 ~550 minecraft:redstone_wire replace
setblock ~354 ~27 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~540 ~162 ~27 ~552 minecraft:redstone_wire replace
fill ~354 ~27 ~540 ~354 ~27 ~552 minecraft:redstone_wire replace
setblock ~114 ~27 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~544 minecraft:redstone_wire replace
fill ~174 ~27 ~544 ~174 ~27 ~550 minecraft:redstone_wire replace
fill ~237 ~27 ~544 ~237 ~27 ~556 minecraft:redstone_wire replace
setblock ~339 ~27 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~548 ~339 ~27 ~560 minecraft:redstone_wire replace
setblock ~93 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~552 ~93 ~27 ~564 minecraft:redstone_wire replace
setblock ~174 ~27 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~27 ~552 ~201 ~27 ~556 minecraft:redstone_wire replace
setblock ~270 ~27 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~27 ~552 ~291 ~27 ~564 minecraft:redstone_wire replace
fill ~336 ~27 ~552 ~336 ~27 ~564 minecraft:redstone_wire replace
fill ~357 ~27 ~552 ~357 ~27 ~564 minecraft:redstone_wire replace
setblock ~162 ~27 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~27 ~554 ~270 ~27 ~562 minecraft:redstone_wire replace
setblock ~354 ~27 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~556 ~162 ~27 ~568 minecraft:redstone_wire replace
fill ~354 ~27 ~556 ~354 ~27 ~568 minecraft:redstone_wire replace
setblock ~237 ~27 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~560 minecraft:redstone_wire replace
setblock ~339 ~27 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~564 ~339 ~27 ~576 minecraft:redstone_wire replace
setblock ~93 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~27 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~27 ~568 ~93 ~27 ~580 minecraft:redstone_wire replace
setblock ~291 ~27 ~568 minecraft:redstone_wire replace
fill ~336 ~27 ~568 ~336 ~27 ~572 minecraft:redstone_wire replace
fill ~357 ~27 ~568 ~357 ~27 ~578 minecraft:redstone_wire replace
setblock ~162 ~27 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~27 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~27 ~572 ~162 ~27 ~576 minecraft:redstone_wire replace
fill ~354 ~27 ~572 ~354 ~27 ~584 minecraft:redstone_wire replace
setblock ~339 ~27 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~27 ~580 ~339 ~27 ~586 minecraft:redstone_wire replace
setblock ~357 ~27 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~27 ~584 minecraft:redstone_wire replace
setblock ~354 ~27 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~27 ~588 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~27 ~588 ~354 ~27 ~592 minecraft:redstone_wire replace
setblock ~126 ~28 ~13 minecraft:redstone_wire replace
setblock ~153 ~28 ~21 minecraft:redstone_wire replace
setblock ~177 ~28 ~29 minecraft:redstone_wire replace
setblock ~207 ~28 ~37 minecraft:redstone_wire replace
setblock ~225 ~28 ~45 minecraft:redstone_wire replace
setblock ~249 ~28 ~53 minecraft:redstone_wire replace
setblock ~282 ~28 ~61 minecraft:redstone_wire replace
setblock ~300 ~28 ~65 minecraft:redstone_wire replace
setblock ~309 ~28 ~77 minecraft:redstone_wire replace
setblock ~327 ~28 ~81 minecraft:redstone_wire replace
setblock ~132 ~28 ~261 minecraft:redstone_wire replace
setblock ~135 ~28 ~265 minecraft:redstone_wire replace
setblock ~147 ~28 ~269 minecraft:redstone_wire replace
setblock ~156 ~28 ~273 minecraft:redstone_wire replace
setblock ~159 ~28 ~277 minecraft:redstone_wire replace
setblock ~180 ~28 ~281 minecraft:redstone_wire replace
setblock ~183 ~28 ~285 minecraft:redstone_wire replace
setblock ~210 ~28 ~289 minecraft:redstone_wire replace
setblock ~213 ~28 ~293 minecraft:redstone_wire replace
setblock ~228 ~28 ~297 minecraft:redstone_wire replace
setblock ~231 ~28 ~301 minecraft:redstone_wire replace
setblock ~252 ~28 ~305 minecraft:redstone_wire replace
setblock ~255 ~28 ~309 minecraft:redstone_wire replace
setblock ~285 ~28 ~313 minecraft:redstone_wire replace
setblock ~288 ~28 ~317 minecraft:redstone_wire replace
setblock ~294 ~28 ~321 minecraft:redstone_wire replace
setblock ~297 ~28 ~325 minecraft:redstone_wire replace
setblock ~303 ~28 ~329 minecraft:redstone_wire replace
setblock ~306 ~28 ~333 minecraft:redstone_wire replace
setblock ~321 ~28 ~337 minecraft:redstone_wire replace
setblock ~324 ~28 ~341 minecraft:redstone_wire replace
setblock ~90 ~28 ~345 minecraft:redstone_wire replace
setblock ~111 ~28 ~349 minecraft:redstone_wire replace
setblock ~138 ~28 ~353 minecraft:redstone_wire replace
setblock ~171 ~28 ~357 minecraft:redstone_wire replace
setblock ~198 ~28 ~361 minecraft:redstone_wire replace
setblock ~234 ~28 ~365 minecraft:redstone_wire replace
setblock ~261 ~28 ~369 minecraft:redstone_wire replace
setblock ~279 ~28 ~373 minecraft:redstone_wire replace
setblock ~312 ~28 ~377 minecraft:redstone_wire replace
setblock ~87 ~28 ~381 minecraft:redstone_wire replace
setblock ~108 ~28 ~385 minecraft:redstone_wire replace
setblock ~129 ~28 ~389 minecraft:redstone_wire replace
setblock ~168 ~28 ~393 minecraft:redstone_wire replace
setblock ~195 ~28 ~397 minecraft:redstone_wire replace
setblock ~222 ~28 ~401 minecraft:redstone_wire replace
setblock ~258 ~28 ~405 minecraft:redstone_wire replace
setblock ~276 ~28 ~409 minecraft:redstone_wire replace
setblock ~333 ~28 ~413 minecraft:redstone_wire replace
setblock ~351 ~28 ~417 minecraft:redstone_wire replace
setblock ~84 ~28 ~421 minecraft:redstone_wire replace
setblock ~105 ~28 ~425 minecraft:redstone_wire replace
setblock ~123 ~28 ~429 minecraft:redstone_wire replace
setblock ~165 ~28 ~433 minecraft:redstone_wire replace
setblock ~192 ~28 ~437 minecraft:redstone_wire replace
setblock ~219 ~28 ~441 minecraft:redstone_wire replace
setblock ~246 ~28 ~445 minecraft:redstone_wire replace
setblock ~273 ~28 ~449 minecraft:redstone_wire replace
setblock ~330 ~28 ~453 minecraft:redstone_wire replace
setblock ~348 ~28 ~457 minecraft:redstone_wire replace
setblock ~81 ~28 ~461 minecraft:redstone_wire replace
setblock ~102 ~28 ~465 minecraft:redstone_wire replace
setblock ~120 ~28 ~469 minecraft:redstone_wire replace
setblock ~150 ~28 ~473 minecraft:redstone_wire replace
setblock ~189 ~28 ~477 minecraft:redstone_wire replace
setblock ~216 ~28 ~481 minecraft:redstone_wire replace
setblock ~243 ~28 ~485 minecraft:redstone_wire replace
setblock ~267 ~28 ~489 minecraft:redstone_wire replace
setblock ~318 ~28 ~493 minecraft:redstone_wire replace
setblock ~345 ~28 ~497 minecraft:redstone_wire replace
setblock ~78 ~28 ~501 minecraft:redstone_wire replace
setblock ~99 ~28 ~505 minecraft:redstone_wire replace
setblock ~117 ~28 ~509 minecraft:redstone_wire replace
setblock ~144 ~28 ~513 minecraft:redstone_wire replace
setblock ~186 ~28 ~517 minecraft:redstone_wire replace
setblock ~204 ~28 ~521 minecraft:redstone_wire replace
setblock ~240 ~28 ~525 minecraft:redstone_wire replace
setblock ~264 ~28 ~529 minecraft:redstone_wire replace
setblock ~315 ~28 ~533 minecraft:redstone_wire replace
setblock ~342 ~28 ~537 minecraft:redstone_wire replace
setblock ~96 ~28 ~541 minecraft:redstone_wire replace
setblock ~114 ~28 ~545 minecraft:redstone_wire replace
setblock ~141 ~28 ~549 minecraft:redstone_wire replace
setblock ~174 ~28 ~553 minecraft:redstone_wire replace
setblock ~201 ~28 ~557 minecraft:redstone_wire replace
setblock ~237 ~28 ~561 minecraft:redstone_wire replace
setblock ~270 ~28 ~565 minecraft:redstone_wire replace
setblock ~291 ~28 ~569 minecraft:redstone_wire replace
setblock ~336 ~28 ~573 minecraft:redstone_wire replace
setblock ~162 ~28 ~577 minecraft:redstone_wire replace
setblock ~357 ~28 ~581 minecraft:redstone_wire replace
setblock ~93 ~28 ~585 minecraft:redstone_wire replace
setblock ~339 ~28 ~589 minecraft:redstone_wire replace
setblock ~354 ~28 ~593 minecraft:redstone_wire replace
fill ~126 ~29 ~14 ~128 ~29 ~14 minecraft:redstone_wire replace
setblock ~127 ~29 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~29 ~22 ~153 ~29 ~22 minecraft:redstone_wire replace
setblock ~151 ~29 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~29 ~30 ~177 ~29 ~30 minecraft:redstone_wire replace
setblock ~172 ~29 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~29 ~38 ~199 ~29 ~38 minecraft:redstone_wire replace
setblock ~200 ~29 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~29 ~38 ~207 ~29 ~38 minecraft:redstone_wire replace
setblock ~199 ~29 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~29 ~46 ~215 ~29 ~46 minecraft:redstone_wire replace
setblock ~217 ~29 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~29 ~46 ~225 ~29 ~46 minecraft:redstone_wire replace
setblock ~214 ~29 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~29 ~54 ~239 ~29 ~54 minecraft:redstone_wire replace
setblock ~241 ~29 ~54 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~29 ~54 ~249 ~29 ~54 minecraft:redstone_wire replace
setblock ~235 ~29 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~29 ~62 ~272 ~29 ~62 minecraft:redstone_wire replace
setblock ~274 ~29 ~62 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~29 ~62 ~282 ~29 ~62 minecraft:redstone_wire replace
setblock ~265 ~29 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~29 ~66 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~29 ~66 ~290 ~29 ~66 minecraft:redstone_wire replace
setblock ~292 ~29 ~66 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~29 ~66 ~300 ~29 ~66 minecraft:redstone_wire replace
setblock ~277 ~29 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~282 ~29 ~78 ~284 ~29 ~78 minecraft:redstone_wire replace
setblock ~285 ~29 ~78 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~29 ~78 ~299 ~29 ~78 minecraft:redstone_wire replace
setblock ~301 ~29 ~78 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~29 ~78 ~309 ~29 ~78 minecraft:redstone_wire replace
setblock ~283 ~29 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~29 ~82 ~300 ~29 ~82 minecraft:redstone_wire replace
setblock ~302 ~29 ~82 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~29 ~82 ~317 ~29 ~82 minecraft:redstone_wire replace
setblock ~319 ~29 ~82 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~29 ~82 ~327 ~29 ~82 minecraft:redstone_wire replace
setblock ~298 ~29 ~83 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~29 ~262 ~134 ~29 ~262 minecraft:redstone_wire replace
setblock ~133 ~29 ~263 minecraft:redstone_wire replace
fill ~132 ~29 ~266 ~135 ~29 ~266 minecraft:redstone_wire replace
setblock ~133 ~29 ~267 minecraft:redstone_wire replace
fill ~144 ~29 ~270 ~147 ~29 ~270 minecraft:redstone_wire replace
setblock ~145 ~29 ~271 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~29 ~274 ~156 ~29 ~274 minecraft:redstone_wire replace
setblock ~154 ~29 ~275 minecraft:redstone_wire replace
fill ~153 ~29 ~278 ~159 ~29 ~278 minecraft:redstone_wire replace
setblock ~154 ~29 ~279 minecraft:redstone_wire replace
fill ~174 ~29 ~282 ~180 ~29 ~282 minecraft:redstone_wire replace
setblock ~175 ~29 ~283 minecraft:redstone_wire replace
fill ~174 ~29 ~286 ~183 ~29 ~286 minecraft:redstone_wire replace
setblock ~175 ~29 ~287 minecraft:redstone_wire replace
fill ~201 ~29 ~290 ~202 ~29 ~290 minecraft:redstone_wire replace
setblock ~203 ~29 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~29 ~290 ~210 ~29 ~290 minecraft:redstone_wire replace
setblock ~202 ~29 ~291 minecraft:redstone_wire replace
fill ~201 ~29 ~294 ~213 ~29 ~294 minecraft:redstone_wire replace
setblock ~202 ~29 ~295 minecraft:redstone_wire replace
fill ~216 ~29 ~298 ~228 ~29 ~298 minecraft:redstone_wire replace
setblock ~217 ~29 ~299 minecraft:redstone_wire replace
fill ~216 ~29 ~302 ~218 ~29 ~302 minecraft:redstone_wire replace
setblock ~219 ~29 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~29 ~302 ~231 ~29 ~302 minecraft:redstone_wire replace
setblock ~217 ~29 ~303 minecraft:redstone_wire replace
fill ~237 ~29 ~306 ~241 ~29 ~306 minecraft:redstone_wire replace
setblock ~243 ~29 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~29 ~306 ~252 ~29 ~306 minecraft:redstone_wire replace
setblock ~238 ~29 ~307 minecraft:redstone_wire replace
fill ~237 ~29 ~310 ~239 ~29 ~310 minecraft:redstone_wire replace
setblock ~241 ~29 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~29 ~310 ~255 ~29 ~310 minecraft:redstone_wire replace
setblock ~238 ~29 ~311 minecraft:redstone_wire replace
fill ~267 ~29 ~314 ~269 ~29 ~314 minecraft:redstone_wire replace
setblock ~271 ~29 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~29 ~314 ~285 ~29 ~314 minecraft:redstone_wire replace
setblock ~268 ~29 ~315 minecraft:redstone_wire replace
fill ~267 ~29 ~318 ~273 ~29 ~318 minecraft:redstone_wire replace
setblock ~275 ~29 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~29 ~318 ~288 ~29 ~318 minecraft:redstone_wire replace
setblock ~268 ~29 ~319 minecraft:redstone_wire replace
fill ~273 ~29 ~322 ~279 ~29 ~322 minecraft:redstone_wire replace
setblock ~281 ~29 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~29 ~322 ~294 ~29 ~322 minecraft:redstone_wire replace
setblock ~274 ~29 ~323 minecraft:redstone_wire replace
fill ~273 ~29 ~326 ~286 ~29 ~326 minecraft:redstone_wire replace
setblock ~288 ~29 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~29 ~326 ~297 ~29 ~326 minecraft:redstone_wire replace
setblock ~274 ~29 ~327 minecraft:redstone_wire replace
fill ~279 ~29 ~330 ~287 ~29 ~330 minecraft:redstone_wire replace
setblock ~289 ~29 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~29 ~330 ~303 ~29 ~330 minecraft:redstone_wire replace
setblock ~280 ~29 ~331 minecraft:redstone_wire replace
fill ~279 ~29 ~334 ~291 ~29 ~334 minecraft:redstone_wire replace
setblock ~293 ~29 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~29 ~334 ~306 ~29 ~334 minecraft:redstone_wire replace
setblock ~280 ~29 ~335 minecraft:redstone_wire replace
fill ~294 ~29 ~338 ~306 ~29 ~338 minecraft:redstone_wire replace
setblock ~308 ~29 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~29 ~338 ~321 ~29 ~338 minecraft:redstone_wire replace
setblock ~295 ~29 ~339 minecraft:redstone_wire replace
fill ~294 ~29 ~342 ~296 ~29 ~342 minecraft:redstone_wire replace
setblock ~298 ~29 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~29 ~342 ~313 ~29 ~342 minecraft:redstone_wire replace
setblock ~315 ~29 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~29 ~342 ~324 ~29 ~342 minecraft:redstone_wire replace
setblock ~295 ~29 ~343 minecraft:redstone_wire replace
fill ~90 ~29 ~346 ~92 ~29 ~346 minecraft:redstone_wire replace
setblock ~91 ~29 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~29 ~350 ~113 ~29 ~350 minecraft:redstone_wire replace
setblock ~112 ~29 ~351 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~29 ~354 ~138 ~29 ~354 minecraft:redstone_wire replace
setblock ~136 ~29 ~355 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~29 ~358 ~171 ~29 ~358 minecraft:redstone_wire replace
setblock ~166 ~29 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~29 ~362 ~198 ~29 ~362 minecraft:redstone_wire replace
setblock ~190 ~29 ~363 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~29 ~366 ~225 ~29 ~366 minecraft:redstone_wire replace
setblock ~227 ~29 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~29 ~366 ~234 ~29 ~366 minecraft:redstone_wire replace
setblock ~220 ~29 ~367 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~243 ~29 ~370 ~250 ~29 ~370 minecraft:redstone_wire replace
setblock ~252 ~29 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~29 ~370 ~261 ~29 ~370 minecraft:redstone_wire replace
setblock ~244 ~29 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~29 ~374 ~263 ~29 ~374 minecraft:redstone_wire replace
setblock ~265 ~29 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~29 ~374 ~279 ~29 ~374 minecraft:redstone_wire replace
setblock ~262 ~29 ~375 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~29 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~29 ~378 ~299 ~29 ~378 minecraft:redstone_wire replace
setblock ~301 ~29 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~29 ~378 ~312 ~29 ~378 minecraft:redstone_wire replace
setblock ~286 ~29 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~29 ~382 ~89 ~29 ~382 minecraft:redstone_wire replace
setblock ~88 ~29 ~383 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~29 ~386 ~110 ~29 ~386 minecraft:redstone_wire replace
setblock ~109 ~29 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~29 ~390 ~131 ~29 ~390 minecraft:redstone_wire replace
setblock ~130 ~29 ~391 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~29 ~394 ~168 ~29 ~394 minecraft:redstone_wire replace
setblock ~163 ~29 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~29 ~398 ~187 ~29 ~398 minecraft:redstone_wire replace
setblock ~188 ~29 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~29 ~398 ~195 ~29 ~398 minecraft:redstone_wire replace
setblock ~187 ~29 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~29 ~402 ~222 ~29 ~402 minecraft:redstone_wire replace
setblock ~211 ~29 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~29 ~406 ~242 ~29 ~406 minecraft:redstone_wire replace
setblock ~244 ~29 ~406 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~29 ~406 ~258 ~29 ~406 minecraft:redstone_wire replace
setblock ~241 ~29 ~407 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~29 ~410 ~261 ~29 ~410 minecraft:redstone_wire replace
setblock ~263 ~29 ~410 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~29 ~410 ~276 ~29 ~410 minecraft:redstone_wire replace
setblock ~259 ~29 ~411 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~29 ~414 ~305 ~29 ~414 minecraft:redstone_wire replace
setblock ~306 ~29 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~29 ~414 ~320 ~29 ~414 minecraft:redstone_wire replace
setblock ~322 ~29 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~29 ~414 ~333 ~29 ~414 minecraft:redstone_wire replace
setblock ~304 ~29 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~321 ~29 ~418 ~325 ~29 ~418 minecraft:redstone_wire replace
setblock ~327 ~29 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~29 ~418 ~342 ~29 ~418 minecraft:redstone_wire replace
setblock ~344 ~29 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~29 ~418 ~351 ~29 ~418 minecraft:redstone_wire replace
setblock ~322 ~29 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~29 ~422 ~86 ~29 ~422 minecraft:redstone_wire replace
setblock ~85 ~29 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~29 ~426 ~107 ~29 ~426 minecraft:redstone_wire replace
setblock ~106 ~29 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~29 ~430 ~125 ~29 ~430 minecraft:redstone_wire replace
setblock ~124 ~29 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~29 ~434 ~165 ~29 ~434 minecraft:redstone_wire replace
setblock ~160 ~29 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~29 ~438 ~192 ~29 ~438 minecraft:redstone_wire replace
setblock ~184 ~29 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~29 ~442 ~208 ~29 ~442 minecraft:redstone_wire replace
setblock ~210 ~29 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~29 ~442 ~219 ~29 ~442 minecraft:redstone_wire replace
setblock ~208 ~29 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~29 ~446 ~232 ~29 ~446 minecraft:redstone_wire replace
setblock ~233 ~29 ~446 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~29 ~446 ~246 ~29 ~446 minecraft:redstone_wire replace
setblock ~232 ~29 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~29 ~450 ~257 ~29 ~450 minecraft:redstone_wire replace
setblock ~259 ~29 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~29 ~450 ~273 ~29 ~450 minecraft:redstone_wire replace
setblock ~256 ~29 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~29 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~29 ~454 ~314 ~29 ~454 minecraft:redstone_wire replace
setblock ~316 ~29 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~29 ~454 ~330 ~29 ~454 minecraft:redstone_wire replace
setblock ~301 ~29 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~29 ~458 ~320 ~29 ~458 minecraft:redstone_wire replace
setblock ~321 ~29 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~29 ~458 ~334 ~29 ~458 minecraft:redstone_wire replace
setblock ~336 ~29 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~338 ~29 ~458 ~348 ~29 ~458 minecraft:redstone_wire replace
setblock ~319 ~29 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~29 ~462 ~83 ~29 ~462 minecraft:redstone_wire replace
setblock ~82 ~29 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~29 ~466 ~104 ~29 ~466 minecraft:redstone_wire replace
setblock ~103 ~29 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~29 ~470 ~122 ~29 ~470 minecraft:redstone_wire replace
setblock ~121 ~29 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~29 ~474 ~150 ~29 ~474 minecraft:redstone_wire replace
setblock ~148 ~29 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~29 ~478 ~189 ~29 ~478 minecraft:redstone_wire replace
setblock ~181 ~29 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~29 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~29 ~482 ~216 ~29 ~482 minecraft:redstone_wire replace
setblock ~205 ~29 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~29 ~486 ~232 ~29 ~486 minecraft:redstone_wire replace
setblock ~234 ~29 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~29 ~486 ~243 ~29 ~486 minecraft:redstone_wire replace
setblock ~229 ~29 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~29 ~490 ~251 ~29 ~490 minecraft:redstone_wire replace
setblock ~253 ~29 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~29 ~490 ~267 ~29 ~490 minecraft:redstone_wire replace
setblock ~250 ~29 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~29 ~494 ~302 ~29 ~494 minecraft:redstone_wire replace
setblock ~304 ~29 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~29 ~494 ~318 ~29 ~494 minecraft:redstone_wire replace
setblock ~292 ~29 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~29 ~498 ~317 ~29 ~498 minecraft:redstone_wire replace
setblock ~318 ~29 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~29 ~498 ~331 ~29 ~498 minecraft:redstone_wire replace
setblock ~333 ~29 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~335 ~29 ~498 ~345 ~29 ~498 minecraft:redstone_wire replace
setblock ~316 ~29 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~29 ~502 ~80 ~29 ~502 minecraft:redstone_wire replace
setblock ~79 ~29 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~29 ~506 ~101 ~29 ~506 minecraft:redstone_wire replace
setblock ~100 ~29 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~29 ~510 ~119 ~29 ~510 minecraft:redstone_wire replace
setblock ~118 ~29 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~29 ~514 ~144 ~29 ~514 minecraft:redstone_wire replace
setblock ~142 ~29 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~29 ~518 ~186 ~29 ~518 minecraft:redstone_wire replace
setblock ~178 ~29 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~29 ~522 ~204 ~29 ~522 minecraft:redstone_wire replace
setblock ~196 ~29 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~29 ~526 ~226 ~29 ~526 minecraft:redstone_wire replace
setblock ~227 ~29 ~526 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~29 ~526 ~240 ~29 ~526 minecraft:redstone_wire replace
setblock ~226 ~29 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~29 ~530 ~248 ~29 ~530 minecraft:redstone_wire replace
setblock ~250 ~29 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~29 ~530 ~264 ~29 ~530 minecraft:redstone_wire replace
setblock ~247 ~29 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~29 ~534 ~289 ~29 ~534 minecraft:redstone_wire replace
setblock ~290 ~29 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~29 ~534 ~304 ~29 ~534 minecraft:redstone_wire replace
setblock ~306 ~29 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~29 ~534 ~315 ~29 ~534 minecraft:redstone_wire replace
setblock ~289 ~29 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~29 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~29 ~538 ~326 ~29 ~538 minecraft:redstone_wire replace
setblock ~328 ~29 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~29 ~538 ~342 ~29 ~538 minecraft:redstone_wire replace
setblock ~313 ~29 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~29 ~542 ~98 ~29 ~542 minecraft:redstone_wire replace
setblock ~97 ~29 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~29 ~546 ~116 ~29 ~546 minecraft:redstone_wire replace
setblock ~115 ~29 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~29 ~550 ~141 ~29 ~550 minecraft:redstone_wire replace
setblock ~139 ~29 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~29 ~554 ~174 ~29 ~554 minecraft:redstone_wire replace
setblock ~169 ~29 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~29 ~558 ~193 ~29 ~558 minecraft:redstone_wire replace
setblock ~194 ~29 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~29 ~558 ~201 ~29 ~558 minecraft:redstone_wire replace
setblock ~193 ~29 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~29 ~562 ~224 ~29 ~562 minecraft:redstone_wire replace
setblock ~225 ~29 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~29 ~562 ~237 ~29 ~562 minecraft:redstone_wire replace
setblock ~223 ~29 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~252 ~29 ~566 ~254 ~29 ~566 minecraft:redstone_wire replace
setblock ~256 ~29 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~29 ~566 ~270 ~29 ~566 minecraft:redstone_wire replace
setblock ~253 ~29 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~29 ~570 ~276 ~29 ~570 minecraft:redstone_wire replace
setblock ~278 ~29 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~29 ~570 ~291 ~29 ~570 minecraft:redstone_wire replace
setblock ~271 ~29 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~29 ~574 ~308 ~29 ~574 minecraft:redstone_wire replace
setblock ~310 ~29 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~29 ~574 ~325 ~29 ~574 minecraft:redstone_wire replace
setblock ~327 ~29 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~29 ~574 ~336 ~29 ~574 minecraft:redstone_wire replace
setblock ~307 ~29 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~29 ~578 ~162 ~29 ~578 minecraft:redstone_wire replace
setblock ~157 ~29 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~29 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~328 ~29 ~582 ~341 ~29 ~582 minecraft:redstone_wire replace
setblock ~343 ~29 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~345 ~29 ~582 ~357 ~29 ~582 minecraft:redstone_wire replace
setblock ~328 ~29 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~29 ~586 ~95 ~29 ~586 minecraft:redstone_wire replace
setblock ~94 ~29 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~29 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~29 ~590 ~323 ~29 ~590 minecraft:redstone_wire replace
setblock ~325 ~29 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~29 ~590 ~339 ~29 ~590 minecraft:redstone_wire replace
setblock ~310 ~29 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~29 ~594 ~326 ~29 ~594 minecraft:redstone_wire replace
setblock ~328 ~29 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~29 ~594 ~343 ~29 ~594 minecraft:redstone_wire replace
setblock ~345 ~29 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~347 ~29 ~594 ~354 ~29 ~594 minecraft:redstone_wire replace
setblock ~325 ~29 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~30 ~16 minecraft:redstone_wire replace
setblock ~151 ~30 ~24 minecraft:redstone_wire replace
setblock ~172 ~30 ~32 minecraft:redstone_wire replace
setblock ~199 ~30 ~40 minecraft:redstone_wire replace
setblock ~214 ~30 ~48 minecraft:redstone_wire replace
setblock ~235 ~30 ~56 minecraft:redstone_wire replace
setblock ~265 ~30 ~64 minecraft:redstone_wire replace
setblock ~277 ~30 ~68 minecraft:redstone_wire replace
setblock ~283 ~30 ~80 minecraft:redstone_wire replace
setblock ~298 ~30 ~84 minecraft:redstone_wire replace
setblock ~133 ~30 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~30 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~30 ~272 minecraft:redstone_wire replace
setblock ~154 ~30 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~30 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~30 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~30 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~30 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~30 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~30 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~30 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~30 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~30 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~30 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~30 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~30 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~30 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~30 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~30 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~30 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~30 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~30 ~348 minecraft:redstone_wire replace
setblock ~112 ~30 ~352 minecraft:redstone_wire replace
setblock ~136 ~30 ~356 minecraft:redstone_wire replace
setblock ~166 ~30 ~360 minecraft:redstone_wire replace
setblock ~190 ~30 ~364 minecraft:redstone_wire replace
setblock ~220 ~30 ~368 minecraft:redstone_wire replace
setblock ~244 ~30 ~372 minecraft:redstone_wire replace
setblock ~262 ~30 ~376 minecraft:redstone_wire replace
setblock ~286 ~30 ~380 minecraft:redstone_wire replace
setblock ~88 ~30 ~384 minecraft:redstone_wire replace
setblock ~109 ~30 ~388 minecraft:redstone_wire replace
setblock ~130 ~30 ~392 minecraft:redstone_wire replace
setblock ~163 ~30 ~396 minecraft:redstone_wire replace
setblock ~187 ~30 ~400 minecraft:redstone_wire replace
setblock ~211 ~30 ~404 minecraft:redstone_wire replace
setblock ~241 ~30 ~408 minecraft:redstone_wire replace
setblock ~259 ~30 ~412 minecraft:redstone_wire replace
setblock ~304 ~30 ~416 minecraft:redstone_wire replace
setblock ~322 ~30 ~420 minecraft:redstone_wire replace
setblock ~85 ~30 ~424 minecraft:redstone_wire replace
setblock ~106 ~30 ~428 minecraft:redstone_wire replace
setblock ~124 ~30 ~432 minecraft:redstone_wire replace
setblock ~160 ~30 ~436 minecraft:redstone_wire replace
setblock ~184 ~30 ~440 minecraft:redstone_wire replace
setblock ~208 ~30 ~444 minecraft:redstone_wire replace
setblock ~232 ~30 ~448 minecraft:redstone_wire replace
setblock ~256 ~30 ~452 minecraft:redstone_wire replace
setblock ~301 ~30 ~456 minecraft:redstone_wire replace
setblock ~319 ~30 ~460 minecraft:redstone_wire replace
setblock ~82 ~30 ~464 minecraft:redstone_wire replace
setblock ~103 ~30 ~468 minecraft:redstone_wire replace
setblock ~121 ~30 ~472 minecraft:redstone_wire replace
setblock ~148 ~30 ~476 minecraft:redstone_wire replace
setblock ~181 ~30 ~480 minecraft:redstone_wire replace
setblock ~205 ~30 ~484 minecraft:redstone_wire replace
setblock ~229 ~30 ~488 minecraft:redstone_wire replace
setblock ~250 ~30 ~492 minecraft:redstone_wire replace
setblock ~292 ~30 ~496 minecraft:redstone_wire replace
setblock ~316 ~30 ~500 minecraft:redstone_wire replace
setblock ~79 ~30 ~504 minecraft:redstone_wire replace
setblock ~100 ~30 ~508 minecraft:redstone_wire replace
setblock ~118 ~30 ~512 minecraft:redstone_wire replace
setblock ~142 ~30 ~516 minecraft:redstone_wire replace
setblock ~178 ~30 ~520 minecraft:redstone_wire replace
setblock ~196 ~30 ~524 minecraft:redstone_wire replace
setblock ~226 ~30 ~528 minecraft:redstone_wire replace
setblock ~247 ~30 ~532 minecraft:redstone_wire replace
setblock ~289 ~30 ~536 minecraft:redstone_wire replace
setblock ~313 ~30 ~540 minecraft:redstone_wire replace
setblock ~97 ~30 ~544 minecraft:redstone_wire replace
setblock ~115 ~30 ~548 minecraft:redstone_wire replace
setblock ~139 ~30 ~552 minecraft:redstone_wire replace
setblock ~169 ~30 ~556 minecraft:redstone_wire replace
setblock ~193 ~30 ~560 minecraft:redstone_wire replace
setblock ~223 ~30 ~564 minecraft:redstone_wire replace
setblock ~253 ~30 ~568 minecraft:redstone_wire replace
setblock ~271 ~30 ~572 minecraft:redstone_wire replace
setblock ~307 ~30 ~576 minecraft:redstone_wire replace
setblock ~157 ~30 ~580 minecraft:redstone_wire replace
setblock ~328 ~30 ~584 minecraft:redstone_wire replace
setblock ~94 ~30 ~588 minecraft:redstone_wire replace
setblock ~310 ~30 ~592 minecraft:redstone_wire replace
setblock ~325 ~30 ~596 minecraft:redstone_wire replace
fill ~126 ~31 ~12 ~126 ~31 ~16 minecraft:redstone_wire replace
fill ~150 ~31 ~20 ~150 ~31 ~24 minecraft:redstone_wire replace
fill ~171 ~31 ~28 ~171 ~31 ~32 minecraft:redstone_wire replace
fill ~198 ~31 ~36 ~198 ~31 ~40 minecraft:redstone_wire replace
fill ~213 ~31 ~44 ~213 ~31 ~48 minecraft:redstone_wire replace
fill ~234 ~31 ~52 ~234 ~31 ~56 minecraft:redstone_wire replace
fill ~264 ~31 ~60 ~264 ~31 ~64 minecraft:redstone_wire replace
fill ~276 ~31 ~64 ~276 ~31 ~68 minecraft:redstone_wire replace
fill ~282 ~31 ~76 ~282 ~31 ~80 minecraft:redstone_wire replace
fill ~297 ~31 ~80 ~297 ~31 ~84 minecraft:redstone_wire replace
setblock ~132 ~31 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~31 ~262 ~132 ~31 ~268 minecraft:redstone_wire replace
fill ~144 ~31 ~268 ~144 ~31 ~272 minecraft:redstone_wire replace
setblock ~153 ~31 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~31 ~274 ~153 ~31 ~280 minecraft:redstone_wire replace
setblock ~174 ~31 ~280 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~31 ~282 ~174 ~31 ~288 minecraft:redstone_wire replace
setblock ~201 ~31 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~31 ~290 ~201 ~31 ~296 minecraft:redstone_wire replace
setblock ~216 ~31 ~296 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~31 ~298 ~216 ~31 ~304 minecraft:redstone_wire replace
setblock ~237 ~31 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~31 ~306 ~237 ~31 ~312 minecraft:redstone_wire replace
setblock ~267 ~31 ~312 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~31 ~314 ~267 ~31 ~320 minecraft:redstone_wire replace
setblock ~273 ~31 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~31 ~322 ~273 ~31 ~328 minecraft:redstone_wire replace
setblock ~279 ~31 ~328 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~31 ~330 ~279 ~31 ~336 minecraft:redstone_wire replace
setblock ~294 ~31 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~294 ~31 ~338 ~294 ~31 ~344 minecraft:redstone_wire replace
fill ~90 ~31 ~344 ~90 ~31 ~348 minecraft:redstone_wire replace
fill ~111 ~31 ~348 ~111 ~31 ~352 minecraft:redstone_wire replace
fill ~135 ~31 ~352 ~135 ~31 ~356 minecraft:redstone_wire replace
fill ~165 ~31 ~356 ~165 ~31 ~360 minecraft:redstone_wire replace
fill ~189 ~31 ~360 ~189 ~31 ~364 minecraft:redstone_wire replace
fill ~219 ~31 ~364 ~219 ~31 ~368 minecraft:redstone_wire replace
fill ~243 ~31 ~368 ~243 ~31 ~372 minecraft:redstone_wire replace
fill ~261 ~31 ~372 ~261 ~31 ~376 minecraft:redstone_wire replace
fill ~285 ~31 ~376 ~285 ~31 ~380 minecraft:redstone_wire replace
fill ~87 ~31 ~380 ~87 ~31 ~384 minecraft:redstone_wire replace
fill ~108 ~31 ~384 ~108 ~31 ~388 minecraft:redstone_wire replace
fill ~129 ~31 ~388 ~129 ~31 ~392 minecraft:redstone_wire replace
fill ~162 ~31 ~392 ~162 ~31 ~396 minecraft:redstone_wire replace
fill ~186 ~31 ~396 ~186 ~31 ~400 minecraft:redstone_wire replace
fill ~210 ~31 ~400 ~210 ~31 ~404 minecraft:redstone_wire replace
fill ~240 ~31 ~404 ~240 ~31 ~408 minecraft:redstone_wire replace
fill ~258 ~31 ~408 ~258 ~31 ~412 minecraft:redstone_wire replace
fill ~303 ~31 ~412 ~303 ~31 ~416 minecraft:redstone_wire replace
fill ~321 ~31 ~416 ~321 ~31 ~420 minecraft:redstone_wire replace
fill ~84 ~31 ~420 ~84 ~31 ~424 minecraft:redstone_wire replace
fill ~105 ~31 ~424 ~105 ~31 ~428 minecraft:redstone_wire replace
fill ~123 ~31 ~428 ~123 ~31 ~432 minecraft:redstone_wire replace
fill ~159 ~31 ~432 ~159 ~31 ~436 minecraft:redstone_wire replace
fill ~183 ~31 ~436 ~183 ~31 ~440 minecraft:redstone_wire replace
fill ~207 ~31 ~440 ~207 ~31 ~444 minecraft:redstone_wire replace
fill ~231 ~31 ~444 ~231 ~31 ~448 minecraft:redstone_wire replace
fill ~255 ~31 ~448 ~255 ~31 ~452 minecraft:redstone_wire replace
fill ~300 ~31 ~452 ~300 ~31 ~456 minecraft:redstone_wire replace
fill ~318 ~31 ~456 ~318 ~31 ~460 minecraft:redstone_wire replace
fill ~81 ~31 ~460 ~81 ~31 ~464 minecraft:redstone_wire replace
fill ~102 ~31 ~464 ~102 ~31 ~468 minecraft:redstone_wire replace
fill ~120 ~31 ~468 ~120 ~31 ~472 minecraft:redstone_wire replace
fill ~147 ~31 ~472 ~147 ~31 ~476 minecraft:redstone_wire replace
fill ~180 ~31 ~476 ~180 ~31 ~480 minecraft:redstone_wire replace
fill ~204 ~31 ~480 ~204 ~31 ~484 minecraft:redstone_wire replace
fill ~228 ~31 ~484 ~228 ~31 ~488 minecraft:redstone_wire replace
fill ~249 ~31 ~488 ~249 ~31 ~492 minecraft:redstone_wire replace
fill ~291 ~31 ~492 ~291 ~31 ~496 minecraft:redstone_wire replace
fill ~315 ~31 ~496 ~315 ~31 ~500 minecraft:redstone_wire replace
fill ~78 ~31 ~500 ~78 ~31 ~504 minecraft:redstone_wire replace
fill ~99 ~31 ~504 ~99 ~31 ~508 minecraft:redstone_wire replace
fill ~117 ~31 ~508 ~117 ~31 ~512 minecraft:redstone_wire replace
fill ~141 ~31 ~512 ~141 ~31 ~516 minecraft:redstone_wire replace
fill ~177 ~31 ~516 ~177 ~31 ~520 minecraft:redstone_wire replace
fill ~195 ~31 ~520 ~195 ~31 ~524 minecraft:redstone_wire replace
fill ~225 ~31 ~524 ~225 ~31 ~528 minecraft:redstone_wire replace
fill ~246 ~31 ~528 ~246 ~31 ~532 minecraft:redstone_wire replace
fill ~288 ~31 ~532 ~288 ~31 ~536 minecraft:redstone_wire replace
fill ~312 ~31 ~536 ~312 ~31 ~540 minecraft:redstone_wire replace
fill ~96 ~31 ~540 ~96 ~31 ~544 minecraft:redstone_wire replace
fill ~114 ~31 ~544 ~114 ~31 ~548 minecraft:redstone_wire replace
fill ~138 ~31 ~548 ~138 ~31 ~552 minecraft:redstone_wire replace
fill ~168 ~31 ~552 ~168 ~31 ~556 minecraft:redstone_wire replace
fill ~192 ~31 ~556 ~192 ~31 ~560 minecraft:redstone_wire replace
fill ~222 ~31 ~560 ~222 ~31 ~564 minecraft:redstone_wire replace
fill ~252 ~31 ~564 ~252 ~31 ~568 minecraft:redstone_wire replace
fill ~270 ~31 ~568 ~270 ~31 ~572 minecraft:redstone_wire replace
fill ~306 ~31 ~572 ~306 ~31 ~576 minecraft:redstone_wire replace
fill ~156 ~31 ~576 ~156 ~31 ~580 minecraft:redstone_wire replace
fill ~327 ~31 ~580 ~327 ~31 ~584 minecraft:redstone_wire replace
fill ~93 ~31 ~584 ~93 ~31 ~588 minecraft:redstone_wire replace
fill ~309 ~31 ~588 ~309 ~31 ~592 minecraft:redstone_wire replace
fill ~324 ~31 ~592 ~324 ~31 ~596 minecraft:redstone_wire replace
setblock ~126 ~32 ~11 minecraft:redstone_wire replace
setblock ~150 ~32 ~19 minecraft:redstone_wire replace
setblock ~171 ~32 ~27 minecraft:redstone_wire replace
setblock ~198 ~32 ~35 minecraft:redstone_wire replace
setblock ~213 ~32 ~43 minecraft:redstone_wire replace
setblock ~234 ~32 ~51 minecraft:redstone_wire replace
setblock ~264 ~32 ~59 minecraft:redstone_wire replace
setblock ~276 ~32 ~63 minecraft:redstone_wire replace
setblock ~282 ~32 ~75 minecraft:redstone_wire replace
setblock ~297 ~32 ~79 minecraft:redstone_wire replace
setblock ~132 ~32 ~259 minecraft:redstone_wire replace
setblock ~144 ~32 ~267 minecraft:redstone_wire replace
setblock ~153 ~32 ~271 minecraft:redstone_wire replace
setblock ~174 ~32 ~279 minecraft:redstone_wire replace
setblock ~201 ~32 ~287 minecraft:redstone_wire replace
setblock ~216 ~32 ~295 minecraft:redstone_wire replace
setblock ~237 ~32 ~303 minecraft:redstone_wire replace
setblock ~267 ~32 ~311 minecraft:redstone_wire replace
setblock ~273 ~32 ~319 minecraft:redstone_wire replace
setblock ~279 ~32 ~327 minecraft:redstone_wire replace
setblock ~294 ~32 ~335 minecraft:redstone_wire replace
setblock ~90 ~32 ~343 minecraft:redstone_wire replace
setblock ~111 ~32 ~347 minecraft:redstone_wire replace
setblock ~135 ~32 ~351 minecraft:redstone_wire replace
setblock ~165 ~32 ~355 minecraft:redstone_wire replace
setblock ~189 ~32 ~359 minecraft:redstone_wire replace
setblock ~219 ~32 ~363 minecraft:redstone_wire replace
setblock ~243 ~32 ~367 minecraft:redstone_wire replace
setblock ~261 ~32 ~371 minecraft:redstone_wire replace
setblock ~285 ~32 ~375 minecraft:redstone_wire replace
setblock ~87 ~32 ~379 minecraft:redstone_wire replace
setblock ~108 ~32 ~383 minecraft:redstone_wire replace
setblock ~129 ~32 ~387 minecraft:redstone_wire replace
setblock ~162 ~32 ~391 minecraft:redstone_wire replace
setblock ~186 ~32 ~395 minecraft:redstone_wire replace
setblock ~210 ~32 ~399 minecraft:redstone_wire replace
setblock ~240 ~32 ~403 minecraft:redstone_wire replace
setblock ~258 ~32 ~407 minecraft:redstone_wire replace
setblock ~303 ~32 ~411 minecraft:redstone_wire replace
setblock ~321 ~32 ~415 minecraft:redstone_wire replace
setblock ~84 ~32 ~419 minecraft:redstone_wire replace
setblock ~105 ~32 ~423 minecraft:redstone_wire replace
setblock ~123 ~32 ~427 minecraft:redstone_wire replace
setblock ~159 ~32 ~431 minecraft:redstone_wire replace
setblock ~183 ~32 ~435 minecraft:redstone_wire replace
setblock ~207 ~32 ~439 minecraft:redstone_wire replace
setblock ~231 ~32 ~443 minecraft:redstone_wire replace
setblock ~255 ~32 ~447 minecraft:redstone_wire replace
setblock ~300 ~32 ~451 minecraft:redstone_wire replace
setblock ~318 ~32 ~455 minecraft:redstone_wire replace
setblock ~81 ~32 ~459 minecraft:redstone_wire replace
setblock ~102 ~32 ~463 minecraft:redstone_wire replace
setblock ~120 ~32 ~467 minecraft:redstone_wire replace
setblock ~147 ~32 ~471 minecraft:redstone_wire replace
setblock ~180 ~32 ~475 minecraft:redstone_wire replace
setblock ~204 ~32 ~479 minecraft:redstone_wire replace
setblock ~228 ~32 ~483 minecraft:redstone_wire replace
setblock ~249 ~32 ~487 minecraft:redstone_wire replace
setblock ~291 ~32 ~491 minecraft:redstone_wire replace
setblock ~315 ~32 ~495 minecraft:redstone_wire replace
setblock ~78 ~32 ~499 minecraft:redstone_wire replace
setblock ~99 ~32 ~503 minecraft:redstone_wire replace
setblock ~117 ~32 ~507 minecraft:redstone_wire replace
setblock ~141 ~32 ~511 minecraft:redstone_wire replace
setblock ~177 ~32 ~515 minecraft:redstone_wire replace
setblock ~195 ~32 ~519 minecraft:redstone_wire replace
setblock ~225 ~32 ~523 minecraft:redstone_wire replace
setblock ~246 ~32 ~527 minecraft:redstone_wire replace
setblock ~288 ~32 ~531 minecraft:redstone_wire replace
setblock ~312 ~32 ~535 minecraft:redstone_wire replace
setblock ~96 ~32 ~539 minecraft:redstone_wire replace
setblock ~114 ~32 ~543 minecraft:redstone_wire replace
setblock ~138 ~32 ~547 minecraft:redstone_wire replace
setblock ~168 ~32 ~551 minecraft:redstone_wire replace
setblock ~192 ~32 ~555 minecraft:redstone_wire replace
setblock ~222 ~32 ~559 minecraft:redstone_wire replace
setblock ~252 ~32 ~563 minecraft:redstone_wire replace
setblock ~270 ~32 ~567 minecraft:redstone_wire replace
setblock ~306 ~32 ~571 minecraft:redstone_wire replace
setblock ~156 ~32 ~575 minecraft:redstone_wire replace
setblock ~327 ~32 ~579 minecraft:redstone_wire replace
setblock ~93 ~32 ~583 minecraft:redstone_wire replace
setblock ~309 ~32 ~587 minecraft:redstone_wire replace
setblock ~324 ~32 ~591 minecraft:redstone_wire replace
setblock ~94 ~33 ~9 minecraft:redstone_wire replace
setblock ~121 ~33 ~9 minecraft:redstone_wire replace
setblock ~151 ~33 ~9 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~178 ~33 ~9 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~33 ~10 ~99 ~33 ~10 minecraft:redstone_wire replace
setblock ~101 ~33 ~10 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~33 ~10 ~116 ~33 ~10 minecraft:redstone_wire replace
setblock ~118 ~33 ~10 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~33 ~10 ~132 ~33 ~10 minecraft:redstone_wire replace
setblock ~134 ~33 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~33 ~10 ~149 ~33 ~10 minecraft:redstone_wire replace
setblock ~150 ~33 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~151 ~33 ~10 ~164 ~33 ~10 minecraft:redstone_wire replace
setblock ~166 ~33 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~168 ~33 ~10 ~179 ~33 ~10 minecraft:redstone_wire replace
setblock ~118 ~33 ~17 minecraft:redstone_wire replace
setblock ~142 ~33 ~17 minecraft:redstone_wire replace
setblock ~172 ~33 ~17 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~33 ~17 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~33 ~18 ~125 ~33 ~18 minecraft:redstone_wire replace
setblock ~127 ~33 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~33 ~18 ~142 ~33 ~18 minecraft:redstone_wire replace
setblock ~143 ~33 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~33 ~18 ~156 ~33 ~18 minecraft:redstone_wire replace
setblock ~158 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~33 ~18 ~173 ~33 ~18 minecraft:redstone_wire replace
setblock ~175 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~33 ~18 ~190 ~33 ~18 minecraft:redstone_wire replace
setblock ~192 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~33 ~18 ~207 ~33 ~18 minecraft:redstone_wire replace
setblock ~209 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~33 ~18 ~212 ~33 ~18 minecraft:redstone_wire replace
setblock ~145 ~33 ~25 minecraft:redstone_wire replace
setblock ~169 ~33 ~25 minecraft:redstone_wire replace
setblock ~202 ~33 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~33 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~33 ~26 ~146 ~33 ~26 minecraft:redstone_wire replace
setblock ~147 ~33 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~33 ~26 ~161 ~33 ~26 minecraft:redstone_wire replace
setblock ~163 ~33 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~33 ~26 ~177 ~33 ~26 minecraft:redstone_wire replace
setblock ~179 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~181 ~33 ~26 ~194 ~33 ~26 minecraft:redstone_wire replace
setblock ~196 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~198 ~33 ~26 ~211 ~33 ~26 minecraft:redstone_wire replace
setblock ~213 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~215 ~33 ~26 ~228 ~33 ~26 minecraft:redstone_wire replace
setblock ~230 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~33 ~26 ~245 ~33 ~26 minecraft:redstone_wire replace
setblock ~247 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~33 ~26 ~254 ~33 ~26 minecraft:redstone_wire replace
setblock ~175 ~33 ~33 minecraft:redstone_wire replace
setblock ~241 ~33 ~33 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~33 ~33 minecraft:redstone_wire replace
setblock ~174 ~33 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~33 ~34 ~188 ~33 ~34 minecraft:redstone_wire replace
setblock ~190 ~33 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~33 ~34 ~204 ~33 ~34 minecraft:redstone_wire replace
setblock ~206 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~33 ~34 ~221 ~33 ~34 minecraft:redstone_wire replace
setblock ~223 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~33 ~34 ~238 ~33 ~34 minecraft:redstone_wire replace
setblock ~239 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~33 ~34 ~253 ~33 ~34 minecraft:redstone_wire replace
setblock ~255 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~257 ~33 ~34 ~260 ~33 ~34 minecraft:redstone_wire replace
setblock ~196 ~33 ~41 minecraft:redstone_wire replace
setblock ~226 ~33 ~41 minecraft:redstone_wire replace
setblock ~247 ~33 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~33 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~33 ~42 ~203 ~33 ~42 minecraft:redstone_wire replace
setblock ~205 ~33 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~33 ~42 ~219 ~33 ~42 minecraft:redstone_wire replace
setblock ~221 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~33 ~42 ~236 ~33 ~42 minecraft:redstone_wire replace
setblock ~238 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~33 ~42 ~253 ~33 ~42 minecraft:redstone_wire replace
setblock ~255 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~257 ~33 ~42 ~270 ~33 ~42 minecraft:redstone_wire replace
setblock ~272 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~274 ~33 ~42 ~287 ~33 ~42 minecraft:redstone_wire replace
setblock ~289 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~33 ~42 ~302 ~33 ~42 minecraft:redstone_wire replace
setblock ~229 ~33 ~49 minecraft:redstone_wire replace
setblock ~262 ~33 ~49 minecraft:redstone_wire replace
setblock ~283 ~33 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~33 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~33 ~50 ~240 ~33 ~50 minecraft:redstone_wire replace
setblock ~242 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~33 ~50 ~257 ~33 ~50 minecraft:redstone_wire replace
setblock ~259 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~33 ~50 ~274 ~33 ~50 minecraft:redstone_wire replace
setblock ~276 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~278 ~33 ~50 ~291 ~33 ~50 minecraft:redstone_wire replace
setblock ~293 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~33 ~50 ~308 ~33 ~50 minecraft:redstone_wire replace
setblock ~310 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~50 ~325 ~33 ~50 minecraft:redstone_wire replace
setblock ~327 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~33 ~50 ~332 ~33 ~50 minecraft:redstone_wire replace
setblock ~265 ~33 ~57 minecraft:redstone_wire replace
setblock ~316 ~33 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~33 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~33 ~57 minecraft:redstone_wire replace
fill ~264 ~33 ~58 ~269 ~33 ~58 minecraft:redstone_wire replace
setblock ~271 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~33 ~58 ~285 ~33 ~58 minecraft:redstone_wire replace
setblock ~287 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~289 ~33 ~58 ~301 ~33 ~58 minecraft:redstone_wire replace
setblock ~303 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~305 ~33 ~58 ~317 ~33 ~58 minecraft:redstone_wire replace
setblock ~319 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~321 ~33 ~58 ~333 ~33 ~58 minecraft:redstone_wire replace
setblock ~335 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~33 ~58 ~341 ~33 ~58 minecraft:redstone_wire replace
setblock ~319 ~33 ~61 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~33 ~61 minecraft:redstone_wire replace
setblock ~343 ~33 ~61 minecraft:redstone_wire replace
fill ~276 ~33 ~62 ~282 ~33 ~62 minecraft:redstone_wire replace
setblock ~284 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~33 ~62 ~299 ~33 ~62 minecraft:redstone_wire replace
setblock ~301 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~33 ~62 ~316 ~33 ~62 minecraft:redstone_wire replace
setblock ~317 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~33 ~62 ~331 ~33 ~62 minecraft:redstone_wire replace
setblock ~333 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~335 ~33 ~62 ~344 ~33 ~62 minecraft:redstone_wire replace
setblock ~286 ~33 ~73 minecraft:redstone_wire replace
setblock ~328 ~33 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~33 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~33 ~73 minecraft:redstone_wire replace
fill ~282 ~33 ~74 ~288 ~33 ~74 minecraft:redstone_wire replace
setblock ~290 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~33 ~74 ~305 ~33 ~74 minecraft:redstone_wire replace
setblock ~307 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~33 ~74 ~322 ~33 ~74 minecraft:redstone_wire replace
setblock ~324 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~326 ~33 ~74 ~339 ~33 ~74 minecraft:redstone_wire replace
setblock ~341 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~343 ~33 ~74 ~356 ~33 ~74 minecraft:redstone_wire replace
setblock ~358 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~360 ~33 ~74 ~373 ~33 ~74 minecraft:redstone_wire replace
setblock ~375 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~377 ~33 ~74 ~389 ~33 ~74 minecraft:redstone_wire replace
setblock ~355 ~33 ~77 minecraft:redstone_wire replace
setblock ~361 ~33 ~77 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~33 ~77 minecraft:redstone_wire replace
fill ~297 ~33 ~78 ~302 ~33 ~78 minecraft:redstone_wire replace
setblock ~304 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~306 ~33 ~78 ~318 ~33 ~78 minecraft:redstone_wire replace
setblock ~320 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~322 ~33 ~78 ~334 ~33 ~78 minecraft:redstone_wire replace
setblock ~336 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~338 ~33 ~78 ~350 ~33 ~78 minecraft:redstone_wire replace
setblock ~352 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~33 ~78 ~366 ~33 ~78 minecraft:redstone_wire replace
setblock ~368 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~370 ~33 ~78 ~380 ~33 ~78 minecraft:redstone_wire replace
setblock ~94 ~33 ~257 minecraft:redstone_wire replace
setblock ~121 ~33 ~257 minecraft:redstone_wire replace
setblock ~151 ~33 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~33 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~33 ~258 ~99 ~33 ~258 minecraft:redstone_wire replace
setblock ~101 ~33 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~33 ~258 ~116 ~33 ~258 minecraft:redstone_wire replace
setblock ~118 ~33 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~33 ~258 ~144 ~33 ~258 minecraft:redstone_wire replace
setblock ~146 ~33 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~33 ~258 ~161 ~33 ~258 minecraft:redstone_wire replace
setblock ~163 ~33 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~33 ~258 ~178 ~33 ~258 minecraft:redstone_wire replace
setblock ~179 ~33 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~180 ~33 ~258 ~182 ~33 ~258 minecraft:redstone_wire replace
setblock ~157 ~33 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~33 ~266 ~150 ~33 ~266 minecraft:redstone_wire replace
setblock ~152 ~33 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~154 ~33 ~266 ~158 ~33 ~266 minecraft:redstone_wire replace
setblock ~118 ~33 ~269 minecraft:redstone_wire replace
setblock ~142 ~33 ~269 minecraft:redstone_wire replace
setblock ~172 ~33 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~214 ~33 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~33 ~270 ~120 ~33 ~270 minecraft:redstone_wire replace
setblock ~122 ~33 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~33 ~270 ~137 ~33 ~270 minecraft:redstone_wire replace
setblock ~139 ~33 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~33 ~270 ~165 ~33 ~270 minecraft:redstone_wire replace
setblock ~167 ~33 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~33 ~270 ~182 ~33 ~270 minecraft:redstone_wire replace
setblock ~184 ~33 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~33 ~270 ~199 ~33 ~270 minecraft:redstone_wire replace
setblock ~201 ~33 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~203 ~33 ~270 ~215 ~33 ~270 minecraft:redstone_wire replace
setblock ~145 ~33 ~277 minecraft:redstone_wire replace
setblock ~169 ~33 ~277 minecraft:redstone_wire replace
setblock ~202 ~33 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~256 ~33 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~33 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~33 ~278 ~158 ~33 ~278 minecraft:redstone_wire replace
setblock ~160 ~33 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~33 ~278 ~186 ~33 ~278 minecraft:redstone_wire replace
setblock ~188 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~190 ~33 ~278 ~203 ~33 ~278 minecraft:redstone_wire replace
setblock ~205 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~207 ~33 ~278 ~220 ~33 ~278 minecraft:redstone_wire replace
setblock ~222 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~224 ~33 ~278 ~237 ~33 ~278 minecraft:redstone_wire replace
setblock ~239 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~33 ~278 ~254 ~33 ~278 minecraft:redstone_wire replace
setblock ~255 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~256 ~33 ~278 ~257 ~33 ~278 minecraft:redstone_wire replace
setblock ~175 ~33 ~285 minecraft:redstone_wire replace
setblock ~241 ~33 ~285 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~33 ~285 minecraft:redstone_wire replace
fill ~174 ~33 ~286 ~185 ~33 ~286 minecraft:redstone_wire replace
setblock ~187 ~33 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~33 ~286 ~213 ~33 ~286 minecraft:redstone_wire replace
setblock ~215 ~33 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~33 ~286 ~230 ~33 ~286 minecraft:redstone_wire replace
setblock ~232 ~33 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~33 ~286 ~247 ~33 ~286 minecraft:redstone_wire replace
setblock ~249 ~33 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~251 ~33 ~286 ~260 ~33 ~286 minecraft:redstone_wire replace
setblock ~196 ~33 ~293 minecraft:redstone_wire replace
setblock ~226 ~33 ~293 minecraft:redstone_wire replace
setblock ~247 ~33 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~33 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~33 ~294 ~200 ~33 ~294 minecraft:redstone_wire replace
setblock ~202 ~33 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~33 ~294 ~228 ~33 ~294 minecraft:redstone_wire replace
setblock ~230 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~33 ~294 ~245 ~33 ~294 minecraft:redstone_wire replace
setblock ~246 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~33 ~294 ~260 ~33 ~294 minecraft:redstone_wire replace
setblock ~262 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~33 ~294 ~277 ~33 ~294 minecraft:redstone_wire replace
setblock ~279 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~33 ~294 ~294 ~33 ~294 minecraft:redstone_wire replace
setblock ~296 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~33 ~294 ~305 ~33 ~294 minecraft:redstone_wire replace
setblock ~229 ~33 ~301 minecraft:redstone_wire replace
setblock ~262 ~33 ~301 minecraft:redstone_wire replace
setblock ~283 ~33 ~301 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~33 ~301 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~33 ~302 ~249 ~33 ~302 minecraft:redstone_wire replace
setblock ~251 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~33 ~302 ~266 ~33 ~302 minecraft:redstone_wire replace
setblock ~268 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~33 ~302 ~283 ~33 ~302 minecraft:redstone_wire replace
setblock ~284 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~33 ~302 ~298 ~33 ~302 minecraft:redstone_wire replace
setblock ~300 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~33 ~302 ~315 ~33 ~302 minecraft:redstone_wire replace
setblock ~317 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~319 ~33 ~302 ~332 ~33 ~302 minecraft:redstone_wire replace
setblock ~333 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~33 ~302 ~335 ~33 ~302 minecraft:redstone_wire replace
setblock ~265 ~33 ~309 minecraft:redstone_wire replace
setblock ~316 ~33 ~309 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~325 ~33 ~309 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~33 ~309 minecraft:redstone_wire replace
fill ~264 ~33 ~310 ~279 ~33 ~310 minecraft:redstone_wire replace
setblock ~281 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~33 ~310 ~296 ~33 ~310 minecraft:redstone_wire replace
setblock ~298 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~33 ~310 ~313 ~33 ~310 minecraft:redstone_wire replace
setblock ~314 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~33 ~310 ~328 ~33 ~310 minecraft:redstone_wire replace
setblock ~330 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~332 ~33 ~310 ~341 ~33 ~310 minecraft:redstone_wire replace
setblock ~319 ~33 ~317 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~33 ~317 minecraft:redstone_wire replace
setblock ~343 ~33 ~317 minecraft:redstone_wire replace
fill ~273 ~33 ~318 ~285 ~33 ~318 minecraft:redstone_wire replace
setblock ~287 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~289 ~33 ~318 ~302 ~33 ~318 minecraft:redstone_wire replace
setblock ~304 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~306 ~33 ~318 ~319 ~33 ~318 minecraft:redstone_wire replace
setblock ~320 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~321 ~33 ~318 ~334 ~33 ~318 minecraft:redstone_wire replace
setblock ~335 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~336 ~33 ~318 ~344 ~33 ~318 minecraft:redstone_wire replace
setblock ~286 ~33 ~325 minecraft:redstone_wire replace
setblock ~328 ~33 ~325 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~33 ~325 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~33 ~325 minecraft:redstone_wire replace
fill ~279 ~33 ~326 ~291 ~33 ~326 minecraft:redstone_wire replace
setblock ~293 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~33 ~326 ~308 ~33 ~326 minecraft:redstone_wire replace
setblock ~310 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~326 ~325 ~33 ~326 minecraft:redstone_wire replace
setblock ~326 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~33 ~326 ~340 ~33 ~326 minecraft:redstone_wire replace
setblock ~342 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~33 ~326 ~357 ~33 ~326 minecraft:redstone_wire replace
setblock ~359 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~361 ~33 ~326 ~374 ~33 ~326 minecraft:redstone_wire replace
setblock ~376 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~378 ~33 ~326 ~389 ~33 ~326 minecraft:redstone_wire replace
setblock ~355 ~33 ~333 minecraft:redstone_wire replace
setblock ~361 ~33 ~333 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~33 ~333 minecraft:redstone_wire replace
fill ~294 ~33 ~334 ~306 ~33 ~334 minecraft:redstone_wire replace
setblock ~308 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~33 ~334 ~323 ~33 ~334 minecraft:redstone_wire replace
setblock ~325 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~33 ~334 ~340 ~33 ~334 minecraft:redstone_wire replace
setblock ~342 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~33 ~334 ~357 ~33 ~334 minecraft:redstone_wire replace
setblock ~359 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~361 ~33 ~334 ~374 ~33 ~334 minecraft:redstone_wire replace
setblock ~376 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~378 ~33 ~334 ~380 ~33 ~334 minecraft:redstone_wire replace
setblock ~91 ~33 ~341 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~33 ~342 ~92 ~33 ~342 minecraft:redstone_wire replace
setblock ~115 ~33 ~345 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~33 ~346 ~116 ~33 ~346 minecraft:redstone_wire replace
setblock ~139 ~33 ~349 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~33 ~350 ~140 ~33 ~350 minecraft:redstone_wire replace
setblock ~187 ~33 ~353 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~33 ~354 ~171 ~33 ~354 minecraft:redstone_wire replace
setblock ~173 ~33 ~354 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~33 ~354 ~188 ~33 ~354 minecraft:redstone_wire replace
setblock ~217 ~33 ~357 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~33 ~358 ~195 ~33 ~358 minecraft:redstone_wire replace
setblock ~197 ~33 ~358 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~199 ~33 ~358 ~212 ~33 ~358 minecraft:redstone_wire replace
setblock ~214 ~33 ~358 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~216 ~33 ~358 ~218 ~33 ~358 minecraft:redstone_wire replace
setblock ~244 ~33 ~361 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~219 ~33 ~362 ~225 ~33 ~362 minecraft:redstone_wire replace
setblock ~227 ~33 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~33 ~362 ~242 ~33 ~362 minecraft:redstone_wire replace
setblock ~243 ~33 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~33 ~362 ~245 ~33 ~362 minecraft:redstone_wire replace
setblock ~280 ~33 ~365 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~33 ~366 ~249 ~33 ~366 minecraft:redstone_wire replace
setblock ~251 ~33 ~366 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~33 ~366 ~266 ~33 ~366 minecraft:redstone_wire replace
setblock ~268 ~33 ~366 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~33 ~366 ~281 ~33 ~366 minecraft:redstone_wire replace
setblock ~310 ~33 ~369 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~261 ~33 ~370 ~267 ~33 ~370 minecraft:redstone_wire replace
setblock ~269 ~33 ~370 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~271 ~33 ~370 ~284 ~33 ~370 minecraft:redstone_wire replace
setblock ~286 ~33 ~370 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~33 ~370 ~301 ~33 ~370 minecraft:redstone_wire replace
setblock ~303 ~33 ~370 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~305 ~33 ~370 ~311 ~33 ~370 minecraft:redstone_wire replace
setblock ~346 ~33 ~373 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~33 ~374 ~291 ~33 ~374 minecraft:redstone_wire replace
setblock ~293 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~33 ~374 ~308 ~33 ~374 minecraft:redstone_wire replace
setblock ~310 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~374 ~325 ~33 ~374 minecraft:redstone_wire replace
setblock ~327 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~33 ~374 ~342 ~33 ~374 minecraft:redstone_wire replace
setblock ~344 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~346 ~33 ~374 ~347 ~33 ~374 minecraft:redstone_wire replace
setblock ~88 ~33 ~377 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~33 ~378 ~89 ~33 ~378 minecraft:redstone_wire replace
setblock ~112 ~33 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~33 ~382 ~113 ~33 ~382 minecraft:redstone_wire replace
setblock ~136 ~33 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~33 ~386 ~134 ~33 ~386 minecraft:redstone_wire replace
setblock ~135 ~33 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~33 ~386 ~137 ~33 ~386 minecraft:redstone_wire replace
setblock ~184 ~33 ~389 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~33 ~390 ~168 ~33 ~390 minecraft:redstone_wire replace
setblock ~170 ~33 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~33 ~390 ~185 ~33 ~390 minecraft:redstone_wire replace
setblock ~208 ~33 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~33 ~394 ~192 ~33 ~394 minecraft:redstone_wire replace
setblock ~194 ~33 ~394 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~33 ~394 ~209 ~33 ~394 minecraft:redstone_wire replace
setblock ~238 ~33 ~397 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~33 ~398 ~216 ~33 ~398 minecraft:redstone_wire replace
setblock ~218 ~33 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~33 ~398 ~233 ~33 ~398 minecraft:redstone_wire replace
setblock ~235 ~33 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~33 ~398 ~239 ~33 ~398 minecraft:redstone_wire replace
setblock ~277 ~33 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~240 ~33 ~402 ~246 ~33 ~402 minecraft:redstone_wire replace
setblock ~248 ~33 ~402 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~33 ~402 ~263 ~33 ~402 minecraft:redstone_wire replace
setblock ~265 ~33 ~402 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~33 ~402 ~278 ~33 ~402 minecraft:redstone_wire replace
setblock ~307 ~33 ~405 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~33 ~406 ~264 ~33 ~406 minecraft:redstone_wire replace
setblock ~266 ~33 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~33 ~406 ~281 ~33 ~406 minecraft:redstone_wire replace
setblock ~283 ~33 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~33 ~406 ~298 ~33 ~406 minecraft:redstone_wire replace
setblock ~300 ~33 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~33 ~406 ~308 ~33 ~406 minecraft:redstone_wire replace
setblock ~370 ~33 ~409 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~303 ~33 ~410 ~309 ~33 ~410 minecraft:redstone_wire replace
setblock ~311 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~313 ~33 ~410 ~326 ~33 ~410 minecraft:redstone_wire replace
setblock ~328 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~33 ~410 ~343 ~33 ~410 minecraft:redstone_wire replace
setblock ~345 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~347 ~33 ~410 ~360 ~33 ~410 minecraft:redstone_wire replace
setblock ~362 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~364 ~33 ~410 ~371 ~33 ~410 minecraft:redstone_wire replace
setblock ~394 ~33 ~413 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~321 ~33 ~414 ~327 ~33 ~414 minecraft:redstone_wire replace
setblock ~329 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~33 ~414 ~344 ~33 ~414 minecraft:redstone_wire replace
setblock ~346 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~33 ~414 ~361 ~33 ~414 minecraft:redstone_wire replace
setblock ~363 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~365 ~33 ~414 ~378 ~33 ~414 minecraft:redstone_wire replace
setblock ~380 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~382 ~33 ~414 ~395 ~33 ~414 minecraft:redstone_wire replace
setblock ~85 ~33 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~33 ~418 ~86 ~33 ~418 minecraft:redstone_wire replace
setblock ~109 ~33 ~421 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~33 ~422 ~110 ~33 ~422 minecraft:redstone_wire replace
setblock ~133 ~33 ~425 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~33 ~426 ~129 ~33 ~426 minecraft:redstone_wire replace
setblock ~131 ~33 ~426 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~33 ~426 ~134 ~33 ~426 minecraft:redstone_wire replace
setblock ~166 ~33 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~33 ~430 ~164 ~33 ~430 minecraft:redstone_wire replace
setblock ~165 ~33 ~430 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~166 ~33 ~430 ~167 ~33 ~430 minecraft:redstone_wire replace
setblock ~205 ~33 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~33 ~434 ~189 ~33 ~434 minecraft:redstone_wire replace
setblock ~191 ~33 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~33 ~434 ~206 ~33 ~434 minecraft:redstone_wire replace
setblock ~235 ~33 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~33 ~438 ~213 ~33 ~438 minecraft:redstone_wire replace
setblock ~215 ~33 ~438 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~33 ~438 ~230 ~33 ~438 minecraft:redstone_wire replace
setblock ~232 ~33 ~438 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~33 ~438 ~236 ~33 ~438 minecraft:redstone_wire replace
setblock ~274 ~33 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~33 ~442 ~237 ~33 ~442 minecraft:redstone_wire replace
setblock ~239 ~33 ~442 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~33 ~442 ~254 ~33 ~442 minecraft:redstone_wire replace
setblock ~256 ~33 ~442 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~258 ~33 ~442 ~271 ~33 ~442 minecraft:redstone_wire replace
setblock ~272 ~33 ~442 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~33 ~442 ~275 ~33 ~442 minecraft:redstone_wire replace
setblock ~298 ~33 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~255 ~33 ~446 ~261 ~33 ~446 minecraft:redstone_wire replace
setblock ~263 ~33 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~33 ~446 ~278 ~33 ~446 minecraft:redstone_wire replace
setblock ~280 ~33 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~33 ~446 ~295 ~33 ~446 minecraft:redstone_wire replace
setblock ~296 ~33 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~33 ~446 ~299 ~33 ~446 minecraft:redstone_wire replace
setblock ~367 ~33 ~449 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~300 ~33 ~450 ~306 ~33 ~450 minecraft:redstone_wire replace
setblock ~308 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~33 ~450 ~323 ~33 ~450 minecraft:redstone_wire replace
setblock ~325 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~33 ~450 ~340 ~33 ~450 minecraft:redstone_wire replace
setblock ~342 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~33 ~450 ~357 ~33 ~450 minecraft:redstone_wire replace
setblock ~359 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~361 ~33 ~450 ~368 ~33 ~450 minecraft:redstone_wire replace
setblock ~391 ~33 ~453 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~33 ~454 ~324 ~33 ~454 minecraft:redstone_wire replace
setblock ~326 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~328 ~33 ~454 ~341 ~33 ~454 minecraft:redstone_wire replace
setblock ~343 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~345 ~33 ~454 ~358 ~33 ~454 minecraft:redstone_wire replace
setblock ~360 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~362 ~33 ~454 ~375 ~33 ~454 minecraft:redstone_wire replace
setblock ~377 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~379 ~33 ~454 ~392 ~33 ~454 minecraft:redstone_wire replace
setblock ~82 ~33 ~457 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~33 ~458 ~83 ~33 ~458 minecraft:redstone_wire replace
setblock ~106 ~33 ~461 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~33 ~462 ~107 ~33 ~462 minecraft:redstone_wire replace
setblock ~130 ~33 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~33 ~466 ~126 ~33 ~466 minecraft:redstone_wire replace
setblock ~128 ~33 ~466 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~33 ~466 ~131 ~33 ~466 minecraft:redstone_wire replace
setblock ~160 ~33 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~33 ~470 ~153 ~33 ~470 minecraft:redstone_wire replace
setblock ~155 ~33 ~470 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~33 ~470 ~161 ~33 ~470 minecraft:redstone_wire replace
setblock ~199 ~33 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~33 ~474 ~186 ~33 ~474 minecraft:redstone_wire replace
setblock ~188 ~33 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~190 ~33 ~474 ~200 ~33 ~474 minecraft:redstone_wire replace
setblock ~232 ~33 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~33 ~478 ~210 ~33 ~478 minecraft:redstone_wire replace
setblock ~212 ~33 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~214 ~33 ~478 ~227 ~33 ~478 minecraft:redstone_wire replace
setblock ~229 ~33 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~231 ~33 ~478 ~233 ~33 ~478 minecraft:redstone_wire replace
setblock ~271 ~33 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~33 ~482 ~234 ~33 ~482 minecraft:redstone_wire replace
setblock ~236 ~33 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~33 ~482 ~251 ~33 ~482 minecraft:redstone_wire replace
setblock ~253 ~33 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~33 ~482 ~268 ~33 ~482 minecraft:redstone_wire replace
setblock ~269 ~33 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~33 ~482 ~272 ~33 ~482 minecraft:redstone_wire replace
setblock ~292 ~33 ~485 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~33 ~486 ~255 ~33 ~486 minecraft:redstone_wire replace
setblock ~257 ~33 ~486 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~33 ~486 ~272 ~33 ~486 minecraft:redstone_wire replace
setblock ~274 ~33 ~486 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~33 ~486 ~289 ~33 ~486 minecraft:redstone_wire replace
setblock ~290 ~33 ~486 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~33 ~486 ~293 ~33 ~486 minecraft:redstone_wire replace
setblock ~364 ~33 ~489 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~291 ~33 ~490 ~297 ~33 ~490 minecraft:redstone_wire replace
setblock ~299 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~33 ~490 ~314 ~33 ~490 minecraft:redstone_wire replace
setblock ~316 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~33 ~490 ~331 ~33 ~490 minecraft:redstone_wire replace
setblock ~333 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~335 ~33 ~490 ~348 ~33 ~490 minecraft:redstone_wire replace
setblock ~350 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~352 ~33 ~490 ~365 ~33 ~490 minecraft:redstone_wire replace
setblock ~385 ~33 ~493 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~33 ~494 ~321 ~33 ~494 minecraft:redstone_wire replace
setblock ~323 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~325 ~33 ~494 ~338 ~33 ~494 minecraft:redstone_wire replace
setblock ~340 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~33 ~494 ~355 ~33 ~494 minecraft:redstone_wire replace
setblock ~357 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~359 ~33 ~494 ~372 ~33 ~494 minecraft:redstone_wire replace
setblock ~374 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~376 ~33 ~494 ~386 ~33 ~494 minecraft:redstone_wire replace
setblock ~79 ~33 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~33 ~498 ~80 ~33 ~498 minecraft:redstone_wire replace
setblock ~103 ~33 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~33 ~502 ~104 ~33 ~502 minecraft:redstone_wire replace
setblock ~127 ~33 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~33 ~506 ~123 ~33 ~506 minecraft:redstone_wire replace
setblock ~125 ~33 ~506 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~33 ~506 ~128 ~33 ~506 minecraft:redstone_wire replace
setblock ~154 ~33 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~33 ~510 ~147 ~33 ~510 minecraft:redstone_wire replace
setblock ~149 ~33 ~510 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~151 ~33 ~510 ~155 ~33 ~510 minecraft:redstone_wire replace
setblock ~193 ~33 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~33 ~514 ~183 ~33 ~514 minecraft:redstone_wire replace
setblock ~185 ~33 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~33 ~514 ~194 ~33 ~514 minecraft:redstone_wire replace
setblock ~223 ~33 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~33 ~518 ~201 ~33 ~518 minecraft:redstone_wire replace
setblock ~203 ~33 ~518 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~33 ~518 ~218 ~33 ~518 minecraft:redstone_wire replace
setblock ~220 ~33 ~518 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~222 ~33 ~518 ~224 ~33 ~518 minecraft:redstone_wire replace
setblock ~268 ~33 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~225 ~33 ~522 ~231 ~33 ~522 minecraft:redstone_wire replace
setblock ~233 ~33 ~522 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~33 ~522 ~248 ~33 ~522 minecraft:redstone_wire replace
setblock ~250 ~33 ~522 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~33 ~522 ~265 ~33 ~522 minecraft:redstone_wire replace
setblock ~266 ~33 ~522 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~33 ~522 ~269 ~33 ~522 minecraft:redstone_wire replace
setblock ~289 ~33 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~33 ~526 ~252 ~33 ~526 minecraft:redstone_wire replace
setblock ~254 ~33 ~526 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~256 ~33 ~526 ~269 ~33 ~526 minecraft:redstone_wire replace
setblock ~271 ~33 ~526 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~33 ~526 ~286 ~33 ~526 minecraft:redstone_wire replace
setblock ~287 ~33 ~526 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~33 ~526 ~290 ~33 ~526 minecraft:redstone_wire replace
setblock ~358 ~33 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~288 ~33 ~530 ~294 ~33 ~530 minecraft:redstone_wire replace
setblock ~296 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~33 ~530 ~311 ~33 ~530 minecraft:redstone_wire replace
setblock ~313 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~33 ~530 ~328 ~33 ~530 minecraft:redstone_wire replace
setblock ~330 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~332 ~33 ~530 ~345 ~33 ~530 minecraft:redstone_wire replace
setblock ~347 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~349 ~33 ~530 ~359 ~33 ~530 minecraft:redstone_wire replace
setblock ~382 ~33 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~33 ~534 ~318 ~33 ~534 minecraft:redstone_wire replace
setblock ~320 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~322 ~33 ~534 ~335 ~33 ~534 minecraft:redstone_wire replace
setblock ~337 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~339 ~33 ~534 ~352 ~33 ~534 minecraft:redstone_wire replace
setblock ~354 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~356 ~33 ~534 ~369 ~33 ~534 minecraft:redstone_wire replace
setblock ~371 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~373 ~33 ~534 ~383 ~33 ~534 minecraft:redstone_wire replace
setblock ~100 ~33 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~33 ~538 ~101 ~33 ~538 minecraft:redstone_wire replace
setblock ~124 ~33 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~33 ~542 ~120 ~33 ~542 minecraft:redstone_wire replace
setblock ~122 ~33 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~33 ~542 ~125 ~33 ~542 minecraft:redstone_wire replace
setblock ~148 ~33 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~33 ~546 ~144 ~33 ~546 minecraft:redstone_wire replace
setblock ~146 ~33 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~33 ~546 ~149 ~33 ~546 minecraft:redstone_wire replace
setblock ~190 ~33 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~33 ~550 ~174 ~33 ~550 minecraft:redstone_wire replace
setblock ~176 ~33 ~550 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~33 ~550 ~191 ~33 ~550 minecraft:redstone_wire replace
setblock ~220 ~33 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~33 ~554 ~198 ~33 ~554 minecraft:redstone_wire replace
setblock ~200 ~33 ~554 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~202 ~33 ~554 ~215 ~33 ~554 minecraft:redstone_wire replace
setblock ~217 ~33 ~554 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~219 ~33 ~554 ~221 ~33 ~554 minecraft:redstone_wire replace
setblock ~250 ~33 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~222 ~33 ~558 ~228 ~33 ~558 minecraft:redstone_wire replace
setblock ~230 ~33 ~558 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~33 ~558 ~245 ~33 ~558 minecraft:redstone_wire replace
setblock ~247 ~33 ~558 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~33 ~558 ~251 ~33 ~558 minecraft:redstone_wire replace
setblock ~295 ~33 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~33 ~562 ~258 ~33 ~562 minecraft:redstone_wire replace
setblock ~260 ~33 ~562 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~33 ~562 ~275 ~33 ~562 minecraft:redstone_wire replace
setblock ~277 ~33 ~562 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~33 ~562 ~292 ~33 ~562 minecraft:redstone_wire replace
setblock ~293 ~33 ~562 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~294 ~33 ~562 ~296 ~33 ~562 minecraft:redstone_wire replace
setblock ~313 ~33 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~33 ~566 ~276 ~33 ~566 minecraft:redstone_wire replace
setblock ~278 ~33 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~33 ~566 ~293 ~33 ~566 minecraft:redstone_wire replace
setblock ~295 ~33 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~33 ~566 ~310 ~33 ~566 minecraft:redstone_wire replace
setblock ~311 ~33 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~566 ~314 ~33 ~566 minecraft:redstone_wire replace
setblock ~373 ~33 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~306 ~33 ~570 ~312 ~33 ~570 minecraft:redstone_wire replace
setblock ~314 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~316 ~33 ~570 ~329 ~33 ~570 minecraft:redstone_wire replace
setblock ~331 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~333 ~33 ~570 ~346 ~33 ~570 minecraft:redstone_wire replace
setblock ~348 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~350 ~33 ~570 ~363 ~33 ~570 minecraft:redstone_wire replace
setblock ~365 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~367 ~33 ~570 ~374 ~33 ~570 minecraft:redstone_wire replace
setblock ~163 ~33 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~33 ~574 ~161 ~33 ~574 minecraft:redstone_wire replace
setblock ~162 ~33 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~163 ~33 ~574 ~164 ~33 ~574 minecraft:redstone_wire replace
setblock ~400 ~33 ~577 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~327 ~33 ~578 ~333 ~33 ~578 minecraft:redstone_wire replace
setblock ~335 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~33 ~578 ~350 ~33 ~578 minecraft:redstone_wire replace
setblock ~352 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~33 ~578 ~367 ~33 ~578 minecraft:redstone_wire replace
setblock ~369 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~371 ~33 ~578 ~384 ~33 ~578 minecraft:redstone_wire replace
setblock ~386 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~388 ~33 ~578 ~401 ~33 ~578 minecraft:redstone_wire replace
setblock ~97 ~33 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~33 ~582 ~98 ~33 ~582 minecraft:redstone_wire replace
setblock ~376 ~33 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~309 ~33 ~586 ~315 ~33 ~586 minecraft:redstone_wire replace
setblock ~317 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~319 ~33 ~586 ~332 ~33 ~586 minecraft:redstone_wire replace
setblock ~334 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~336 ~33 ~586 ~349 ~33 ~586 minecraft:redstone_wire replace
setblock ~351 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~353 ~33 ~586 ~366 ~33 ~586 minecraft:redstone_wire replace
setblock ~368 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~370 ~33 ~586 ~377 ~33 ~586 minecraft:redstone_wire replace
setblock ~397 ~33 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~33 ~590 ~330 ~33 ~590 minecraft:redstone_wire replace
setblock ~332 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~33 ~590 ~347 ~33 ~590 minecraft:redstone_wire replace
setblock ~349 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~33 ~590 ~364 ~33 ~590 minecraft:redstone_wire replace
setblock ~366 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~368 ~33 ~590 ~381 ~33 ~590 minecraft:redstone_wire replace
setblock ~383 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~385 ~33 ~590 ~398 ~33 ~590 minecraft:redstone_wire replace
setblock ~94 ~34 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~34 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~34 ~8 minecraft:redstone_wire replace
setblock ~178 ~34 ~8 minecraft:redstone_wire replace
setblock ~118 ~34 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~34 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~34 ~16 minecraft:redstone_wire replace
setblock ~211 ~34 ~16 minecraft:redstone_wire replace
setblock ~145 ~34 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~34 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~34 ~24 minecraft:redstone_wire replace
setblock ~253 ~34 ~24 minecraft:redstone_wire replace
setblock ~175 ~34 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~34 ~32 minecraft:redstone_wire replace
setblock ~259 ~34 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~34 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~34 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~34 ~40 minecraft:redstone_wire replace
setblock ~301 ~34 ~40 minecraft:redstone_wire replace
setblock ~229 ~34 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~34 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~34 ~48 minecraft:redstone_wire replace
setblock ~331 ~34 ~48 minecraft:redstone_wire replace
setblock ~265 ~34 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~34 ~56 minecraft:redstone_wire replace
setblock ~322 ~34 ~56 minecraft:redstone_wire replace
setblock ~340 ~34 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~34 ~60 minecraft:redstone_wire replace
setblock ~337 ~34 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~34 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~34 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~34 ~72 minecraft:redstone_wire replace
setblock ~352 ~34 ~72 minecraft:redstone_wire replace
setblock ~388 ~34 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~34 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~34 ~76 minecraft:redstone_wire replace
setblock ~379 ~34 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~34 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~34 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~34 ~256 minecraft:redstone_wire replace
setblock ~181 ~34 ~256 minecraft:redstone_wire replace
setblock ~157 ~34 ~264 minecraft:redstone_wire replace
setblock ~118 ~34 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~34 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~34 ~268 minecraft:redstone_wire replace
setblock ~214 ~34 ~268 minecraft:redstone_wire replace
setblock ~145 ~34 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~34 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~34 ~276 minecraft:redstone_wire replace
setblock ~256 ~34 ~276 minecraft:redstone_wire replace
setblock ~175 ~34 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~34 ~284 minecraft:redstone_wire replace
setblock ~259 ~34 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~34 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~34 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~34 ~292 minecraft:redstone_wire replace
setblock ~304 ~34 ~292 minecraft:redstone_wire replace
setblock ~229 ~34 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~34 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~34 ~300 minecraft:redstone_wire replace
setblock ~334 ~34 ~300 minecraft:redstone_wire replace
setblock ~265 ~34 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~34 ~308 minecraft:redstone_wire replace
setblock ~325 ~34 ~308 minecraft:redstone_wire replace
setblock ~340 ~34 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~34 ~316 minecraft:redstone_wire replace
setblock ~337 ~34 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~34 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~34 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~34 ~324 minecraft:redstone_wire replace
setblock ~349 ~34 ~324 minecraft:redstone_wire replace
setblock ~388 ~34 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~34 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~34 ~332 minecraft:redstone_wire replace
setblock ~379 ~34 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~34 ~340 minecraft:redstone_wire replace
setblock ~115 ~34 ~344 minecraft:redstone_wire replace
setblock ~139 ~34 ~348 minecraft:redstone_wire replace
setblock ~187 ~34 ~352 minecraft:redstone_wire replace
setblock ~217 ~34 ~356 minecraft:redstone_wire replace
setblock ~244 ~34 ~360 minecraft:redstone_wire replace
setblock ~280 ~34 ~364 minecraft:redstone_wire replace
setblock ~310 ~34 ~368 minecraft:redstone_wire replace
setblock ~346 ~34 ~372 minecraft:redstone_wire replace
setblock ~88 ~34 ~376 minecraft:redstone_wire replace
setblock ~112 ~34 ~380 minecraft:redstone_wire replace
setblock ~136 ~34 ~384 minecraft:redstone_wire replace
setblock ~184 ~34 ~388 minecraft:redstone_wire replace
setblock ~208 ~34 ~392 minecraft:redstone_wire replace
setblock ~238 ~34 ~396 minecraft:redstone_wire replace
setblock ~277 ~34 ~400 minecraft:redstone_wire replace
setblock ~307 ~34 ~404 minecraft:redstone_wire replace
setblock ~370 ~34 ~408 minecraft:redstone_wire replace
setblock ~394 ~34 ~412 minecraft:redstone_wire replace
setblock ~85 ~34 ~416 minecraft:redstone_wire replace
setblock ~109 ~34 ~420 minecraft:redstone_wire replace
setblock ~133 ~34 ~424 minecraft:redstone_wire replace
setblock ~166 ~34 ~428 minecraft:redstone_wire replace
setblock ~205 ~34 ~432 minecraft:redstone_wire replace
setblock ~235 ~34 ~436 minecraft:redstone_wire replace
setblock ~274 ~34 ~440 minecraft:redstone_wire replace
setblock ~298 ~34 ~444 minecraft:redstone_wire replace
setblock ~367 ~34 ~448 minecraft:redstone_wire replace
setblock ~391 ~34 ~452 minecraft:redstone_wire replace
setblock ~82 ~34 ~456 minecraft:redstone_wire replace
setblock ~106 ~34 ~460 minecraft:redstone_wire replace
setblock ~130 ~34 ~464 minecraft:redstone_wire replace
setblock ~160 ~34 ~468 minecraft:redstone_wire replace
setblock ~199 ~34 ~472 minecraft:redstone_wire replace
setblock ~232 ~34 ~476 minecraft:redstone_wire replace
setblock ~271 ~34 ~480 minecraft:redstone_wire replace
setblock ~292 ~34 ~484 minecraft:redstone_wire replace
setblock ~364 ~34 ~488 minecraft:redstone_wire replace
setblock ~385 ~34 ~492 minecraft:redstone_wire replace
setblock ~79 ~34 ~496 minecraft:redstone_wire replace
setblock ~103 ~34 ~500 minecraft:redstone_wire replace
setblock ~127 ~34 ~504 minecraft:redstone_wire replace
setblock ~154 ~34 ~508 minecraft:redstone_wire replace
setblock ~193 ~34 ~512 minecraft:redstone_wire replace
setblock ~223 ~34 ~516 minecraft:redstone_wire replace
setblock ~268 ~34 ~520 minecraft:redstone_wire replace
setblock ~289 ~34 ~524 minecraft:redstone_wire replace
setblock ~358 ~34 ~528 minecraft:redstone_wire replace
setblock ~382 ~34 ~532 minecraft:redstone_wire replace
setblock ~100 ~34 ~536 minecraft:redstone_wire replace
setblock ~124 ~34 ~540 minecraft:redstone_wire replace
setblock ~148 ~34 ~544 minecraft:redstone_wire replace
setblock ~190 ~34 ~548 minecraft:redstone_wire replace
setblock ~220 ~34 ~552 minecraft:redstone_wire replace
setblock ~250 ~34 ~556 minecraft:redstone_wire replace
setblock ~295 ~34 ~560 minecraft:redstone_wire replace
setblock ~313 ~34 ~564 minecraft:redstone_wire replace
setblock ~373 ~34 ~568 minecraft:redstone_wire replace
setblock ~163 ~34 ~572 minecraft:redstone_wire replace
setblock ~400 ~34 ~576 minecraft:redstone_wire replace
setblock ~97 ~34 ~580 minecraft:redstone_wire replace
setblock ~376 ~34 ~584 minecraft:redstone_wire replace
setblock ~397 ~34 ~588 minecraft:redstone_wire replace
fill ~93 ~35 ~8 ~93 ~35 ~20 minecraft:redstone_wire replace
fill ~120 ~35 ~8 ~120 ~35 ~20 minecraft:redstone_wire replace
fill ~150 ~35 ~8 ~150 ~35 ~20 minecraft:redstone_wire replace
fill ~177 ~35 ~8 ~177 ~35 ~12 minecraft:redstone_wire replace
fill ~117 ~35 ~16 ~117 ~35 ~28 minecraft:redstone_wire replace
fill ~141 ~35 ~16 ~141 ~35 ~28 minecraft:redstone_wire replace
fill ~171 ~35 ~16 ~171 ~35 ~28 minecraft:redstone_wire replace
fill ~210 ~35 ~16 ~210 ~35 ~20 minecraft:redstone_wire replace
setblock ~93 ~35 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~24 ~93 ~35 ~36 minecraft:redstone_wire replace
fill ~120 ~35 ~24 ~120 ~35 ~36 minecraft:redstone_wire replace
fill ~144 ~35 ~24 ~144 ~35 ~36 minecraft:redstone_wire replace
fill ~150 ~35 ~24 ~150 ~35 ~36 minecraft:redstone_wire replace
fill ~168 ~35 ~24 ~168 ~35 ~36 minecraft:redstone_wire replace
fill ~201 ~35 ~24 ~201 ~35 ~36 minecraft:redstone_wire replace
fill ~252 ~35 ~24 ~252 ~35 ~28 minecraft:redstone_wire replace
setblock ~117 ~35 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~32 ~117 ~35 ~44 minecraft:redstone_wire replace
fill ~141 ~35 ~32 ~141 ~35 ~44 minecraft:redstone_wire replace
fill ~171 ~35 ~32 ~171 ~35 ~44 minecraft:redstone_wire replace
fill ~174 ~35 ~32 ~174 ~35 ~44 minecraft:redstone_wire replace
