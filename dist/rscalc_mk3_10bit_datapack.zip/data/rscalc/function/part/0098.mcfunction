setblock ~118 ~153 ~533 minecraft:redstone_wire replace
setblock ~121 ~153 ~533 minecraft:redstone_wire replace
setblock ~124 ~153 ~533 minecraft:redstone_wire replace
setblock ~127 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~133 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~145 ~153 ~533 minecraft:redstone_wire replace
setblock ~148 ~153 ~533 minecraft:redstone_wire replace
setblock ~151 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~154 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~157 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~163 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~166 ~153 ~533 minecraft:redstone_wire replace
setblock ~169 ~153 ~533 minecraft:redstone_wire replace
setblock ~172 ~153 ~533 minecraft:redstone_wire replace
setblock ~175 ~153 ~533 minecraft:redstone_wire replace
setblock ~178 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~184 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~193 ~153 ~533 minecraft:redstone_wire replace
setblock ~196 ~153 ~533 minecraft:redstone_wire replace
setblock ~199 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~205 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~153 ~533 minecraft:redstone_wire replace
setblock ~214 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~533 minecraft:redstone_wire replace
setblock ~223 ~153 ~533 minecraft:redstone_wire replace
setblock ~226 ~153 ~533 minecraft:redstone_wire replace
setblock ~229 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~232 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~235 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~241 ~153 ~533 minecraft:redstone_wire replace
setblock ~244 ~153 ~533 minecraft:redstone_wire replace
setblock ~247 ~153 ~533 minecraft:redstone_wire replace
setblock ~250 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~153 ~534 ~115 ~153 ~534 minecraft:redstone_wire replace
setblock ~116 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~153 ~534 ~130 ~153 ~534 minecraft:redstone_wire replace
setblock ~131 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~153 ~534 ~145 ~153 ~534 minecraft:redstone_wire replace
setblock ~146 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~534 ~160 ~153 ~534 minecraft:redstone_wire replace
setblock ~161 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~153 ~534 ~175 ~153 ~534 minecraft:redstone_wire replace
setblock ~176 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~153 ~534 ~190 ~153 ~534 minecraft:redstone_wire replace
setblock ~191 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~153 ~534 ~205 ~153 ~534 minecraft:redstone_wire replace
setblock ~206 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~153 ~534 ~220 ~153 ~534 minecraft:redstone_wire replace
setblock ~221 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~153 ~534 ~235 ~153 ~534 minecraft:redstone_wire replace
setblock ~236 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~153 ~534 ~248 ~153 ~534 minecraft:redstone_wire replace
setblock ~249 ~153 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~153 ~534 ~254 ~153 ~534 minecraft:redstone_wire replace
setblock ~256 ~153 ~537 minecraft:redstone_wire replace
setblock ~259 ~153 ~537 minecraft:redstone_wire replace
setblock ~262 ~153 ~537 minecraft:redstone_wire replace
setblock ~265 ~153 ~537 minecraft:redstone_wire replace
setblock ~268 ~153 ~537 minecraft:redstone_wire replace
setblock ~271 ~153 ~537 minecraft:redstone_wire replace
setblock ~274 ~153 ~537 minecraft:redstone_wire replace
setblock ~277 ~153 ~537 minecraft:redstone_wire replace
setblock ~280 ~153 ~537 minecraft:redstone_wire replace
setblock ~283 ~153 ~537 minecraft:redstone_wire replace
setblock ~286 ~153 ~537 minecraft:redstone_wire replace
setblock ~289 ~153 ~537 minecraft:redstone_wire replace
setblock ~292 ~153 ~537 minecraft:redstone_wire replace
setblock ~295 ~153 ~537 minecraft:redstone_wire replace
setblock ~298 ~153 ~537 minecraft:redstone_wire replace
setblock ~301 ~153 ~537 minecraft:redstone_wire replace
setblock ~304 ~153 ~537 minecraft:redstone_wire replace
setblock ~307 ~153 ~537 minecraft:redstone_wire replace
setblock ~310 ~153 ~537 minecraft:redstone_wire replace
setblock ~313 ~153 ~537 minecraft:redstone_wire replace
setblock ~316 ~153 ~537 minecraft:redstone_wire replace
setblock ~319 ~153 ~537 minecraft:redstone_wire replace
setblock ~322 ~153 ~537 minecraft:redstone_wire replace
setblock ~325 ~153 ~537 minecraft:redstone_wire replace
setblock ~328 ~153 ~537 minecraft:redstone_wire replace
setblock ~331 ~153 ~537 minecraft:redstone_wire replace
setblock ~334 ~153 ~537 minecraft:redstone_wire replace
setblock ~337 ~153 ~537 minecraft:redstone_wire replace
setblock ~340 ~153 ~537 minecraft:redstone_wire replace
setblock ~343 ~153 ~537 minecraft:redstone_wire replace
setblock ~346 ~153 ~537 minecraft:redstone_wire replace
setblock ~349 ~153 ~537 minecraft:redstone_wire replace
setblock ~352 ~153 ~537 minecraft:redstone_wire replace
setblock ~355 ~153 ~537 minecraft:redstone_wire replace
setblock ~358 ~153 ~537 minecraft:redstone_wire replace
setblock ~361 ~153 ~537 minecraft:redstone_wire replace
setblock ~364 ~153 ~537 minecraft:redstone_wire replace
setblock ~367 ~153 ~537 minecraft:redstone_wire replace
setblock ~370 ~153 ~537 minecraft:redstone_wire replace
setblock ~373 ~153 ~537 minecraft:redstone_wire replace
setblock ~376 ~153 ~537 minecraft:redstone_wire replace
setblock ~379 ~153 ~537 minecraft:redstone_wire replace
setblock ~382 ~153 ~537 minecraft:redstone_wire replace
setblock ~385 ~153 ~537 minecraft:redstone_wire replace
setblock ~388 ~153 ~537 minecraft:redstone_wire replace
setblock ~391 ~153 ~537 minecraft:redstone_wire replace
setblock ~394 ~153 ~537 minecraft:redstone_wire replace
setblock ~397 ~153 ~537 minecraft:redstone_wire replace
setblock ~400 ~153 ~537 minecraft:redstone_wire replace
fill ~255 ~153 ~538 ~266 ~153 ~538 minecraft:redstone_wire replace
setblock ~267 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~153 ~538 ~280 ~153 ~538 minecraft:redstone_wire replace
setblock ~281 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~153 ~538 ~295 ~153 ~538 minecraft:redstone_wire replace
setblock ~296 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~153 ~538 ~310 ~153 ~538 minecraft:redstone_wire replace
setblock ~311 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~153 ~538 ~325 ~153 ~538 minecraft:redstone_wire replace
setblock ~326 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~153 ~538 ~340 ~153 ~538 minecraft:redstone_wire replace
setblock ~341 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~153 ~538 ~355 ~153 ~538 minecraft:redstone_wire replace
setblock ~356 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~357 ~153 ~538 ~370 ~153 ~538 minecraft:redstone_wire replace
setblock ~371 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~372 ~153 ~538 ~385 ~153 ~538 minecraft:redstone_wire replace
setblock ~386 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~387 ~153 ~538 ~400 ~153 ~538 minecraft:redstone_wire replace
setblock ~401 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~256 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~153 ~541 minecraft:redstone_wire replace
setblock ~265 ~153 ~541 minecraft:redstone_wire replace
setblock ~268 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~271 ~153 ~541 minecraft:redstone_wire replace
setblock ~274 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~153 ~541 minecraft:redstone_wire replace
setblock ~280 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~541 minecraft:redstone_wire replace
setblock ~286 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~289 ~153 ~541 minecraft:redstone_wire replace
setblock ~292 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~153 ~541 minecraft:redstone_wire replace
setblock ~298 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~153 ~541 minecraft:redstone_wire replace
setblock ~304 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~541 minecraft:redstone_wire replace
setblock ~310 ~153 ~541 minecraft:redstone_wire replace
setblock ~313 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~153 ~541 minecraft:redstone_wire replace
setblock ~319 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~153 ~541 minecraft:redstone_wire replace
setblock ~325 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~328 ~153 ~541 minecraft:redstone_wire replace
setblock ~331 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~153 ~541 minecraft:redstone_wire replace
setblock ~340 ~153 ~541 minecraft:redstone_wire replace
setblock ~343 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~346 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~153 ~541 minecraft:redstone_wire replace
setblock ~352 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~358 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~361 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~364 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~370 ~153 ~541 minecraft:redstone_wire replace
setblock ~373 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~376 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~153 ~541 minecraft:redstone_wire replace
setblock ~382 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~385 ~153 ~541 minecraft:redstone_wire replace
setblock ~388 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~391 ~153 ~541 minecraft:redstone_wire replace
setblock ~394 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~397 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~400 ~153 ~541 minecraft:redstone_wire replace
fill ~249 ~153 ~542 ~254 ~153 ~542 minecraft:redstone_wire replace
setblock ~255 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~256 ~153 ~542 ~268 ~153 ~542 minecraft:redstone_wire replace
setblock ~269 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~153 ~542 ~283 ~153 ~542 minecraft:redstone_wire replace
setblock ~284 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~153 ~542 ~298 ~153 ~542 minecraft:redstone_wire replace
setblock ~299 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~153 ~542 ~313 ~153 ~542 minecraft:redstone_wire replace
setblock ~314 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~153 ~542 ~328 ~153 ~542 minecraft:redstone_wire replace
setblock ~329 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~153 ~542 ~343 ~153 ~542 minecraft:redstone_wire replace
setblock ~344 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~345 ~153 ~542 ~358 ~153 ~542 minecraft:redstone_wire replace
setblock ~359 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~360 ~153 ~542 ~373 ~153 ~542 minecraft:redstone_wire replace
setblock ~374 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~375 ~153 ~542 ~388 ~153 ~542 minecraft:redstone_wire replace
setblock ~389 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~390 ~153 ~542 ~401 ~153 ~542 minecraft:redstone_wire replace
setblock ~256 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~265 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~268 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~271 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~274 ~153 ~565 minecraft:redstone_wire replace
setblock ~277 ~153 ~565 minecraft:redstone_wire replace
setblock ~280 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~289 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~298 ~153 ~565 minecraft:redstone_wire replace
setblock ~301 ~153 ~565 minecraft:redstone_wire replace
setblock ~304 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~310 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~319 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~325 ~153 ~565 minecraft:redstone_wire replace
setblock ~328 ~153 ~565 minecraft:redstone_wire replace
setblock ~331 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~343 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~346 ~153 ~565 minecraft:redstone_wire replace
setblock ~349 ~153 ~565 minecraft:redstone_wire replace
setblock ~352 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~358 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~361 ~153 ~565 minecraft:redstone_wire replace
setblock ~364 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~370 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~373 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~376 ~153 ~565 minecraft:redstone_wire replace
setblock ~379 ~153 ~565 minecraft:redstone_wire replace
setblock ~382 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~385 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~391 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~394 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~397 ~153 ~565 minecraft:redstone_wire replace
setblock ~400 ~153 ~565 minecraft:redstone_wire replace
fill ~255 ~153 ~566 ~263 ~153 ~566 minecraft:redstone_wire replace
setblock ~264 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~153 ~566 ~277 ~153 ~566 minecraft:redstone_wire replace
setblock ~278 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~153 ~566 ~292 ~153 ~566 minecraft:redstone_wire replace
setblock ~293 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~294 ~153 ~566 ~307 ~153 ~566 minecraft:redstone_wire replace
setblock ~308 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~153 ~566 ~322 ~153 ~566 minecraft:redstone_wire replace
setblock ~323 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~324 ~153 ~566 ~337 ~153 ~566 minecraft:redstone_wire replace
setblock ~338 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~339 ~153 ~566 ~352 ~153 ~566 minecraft:redstone_wire replace
setblock ~353 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~153 ~566 ~367 ~153 ~566 minecraft:redstone_wire replace
setblock ~368 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~369 ~153 ~566 ~382 ~153 ~566 minecraft:redstone_wire replace
setblock ~383 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~384 ~153 ~566 ~397 ~153 ~566 minecraft:redstone_wire replace
setblock ~398 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~399 ~153 ~566 ~401 ~153 ~566 minecraft:redstone_wire replace
setblock ~256 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~573 minecraft:redstone_wire replace
setblock ~262 ~153 ~573 minecraft:redstone_wire replace
setblock ~265 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~268 ~153 ~573 minecraft:redstone_wire replace
setblock ~271 ~153 ~573 minecraft:redstone_wire replace
setblock ~274 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~280 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~153 ~573 minecraft:redstone_wire replace
setblock ~289 ~153 ~573 minecraft:redstone_wire replace
setblock ~292 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~153 ~573 minecraft:redstone_wire replace
setblock ~298 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~310 ~153 ~573 minecraft:redstone_wire replace
setblock ~313 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~319 ~153 ~573 minecraft:redstone_wire replace
setblock ~322 ~153 ~573 minecraft:redstone_wire replace
setblock ~325 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~328 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~573 minecraft:redstone_wire replace
setblock ~337 ~153 ~573 minecraft:redstone_wire replace
setblock ~340 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~343 ~153 ~573 minecraft:redstone_wire replace
setblock ~346 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~573 minecraft:redstone_wire replace
setblock ~358 ~153 ~573 minecraft:redstone_wire replace
setblock ~361 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~364 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~370 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~373 ~153 ~573 minecraft:redstone_wire replace
setblock ~376 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~382 ~153 ~573 minecraft:redstone_wire replace
setblock ~385 ~153 ~573 minecraft:redstone_wire replace
setblock ~388 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~391 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~394 ~153 ~573 minecraft:redstone_wire replace
setblock ~397 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~400 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~153 ~574 ~257 ~153 ~574 minecraft:redstone_wire replace
setblock ~258 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~153 ~574 ~271 ~153 ~574 minecraft:redstone_wire replace
setblock ~272 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~153 ~574 ~286 ~153 ~574 minecraft:redstone_wire replace
setblock ~287 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~153 ~574 ~301 ~153 ~574 minecraft:redstone_wire replace
setblock ~302 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~153 ~574 ~316 ~153 ~574 minecraft:redstone_wire replace
setblock ~317 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~153 ~574 ~331 ~153 ~574 minecraft:redstone_wire replace
setblock ~332 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~333 ~153 ~574 ~346 ~153 ~574 minecraft:redstone_wire replace
setblock ~347 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~153 ~574 ~361 ~153 ~574 minecraft:redstone_wire replace
setblock ~362 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~363 ~153 ~574 ~376 ~153 ~574 minecraft:redstone_wire replace
setblock ~377 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~378 ~153 ~574 ~391 ~153 ~574 minecraft:redstone_wire replace
setblock ~392 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~393 ~153 ~574 ~401 ~153 ~574 minecraft:redstone_wire replace
setblock ~403 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~406 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~409 ~153 ~597 minecraft:redstone_wire replace
setblock ~412 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~415 ~153 ~597 minecraft:redstone_wire replace
setblock ~418 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~421 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~424 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~153 ~598 ~279 ~153 ~598 minecraft:redstone_wire replace
setblock ~281 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~153 ~598 ~296 ~153 ~598 minecraft:redstone_wire replace
setblock ~298 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~153 ~598 ~313 ~153 ~598 minecraft:redstone_wire replace
setblock ~315 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~153 ~598 ~330 ~153 ~598 minecraft:redstone_wire replace
setblock ~332 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~153 ~598 ~347 ~153 ~598 minecraft:redstone_wire replace
setblock ~349 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~153 ~598 ~364 ~153 ~598 minecraft:redstone_wire replace
setblock ~366 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~368 ~153 ~598 ~381 ~153 ~598 minecraft:redstone_wire replace
setblock ~383 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~385 ~153 ~598 ~398 ~153 ~598 minecraft:redstone_wire replace
setblock ~400 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~402 ~153 ~598 ~415 ~153 ~598 minecraft:redstone_wire replace
setblock ~416 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~417 ~153 ~598 ~425 ~153 ~598 minecraft:redstone_wire replace
setblock ~403 ~153 ~601 minecraft:redstone_wire replace
setblock ~406 ~153 ~601 minecraft:redstone_wire replace
setblock ~409 ~153 ~601 minecraft:redstone_wire replace
setblock ~412 ~153 ~601 minecraft:redstone_wire replace
setblock ~415 ~153 ~601 minecraft:redstone_wire replace
setblock ~418 ~153 ~601 minecraft:redstone_wire replace
setblock ~421 ~153 ~601 minecraft:redstone_wire replace
setblock ~424 ~153 ~601 minecraft:redstone_wire replace
fill ~264 ~153 ~602 ~270 ~153 ~602 minecraft:redstone_wire replace
setblock ~272 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~274 ~153 ~602 ~287 ~153 ~602 minecraft:redstone_wire replace
setblock ~289 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~153 ~602 ~304 ~153 ~602 minecraft:redstone_wire replace
setblock ~306 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~308 ~153 ~602 ~321 ~153 ~602 minecraft:redstone_wire replace
setblock ~323 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~325 ~153 ~602 ~338 ~153 ~602 minecraft:redstone_wire replace
setblock ~340 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~153 ~602 ~355 ~153 ~602 minecraft:redstone_wire replace
setblock ~357 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~359 ~153 ~602 ~372 ~153 ~602 minecraft:redstone_wire replace
setblock ~374 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~376 ~153 ~602 ~389 ~153 ~602 minecraft:redstone_wire replace
setblock ~391 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~393 ~153 ~602 ~406 ~153 ~602 minecraft:redstone_wire replace
setblock ~407 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~408 ~153 ~602 ~421 ~153 ~602 minecraft:redstone_wire replace
setblock ~422 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~423 ~153 ~602 ~425 ~153 ~602 minecraft:redstone_wire replace
setblock ~256 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~265 ~153 ~605 minecraft:redstone_wire replace
setblock ~268 ~153 ~605 minecraft:redstone_wire replace
setblock ~271 ~153 ~605 minecraft:redstone_wire replace
setblock ~274 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~280 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~289 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~153 ~605 minecraft:redstone_wire replace
setblock ~295 ~153 ~605 minecraft:redstone_wire replace
setblock ~298 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~310 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~153 ~605 minecraft:redstone_wire replace
setblock ~316 ~153 ~605 minecraft:redstone_wire replace
setblock ~319 ~153 ~605 minecraft:redstone_wire replace
setblock ~322 ~153 ~605 minecraft:redstone_wire replace
setblock ~325 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~328 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~153 ~605 minecraft:redstone_wire replace
setblock ~343 ~153 ~605 minecraft:redstone_wire replace
setblock ~346 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~358 ~153 ~605 minecraft:redstone_wire replace
setblock ~361 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~364 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~605 minecraft:redstone_wire replace
setblock ~370 ~153 ~605 minecraft:redstone_wire replace
setblock ~373 ~153 ~605 minecraft:redstone_wire replace
setblock ~376 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~382 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~385 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~153 ~605 minecraft:redstone_wire replace
setblock ~391 ~153 ~605 minecraft:redstone_wire replace
setblock ~394 ~153 ~605 minecraft:redstone_wire replace
setblock ~397 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~400 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~255 ~153 ~606 ~266 ~153 ~606 minecraft:redstone_wire replace
setblock ~267 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~153 ~606 ~280 ~153 ~606 minecraft:redstone_wire replace
setblock ~281 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~153 ~606 ~295 ~153 ~606 minecraft:redstone_wire replace
setblock ~296 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~153 ~606 ~310 ~153 ~606 minecraft:redstone_wire replace
setblock ~311 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~153 ~606 ~325 ~153 ~606 minecraft:redstone_wire replace
setblock ~326 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~153 ~606 ~340 ~153 ~606 minecraft:redstone_wire replace
setblock ~341 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~153 ~606 ~355 ~153 ~606 minecraft:redstone_wire replace
setblock ~356 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~357 ~153 ~606 ~370 ~153 ~606 minecraft:redstone_wire replace
setblock ~371 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~372 ~153 ~606 ~385 ~153 ~606 minecraft:redstone_wire replace
setblock ~386 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~387 ~153 ~606 ~400 ~153 ~606 minecraft:redstone_wire replace
setblock ~401 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~433 ~153 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~153 ~642 ~282 ~153 ~642 minecraft:redstone_wire replace
setblock ~284 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~153 ~642 ~299 ~153 ~642 minecraft:redstone_wire replace
setblock ~301 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~153 ~642 ~316 ~153 ~642 minecraft:redstone_wire replace
setblock ~318 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~320 ~153 ~642 ~333 ~153 ~642 minecraft:redstone_wire replace
setblock ~335 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~153 ~642 ~350 ~153 ~642 minecraft:redstone_wire replace
setblock ~352 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~153 ~642 ~367 ~153 ~642 minecraft:redstone_wire replace
setblock ~369 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~371 ~153 ~642 ~384 ~153 ~642 minecraft:redstone_wire replace
setblock ~386 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~388 ~153 ~642 ~401 ~153 ~642 minecraft:redstone_wire replace
setblock ~403 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~405 ~153 ~642 ~418 ~153 ~642 minecraft:redstone_wire replace
setblock ~420 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~422 ~153 ~642 ~434 ~153 ~642 minecraft:redstone_wire replace
setblock ~427 ~153 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~153 ~650 ~276 ~153 ~650 minecraft:redstone_wire replace
setblock ~278 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~153 ~650 ~293 ~153 ~650 minecraft:redstone_wire replace
setblock ~295 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~153 ~650 ~310 ~153 ~650 minecraft:redstone_wire replace
setblock ~312 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~153 ~650 ~327 ~153 ~650 minecraft:redstone_wire replace
setblock ~329 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~153 ~650 ~344 ~153 ~650 minecraft:redstone_wire replace
setblock ~346 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~153 ~650 ~361 ~153 ~650 minecraft:redstone_wire replace
setblock ~363 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~365 ~153 ~650 ~378 ~153 ~650 minecraft:redstone_wire replace
setblock ~380 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~382 ~153 ~650 ~395 ~153 ~650 minecraft:redstone_wire replace
setblock ~397 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~399 ~153 ~650 ~412 ~153 ~650 minecraft:redstone_wire replace
setblock ~414 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~416 ~153 ~650 ~428 ~153 ~650 minecraft:redstone_wire replace
setblock ~430 ~153 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~153 ~658 ~279 ~153 ~658 minecraft:redstone_wire replace
setblock ~281 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~153 ~658 ~296 ~153 ~658 minecraft:redstone_wire replace
setblock ~298 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~153 ~658 ~313 ~153 ~658 minecraft:redstone_wire replace
setblock ~315 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~153 ~658 ~330 ~153 ~658 minecraft:redstone_wire replace
setblock ~332 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~153 ~658 ~347 ~153 ~658 minecraft:redstone_wire replace
setblock ~349 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~153 ~658 ~364 ~153 ~658 minecraft:redstone_wire replace
setblock ~366 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~368 ~153 ~658 ~381 ~153 ~658 minecraft:redstone_wire replace
setblock ~383 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~385 ~153 ~658 ~398 ~153 ~658 minecraft:redstone_wire replace
setblock ~400 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~402 ~153 ~658 ~415 ~153 ~658 minecraft:redstone_wire replace
setblock ~417 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~419 ~153 ~658 ~431 ~153 ~658 minecraft:redstone_wire replace
setblock ~106 ~154 ~228 minecraft:redstone_wire replace
setblock ~82 ~154 ~232 minecraft:redstone_wire replace
setblock ~103 ~154 ~236 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~240 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~348 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~384 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~400 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~404 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~416 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~420 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~424 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~428 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~154 ~444 minecraft:redstone_wire replace
setblock ~109 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~154 ~472 minecraft:redstone_torch[lit=true] replace
