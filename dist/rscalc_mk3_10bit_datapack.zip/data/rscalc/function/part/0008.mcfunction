setblock ~168 ~59 ~293 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~295 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~295 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~295 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~305 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~305 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~307 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~307 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~309 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~309 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~309 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~311 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~311 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~311 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~316 minecraft:light_gray_concrete replace
setblock ~100 ~59 ~320 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~321 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~321 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~323 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~323 minecraft:light_gray_concrete replace
setblock ~100 ~59 ~324 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~325 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~325 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~325 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~327 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~327 minecraft:light_gray_concrete replace
setblock ~99 ~59 ~327 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~327 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~329 minecraft:light_gray_concrete replace
setblock ~99 ~59 ~329 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~331 minecraft:light_gray_concrete replace
setblock ~118 ~59 ~336 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~337 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~337 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~339 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~339 minecraft:light_gray_concrete replace
setblock ~118 ~59 ~340 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~341 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~341 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~341 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~343 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~343 minecraft:light_gray_concrete replace
setblock ~117 ~59 ~343 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~343 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~345 minecraft:light_gray_concrete replace
setblock ~117 ~59 ~345 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~347 minecraft:light_gray_concrete replace
setblock ~163 ~59 ~352 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~353 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~353 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~355 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~355 minecraft:light_gray_concrete replace
setblock ~163 ~59 ~356 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~357 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~357 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~357 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~359 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~359 minecraft:light_gray_concrete replace
setblock ~162 ~59 ~359 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~359 minecraft:light_gray_concrete replace
setblock ~199 ~59 ~360 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~361 minecraft:light_gray_concrete replace
setblock ~162 ~59 ~361 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~363 minecraft:light_gray_concrete replace
setblock ~169 ~59 ~364 minecraft:light_gray_concrete replace
setblock ~139 ~59 ~368 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~369 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~369 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~371 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~371 minecraft:light_gray_concrete replace
setblock ~139 ~59 ~372 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~373 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~373 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~373 minecraft:light_gray_concrete replace
setblock ~198 ~59 ~373 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~375 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~375 minecraft:light_gray_concrete replace
setblock ~138 ~59 ~375 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~375 minecraft:light_gray_concrete replace
setblock ~198 ~59 ~375 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~377 minecraft:light_gray_concrete replace
setblock ~138 ~59 ~377 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~379 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~385 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~385 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~387 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~387 minecraft:light_gray_concrete replace
setblock ~199 ~59 ~388 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~389 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~389 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~389 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~391 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~391 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~391 minecraft:light_gray_concrete replace
setblock ~169 ~59 ~392 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~393 minecraft:light_gray_concrete replace
setblock ~198 ~59 ~393 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~395 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~397 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~401 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~401 minecraft:light_gray_concrete replace
setblock ~189 ~59 ~401 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~403 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~403 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~405 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~405 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~407 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~407 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~408 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~409 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~411 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~412 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~416 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~417 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~417 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~419 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~419 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~420 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~421 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~421 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~423 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~423 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~424 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~433 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~433 minecraft:light_gray_concrete replace
setblock ~111 ~59 ~433 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~435 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~435 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~437 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~437 minecraft:light_gray_concrete replace
setblock ~135 ~59 ~437 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~439 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~439 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~439 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~441 minecraft:light_gray_concrete replace
setblock ~156 ~59 ~441 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~444 minecraft:light_gray_concrete replace
setblock ~165 ~59 ~445 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~448 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~449 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~449 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~451 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~451 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~452 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~453 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~455 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~455 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~456 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~457 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~460 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~465 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~465 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~467 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~467 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~467 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~469 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~469 minecraft:light_gray_concrete replace
setblock ~108 ~59 ~469 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~471 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~471 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~473 minecraft:light_gray_concrete replace
setblock ~129 ~59 ~473 minecraft:light_gray_concrete replace
setblock ~153 ~59 ~477 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~481 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~481 minecraft:light_gray_concrete replace
setblock ~180 ~59 ~481 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~483 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~483 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~484 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~485 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~485 minecraft:light_gray_concrete replace
setblock ~204 ~59 ~485 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~487 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~487 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~488 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~489 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~492 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~496 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~497 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~499 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~499 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~500 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~501 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~501 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~503 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~503 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~505 minecraft:light_gray_concrete replace
setblock ~105 ~59 ~509 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~511 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~513 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~513 minecraft:light_gray_concrete replace
setblock ~126 ~59 ~513 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~515 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~515 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~517 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~517 minecraft:light_gray_concrete replace
setblock ~150 ~59 ~517 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~519 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~519 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~521 minecraft:light_gray_concrete replace
setblock ~177 ~59 ~521 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~524 minecraft:light_gray_concrete replace
setblock ~201 ~59 ~525 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~527 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~528 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~529 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~529 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~531 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~532 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~533 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~535 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~535 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~536 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~537 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~540 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~543 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~545 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~545 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~545 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~547 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~547 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~549 minecraft:light_gray_concrete replace
setblock ~102 ~59 ~549 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~551 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~551 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~553 minecraft:light_gray_concrete replace
setblock ~123 ~59 ~553 minecraft:light_gray_concrete replace
setblock ~144 ~59 ~557 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~559 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~174 ~59 ~561 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~563 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~563 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~564 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~565 minecraft:light_gray_concrete replace
setblock ~195 ~59 ~565 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~567 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~567 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~568 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~569 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~572 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~576 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~577 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~577 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~579 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~579 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~580 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~581 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~583 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~583 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~585 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~589 minecraft:light_gray_concrete replace
setblock ~96 ~59 ~589 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~591 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~593 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~593 minecraft:light_gray_concrete replace
setblock ~120 ~59 ~593 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~595 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~595 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~597 minecraft:light_gray_concrete replace
setblock ~141 ~59 ~597 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~599 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~599 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~601 minecraft:light_gray_concrete replace
setblock ~171 ~59 ~601 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~604 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~605 minecraft:light_gray_concrete replace
setblock ~192 ~59 ~605 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~607 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~607 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~608 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~609 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~609 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~611 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~612 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~613 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~615 minecraft:light_gray_concrete replace
setblock ~91 ~59 ~616 minecraft:light_gray_concrete replace
setblock ~87 ~59 ~617 minecraft:light_gray_concrete replace
setblock ~90 ~59 ~621 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~625 minecraft:light_gray_concrete replace
setblock ~93 ~59 ~625 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~627 minecraft:light_gray_concrete replace
setblock ~114 ~59 ~629 minecraft:light_gray_concrete replace
setblock ~147 ~59 ~633 minecraft:light_gray_concrete replace
setblock ~159 ~59 ~637 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~641 minecraft:light_gray_concrete replace
setblock ~183 ~59 ~641 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~643 minecraft:light_gray_concrete replace
setblock ~132 ~59 ~645 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~648 minecraft:light_gray_concrete replace
setblock ~210 ~59 ~649 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~651 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~653 minecraft:light_gray_concrete replace
setblock ~186 ~59 ~657 minecraft:light_gray_concrete replace
setblock ~207 ~59 ~661 minecraft:light_gray_concrete replace
fill ~99 ~60 ~330 ~104 ~60 ~330 minecraft:light_gray_concrete replace
fill ~103 ~60 ~331 ~103 ~60 ~332 minecraft:light_gray_concrete replace
fill ~117 ~60 ~346 ~122 ~60 ~346 minecraft:light_gray_concrete replace
fill ~121 ~60 ~347 ~121 ~60 ~348 minecraft:light_gray_concrete replace
fill ~162 ~60 ~362 ~164 ~60 ~362 minecraft:light_gray_concrete replace
fill ~163 ~60 ~363 ~163 ~60 ~364 minecraft:light_gray_concrete replace
fill ~138 ~60 ~378 ~140 ~60 ~378 minecraft:light_gray_concrete replace
fill ~139 ~60 ~379 ~139 ~60 ~380 minecraft:light_gray_concrete replace
fill ~186 ~60 ~394 ~212 ~60 ~394 minecraft:light_gray_concrete replace
fill ~187 ~60 ~395 ~187 ~60 ~396 minecraft:light_gray_concrete replace
fill ~190 ~60 ~395 ~190 ~60 ~396 minecraft:light_gray_concrete replace
fill ~208 ~60 ~395 ~208 ~60 ~396 minecraft:light_gray_concrete replace
fill ~211 ~60 ~395 ~211 ~60 ~396 minecraft:light_gray_concrete replace
fill ~81 ~60 ~398 ~212 ~60 ~398 minecraft:light_gray_concrete replace
fill ~82 ~60 ~399 ~82 ~60 ~400 minecraft:light_gray_concrete replace
fill ~208 ~60 ~399 ~208 ~60 ~400 minecraft:light_gray_concrete replace
fill ~211 ~60 ~399 ~211 ~60 ~400 minecraft:light_gray_concrete replace
fill ~186 ~60 ~402 ~191 ~60 ~402 minecraft:light_gray_concrete replace
fill ~187 ~60 ~403 ~187 ~60 ~404 minecraft:light_gray_concrete replace
fill ~190 ~60 ~403 ~190 ~60 ~404 minecraft:light_gray_concrete replace
fill ~111 ~60 ~434 ~116 ~60 ~434 minecraft:light_gray_concrete replace
fill ~115 ~60 ~435 ~115 ~60 ~436 minecraft:light_gray_concrete replace
fill ~135 ~60 ~438 ~137 ~60 ~438 minecraft:light_gray_concrete replace
fill ~136 ~60 ~439 ~136 ~60 ~440 minecraft:light_gray_concrete replace
fill ~156 ~60 ~442 ~158 ~60 ~442 minecraft:light_gray_concrete replace
fill ~157 ~60 ~443 ~157 ~60 ~444 minecraft:light_gray_concrete replace
fill ~165 ~60 ~446 ~167 ~60 ~446 minecraft:light_gray_concrete replace
fill ~166 ~60 ~447 ~166 ~60 ~448 minecraft:light_gray_concrete replace
fill ~108 ~60 ~470 ~113 ~60 ~470 minecraft:light_gray_concrete replace
fill ~112 ~60 ~471 ~112 ~60 ~472 minecraft:light_gray_concrete replace
fill ~129 ~60 ~474 ~134 ~60 ~474 minecraft:light_gray_concrete replace
fill ~133 ~60 ~475 ~133 ~60 ~476 minecraft:light_gray_concrete replace
fill ~153 ~60 ~478 ~155 ~60 ~478 minecraft:light_gray_concrete replace
fill ~154 ~60 ~479 ~154 ~60 ~480 minecraft:light_gray_concrete replace
fill ~177 ~60 ~482 ~180 ~60 ~482 minecraft:light_gray_concrete replace
fill ~178 ~60 ~483 ~178 ~60 ~484 minecraft:light_gray_concrete replace
fill ~204 ~60 ~486 ~206 ~60 ~486 minecraft:light_gray_concrete replace
fill ~205 ~60 ~487 ~205 ~60 ~488 minecraft:light_gray_concrete replace
fill ~105 ~60 ~510 ~110 ~60 ~510 minecraft:light_gray_concrete replace
fill ~109 ~60 ~511 ~109 ~60 ~512 minecraft:light_gray_concrete replace
fill ~126 ~60 ~514 ~131 ~60 ~514 minecraft:light_gray_concrete replace
fill ~130 ~60 ~515 ~130 ~60 ~516 minecraft:light_gray_concrete replace
fill ~150 ~60 ~518 ~152 ~60 ~518 minecraft:light_gray_concrete replace
fill ~151 ~60 ~519 ~151 ~60 ~520 minecraft:light_gray_concrete replace
fill ~174 ~60 ~522 ~177 ~60 ~522 minecraft:light_gray_concrete replace
fill ~175 ~60 ~523 ~175 ~60 ~524 minecraft:light_gray_concrete replace
fill ~201 ~60 ~526 ~203 ~60 ~526 minecraft:light_gray_concrete replace
fill ~202 ~60 ~527 ~202 ~60 ~528 minecraft:light_gray_concrete replace
fill ~102 ~60 ~550 ~107 ~60 ~550 minecraft:light_gray_concrete replace
fill ~106 ~60 ~551 ~106 ~60 ~552 minecraft:light_gray_concrete replace
fill ~123 ~60 ~554 ~128 ~60 ~554 minecraft:light_gray_concrete replace
fill ~127 ~60 ~555 ~127 ~60 ~556 minecraft:light_gray_concrete replace
fill ~144 ~60 ~558 ~146 ~60 ~558 minecraft:light_gray_concrete replace
fill ~145 ~60 ~559 ~145 ~60 ~560 minecraft:light_gray_concrete replace
fill ~171 ~60 ~562 ~174 ~60 ~562 minecraft:light_gray_concrete replace
fill ~172 ~60 ~563 ~172 ~60 ~564 minecraft:light_gray_concrete replace
fill ~195 ~60 ~566 ~197 ~60 ~566 minecraft:light_gray_concrete replace
fill ~196 ~60 ~567 ~196 ~60 ~568 minecraft:light_gray_concrete replace
fill ~96 ~60 ~590 ~101 ~60 ~590 minecraft:light_gray_concrete replace
fill ~100 ~60 ~591 ~100 ~60 ~592 minecraft:light_gray_concrete replace
fill ~120 ~60 ~594 ~125 ~60 ~594 minecraft:light_gray_concrete replace
fill ~124 ~60 ~595 ~124 ~60 ~596 minecraft:light_gray_concrete replace
fill ~141 ~60 ~598 ~143 ~60 ~598 minecraft:light_gray_concrete replace
fill ~142 ~60 ~599 ~142 ~60 ~600 minecraft:light_gray_concrete replace
fill ~168 ~60 ~602 ~171 ~60 ~602 minecraft:light_gray_concrete replace
fill ~169 ~60 ~603 ~169 ~60 ~604 minecraft:light_gray_concrete replace
fill ~192 ~60 ~606 ~194 ~60 ~606 minecraft:light_gray_concrete replace
fill ~193 ~60 ~607 ~193 ~60 ~608 minecraft:light_gray_concrete replace
fill ~81 ~60 ~610 ~86 ~60 ~610 minecraft:light_gray_concrete replace
fill ~85 ~60 ~611 ~85 ~60 ~612 minecraft:light_gray_concrete replace
fill ~84 ~60 ~614 ~89 ~60 ~614 minecraft:light_gray_concrete replace
fill ~88 ~60 ~615 ~88 ~60 ~616 minecraft:light_gray_concrete replace
fill ~87 ~60 ~618 ~92 ~60 ~618 minecraft:light_gray_concrete replace
fill ~91 ~60 ~619 ~91 ~60 ~620 minecraft:light_gray_concrete replace
fill ~90 ~60 ~622 ~95 ~60 ~622 minecraft:light_gray_concrete replace
fill ~94 ~60 ~623 ~94 ~60 ~624 minecraft:light_gray_concrete replace
fill ~93 ~60 ~626 ~98 ~60 ~626 minecraft:light_gray_concrete replace
fill ~97 ~60 ~627 ~97 ~60 ~628 minecraft:light_gray_concrete replace
fill ~114 ~60 ~630 ~119 ~60 ~630 minecraft:light_gray_concrete replace
fill ~118 ~60 ~631 ~118 ~60 ~632 minecraft:light_gray_concrete replace
fill ~147 ~60 ~634 ~149 ~60 ~634 minecraft:light_gray_concrete replace
fill ~148 ~60 ~635 ~148 ~60 ~636 minecraft:light_gray_concrete replace
fill ~159 ~60 ~638 ~161 ~60 ~638 minecraft:light_gray_concrete replace
fill ~160 ~60 ~639 ~160 ~60 ~640 minecraft:light_gray_concrete replace
fill ~180 ~60 ~642 ~183 ~60 ~642 minecraft:light_gray_concrete replace
fill ~181 ~60 ~643 ~181 ~60 ~644 minecraft:light_gray_concrete replace
fill ~81 ~60 ~646 ~200 ~60 ~646 minecraft:light_gray_concrete replace
fill ~82 ~60 ~647 ~82 ~60 ~648 minecraft:light_gray_concrete replace
fill ~103 ~60 ~647 ~103 ~60 ~648 minecraft:light_gray_concrete replace
fill ~121 ~60 ~647 ~121 ~60 ~648 minecraft:light_gray_concrete replace
fill ~139 ~60 ~647 ~139 ~60 ~648 minecraft:light_gray_concrete replace
fill ~163 ~60 ~647 ~163 ~60 ~648 minecraft:light_gray_concrete replace
fill ~199 ~60 ~647 ~199 ~60 ~648 minecraft:light_gray_concrete replace
fill ~210 ~60 ~650 ~218 ~60 ~650 minecraft:light_gray_concrete replace
fill ~217 ~60 ~651 ~217 ~60 ~652 minecraft:light_gray_concrete replace
fill ~78 ~60 ~654 ~80 ~60 ~654 minecraft:light_gray_concrete replace
fill ~79 ~60 ~655 ~79 ~60 ~656 minecraft:light_gray_concrete replace
fill ~183 ~60 ~658 ~186 ~60 ~658 minecraft:light_gray_concrete replace
fill ~184 ~60 ~659 ~184 ~60 ~660 minecraft:light_gray_concrete replace
fill ~207 ~60 ~662 ~215 ~60 ~662 minecraft:light_gray_concrete replace
fill ~214 ~60 ~663 ~214 ~60 ~664 minecraft:light_gray_concrete replace
setblock ~103 ~61 ~332 minecraft:light_gray_concrete replace
setblock ~121 ~61 ~348 minecraft:light_gray_concrete replace
setblock ~163 ~61 ~364 minecraft:light_gray_concrete replace
setblock ~139 ~61 ~380 minecraft:light_gray_concrete replace
setblock ~187 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~190 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~208 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~211 ~61 ~396 minecraft:light_gray_concrete replace
setblock ~91 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~93 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~108 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~110 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~125 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~127 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~142 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~144 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~159 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~161 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~175 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~177 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~192 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~194 ~61 ~398 minecraft:light_gray_concrete replace
setblock ~82 ~61 ~400 minecraft:light_gray_concrete replace
setblock ~208 ~61 ~400 minecraft:light_gray_concrete replace
setblock ~211 ~61 ~400 minecraft:light_gray_concrete replace
setblock ~187 ~61 ~404 minecraft:light_gray_concrete replace
setblock ~190 ~61 ~404 minecraft:light_gray_concrete replace
setblock ~115 ~61 ~436 minecraft:light_gray_concrete replace
setblock ~136 ~61 ~440 minecraft:light_gray_concrete replace
setblock ~157 ~61 ~444 minecraft:light_gray_concrete replace
setblock ~166 ~61 ~448 minecraft:light_gray_concrete replace
setblock ~112 ~61 ~472 minecraft:light_gray_concrete replace
setblock ~133 ~61 ~476 minecraft:light_gray_concrete replace
setblock ~154 ~61 ~480 minecraft:light_gray_concrete replace
setblock ~178 ~61 ~484 minecraft:light_gray_concrete replace
setblock ~205 ~61 ~488 minecraft:light_gray_concrete replace
setblock ~109 ~61 ~512 minecraft:light_gray_concrete replace
setblock ~130 ~61 ~516 minecraft:light_gray_concrete replace
setblock ~151 ~61 ~520 minecraft:light_gray_concrete replace
setblock ~175 ~61 ~524 minecraft:light_gray_concrete replace
setblock ~202 ~61 ~528 minecraft:light_gray_concrete replace
setblock ~106 ~61 ~552 minecraft:light_gray_concrete replace
setblock ~127 ~61 ~556 minecraft:light_gray_concrete replace
setblock ~145 ~61 ~560 minecraft:light_gray_concrete replace
setblock ~172 ~61 ~564 minecraft:light_gray_concrete replace
setblock ~196 ~61 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~61 ~592 minecraft:light_gray_concrete replace
setblock ~124 ~61 ~596 minecraft:light_gray_concrete replace
setblock ~142 ~61 ~600 minecraft:light_gray_concrete replace
setblock ~169 ~61 ~604 minecraft:light_gray_concrete replace
setblock ~193 ~61 ~608 minecraft:light_gray_concrete replace
setblock ~85 ~61 ~612 minecraft:light_gray_concrete replace
setblock ~88 ~61 ~616 minecraft:light_gray_concrete replace
setblock ~91 ~61 ~620 minecraft:light_gray_concrete replace
setblock ~94 ~61 ~624 minecraft:light_gray_concrete replace
setblock ~97 ~61 ~628 minecraft:light_gray_concrete replace
setblock ~118 ~61 ~632 minecraft:light_gray_concrete replace
setblock ~148 ~61 ~636 minecraft:light_gray_concrete replace
setblock ~160 ~61 ~640 minecraft:light_gray_concrete replace
setblock ~181 ~61 ~644 minecraft:light_gray_concrete replace
setblock ~89 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~91 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~106 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~108 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~123 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~125 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~152 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~154 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~168 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~170 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~184 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~186 ~61 ~646 minecraft:light_gray_concrete replace
setblock ~82 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~103 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~121 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~139 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~163 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~199 ~61 ~648 minecraft:light_gray_concrete replace
setblock ~217 ~61 ~652 minecraft:light_gray_concrete replace
setblock ~79 ~61 ~656 minecraft:light_gray_concrete replace
setblock ~184 ~61 ~660 minecraft:light_gray_concrete replace
setblock ~214 ~61 ~664 minecraft:light_gray_concrete replace
fill ~102 ~62 ~328 ~102 ~62 ~648 minecraft:light_gray_concrete replace
fill ~120 ~62 ~344 ~120 ~62 ~648 minecraft:light_gray_concrete replace
fill ~162 ~62 ~360 ~162 ~62 ~648 minecraft:light_gray_concrete replace
fill ~138 ~62 ~376 ~138 ~62 ~648 minecraft:light_gray_concrete replace
fill ~210 ~62 ~380 ~210 ~62 ~400 minecraft:light_gray_concrete replace
fill ~207 ~62 ~384 ~207 ~62 ~400 minecraft:light_gray_concrete replace
fill ~189 ~62 ~388 ~189 ~62 ~404 minecraft:light_gray_concrete replace
fill ~186 ~62 ~392 ~186 ~62 ~404 minecraft:light_gray_concrete replace
fill ~81 ~62 ~396 ~81 ~62 ~648 minecraft:light_gray_concrete replace
fill ~114 ~62 ~432 ~114 ~62 ~436 minecraft:light_gray_concrete replace
fill ~135 ~62 ~436 ~135 ~62 ~440 minecraft:light_gray_concrete replace
fill ~156 ~62 ~440 ~156 ~62 ~444 minecraft:light_gray_concrete replace
fill ~165 ~62 ~444 ~165 ~62 ~448 minecraft:light_gray_concrete replace
fill ~111 ~62 ~468 ~111 ~62 ~472 minecraft:light_gray_concrete replace
fill ~132 ~62 ~472 ~132 ~62 ~476 minecraft:light_gray_concrete replace
fill ~153 ~62 ~476 ~153 ~62 ~480 minecraft:light_gray_concrete replace
fill ~177 ~62 ~480 ~177 ~62 ~484 minecraft:light_gray_concrete replace
fill ~204 ~62 ~484 ~204 ~62 ~488 minecraft:light_gray_concrete replace
fill ~108 ~62 ~508 ~108 ~62 ~512 minecraft:light_gray_concrete replace
fill ~129 ~62 ~512 ~129 ~62 ~516 minecraft:light_gray_concrete replace
fill ~150 ~62 ~516 ~150 ~62 ~520 minecraft:light_gray_concrete replace
fill ~174 ~62 ~520 ~174 ~62 ~524 minecraft:light_gray_concrete replace
fill ~201 ~62 ~524 ~201 ~62 ~528 minecraft:light_gray_concrete replace
fill ~105 ~62 ~548 ~105 ~62 ~552 minecraft:light_gray_concrete replace
fill ~126 ~62 ~552 ~126 ~62 ~556 minecraft:light_gray_concrete replace
fill ~144 ~62 ~556 ~144 ~62 ~560 minecraft:light_gray_concrete replace
fill ~171 ~62 ~560 ~171 ~62 ~564 minecraft:light_gray_concrete replace
fill ~195 ~62 ~564 ~195 ~62 ~568 minecraft:light_gray_concrete replace
fill ~99 ~62 ~588 ~99 ~62 ~592 minecraft:light_gray_concrete replace
fill ~123 ~62 ~592 ~123 ~62 ~596 minecraft:light_gray_concrete replace
fill ~141 ~62 ~596 ~141 ~62 ~600 minecraft:light_gray_concrete replace
fill ~168 ~62 ~600 ~168 ~62 ~604 minecraft:light_gray_concrete replace
fill ~192 ~62 ~604 ~192 ~62 ~608 minecraft:light_gray_concrete replace
fill ~84 ~62 ~608 ~84 ~62 ~612 minecraft:light_gray_concrete replace
fill ~87 ~62 ~612 ~87 ~62 ~616 minecraft:light_gray_concrete replace
fill ~90 ~62 ~616 ~90 ~62 ~620 minecraft:light_gray_concrete replace
fill ~93 ~62 ~620 ~93 ~62 ~624 minecraft:light_gray_concrete replace
fill ~96 ~62 ~624 ~96 ~62 ~628 minecraft:light_gray_concrete replace
fill ~117 ~62 ~628 ~117 ~62 ~632 minecraft:light_gray_concrete replace
fill ~147 ~62 ~632 ~147 ~62 ~636 minecraft:light_gray_concrete replace
fill ~159 ~62 ~636 ~159 ~62 ~640 minecraft:light_gray_concrete replace
fill ~180 ~62 ~640 ~180 ~62 ~644 minecraft:light_gray_concrete replace
fill ~198 ~62 ~644 ~198 ~62 ~648 minecraft:light_gray_concrete replace
fill ~216 ~62 ~648 ~216 ~62 ~652 minecraft:light_gray_concrete replace
fill ~78 ~62 ~652 ~78 ~62 ~656 minecraft:light_gray_concrete replace
fill ~183 ~62 ~656 ~183 ~62 ~660 minecraft:light_gray_concrete replace
fill ~213 ~62 ~660 ~213 ~62 ~664 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~327 minecraft:light_gray_concrete replace
setblock ~103 ~63 ~332 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~343 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~345 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~347 minecraft:light_gray_concrete replace
setblock ~121 ~63 ~348 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~359 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~361 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~361 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~363 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~363 minecraft:light_gray_concrete replace
setblock ~163 ~63 ~364 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~375 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~377 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~377 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~377 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~210 ~63 ~379 minecraft:light_gray_concrete replace
setblock ~139 ~63 ~380 minecraft:light_gray_concrete replace
setblock ~207 ~63 ~383 minecraft:light_gray_concrete replace
setblock ~207 ~63 ~385 minecraft:light_gray_concrete replace
setblock ~210 ~63 ~385 minecraft:light_gray_concrete replace
setblock ~189 ~63 ~387 minecraft:light_gray_concrete replace
setblock ~207 ~63 ~387 minecraft:light_gray_concrete replace
setblock ~210 ~63 ~387 minecraft:light_gray_concrete replace
setblock ~189 ~63 ~389 minecraft:light_gray_concrete replace
setblock ~186 ~63 ~391 minecraft:light_gray_concrete replace
setblock ~189 ~63 ~391 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~186 ~63 ~393 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~395 minecraft:light_gray_concrete replace
setblock ~190 ~63 ~396 minecraft:light_gray_concrete replace
setblock ~211 ~63 ~396 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~397 minecraft:light_gray_concrete replace
setblock ~82 ~63 ~400 minecraft:light_gray_concrete replace
setblock ~208 ~63 ~400 minecraft:light_gray_concrete replace
setblock ~187 ~63 ~404 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~409 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~411 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~425 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~63 ~431 minecraft:light_gray_concrete replace
setblock ~135 ~63 ~435 minecraft:light_gray_concrete replace
setblock ~156 ~63 ~439 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~441 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~165 ~63 ~443 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~457 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~459 minecraft:light_gray_concrete replace
setblock ~111 ~63 ~467 minecraft:light_gray_concrete replace
setblock ~132 ~63 ~471 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~473 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~153 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~475 minecraft:light_gray_concrete replace
setblock ~177 ~63 ~479 minecraft:light_gray_concrete replace
setblock ~204 ~63 ~483 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~489 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~491 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~505 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~108 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~507 minecraft:light_gray_concrete replace
setblock ~129 ~63 ~511 minecraft:light_gray_concrete replace
setblock ~150 ~63 ~515 minecraft:light_gray_concrete replace
setblock ~174 ~63 ~519 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~521 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~201 ~63 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~537 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~539 minecraft:light_gray_concrete replace
setblock ~105 ~63 ~547 minecraft:light_gray_concrete replace
setblock ~126 ~63 ~551 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~553 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~555 minecraft:light_gray_concrete replace
setblock ~171 ~63 ~559 minecraft:light_gray_concrete replace
setblock ~195 ~63 ~563 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~569 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~571 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~585 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~99 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~587 minecraft:light_gray_concrete replace
setblock ~123 ~63 ~591 minecraft:light_gray_concrete replace
setblock ~141 ~63 ~595 minecraft:light_gray_concrete replace
setblock ~168 ~63 ~599 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~601 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~192 ~63 ~603 minecraft:light_gray_concrete replace
setblock ~84 ~63 ~607 minecraft:light_gray_concrete replace
setblock ~87 ~63 ~611 minecraft:light_gray_concrete replace
setblock ~90 ~63 ~615 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~617 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~93 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~619 minecraft:light_gray_concrete replace
setblock ~96 ~63 ~623 minecraft:light_gray_concrete replace
setblock ~117 ~63 ~627 minecraft:light_gray_concrete replace
setblock ~147 ~63 ~631 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~633 minecraft:light_gray_concrete replace
setblock ~81 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~102 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~120 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~138 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~159 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~162 ~63 ~635 minecraft:light_gray_concrete replace
setblock ~180 ~63 ~639 minecraft:light_gray_concrete replace
setblock ~198 ~63 ~643 minecraft:light_gray_concrete replace
setblock ~216 ~63 ~647 minecraft:light_gray_concrete replace
setblock ~78 ~63 ~651 minecraft:light_gray_concrete replace
setblock ~183 ~63 ~655 minecraft:light_gray_concrete replace
setblock ~213 ~63 ~659 minecraft:light_gray_concrete replace
fill ~97 ~64 ~324 ~97 ~64 ~325 minecraft:light_gray_concrete replace
fill ~96 ~64 ~326 ~102 ~64 ~326 minecraft:light_gray_concrete replace
fill ~100 ~64 ~340 ~100 ~64 ~341 minecraft:light_gray_concrete replace
fill ~99 ~64 ~342 ~120 ~64 ~342 minecraft:light_gray_concrete replace
fill ~106 ~64 ~356 ~106 ~64 ~357 minecraft:light_gray_concrete replace
fill ~105 ~64 ~358 ~162 ~64 ~358 minecraft:light_gray_concrete replace
fill ~103 ~64 ~372 ~103 ~64 ~373 minecraft:light_gray_concrete replace
fill ~102 ~64 ~374 ~138 ~64 ~374 minecraft:light_gray_concrete replace
fill ~133 ~64 ~376 ~133 ~64 ~377 minecraft:light_gray_concrete replace
fill ~132 ~64 ~378 ~210 ~64 ~378 minecraft:light_gray_concrete replace
fill ~133 ~64 ~380 ~133 ~64 ~381 minecraft:light_gray_concrete replace
fill ~132 ~64 ~382 ~207 ~64 ~382 minecraft:light_gray_concrete replace
fill ~115 ~64 ~384 ~115 ~64 ~385 minecraft:light_gray_concrete replace
fill ~114 ~64 ~386 ~189 ~64 ~386 minecraft:light_gray_concrete replace
fill ~115 ~64 ~388 ~115 ~64 ~389 minecraft:light_gray_concrete replace
fill ~114 ~64 ~390 ~186 ~64 ~390 minecraft:light_gray_concrete replace
fill ~82 ~64 ~392 ~82 ~64 ~393 minecraft:light_gray_concrete replace
fill ~81 ~64 ~394 ~83 ~64 ~394 minecraft:light_gray_concrete replace
fill ~97 ~64 ~428 ~97 ~64 ~429 minecraft:light_gray_concrete replace
fill ~96 ~64 ~430 ~114 ~64 ~430 minecraft:light_gray_concrete replace
fill ~100 ~64 ~432 ~100 ~64 ~433 minecraft:light_gray_concrete replace
fill ~99 ~64 ~434 ~135 ~64 ~434 minecraft:light_gray_concrete replace
fill ~103 ~64 ~436 ~103 ~64 ~437 minecraft:light_gray_concrete replace
fill ~102 ~64 ~438 ~156 ~64 ~438 minecraft:light_gray_concrete replace
fill ~106 ~64 ~440 ~106 ~64 ~441 minecraft:light_gray_concrete replace
fill ~105 ~64 ~442 ~165 ~64 ~442 minecraft:light_gray_concrete replace
fill ~97 ~64 ~464 ~97 ~64 ~465 minecraft:light_gray_concrete replace
fill ~96 ~64 ~466 ~111 ~64 ~466 minecraft:light_gray_concrete replace
fill ~100 ~64 ~468 ~100 ~64 ~469 minecraft:light_gray_concrete replace
fill ~99 ~64 ~470 ~132 ~64 ~470 minecraft:light_gray_concrete replace
fill ~103 ~64 ~472 ~103 ~64 ~473 minecraft:light_gray_concrete replace
fill ~102 ~64 ~474 ~153 ~64 ~474 minecraft:light_gray_concrete replace
fill ~106 ~64 ~476 ~106 ~64 ~477 minecraft:light_gray_concrete replace
fill ~105 ~64 ~478 ~177 ~64 ~478 minecraft:light_gray_concrete replace
fill ~130 ~64 ~480 ~130 ~64 ~481 minecraft:light_gray_concrete replace
fill ~129 ~64 ~482 ~204 ~64 ~482 minecraft:light_gray_concrete replace
fill ~97 ~64 ~504 ~97 ~64 ~505 minecraft:light_gray_concrete replace
fill ~96 ~64 ~506 ~108 ~64 ~506 minecraft:light_gray_concrete replace
fill ~100 ~64 ~508 ~100 ~64 ~509 minecraft:light_gray_concrete replace
fill ~99 ~64 ~510 ~129 ~64 ~510 minecraft:light_gray_concrete replace
fill ~103 ~64 ~512 ~103 ~64 ~513 minecraft:light_gray_concrete replace
fill ~102 ~64 ~514 ~150 ~64 ~514 minecraft:light_gray_concrete replace
fill ~106 ~64 ~516 ~106 ~64 ~517 minecraft:light_gray_concrete replace
fill ~105 ~64 ~518 ~174 ~64 ~518 minecraft:light_gray_concrete replace
fill ~127 ~64 ~520 ~127 ~64 ~521 minecraft:light_gray_concrete replace
fill ~126 ~64 ~522 ~201 ~64 ~522 minecraft:light_gray_concrete replace
fill ~97 ~64 ~544 ~97 ~64 ~545 minecraft:light_gray_concrete replace
fill ~96 ~64 ~546 ~105 ~64 ~546 minecraft:light_gray_concrete replace
fill ~100 ~64 ~548 ~100 ~64 ~549 minecraft:light_gray_concrete replace
fill ~99 ~64 ~550 ~126 ~64 ~550 minecraft:light_gray_concrete replace
fill ~103 ~64 ~552 ~103 ~64 ~553 minecraft:light_gray_concrete replace
fill ~102 ~64 ~554 ~144 ~64 ~554 minecraft:light_gray_concrete replace
fill ~106 ~64 ~556 ~106 ~64 ~557 minecraft:light_gray_concrete replace
fill ~105 ~64 ~558 ~171 ~64 ~558 minecraft:light_gray_concrete replace
fill ~121 ~64 ~560 ~121 ~64 ~561 minecraft:light_gray_concrete replace
fill ~120 ~64 ~562 ~195 ~64 ~562 minecraft:light_gray_concrete replace
fill ~97 ~64 ~584 ~97 ~64 ~585 minecraft:light_gray_concrete replace
fill ~96 ~64 ~586 ~99 ~64 ~586 minecraft:light_gray_concrete replace
fill ~100 ~64 ~588 ~100 ~64 ~589 minecraft:light_gray_concrete replace
fill ~99 ~64 ~590 ~123 ~64 ~590 minecraft:light_gray_concrete replace
fill ~103 ~64 ~592 ~103 ~64 ~593 minecraft:light_gray_concrete replace
fill ~102 ~64 ~594 ~141 ~64 ~594 minecraft:light_gray_concrete replace
fill ~106 ~64 ~596 ~106 ~64 ~597 minecraft:light_gray_concrete replace
fill ~105 ~64 ~598 ~168 ~64 ~598 minecraft:light_gray_concrete replace
fill ~118 ~64 ~600 ~118 ~64 ~601 minecraft:light_gray_concrete replace
fill ~117 ~64 ~602 ~192 ~64 ~602 minecraft:light_gray_concrete replace
fill ~85 ~64 ~604 ~85 ~64 ~605 minecraft:light_gray_concrete replace
fill ~84 ~64 ~606 ~86 ~64 ~606 minecraft:light_gray_concrete replace
fill ~88 ~64 ~608 ~88 ~64 ~609 minecraft:light_gray_concrete replace
fill ~87 ~64 ~610 ~89 ~64 ~610 minecraft:light_gray_concrete replace
fill ~91 ~64 ~612 ~91 ~64 ~613 minecraft:light_gray_concrete replace
fill ~90 ~64 ~614 ~92 ~64 ~614 minecraft:light_gray_concrete replace
fill ~94 ~64 ~616 ~94 ~64 ~617 minecraft:light_gray_concrete replace
fill ~93 ~64 ~618 ~95 ~64 ~618 minecraft:light_gray_concrete replace
fill ~97 ~64 ~620 ~97 ~64 ~621 minecraft:light_gray_concrete replace
fill ~96 ~64 ~622 ~98 ~64 ~622 minecraft:light_gray_concrete replace
fill ~100 ~64 ~624 ~100 ~64 ~625 minecraft:light_gray_concrete replace
fill ~99 ~64 ~626 ~117 ~64 ~626 minecraft:light_gray_concrete replace
fill ~103 ~64 ~628 ~103 ~64 ~629 minecraft:light_gray_concrete replace
fill ~102 ~64 ~630 ~147 ~64 ~630 minecraft:light_gray_concrete replace
fill ~106 ~64 ~632 ~106 ~64 ~633 minecraft:light_gray_concrete replace
fill ~105 ~64 ~634 ~159 ~64 ~634 minecraft:light_gray_concrete replace
fill ~109 ~64 ~636 ~109 ~64 ~637 minecraft:light_gray_concrete replace
fill ~108 ~64 ~638 ~180 ~64 ~638 minecraft:light_gray_concrete replace
fill ~124 ~64 ~640 ~124 ~64 ~641 minecraft:light_gray_concrete replace
fill ~123 ~64 ~642 ~198 ~64 ~642 minecraft:light_gray_concrete replace
fill ~139 ~64 ~644 ~139 ~64 ~645 minecraft:light_gray_concrete replace
fill ~138 ~64 ~646 ~216 ~64 ~646 minecraft:light_gray_concrete replace
fill ~79 ~64 ~648 ~79 ~64 ~649 minecraft:light_gray_concrete replace
fill ~78 ~64 ~650 ~80 ~64 ~650 minecraft:light_gray_concrete replace
fill ~112 ~64 ~652 ~112 ~64 ~653 minecraft:light_gray_concrete replace
fill ~111 ~64 ~654 ~183 ~64 ~654 minecraft:light_gray_concrete replace
fill ~136 ~64 ~656 ~136 ~64 ~657 minecraft:light_gray_concrete replace
fill ~135 ~64 ~658 ~213 ~64 ~658 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~324 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~340 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~342 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~342 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~356 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~118 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~135 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~150 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~152 ~65 ~358 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~372 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~111 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~128 ~65 ~374 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~376 minecraft:light_gray_concrete replace
setblock ~149 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~151 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~166 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~168 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~183 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~185 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~200 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~202 ~65 ~378 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~380 minecraft:light_gray_concrete replace
setblock ~142 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~159 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~161 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~176 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~178 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~193 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~195 ~65 ~382 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~384 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~143 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~160 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~175 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~177 ~65 ~386 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~388 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~137 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~154 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~171 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~173 ~65 ~390 minecraft:light_gray_concrete replace
setblock ~82 ~65 ~392 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~428 minecraft:light_gray_concrete replace
setblock ~105 ~65 ~430 minecraft:light_gray_concrete replace
setblock ~107 ~65 ~430 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~432 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~111 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~128 ~65 ~434 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~436 minecraft:light_gray_concrete replace
setblock ~113 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~130 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~132 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~147 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~149 ~65 ~438 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~440 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~442 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~464 minecraft:light_gray_concrete replace
setblock ~102 ~65 ~466 minecraft:light_gray_concrete replace
setblock ~104 ~65 ~466 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~468 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~123 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~125 ~65 ~470 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~472 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~112 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~127 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~129 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~146 ~65 ~474 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~476 minecraft:light_gray_concrete replace
setblock ~117 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~119 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~134 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~136 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~151 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~153 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~168 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~170 ~65 ~478 minecraft:light_gray_concrete replace
setblock ~130 ~65 ~480 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~146 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~161 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~163 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~178 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~180 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~195 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~197 ~65 ~482 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~504 minecraft:light_gray_concrete replace
setblock ~99 ~65 ~506 minecraft:light_gray_concrete replace
setblock ~101 ~65 ~506 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~508 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~105 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~510 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~512 minecraft:light_gray_concrete replace
setblock ~107 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~126 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~143 ~65 ~514 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~516 minecraft:light_gray_concrete replace
setblock ~114 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~131 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~148 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~150 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~165 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~167 ~65 ~518 minecraft:light_gray_concrete replace
setblock ~127 ~65 ~520 minecraft:light_gray_concrete replace
setblock ~141 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~143 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~160 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~175 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~177 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~192 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~194 ~65 ~522 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~544 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~548 minecraft:light_gray_concrete replace
setblock ~117 ~65 ~550 minecraft:light_gray_concrete replace
setblock ~119 ~65 ~550 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~552 minecraft:light_gray_concrete replace
setblock ~104 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~136 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~138 ~65 ~554 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~556 minecraft:light_gray_concrete replace
setblock ~111 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~113 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~128 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~130 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~145 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~147 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~162 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~164 ~65 ~558 minecraft:light_gray_concrete replace
setblock ~121 ~65 ~560 minecraft:light_gray_concrete replace
setblock ~135 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~137 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~152 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~154 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~169 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~171 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~186 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~188 ~65 ~562 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~584 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~588 minecraft:light_gray_concrete replace
setblock ~114 ~65 ~590 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~590 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~592 minecraft:light_gray_concrete replace
setblock ~115 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~117 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~132 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~134 ~65 ~594 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~596 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~125 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~127 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~142 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~144 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~159 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~161 ~65 ~598 minecraft:light_gray_concrete replace
setblock ~118 ~65 ~600 minecraft:light_gray_concrete replace
setblock ~132 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~134 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~149 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~151 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~166 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~168 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~183 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~185 ~65 ~602 minecraft:light_gray_concrete replace
setblock ~85 ~65 ~604 minecraft:light_gray_concrete replace
setblock ~88 ~65 ~608 minecraft:light_gray_concrete replace
setblock ~91 ~65 ~612 minecraft:light_gray_concrete replace
setblock ~94 ~65 ~616 minecraft:light_gray_concrete replace
setblock ~97 ~65 ~620 minecraft:light_gray_concrete replace
setblock ~100 ~65 ~624 minecraft:light_gray_concrete replace
setblock ~108 ~65 ~626 minecraft:light_gray_concrete replace
setblock ~110 ~65 ~626 minecraft:light_gray_concrete replace
setblock ~103 ~65 ~628 minecraft:light_gray_concrete replace
setblock ~104 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~121 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~123 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~138 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~140 ~65 ~630 minecraft:light_gray_concrete replace
setblock ~106 ~65 ~632 minecraft:light_gray_concrete replace
setblock ~116 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~118 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~133 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~135 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~150 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~152 ~65 ~634 minecraft:light_gray_concrete replace
setblock ~109 ~65 ~636 minecraft:light_gray_concrete replace
setblock ~120 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~122 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~137 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~154 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~171 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~173 ~65 ~638 minecraft:light_gray_concrete replace
setblock ~124 ~65 ~640 minecraft:light_gray_concrete replace
setblock ~138 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~140 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~155 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~157 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~172 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~174 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~189 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~191 ~65 ~642 minecraft:light_gray_concrete replace
setblock ~139 ~65 ~644 minecraft:light_gray_concrete replace
setblock ~156 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~158 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~173 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~175 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~190 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~192 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~207 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~209 ~65 ~646 minecraft:light_gray_concrete replace
setblock ~79 ~65 ~648 minecraft:light_gray_concrete replace
setblock ~112 ~65 ~652 minecraft:light_gray_concrete replace
setblock ~123 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~125 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~140 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~142 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~157 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~159 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~174 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~176 ~65 ~654 minecraft:light_gray_concrete replace
setblock ~136 ~65 ~656 minecraft:light_gray_concrete replace
setblock ~153 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~155 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~170 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~172 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~187 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~189 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~204 ~65 ~658 minecraft:light_gray_concrete replace
setblock ~206 ~65 ~658 minecraft:light_gray_concrete replace
fill ~96 ~66 ~324 ~96 ~66 ~624 minecraft:light_gray_concrete replace
fill ~99 ~66 ~340 ~99 ~66 ~628 minecraft:light_gray_concrete replace
fill ~105 ~66 ~356 ~105 ~66 ~636 minecraft:light_gray_concrete replace
fill ~102 ~66 ~372 ~102 ~66 ~632 minecraft:light_gray_concrete replace
fill ~132 ~66 ~376 ~132 ~66 ~384 minecraft:light_gray_concrete replace
fill ~114 ~66 ~384 ~114 ~66 ~392 minecraft:light_gray_concrete replace
fill ~81 ~66 ~392 ~81 ~66 ~396 minecraft:light_gray_concrete replace
fill ~129 ~66 ~480 ~129 ~66 ~484 minecraft:light_gray_concrete replace
fill ~126 ~66 ~520 ~126 ~66 ~524 minecraft:light_gray_concrete replace
fill ~120 ~66 ~560 ~120 ~66 ~564 minecraft:light_gray_concrete replace
fill ~117 ~66 ~600 ~117 ~66 ~604 minecraft:light_gray_concrete replace
fill ~84 ~66 ~604 ~84 ~66 ~608 minecraft:light_gray_concrete replace
fill ~87 ~66 ~608 ~87 ~66 ~612 minecraft:light_gray_concrete replace
fill ~90 ~66 ~612 ~90 ~66 ~616 minecraft:light_gray_concrete replace
fill ~93 ~66 ~616 ~93 ~66 ~620 minecraft:light_gray_concrete replace
fill ~108 ~66 ~636 ~108 ~66 ~640 minecraft:light_gray_concrete replace
fill ~123 ~66 ~640 ~123 ~66 ~644 minecraft:light_gray_concrete replace
fill ~138 ~66 ~644 ~138 ~66 ~648 minecraft:light_gray_concrete replace
fill ~78 ~66 ~648 ~78 ~66 ~652 minecraft:light_gray_concrete replace
fill ~111 ~66 ~652 ~111 ~66 ~656 minecraft:light_gray_concrete replace
fill ~135 ~66 ~656 ~135 ~66 ~660 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~324 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~337 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~339 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~340 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~353 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~353 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~355 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~355 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~356 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~369 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~369 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~369 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~371 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~371 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~371 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~372 minecraft:light_gray_concrete replace
setblock ~133 ~67 ~376 minecraft:light_gray_concrete replace
setblock ~133 ~67 ~380 minecraft:light_gray_concrete replace
setblock ~132 ~67 ~383 minecraft:light_gray_concrete replace
setblock ~115 ~67 ~384 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~132 ~67 ~385 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~387 minecraft:light_gray_concrete replace
setblock ~115 ~67 ~388 minecraft:light_gray_concrete replace
setblock ~114 ~67 ~391 minecraft:light_gray_concrete replace
setblock ~82 ~67 ~392 minecraft:light_gray_concrete replace
setblock ~114 ~67 ~393 minecraft:light_gray_concrete replace
setblock ~81 ~67 ~397 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~401 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~403 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~417 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~419 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~428 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~432 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~433 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~433 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~433 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~435 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~435 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~435 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~436 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~440 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~447 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~449 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~451 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~451 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~451 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~463 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~464 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~465 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~467 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~467 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~468 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~472 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~476 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~479 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~479 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~481 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~483 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~483 minecraft:light_gray_concrete replace
setblock ~129 ~67 ~485 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~495 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~495 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~497 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~499 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~499 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~508 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~511 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~511 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~512 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~513 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~513 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~513 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~515 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~516 minecraft:light_gray_concrete replace
setblock ~126 ~67 ~525 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~527 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~527 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~527 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~529 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~531 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~543 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~543 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~544 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~545 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~545 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~547 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~552 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~556 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~557 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~559 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~559 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~559 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~561 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~561 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~561 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~563 minecraft:light_gray_concrete replace
setblock ~120 ~67 ~565 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~573 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~575 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~577 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~579 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~584 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~588 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~589 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~591 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~591 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~592 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~593 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~593 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~595 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~596 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~605 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~605 minecraft:light_gray_concrete replace
setblock ~117 ~67 ~605 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~607 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~607 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~607 minecraft:light_gray_concrete replace
setblock ~84 ~67 ~609 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~609 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~609 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~611 minecraft:light_gray_concrete replace
setblock ~87 ~67 ~613 minecraft:light_gray_concrete replace
setblock ~90 ~67 ~617 minecraft:light_gray_concrete replace
setblock ~97 ~67 ~620 minecraft:light_gray_concrete replace
setblock ~93 ~67 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~623 minecraft:light_gray_concrete replace
setblock ~100 ~67 ~624 minecraft:light_gray_concrete replace
setblock ~96 ~67 ~625 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~625 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~627 minecraft:light_gray_concrete replace
setblock ~103 ~67 ~628 minecraft:light_gray_concrete replace
setblock ~99 ~67 ~629 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~631 minecraft:light_gray_concrete replace
setblock ~106 ~67 ~632 minecraft:light_gray_concrete replace
setblock ~102 ~67 ~633 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~635 minecraft:light_gray_concrete replace
setblock ~105 ~67 ~637 minecraft:light_gray_concrete replace
setblock ~108 ~67 ~641 minecraft:light_gray_concrete replace
setblock ~123 ~67 ~645 minecraft:light_gray_concrete replace
setblock ~138 ~67 ~649 minecraft:light_gray_concrete replace
setblock ~78 ~67 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~67 ~657 minecraft:light_gray_concrete replace
setblock ~135 ~67 ~661 minecraft:light_gray_concrete replace
fill ~132 ~68 ~386 ~134 ~68 ~386 minecraft:light_gray_concrete replace
fill ~133 ~68 ~387 ~133 ~68 ~388 minecraft:light_gray_concrete replace
fill ~114 ~68 ~394 ~116 ~68 ~394 minecraft:light_gray_concrete replace
fill ~115 ~68 ~395 ~115 ~68 ~396 minecraft:light_gray_concrete replace
fill ~81 ~68 ~398 ~86 ~68 ~398 minecraft:light_gray_concrete replace
fill ~85 ~68 ~399 ~85 ~68 ~400 minecraft:light_gray_concrete replace
fill ~126 ~68 ~486 ~129 ~68 ~486 minecraft:light_gray_concrete replace
fill ~127 ~68 ~487 ~127 ~68 ~488 minecraft:light_gray_concrete replace
fill ~123 ~68 ~526 ~126 ~68 ~526 minecraft:light_gray_concrete replace
fill ~124 ~68 ~527 ~124 ~68 ~528 minecraft:light_gray_concrete replace
fill ~120 ~68 ~566 ~122 ~68 ~566 minecraft:light_gray_concrete replace
fill ~121 ~68 ~567 ~121 ~68 ~568 minecraft:light_gray_concrete replace
fill ~117 ~68 ~606 ~119 ~68 ~606 minecraft:light_gray_concrete replace
fill ~118 ~68 ~607 ~118 ~68 ~608 minecraft:light_gray_concrete replace
fill ~84 ~68 ~610 ~89 ~68 ~610 minecraft:light_gray_concrete replace
fill ~88 ~68 ~611 ~88 ~68 ~612 minecraft:light_gray_concrete replace
fill ~87 ~68 ~614 ~92 ~68 ~614 minecraft:light_gray_concrete replace
fill ~91 ~68 ~615 ~91 ~68 ~616 minecraft:light_gray_concrete replace
fill ~90 ~68 ~618 ~95 ~68 ~618 minecraft:light_gray_concrete replace
fill ~94 ~68 ~619 ~94 ~68 ~620 minecraft:light_gray_concrete replace
fill ~93 ~68 ~622 ~98 ~68 ~622 minecraft:light_gray_concrete replace
fill ~97 ~68 ~623 ~97 ~68 ~624 minecraft:light_gray_concrete replace
fill ~96 ~68 ~626 ~101 ~68 ~626 minecraft:light_gray_concrete replace
fill ~100 ~68 ~627 ~100 ~68 ~628 minecraft:light_gray_concrete replace
fill ~99 ~68 ~630 ~104 ~68 ~630 minecraft:light_gray_concrete replace
fill ~103 ~68 ~631 ~103 ~68 ~632 minecraft:light_gray_concrete replace
fill ~78 ~68 ~634 ~131 ~68 ~634 minecraft:light_gray_concrete replace
fill ~79 ~68 ~635 ~79 ~68 ~636 minecraft:light_gray_concrete replace
fill ~130 ~68 ~635 ~130 ~68 ~636 minecraft:light_gray_concrete replace
fill ~105 ~68 ~638 ~107 ~68 ~638 minecraft:light_gray_concrete replace
fill ~106 ~68 ~639 ~106 ~68 ~640 minecraft:light_gray_concrete replace
fill ~108 ~68 ~642 ~110 ~68 ~642 minecraft:light_gray_concrete replace
fill ~109 ~68 ~643 ~109 ~68 ~644 minecraft:light_gray_concrete replace
fill ~114 ~68 ~646 ~134 ~68 ~646 minecraft:light_gray_concrete replace
fill ~115 ~68 ~647 ~115 ~68 ~648 minecraft:light_gray_concrete replace
fill ~133 ~68 ~647 ~133 ~68 ~648 minecraft:light_gray_concrete replace
fill ~138 ~68 ~650 ~140 ~68 ~650 minecraft:light_gray_concrete replace
fill ~139 ~68 ~651 ~139 ~68 ~652 minecraft:light_gray_concrete replace
fill ~78 ~68 ~654 ~83 ~68 ~654 minecraft:light_gray_concrete replace
fill ~82 ~68 ~655 ~82 ~68 ~656 minecraft:light_gray_concrete replace
fill ~111 ~68 ~658 ~113 ~68 ~658 minecraft:light_gray_concrete replace
fill ~112 ~68 ~659 ~112 ~68 ~660 minecraft:light_gray_concrete replace
fill ~135 ~68 ~662 ~137 ~68 ~662 minecraft:light_gray_concrete replace
fill ~136 ~68 ~663 ~136 ~68 ~664 minecraft:light_gray_concrete replace
setblock ~133 ~69 ~388 minecraft:light_gray_concrete replace
setblock ~115 ~69 ~396 minecraft:light_gray_concrete replace
setblock ~85 ~69 ~400 minecraft:light_gray_concrete replace
setblock ~127 ~69 ~488 minecraft:light_gray_concrete replace
setblock ~124 ~69 ~528 minecraft:light_gray_concrete replace
setblock ~121 ~69 ~568 minecraft:light_gray_concrete replace
setblock ~118 ~69 ~608 minecraft:light_gray_concrete replace
setblock ~88 ~69 ~612 minecraft:light_gray_concrete replace
setblock ~91 ~69 ~616 minecraft:light_gray_concrete replace
setblock ~94 ~69 ~620 minecraft:light_gray_concrete replace
setblock ~97 ~69 ~624 minecraft:light_gray_concrete replace
setblock ~100 ~69 ~628 minecraft:light_gray_concrete replace
setblock ~103 ~69 ~632 minecraft:light_gray_concrete replace
setblock ~87 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~89 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~115 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~117 ~69 ~634 minecraft:light_gray_concrete replace
setblock ~79 ~69 ~636 minecraft:light_gray_concrete replace
setblock ~130 ~69 ~636 minecraft:light_gray_concrete replace
setblock ~106 ~69 ~640 minecraft:light_gray_concrete replace
setblock ~109 ~69 ~644 minecraft:light_gray_concrete replace
setblock ~130 ~69 ~646 minecraft:light_gray_concrete replace
setblock ~132 ~69 ~646 minecraft:light_gray_concrete replace
setblock ~115 ~69 ~648 minecraft:light_gray_concrete replace
setblock ~133 ~69 ~648 minecraft:light_gray_concrete replace
setblock ~139 ~69 ~652 minecraft:light_gray_concrete replace
setblock ~82 ~69 ~656 minecraft:light_gray_concrete replace
setblock ~112 ~69 ~660 minecraft:light_gray_concrete replace
setblock ~136 ~69 ~664 minecraft:light_gray_concrete replace
fill ~132 ~70 ~384 ~132 ~70 ~648 minecraft:light_gray_concrete replace
fill ~114 ~70 ~392 ~114 ~70 ~648 minecraft:light_gray_concrete replace
fill ~84 ~70 ~396 ~84 ~70 ~400 minecraft:light_gray_concrete replace
fill ~126 ~70 ~484 ~126 ~70 ~488 minecraft:light_gray_concrete replace
fill ~123 ~70 ~524 ~123 ~70 ~528 minecraft:light_gray_concrete replace
fill ~120 ~70 ~564 ~120 ~70 ~568 minecraft:light_gray_concrete replace
fill ~117 ~70 ~600 ~117 ~70 ~608 minecraft:light_gray_concrete replace
fill ~87 ~70 ~604 ~87 ~70 ~612 minecraft:light_gray_concrete replace
fill ~90 ~70 ~608 ~90 ~70 ~616 minecraft:light_gray_concrete replace
fill ~93 ~70 ~612 ~93 ~70 ~620 minecraft:light_gray_concrete replace
fill ~96 ~70 ~616 ~96 ~70 ~624 minecraft:light_gray_concrete replace
fill ~99 ~70 ~620 ~99 ~70 ~628 minecraft:light_gray_concrete replace
fill ~102 ~70 ~624 ~102 ~70 ~632 minecraft:light_gray_concrete replace
fill ~129 ~70 ~628 ~129 ~70 ~636 minecraft:light_gray_concrete replace
fill ~78 ~70 ~632 ~78 ~70 ~636 minecraft:light_gray_concrete replace
fill ~105 ~70 ~636 ~105 ~70 ~640 minecraft:light_gray_concrete replace
fill ~108 ~70 ~640 ~108 ~70 ~644 minecraft:light_gray_concrete replace
fill ~138 ~70 ~648 ~138 ~70 ~652 minecraft:light_gray_concrete replace
fill ~81 ~70 ~652 ~81 ~70 ~656 minecraft:light_gray_concrete replace
fill ~111 ~70 ~656 ~111 ~70 ~660 minecraft:light_gray_concrete replace
fill ~135 ~70 ~660 ~135 ~70 ~664 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~383 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~385 minecraft:light_gray_concrete replace
setblock ~133 ~71 ~388 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~391 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~393 minecraft:light_gray_concrete replace
setblock ~84 ~71 ~395 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~395 minecraft:light_gray_concrete replace
setblock ~115 ~71 ~396 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~409 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~409 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~411 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~411 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~425 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~425 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~427 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~441 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~441 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~443 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~443 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~457 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~457 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~459 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~459 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~473 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~473 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~475 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~475 minecraft:light_gray_concrete replace
setblock ~126 ~71 ~483 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~489 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~489 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~491 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~491 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~505 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~505 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~507 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~507 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~521 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~521 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~523 minecraft:light_gray_concrete replace
setblock ~123 ~71 ~523 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~523 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~537 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~537 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~539 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~539 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~553 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~553 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~555 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~555 minecraft:light_gray_concrete replace
setblock ~120 ~71 ~563 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~569 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~569 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~571 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~571 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~585 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~585 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~587 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~587 minecraft:light_gray_concrete replace
setblock ~117 ~71 ~599 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~601 minecraft:light_gray_concrete replace
setblock ~117 ~71 ~601 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~601 minecraft:light_gray_concrete replace
setblock ~87 ~71 ~603 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~603 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~603 minecraft:light_gray_concrete replace
setblock ~87 ~71 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~71 ~607 minecraft:light_gray_concrete replace
setblock ~90 ~71 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~71 ~611 minecraft:light_gray_concrete replace
setblock ~93 ~71 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~71 ~615 minecraft:light_gray_concrete replace
setblock ~96 ~71 ~617 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~617 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~71 ~619 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~619 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~619 minecraft:light_gray_concrete replace
setblock ~99 ~71 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~71 ~623 minecraft:light_gray_concrete replace
setblock ~102 ~71 ~625 minecraft:light_gray_concrete replace
setblock ~129 ~71 ~627 minecraft:light_gray_concrete replace
setblock ~129 ~71 ~629 minecraft:light_gray_concrete replace
setblock ~78 ~71 ~631 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~633 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~633 minecraft:light_gray_concrete replace
setblock ~105 ~71 ~635 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~635 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~635 minecraft:light_gray_concrete replace
setblock ~130 ~71 ~636 minecraft:light_gray_concrete replace
setblock ~108 ~71 ~639 minecraft:light_gray_concrete replace
setblock ~138 ~71 ~647 minecraft:light_gray_concrete replace
setblock ~81 ~71 ~651 minecraft:light_gray_concrete replace
setblock ~111 ~71 ~655 minecraft:light_gray_concrete replace
setblock ~135 ~71 ~659 minecraft:light_gray_concrete replace
fill ~115 ~72 ~380 ~115 ~72 ~381 minecraft:light_gray_concrete replace
fill ~114 ~72 ~382 ~132 ~72 ~382 minecraft:light_gray_concrete replace
fill ~109 ~72 ~388 ~109 ~72 ~389 minecraft:light_gray_concrete replace
fill ~108 ~72 ~390 ~114 ~72 ~390 minecraft:light_gray_concrete replace
fill ~85 ~72 ~392 ~85 ~72 ~393 minecraft:light_gray_concrete replace
fill ~84 ~72 ~394 ~86 ~72 ~394 minecraft:light_gray_concrete replace
fill ~109 ~72 ~480 ~109 ~72 ~481 minecraft:light_gray_concrete replace
fill ~108 ~72 ~482 ~126 ~72 ~482 minecraft:light_gray_concrete replace
fill ~109 ~72 ~520 ~109 ~72 ~521 minecraft:light_gray_concrete replace
fill ~108 ~72 ~522 ~123 ~72 ~522 minecraft:light_gray_concrete replace
fill ~109 ~72 ~560 ~109 ~72 ~561 minecraft:light_gray_concrete replace
fill ~108 ~72 ~562 ~120 ~72 ~562 minecraft:light_gray_concrete replace
fill ~109 ~72 ~596 ~109 ~72 ~597 minecraft:light_gray_concrete replace
fill ~108 ~72 ~598 ~117 ~72 ~598 minecraft:light_gray_concrete replace
fill ~88 ~72 ~600 ~88 ~72 ~601 minecraft:light_gray_concrete replace
fill ~87 ~72 ~602 ~89 ~72 ~602 minecraft:light_gray_concrete replace
fill ~91 ~72 ~604 ~91 ~72 ~605 minecraft:light_gray_concrete replace
fill ~90 ~72 ~606 ~92 ~72 ~606 minecraft:light_gray_concrete replace
fill ~94 ~72 ~608 ~94 ~72 ~609 minecraft:light_gray_concrete replace
fill ~93 ~72 ~610 ~95 ~72 ~610 minecraft:light_gray_concrete replace
fill ~97 ~72 ~612 ~97 ~72 ~613 minecraft:light_gray_concrete replace
fill ~96 ~72 ~614 ~98 ~72 ~614 minecraft:light_gray_concrete replace
fill ~100 ~72 ~616 ~100 ~72 ~617 minecraft:light_gray_concrete replace
fill ~99 ~72 ~618 ~101 ~72 ~618 minecraft:light_gray_concrete replace
fill ~103 ~72 ~620 ~103 ~72 ~621 minecraft:light_gray_concrete replace
fill ~102 ~72 ~622 ~104 ~72 ~622 minecraft:light_gray_concrete replace
fill ~112 ~72 ~624 ~112 ~72 ~625 minecraft:light_gray_concrete replace
fill ~111 ~72 ~626 ~129 ~72 ~626 minecraft:light_gray_concrete replace
fill ~79 ~72 ~628 ~79 ~72 ~629 minecraft:light_gray_concrete replace
fill ~78 ~72 ~630 ~80 ~72 ~630 minecraft:light_gray_concrete replace
fill ~106 ~72 ~632 ~106 ~72 ~633 minecraft:light_gray_concrete replace
fill ~105 ~72 ~634 ~107 ~72 ~634 minecraft:light_gray_concrete replace
fill ~109 ~72 ~636 ~109 ~72 ~637 minecraft:light_gray_concrete replace
fill ~108 ~72 ~638 ~110 ~72 ~638 minecraft:light_gray_concrete replace
fill ~121 ~72 ~644 ~121 ~72 ~645 minecraft:light_gray_concrete replace
fill ~120 ~72 ~646 ~138 ~72 ~646 minecraft:light_gray_concrete replace
fill ~82 ~72 ~648 ~82 ~72 ~649 minecraft:light_gray_concrete replace
fill ~81 ~72 ~650 ~83 ~72 ~650 minecraft:light_gray_concrete replace
fill ~109 ~72 ~652 ~109 ~72 ~653 minecraft:light_gray_concrete replace
fill ~108 ~72 ~654 ~111 ~72 ~654 minecraft:light_gray_concrete replace
fill ~118 ~72 ~656 ~118 ~72 ~657 minecraft:light_gray_concrete replace
fill ~117 ~72 ~658 ~135 ~72 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~73 ~380 minecraft:light_gray_concrete replace
setblock ~117 ~73 ~382 minecraft:light_gray_concrete replace
setblock ~119 ~73 ~382 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~388 minecraft:light_gray_concrete replace
setblock ~85 ~73 ~392 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~480 minecraft:light_gray_concrete replace
setblock ~117 ~73 ~482 minecraft:light_gray_concrete replace
setblock ~119 ~73 ~482 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~520 minecraft:light_gray_concrete replace
setblock ~114 ~73 ~522 minecraft:light_gray_concrete replace
setblock ~116 ~73 ~522 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~560 minecraft:light_gray_concrete replace
setblock ~111 ~73 ~562 minecraft:light_gray_concrete replace
setblock ~113 ~73 ~562 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~596 minecraft:light_gray_concrete replace
setblock ~88 ~73 ~600 minecraft:light_gray_concrete replace
setblock ~91 ~73 ~604 minecraft:light_gray_concrete replace
setblock ~94 ~73 ~608 minecraft:light_gray_concrete replace
setblock ~97 ~73 ~612 minecraft:light_gray_concrete replace
setblock ~100 ~73 ~616 minecraft:light_gray_concrete replace
setblock ~103 ~73 ~620 minecraft:light_gray_concrete replace
setblock ~112 ~73 ~624 minecraft:light_gray_concrete replace
setblock ~114 ~73 ~626 minecraft:light_gray_concrete replace
setblock ~116 ~73 ~626 minecraft:light_gray_concrete replace
setblock ~79 ~73 ~628 minecraft:light_gray_concrete replace
setblock ~106 ~73 ~632 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~636 minecraft:light_gray_concrete replace
setblock ~121 ~73 ~644 minecraft:light_gray_concrete replace
setblock ~129 ~73 ~646 minecraft:light_gray_concrete replace
setblock ~131 ~73 ~646 minecraft:light_gray_concrete replace
setblock ~82 ~73 ~648 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~652 minecraft:light_gray_concrete replace
setblock ~118 ~73 ~656 minecraft:light_gray_concrete replace
setblock ~126 ~73 ~658 minecraft:light_gray_concrete replace
setblock ~128 ~73 ~658 minecraft:light_gray_concrete replace
fill ~114 ~74 ~380 ~114 ~74 ~384 minecraft:light_gray_concrete replace
fill ~108 ~74 ~388 ~108 ~74 ~656 minecraft:light_gray_concrete replace
fill ~84 ~74 ~392 ~84 ~74 ~396 minecraft:light_gray_concrete replace
fill ~87 ~74 ~600 ~87 ~74 ~604 minecraft:light_gray_concrete replace
fill ~90 ~74 ~604 ~90 ~74 ~608 minecraft:light_gray_concrete replace
fill ~93 ~74 ~608 ~93 ~74 ~612 minecraft:light_gray_concrete replace
fill ~96 ~74 ~612 ~96 ~74 ~616 minecraft:light_gray_concrete replace
fill ~99 ~74 ~616 ~99 ~74 ~620 minecraft:light_gray_concrete replace
fill ~102 ~74 ~620 ~102 ~74 ~624 minecraft:light_gray_concrete replace
fill ~111 ~74 ~624 ~111 ~74 ~628 minecraft:light_gray_concrete replace
fill ~78 ~74 ~628 ~78 ~74 ~632 minecraft:light_gray_concrete replace
fill ~105 ~74 ~632 ~105 ~74 ~636 minecraft:light_gray_concrete replace
fill ~120 ~74 ~644 ~120 ~74 ~648 minecraft:light_gray_concrete replace
fill ~81 ~74 ~648 ~81 ~74 ~652 minecraft:light_gray_concrete replace
fill ~117 ~74 ~656 ~117 ~74 ~660 minecraft:light_gray_concrete replace
setblock ~115 ~75 ~380 minecraft:light_gray_concrete replace
setblock ~114 ~75 ~385 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~388 minecraft:light_gray_concrete replace
setblock ~84 ~75 ~397 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~401 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~403 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~417 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~419 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~433 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~435 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~449 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~451 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~465 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~467 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~480 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~495 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~497 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~511 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~513 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~520 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~543 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~545 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~560 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~573 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~575 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~589 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~591 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~596 minecraft:light_gray_concrete replace
setblock ~87 ~75 ~605 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~605 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~607 minecraft:light_gray_concrete replace
setblock ~90 ~75 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~75 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~75 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~75 ~621 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~621 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~623 minecraft:light_gray_concrete replace
setblock ~112 ~75 ~624 minecraft:light_gray_concrete replace
setblock ~102 ~75 ~625 minecraft:light_gray_concrete replace
setblock ~111 ~75 ~629 minecraft:light_gray_concrete replace
setblock ~78 ~75 ~633 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~636 minecraft:light_gray_concrete replace
setblock ~105 ~75 ~637 minecraft:light_gray_concrete replace
setblock ~120 ~75 ~649 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~652 minecraft:light_gray_concrete replace
setblock ~81 ~75 ~653 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~657 minecraft:light_gray_concrete replace
setblock ~117 ~75 ~661 minecraft:light_gray_concrete replace
fill ~114 ~76 ~386 ~116 ~76 ~386 minecraft:light_gray_concrete replace
fill ~115 ~76 ~387 ~115 ~76 ~388 minecraft:light_gray_concrete replace
fill ~81 ~76 ~398 ~84 ~76 ~398 minecraft:light_gray_concrete replace
fill ~82 ~76 ~399 ~82 ~76 ~400 minecraft:light_gray_concrete replace
fill ~78 ~76 ~606 ~89 ~76 ~606 minecraft:light_gray_concrete replace
fill ~79 ~76 ~607 ~79 ~76 ~608 minecraft:light_gray_concrete replace
fill ~88 ~76 ~607 ~88 ~76 ~608 minecraft:light_gray_concrete replace
fill ~78 ~76 ~610 ~92 ~76 ~610 minecraft:light_gray_concrete replace
fill ~79 ~76 ~611 ~79 ~76 ~612 minecraft:light_gray_concrete replace
fill ~91 ~76 ~611 ~91 ~76 ~612 minecraft:light_gray_concrete replace
fill ~78 ~76 ~614 ~95 ~76 ~614 minecraft:light_gray_concrete replace
fill ~79 ~76 ~615 ~79 ~76 ~616 minecraft:light_gray_concrete replace
fill ~94 ~76 ~615 ~94 ~76 ~616 minecraft:light_gray_concrete replace
fill ~78 ~76 ~618 ~98 ~76 ~618 minecraft:light_gray_concrete replace
fill ~79 ~76 ~619 ~79 ~76 ~620 minecraft:light_gray_concrete replace
fill ~97 ~76 ~619 ~97 ~76 ~620 minecraft:light_gray_concrete replace
fill ~78 ~76 ~622 ~101 ~76 ~622 minecraft:light_gray_concrete replace
fill ~79 ~76 ~623 ~79 ~76 ~624 minecraft:light_gray_concrete replace
fill ~100 ~76 ~623 ~100 ~76 ~624 minecraft:light_gray_concrete replace
fill ~78 ~76 ~626 ~104 ~76 ~626 minecraft:light_gray_concrete replace
fill ~79 ~76 ~627 ~79 ~76 ~628 minecraft:light_gray_concrete replace
fill ~103 ~76 ~627 ~103 ~76 ~628 minecraft:light_gray_concrete replace
fill ~108 ~76 ~630 ~111 ~76 ~630 minecraft:light_gray_concrete replace
fill ~109 ~76 ~631 ~109 ~76 ~632 minecraft:light_gray_concrete replace
fill ~78 ~76 ~634 ~80 ~76 ~634 minecraft:light_gray_concrete replace
fill ~79 ~76 ~635 ~79 ~76 ~636 minecraft:light_gray_concrete replace
fill ~78 ~76 ~638 ~107 ~76 ~638 minecraft:light_gray_concrete replace
fill ~79 ~76 ~639 ~79 ~76 ~640 minecraft:light_gray_concrete replace
fill ~106 ~76 ~639 ~106 ~76 ~640 minecraft:light_gray_concrete replace
fill ~120 ~76 ~650 ~125 ~76 ~650 minecraft:light_gray_concrete replace
fill ~124 ~76 ~651 ~124 ~76 ~652 minecraft:light_gray_concrete replace
fill ~78 ~76 ~654 ~86 ~76 ~654 minecraft:light_gray_concrete replace
fill ~79 ~76 ~655 ~79 ~76 ~656 minecraft:light_gray_concrete replace
fill ~85 ~76 ~655 ~85 ~76 ~656 minecraft:light_gray_concrete replace
fill ~78 ~76 ~658 ~119 ~76 ~658 minecraft:light_gray_concrete replace
fill ~79 ~76 ~659 ~79 ~76 ~660 minecraft:light_gray_concrete replace
fill ~112 ~76 ~659 ~112 ~76 ~660 minecraft:light_gray_concrete replace
fill ~118 ~76 ~659 ~118 ~76 ~660 minecraft:light_gray_concrete replace
fill ~117 ~76 ~662 ~122 ~76 ~662 minecraft:light_gray_concrete replace
fill ~121 ~76 ~663 ~121 ~76 ~664 minecraft:light_gray_concrete replace
setblock ~115 ~77 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~77 ~400 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~608 minecraft:light_gray_concrete replace
setblock ~88 ~77 ~608 minecraft:light_gray_concrete replace
setblock ~81 ~77 ~610 minecraft:light_gray_concrete replace
setblock ~83 ~77 ~610 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~612 minecraft:light_gray_concrete replace
setblock ~91 ~77 ~612 minecraft:light_gray_concrete replace
setblock ~84 ~77 ~614 minecraft:light_gray_concrete replace
setblock ~86 ~77 ~614 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~616 minecraft:light_gray_concrete replace
setblock ~94 ~77 ~616 minecraft:light_gray_concrete replace
setblock ~87 ~77 ~618 minecraft:light_gray_concrete replace
setblock ~89 ~77 ~618 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~620 minecraft:light_gray_concrete replace
setblock ~97 ~77 ~620 minecraft:light_gray_concrete replace
setblock ~90 ~77 ~622 minecraft:light_gray_concrete replace
setblock ~92 ~77 ~622 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~624 minecraft:light_gray_concrete replace
setblock ~100 ~77 ~624 minecraft:light_gray_concrete replace
setblock ~93 ~77 ~626 minecraft:light_gray_concrete replace
setblock ~95 ~77 ~626 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~628 minecraft:light_gray_concrete replace
setblock ~103 ~77 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~77 ~632 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~636 minecraft:light_gray_concrete replace
setblock ~96 ~77 ~638 minecraft:light_gray_concrete replace
setblock ~98 ~77 ~638 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~640 minecraft:light_gray_concrete replace
setblock ~106 ~77 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~77 ~652 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~656 minecraft:light_gray_concrete replace
setblock ~85 ~77 ~656 minecraft:light_gray_concrete replace
setblock ~82 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~84 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~99 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~101 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~117 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~660 minecraft:light_gray_concrete replace
setblock ~112 ~77 ~660 minecraft:light_gray_concrete replace
setblock ~118 ~77 ~660 minecraft:light_gray_concrete replace
setblock ~121 ~77 ~664 minecraft:light_gray_concrete replace
fill ~114 ~78 ~384 ~114 ~78 ~388 minecraft:light_gray_concrete replace
fill ~81 ~78 ~396 ~81 ~78 ~400 minecraft:light_gray_concrete replace
fill ~87 ~78 ~600 ~87 ~78 ~608 minecraft:light_gray_concrete replace
fill ~78 ~78 ~604 ~78 ~78 ~660 minecraft:light_gray_concrete replace
fill ~90 ~78 ~608 ~90 ~78 ~612 minecraft:light_gray_concrete replace
fill ~93 ~78 ~612 ~93 ~78 ~616 minecraft:light_gray_concrete replace
fill ~96 ~78 ~616 ~96 ~78 ~620 minecraft:light_gray_concrete replace
fill ~99 ~78 ~620 ~99 ~78 ~624 minecraft:light_gray_concrete replace
fill ~102 ~78 ~624 ~102 ~78 ~628 minecraft:light_gray_concrete replace
fill ~108 ~78 ~628 ~108 ~78 ~632 minecraft:light_gray_concrete replace
fill ~105 ~78 ~636 ~105 ~78 ~640 minecraft:light_gray_concrete replace
fill ~123 ~78 ~644 ~123 ~78 ~652 minecraft:light_gray_concrete replace
fill ~84 ~78 ~648 ~84 ~78 ~656 minecraft:light_gray_concrete replace
fill ~117 ~78 ~652 ~117 ~78 ~660 minecraft:light_gray_concrete replace
fill ~111 ~78 ~656 ~111 ~78 ~660 minecraft:light_gray_concrete replace
fill ~120 ~78 ~660 ~120 ~78 ~664 minecraft:light_gray_concrete replace
setblock ~114 ~79 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~79 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~79 ~599 minecraft:light_gray_concrete replace
setblock ~87 ~79 ~601 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~603 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~79 ~607 minecraft:light_gray_concrete replace
setblock ~93 ~79 ~611 minecraft:light_gray_concrete replace
setblock ~96 ~79 ~615 minecraft:light_gray_concrete replace
setblock ~99 ~79 ~619 minecraft:light_gray_concrete replace
setblock ~102 ~79 ~623 minecraft:light_gray_concrete replace
setblock ~108 ~79 ~627 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~629 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~631 minecraft:light_gray_concrete replace
setblock ~105 ~79 ~635 minecraft:light_gray_concrete replace
setblock ~123 ~79 ~643 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~645 minecraft:light_gray_concrete replace
setblock ~123 ~79 ~645 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~647 minecraft:light_gray_concrete replace
setblock ~84 ~79 ~647 minecraft:light_gray_concrete replace
setblock ~84 ~79 ~649 minecraft:light_gray_concrete replace
setblock ~117 ~79 ~651 minecraft:light_gray_concrete replace
setblock ~117 ~79 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~79 ~655 minecraft:light_gray_concrete replace
setblock ~120 ~79 ~659 minecraft:light_gray_concrete replace
setblock ~112 ~79 ~660 minecraft:light_gray_concrete replace
fill ~115 ~80 ~380 ~115 ~80 ~381 minecraft:light_gray_concrete replace
fill ~114 ~80 ~382 ~116 ~80 ~382 minecraft:light_gray_concrete replace
fill ~82 ~80 ~392 ~82 ~80 ~393 minecraft:light_gray_concrete replace
fill ~81 ~80 ~394 ~83 ~80 ~394 minecraft:light_gray_concrete replace
fill ~88 ~80 ~596 ~88 ~80 ~597 minecraft:light_gray_concrete replace
fill ~87 ~80 ~598 ~89 ~80 ~598 minecraft:light_gray_concrete replace
fill ~79 ~80 ~600 ~79 ~80 ~601 minecraft:light_gray_concrete replace
fill ~78 ~80 ~602 ~80 ~80 ~602 minecraft:light_gray_concrete replace
fill ~91 ~80 ~604 ~91 ~80 ~605 minecraft:light_gray_concrete replace
fill ~90 ~80 ~606 ~92 ~80 ~606 minecraft:light_gray_concrete replace
fill ~94 ~80 ~608 ~94 ~80 ~609 minecraft:light_gray_concrete replace
fill ~93 ~80 ~610 ~95 ~80 ~610 minecraft:light_gray_concrete replace
fill ~97 ~80 ~612 ~97 ~80 ~613 minecraft:light_gray_concrete replace
fill ~96 ~80 ~614 ~98 ~80 ~614 minecraft:light_gray_concrete replace
fill ~100 ~80 ~616 ~100 ~80 ~617 minecraft:light_gray_concrete replace
fill ~99 ~80 ~618 ~101 ~80 ~618 minecraft:light_gray_concrete replace
fill ~103 ~80 ~620 ~103 ~80 ~621 minecraft:light_gray_concrete replace
fill ~102 ~80 ~622 ~104 ~80 ~622 minecraft:light_gray_concrete replace
fill ~109 ~80 ~624 ~109 ~80 ~625 minecraft:light_gray_concrete replace
fill ~108 ~80 ~626 ~110 ~80 ~626 minecraft:light_gray_concrete replace
fill ~106 ~80 ~632 ~106 ~80 ~633 minecraft:light_gray_concrete replace
fill ~105 ~80 ~634 ~107 ~80 ~634 minecraft:light_gray_concrete replace
fill ~124 ~80 ~640 ~124 ~80 ~641 minecraft:light_gray_concrete replace
fill ~123 ~80 ~642 ~125 ~80 ~642 minecraft:light_gray_concrete replace
fill ~85 ~80 ~644 ~85 ~80 ~645 minecraft:light_gray_concrete replace
fill ~84 ~80 ~646 ~86 ~80 ~646 minecraft:light_gray_concrete replace
fill ~118 ~80 ~648 ~118 ~80 ~649 minecraft:light_gray_concrete replace
fill ~117 ~80 ~650 ~119 ~80 ~650 minecraft:light_gray_concrete replace
fill ~112 ~80 ~652 ~112 ~80 ~653 minecraft:light_gray_concrete replace
fill ~111 ~80 ~654 ~113 ~80 ~654 minecraft:light_gray_concrete replace
fill ~121 ~80 ~656 ~121 ~80 ~657 minecraft:light_gray_concrete replace
fill ~120 ~80 ~658 ~122 ~80 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~81 ~380 minecraft:light_gray_concrete replace
setblock ~82 ~81 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~81 ~596 minecraft:light_gray_concrete replace
setblock ~79 ~81 ~600 minecraft:light_gray_concrete replace
setblock ~91 ~81 ~604 minecraft:light_gray_concrete replace
setblock ~94 ~81 ~608 minecraft:light_gray_concrete replace
setblock ~97 ~81 ~612 minecraft:light_gray_concrete replace
setblock ~100 ~81 ~616 minecraft:light_gray_concrete replace
setblock ~103 ~81 ~620 minecraft:light_gray_concrete replace
setblock ~109 ~81 ~624 minecraft:light_gray_concrete replace
setblock ~106 ~81 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~81 ~640 minecraft:light_gray_concrete replace
setblock ~85 ~81 ~644 minecraft:light_gray_concrete replace
setblock ~118 ~81 ~648 minecraft:light_gray_concrete replace
setblock ~112 ~81 ~652 minecraft:light_gray_concrete replace
setblock ~121 ~81 ~656 minecraft:light_gray_concrete replace
fill ~114 ~82 ~380 ~114 ~82 ~384 minecraft:light_gray_concrete replace
fill ~81 ~82 ~392 ~81 ~82 ~396 minecraft:light_gray_concrete replace
fill ~87 ~82 ~596 ~87 ~82 ~600 minecraft:light_gray_concrete replace
fill ~78 ~82 ~600 ~78 ~82 ~604 minecraft:light_gray_concrete replace
fill ~90 ~82 ~604 ~90 ~82 ~608 minecraft:light_gray_concrete replace
fill ~93 ~82 ~608 ~93 ~82 ~612 minecraft:light_gray_concrete replace
fill ~96 ~82 ~612 ~96 ~82 ~616 minecraft:light_gray_concrete replace
fill ~99 ~82 ~616 ~99 ~82 ~620 minecraft:light_gray_concrete replace
fill ~102 ~82 ~620 ~102 ~82 ~624 minecraft:light_gray_concrete replace
fill ~108 ~82 ~624 ~108 ~82 ~628 minecraft:light_gray_concrete replace
fill ~105 ~82 ~632 ~105 ~82 ~636 minecraft:light_gray_concrete replace
fill ~123 ~82 ~640 ~123 ~82 ~644 minecraft:light_gray_concrete replace
fill ~84 ~82 ~644 ~84 ~82 ~648 minecraft:light_gray_concrete replace
fill ~117 ~82 ~648 ~117 ~82 ~652 minecraft:light_gray_concrete replace
fill ~111 ~82 ~652 ~111 ~82 ~656 minecraft:light_gray_concrete replace
fill ~120 ~82 ~656 ~120 ~82 ~660 minecraft:light_gray_concrete replace
setblock ~114 ~83 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~83 ~397 minecraft:light_gray_concrete replace
setblock ~79 ~83 ~600 minecraft:light_gray_concrete replace
setblock ~87 ~83 ~601 minecraft:light_gray_concrete replace
setblock ~78 ~83 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~83 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~83 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~83 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~83 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~83 ~625 minecraft:light_gray_concrete replace
setblock ~108 ~83 ~629 minecraft:light_gray_concrete replace
setblock ~105 ~83 ~637 minecraft:light_gray_concrete replace
setblock ~123 ~83 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~83 ~649 minecraft:light_gray_concrete replace
setblock ~112 ~83 ~652 minecraft:light_gray_concrete replace
setblock ~117 ~83 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~83 ~657 minecraft:light_gray_concrete replace
setblock ~120 ~83 ~661 minecraft:light_gray_concrete replace
fill ~114 ~84 ~386 ~116 ~84 ~386 minecraft:light_gray_concrete replace
fill ~115 ~84 ~387 ~115 ~84 ~388 minecraft:light_gray_concrete replace
fill ~81 ~84 ~398 ~83 ~84 ~398 minecraft:light_gray_concrete replace
fill ~82 ~84 ~399 ~82 ~84 ~400 minecraft:light_gray_concrete replace
fill ~87 ~84 ~602 ~89 ~84 ~602 minecraft:light_gray_concrete replace
fill ~88 ~84 ~603 ~88 ~84 ~604 minecraft:light_gray_concrete replace
fill ~78 ~84 ~606 ~80 ~84 ~606 minecraft:light_gray_concrete replace
fill ~79 ~84 ~607 ~79 ~84 ~608 minecraft:light_gray_concrete replace
fill ~90 ~84 ~610 ~92 ~84 ~610 minecraft:light_gray_concrete replace
fill ~91 ~84 ~611 ~91 ~84 ~612 minecraft:light_gray_concrete replace
fill ~93 ~84 ~614 ~95 ~84 ~614 minecraft:light_gray_concrete replace
fill ~94 ~84 ~615 ~94 ~84 ~616 minecraft:light_gray_concrete replace
fill ~96 ~84 ~618 ~98 ~84 ~618 minecraft:light_gray_concrete replace
fill ~97 ~84 ~619 ~97 ~84 ~620 minecraft:light_gray_concrete replace
fill ~99 ~84 ~622 ~101 ~84 ~622 minecraft:light_gray_concrete replace
fill ~100 ~84 ~623 ~100 ~84 ~624 minecraft:light_gray_concrete replace
fill ~102 ~84 ~626 ~104 ~84 ~626 minecraft:light_gray_concrete replace
fill ~103 ~84 ~627 ~103 ~84 ~628 minecraft:light_gray_concrete replace
fill ~108 ~84 ~630 ~110 ~84 ~630 minecraft:light_gray_concrete replace
fill ~109 ~84 ~631 ~109 ~84 ~632 minecraft:light_gray_concrete replace
fill ~105 ~84 ~638 ~107 ~84 ~638 minecraft:light_gray_concrete replace
fill ~106 ~84 ~639 ~106 ~84 ~640 minecraft:light_gray_concrete replace
fill ~123 ~84 ~646 ~125 ~84 ~646 minecraft:light_gray_concrete replace
fill ~124 ~84 ~647 ~124 ~84 ~648 minecraft:light_gray_concrete replace
fill ~84 ~84 ~650 ~86 ~84 ~650 minecraft:light_gray_concrete replace
fill ~85 ~84 ~651 ~85 ~84 ~652 minecraft:light_gray_concrete replace
fill ~117 ~84 ~654 ~119 ~84 ~654 minecraft:light_gray_concrete replace
fill ~118 ~84 ~655 ~118 ~84 ~656 minecraft:light_gray_concrete replace
fill ~111 ~84 ~658 ~113 ~84 ~658 minecraft:light_gray_concrete replace
fill ~112 ~84 ~659 ~112 ~84 ~660 minecraft:light_gray_concrete replace
fill ~120 ~84 ~662 ~122 ~84 ~662 minecraft:light_gray_concrete replace
fill ~121 ~84 ~663 ~121 ~84 ~664 minecraft:light_gray_concrete replace
setblock ~115 ~85 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~85 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~85 ~604 minecraft:light_gray_concrete replace
setblock ~79 ~85 ~608 minecraft:light_gray_concrete replace
setblock ~91 ~85 ~612 minecraft:light_gray_concrete replace
setblock ~94 ~85 ~616 minecraft:light_gray_concrete replace
setblock ~97 ~85 ~620 minecraft:light_gray_concrete replace
setblock ~100 ~85 ~624 minecraft:light_gray_concrete replace
setblock ~103 ~85 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~85 ~632 minecraft:light_gray_concrete replace
setblock ~106 ~85 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~85 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~85 ~652 minecraft:light_gray_concrete replace
setblock ~118 ~85 ~656 minecraft:light_gray_concrete replace
setblock ~112 ~85 ~660 minecraft:light_gray_concrete replace
setblock ~121 ~85 ~664 minecraft:light_gray_concrete replace
fill ~114 ~86 ~384 ~114 ~86 ~388 minecraft:light_gray_concrete replace
fill ~81 ~86 ~396 ~81 ~86 ~400 minecraft:light_gray_concrete replace
fill ~87 ~86 ~600 ~87 ~86 ~604 minecraft:light_gray_concrete replace
fill ~78 ~86 ~604 ~78 ~86 ~608 minecraft:light_gray_concrete replace
fill ~90 ~86 ~608 ~90 ~86 ~612 minecraft:light_gray_concrete replace
fill ~93 ~86 ~612 ~93 ~86 ~616 minecraft:light_gray_concrete replace
fill ~96 ~86 ~616 ~96 ~86 ~620 minecraft:light_gray_concrete replace
fill ~99 ~86 ~620 ~99 ~86 ~624 minecraft:light_gray_concrete replace
fill ~102 ~86 ~624 ~102 ~86 ~628 minecraft:light_gray_concrete replace
fill ~108 ~86 ~628 ~108 ~86 ~632 minecraft:light_gray_concrete replace
fill ~105 ~86 ~636 ~105 ~86 ~640 minecraft:light_gray_concrete replace
fill ~123 ~86 ~644 ~123 ~86 ~648 minecraft:light_gray_concrete replace
fill ~84 ~86 ~648 ~84 ~86 ~652 minecraft:light_gray_concrete replace
fill ~117 ~86 ~652 ~117 ~86 ~656 minecraft:light_gray_concrete replace
fill ~111 ~86 ~656 ~111 ~86 ~660 minecraft:light_gray_concrete replace
fill ~120 ~86 ~660 ~120 ~86 ~664 minecraft:light_gray_concrete replace
setblock ~114 ~87 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~87 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~87 ~599 minecraft:light_gray_concrete replace
setblock ~78 ~87 ~603 minecraft:light_gray_concrete replace
setblock ~90 ~87 ~607 minecraft:light_gray_concrete replace
setblock ~93 ~87 ~611 minecraft:light_gray_concrete replace
setblock ~96 ~87 ~615 minecraft:light_gray_concrete replace
setblock ~99 ~87 ~619 minecraft:light_gray_concrete replace
setblock ~102 ~87 ~623 minecraft:light_gray_concrete replace
setblock ~108 ~87 ~627 minecraft:light_gray_concrete replace
setblock ~105 ~87 ~635 minecraft:light_gray_concrete replace
setblock ~123 ~87 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~87 ~647 minecraft:light_gray_concrete replace
setblock ~117 ~87 ~651 minecraft:light_gray_concrete replace
setblock ~111 ~87 ~655 minecraft:light_gray_concrete replace
setblock ~120 ~87 ~659 minecraft:light_gray_concrete replace
setblock ~112 ~87 ~660 minecraft:light_gray_concrete replace
fill ~115 ~88 ~380 ~115 ~88 ~381 minecraft:light_gray_concrete replace
fill ~114 ~88 ~382 ~116 ~88 ~382 minecraft:light_gray_concrete replace
fill ~82 ~88 ~392 ~82 ~88 ~393 minecraft:light_gray_concrete replace
fill ~81 ~88 ~394 ~83 ~88 ~394 minecraft:light_gray_concrete replace
fill ~88 ~88 ~596 ~88 ~88 ~597 minecraft:light_gray_concrete replace
fill ~87 ~88 ~598 ~89 ~88 ~598 minecraft:light_gray_concrete replace
fill ~79 ~88 ~600 ~79 ~88 ~601 minecraft:light_gray_concrete replace
fill ~78 ~88 ~602 ~80 ~88 ~602 minecraft:light_gray_concrete replace
fill ~91 ~88 ~604 ~91 ~88 ~605 minecraft:light_gray_concrete replace
fill ~90 ~88 ~606 ~92 ~88 ~606 minecraft:light_gray_concrete replace
fill ~94 ~88 ~608 ~94 ~88 ~609 minecraft:light_gray_concrete replace
fill ~93 ~88 ~610 ~95 ~88 ~610 minecraft:light_gray_concrete replace
fill ~97 ~88 ~612 ~97 ~88 ~613 minecraft:light_gray_concrete replace
fill ~96 ~88 ~614 ~98 ~88 ~614 minecraft:light_gray_concrete replace
fill ~100 ~88 ~616 ~100 ~88 ~617 minecraft:light_gray_concrete replace
fill ~99 ~88 ~618 ~101 ~88 ~618 minecraft:light_gray_concrete replace
fill ~103 ~88 ~620 ~103 ~88 ~621 minecraft:light_gray_concrete replace
fill ~102 ~88 ~622 ~104 ~88 ~622 minecraft:light_gray_concrete replace
fill ~109 ~88 ~624 ~109 ~88 ~625 minecraft:light_gray_concrete replace
fill ~108 ~88 ~626 ~110 ~88 ~626 minecraft:light_gray_concrete replace
fill ~106 ~88 ~632 ~106 ~88 ~633 minecraft:light_gray_concrete replace
fill ~105 ~88 ~634 ~107 ~88 ~634 minecraft:light_gray_concrete replace
fill ~124 ~88 ~640 ~124 ~88 ~641 minecraft:light_gray_concrete replace
fill ~123 ~88 ~642 ~125 ~88 ~642 minecraft:light_gray_concrete replace
fill ~85 ~88 ~644 ~85 ~88 ~645 minecraft:light_gray_concrete replace
fill ~84 ~88 ~646 ~86 ~88 ~646 minecraft:light_gray_concrete replace
fill ~118 ~88 ~648 ~118 ~88 ~649 minecraft:light_gray_concrete replace
fill ~117 ~88 ~650 ~119 ~88 ~650 minecraft:light_gray_concrete replace
fill ~112 ~88 ~652 ~112 ~88 ~653 minecraft:light_gray_concrete replace
fill ~111 ~88 ~654 ~113 ~88 ~654 minecraft:light_gray_concrete replace
fill ~121 ~88 ~656 ~121 ~88 ~657 minecraft:light_gray_concrete replace
fill ~120 ~88 ~658 ~122 ~88 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~89 ~380 minecraft:light_gray_concrete replace
setblock ~82 ~89 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~89 ~596 minecraft:light_gray_concrete replace
setblock ~79 ~89 ~600 minecraft:light_gray_concrete replace
setblock ~91 ~89 ~604 minecraft:light_gray_concrete replace
setblock ~94 ~89 ~608 minecraft:light_gray_concrete replace
setblock ~97 ~89 ~612 minecraft:light_gray_concrete replace
setblock ~100 ~89 ~616 minecraft:light_gray_concrete replace
setblock ~103 ~89 ~620 minecraft:light_gray_concrete replace
setblock ~109 ~89 ~624 minecraft:light_gray_concrete replace
setblock ~106 ~89 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~89 ~640 minecraft:light_gray_concrete replace
setblock ~85 ~89 ~644 minecraft:light_gray_concrete replace
setblock ~118 ~89 ~648 minecraft:light_gray_concrete replace
setblock ~112 ~89 ~652 minecraft:light_gray_concrete replace
setblock ~121 ~89 ~656 minecraft:light_gray_concrete replace
fill ~114 ~90 ~380 ~114 ~90 ~384 minecraft:light_gray_concrete replace
fill ~81 ~90 ~392 ~81 ~90 ~396 minecraft:light_gray_concrete replace
fill ~87 ~90 ~596 ~87 ~90 ~600 minecraft:light_gray_concrete replace
fill ~78 ~90 ~600 ~78 ~90 ~604 minecraft:light_gray_concrete replace
fill ~90 ~90 ~604 ~90 ~90 ~608 minecraft:light_gray_concrete replace
fill ~93 ~90 ~608 ~93 ~90 ~612 minecraft:light_gray_concrete replace
