setblock ~165 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~151 ~402 ~108 ~151 ~414 minecraft:redstone_wire replace
fill ~111 ~151 ~402 ~111 ~151 ~414 minecraft:redstone_wire replace
fill ~114 ~151 ~402 ~114 ~151 ~414 minecraft:redstone_wire replace
fill ~117 ~151 ~402 ~117 ~151 ~414 minecraft:redstone_wire replace
fill ~120 ~151 ~402 ~120 ~151 ~414 minecraft:redstone_wire replace
fill ~123 ~151 ~402 ~123 ~151 ~414 minecraft:redstone_wire replace
fill ~126 ~151 ~402 ~126 ~151 ~414 minecraft:redstone_wire replace
fill ~129 ~151 ~402 ~129 ~151 ~414 minecraft:redstone_wire replace
fill ~132 ~151 ~402 ~132 ~151 ~414 minecraft:redstone_wire replace
fill ~135 ~151 ~402 ~135 ~151 ~414 minecraft:redstone_wire replace
fill ~138 ~151 ~402 ~138 ~151 ~414 minecraft:redstone_wire replace
fill ~141 ~151 ~402 ~141 ~151 ~414 minecraft:redstone_wire replace
fill ~144 ~151 ~402 ~144 ~151 ~414 minecraft:redstone_wire replace
fill ~147 ~151 ~402 ~147 ~151 ~414 minecraft:redstone_wire replace
fill ~150 ~151 ~402 ~150 ~151 ~414 minecraft:redstone_wire replace
fill ~153 ~151 ~402 ~153 ~151 ~414 minecraft:redstone_wire replace
fill ~156 ~151 ~402 ~156 ~151 ~414 minecraft:redstone_wire replace
fill ~159 ~151 ~402 ~159 ~151 ~414 minecraft:redstone_wire replace
fill ~162 ~151 ~402 ~162 ~151 ~414 minecraft:redstone_wire replace
fill ~165 ~151 ~402 ~165 ~151 ~414 minecraft:redstone_wire replace
fill ~168 ~151 ~402 ~168 ~151 ~414 minecraft:redstone_wire replace
fill ~171 ~151 ~402 ~171 ~151 ~414 minecraft:redstone_wire replace
fill ~174 ~151 ~402 ~174 ~151 ~414 minecraft:redstone_wire replace
fill ~177 ~151 ~402 ~177 ~151 ~414 minecraft:redstone_wire replace
fill ~180 ~151 ~402 ~180 ~151 ~414 minecraft:redstone_wire replace
fill ~183 ~151 ~402 ~183 ~151 ~414 minecraft:redstone_wire replace
fill ~186 ~151 ~402 ~186 ~151 ~414 minecraft:redstone_wire replace
fill ~189 ~151 ~402 ~189 ~151 ~414 minecraft:redstone_wire replace
fill ~192 ~151 ~402 ~192 ~151 ~414 minecraft:redstone_wire replace
fill ~195 ~151 ~402 ~195 ~151 ~414 minecraft:redstone_wire replace
fill ~198 ~151 ~402 ~198 ~151 ~414 minecraft:redstone_wire replace
fill ~201 ~151 ~402 ~201 ~151 ~414 minecraft:redstone_wire replace
fill ~204 ~151 ~402 ~204 ~151 ~414 minecraft:redstone_wire replace
fill ~207 ~151 ~402 ~207 ~151 ~414 minecraft:redstone_wire replace
fill ~210 ~151 ~402 ~210 ~151 ~414 minecraft:redstone_wire replace
fill ~213 ~151 ~402 ~213 ~151 ~414 minecraft:redstone_wire replace
fill ~216 ~151 ~402 ~216 ~151 ~414 minecraft:redstone_wire replace
fill ~219 ~151 ~402 ~219 ~151 ~414 minecraft:redstone_wire replace
fill ~222 ~151 ~402 ~222 ~151 ~414 minecraft:redstone_wire replace
fill ~225 ~151 ~402 ~225 ~151 ~414 minecraft:redstone_wire replace
fill ~228 ~151 ~402 ~228 ~151 ~414 minecraft:redstone_wire replace
setblock ~105 ~151 ~404 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~151 ~406 ~105 ~151 ~414 minecraft:redstone_wire replace
fill ~102 ~151 ~408 ~102 ~151 ~414 minecraft:redstone_wire replace
fill ~99 ~151 ~412 ~99 ~151 ~414 minecraft:redstone_wire replace
setblock ~96 ~151 ~416 minecraft:redstone_wire replace
setblock ~99 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~151 ~418 ~96 ~151 ~430 minecraft:redstone_wire replace
fill ~99 ~151 ~418 ~99 ~151 ~430 minecraft:redstone_wire replace
fill ~102 ~151 ~418 ~102 ~151 ~430 minecraft:redstone_wire replace
fill ~105 ~151 ~418 ~105 ~151 ~430 minecraft:redstone_wire replace
fill ~108 ~151 ~418 ~108 ~151 ~430 minecraft:redstone_wire replace
fill ~111 ~151 ~418 ~111 ~151 ~430 minecraft:redstone_wire replace
fill ~114 ~151 ~418 ~114 ~151 ~430 minecraft:redstone_wire replace
fill ~117 ~151 ~418 ~117 ~151 ~430 minecraft:redstone_wire replace
fill ~120 ~151 ~418 ~120 ~151 ~430 minecraft:redstone_wire replace
fill ~123 ~151 ~418 ~123 ~151 ~430 minecraft:redstone_wire replace
fill ~126 ~151 ~418 ~126 ~151 ~430 minecraft:redstone_wire replace
fill ~129 ~151 ~418 ~129 ~151 ~430 minecraft:redstone_wire replace
fill ~132 ~151 ~418 ~132 ~151 ~430 minecraft:redstone_wire replace
fill ~135 ~151 ~418 ~135 ~151 ~430 minecraft:redstone_wire replace
fill ~138 ~151 ~418 ~138 ~151 ~430 minecraft:redstone_wire replace
fill ~141 ~151 ~418 ~141 ~151 ~430 minecraft:redstone_wire replace
fill ~144 ~151 ~418 ~144 ~151 ~430 minecraft:redstone_wire replace
fill ~147 ~151 ~418 ~147 ~151 ~430 minecraft:redstone_wire replace
fill ~150 ~151 ~418 ~150 ~151 ~430 minecraft:redstone_wire replace
fill ~153 ~151 ~418 ~153 ~151 ~430 minecraft:redstone_wire replace
fill ~156 ~151 ~418 ~156 ~151 ~430 minecraft:redstone_wire replace
fill ~159 ~151 ~418 ~159 ~151 ~430 minecraft:redstone_wire replace
fill ~162 ~151 ~418 ~162 ~151 ~430 minecraft:redstone_wire replace
fill ~165 ~151 ~418 ~165 ~151 ~430 minecraft:redstone_wire replace
fill ~168 ~151 ~418 ~168 ~151 ~430 minecraft:redstone_wire replace
fill ~171 ~151 ~418 ~171 ~151 ~430 minecraft:redstone_wire replace
fill ~174 ~151 ~418 ~174 ~151 ~430 minecraft:redstone_wire replace
fill ~177 ~151 ~418 ~177 ~151 ~430 minecraft:redstone_wire replace
fill ~180 ~151 ~418 ~180 ~151 ~430 minecraft:redstone_wire replace
fill ~183 ~151 ~418 ~183 ~151 ~430 minecraft:redstone_wire replace
fill ~186 ~151 ~418 ~186 ~151 ~430 minecraft:redstone_wire replace
fill ~189 ~151 ~418 ~189 ~151 ~430 minecraft:redstone_wire replace
fill ~192 ~151 ~418 ~192 ~151 ~430 minecraft:redstone_wire replace
fill ~195 ~151 ~418 ~195 ~151 ~430 minecraft:redstone_wire replace
fill ~198 ~151 ~418 ~198 ~151 ~430 minecraft:redstone_wire replace
fill ~201 ~151 ~418 ~201 ~151 ~430 minecraft:redstone_wire replace
fill ~204 ~151 ~418 ~204 ~151 ~430 minecraft:redstone_wire replace
fill ~207 ~151 ~418 ~207 ~151 ~430 minecraft:redstone_wire replace
fill ~210 ~151 ~418 ~210 ~151 ~430 minecraft:redstone_wire replace
fill ~213 ~151 ~418 ~213 ~151 ~430 minecraft:redstone_wire replace
fill ~216 ~151 ~418 ~216 ~151 ~430 minecraft:redstone_wire replace
fill ~219 ~151 ~418 ~219 ~151 ~430 minecraft:redstone_wire replace
fill ~222 ~151 ~418 ~222 ~151 ~430 minecraft:redstone_wire replace
fill ~225 ~151 ~418 ~225 ~151 ~430 minecraft:redstone_wire replace
fill ~228 ~151 ~418 ~228 ~151 ~430 minecraft:redstone_wire replace
setblock ~93 ~151 ~420 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~151 ~422 ~93 ~151 ~430 minecraft:redstone_wire replace
fill ~90 ~151 ~424 ~90 ~151 ~430 minecraft:redstone_wire replace
fill ~87 ~151 ~428 ~87 ~151 ~430 minecraft:redstone_wire replace
setblock ~84 ~151 ~432 minecraft:redstone_wire replace
setblock ~87 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~432 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~84 ~151 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~434 ~84 ~151 ~446 minecraft:redstone_wire replace
fill ~87 ~151 ~434 ~87 ~151 ~446 minecraft:redstone_wire replace
fill ~90 ~151 ~434 ~90 ~151 ~446 minecraft:redstone_wire replace
fill ~93 ~151 ~434 ~93 ~151 ~446 minecraft:redstone_wire replace
fill ~96 ~151 ~434 ~96 ~151 ~446 minecraft:redstone_wire replace
fill ~99 ~151 ~434 ~99 ~151 ~446 minecraft:redstone_wire replace
fill ~102 ~151 ~434 ~102 ~151 ~446 minecraft:redstone_wire replace
fill ~105 ~151 ~434 ~105 ~151 ~446 minecraft:redstone_wire replace
fill ~108 ~151 ~434 ~108 ~151 ~446 minecraft:redstone_wire replace
fill ~111 ~151 ~434 ~111 ~151 ~446 minecraft:redstone_wire replace
fill ~114 ~151 ~434 ~114 ~151 ~446 minecraft:redstone_wire replace
fill ~117 ~151 ~434 ~117 ~151 ~446 minecraft:redstone_wire replace
fill ~120 ~151 ~434 ~120 ~151 ~446 minecraft:redstone_wire replace
fill ~123 ~151 ~434 ~123 ~151 ~446 minecraft:redstone_wire replace
fill ~126 ~151 ~434 ~126 ~151 ~446 minecraft:redstone_wire replace
fill ~129 ~151 ~434 ~129 ~151 ~446 minecraft:redstone_wire replace
fill ~132 ~151 ~434 ~132 ~151 ~446 minecraft:redstone_wire replace
fill ~135 ~151 ~434 ~135 ~151 ~446 minecraft:redstone_wire replace
fill ~138 ~151 ~434 ~138 ~151 ~446 minecraft:redstone_wire replace
fill ~141 ~151 ~434 ~141 ~151 ~446 minecraft:redstone_wire replace
fill ~144 ~151 ~434 ~144 ~151 ~446 minecraft:redstone_wire replace
fill ~147 ~151 ~434 ~147 ~151 ~446 minecraft:redstone_wire replace
fill ~150 ~151 ~434 ~150 ~151 ~446 minecraft:redstone_wire replace
fill ~153 ~151 ~434 ~153 ~151 ~446 minecraft:redstone_wire replace
fill ~156 ~151 ~434 ~156 ~151 ~446 minecraft:redstone_wire replace
fill ~159 ~151 ~434 ~159 ~151 ~446 minecraft:redstone_wire replace
fill ~162 ~151 ~434 ~162 ~151 ~446 minecraft:redstone_wire replace
fill ~165 ~151 ~434 ~165 ~151 ~446 minecraft:redstone_wire replace
fill ~168 ~151 ~434 ~168 ~151 ~446 minecraft:redstone_wire replace
fill ~171 ~151 ~434 ~171 ~151 ~446 minecraft:redstone_wire replace
fill ~174 ~151 ~434 ~174 ~151 ~446 minecraft:redstone_wire replace
fill ~177 ~151 ~434 ~177 ~151 ~446 minecraft:redstone_wire replace
fill ~180 ~151 ~434 ~180 ~151 ~446 minecraft:redstone_wire replace
fill ~183 ~151 ~434 ~183 ~151 ~446 minecraft:redstone_wire replace
fill ~186 ~151 ~434 ~186 ~151 ~446 minecraft:redstone_wire replace
fill ~189 ~151 ~434 ~189 ~151 ~446 minecraft:redstone_wire replace
fill ~192 ~151 ~434 ~192 ~151 ~446 minecraft:redstone_wire replace
fill ~195 ~151 ~434 ~195 ~151 ~446 minecraft:redstone_wire replace
fill ~198 ~151 ~434 ~198 ~151 ~446 minecraft:redstone_wire replace
fill ~201 ~151 ~434 ~201 ~151 ~446 minecraft:redstone_wire replace
fill ~204 ~151 ~434 ~204 ~151 ~446 minecraft:redstone_wire replace
fill ~207 ~151 ~434 ~207 ~151 ~446 minecraft:redstone_wire replace
fill ~210 ~151 ~434 ~210 ~151 ~446 minecraft:redstone_wire replace
fill ~213 ~151 ~434 ~213 ~151 ~446 minecraft:redstone_wire replace
fill ~216 ~151 ~434 ~216 ~151 ~446 minecraft:redstone_wire replace
fill ~219 ~151 ~434 ~219 ~151 ~446 minecraft:redstone_wire replace
fill ~222 ~151 ~434 ~222 ~151 ~446 minecraft:redstone_wire replace
fill ~225 ~151 ~434 ~225 ~151 ~446 minecraft:redstone_wire replace
fill ~228 ~151 ~434 ~228 ~151 ~446 minecraft:redstone_wire replace
setblock ~84 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~447 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~151 ~448 ~78 ~151 ~452 minecraft:redstone_wire replace
fill ~84 ~151 ~448 ~84 ~151 ~460 minecraft:redstone_wire replace
fill ~87 ~151 ~448 ~87 ~151 ~460 minecraft:redstone_wire replace
fill ~90 ~151 ~448 ~90 ~151 ~460 minecraft:redstone_wire replace
fill ~93 ~151 ~448 ~93 ~151 ~460 minecraft:redstone_wire replace
fill ~96 ~151 ~448 ~96 ~151 ~460 minecraft:redstone_wire replace
fill ~99 ~151 ~448 ~99 ~151 ~460 minecraft:redstone_wire replace
fill ~102 ~151 ~448 ~102 ~151 ~460 minecraft:redstone_wire replace
fill ~105 ~151 ~448 ~105 ~151 ~460 minecraft:redstone_wire replace
fill ~108 ~151 ~448 ~108 ~151 ~460 minecraft:redstone_wire replace
fill ~111 ~151 ~448 ~111 ~151 ~460 minecraft:redstone_wire replace
fill ~114 ~151 ~448 ~114 ~151 ~460 minecraft:redstone_wire replace
fill ~117 ~151 ~448 ~117 ~151 ~460 minecraft:redstone_wire replace
fill ~120 ~151 ~448 ~120 ~151 ~460 minecraft:redstone_wire replace
fill ~123 ~151 ~448 ~123 ~151 ~460 minecraft:redstone_wire replace
fill ~126 ~151 ~448 ~126 ~151 ~460 minecraft:redstone_wire replace
fill ~129 ~151 ~448 ~129 ~151 ~460 minecraft:redstone_wire replace
fill ~132 ~151 ~448 ~132 ~151 ~460 minecraft:redstone_wire replace
fill ~135 ~151 ~448 ~135 ~151 ~460 minecraft:redstone_wire replace
fill ~138 ~151 ~448 ~138 ~151 ~460 minecraft:redstone_wire replace
fill ~141 ~151 ~448 ~141 ~151 ~460 minecraft:redstone_wire replace
fill ~144 ~151 ~448 ~144 ~151 ~460 minecraft:redstone_wire replace
fill ~147 ~151 ~448 ~147 ~151 ~460 minecraft:redstone_wire replace
fill ~150 ~151 ~448 ~150 ~151 ~460 minecraft:redstone_wire replace
fill ~153 ~151 ~448 ~153 ~151 ~460 minecraft:redstone_wire replace
fill ~156 ~151 ~448 ~156 ~151 ~460 minecraft:redstone_wire replace
fill ~159 ~151 ~448 ~159 ~151 ~460 minecraft:redstone_wire replace
fill ~162 ~151 ~448 ~162 ~151 ~460 minecraft:redstone_wire replace
fill ~165 ~151 ~448 ~165 ~151 ~460 minecraft:redstone_wire replace
fill ~168 ~151 ~448 ~168 ~151 ~460 minecraft:redstone_wire replace
fill ~171 ~151 ~448 ~171 ~151 ~460 minecraft:redstone_wire replace
fill ~174 ~151 ~448 ~174 ~151 ~460 minecraft:redstone_wire replace
fill ~177 ~151 ~448 ~177 ~151 ~460 minecraft:redstone_wire replace
fill ~180 ~151 ~448 ~180 ~151 ~460 minecraft:redstone_wire replace
fill ~183 ~151 ~448 ~183 ~151 ~460 minecraft:redstone_wire replace
fill ~186 ~151 ~448 ~186 ~151 ~460 minecraft:redstone_wire replace
fill ~189 ~151 ~448 ~189 ~151 ~460 minecraft:redstone_wire replace
fill ~192 ~151 ~448 ~192 ~151 ~460 minecraft:redstone_wire replace
fill ~195 ~151 ~448 ~195 ~151 ~460 minecraft:redstone_wire replace
fill ~198 ~151 ~448 ~198 ~151 ~460 minecraft:redstone_wire replace
fill ~201 ~151 ~448 ~201 ~151 ~460 minecraft:redstone_wire replace
fill ~204 ~151 ~448 ~204 ~151 ~460 minecraft:redstone_wire replace
fill ~207 ~151 ~448 ~207 ~151 ~460 minecraft:redstone_wire replace
fill ~210 ~151 ~448 ~210 ~151 ~460 minecraft:redstone_wire replace
fill ~213 ~151 ~448 ~213 ~151 ~460 minecraft:redstone_wire replace
fill ~216 ~151 ~448 ~216 ~151 ~460 minecraft:redstone_wire replace
fill ~219 ~151 ~448 ~219 ~151 ~460 minecraft:redstone_wire replace
fill ~222 ~151 ~448 ~222 ~151 ~460 minecraft:redstone_wire replace
fill ~225 ~151 ~448 ~225 ~151 ~460 minecraft:redstone_wire replace
fill ~228 ~151 ~448 ~228 ~151 ~460 minecraft:redstone_wire replace
setblock ~84 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~464 ~84 ~151 ~476 minecraft:redstone_wire replace
fill ~87 ~151 ~464 ~87 ~151 ~476 minecraft:redstone_wire replace
fill ~90 ~151 ~464 ~90 ~151 ~476 minecraft:redstone_wire replace
fill ~93 ~151 ~464 ~93 ~151 ~476 minecraft:redstone_wire replace
fill ~96 ~151 ~464 ~96 ~151 ~476 minecraft:redstone_wire replace
fill ~99 ~151 ~464 ~99 ~151 ~476 minecraft:redstone_wire replace
fill ~102 ~151 ~464 ~102 ~151 ~476 minecraft:redstone_wire replace
fill ~105 ~151 ~464 ~105 ~151 ~476 minecraft:redstone_wire replace
fill ~108 ~151 ~464 ~108 ~151 ~476 minecraft:redstone_wire replace
fill ~111 ~151 ~464 ~111 ~151 ~476 minecraft:redstone_wire replace
fill ~114 ~151 ~464 ~114 ~151 ~476 minecraft:redstone_wire replace
fill ~117 ~151 ~464 ~117 ~151 ~476 minecraft:redstone_wire replace
fill ~120 ~151 ~464 ~120 ~151 ~476 minecraft:redstone_wire replace
fill ~123 ~151 ~464 ~123 ~151 ~476 minecraft:redstone_wire replace
fill ~126 ~151 ~464 ~126 ~151 ~476 minecraft:redstone_wire replace
fill ~129 ~151 ~464 ~129 ~151 ~476 minecraft:redstone_wire replace
fill ~132 ~151 ~464 ~132 ~151 ~476 minecraft:redstone_wire replace
fill ~135 ~151 ~464 ~135 ~151 ~476 minecraft:redstone_wire replace
fill ~138 ~151 ~464 ~138 ~151 ~476 minecraft:redstone_wire replace
fill ~141 ~151 ~464 ~141 ~151 ~476 minecraft:redstone_wire replace
fill ~144 ~151 ~464 ~144 ~151 ~476 minecraft:redstone_wire replace
fill ~147 ~151 ~464 ~147 ~151 ~476 minecraft:redstone_wire replace
fill ~150 ~151 ~464 ~150 ~151 ~476 minecraft:redstone_wire replace
fill ~153 ~151 ~464 ~153 ~151 ~476 minecraft:redstone_wire replace
fill ~156 ~151 ~464 ~156 ~151 ~476 minecraft:redstone_wire replace
fill ~159 ~151 ~464 ~159 ~151 ~476 minecraft:redstone_wire replace
fill ~162 ~151 ~464 ~162 ~151 ~476 minecraft:redstone_wire replace
fill ~165 ~151 ~464 ~165 ~151 ~476 minecraft:redstone_wire replace
fill ~168 ~151 ~464 ~168 ~151 ~476 minecraft:redstone_wire replace
fill ~171 ~151 ~464 ~171 ~151 ~476 minecraft:redstone_wire replace
fill ~174 ~151 ~464 ~174 ~151 ~476 minecraft:redstone_wire replace
fill ~177 ~151 ~464 ~177 ~151 ~476 minecraft:redstone_wire replace
fill ~180 ~151 ~464 ~180 ~151 ~476 minecraft:redstone_wire replace
fill ~183 ~151 ~464 ~183 ~151 ~476 minecraft:redstone_wire replace
fill ~186 ~151 ~464 ~186 ~151 ~476 minecraft:redstone_wire replace
fill ~189 ~151 ~464 ~189 ~151 ~476 minecraft:redstone_wire replace
fill ~192 ~151 ~464 ~192 ~151 ~476 minecraft:redstone_wire replace
fill ~195 ~151 ~464 ~195 ~151 ~476 minecraft:redstone_wire replace
fill ~198 ~151 ~464 ~198 ~151 ~476 minecraft:redstone_wire replace
fill ~201 ~151 ~464 ~201 ~151 ~476 minecraft:redstone_wire replace
fill ~204 ~151 ~464 ~204 ~151 ~476 minecraft:redstone_wire replace
fill ~207 ~151 ~464 ~207 ~151 ~476 minecraft:redstone_wire replace
fill ~210 ~151 ~464 ~210 ~151 ~476 minecraft:redstone_wire replace
fill ~213 ~151 ~464 ~213 ~151 ~476 minecraft:redstone_wire replace
fill ~216 ~151 ~464 ~216 ~151 ~476 minecraft:redstone_wire replace
fill ~219 ~151 ~464 ~219 ~151 ~476 minecraft:redstone_wire replace
fill ~222 ~151 ~464 ~222 ~151 ~476 minecraft:redstone_wire replace
fill ~225 ~151 ~464 ~225 ~151 ~476 minecraft:redstone_wire replace
fill ~228 ~151 ~464 ~228 ~151 ~476 minecraft:redstone_wire replace
setblock ~246 ~151 ~476 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~84 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~478 ~246 ~151 ~486 minecraft:redstone_wire replace
fill ~84 ~151 ~480 ~84 ~151 ~492 minecraft:redstone_wire replace
fill ~87 ~151 ~480 ~87 ~151 ~492 minecraft:redstone_wire replace
fill ~90 ~151 ~480 ~90 ~151 ~492 minecraft:redstone_wire replace
fill ~93 ~151 ~480 ~93 ~151 ~492 minecraft:redstone_wire replace
fill ~96 ~151 ~480 ~96 ~151 ~492 minecraft:redstone_wire replace
fill ~99 ~151 ~480 ~99 ~151 ~492 minecraft:redstone_wire replace
fill ~102 ~151 ~480 ~102 ~151 ~492 minecraft:redstone_wire replace
fill ~105 ~151 ~480 ~105 ~151 ~492 minecraft:redstone_wire replace
fill ~108 ~151 ~480 ~108 ~151 ~492 minecraft:redstone_wire replace
fill ~111 ~151 ~480 ~111 ~151 ~492 minecraft:redstone_wire replace
fill ~114 ~151 ~480 ~114 ~151 ~492 minecraft:redstone_wire replace
fill ~117 ~151 ~480 ~117 ~151 ~492 minecraft:redstone_wire replace
fill ~120 ~151 ~480 ~120 ~151 ~492 minecraft:redstone_wire replace
fill ~123 ~151 ~480 ~123 ~151 ~492 minecraft:redstone_wire replace
fill ~126 ~151 ~480 ~126 ~151 ~492 minecraft:redstone_wire replace
fill ~129 ~151 ~480 ~129 ~151 ~492 minecraft:redstone_wire replace
fill ~132 ~151 ~480 ~132 ~151 ~492 minecraft:redstone_wire replace
fill ~135 ~151 ~480 ~135 ~151 ~492 minecraft:redstone_wire replace
fill ~138 ~151 ~480 ~138 ~151 ~492 minecraft:redstone_wire replace
fill ~141 ~151 ~480 ~141 ~151 ~492 minecraft:redstone_wire replace
fill ~144 ~151 ~480 ~144 ~151 ~492 minecraft:redstone_wire replace
fill ~147 ~151 ~480 ~147 ~151 ~492 minecraft:redstone_wire replace
fill ~150 ~151 ~480 ~150 ~151 ~492 minecraft:redstone_wire replace
fill ~153 ~151 ~480 ~153 ~151 ~492 minecraft:redstone_wire replace
fill ~156 ~151 ~480 ~156 ~151 ~492 minecraft:redstone_wire replace
fill ~159 ~151 ~480 ~159 ~151 ~492 minecraft:redstone_wire replace
fill ~162 ~151 ~480 ~162 ~151 ~492 minecraft:redstone_wire replace
fill ~165 ~151 ~480 ~165 ~151 ~492 minecraft:redstone_wire replace
fill ~168 ~151 ~480 ~168 ~151 ~492 minecraft:redstone_wire replace
fill ~171 ~151 ~480 ~171 ~151 ~492 minecraft:redstone_wire replace
fill ~174 ~151 ~480 ~174 ~151 ~492 minecraft:redstone_wire replace
fill ~177 ~151 ~480 ~177 ~151 ~492 minecraft:redstone_wire replace
fill ~180 ~151 ~480 ~180 ~151 ~492 minecraft:redstone_wire replace
fill ~183 ~151 ~480 ~183 ~151 ~492 minecraft:redstone_wire replace
fill ~186 ~151 ~480 ~186 ~151 ~492 minecraft:redstone_wire replace
fill ~189 ~151 ~480 ~189 ~151 ~492 minecraft:redstone_wire replace
fill ~192 ~151 ~480 ~192 ~151 ~492 minecraft:redstone_wire replace
fill ~195 ~151 ~480 ~195 ~151 ~492 minecraft:redstone_wire replace
fill ~198 ~151 ~480 ~198 ~151 ~492 minecraft:redstone_wire replace
fill ~201 ~151 ~480 ~201 ~151 ~492 minecraft:redstone_wire replace
fill ~204 ~151 ~480 ~204 ~151 ~492 minecraft:redstone_wire replace
fill ~207 ~151 ~480 ~207 ~151 ~492 minecraft:redstone_wire replace
fill ~210 ~151 ~480 ~210 ~151 ~492 minecraft:redstone_wire replace
fill ~213 ~151 ~480 ~213 ~151 ~492 minecraft:redstone_wire replace
fill ~216 ~151 ~480 ~216 ~151 ~492 minecraft:redstone_wire replace
fill ~219 ~151 ~480 ~219 ~151 ~492 minecraft:redstone_wire replace
fill ~222 ~151 ~480 ~222 ~151 ~492 minecraft:redstone_wire replace
fill ~225 ~151 ~480 ~225 ~151 ~492 minecraft:redstone_wire replace
fill ~228 ~151 ~480 ~228 ~151 ~492 minecraft:redstone_wire replace
fill ~234 ~151 ~480 ~234 ~151 ~484 minecraft:redstone_wire replace
setblock ~246 ~151 ~488 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~490 ~246 ~151 ~502 minecraft:redstone_wire replace
setblock ~84 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
