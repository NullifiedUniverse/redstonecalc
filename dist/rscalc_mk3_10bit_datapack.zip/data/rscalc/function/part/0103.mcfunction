fill ~426 ~155 ~664 ~426 ~155 ~676 minecraft:redstone_wire replace
setblock ~429 ~155 ~670 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~670 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~672 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~672 ~429 ~155 ~684 minecraft:redstone_wire replace
fill ~432 ~155 ~672 ~432 ~155 ~684 minecraft:redstone_wire replace
setblock ~402 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~674 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~675 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~676 minecraft:redstone_wire replace
setblock ~216 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~676 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~676 ~402 ~155 ~688 minecraft:redstone_wire replace
fill ~405 ~155 ~676 ~405 ~155 ~688 minecraft:redstone_wire replace
fill ~408 ~155 ~676 ~408 ~155 ~688 minecraft:redstone_wire replace
fill ~411 ~155 ~676 ~411 ~155 ~688 minecraft:redstone_wire replace
fill ~414 ~155 ~676 ~414 ~155 ~688 minecraft:redstone_wire replace
fill ~417 ~155 ~676 ~417 ~155 ~688 minecraft:redstone_wire replace
fill ~420 ~155 ~676 ~420 ~155 ~688 minecraft:redstone_wire replace
fill ~423 ~155 ~676 ~423 ~155 ~688 minecraft:redstone_wire replace
fill ~216 ~155 ~678 ~216 ~155 ~680 minecraft:redstone_wire replace
fill ~219 ~155 ~678 ~219 ~155 ~684 minecraft:redstone_wire replace
fill ~222 ~155 ~678 ~222 ~155 ~686 minecraft:redstone_wire replace
fill ~225 ~155 ~678 ~225 ~155 ~690 minecraft:redstone_wire replace
fill ~228 ~155 ~678 ~228 ~155 ~690 minecraft:redstone_wire replace
fill ~231 ~155 ~678 ~231 ~155 ~690 minecraft:redstone_wire replace
fill ~234 ~155 ~678 ~234 ~155 ~690 minecraft:redstone_wire replace
fill ~237 ~155 ~678 ~237 ~155 ~690 minecraft:redstone_wire replace
fill ~240 ~155 ~678 ~240 ~155 ~690 minecraft:redstone_wire replace
fill ~243 ~155 ~678 ~243 ~155 ~690 minecraft:redstone_wire replace
fill ~246 ~155 ~678 ~246 ~155 ~690 minecraft:redstone_wire replace
fill ~249 ~155 ~678 ~249 ~155 ~690 minecraft:redstone_wire replace
fill ~252 ~155 ~678 ~252 ~155 ~690 minecraft:redstone_wire replace
fill ~255 ~155 ~678 ~255 ~155 ~690 minecraft:redstone_wire replace
fill ~258 ~155 ~678 ~258 ~155 ~690 minecraft:redstone_wire replace
fill ~261 ~155 ~678 ~261 ~155 ~690 minecraft:redstone_wire replace
fill ~264 ~155 ~678 ~264 ~155 ~690 minecraft:redstone_wire replace
fill ~267 ~155 ~678 ~267 ~155 ~690 minecraft:redstone_wire replace
fill ~270 ~155 ~678 ~270 ~155 ~690 minecraft:redstone_wire replace
fill ~273 ~155 ~678 ~273 ~155 ~690 minecraft:redstone_wire replace
fill ~276 ~155 ~678 ~276 ~155 ~690 minecraft:redstone_wire replace
fill ~279 ~155 ~678 ~279 ~155 ~690 minecraft:redstone_wire replace
fill ~282 ~155 ~678 ~282 ~155 ~690 minecraft:redstone_wire replace
fill ~285 ~155 ~678 ~285 ~155 ~690 minecraft:redstone_wire replace
fill ~288 ~155 ~678 ~288 ~155 ~690 minecraft:redstone_wire replace
fill ~291 ~155 ~678 ~291 ~155 ~690 minecraft:redstone_wire replace
fill ~294 ~155 ~678 ~294 ~155 ~690 minecraft:redstone_wire replace
fill ~297 ~155 ~678 ~297 ~155 ~690 minecraft:redstone_wire replace
fill ~300 ~155 ~678 ~300 ~155 ~690 minecraft:redstone_wire replace
fill ~303 ~155 ~678 ~303 ~155 ~690 minecraft:redstone_wire replace
fill ~306 ~155 ~678 ~306 ~155 ~690 minecraft:redstone_wire replace
fill ~309 ~155 ~678 ~309 ~155 ~690 minecraft:redstone_wire replace
fill ~312 ~155 ~678 ~312 ~155 ~690 minecraft:redstone_wire replace
fill ~315 ~155 ~678 ~315 ~155 ~690 minecraft:redstone_wire replace
fill ~318 ~155 ~678 ~318 ~155 ~690 minecraft:redstone_wire replace
fill ~321 ~155 ~678 ~321 ~155 ~690 minecraft:redstone_wire replace
fill ~324 ~155 ~678 ~324 ~155 ~690 minecraft:redstone_wire replace
fill ~327 ~155 ~678 ~327 ~155 ~690 minecraft:redstone_wire replace
fill ~330 ~155 ~678 ~330 ~155 ~690 minecraft:redstone_wire replace
fill ~333 ~155 ~678 ~333 ~155 ~690 minecraft:redstone_wire replace
fill ~336 ~155 ~678 ~336 ~155 ~690 minecraft:redstone_wire replace
fill ~339 ~155 ~678 ~339 ~155 ~690 minecraft:redstone_wire replace
fill ~342 ~155 ~678 ~342 ~155 ~690 minecraft:redstone_wire replace
fill ~345 ~155 ~678 ~345 ~155 ~690 minecraft:redstone_wire replace
fill ~348 ~155 ~678 ~348 ~155 ~690 minecraft:redstone_wire replace
fill ~351 ~155 ~678 ~351 ~155 ~690 minecraft:redstone_wire replace
fill ~354 ~155 ~678 ~354 ~155 ~690 minecraft:redstone_wire replace
fill ~357 ~155 ~678 ~357 ~155 ~690 minecraft:redstone_wire replace
fill ~360 ~155 ~678 ~360 ~155 ~690 minecraft:redstone_wire replace
fill ~363 ~155 ~678 ~363 ~155 ~690 minecraft:redstone_wire replace
fill ~366 ~155 ~678 ~366 ~155 ~690 minecraft:redstone_wire replace
fill ~369 ~155 ~678 ~369 ~155 ~690 minecraft:redstone_wire replace
fill ~372 ~155 ~678 ~372 ~155 ~690 minecraft:redstone_wire replace
fill ~375 ~155 ~678 ~375 ~155 ~690 minecraft:redstone_wire replace
fill ~378 ~155 ~678 ~378 ~155 ~690 minecraft:redstone_wire replace
fill ~381 ~155 ~678 ~381 ~155 ~690 minecraft:redstone_wire replace
fill ~384 ~155 ~678 ~384 ~155 ~690 minecraft:redstone_wire replace
fill ~387 ~155 ~678 ~387 ~155 ~690 minecraft:redstone_wire replace
fill ~390 ~155 ~678 ~390 ~155 ~690 minecraft:redstone_wire replace
fill ~393 ~155 ~678 ~393 ~155 ~690 minecraft:redstone_wire replace
fill ~396 ~155 ~678 ~396 ~155 ~690 minecraft:redstone_wire replace
fill ~399 ~155 ~678 ~399 ~155 ~690 minecraft:redstone_wire replace
setblock ~426 ~155 ~678 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~680 ~426 ~155 ~692 minecraft:redstone_wire replace
setblock ~429 ~155 ~686 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~686 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~688 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~688 ~429 ~155 ~700 minecraft:redstone_wire replace
fill ~432 ~155 ~688 ~432 ~155 ~700 minecraft:redstone_wire replace
setblock ~402 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~690 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~691 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~692 minecraft:redstone_wire replace
setblock ~228 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~692 ~402 ~155 ~704 minecraft:redstone_wire replace
fill ~405 ~155 ~692 ~405 ~155 ~704 minecraft:redstone_wire replace
fill ~408 ~155 ~692 ~408 ~155 ~704 minecraft:redstone_wire replace
fill ~411 ~155 ~692 ~411 ~155 ~704 minecraft:redstone_wire replace
fill ~414 ~155 ~692 ~414 ~155 ~704 minecraft:redstone_wire replace
fill ~417 ~155 ~692 ~417 ~155 ~704 minecraft:redstone_wire replace
fill ~420 ~155 ~692 ~420 ~155 ~704 minecraft:redstone_wire replace
fill ~423 ~155 ~692 ~423 ~155 ~704 minecraft:redstone_wire replace
fill ~228 ~155 ~694 ~228 ~155 ~696 minecraft:redstone_wire replace
fill ~231 ~155 ~694 ~231 ~155 ~700 minecraft:redstone_wire replace
fill ~234 ~155 ~694 ~234 ~155 ~702 minecraft:redstone_wire replace
fill ~237 ~155 ~694 ~237 ~155 ~706 minecraft:redstone_wire replace
fill ~240 ~155 ~694 ~240 ~155 ~706 minecraft:redstone_wire replace
fill ~243 ~155 ~694 ~243 ~155 ~706 minecraft:redstone_wire replace
fill ~246 ~155 ~694 ~246 ~155 ~706 minecraft:redstone_wire replace
fill ~249 ~155 ~694 ~249 ~155 ~706 minecraft:redstone_wire replace
fill ~252 ~155 ~694 ~252 ~155 ~706 minecraft:redstone_wire replace
fill ~255 ~155 ~694 ~255 ~155 ~706 minecraft:redstone_wire replace
fill ~258 ~155 ~694 ~258 ~155 ~706 minecraft:redstone_wire replace
fill ~261 ~155 ~694 ~261 ~155 ~706 minecraft:redstone_wire replace
fill ~264 ~155 ~694 ~264 ~155 ~706 minecraft:redstone_wire replace
fill ~267 ~155 ~694 ~267 ~155 ~706 minecraft:redstone_wire replace
fill ~270 ~155 ~694 ~270 ~155 ~706 minecraft:redstone_wire replace
fill ~273 ~155 ~694 ~273 ~155 ~706 minecraft:redstone_wire replace
fill ~276 ~155 ~694 ~276 ~155 ~706 minecraft:redstone_wire replace
fill ~279 ~155 ~694 ~279 ~155 ~706 minecraft:redstone_wire replace
fill ~282 ~155 ~694 ~282 ~155 ~706 minecraft:redstone_wire replace
fill ~285 ~155 ~694 ~285 ~155 ~706 minecraft:redstone_wire replace
fill ~288 ~155 ~694 ~288 ~155 ~706 minecraft:redstone_wire replace
fill ~291 ~155 ~694 ~291 ~155 ~706 minecraft:redstone_wire replace
fill ~294 ~155 ~694 ~294 ~155 ~706 minecraft:redstone_wire replace
fill ~297 ~155 ~694 ~297 ~155 ~706 minecraft:redstone_wire replace
fill ~300 ~155 ~694 ~300 ~155 ~706 minecraft:redstone_wire replace
fill ~303 ~155 ~694 ~303 ~155 ~706 minecraft:redstone_wire replace
fill ~306 ~155 ~694 ~306 ~155 ~706 minecraft:redstone_wire replace
fill ~309 ~155 ~694 ~309 ~155 ~706 minecraft:redstone_wire replace
fill ~312 ~155 ~694 ~312 ~155 ~706 minecraft:redstone_wire replace
fill ~315 ~155 ~694 ~315 ~155 ~706 minecraft:redstone_wire replace
fill ~318 ~155 ~694 ~318 ~155 ~706 minecraft:redstone_wire replace
fill ~321 ~155 ~694 ~321 ~155 ~706 minecraft:redstone_wire replace
fill ~324 ~155 ~694 ~324 ~155 ~706 minecraft:redstone_wire replace
fill ~327 ~155 ~694 ~327 ~155 ~706 minecraft:redstone_wire replace
fill ~330 ~155 ~694 ~330 ~155 ~706 minecraft:redstone_wire replace
fill ~333 ~155 ~694 ~333 ~155 ~706 minecraft:redstone_wire replace
fill ~336 ~155 ~694 ~336 ~155 ~706 minecraft:redstone_wire replace
fill ~339 ~155 ~694 ~339 ~155 ~706 minecraft:redstone_wire replace
fill ~342 ~155 ~694 ~342 ~155 ~706 minecraft:redstone_wire replace
fill ~345 ~155 ~694 ~345 ~155 ~706 minecraft:redstone_wire replace
fill ~348 ~155 ~694 ~348 ~155 ~706 minecraft:redstone_wire replace
fill ~351 ~155 ~694 ~351 ~155 ~706 minecraft:redstone_wire replace
fill ~354 ~155 ~694 ~354 ~155 ~706 minecraft:redstone_wire replace
fill ~357 ~155 ~694 ~357 ~155 ~706 minecraft:redstone_wire replace
fill ~360 ~155 ~694 ~360 ~155 ~706 minecraft:redstone_wire replace
fill ~363 ~155 ~694 ~363 ~155 ~706 minecraft:redstone_wire replace
fill ~366 ~155 ~694 ~366 ~155 ~706 minecraft:redstone_wire replace
fill ~369 ~155 ~694 ~369 ~155 ~706 minecraft:redstone_wire replace
fill ~372 ~155 ~694 ~372 ~155 ~706 minecraft:redstone_wire replace
fill ~375 ~155 ~694 ~375 ~155 ~706 minecraft:redstone_wire replace
fill ~378 ~155 ~694 ~378 ~155 ~706 minecraft:redstone_wire replace
fill ~381 ~155 ~694 ~381 ~155 ~706 minecraft:redstone_wire replace
fill ~384 ~155 ~694 ~384 ~155 ~706 minecraft:redstone_wire replace
fill ~387 ~155 ~694 ~387 ~155 ~706 minecraft:redstone_wire replace
fill ~390 ~155 ~694 ~390 ~155 ~706 minecraft:redstone_wire replace
fill ~393 ~155 ~694 ~393 ~155 ~706 minecraft:redstone_wire replace
fill ~396 ~155 ~694 ~396 ~155 ~706 minecraft:redstone_wire replace
fill ~399 ~155 ~694 ~399 ~155 ~706 minecraft:redstone_wire replace
setblock ~426 ~155 ~694 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~696 ~426 ~155 ~708 minecraft:redstone_wire replace
setblock ~429 ~155 ~702 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~702 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~704 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~704 ~429 ~155 ~716 minecraft:redstone_wire replace
fill ~432 ~155 ~704 ~432 ~155 ~716 minecraft:redstone_wire replace
setblock ~402 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~707 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~708 minecraft:redstone_wire replace
setblock ~240 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~708 ~402 ~155 ~720 minecraft:redstone_wire replace
fill ~405 ~155 ~708 ~405 ~155 ~720 minecraft:redstone_wire replace
fill ~408 ~155 ~708 ~408 ~155 ~720 minecraft:redstone_wire replace
fill ~411 ~155 ~708 ~411 ~155 ~720 minecraft:redstone_wire replace
fill ~414 ~155 ~708 ~414 ~155 ~720 minecraft:redstone_wire replace
fill ~417 ~155 ~708 ~417 ~155 ~720 minecraft:redstone_wire replace
fill ~420 ~155 ~708 ~420 ~155 ~720 minecraft:redstone_wire replace
fill ~423 ~155 ~708 ~423 ~155 ~720 minecraft:redstone_wire replace
fill ~240 ~155 ~710 ~240 ~155 ~712 minecraft:redstone_wire replace
fill ~243 ~155 ~710 ~243 ~155 ~716 minecraft:redstone_wire replace
fill ~246 ~155 ~710 ~246 ~155 ~718 minecraft:redstone_wire replace
fill ~249 ~155 ~710 ~249 ~155 ~722 minecraft:redstone_wire replace
fill ~252 ~155 ~710 ~252 ~155 ~722 minecraft:redstone_wire replace
fill ~255 ~155 ~710 ~255 ~155 ~722 minecraft:redstone_wire replace
fill ~258 ~155 ~710 ~258 ~155 ~722 minecraft:redstone_wire replace
fill ~261 ~155 ~710 ~261 ~155 ~722 minecraft:redstone_wire replace
fill ~264 ~155 ~710 ~264 ~155 ~722 minecraft:redstone_wire replace
fill ~267 ~155 ~710 ~267 ~155 ~722 minecraft:redstone_wire replace
fill ~270 ~155 ~710 ~270 ~155 ~722 minecraft:redstone_wire replace
fill ~273 ~155 ~710 ~273 ~155 ~722 minecraft:redstone_wire replace
fill ~276 ~155 ~710 ~276 ~155 ~722 minecraft:redstone_wire replace
fill ~279 ~155 ~710 ~279 ~155 ~722 minecraft:redstone_wire replace
fill ~282 ~155 ~710 ~282 ~155 ~722 minecraft:redstone_wire replace
fill ~285 ~155 ~710 ~285 ~155 ~722 minecraft:redstone_wire replace
fill ~288 ~155 ~710 ~288 ~155 ~722 minecraft:redstone_wire replace
fill ~291 ~155 ~710 ~291 ~155 ~722 minecraft:redstone_wire replace
fill ~294 ~155 ~710 ~294 ~155 ~722 minecraft:redstone_wire replace
fill ~297 ~155 ~710 ~297 ~155 ~722 minecraft:redstone_wire replace
fill ~300 ~155 ~710 ~300 ~155 ~722 minecraft:redstone_wire replace
fill ~303 ~155 ~710 ~303 ~155 ~722 minecraft:redstone_wire replace
fill ~306 ~155 ~710 ~306 ~155 ~722 minecraft:redstone_wire replace
fill ~309 ~155 ~710 ~309 ~155 ~722 minecraft:redstone_wire replace
fill ~312 ~155 ~710 ~312 ~155 ~722 minecraft:redstone_wire replace
fill ~315 ~155 ~710 ~315 ~155 ~722 minecraft:redstone_wire replace
fill ~318 ~155 ~710 ~318 ~155 ~722 minecraft:redstone_wire replace
fill ~321 ~155 ~710 ~321 ~155 ~722 minecraft:redstone_wire replace
fill ~324 ~155 ~710 ~324 ~155 ~722 minecraft:redstone_wire replace
fill ~327 ~155 ~710 ~327 ~155 ~722 minecraft:redstone_wire replace
fill ~330 ~155 ~710 ~330 ~155 ~722 minecraft:redstone_wire replace
fill ~333 ~155 ~710 ~333 ~155 ~722 minecraft:redstone_wire replace
fill ~336 ~155 ~710 ~336 ~155 ~722 minecraft:redstone_wire replace
fill ~339 ~155 ~710 ~339 ~155 ~722 minecraft:redstone_wire replace
fill ~342 ~155 ~710 ~342 ~155 ~722 minecraft:redstone_wire replace
fill ~345 ~155 ~710 ~345 ~155 ~722 minecraft:redstone_wire replace
fill ~348 ~155 ~710 ~348 ~155 ~722 minecraft:redstone_wire replace
fill ~351 ~155 ~710 ~351 ~155 ~722 minecraft:redstone_wire replace
fill ~354 ~155 ~710 ~354 ~155 ~722 minecraft:redstone_wire replace
fill ~357 ~155 ~710 ~357 ~155 ~722 minecraft:redstone_wire replace
fill ~360 ~155 ~710 ~360 ~155 ~722 minecraft:redstone_wire replace
fill ~363 ~155 ~710 ~363 ~155 ~722 minecraft:redstone_wire replace
fill ~366 ~155 ~710 ~366 ~155 ~722 minecraft:redstone_wire replace
fill ~369 ~155 ~710 ~369 ~155 ~722 minecraft:redstone_wire replace
fill ~372 ~155 ~710 ~372 ~155 ~722 minecraft:redstone_wire replace
fill ~375 ~155 ~710 ~375 ~155 ~722 minecraft:redstone_wire replace
fill ~378 ~155 ~710 ~378 ~155 ~722 minecraft:redstone_wire replace
fill ~381 ~155 ~710 ~381 ~155 ~722 minecraft:redstone_wire replace
fill ~384 ~155 ~710 ~384 ~155 ~722 minecraft:redstone_wire replace
fill ~387 ~155 ~710 ~387 ~155 ~722 minecraft:redstone_wire replace
fill ~390 ~155 ~710 ~390 ~155 ~722 minecraft:redstone_wire replace
fill ~393 ~155 ~710 ~393 ~155 ~722 minecraft:redstone_wire replace
fill ~396 ~155 ~710 ~396 ~155 ~722 minecraft:redstone_wire replace
fill ~399 ~155 ~710 ~399 ~155 ~722 minecraft:redstone_wire replace
setblock ~426 ~155 ~710 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~712 ~426 ~155 ~724 minecraft:redstone_wire replace
setblock ~429 ~155 ~718 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~718 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~720 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~720 ~429 ~155 ~732 minecraft:redstone_wire replace
fill ~432 ~155 ~720 ~432 ~155 ~732 minecraft:redstone_wire replace
setblock ~402 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~723 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~724 minecraft:redstone_wire replace
setblock ~252 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~724 ~402 ~155 ~730 minecraft:redstone_wire replace
fill ~405 ~155 ~724 ~405 ~155 ~734 minecraft:redstone_wire replace
fill ~408 ~155 ~724 ~408 ~155 ~736 minecraft:redstone_wire replace
fill ~411 ~155 ~724 ~411 ~155 ~736 minecraft:redstone_wire replace
fill ~414 ~155 ~724 ~414 ~155 ~736 minecraft:redstone_wire replace
fill ~417 ~155 ~724 ~417 ~155 ~736 minecraft:redstone_wire replace
fill ~420 ~155 ~724 ~420 ~155 ~736 minecraft:redstone_wire replace
fill ~423 ~155 ~724 ~423 ~155 ~736 minecraft:redstone_wire replace
fill ~252 ~155 ~726 ~252 ~155 ~728 minecraft:redstone_wire replace
fill ~255 ~155 ~726 ~255 ~155 ~738 minecraft:redstone_wire replace
fill ~258 ~155 ~726 ~258 ~155 ~738 minecraft:redstone_wire replace
fill ~261 ~155 ~726 ~261 ~155 ~738 minecraft:redstone_wire replace
fill ~264 ~155 ~726 ~264 ~155 ~738 minecraft:redstone_wire replace
fill ~267 ~155 ~726 ~267 ~155 ~738 minecraft:redstone_wire replace
fill ~270 ~155 ~726 ~270 ~155 ~738 minecraft:redstone_wire replace
fill ~273 ~155 ~726 ~273 ~155 ~738 minecraft:redstone_wire replace
fill ~276 ~155 ~726 ~276 ~155 ~738 minecraft:redstone_wire replace
fill ~279 ~155 ~726 ~279 ~155 ~738 minecraft:redstone_wire replace
fill ~282 ~155 ~726 ~282 ~155 ~738 minecraft:redstone_wire replace
fill ~285 ~155 ~726 ~285 ~155 ~738 minecraft:redstone_wire replace
fill ~288 ~155 ~726 ~288 ~155 ~738 minecraft:redstone_wire replace
fill ~291 ~155 ~726 ~291 ~155 ~738 minecraft:redstone_wire replace
fill ~294 ~155 ~726 ~294 ~155 ~738 minecraft:redstone_wire replace
fill ~297 ~155 ~726 ~297 ~155 ~738 minecraft:redstone_wire replace
fill ~300 ~155 ~726 ~300 ~155 ~738 minecraft:redstone_wire replace
fill ~303 ~155 ~726 ~303 ~155 ~738 minecraft:redstone_wire replace
fill ~306 ~155 ~726 ~306 ~155 ~738 minecraft:redstone_wire replace
fill ~309 ~155 ~726 ~309 ~155 ~738 minecraft:redstone_wire replace
fill ~312 ~155 ~726 ~312 ~155 ~738 minecraft:redstone_wire replace
fill ~315 ~155 ~726 ~315 ~155 ~738 minecraft:redstone_wire replace
fill ~318 ~155 ~726 ~318 ~155 ~738 minecraft:redstone_wire replace
fill ~321 ~155 ~726 ~321 ~155 ~738 minecraft:redstone_wire replace
fill ~324 ~155 ~726 ~324 ~155 ~738 minecraft:redstone_wire replace
fill ~327 ~155 ~726 ~327 ~155 ~738 minecraft:redstone_wire replace
fill ~330 ~155 ~726 ~330 ~155 ~738 minecraft:redstone_wire replace
fill ~333 ~155 ~726 ~333 ~155 ~738 minecraft:redstone_wire replace
fill ~336 ~155 ~726 ~336 ~155 ~738 minecraft:redstone_wire replace
fill ~339 ~155 ~726 ~339 ~155 ~738 minecraft:redstone_wire replace
fill ~342 ~155 ~726 ~342 ~155 ~738 minecraft:redstone_wire replace
fill ~345 ~155 ~726 ~345 ~155 ~738 minecraft:redstone_wire replace
fill ~348 ~155 ~726 ~348 ~155 ~738 minecraft:redstone_wire replace
fill ~351 ~155 ~726 ~351 ~155 ~738 minecraft:redstone_wire replace
fill ~354 ~155 ~726 ~354 ~155 ~738 minecraft:redstone_wire replace
fill ~357 ~155 ~726 ~357 ~155 ~738 minecraft:redstone_wire replace
fill ~360 ~155 ~726 ~360 ~155 ~738 minecraft:redstone_wire replace
fill ~363 ~155 ~726 ~363 ~155 ~738 minecraft:redstone_wire replace
fill ~366 ~155 ~726 ~366 ~155 ~738 minecraft:redstone_wire replace
fill ~369 ~155 ~726 ~369 ~155 ~738 minecraft:redstone_wire replace
fill ~372 ~155 ~726 ~372 ~155 ~738 minecraft:redstone_wire replace
fill ~375 ~155 ~726 ~375 ~155 ~738 minecraft:redstone_wire replace
fill ~378 ~155 ~726 ~378 ~155 ~738 minecraft:redstone_wire replace
fill ~381 ~155 ~726 ~381 ~155 ~738 minecraft:redstone_wire replace
fill ~384 ~155 ~726 ~384 ~155 ~738 minecraft:redstone_wire replace
fill ~387 ~155 ~726 ~387 ~155 ~738 minecraft:redstone_wire replace
fill ~390 ~155 ~726 ~390 ~155 ~738 minecraft:redstone_wire replace
fill ~393 ~155 ~726 ~393 ~155 ~738 minecraft:redstone_wire replace
fill ~396 ~155 ~726 ~396 ~155 ~738 minecraft:redstone_wire replace
fill ~399 ~155 ~726 ~399 ~155 ~738 minecraft:redstone_wire replace
setblock ~426 ~155 ~726 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~728 ~426 ~155 ~740 minecraft:redstone_wire replace
setblock ~402 ~155 ~732 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~429 ~155 ~734 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~734 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~736 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~736 ~429 ~155 ~748 minecraft:redstone_wire replace
fill ~432 ~155 ~736 ~432 ~155 ~748 minecraft:redstone_wire replace
setblock ~408 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
