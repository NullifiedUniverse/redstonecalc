setblock ~151 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~57 ~422 ~159 ~57 ~422 minecraft:redstone_wire replace
setblock ~91 ~57 ~425 minecraft:redstone_wire replace
fill ~90 ~57 ~426 ~102 ~57 ~426 minecraft:redstone_wire replace
setblock ~104 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~57 ~426 ~119 ~57 ~426 minecraft:redstone_wire replace
setblock ~121 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~57 ~426 ~136 ~57 ~426 minecraft:redstone_wire replace
setblock ~138 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~57 ~426 ~153 ~57 ~426 minecraft:redstone_wire replace
setblock ~155 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~57 ~426 ~170 ~57 ~426 minecraft:redstone_wire replace
setblock ~172 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~426 ~180 ~57 ~426 minecraft:redstone_wire replace
setblock ~112 ~57 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~57 ~430 ~115 ~57 ~430 minecraft:redstone_wire replace
setblock ~117 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~57 ~430 ~131 ~57 ~430 minecraft:redstone_wire replace
setblock ~133 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~57 ~430 ~147 ~57 ~430 minecraft:redstone_wire replace
setblock ~149 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~57 ~430 ~163 ~57 ~430 minecraft:redstone_wire replace
setblock ~165 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~57 ~430 ~179 ~57 ~430 minecraft:redstone_wire replace
setblock ~181 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~57 ~430 ~195 ~57 ~430 minecraft:redstone_wire replace
setblock ~197 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~57 ~430 ~204 ~57 ~430 minecraft:redstone_wire replace
setblock ~136 ~57 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~57 ~434 ~136 ~57 ~434 minecraft:redstone_wire replace
setblock ~138 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~57 ~434 ~153 ~57 ~434 minecraft:redstone_wire replace
setblock ~155 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~57 ~434 ~170 ~57 ~434 minecraft:redstone_wire replace
setblock ~172 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~434 ~187 ~57 ~434 minecraft:redstone_wire replace
setblock ~189 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~57 ~434 ~204 ~57 ~434 minecraft:redstone_wire replace
setblock ~206 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~57 ~434 ~221 ~57 ~434 minecraft:redstone_wire replace
setblock ~223 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~57 ~434 ~231 ~57 ~434 minecraft:redstone_wire replace
setblock ~157 ~57 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~57 ~438 ~160 ~57 ~438 minecraft:redstone_wire replace
setblock ~162 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~57 ~438 ~177 ~57 ~438 minecraft:redstone_wire replace
setblock ~179 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~57 ~438 ~194 ~57 ~438 minecraft:redstone_wire replace
setblock ~196 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~57 ~438 ~211 ~57 ~438 minecraft:redstone_wire replace
setblock ~213 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~57 ~438 ~228 ~57 ~438 minecraft:redstone_wire replace
setblock ~230 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~57 ~438 ~245 ~57 ~438 minecraft:redstone_wire replace
setblock ~247 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~57 ~438 ~255 ~57 ~438 minecraft:redstone_wire replace
setblock ~166 ~57 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~57 ~442 ~172 ~57 ~442 minecraft:redstone_wire replace
setblock ~174 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~57 ~442 ~189 ~57 ~442 minecraft:redstone_wire replace
setblock ~191 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~57 ~442 ~206 ~57 ~442 minecraft:redstone_wire replace
setblock ~208 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~442 ~223 ~57 ~442 minecraft:redstone_wire replace
setblock ~225 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~57 ~442 ~240 ~57 ~442 minecraft:redstone_wire replace
setblock ~242 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~57 ~442 ~257 ~57 ~442 minecraft:redstone_wire replace
setblock ~259 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~57 ~442 ~267 ~57 ~442 minecraft:redstone_wire replace
setblock ~79 ~57 ~445 minecraft:redstone_wire replace
fill ~78 ~57 ~446 ~79 ~57 ~446 minecraft:redstone_wire replace
setblock ~80 ~57 ~446 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~81 ~57 ~446 ~87 ~57 ~446 minecraft:redstone_wire replace
setblock ~82 ~57 ~449 minecraft:redstone_wire replace
fill ~81 ~57 ~450 ~84 ~57 ~450 minecraft:redstone_wire replace
setblock ~86 ~57 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~57 ~450 ~101 ~57 ~450 minecraft:redstone_wire replace
setblock ~103 ~57 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~450 ~111 ~57 ~450 minecraft:redstone_wire replace
setblock ~85 ~57 ~453 minecraft:redstone_wire replace
fill ~84 ~57 ~454 ~88 ~57 ~454 minecraft:redstone_wire replace
setblock ~90 ~57 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~57 ~454 ~105 ~57 ~454 minecraft:redstone_wire replace
setblock ~107 ~57 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~57 ~454 ~122 ~57 ~454 minecraft:redstone_wire replace
setblock ~124 ~57 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~454 ~132 ~57 ~454 minecraft:redstone_wire replace
setblock ~88 ~57 ~457 minecraft:redstone_wire replace
fill ~87 ~57 ~458 ~95 ~57 ~458 minecraft:redstone_wire replace
setblock ~97 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~57 ~458 ~112 ~57 ~458 minecraft:redstone_wire replace
setblock ~114 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~57 ~458 ~129 ~57 ~458 minecraft:redstone_wire replace
setblock ~131 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~57 ~458 ~146 ~57 ~458 minecraft:redstone_wire replace
setblock ~148 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~57 ~458 ~156 ~57 ~458 minecraft:redstone_wire replace
setblock ~91 ~57 ~461 minecraft:redstone_wire replace
fill ~90 ~57 ~462 ~99 ~57 ~462 minecraft:redstone_wire replace
setblock ~101 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~57 ~462 ~116 ~57 ~462 minecraft:redstone_wire replace
setblock ~118 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~57 ~462 ~133 ~57 ~462 minecraft:redstone_wire replace
setblock ~135 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~57 ~462 ~150 ~57 ~462 minecraft:redstone_wire replace
setblock ~152 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~462 ~167 ~57 ~462 minecraft:redstone_wire replace
setblock ~169 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~57 ~462 ~177 ~57 ~462 minecraft:redstone_wire replace
setblock ~109 ~57 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~57 ~466 ~112 ~57 ~466 minecraft:redstone_wire replace
setblock ~114 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~57 ~466 ~128 ~57 ~466 minecraft:redstone_wire replace
setblock ~130 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~57 ~466 ~144 ~57 ~466 minecraft:redstone_wire replace
setblock ~146 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~57 ~466 ~160 ~57 ~466 minecraft:redstone_wire replace
setblock ~162 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~57 ~466 ~176 ~57 ~466 minecraft:redstone_wire replace
setblock ~178 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~57 ~466 ~192 ~57 ~466 minecraft:redstone_wire replace
setblock ~194 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~57 ~466 ~201 ~57 ~466 minecraft:redstone_wire replace
setblock ~130 ~57 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~57 ~470 ~130 ~57 ~470 minecraft:redstone_wire replace
setblock ~132 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~57 ~470 ~147 ~57 ~470 minecraft:redstone_wire replace
setblock ~149 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~57 ~470 ~164 ~57 ~470 minecraft:redstone_wire replace
setblock ~166 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~57 ~470 ~181 ~57 ~470 minecraft:redstone_wire replace
setblock ~183 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~57 ~470 ~198 ~57 ~470 minecraft:redstone_wire replace
setblock ~200 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~470 ~215 ~57 ~470 minecraft:redstone_wire replace
setblock ~217 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~57 ~470 ~225 ~57 ~470 minecraft:redstone_wire replace
setblock ~154 ~57 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~57 ~474 ~157 ~57 ~474 minecraft:redstone_wire replace
setblock ~159 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~57 ~474 ~174 ~57 ~474 minecraft:redstone_wire replace
setblock ~176 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~57 ~474 ~191 ~57 ~474 minecraft:redstone_wire replace
setblock ~193 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~57 ~474 ~208 ~57 ~474 minecraft:redstone_wire replace
setblock ~210 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~57 ~474 ~225 ~57 ~474 minecraft:redstone_wire replace
setblock ~227 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~57 ~474 ~242 ~57 ~474 minecraft:redstone_wire replace
setblock ~244 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~57 ~474 ~252 ~57 ~474 minecraft:redstone_wire replace
setblock ~181 ~57 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~57 ~478 ~193 ~57 ~478 minecraft:redstone_wire replace
setblock ~195 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~57 ~478 ~210 ~57 ~478 minecraft:redstone_wire replace
setblock ~212 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~57 ~478 ~227 ~57 ~478 minecraft:redstone_wire replace
setblock ~229 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~57 ~478 ~244 ~57 ~478 minecraft:redstone_wire replace
setblock ~246 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~248 ~57 ~478 ~261 ~57 ~478 minecraft:redstone_wire replace
setblock ~263 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~57 ~478 ~278 ~57 ~478 minecraft:redstone_wire replace
setblock ~280 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~57 ~478 ~288 ~57 ~478 minecraft:redstone_wire replace
setblock ~205 ~57 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~57 ~482 ~205 ~57 ~482 minecraft:redstone_wire replace
setblock ~206 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~57 ~482 ~220 ~57 ~482 minecraft:redstone_wire replace
setblock ~222 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~57 ~482 ~237 ~57 ~482 minecraft:redstone_wire replace
setblock ~239 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~57 ~482 ~254 ~57 ~482 minecraft:redstone_wire replace
setblock ~256 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~57 ~482 ~271 ~57 ~482 minecraft:redstone_wire replace
setblock ~273 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~57 ~482 ~288 ~57 ~482 minecraft:redstone_wire replace
setblock ~290 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~57 ~482 ~305 ~57 ~482 minecraft:redstone_wire replace
setblock ~307 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~309 ~57 ~482 ~315 ~57 ~482 minecraft:redstone_wire replace
setblock ~79 ~57 ~485 minecraft:redstone_wire replace
fill ~78 ~57 ~486 ~84 ~57 ~486 minecraft:redstone_wire replace
setblock ~82 ~57 ~489 minecraft:redstone_wire replace
fill ~81 ~57 ~490 ~83 ~57 ~490 minecraft:redstone_wire replace
setblock ~84 ~57 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~57 ~490 ~98 ~57 ~490 minecraft:redstone_wire replace
setblock ~100 ~57 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~57 ~490 ~108 ~57 ~490 minecraft:redstone_wire replace
setblock ~85 ~57 ~493 minecraft:redstone_wire replace
fill ~84 ~57 ~494 ~85 ~57 ~494 minecraft:redstone_wire replace
setblock ~87 ~57 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~89 ~57 ~494 ~102 ~57 ~494 minecraft:redstone_wire replace
setblock ~104 ~57 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~57 ~494 ~119 ~57 ~494 minecraft:redstone_wire replace
setblock ~121 ~57 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~57 ~494 ~129 ~57 ~494 minecraft:redstone_wire replace
setblock ~88 ~57 ~497 minecraft:redstone_wire replace
fill ~87 ~57 ~498 ~89 ~57 ~498 minecraft:redstone_wire replace
setblock ~91 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~57 ~498 ~106 ~57 ~498 minecraft:redstone_wire replace
setblock ~108 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~57 ~498 ~123 ~57 ~498 minecraft:redstone_wire replace
setblock ~125 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~57 ~498 ~140 ~57 ~498 minecraft:redstone_wire replace
setblock ~142 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~57 ~498 ~150 ~57 ~498 minecraft:redstone_wire replace
setblock ~91 ~57 ~501 minecraft:redstone_wire replace
fill ~90 ~57 ~502 ~96 ~57 ~502 minecraft:redstone_wire replace
setblock ~98 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~57 ~502 ~113 ~57 ~502 minecraft:redstone_wire replace
setblock ~115 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~57 ~502 ~130 ~57 ~502 minecraft:redstone_wire replace
setblock ~132 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~57 ~502 ~147 ~57 ~502 minecraft:redstone_wire replace
setblock ~149 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~57 ~502 ~164 ~57 ~502 minecraft:redstone_wire replace
setblock ~166 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~57 ~502 ~174 ~57 ~502 minecraft:redstone_wire replace
setblock ~106 ~57 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~57 ~506 ~109 ~57 ~506 minecraft:redstone_wire replace
setblock ~111 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~57 ~506 ~125 ~57 ~506 minecraft:redstone_wire replace
setblock ~127 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~506 ~141 ~57 ~506 minecraft:redstone_wire replace
setblock ~143 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~57 ~506 ~157 ~57 ~506 minecraft:redstone_wire replace
setblock ~159 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~57 ~506 ~173 ~57 ~506 minecraft:redstone_wire replace
setblock ~175 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~57 ~506 ~189 ~57 ~506 minecraft:redstone_wire replace
setblock ~191 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~57 ~506 ~198 ~57 ~506 minecraft:redstone_wire replace
setblock ~127 ~57 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~57 ~510 ~127 ~57 ~510 minecraft:redstone_wire replace
setblock ~129 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~57 ~510 ~144 ~57 ~510 minecraft:redstone_wire replace
setblock ~146 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~57 ~510 ~161 ~57 ~510 minecraft:redstone_wire replace
setblock ~163 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~57 ~510 ~178 ~57 ~510 minecraft:redstone_wire replace
setblock ~180 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~57 ~510 ~195 ~57 ~510 minecraft:redstone_wire replace
setblock ~197 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~57 ~510 ~212 ~57 ~510 minecraft:redstone_wire replace
setblock ~214 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~57 ~510 ~222 ~57 ~510 minecraft:redstone_wire replace
setblock ~151 ~57 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~57 ~514 ~154 ~57 ~514 minecraft:redstone_wire replace
setblock ~156 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~57 ~514 ~171 ~57 ~514 minecraft:redstone_wire replace
setblock ~173 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~57 ~514 ~188 ~57 ~514 minecraft:redstone_wire replace
setblock ~190 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~57 ~514 ~205 ~57 ~514 minecraft:redstone_wire replace
setblock ~207 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~57 ~514 ~222 ~57 ~514 minecraft:redstone_wire replace
setblock ~224 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~57 ~514 ~239 ~57 ~514 minecraft:redstone_wire replace
setblock ~241 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~57 ~514 ~249 ~57 ~514 minecraft:redstone_wire replace
setblock ~178 ~57 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~57 ~518 ~190 ~57 ~518 minecraft:redstone_wire replace
setblock ~192 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~57 ~518 ~207 ~57 ~518 minecraft:redstone_wire replace
setblock ~209 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~57 ~518 ~224 ~57 ~518 minecraft:redstone_wire replace
setblock ~226 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~57 ~518 ~241 ~57 ~518 minecraft:redstone_wire replace
setblock ~243 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~57 ~518 ~258 ~57 ~518 minecraft:redstone_wire replace
setblock ~260 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~57 ~518 ~275 ~57 ~518 minecraft:redstone_wire replace
setblock ~277 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~57 ~518 ~285 ~57 ~518 minecraft:redstone_wire replace
setblock ~202 ~57 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~57 ~522 ~202 ~57 ~522 minecraft:redstone_wire replace
setblock ~203 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~57 ~522 ~217 ~57 ~522 minecraft:redstone_wire replace
setblock ~219 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~57 ~522 ~234 ~57 ~522 minecraft:redstone_wire replace
setblock ~236 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~57 ~522 ~251 ~57 ~522 minecraft:redstone_wire replace
setblock ~253 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~57 ~522 ~268 ~57 ~522 minecraft:redstone_wire replace
setblock ~270 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~57 ~522 ~285 ~57 ~522 minecraft:redstone_wire replace
setblock ~287 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~57 ~522 ~302 ~57 ~522 minecraft:redstone_wire replace
setblock ~304 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~57 ~522 ~312 ~57 ~522 minecraft:redstone_wire replace
setblock ~79 ~57 ~525 minecraft:redstone_wire replace
fill ~78 ~57 ~526 ~81 ~57 ~526 minecraft:redstone_wire replace
setblock ~82 ~57 ~529 minecraft:redstone_wire replace
setblock ~81 ~57 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~82 ~57 ~530 ~95 ~57 ~530 minecraft:redstone_wire replace
setblock ~97 ~57 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~57 ~530 ~105 ~57 ~530 minecraft:redstone_wire replace
setblock ~85 ~57 ~533 minecraft:redstone_wire replace
fill ~84 ~57 ~534 ~85 ~57 ~534 minecraft:redstone_wire replace
setblock ~87 ~57 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~89 ~57 ~534 ~101 ~57 ~534 minecraft:redstone_wire replace
setblock ~103 ~57 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~534 ~117 ~57 ~534 minecraft:redstone_wire replace
setblock ~119 ~57 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~57 ~534 ~126 ~57 ~534 minecraft:redstone_wire replace
setblock ~88 ~57 ~537 minecraft:redstone_wire replace
fill ~87 ~57 ~538 ~88 ~57 ~538 minecraft:redstone_wire replace
setblock ~89 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~57 ~538 ~103 ~57 ~538 minecraft:redstone_wire replace
setblock ~105 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~57 ~538 ~120 ~57 ~538 minecraft:redstone_wire replace
setblock ~122 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~57 ~538 ~137 ~57 ~538 minecraft:redstone_wire replace
setblock ~139 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~57 ~538 ~147 ~57 ~538 minecraft:redstone_wire replace
setblock ~91 ~57 ~541 minecraft:redstone_wire replace
fill ~90 ~57 ~542 ~93 ~57 ~542 minecraft:redstone_wire replace
setblock ~95 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~57 ~542 ~110 ~57 ~542 minecraft:redstone_wire replace
setblock ~112 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~57 ~542 ~127 ~57 ~542 minecraft:redstone_wire replace
setblock ~129 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~57 ~542 ~144 ~57 ~542 minecraft:redstone_wire replace
setblock ~146 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~57 ~542 ~161 ~57 ~542 minecraft:redstone_wire replace
setblock ~163 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~57 ~542 ~171 ~57 ~542 minecraft:redstone_wire replace
setblock ~103 ~57 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~57 ~546 ~106 ~57 ~546 minecraft:redstone_wire replace
setblock ~108 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~57 ~546 ~122 ~57 ~546 minecraft:redstone_wire replace
setblock ~124 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~546 ~138 ~57 ~546 minecraft:redstone_wire replace
setblock ~140 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~57 ~546 ~154 ~57 ~546 minecraft:redstone_wire replace
setblock ~156 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~57 ~546 ~170 ~57 ~546 minecraft:redstone_wire replace
setblock ~172 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~546 ~186 ~57 ~546 minecraft:redstone_wire replace
setblock ~188 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~57 ~546 ~195 ~57 ~546 minecraft:redstone_wire replace
setblock ~124 ~57 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~57 ~550 ~124 ~57 ~550 minecraft:redstone_wire replace
setblock ~126 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~57 ~550 ~141 ~57 ~550 minecraft:redstone_wire replace
setblock ~143 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~57 ~550 ~158 ~57 ~550 minecraft:redstone_wire replace
setblock ~160 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~57 ~550 ~175 ~57 ~550 minecraft:redstone_wire replace
setblock ~177 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~57 ~550 ~192 ~57 ~550 minecraft:redstone_wire replace
setblock ~194 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~57 ~550 ~209 ~57 ~550 minecraft:redstone_wire replace
setblock ~211 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~57 ~550 ~219 ~57 ~550 minecraft:redstone_wire replace
setblock ~145 ~57 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~57 ~554 ~148 ~57 ~554 minecraft:redstone_wire replace
setblock ~150 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~57 ~554 ~165 ~57 ~554 minecraft:redstone_wire replace
setblock ~167 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~57 ~554 ~182 ~57 ~554 minecraft:redstone_wire replace
setblock ~184 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~57 ~554 ~199 ~57 ~554 minecraft:redstone_wire replace
setblock ~201 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~57 ~554 ~216 ~57 ~554 minecraft:redstone_wire replace
setblock ~218 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~57 ~554 ~233 ~57 ~554 minecraft:redstone_wire replace
setblock ~235 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~57 ~554 ~243 ~57 ~554 minecraft:redstone_wire replace
setblock ~175 ~57 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~57 ~558 ~187 ~57 ~558 minecraft:redstone_wire replace
setblock ~189 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~57 ~558 ~204 ~57 ~558 minecraft:redstone_wire replace
setblock ~206 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~57 ~558 ~221 ~57 ~558 minecraft:redstone_wire replace
setblock ~223 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~57 ~558 ~238 ~57 ~558 minecraft:redstone_wire replace
setblock ~240 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~57 ~558 ~255 ~57 ~558 minecraft:redstone_wire replace
setblock ~257 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~57 ~558 ~272 ~57 ~558 minecraft:redstone_wire replace
setblock ~274 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~57 ~558 ~282 ~57 ~558 minecraft:redstone_wire replace
setblock ~196 ~57 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~57 ~562 ~208 ~57 ~562 minecraft:redstone_wire replace
setblock ~210 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~57 ~562 ~225 ~57 ~562 minecraft:redstone_wire replace
setblock ~227 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~57 ~562 ~242 ~57 ~562 minecraft:redstone_wire replace
setblock ~244 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~57 ~562 ~259 ~57 ~562 minecraft:redstone_wire replace
setblock ~261 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~57 ~562 ~276 ~57 ~562 minecraft:redstone_wire replace
setblock ~278 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~57 ~562 ~293 ~57 ~562 minecraft:redstone_wire replace
setblock ~295 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~57 ~562 ~303 ~57 ~562 minecraft:redstone_wire replace
setblock ~79 ~57 ~565 minecraft:redstone_wire replace
fill ~78 ~57 ~566 ~80 ~57 ~566 minecraft:redstone_wire replace
setblock ~82 ~57 ~569 minecraft:redstone_wire replace
fill ~81 ~57 ~570 ~92 ~57 ~570 minecraft:redstone_wire replace
setblock ~94 ~57 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~96 ~57 ~570 ~102 ~57 ~570 minecraft:redstone_wire replace
setblock ~85 ~57 ~573 minecraft:redstone_wire replace
fill ~84 ~57 ~574 ~96 ~57 ~574 minecraft:redstone_wire replace
setblock ~98 ~57 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~57 ~574 ~113 ~57 ~574 minecraft:redstone_wire replace
setblock ~115 ~57 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~57 ~574 ~123 ~57 ~574 minecraft:redstone_wire replace
setblock ~88 ~57 ~577 minecraft:redstone_wire replace
fill ~87 ~57 ~578 ~100 ~57 ~578 minecraft:redstone_wire replace
setblock ~102 ~57 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~57 ~578 ~117 ~57 ~578 minecraft:redstone_wire replace
setblock ~119 ~57 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~57 ~578 ~134 ~57 ~578 minecraft:redstone_wire replace
setblock ~136 ~57 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~57 ~578 ~144 ~57 ~578 minecraft:redstone_wire replace
setblock ~91 ~57 ~581 minecraft:redstone_wire replace
setblock ~90 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~91 ~57 ~582 ~104 ~57 ~582 minecraft:redstone_wire replace
setblock ~106 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~57 ~582 ~121 ~57 ~582 minecraft:redstone_wire replace
setblock ~123 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~57 ~582 ~138 ~57 ~582 minecraft:redstone_wire replace
setblock ~140 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~57 ~582 ~155 ~57 ~582 minecraft:redstone_wire replace
setblock ~157 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~57 ~582 ~165 ~57 ~582 minecraft:redstone_wire replace
setblock ~97 ~57 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~57 ~586 ~108 ~57 ~586 minecraft:redstone_wire replace
setblock ~110 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~57 ~586 ~125 ~57 ~586 minecraft:redstone_wire replace
setblock ~127 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~586 ~142 ~57 ~586 minecraft:redstone_wire replace
setblock ~144 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~57 ~586 ~159 ~57 ~586 minecraft:redstone_wire replace
setblock ~161 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~57 ~586 ~176 ~57 ~586 minecraft:redstone_wire replace
setblock ~178 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~57 ~586 ~186 ~57 ~586 minecraft:redstone_wire replace
setblock ~121 ~57 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~57 ~590 ~121 ~57 ~590 minecraft:redstone_wire replace
setblock ~123 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~57 ~590 ~138 ~57 ~590 minecraft:redstone_wire replace
setblock ~140 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~57 ~590 ~155 ~57 ~590 minecraft:redstone_wire replace
setblock ~157 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~57 ~590 ~172 ~57 ~590 minecraft:redstone_wire replace
setblock ~174 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~57 ~590 ~189 ~57 ~590 minecraft:redstone_wire replace
setblock ~191 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~57 ~590 ~206 ~57 ~590 minecraft:redstone_wire replace
setblock ~208 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~590 ~216 ~57 ~590 minecraft:redstone_wire replace
setblock ~142 ~57 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~57 ~594 ~145 ~57 ~594 minecraft:redstone_wire replace
setblock ~147 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~57 ~594 ~162 ~57 ~594 minecraft:redstone_wire replace
setblock ~164 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~57 ~594 ~179 ~57 ~594 minecraft:redstone_wire replace
setblock ~181 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~57 ~594 ~196 ~57 ~594 minecraft:redstone_wire replace
setblock ~198 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~57 ~594 ~213 ~57 ~594 minecraft:redstone_wire replace
setblock ~215 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~57 ~594 ~230 ~57 ~594 minecraft:redstone_wire replace
setblock ~232 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~57 ~594 ~240 ~57 ~594 minecraft:redstone_wire replace
setblock ~172 ~57 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~57 ~598 ~184 ~57 ~598 minecraft:redstone_wire replace
setblock ~186 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~57 ~598 ~201 ~57 ~598 minecraft:redstone_wire replace
setblock ~203 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~57 ~598 ~218 ~57 ~598 minecraft:redstone_wire replace
setblock ~220 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~57 ~598 ~235 ~57 ~598 minecraft:redstone_wire replace
setblock ~237 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~57 ~598 ~252 ~57 ~598 minecraft:redstone_wire replace
setblock ~254 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~57 ~598 ~269 ~57 ~598 minecraft:redstone_wire replace
setblock ~271 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~57 ~598 ~279 ~57 ~598 minecraft:redstone_wire replace
setblock ~193 ~57 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~57 ~602 ~205 ~57 ~602 minecraft:redstone_wire replace
setblock ~207 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~57 ~602 ~222 ~57 ~602 minecraft:redstone_wire replace
setblock ~224 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~57 ~602 ~239 ~57 ~602 minecraft:redstone_wire replace
setblock ~241 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~57 ~602 ~256 ~57 ~602 minecraft:redstone_wire replace
setblock ~258 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~260 ~57 ~602 ~273 ~57 ~602 minecraft:redstone_wire replace
setblock ~275 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~57 ~602 ~290 ~57 ~602 minecraft:redstone_wire replace
setblock ~292 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~57 ~602 ~300 ~57 ~602 minecraft:redstone_wire replace
setblock ~82 ~57 ~605 minecraft:redstone_wire replace
fill ~81 ~57 ~606 ~89 ~57 ~606 minecraft:redstone_wire replace
setblock ~91 ~57 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~57 ~606 ~99 ~57 ~606 minecraft:redstone_wire replace
setblock ~85 ~57 ~609 minecraft:redstone_wire replace
fill ~84 ~57 ~610 ~93 ~57 ~610 minecraft:redstone_wire replace
setblock ~95 ~57 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~57 ~610 ~110 ~57 ~610 minecraft:redstone_wire replace
setblock ~112 ~57 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~57 ~610 ~120 ~57 ~610 minecraft:redstone_wire replace
setblock ~88 ~57 ~613 minecraft:redstone_wire replace
fill ~87 ~57 ~614 ~97 ~57 ~614 minecraft:redstone_wire replace
setblock ~99 ~57 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~57 ~614 ~114 ~57 ~614 minecraft:redstone_wire replace
setblock ~116 ~57 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~57 ~614 ~131 ~57 ~614 minecraft:redstone_wire replace
setblock ~133 ~57 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~57 ~614 ~141 ~57 ~614 minecraft:redstone_wire replace
setblock ~91 ~57 ~617 minecraft:redstone_wire replace
fill ~90 ~57 ~618 ~101 ~57 ~618 minecraft:redstone_wire replace
setblock ~103 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~618 ~118 ~57 ~618 minecraft:redstone_wire replace
setblock ~120 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~57 ~618 ~135 ~57 ~618 minecraft:redstone_wire replace
setblock ~137 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~57 ~618 ~152 ~57 ~618 minecraft:redstone_wire replace
setblock ~154 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~57 ~618 ~162 ~57 ~618 minecraft:redstone_wire replace
setblock ~94 ~57 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~57 ~622 ~105 ~57 ~622 minecraft:redstone_wire replace
setblock ~107 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~57 ~622 ~122 ~57 ~622 minecraft:redstone_wire replace
setblock ~124 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~622 ~139 ~57 ~622 minecraft:redstone_wire replace
setblock ~141 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~57 ~622 ~156 ~57 ~622 minecraft:redstone_wire replace
setblock ~158 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~57 ~622 ~173 ~57 ~622 minecraft:redstone_wire replace
setblock ~175 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~57 ~622 ~183 ~57 ~622 minecraft:redstone_wire replace
setblock ~115 ~57 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~57 ~626 ~118 ~57 ~626 minecraft:redstone_wire replace
setblock ~120 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~57 ~626 ~134 ~57 ~626 minecraft:redstone_wire replace
setblock ~136 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~57 ~626 ~150 ~57 ~626 minecraft:redstone_wire replace
setblock ~152 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~626 ~166 ~57 ~626 minecraft:redstone_wire replace
setblock ~168 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~57 ~626 ~182 ~57 ~626 minecraft:redstone_wire replace
setblock ~184 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~57 ~626 ~198 ~57 ~626 minecraft:redstone_wire replace
setblock ~200 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~626 ~207 ~57 ~626 minecraft:redstone_wire replace
setblock ~148 ~57 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~57 ~630 ~151 ~57 ~630 minecraft:redstone_wire replace
setblock ~153 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~57 ~630 ~168 ~57 ~630 minecraft:redstone_wire replace
setblock ~170 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~57 ~630 ~185 ~57 ~630 minecraft:redstone_wire replace
setblock ~187 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~57 ~630 ~202 ~57 ~630 minecraft:redstone_wire replace
setblock ~204 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~57 ~630 ~219 ~57 ~630 minecraft:redstone_wire replace
setblock ~221 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~57 ~630 ~236 ~57 ~630 minecraft:redstone_wire replace
setblock ~238 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~57 ~630 ~246 ~57 ~630 minecraft:redstone_wire replace
setblock ~160 ~57 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~57 ~634 ~163 ~57 ~634 minecraft:redstone_wire replace
setblock ~165 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~57 ~634 ~180 ~57 ~634 minecraft:redstone_wire replace
setblock ~182 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~57 ~634 ~197 ~57 ~634 minecraft:redstone_wire replace
setblock ~199 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~57 ~634 ~214 ~57 ~634 minecraft:redstone_wire replace
setblock ~216 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~57 ~634 ~231 ~57 ~634 minecraft:redstone_wire replace
setblock ~233 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~57 ~634 ~248 ~57 ~634 minecraft:redstone_wire replace
setblock ~250 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~57 ~634 ~258 ~57 ~634 minecraft:redstone_wire replace
setblock ~184 ~57 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~57 ~638 ~196 ~57 ~638 minecraft:redstone_wire replace
setblock ~198 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~57 ~638 ~213 ~57 ~638 minecraft:redstone_wire replace
setblock ~215 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~57 ~638 ~230 ~57 ~638 minecraft:redstone_wire replace
setblock ~232 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~57 ~638 ~247 ~57 ~638 minecraft:redstone_wire replace
setblock ~249 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~57 ~638 ~264 ~57 ~638 minecraft:redstone_wire replace
setblock ~266 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~57 ~638 ~281 ~57 ~638 minecraft:redstone_wire replace
setblock ~283 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~57 ~638 ~291 ~57 ~638 minecraft:redstone_wire replace
setblock ~133 ~57 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~57 ~642 ~133 ~57 ~642 minecraft:redstone_wire replace
setblock ~135 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~57 ~642 ~150 ~57 ~642 minecraft:redstone_wire replace
setblock ~152 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~642 ~167 ~57 ~642 minecraft:redstone_wire replace
