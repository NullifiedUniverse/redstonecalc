fill ~94 ~17 ~98 ~107 ~17 ~98 minecraft:redstone_wire replace
setblock ~109 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~98 ~124 ~17 ~98 minecraft:redstone_wire replace
setblock ~126 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~98 ~141 ~17 ~98 minecraft:redstone_wire replace
setblock ~143 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~98 ~158 ~17 ~98 minecraft:redstone_wire replace
setblock ~160 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~98 ~175 ~17 ~98 minecraft:redstone_wire replace
setblock ~177 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~98 ~192 ~17 ~98 minecraft:redstone_wire replace
setblock ~194 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~98 ~209 ~17 ~98 minecraft:redstone_wire replace
setblock ~211 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~98 ~226 ~17 ~98 minecraft:redstone_wire replace
setblock ~228 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~98 ~243 ~17 ~98 minecraft:redstone_wire replace
setblock ~245 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~98 ~260 ~17 ~98 minecraft:redstone_wire replace
setblock ~262 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~98 ~277 ~17 ~98 minecraft:redstone_wire replace
setblock ~279 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~98 ~294 ~17 ~98 minecraft:redstone_wire replace
setblock ~296 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~98 ~302 ~17 ~98 minecraft:redstone_wire replace
setblock ~76 ~17 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~187 ~17 ~99 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~99 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~101 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~63 ~17 ~102 ~63 ~17 ~112 minecraft:redstone_wire replace
setblock ~65 ~17 ~102 minecraft:redstone_wire replace
setblock ~66 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~102 minecraft:redstone_wire replace
setblock ~68 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~102 minecraft:redstone_wire replace
setblock ~70 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~102 ~75 ~17 ~102 minecraft:redstone_wire replace
setblock ~76 ~17 ~102 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~102 ~90 ~17 ~102 minecraft:redstone_wire replace
setblock ~92 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~102 ~107 ~17 ~102 minecraft:redstone_wire replace
setblock ~109 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~102 ~124 ~17 ~102 minecraft:redstone_wire replace
setblock ~126 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~102 ~141 ~17 ~102 minecraft:redstone_wire replace
setblock ~143 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~102 ~158 ~17 ~102 minecraft:redstone_wire replace
setblock ~160 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~102 ~175 ~17 ~102 minecraft:redstone_wire replace
setblock ~176 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~102 ~190 ~17 ~102 minecraft:redstone_wire replace
setblock ~192 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~102 ~207 ~17 ~102 minecraft:redstone_wire replace
setblock ~209 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~102 ~224 ~17 ~102 minecraft:redstone_wire replace
setblock ~226 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~102 ~241 ~17 ~102 minecraft:redstone_wire replace
setblock ~243 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~102 ~258 ~17 ~102 minecraft:redstone_wire replace
setblock ~260 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~102 ~275 ~17 ~102 minecraft:redstone_wire replace
setblock ~277 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~102 ~292 ~17 ~102 minecraft:redstone_wire replace
setblock ~294 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~102 ~302 ~17 ~102 minecraft:redstone_wire replace
setblock ~76 ~17 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~103 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~103 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~106 minecraft:redstone_wire replace
setblock ~66 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~106 minecraft:redstone_wire replace
setblock ~68 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~106 minecraft:redstone_wire replace
setblock ~70 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~106 ~75 ~17 ~106 minecraft:redstone_wire replace
setblock ~76 ~17 ~106 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~106 ~90 ~17 ~106 minecraft:redstone_wire replace
setblock ~92 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~106 ~107 ~17 ~106 minecraft:redstone_wire replace
setblock ~109 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~106 ~124 ~17 ~106 minecraft:redstone_wire replace
setblock ~126 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~106 ~141 ~17 ~106 minecraft:redstone_wire replace
setblock ~143 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~106 ~158 ~17 ~106 minecraft:redstone_wire replace
setblock ~160 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~106 ~175 ~17 ~106 minecraft:redstone_wire replace
setblock ~176 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~106 ~190 ~17 ~106 minecraft:redstone_wire replace
setblock ~192 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~106 ~207 ~17 ~106 minecraft:redstone_wire replace
setblock ~209 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~106 ~224 ~17 ~106 minecraft:redstone_wire replace
setblock ~226 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~106 ~241 ~17 ~106 minecraft:redstone_wire replace
setblock ~243 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~106 ~258 ~17 ~106 minecraft:redstone_wire replace
setblock ~260 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~106 ~275 ~17 ~106 minecraft:redstone_wire replace
setblock ~277 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~106 ~292 ~17 ~106 minecraft:redstone_wire replace
setblock ~294 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~106 ~302 ~17 ~106 minecraft:redstone_wire replace
setblock ~76 ~17 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~17 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~110 minecraft:redstone_wire replace
setblock ~66 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~110 minecraft:redstone_wire replace
setblock ~68 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~110 minecraft:redstone_wire replace
setblock ~70 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~110 ~75 ~17 ~110 minecraft:redstone_wire replace
setblock ~76 ~17 ~110 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~110 ~90 ~17 ~110 minecraft:redstone_wire replace
setblock ~92 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~110 ~107 ~17 ~110 minecraft:redstone_wire replace
setblock ~109 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~110 ~124 ~17 ~110 minecraft:redstone_wire replace
setblock ~126 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~110 ~141 ~17 ~110 minecraft:redstone_wire replace
setblock ~143 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~110 ~158 ~17 ~110 minecraft:redstone_wire replace
setblock ~160 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~110 ~175 ~17 ~110 minecraft:redstone_wire replace
setblock ~177 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~110 ~192 ~17 ~110 minecraft:redstone_wire replace
setblock ~194 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~110 ~209 ~17 ~110 minecraft:redstone_wire replace
setblock ~211 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~110 ~226 ~17 ~110 minecraft:redstone_wire replace
setblock ~228 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~110 ~243 ~17 ~110 minecraft:redstone_wire replace
setblock ~245 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~110 ~260 ~17 ~110 minecraft:redstone_wire replace
setblock ~262 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~110 ~277 ~17 ~110 minecraft:redstone_wire replace
setblock ~279 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~110 ~294 ~17 ~110 minecraft:redstone_wire replace
setblock ~296 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~110 ~302 ~17 ~110 minecraft:redstone_wire replace
setblock ~76 ~17 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~181 ~17 ~111 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~111 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~113 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~63 ~17 ~114 ~63 ~17 ~123 minecraft:redstone_wire replace
setblock ~65 ~17 ~114 minecraft:redstone_wire replace
setblock ~66 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~114 minecraft:redstone_wire replace
setblock ~68 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~114 minecraft:redstone_wire replace
setblock ~70 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~114 ~75 ~17 ~114 minecraft:redstone_wire replace
setblock ~76 ~17 ~114 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~114 ~90 ~17 ~114 minecraft:redstone_wire replace
setblock ~92 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~114 ~107 ~17 ~114 minecraft:redstone_wire replace
setblock ~109 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~114 ~124 ~17 ~114 minecraft:redstone_wire replace
setblock ~126 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~114 ~141 ~17 ~114 minecraft:redstone_wire replace
setblock ~143 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~114 ~158 ~17 ~114 minecraft:redstone_wire replace
setblock ~160 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~114 ~175 ~17 ~114 minecraft:redstone_wire replace
setblock ~177 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~114 ~192 ~17 ~114 minecraft:redstone_wire replace
setblock ~194 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~114 ~209 ~17 ~114 minecraft:redstone_wire replace
setblock ~211 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~114 ~226 ~17 ~114 minecraft:redstone_wire replace
setblock ~228 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~114 ~243 ~17 ~114 minecraft:redstone_wire replace
setblock ~245 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~114 ~260 ~17 ~114 minecraft:redstone_wire replace
setblock ~262 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~114 ~277 ~17 ~114 minecraft:redstone_wire replace
setblock ~279 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~114 ~294 ~17 ~114 minecraft:redstone_wire replace
setblock ~296 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~114 ~302 ~17 ~114 minecraft:redstone_wire replace
setblock ~76 ~17 ~115 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~181 ~17 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~17 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~118 minecraft:redstone_wire replace
setblock ~66 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~118 minecraft:redstone_wire replace
setblock ~68 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~118 minecraft:redstone_wire replace
setblock ~70 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~118 ~75 ~17 ~118 minecraft:redstone_wire replace
setblock ~76 ~17 ~118 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~118 ~90 ~17 ~118 minecraft:redstone_wire replace
setblock ~92 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~118 ~107 ~17 ~118 minecraft:redstone_wire replace
setblock ~109 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~118 ~124 ~17 ~118 minecraft:redstone_wire replace
setblock ~126 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~118 ~141 ~17 ~118 minecraft:redstone_wire replace
setblock ~143 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~118 ~158 ~17 ~118 minecraft:redstone_wire replace
setblock ~160 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~118 ~175 ~17 ~118 minecraft:redstone_wire replace
setblock ~176 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~118 ~190 ~17 ~118 minecraft:redstone_wire replace
setblock ~192 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~118 ~207 ~17 ~118 minecraft:redstone_wire replace
setblock ~209 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~118 ~224 ~17 ~118 minecraft:redstone_wire replace
setblock ~226 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~118 ~241 ~17 ~118 minecraft:redstone_wire replace
setblock ~243 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~118 ~258 ~17 ~118 minecraft:redstone_wire replace
setblock ~260 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~118 ~275 ~17 ~118 minecraft:redstone_wire replace
setblock ~277 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~118 ~292 ~17 ~118 minecraft:redstone_wire replace
setblock ~294 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~118 ~302 ~17 ~118 minecraft:redstone_wire replace
setblock ~76 ~17 ~119 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~119 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~17 ~119 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~119 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~122 minecraft:redstone_wire replace
setblock ~66 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~122 minecraft:redstone_wire replace
setblock ~68 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~122 minecraft:redstone_wire replace
setblock ~70 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~122 ~75 ~17 ~122 minecraft:redstone_wire replace
setblock ~76 ~17 ~122 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~122 ~90 ~17 ~122 minecraft:redstone_wire replace
setblock ~92 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~122 ~107 ~17 ~122 minecraft:redstone_wire replace
setblock ~109 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~122 ~124 ~17 ~122 minecraft:redstone_wire replace
setblock ~126 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~122 ~141 ~17 ~122 minecraft:redstone_wire replace
setblock ~143 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~122 ~158 ~17 ~122 minecraft:redstone_wire replace
setblock ~160 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~122 ~175 ~17 ~122 minecraft:redstone_wire replace
setblock ~176 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~122 ~190 ~17 ~122 minecraft:redstone_wire replace
setblock ~192 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~122 ~207 ~17 ~122 minecraft:redstone_wire replace
setblock ~209 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~122 ~224 ~17 ~122 minecraft:redstone_wire replace
setblock ~226 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~122 ~241 ~17 ~122 minecraft:redstone_wire replace
setblock ~243 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~122 ~258 ~17 ~122 minecraft:redstone_wire replace
setblock ~260 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~122 ~275 ~17 ~122 minecraft:redstone_wire replace
setblock ~277 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~122 ~292 ~17 ~122 minecraft:redstone_wire replace
setblock ~294 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~122 ~302 ~17 ~122 minecraft:redstone_wire replace
setblock ~76 ~17 ~123 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~124 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~125 minecraft:redstone_wire replace
fill ~78 ~17 ~126 ~90 ~17 ~126 minecraft:redstone_wire replace
setblock ~92 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~126 ~107 ~17 ~126 minecraft:redstone_wire replace
setblock ~109 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~126 ~124 ~17 ~126 minecraft:redstone_wire replace
setblock ~126 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~126 ~141 ~17 ~126 minecraft:redstone_wire replace
setblock ~143 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~126 ~158 ~17 ~126 minecraft:redstone_wire replace
setblock ~160 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~126 ~175 ~17 ~126 minecraft:redstone_wire replace
setblock ~177 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~126 ~192 ~17 ~126 minecraft:redstone_wire replace
setblock ~194 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~126 ~209 ~17 ~126 minecraft:redstone_wire replace
setblock ~211 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~126 ~226 ~17 ~126 minecraft:redstone_wire replace
setblock ~227 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~126 ~230 ~17 ~126 minecraft:redstone_wire replace
setblock ~229 ~17 ~127 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~79 ~18 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~18 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~18 ~4 minecraft:redstone_wire replace
setblock ~88 ~18 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~18 ~4 minecraft:redstone_wire replace
setblock ~109 ~18 ~4 minecraft:redstone_wire replace
setblock ~94 ~18 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~18 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~18 ~8 minecraft:redstone_wire replace
setblock ~103 ~18 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~18 ~8 minecraft:redstone_wire replace
setblock ~115 ~18 ~8 minecraft:redstone_wire replace
setblock ~112 ~18 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~18 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~18 ~12 minecraft:redstone_wire replace
setblock ~124 ~18 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~18 ~12 minecraft:redstone_wire replace
setblock ~133 ~18 ~12 minecraft:redstone_wire replace
setblock ~136 ~18 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~18 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~18 ~16 minecraft:redstone_wire replace
setblock ~148 ~18 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~18 ~16 minecraft:redstone_wire replace
setblock ~154 ~18 ~16 minecraft:redstone_wire replace
setblock ~160 ~18 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~18 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~18 ~20 minecraft:redstone_wire replace
setblock ~169 ~18 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~18 ~20 minecraft:redstone_wire replace
setblock ~175 ~18 ~20 minecraft:redstone_wire replace
setblock ~184 ~18 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~18 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~18 ~24 minecraft:redstone_wire replace
setblock ~199 ~18 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~18 ~24 minecraft:redstone_wire replace
setblock ~205 ~18 ~24 minecraft:redstone_wire replace
setblock ~211 ~18 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~18 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~18 ~28 minecraft:redstone_wire replace
setblock ~223 ~18 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~18 ~28 minecraft:redstone_wire replace
setblock ~238 ~18 ~28 minecraft:redstone_wire replace
setblock ~250 ~18 ~32 minecraft:redstone_wire replace
setblock ~265 ~18 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~18 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~18 ~32 minecraft:redstone_wire replace
setblock ~280 ~18 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~18 ~32 minecraft:redstone_wire replace
setblock ~232 ~18 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~18 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~18 ~36 minecraft:redstone_wire replace
setblock ~244 ~18 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~18 ~36 minecraft:redstone_wire replace
setblock ~271 ~18 ~36 minecraft:redstone_wire replace
setblock ~259 ~18 ~40 minecraft:redstone_wire replace
setblock ~286 ~18 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~18 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~18 ~40 minecraft:redstone_wire replace
setblock ~295 ~18 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~18 ~40 minecraft:redstone_wire replace
setblock ~82 ~18 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~18 ~44 minecraft:redstone_wire replace
setblock ~88 ~18 ~44 minecraft:redstone_wire replace
setblock ~91 ~18 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~18 ~44 minecraft:redstone_wire replace
setblock ~97 ~18 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~18 ~48 minecraft:redstone_wire replace
setblock ~103 ~18 ~48 minecraft:redstone_wire replace
setblock ~106 ~18 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~18 ~48 minecraft:redstone_wire replace
setblock ~118 ~18 ~52 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~18 ~52 minecraft:redstone_wire replace
setblock ~124 ~18 ~52 minecraft:redstone_wire replace
setblock ~127 ~18 ~52 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~18 ~52 minecraft:redstone_wire replace
setblock ~139 ~18 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~18 ~56 minecraft:redstone_wire replace
setblock ~148 ~18 ~56 minecraft:redstone_wire replace
setblock ~151 ~18 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~18 ~56 minecraft:redstone_wire replace
setblock ~163 ~18 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~18 ~60 minecraft:redstone_wire replace
setblock ~169 ~18 ~60 minecraft:redstone_wire replace
setblock ~172 ~18 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~18 ~60 minecraft:redstone_wire replace
setblock ~193 ~18 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~18 ~64 minecraft:redstone_wire replace
setblock ~199 ~18 ~64 minecraft:redstone_wire replace
setblock ~202 ~18 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~18 ~64 minecraft:redstone_wire replace
setblock ~214 ~18 ~68 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~18 ~68 minecraft:redstone_wire replace
setblock ~223 ~18 ~68 minecraft:redstone_wire replace
setblock ~226 ~18 ~68 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~18 ~68 minecraft:redstone_wire replace
setblock ~256 ~18 ~72 minecraft:redstone_wire replace
setblock ~268 ~18 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~18 ~72 minecraft:redstone_wire replace
setblock ~280 ~18 ~72 minecraft:redstone_wire replace
setblock ~283 ~18 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~18 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~18 ~76 minecraft:redstone_wire replace
setblock ~244 ~18 ~76 minecraft:redstone_wire replace
setblock ~247 ~18 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~18 ~76 minecraft:redstone_wire replace
setblock ~274 ~18 ~80 minecraft:redstone_wire replace
setblock ~289 ~18 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~18 ~80 minecraft:redstone_wire replace
setblock ~295 ~18 ~80 minecraft:redstone_wire replace
setblock ~298 ~18 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~18 ~84 minecraft:redstone_wire replace
setblock ~301 ~18 ~88 minecraft:redstone_wire replace
setblock ~301 ~18 ~92 minecraft:redstone_wire replace
setblock ~301 ~18 ~96 minecraft:redstone_wire replace
setblock ~187 ~18 ~100 minecraft:redstone_wire replace
setblock ~301 ~18 ~100 minecraft:redstone_wire replace
setblock ~178 ~18 ~104 minecraft:redstone_wire replace
setblock ~301 ~18 ~104 minecraft:redstone_wire replace
setblock ~178 ~18 ~108 minecraft:redstone_wire replace
setblock ~187 ~18 ~108 minecraft:redstone_wire replace
setblock ~301 ~18 ~108 minecraft:redstone_wire replace
setblock ~181 ~18 ~112 minecraft:redstone_wire replace
setblock ~301 ~18 ~112 minecraft:redstone_wire replace
setblock ~181 ~18 ~116 minecraft:redstone_wire replace
setblock ~187 ~18 ~116 minecraft:redstone_wire replace
setblock ~301 ~18 ~116 minecraft:redstone_wire replace
setblock ~178 ~18 ~120 minecraft:redstone_wire replace
setblock ~181 ~18 ~120 minecraft:redstone_wire replace
setblock ~301 ~18 ~120 minecraft:redstone_wire replace
setblock ~178 ~18 ~124 minecraft:redstone_wire replace
setblock ~181 ~18 ~124 minecraft:redstone_wire replace
setblock ~187 ~18 ~124 minecraft:redstone_wire replace
setblock ~301 ~18 ~124 minecraft:redstone_wire replace
setblock ~229 ~18 ~128 minecraft:redstone_wire replace
fill ~78 ~19 ~4 ~78 ~19 ~8 minecraft:redstone_wire replace
fill ~81 ~19 ~4 ~81 ~19 ~16 minecraft:redstone_wire replace
fill ~84 ~19 ~4 ~84 ~19 ~16 minecraft:redstone_wire replace
fill ~87 ~19 ~4 ~87 ~19 ~16 minecraft:redstone_wire replace
fill ~90 ~19 ~4 ~90 ~19 ~16 minecraft:redstone_wire replace
fill ~108 ~19 ~4 ~108 ~19 ~10 minecraft:redstone_wire replace
fill ~93 ~19 ~8 ~93 ~19 ~14 minecraft:redstone_wire replace
fill ~96 ~19 ~8 ~96 ~19 ~20 minecraft:redstone_wire replace
fill ~99 ~19 ~8 ~99 ~19 ~20 minecraft:redstone_wire replace
fill ~102 ~19 ~8 ~102 ~19 ~20 minecraft:redstone_wire replace
fill ~105 ~19 ~8 ~105 ~19 ~20 minecraft:redstone_wire replace
fill ~114 ~19 ~8 ~114 ~19 ~18 minecraft:redstone_wire replace
setblock ~108 ~19 ~12 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~19 ~12 ~111 ~19 ~22 minecraft:redstone_wire replace
fill ~117 ~19 ~12 ~117 ~19 ~24 minecraft:redstone_wire replace
fill ~120 ~19 ~12 ~120 ~19 ~24 minecraft:redstone_wire replace
fill ~123 ~19 ~12 ~123 ~19 ~24 minecraft:redstone_wire replace
fill ~126 ~19 ~12 ~126 ~19 ~24 minecraft:redstone_wire replace
fill ~132 ~19 ~12 ~132 ~19 ~24 minecraft:redstone_wire replace
setblock ~93 ~19 ~16 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~19 ~16 ~135 ~19 ~28 minecraft:redstone_wire replace
fill ~138 ~19 ~16 ~138 ~19 ~28 minecraft:redstone_wire replace
fill ~144 ~19 ~16 ~144 ~19 ~28 minecraft:redstone_wire replace
fill ~147 ~19 ~16 ~147 ~19 ~28 minecraft:redstone_wire replace
fill ~150 ~19 ~16 ~150 ~19 ~28 minecraft:redstone_wire replace
fill ~153 ~19 ~16 ~153 ~19 ~28 minecraft:redstone_wire replace
setblock ~81 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~20 ~81 ~19 ~32 minecraft:redstone_wire replace
fill ~84 ~19 ~20 ~84 ~19 ~32 minecraft:redstone_wire replace
fill ~87 ~19 ~20 ~87 ~19 ~32 minecraft:redstone_wire replace
fill ~90 ~19 ~20 ~90 ~19 ~32 minecraft:redstone_wire replace
setblock ~114 ~19 ~20 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~19 ~20 ~159 ~19 ~32 minecraft:redstone_wire replace
fill ~162 ~19 ~20 ~162 ~19 ~32 minecraft:redstone_wire replace
fill ~165 ~19 ~20 ~165 ~19 ~32 minecraft:redstone_wire replace
fill ~168 ~19 ~20 ~168 ~19 ~32 minecraft:redstone_wire replace
fill ~171 ~19 ~20 ~171 ~19 ~32 minecraft:redstone_wire replace
fill ~174 ~19 ~20 ~174 ~19 ~32 minecraft:redstone_wire replace
setblock ~96 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~24 ~96 ~19 ~36 minecraft:redstone_wire replace
fill ~99 ~19 ~24 ~99 ~19 ~36 minecraft:redstone_wire replace
fill ~102 ~19 ~24 ~102 ~19 ~36 minecraft:redstone_wire replace
fill ~105 ~19 ~24 ~105 ~19 ~36 minecraft:redstone_wire replace
setblock ~111 ~19 ~24 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~19 ~24 ~183 ~19 ~36 minecraft:redstone_wire replace
fill ~192 ~19 ~24 ~192 ~19 ~36 minecraft:redstone_wire replace
fill ~195 ~19 ~24 ~195 ~19 ~36 minecraft:redstone_wire replace
fill ~198 ~19 ~24 ~198 ~19 ~36 minecraft:redstone_wire replace
fill ~201 ~19 ~24 ~201 ~19 ~36 minecraft:redstone_wire replace
fill ~204 ~19 ~24 ~204 ~19 ~36 minecraft:redstone_wire replace
setblock ~117 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~28 ~117 ~19 ~40 minecraft:redstone_wire replace
fill ~120 ~19 ~28 ~120 ~19 ~40 minecraft:redstone_wire replace
fill ~123 ~19 ~28 ~123 ~19 ~40 minecraft:redstone_wire replace
fill ~126 ~19 ~28 ~126 ~19 ~40 minecraft:redstone_wire replace
setblock ~132 ~19 ~28 minecraft:redstone_wire replace
fill ~210 ~19 ~28 ~210 ~19 ~40 minecraft:redstone_wire replace
fill ~213 ~19 ~28 ~213 ~19 ~40 minecraft:redstone_wire replace
fill ~216 ~19 ~28 ~216 ~19 ~40 minecraft:redstone_wire replace
fill ~222 ~19 ~28 ~222 ~19 ~40 minecraft:redstone_wire replace
fill ~225 ~19 ~28 ~225 ~19 ~40 minecraft:redstone_wire replace
fill ~237 ~19 ~28 ~237 ~19 ~40 minecraft:redstone_wire replace
setblock ~135 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~19 ~32 minecraft:redstone_wire replace
fill ~138 ~19 ~32 ~138 ~19 ~44 minecraft:redstone_wire replace
fill ~144 ~19 ~32 ~144 ~19 ~44 minecraft:redstone_wire replace
fill ~147 ~19 ~32 ~147 ~19 ~44 minecraft:redstone_wire replace
fill ~150 ~19 ~32 ~150 ~19 ~44 minecraft:redstone_wire replace
fill ~153 ~19 ~32 ~153 ~19 ~36 minecraft:redstone_wire replace
fill ~249 ~19 ~32 ~249 ~19 ~44 minecraft:redstone_wire replace
fill ~264 ~19 ~32 ~264 ~19 ~44 minecraft:redstone_wire replace
fill ~267 ~19 ~32 ~267 ~19 ~44 minecraft:redstone_wire replace
fill ~276 ~19 ~32 ~276 ~19 ~44 minecraft:redstone_wire replace
fill ~279 ~19 ~32 ~279 ~19 ~44 minecraft:redstone_wire replace
fill ~282 ~19 ~32 ~282 ~19 ~44 minecraft:redstone_wire replace
setblock ~81 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~36 ~81 ~19 ~48 minecraft:redstone_wire replace
fill ~84 ~19 ~36 ~84 ~19 ~48 minecraft:redstone_wire replace
fill ~87 ~19 ~36 ~87 ~19 ~48 minecraft:redstone_wire replace
fill ~90 ~19 ~36 ~90 ~19 ~48 minecraft:redstone_wire replace
fill ~159 ~19 ~36 ~159 ~19 ~40 minecraft:redstone_wire replace
fill ~162 ~19 ~36 ~162 ~19 ~48 minecraft:redstone_wire replace
fill ~165 ~19 ~36 ~165 ~19 ~48 minecraft:redstone_wire replace
fill ~168 ~19 ~36 ~168 ~19 ~48 minecraft:redstone_wire replace
fill ~171 ~19 ~36 ~171 ~19 ~48 minecraft:redstone_wire replace
fill ~174 ~19 ~36 ~174 ~19 ~42 minecraft:redstone_wire replace
fill ~231 ~19 ~36 ~231 ~19 ~48 minecraft:redstone_wire replace
fill ~234 ~19 ~36 ~234 ~19 ~48 minecraft:redstone_wire replace
fill ~240 ~19 ~36 ~240 ~19 ~48 minecraft:redstone_wire replace
fill ~243 ~19 ~36 ~243 ~19 ~48 minecraft:redstone_wire replace
fill ~246 ~19 ~36 ~246 ~19 ~48 minecraft:redstone_wire replace
fill ~270 ~19 ~36 ~270 ~19 ~48 minecraft:redstone_wire replace
setblock ~96 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~40 ~96 ~19 ~52 minecraft:redstone_wire replace
fill ~99 ~19 ~40 ~99 ~19 ~52 minecraft:redstone_wire replace
fill ~102 ~19 ~40 ~102 ~19 ~52 minecraft:redstone_wire replace
fill ~105 ~19 ~40 ~105 ~19 ~52 minecraft:redstone_wire replace
fill ~183 ~19 ~40 ~183 ~19 ~46 minecraft:redstone_wire replace
fill ~192 ~19 ~40 ~192 ~19 ~52 minecraft:redstone_wire replace
fill ~195 ~19 ~40 ~195 ~19 ~52 minecraft:redstone_wire replace
fill ~198 ~19 ~40 ~198 ~19 ~52 minecraft:redstone_wire replace
fill ~201 ~19 ~40 ~201 ~19 ~52 minecraft:redstone_wire replace
fill ~204 ~19 ~40 ~204 ~19 ~50 minecraft:redstone_wire replace
fill ~258 ~19 ~40 ~258 ~19 ~52 minecraft:redstone_wire replace
fill ~285 ~19 ~40 ~285 ~19 ~52 minecraft:redstone_wire replace
fill ~288 ~19 ~40 ~288 ~19 ~52 minecraft:redstone_wire replace
fill ~291 ~19 ~40 ~291 ~19 ~52 minecraft:redstone_wire replace
fill ~294 ~19 ~40 ~294 ~19 ~52 minecraft:redstone_wire replace
fill ~297 ~19 ~40 ~297 ~19 ~52 minecraft:redstone_wire replace
setblock ~117 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~44 ~117 ~19 ~56 minecraft:redstone_wire replace
fill ~120 ~19 ~44 ~120 ~19 ~56 minecraft:redstone_wire replace
fill ~123 ~19 ~44 ~123 ~19 ~56 minecraft:redstone_wire replace
fill ~126 ~19 ~44 ~126 ~19 ~56 minecraft:redstone_wire replace
fill ~129 ~19 ~44 ~129 ~19 ~56 minecraft:redstone_wire replace
setblock ~174 ~19 ~44 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~19 ~44 ~210 ~19 ~54 minecraft:redstone_wire replace
fill ~213 ~19 ~44 ~213 ~19 ~56 minecraft:redstone_wire replace
fill ~216 ~19 ~44 ~216 ~19 ~56 minecraft:redstone_wire replace
fill ~222 ~19 ~44 ~222 ~19 ~56 minecraft:redstone_wire replace
fill ~225 ~19 ~44 ~225 ~19 ~56 minecraft:redstone_wire replace
fill ~237 ~19 ~44 ~237 ~19 ~56 minecraft:redstone_wire replace
setblock ~138 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~48 ~138 ~19 ~60 minecraft:redstone_wire replace
fill ~141 ~19 ~48 ~141 ~19 ~60 minecraft:redstone_wire replace
fill ~144 ~19 ~48 ~144 ~19 ~60 minecraft:redstone_wire replace
fill ~147 ~19 ~48 ~147 ~19 ~60 minecraft:redstone_wire replace
fill ~150 ~19 ~48 ~150 ~19 ~60 minecraft:redstone_wire replace
