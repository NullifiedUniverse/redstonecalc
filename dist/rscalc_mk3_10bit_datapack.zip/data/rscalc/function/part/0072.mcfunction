setblock ~354 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~35 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~396 ~111 ~35 ~408 minecraft:redstone_wire replace
fill ~138 ~35 ~396 ~138 ~35 ~408 minecraft:redstone_wire replace
fill ~237 ~35 ~396 ~237 ~35 ~408 minecraft:redstone_wire replace
fill ~279 ~35 ~396 ~279 ~35 ~408 minecraft:redstone_wire replace
fill ~354 ~35 ~396 ~354 ~35 ~400 minecraft:redstone_wire replace
fill ~360 ~35 ~396 ~360 ~35 ~402 minecraft:redstone_wire replace
fill ~378 ~35 ~396 ~378 ~35 ~406 minecraft:redstone_wire replace
setblock ~135 ~35 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~35 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~398 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~400 ~135 ~35 ~412 minecraft:redstone_wire replace
fill ~186 ~35 ~400 ~186 ~35 ~412 minecraft:redstone_wire replace
fill ~276 ~35 ~400 ~276 ~35 ~412 minecraft:redstone_wire replace
fill ~309 ~35 ~400 ~309 ~35 ~412 minecraft:redstone_wire replace
setblock ~90 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~35 ~404 ~90 ~35 ~410 minecraft:redstone_wire replace
fill ~183 ~35 ~404 ~183 ~35 ~416 minecraft:redstone_wire replace
fill ~216 ~35 ~404 ~216 ~35 ~416 minecraft:redstone_wire replace
fill ~306 ~35 ~404 ~306 ~35 ~416 minecraft:redstone_wire replace
fill ~345 ~35 ~404 ~345 ~35 ~416 minecraft:redstone_wire replace
setblock ~360 ~35 ~404 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~35 ~408 ~87 ~35 ~420 minecraft:redstone_wire replace
fill ~114 ~35 ~408 ~114 ~35 ~414 minecraft:redstone_wire replace
fill ~207 ~35 ~408 ~207 ~35 ~420 minecraft:redstone_wire replace
fill ~243 ~35 ~408 ~243 ~35 ~420 minecraft:redstone_wire replace
fill ~369 ~35 ~408 ~369 ~35 ~420 minecraft:redstone_wire replace
setblock ~378 ~35 ~408 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~35 ~412 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~412 ~111 ~35 ~424 minecraft:redstone_wire replace
fill ~138 ~35 ~412 ~138 ~35 ~418 minecraft:redstone_wire replace
fill ~237 ~35 ~412 ~237 ~35 ~424 minecraft:redstone_wire replace
fill ~279 ~35 ~412 ~279 ~35 ~424 minecraft:redstone_wire replace
fill ~393 ~35 ~412 ~393 ~35 ~424 minecraft:redstone_wire replace
setblock ~135 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~414 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~416 ~84 ~35 ~428 minecraft:redstone_wire replace
setblock ~114 ~35 ~416 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~416 ~135 ~35 ~428 minecraft:redstone_wire replace
fill ~186 ~35 ~416 ~186 ~35 ~422 minecraft:redstone_wire replace
fill ~276 ~35 ~416 ~276 ~35 ~428 minecraft:redstone_wire replace
fill ~309 ~35 ~416 ~309 ~35 ~428 minecraft:redstone_wire replace
setblock ~183 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~420 ~108 ~35 ~432 minecraft:redstone_wire replace
setblock ~138 ~35 ~420 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~35 ~420 ~183 ~35 ~432 minecraft:redstone_wire replace
fill ~216 ~35 ~420 ~216 ~35 ~426 minecraft:redstone_wire replace
fill ~306 ~35 ~420 ~306 ~35 ~432 minecraft:redstone_wire replace
fill ~345 ~35 ~420 ~345 ~35 ~432 minecraft:redstone_wire replace
setblock ~87 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~35 ~424 ~87 ~35 ~436 minecraft:redstone_wire replace
fill ~132 ~35 ~424 ~132 ~35 ~436 minecraft:redstone_wire replace
setblock ~186 ~35 ~424 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~35 ~424 ~207 ~35 ~436 minecraft:redstone_wire replace
fill ~243 ~35 ~424 ~243 ~35 ~430 minecraft:redstone_wire replace
fill ~369 ~35 ~424 ~369 ~35 ~436 minecraft:redstone_wire replace
setblock ~111 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~428 ~111 ~35 ~440 minecraft:redstone_wire replace
fill ~165 ~35 ~428 ~165 ~35 ~440 minecraft:redstone_wire replace
setblock ~216 ~35 ~428 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~35 ~428 ~237 ~35 ~440 minecraft:redstone_wire replace
fill ~279 ~35 ~428 ~279 ~35 ~434 minecraft:redstone_wire replace
fill ~393 ~35 ~428 ~393 ~35 ~440 minecraft:redstone_wire replace
setblock ~84 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~35 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~432 ~84 ~35 ~444 minecraft:redstone_wire replace
fill ~135 ~35 ~432 ~135 ~35 ~444 minecraft:redstone_wire replace
fill ~204 ~35 ~432 ~204 ~35 ~444 minecraft:redstone_wire replace
setblock ~243 ~35 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~35 ~432 ~276 ~35 ~444 minecraft:redstone_wire replace
fill ~309 ~35 ~432 ~309 ~35 ~438 minecraft:redstone_wire replace
setblock ~108 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~35 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~436 ~108 ~35 ~448 minecraft:redstone_wire replace
fill ~183 ~35 ~436 ~183 ~35 ~448 minecraft:redstone_wire replace
fill ~234 ~35 ~436 ~234 ~35 ~448 minecraft:redstone_wire replace
setblock ~279 ~35 ~436 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~35 ~436 ~306 ~35 ~448 minecraft:redstone_wire replace
fill ~345 ~35 ~436 ~345 ~35 ~442 minecraft:redstone_wire replace
setblock ~87 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~35 ~440 ~87 ~35 ~446 minecraft:redstone_wire replace
fill ~132 ~35 ~440 ~132 ~35 ~452 minecraft:redstone_wire replace
fill ~207 ~35 ~440 ~207 ~35 ~452 minecraft:redstone_wire replace
fill ~273 ~35 ~440 ~273 ~35 ~452 minecraft:redstone_wire replace
setblock ~309 ~35 ~440 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~369 ~35 ~440 ~369 ~35 ~452 minecraft:redstone_wire replace
setblock ~111 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~35 ~444 ~111 ~35 ~450 minecraft:redstone_wire replace
fill ~165 ~35 ~444 ~165 ~35 ~456 minecraft:redstone_wire replace
fill ~237 ~35 ~444 ~237 ~35 ~456 minecraft:redstone_wire replace
fill ~297 ~35 ~444 ~297 ~35 ~456 minecraft:redstone_wire replace
setblock ~345 ~35 ~444 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~393 ~35 ~444 ~393 ~35 ~456 minecraft:redstone_wire replace
setblock ~84 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~448 ~84 ~35 ~460 minecraft:redstone_wire replace
setblock ~87 ~35 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~35 ~448 ~135 ~35 ~454 minecraft:redstone_wire replace
fill ~204 ~35 ~448 ~204 ~35 ~460 minecraft:redstone_wire replace
fill ~276 ~35 ~448 ~276 ~35 ~460 minecraft:redstone_wire replace
fill ~366 ~35 ~448 ~366 ~35 ~460 minecraft:redstone_wire replace
setblock ~108 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~452 ~108 ~35 ~464 minecraft:redstone_wire replace
setblock ~111 ~35 ~452 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~35 ~452 ~183 ~35 ~458 minecraft:redstone_wire replace
fill ~234 ~35 ~452 ~234 ~35 ~464 minecraft:redstone_wire replace
fill ~306 ~35 ~452 ~306 ~35 ~464 minecraft:redstone_wire replace
fill ~390 ~35 ~452 ~390 ~35 ~464 minecraft:redstone_wire replace
setblock ~132 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~456 ~81 ~35 ~468 minecraft:redstone_wire replace
fill ~132 ~35 ~456 ~132 ~35 ~468 minecraft:redstone_wire replace
setblock ~135 ~35 ~456 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~35 ~456 ~207 ~35 ~462 minecraft:redstone_wire replace
fill ~273 ~35 ~456 ~273 ~35 ~468 minecraft:redstone_wire replace
fill ~369 ~35 ~456 ~369 ~35 ~468 minecraft:redstone_wire replace
setblock ~165 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~460 ~105 ~35 ~472 minecraft:redstone_wire replace
fill ~165 ~35 ~460 ~165 ~35 ~472 minecraft:redstone_wire replace
setblock ~183 ~35 ~460 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~35 ~460 ~237 ~35 ~466 minecraft:redstone_wire replace
fill ~297 ~35 ~460 ~297 ~35 ~472 minecraft:redstone_wire replace
fill ~393 ~35 ~460 ~393 ~35 ~472 minecraft:redstone_wire replace
setblock ~84 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~464 ~84 ~35 ~476 minecraft:redstone_wire replace
fill ~129 ~35 ~464 ~129 ~35 ~476 minecraft:redstone_wire replace
fill ~204 ~35 ~464 ~204 ~35 ~476 minecraft:redstone_wire replace
setblock ~207 ~35 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~35 ~464 ~276 ~35 ~470 minecraft:redstone_wire replace
fill ~366 ~35 ~464 ~366 ~35 ~476 minecraft:redstone_wire replace
setblock ~108 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~468 ~108 ~35 ~480 minecraft:redstone_wire replace
fill ~159 ~35 ~468 ~159 ~35 ~480 minecraft:redstone_wire replace
fill ~234 ~35 ~468 ~234 ~35 ~480 minecraft:redstone_wire replace
setblock ~237 ~35 ~468 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~35 ~468 ~306 ~35 ~474 minecraft:redstone_wire replace
fill ~390 ~35 ~468 ~390 ~35 ~480 minecraft:redstone_wire replace
setblock ~81 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~35 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~472 ~81 ~35 ~484 minecraft:redstone_wire replace
fill ~132 ~35 ~472 ~132 ~35 ~484 minecraft:redstone_wire replace
fill ~198 ~35 ~472 ~198 ~35 ~484 minecraft:redstone_wire replace
fill ~273 ~35 ~472 ~273 ~35 ~484 minecraft:redstone_wire replace
setblock ~276 ~35 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~369 ~35 ~472 ~369 ~35 ~478 minecraft:redstone_wire replace
setblock ~105 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~35 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~476 ~105 ~35 ~488 minecraft:redstone_wire replace
fill ~165 ~35 ~476 ~165 ~35 ~488 minecraft:redstone_wire replace
fill ~231 ~35 ~476 ~231 ~35 ~488 minecraft:redstone_wire replace
fill ~297 ~35 ~476 ~297 ~35 ~488 minecraft:redstone_wire replace
setblock ~306 ~35 ~476 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~393 ~35 ~476 ~393 ~35 ~482 minecraft:redstone_wire replace
setblock ~84 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~478 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~35 ~480 ~84 ~35 ~486 minecraft:redstone_wire replace
fill ~129 ~35 ~480 ~129 ~35 ~492 minecraft:redstone_wire replace
fill ~204 ~35 ~480 ~204 ~35 ~492 minecraft:redstone_wire replace
fill ~270 ~35 ~480 ~270 ~35 ~492 minecraft:redstone_wire replace
fill ~366 ~35 ~480 ~366 ~35 ~492 minecraft:redstone_wire replace
setblock ~369 ~35 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~35 ~484 ~108 ~35 ~490 minecraft:redstone_wire replace
fill ~159 ~35 ~484 ~159 ~35 ~496 minecraft:redstone_wire replace
fill ~234 ~35 ~484 ~234 ~35 ~496 minecraft:redstone_wire replace
fill ~291 ~35 ~484 ~291 ~35 ~496 minecraft:redstone_wire replace
fill ~390 ~35 ~484 ~390 ~35 ~496 minecraft:redstone_wire replace
setblock ~393 ~35 ~484 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~488 ~81 ~35 ~500 minecraft:redstone_wire replace
setblock ~84 ~35 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~35 ~488 ~132 ~35 ~494 minecraft:redstone_wire replace
fill ~198 ~35 ~488 ~198 ~35 ~500 minecraft:redstone_wire replace
fill ~273 ~35 ~488 ~273 ~35 ~500 minecraft:redstone_wire replace
fill ~363 ~35 ~488 ~363 ~35 ~500 minecraft:redstone_wire replace
setblock ~105 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~490 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~492 ~105 ~35 ~504 minecraft:redstone_wire replace
setblock ~108 ~35 ~492 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~35 ~492 ~165 ~35 ~498 minecraft:redstone_wire replace
fill ~231 ~35 ~492 ~231 ~35 ~504 minecraft:redstone_wire replace
fill ~297 ~35 ~492 ~297 ~35 ~504 minecraft:redstone_wire replace
fill ~384 ~35 ~492 ~384 ~35 ~504 minecraft:redstone_wire replace
setblock ~129 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~496 ~78 ~35 ~508 minecraft:redstone_wire replace
fill ~129 ~35 ~496 ~129 ~35 ~508 minecraft:redstone_wire replace
setblock ~132 ~35 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~35 ~496 ~204 ~35 ~502 minecraft:redstone_wire replace
fill ~270 ~35 ~496 ~270 ~35 ~508 minecraft:redstone_wire replace
fill ~366 ~35 ~496 ~366 ~35 ~508 minecraft:redstone_wire replace
setblock ~159 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~500 ~102 ~35 ~512 minecraft:redstone_wire replace
fill ~159 ~35 ~500 ~159 ~35 ~512 minecraft:redstone_wire replace
setblock ~165 ~35 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~35 ~500 ~234 ~35 ~506 minecraft:redstone_wire replace
fill ~291 ~35 ~500 ~291 ~35 ~512 minecraft:redstone_wire replace
fill ~390 ~35 ~500 ~390 ~35 ~512 minecraft:redstone_wire replace
setblock ~81 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~504 ~81 ~35 ~516 minecraft:redstone_wire replace
fill ~126 ~35 ~504 ~126 ~35 ~516 minecraft:redstone_wire replace
fill ~198 ~35 ~504 ~198 ~35 ~516 minecraft:redstone_wire replace
setblock ~204 ~35 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~35 ~504 ~273 ~35 ~510 minecraft:redstone_wire replace
fill ~363 ~35 ~504 ~363 ~35 ~516 minecraft:redstone_wire replace
setblock ~105 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~506 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~508 ~105 ~35 ~520 minecraft:redstone_wire replace
fill ~153 ~35 ~508 ~153 ~35 ~520 minecraft:redstone_wire replace
fill ~231 ~35 ~508 ~231 ~35 ~520 minecraft:redstone_wire replace
setblock ~234 ~35 ~508 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~35 ~508 ~297 ~35 ~514 minecraft:redstone_wire replace
fill ~384 ~35 ~508 ~384 ~35 ~520 minecraft:redstone_wire replace
setblock ~78 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~35 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~512 ~78 ~35 ~524 minecraft:redstone_wire replace
fill ~129 ~35 ~512 ~129 ~35 ~524 minecraft:redstone_wire replace
fill ~192 ~35 ~512 ~192 ~35 ~524 minecraft:redstone_wire replace
fill ~270 ~35 ~512 ~270 ~35 ~524 minecraft:redstone_wire replace
setblock ~273 ~35 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~366 ~35 ~512 ~366 ~35 ~518 minecraft:redstone_wire replace
setblock ~102 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~35 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~516 ~102 ~35 ~528 minecraft:redstone_wire replace
fill ~159 ~35 ~516 ~159 ~35 ~528 minecraft:redstone_wire replace
fill ~222 ~35 ~516 ~222 ~35 ~528 minecraft:redstone_wire replace
fill ~291 ~35 ~516 ~291 ~35 ~528 minecraft:redstone_wire replace
setblock ~297 ~35 ~516 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~390 ~35 ~516 ~390 ~35 ~522 minecraft:redstone_wire replace
setblock ~81 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~35 ~520 ~81 ~35 ~526 minecraft:redstone_wire replace
fill ~126 ~35 ~520 ~126 ~35 ~532 minecraft:redstone_wire replace
fill ~198 ~35 ~520 ~198 ~35 ~532 minecraft:redstone_wire replace
fill ~267 ~35 ~520 ~267 ~35 ~532 minecraft:redstone_wire replace
fill ~363 ~35 ~520 ~363 ~35 ~532 minecraft:redstone_wire replace
setblock ~366 ~35 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~522 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~35 ~524 ~105 ~35 ~530 minecraft:redstone_wire replace
fill ~153 ~35 ~524 ~153 ~35 ~536 minecraft:redstone_wire replace
fill ~231 ~35 ~524 ~231 ~35 ~536 minecraft:redstone_wire replace
fill ~288 ~35 ~524 ~288 ~35 ~536 minecraft:redstone_wire replace
fill ~384 ~35 ~524 ~384 ~35 ~536 minecraft:redstone_wire replace
setblock ~390 ~35 ~524 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~528 ~78 ~35 ~540 minecraft:redstone_wire replace
setblock ~81 ~35 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~35 ~528 ~129 ~35 ~534 minecraft:redstone_wire replace
fill ~192 ~35 ~528 ~192 ~35 ~540 minecraft:redstone_wire replace
fill ~270 ~35 ~528 ~270 ~35 ~540 minecraft:redstone_wire replace
fill ~357 ~35 ~528 ~357 ~35 ~540 minecraft:redstone_wire replace
setblock ~102 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~532 ~102 ~35 ~544 minecraft:redstone_wire replace
setblock ~105 ~35 ~532 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~35 ~532 ~159 ~35 ~538 minecraft:redstone_wire replace
fill ~222 ~35 ~532 ~222 ~35 ~544 minecraft:redstone_wire replace
fill ~291 ~35 ~532 ~291 ~35 ~544 minecraft:redstone_wire replace
fill ~381 ~35 ~532 ~381 ~35 ~544 minecraft:redstone_wire replace
setblock ~126 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~536 ~99 ~35 ~548 minecraft:redstone_wire replace
fill ~126 ~35 ~536 ~126 ~35 ~548 minecraft:redstone_wire replace
setblock ~129 ~35 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~35 ~536 ~198 ~35 ~542 minecraft:redstone_wire replace
fill ~267 ~35 ~536 ~267 ~35 ~548 minecraft:redstone_wire replace
fill ~363 ~35 ~536 ~363 ~35 ~548 minecraft:redstone_wire replace
setblock ~153 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~538 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~540 ~123 ~35 ~552 minecraft:redstone_wire replace
fill ~153 ~35 ~540 ~153 ~35 ~552 minecraft:redstone_wire replace
setblock ~159 ~35 ~540 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~35 ~540 ~231 ~35 ~546 minecraft:redstone_wire replace
fill ~288 ~35 ~540 ~288 ~35 ~552 minecraft:redstone_wire replace
fill ~384 ~35 ~540 ~384 ~35 ~552 minecraft:redstone_wire replace
setblock ~78 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~544 ~78 ~35 ~556 minecraft:redstone_wire replace
fill ~147 ~35 ~544 ~147 ~35 ~556 minecraft:redstone_wire replace
fill ~192 ~35 ~544 ~192 ~35 ~556 minecraft:redstone_wire replace
setblock ~198 ~35 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~35 ~544 ~270 ~35 ~550 minecraft:redstone_wire replace
fill ~357 ~35 ~544 ~357 ~35 ~556 minecraft:redstone_wire replace
setblock ~102 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~548 ~102 ~35 ~560 minecraft:redstone_wire replace
fill ~189 ~35 ~548 ~189 ~35 ~560 minecraft:redstone_wire replace
fill ~222 ~35 ~548 ~222 ~35 ~560 minecraft:redstone_wire replace
setblock ~231 ~35 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~35 ~548 ~291 ~35 ~554 minecraft:redstone_wire replace
fill ~381 ~35 ~548 ~381 ~35 ~560 minecraft:redstone_wire replace
setblock ~99 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~35 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~552 ~99 ~35 ~564 minecraft:redstone_wire replace
fill ~126 ~35 ~552 ~126 ~35 ~564 minecraft:redstone_wire replace
fill ~219 ~35 ~552 ~219 ~35 ~564 minecraft:redstone_wire replace
fill ~267 ~35 ~552 ~267 ~35 ~564 minecraft:redstone_wire replace
setblock ~270 ~35 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~363 ~35 ~552 ~363 ~35 ~558 minecraft:redstone_wire replace
setblock ~123 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~35 ~554 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~556 ~123 ~35 ~568 minecraft:redstone_wire replace
fill ~153 ~35 ~556 ~153 ~35 ~568 minecraft:redstone_wire replace
fill ~249 ~35 ~556 ~249 ~35 ~568 minecraft:redstone_wire replace
fill ~288 ~35 ~556 ~288 ~35 ~568 minecraft:redstone_wire replace
setblock ~291 ~35 ~556 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~384 ~35 ~556 ~384 ~35 ~562 minecraft:redstone_wire replace
setblock ~78 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~35 ~560 ~78 ~35 ~566 minecraft:redstone_wire replace
fill ~147 ~35 ~560 ~147 ~35 ~572 minecraft:redstone_wire replace
fill ~192 ~35 ~560 ~192 ~35 ~572 minecraft:redstone_wire replace
fill ~294 ~35 ~560 ~294 ~35 ~572 minecraft:redstone_wire replace
fill ~357 ~35 ~560 ~357 ~35 ~572 minecraft:redstone_wire replace
setblock ~363 ~35 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~35 ~564 ~102 ~35 ~570 minecraft:redstone_wire replace
fill ~189 ~35 ~564 ~189 ~35 ~576 minecraft:redstone_wire replace
fill ~222 ~35 ~564 ~222 ~35 ~576 minecraft:redstone_wire replace
fill ~312 ~35 ~564 ~312 ~35 ~576 minecraft:redstone_wire replace
fill ~381 ~35 ~564 ~381 ~35 ~576 minecraft:redstone_wire replace
setblock ~384 ~35 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~35 ~568 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~568 ~99 ~35 ~580 minecraft:redstone_wire replace
fill ~126 ~35 ~568 ~126 ~35 ~574 minecraft:redstone_wire replace
fill ~219 ~35 ~568 ~219 ~35 ~580 minecraft:redstone_wire replace
fill ~267 ~35 ~568 ~267 ~35 ~580 minecraft:redstone_wire replace
fill ~372 ~35 ~568 ~372 ~35 ~580 minecraft:redstone_wire replace
setblock ~123 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~35 ~572 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~572 ~123 ~35 ~584 minecraft:redstone_wire replace
fill ~153 ~35 ~572 ~153 ~35 ~578 minecraft:redstone_wire replace
fill ~162 ~35 ~572 ~162 ~35 ~584 minecraft:redstone_wire replace
fill ~249 ~35 ~572 ~249 ~35 ~584 minecraft:redstone_wire replace
fill ~288 ~35 ~572 ~288 ~35 ~584 minecraft:redstone_wire replace
setblock ~147 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~35 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~35 ~576 ~147 ~35 ~588 minecraft:redstone_wire replace
fill ~192 ~35 ~576 ~192 ~35 ~582 minecraft:redstone_wire replace
fill ~294 ~35 ~576 ~294 ~35 ~588 minecraft:redstone_wire replace
fill ~357 ~35 ~576 ~357 ~35 ~588 minecraft:redstone_wire replace
fill ~399 ~35 ~576 ~399 ~35 ~588 minecraft:redstone_wire replace
setblock ~189 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~580 ~96 ~35 ~592 minecraft:redstone_wire replace
setblock ~153 ~35 ~580 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~35 ~580 ~189 ~35 ~592 minecraft:redstone_wire replace
fill ~222 ~35 ~580 ~222 ~35 ~586 minecraft:redstone_wire replace
fill ~312 ~35 ~580 ~312 ~35 ~592 minecraft:redstone_wire replace
fill ~381 ~35 ~580 ~381 ~35 ~592 minecraft:redstone_wire replace
setblock ~99 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~584 ~99 ~35 ~596 minecraft:redstone_wire replace
setblock ~192 ~35 ~584 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~35 ~584 ~219 ~35 ~596 minecraft:redstone_wire replace
fill ~267 ~35 ~584 ~267 ~35 ~590 minecraft:redstone_wire replace
fill ~372 ~35 ~584 ~372 ~35 ~596 minecraft:redstone_wire replace
fill ~375 ~35 ~584 ~375 ~35 ~596 minecraft:redstone_wire replace
setblock ~123 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~35 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~588 ~123 ~35 ~600 minecraft:redstone_wire replace
fill ~162 ~35 ~588 ~162 ~35 ~600 minecraft:redstone_wire replace
setblock ~222 ~35 ~588 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~35 ~588 ~249 ~35 ~600 minecraft:redstone_wire replace
fill ~288 ~35 ~588 ~288 ~35 ~594 minecraft:redstone_wire replace
fill ~396 ~35 ~588 ~396 ~35 ~600 minecraft:redstone_wire replace
setblock ~147 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~35 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~35 ~592 ~147 ~35 ~604 minecraft:redstone_wire replace
setblock ~267 ~35 ~592 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~35 ~592 ~294 ~35 ~604 minecraft:redstone_wire replace
fill ~357 ~35 ~592 ~357 ~35 ~598 minecraft:redstone_wire replace
fill ~399 ~35 ~592 ~399 ~35 ~604 minecraft:redstone_wire replace
setblock ~96 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~35 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~596 ~96 ~35 ~608 minecraft:redstone_wire replace
fill ~189 ~35 ~596 ~189 ~35 ~608 minecraft:redstone_wire replace
setblock ~288 ~35 ~596 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~35 ~596 ~312 ~35 ~608 minecraft:redstone_wire replace
fill ~381 ~35 ~596 ~381 ~35 ~602 minecraft:redstone_wire replace
setblock ~99 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~35 ~600 ~99 ~35 ~606 minecraft:redstone_wire replace
fill ~219 ~35 ~600 ~219 ~35 ~612 minecraft:redstone_wire replace
setblock ~357 ~35 ~600 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~35 ~600 ~372 ~35 ~612 minecraft:redstone_wire replace
fill ~375 ~35 ~600 ~375 ~35 ~612 minecraft:redstone_wire replace
setblock ~123 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~35 ~604 ~123 ~35 ~610 minecraft:redstone_wire replace
fill ~162 ~35 ~604 ~162 ~35 ~616 minecraft:redstone_wire replace
fill ~249 ~35 ~604 ~249 ~35 ~616 minecraft:redstone_wire replace
setblock ~381 ~35 ~604 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~35 ~604 ~396 ~35 ~616 minecraft:redstone_wire replace
setblock ~147 ~35 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~35 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~35 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~35 ~608 ~147 ~35 ~614 minecraft:redstone_wire replace
fill ~294 ~35 ~608 ~294 ~35 ~620 minecraft:redstone_wire replace
fill ~399 ~35 ~608 ~399 ~35 ~620 minecraft:redstone_wire replace
setblock ~96 ~35 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~35 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~612 ~96 ~35 ~624 minecraft:redstone_wire replace
setblock ~123 ~35 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~35 ~612 ~189 ~35 ~618 minecraft:redstone_wire replace
fill ~312 ~35 ~612 ~312 ~35 ~624 minecraft:redstone_wire replace
setblock ~219 ~35 ~614 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~614 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~614 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~35 ~616 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~35 ~616 ~219 ~35 ~622 minecraft:redstone_wire replace
fill ~372 ~35 ~616 ~372 ~35 ~628 minecraft:redstone_wire replace
fill ~375 ~35 ~616 ~375 ~35 ~628 minecraft:redstone_wire replace
setblock ~162 ~35 ~618 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~35 ~618 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~618 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~35 ~620 ~162 ~35 ~632 minecraft:redstone_wire replace
setblock ~189 ~35 ~620 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~35 ~620 ~249 ~35 ~626 minecraft:redstone_wire replace
fill ~396 ~35 ~620 ~396 ~35 ~632 minecraft:redstone_wire replace
setblock ~294 ~35 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~35 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~35 ~624 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~35 ~624 ~294 ~35 ~630 minecraft:redstone_wire replace
fill ~399 ~35 ~624 ~399 ~35 ~636 minecraft:redstone_wire replace
setblock ~96 ~35 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~35 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~628 ~96 ~35 ~640 minecraft:redstone_wire replace
setblock ~249 ~35 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~35 ~628 ~312 ~35 ~634 minecraft:redstone_wire replace
setblock ~372 ~35 ~630 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~630 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~35 ~632 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~35 ~632 ~372 ~35 ~638 minecraft:redstone_wire replace
fill ~375 ~35 ~632 ~375 ~35 ~644 minecraft:redstone_wire replace
setblock ~162 ~35 ~634 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~634 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~35 ~636 ~162 ~35 ~642 minecraft:redstone_wire replace
setblock ~312 ~35 ~636 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~35 ~636 ~396 ~35 ~648 minecraft:redstone_wire replace
setblock ~399 ~35 ~638 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~35 ~640 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~399 ~35 ~640 ~399 ~35 ~646 minecraft:redstone_wire replace
setblock ~96 ~35 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~35 ~644 ~96 ~35 ~650 minecraft:redstone_wire replace
setblock ~162 ~35 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~35 ~646 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~375 ~35 ~648 ~375 ~35 ~654 minecraft:redstone_wire replace
setblock ~399 ~35 ~648 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~650 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~35 ~652 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~35 ~652 ~396 ~35 ~658 minecraft:redstone_wire replace
setblock ~375 ~35 ~656 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~35 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~36 ~13 minecraft:redstone_wire replace
setblock ~210 ~36 ~21 minecraft:redstone_wire replace
setblock ~252 ~36 ~29 minecraft:redstone_wire replace
setblock ~300 ~36 ~45 minecraft:redstone_wire replace
setblock ~330 ~36 ~53 minecraft:redstone_wire replace
setblock ~321 ~36 ~61 minecraft:redstone_wire replace
setblock ~351 ~36 ~77 minecraft:redstone_wire replace
setblock ~93 ~36 ~261 minecraft:redstone_wire replace
setblock ~120 ~36 ~265 minecraft:redstone_wire replace
setblock ~150 ~36 ~269 minecraft:redstone_wire replace
setblock ~180 ~36 ~273 minecraft:redstone_wire replace
setblock ~156 ~36 ~277 minecraft:redstone_wire replace
setblock ~117 ~36 ~281 minecraft:redstone_wire replace
setblock ~141 ~36 ~285 minecraft:redstone_wire replace
setblock ~171 ~36 ~289 minecraft:redstone_wire replace
