setblock ~171 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~173 ~145 ~658 minecraft:light_gray_concrete replace
fill ~96 ~146 ~380 ~96 ~146 ~384 minecraft:light_gray_concrete replace
fill ~81 ~146 ~392 ~81 ~146 ~396 minecraft:light_gray_concrete replace
fill ~99 ~146 ~412 ~99 ~146 ~480 minecraft:light_gray_concrete replace
fill ~93 ~146 ~416 ~93 ~146 ~472 minecraft:light_gray_concrete replace
fill ~90 ~146 ~424 ~90 ~146 ~432 minecraft:light_gray_concrete replace
fill ~87 ~146 ~432 ~87 ~146 ~444 minecraft:light_gray_concrete replace
fill ~78 ~146 ~444 ~78 ~146 ~448 minecraft:light_gray_concrete replace
fill ~111 ~146 ~480 ~111 ~146 ~544 minecraft:light_gray_concrete replace
fill ~108 ~146 ~484 ~108 ~146 ~536 minecraft:light_gray_concrete replace
fill ~105 ~146 ~492 ~105 ~146 ~500 minecraft:light_gray_concrete replace
fill ~102 ~146 ~500 ~102 ~146 ~512 minecraft:light_gray_concrete replace
fill ~123 ~146 ~556 ~123 ~146 ~604 minecraft:light_gray_concrete replace
fill ~120 ~146 ~560 ~120 ~146 ~608 minecraft:light_gray_concrete replace
fill ~117 ~146 ~564 ~117 ~146 ~568 minecraft:light_gray_concrete replace
fill ~114 ~146 ~568 ~114 ~146 ~576 minecraft:light_gray_concrete replace
fill ~132 ~146 ~640 ~132 ~146 ~644 minecraft:light_gray_concrete replace
fill ~84 ~146 ~644 ~84 ~146 ~648 minecraft:light_gray_concrete replace
fill ~126 ~146 ~648 ~126 ~146 ~652 minecraft:light_gray_concrete replace
fill ~129 ~146 ~656 ~129 ~146 ~660 minecraft:light_gray_concrete replace
setblock ~96 ~147 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~147 ~397 minecraft:light_gray_concrete replace
setblock ~100 ~147 ~412 minecraft:light_gray_concrete replace
setblock ~94 ~147 ~416 minecraft:light_gray_concrete replace
setblock ~94 ~147 ~420 minecraft:light_gray_concrete replace
setblock ~91 ~147 ~424 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~425 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~427 minecraft:light_gray_concrete replace
setblock ~91 ~147 ~428 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~429 minecraft:light_gray_concrete replace
setblock ~90 ~147 ~431 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~431 minecraft:light_gray_concrete replace
setblock ~88 ~147 ~432 minecraft:light_gray_concrete replace
setblock ~90 ~147 ~433 minecraft:light_gray_concrete replace
setblock ~88 ~147 ~436 minecraft:light_gray_concrete replace
setblock ~88 ~147 ~440 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~441 minecraft:light_gray_concrete replace
setblock ~87 ~147 ~443 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~147 ~445 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~445 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~447 minecraft:light_gray_concrete replace
setblock ~78 ~147 ~449 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~457 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~459 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~461 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~463 minecraft:light_gray_concrete replace
setblock ~100 ~147 ~464 minecraft:light_gray_concrete replace
setblock ~94 ~147 ~468 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~471 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~473 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~473 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~475 minecraft:light_gray_concrete replace
setblock ~100 ~147 ~476 minecraft:light_gray_concrete replace
setblock ~112 ~147 ~480 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~481 minecraft:light_gray_concrete replace
setblock ~109 ~147 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~147 ~488 minecraft:light_gray_concrete replace
setblock ~106 ~147 ~492 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~493 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~495 minecraft:light_gray_concrete replace
setblock ~106 ~147 ~496 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~497 minecraft:light_gray_concrete replace
setblock ~105 ~147 ~499 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~499 minecraft:light_gray_concrete replace
setblock ~103 ~147 ~500 minecraft:light_gray_concrete replace
setblock ~105 ~147 ~501 minecraft:light_gray_concrete replace
setblock ~103 ~147 ~504 minecraft:light_gray_concrete replace
setblock ~103 ~147 ~508 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~509 minecraft:light_gray_concrete replace
setblock ~102 ~147 ~511 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~511 minecraft:light_gray_concrete replace
setblock ~102 ~147 ~513 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~513 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~515 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~527 minecraft:light_gray_concrete replace
setblock ~112 ~147 ~528 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~531 minecraft:light_gray_concrete replace
setblock ~109 ~147 ~532 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~537 minecraft:light_gray_concrete replace
setblock ~112 ~147 ~540 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~545 minecraft:light_gray_concrete replace
setblock ~124 ~147 ~556 minecraft:light_gray_concrete replace
setblock ~121 ~147 ~560 minecraft:light_gray_concrete replace
setblock ~118 ~147 ~564 minecraft:light_gray_concrete replace
setblock ~115 ~147 ~568 minecraft:light_gray_concrete replace
setblock ~117 ~147 ~569 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~569 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~571 minecraft:light_gray_concrete replace
setblock ~115 ~147 ~572 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~573 minecraft:light_gray_concrete replace
setblock ~114 ~147 ~575 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~575 minecraft:light_gray_concrete replace
setblock ~114 ~147 ~577 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~585 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~587 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~589 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~591 minecraft:light_gray_concrete replace
setblock ~124 ~147 ~600 minecraft:light_gray_concrete replace
setblock ~121 ~147 ~604 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~605 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~609 minecraft:light_gray_concrete replace
setblock ~132 ~147 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~147 ~649 minecraft:light_gray_concrete replace
setblock ~126 ~147 ~653 minecraft:light_gray_concrete replace
setblock ~129 ~147 ~661 minecraft:light_gray_concrete replace
fill ~96 ~148 ~386 ~233 ~148 ~386 minecraft:light_gray_concrete replace
fill ~232 ~148 ~387 ~232 ~148 ~388 minecraft:light_gray_concrete replace
fill ~81 ~148 ~398 ~83 ~148 ~398 minecraft:light_gray_concrete replace
fill ~82 ~148 ~399 ~82 ~148 ~400 minecraft:light_gray_concrete replace
fill ~84 ~148 ~434 ~230 ~148 ~434 minecraft:light_gray_concrete replace
fill ~85 ~148 ~435 ~85 ~148 ~436 minecraft:light_gray_concrete replace
fill ~88 ~148 ~435 ~88 ~148 ~436 minecraft:light_gray_concrete replace
fill ~91 ~148 ~435 ~91 ~148 ~436 minecraft:light_gray_concrete replace
fill ~94 ~148 ~435 ~94 ~148 ~436 minecraft:light_gray_concrete replace
fill ~97 ~148 ~435 ~97 ~148 ~436 minecraft:light_gray_concrete replace
fill ~100 ~148 ~435 ~100 ~148 ~436 minecraft:light_gray_concrete replace
fill ~103 ~148 ~435 ~103 ~148 ~436 minecraft:light_gray_concrete replace
fill ~106 ~148 ~435 ~106 ~148 ~436 minecraft:light_gray_concrete replace
fill ~109 ~148 ~435 ~109 ~148 ~436 minecraft:light_gray_concrete replace
fill ~112 ~148 ~435 ~112 ~148 ~436 minecraft:light_gray_concrete replace
fill ~115 ~148 ~435 ~115 ~148 ~436 minecraft:light_gray_concrete replace
fill ~118 ~148 ~435 ~118 ~148 ~436 minecraft:light_gray_concrete replace
fill ~121 ~148 ~435 ~121 ~148 ~436 minecraft:light_gray_concrete replace
fill ~124 ~148 ~435 ~124 ~148 ~436 minecraft:light_gray_concrete replace
fill ~127 ~148 ~435 ~127 ~148 ~436 minecraft:light_gray_concrete replace
fill ~130 ~148 ~435 ~130 ~148 ~436 minecraft:light_gray_concrete replace
fill ~133 ~148 ~435 ~133 ~148 ~436 minecraft:light_gray_concrete replace
fill ~136 ~148 ~435 ~136 ~148 ~436 minecraft:light_gray_concrete replace
fill ~139 ~148 ~435 ~139 ~148 ~436 minecraft:light_gray_concrete replace
fill ~142 ~148 ~435 ~142 ~148 ~436 minecraft:light_gray_concrete replace
fill ~145 ~148 ~435 ~145 ~148 ~436 minecraft:light_gray_concrete replace
fill ~148 ~148 ~435 ~148 ~148 ~436 minecraft:light_gray_concrete replace
fill ~151 ~148 ~435 ~151 ~148 ~436 minecraft:light_gray_concrete replace
fill ~154 ~148 ~435 ~154 ~148 ~436 minecraft:light_gray_concrete replace
fill ~157 ~148 ~435 ~157 ~148 ~436 minecraft:light_gray_concrete replace
fill ~160 ~148 ~435 ~160 ~148 ~436 minecraft:light_gray_concrete replace
fill ~163 ~148 ~435 ~163 ~148 ~436 minecraft:light_gray_concrete replace
fill ~166 ~148 ~435 ~166 ~148 ~436 minecraft:light_gray_concrete replace
fill ~169 ~148 ~435 ~169 ~148 ~436 minecraft:light_gray_concrete replace
fill ~172 ~148 ~435 ~172 ~148 ~436 minecraft:light_gray_concrete replace
fill ~175 ~148 ~435 ~175 ~148 ~436 minecraft:light_gray_concrete replace
fill ~178 ~148 ~435 ~178 ~148 ~436 minecraft:light_gray_concrete replace
fill ~181 ~148 ~435 ~181 ~148 ~436 minecraft:light_gray_concrete replace
fill ~184 ~148 ~435 ~184 ~148 ~436 minecraft:light_gray_concrete replace
fill ~187 ~148 ~435 ~187 ~148 ~436 minecraft:light_gray_concrete replace
fill ~190 ~148 ~435 ~190 ~148 ~436 minecraft:light_gray_concrete replace
fill ~193 ~148 ~435 ~193 ~148 ~436 minecraft:light_gray_concrete replace
fill ~196 ~148 ~435 ~196 ~148 ~436 minecraft:light_gray_concrete replace
fill ~199 ~148 ~435 ~199 ~148 ~436 minecraft:light_gray_concrete replace
fill ~202 ~148 ~435 ~202 ~148 ~436 minecraft:light_gray_concrete replace
fill ~205 ~148 ~435 ~205 ~148 ~436 minecraft:light_gray_concrete replace
fill ~208 ~148 ~435 ~208 ~148 ~436 minecraft:light_gray_concrete replace
fill ~211 ~148 ~435 ~211 ~148 ~436 minecraft:light_gray_concrete replace
fill ~214 ~148 ~435 ~214 ~148 ~436 minecraft:light_gray_concrete replace
fill ~217 ~148 ~435 ~217 ~148 ~436 minecraft:light_gray_concrete replace
fill ~220 ~148 ~435 ~220 ~148 ~436 minecraft:light_gray_concrete replace
fill ~223 ~148 ~435 ~223 ~148 ~436 minecraft:light_gray_concrete replace
fill ~226 ~148 ~435 ~226 ~148 ~436 minecraft:light_gray_concrete replace
fill ~229 ~148 ~435 ~229 ~148 ~436 minecraft:light_gray_concrete replace
fill ~84 ~148 ~446 ~230 ~148 ~446 minecraft:light_gray_concrete replace
fill ~85 ~148 ~447 ~85 ~148 ~448 minecraft:light_gray_concrete replace
fill ~88 ~148 ~447 ~88 ~148 ~448 minecraft:light_gray_concrete replace
fill ~91 ~148 ~447 ~91 ~148 ~448 minecraft:light_gray_concrete replace
fill ~94 ~148 ~447 ~94 ~148 ~448 minecraft:light_gray_concrete replace
fill ~97 ~148 ~447 ~97 ~148 ~448 minecraft:light_gray_concrete replace
fill ~100 ~148 ~447 ~100 ~148 ~448 minecraft:light_gray_concrete replace
fill ~103 ~148 ~447 ~103 ~148 ~448 minecraft:light_gray_concrete replace
fill ~106 ~148 ~447 ~106 ~148 ~448 minecraft:light_gray_concrete replace
fill ~109 ~148 ~447 ~109 ~148 ~448 minecraft:light_gray_concrete replace
fill ~112 ~148 ~447 ~112 ~148 ~448 minecraft:light_gray_concrete replace
fill ~115 ~148 ~447 ~115 ~148 ~448 minecraft:light_gray_concrete replace
fill ~118 ~148 ~447 ~118 ~148 ~448 minecraft:light_gray_concrete replace
fill ~121 ~148 ~447 ~121 ~148 ~448 minecraft:light_gray_concrete replace
fill ~124 ~148 ~447 ~124 ~148 ~448 minecraft:light_gray_concrete replace
fill ~127 ~148 ~447 ~127 ~148 ~448 minecraft:light_gray_concrete replace
fill ~130 ~148 ~447 ~130 ~148 ~448 minecraft:light_gray_concrete replace
fill ~133 ~148 ~447 ~133 ~148 ~448 minecraft:light_gray_concrete replace
fill ~136 ~148 ~447 ~136 ~148 ~448 minecraft:light_gray_concrete replace
fill ~139 ~148 ~447 ~139 ~148 ~448 minecraft:light_gray_concrete replace
fill ~142 ~148 ~447 ~142 ~148 ~448 minecraft:light_gray_concrete replace
fill ~145 ~148 ~447 ~145 ~148 ~448 minecraft:light_gray_concrete replace
fill ~148 ~148 ~447 ~148 ~148 ~448 minecraft:light_gray_concrete replace
fill ~151 ~148 ~447 ~151 ~148 ~448 minecraft:light_gray_concrete replace
fill ~154 ~148 ~447 ~154 ~148 ~448 minecraft:light_gray_concrete replace
fill ~157 ~148 ~447 ~157 ~148 ~448 minecraft:light_gray_concrete replace
fill ~160 ~148 ~447 ~160 ~148 ~448 minecraft:light_gray_concrete replace
fill ~163 ~148 ~447 ~163 ~148 ~448 minecraft:light_gray_concrete replace
fill ~166 ~148 ~447 ~166 ~148 ~448 minecraft:light_gray_concrete replace
fill ~169 ~148 ~447 ~169 ~148 ~448 minecraft:light_gray_concrete replace
fill ~172 ~148 ~447 ~172 ~148 ~448 minecraft:light_gray_concrete replace
fill ~175 ~148 ~447 ~175 ~148 ~448 minecraft:light_gray_concrete replace
fill ~178 ~148 ~447 ~178 ~148 ~448 minecraft:light_gray_concrete replace
fill ~181 ~148 ~447 ~181 ~148 ~448 minecraft:light_gray_concrete replace
fill ~184 ~148 ~447 ~184 ~148 ~448 minecraft:light_gray_concrete replace
fill ~187 ~148 ~447 ~187 ~148 ~448 minecraft:light_gray_concrete replace
fill ~190 ~148 ~447 ~190 ~148 ~448 minecraft:light_gray_concrete replace
fill ~193 ~148 ~447 ~193 ~148 ~448 minecraft:light_gray_concrete replace
fill ~196 ~148 ~447 ~196 ~148 ~448 minecraft:light_gray_concrete replace
fill ~199 ~148 ~447 ~199 ~148 ~448 minecraft:light_gray_concrete replace
fill ~202 ~148 ~447 ~202 ~148 ~448 minecraft:light_gray_concrete replace
fill ~205 ~148 ~447 ~205 ~148 ~448 minecraft:light_gray_concrete replace
fill ~208 ~148 ~447 ~208 ~148 ~448 minecraft:light_gray_concrete replace
fill ~211 ~148 ~447 ~211 ~148 ~448 minecraft:light_gray_concrete replace
fill ~214 ~148 ~447 ~214 ~148 ~448 minecraft:light_gray_concrete replace
fill ~217 ~148 ~447 ~217 ~148 ~448 minecraft:light_gray_concrete replace
fill ~220 ~148 ~447 ~220 ~148 ~448 minecraft:light_gray_concrete replace
fill ~223 ~148 ~447 ~223 ~148 ~448 minecraft:light_gray_concrete replace
fill ~226 ~148 ~447 ~226 ~148 ~448 minecraft:light_gray_concrete replace
fill ~229 ~148 ~447 ~229 ~148 ~448 minecraft:light_gray_concrete replace
fill ~78 ~148 ~450 ~80 ~148 ~450 minecraft:light_gray_concrete replace
fill ~79 ~148 ~451 ~79 ~148 ~452 minecraft:light_gray_concrete replace
fill ~84 ~148 ~474 ~230 ~148 ~474 minecraft:light_gray_concrete replace
fill ~85 ~148 ~475 ~85 ~148 ~476 minecraft:light_gray_concrete replace
fill ~88 ~148 ~475 ~88 ~148 ~476 minecraft:light_gray_concrete replace
fill ~91 ~148 ~475 ~91 ~148 ~476 minecraft:light_gray_concrete replace
fill ~94 ~148 ~475 ~94 ~148 ~476 minecraft:light_gray_concrete replace
fill ~97 ~148 ~475 ~97 ~148 ~476 minecraft:light_gray_concrete replace
fill ~100 ~148 ~475 ~100 ~148 ~476 minecraft:light_gray_concrete replace
fill ~103 ~148 ~475 ~103 ~148 ~476 minecraft:light_gray_concrete replace
fill ~106 ~148 ~475 ~106 ~148 ~476 minecraft:light_gray_concrete replace
fill ~109 ~148 ~475 ~109 ~148 ~476 minecraft:light_gray_concrete replace
fill ~112 ~148 ~475 ~112 ~148 ~476 minecraft:light_gray_concrete replace
fill ~115 ~148 ~475 ~115 ~148 ~476 minecraft:light_gray_concrete replace
fill ~118 ~148 ~475 ~118 ~148 ~476 minecraft:light_gray_concrete replace
fill ~121 ~148 ~475 ~121 ~148 ~476 minecraft:light_gray_concrete replace
fill ~124 ~148 ~475 ~124 ~148 ~476 minecraft:light_gray_concrete replace
fill ~127 ~148 ~475 ~127 ~148 ~476 minecraft:light_gray_concrete replace
fill ~130 ~148 ~475 ~130 ~148 ~476 minecraft:light_gray_concrete replace
fill ~133 ~148 ~475 ~133 ~148 ~476 minecraft:light_gray_concrete replace
fill ~136 ~148 ~475 ~136 ~148 ~476 minecraft:light_gray_concrete replace
fill ~139 ~148 ~475 ~139 ~148 ~476 minecraft:light_gray_concrete replace
fill ~142 ~148 ~475 ~142 ~148 ~476 minecraft:light_gray_concrete replace
fill ~145 ~148 ~475 ~145 ~148 ~476 minecraft:light_gray_concrete replace
fill ~148 ~148 ~475 ~148 ~148 ~476 minecraft:light_gray_concrete replace
fill ~151 ~148 ~475 ~151 ~148 ~476 minecraft:light_gray_concrete replace
fill ~154 ~148 ~475 ~154 ~148 ~476 minecraft:light_gray_concrete replace
fill ~157 ~148 ~475 ~157 ~148 ~476 minecraft:light_gray_concrete replace
fill ~160 ~148 ~475 ~160 ~148 ~476 minecraft:light_gray_concrete replace
fill ~163 ~148 ~475 ~163 ~148 ~476 minecraft:light_gray_concrete replace
fill ~166 ~148 ~475 ~166 ~148 ~476 minecraft:light_gray_concrete replace
fill ~169 ~148 ~475 ~169 ~148 ~476 minecraft:light_gray_concrete replace
fill ~172 ~148 ~475 ~172 ~148 ~476 minecraft:light_gray_concrete replace
fill ~175 ~148 ~475 ~175 ~148 ~476 minecraft:light_gray_concrete replace
fill ~178 ~148 ~475 ~178 ~148 ~476 minecraft:light_gray_concrete replace
fill ~181 ~148 ~475 ~181 ~148 ~476 minecraft:light_gray_concrete replace
fill ~184 ~148 ~475 ~184 ~148 ~476 minecraft:light_gray_concrete replace
fill ~187 ~148 ~475 ~187 ~148 ~476 minecraft:light_gray_concrete replace
fill ~190 ~148 ~475 ~190 ~148 ~476 minecraft:light_gray_concrete replace
fill ~193 ~148 ~475 ~193 ~148 ~476 minecraft:light_gray_concrete replace
fill ~196 ~148 ~475 ~196 ~148 ~476 minecraft:light_gray_concrete replace
fill ~199 ~148 ~475 ~199 ~148 ~476 minecraft:light_gray_concrete replace
fill ~202 ~148 ~475 ~202 ~148 ~476 minecraft:light_gray_concrete replace
fill ~205 ~148 ~475 ~205 ~148 ~476 minecraft:light_gray_concrete replace
fill ~208 ~148 ~475 ~208 ~148 ~476 minecraft:light_gray_concrete replace
fill ~211 ~148 ~475 ~211 ~148 ~476 minecraft:light_gray_concrete replace
fill ~214 ~148 ~475 ~214 ~148 ~476 minecraft:light_gray_concrete replace
fill ~217 ~148 ~475 ~217 ~148 ~476 minecraft:light_gray_concrete replace
fill ~220 ~148 ~475 ~220 ~148 ~476 minecraft:light_gray_concrete replace
fill ~223 ~148 ~475 ~223 ~148 ~476 minecraft:light_gray_concrete replace
fill ~226 ~148 ~475 ~226 ~148 ~476 minecraft:light_gray_concrete replace
fill ~229 ~148 ~475 ~229 ~148 ~476 minecraft:light_gray_concrete replace
fill ~99 ~148 ~482 ~248 ~148 ~482 minecraft:light_gray_concrete replace
fill ~235 ~148 ~483 ~235 ~148 ~484 minecraft:light_gray_concrete replace
fill ~247 ~148 ~483 ~247 ~148 ~484 minecraft:light_gray_concrete replace
fill ~105 ~148 ~502 ~248 ~148 ~502 minecraft:light_gray_concrete replace
fill ~241 ~148 ~503 ~241 ~148 ~504 minecraft:light_gray_concrete replace
fill ~247 ~148 ~503 ~247 ~148 ~504 minecraft:light_gray_concrete replace
fill ~102 ~148 ~514 ~248 ~148 ~514 minecraft:light_gray_concrete replace
fill ~238 ~148 ~515 ~238 ~148 ~516 minecraft:light_gray_concrete replace
fill ~247 ~148 ~515 ~247 ~148 ~516 minecraft:light_gray_concrete replace
fill ~108 ~148 ~538 ~248 ~148 ~538 minecraft:light_gray_concrete replace
fill ~244 ~148 ~539 ~244 ~148 ~540 minecraft:light_gray_concrete replace
fill ~247 ~148 ~539 ~247 ~148 ~540 minecraft:light_gray_concrete replace
fill ~111 ~148 ~546 ~257 ~148 ~546 minecraft:light_gray_concrete replace
fill ~247 ~148 ~547 ~247 ~148 ~548 minecraft:light_gray_concrete replace
fill ~250 ~148 ~547 ~250 ~148 ~548 minecraft:light_gray_concrete replace
fill ~256 ~148 ~547 ~256 ~148 ~548 minecraft:light_gray_concrete replace
fill ~117 ~148 ~570 ~260 ~148 ~570 minecraft:light_gray_concrete replace
fill ~247 ~148 ~571 ~247 ~148 ~572 minecraft:light_gray_concrete replace
fill ~256 ~148 ~571 ~256 ~148 ~572 minecraft:light_gray_concrete replace
fill ~259 ~148 ~571 ~259 ~148 ~572 minecraft:light_gray_concrete replace
fill ~114 ~148 ~578 ~257 ~148 ~578 minecraft:light_gray_concrete replace
fill ~247 ~148 ~579 ~247 ~148 ~580 minecraft:light_gray_concrete replace
fill ~253 ~148 ~579 ~253 ~148 ~580 minecraft:light_gray_concrete replace
fill ~256 ~148 ~579 ~256 ~148 ~580 minecraft:light_gray_concrete replace
fill ~123 ~148 ~606 ~269 ~148 ~606 minecraft:light_gray_concrete replace
fill ~247 ~148 ~607 ~247 ~148 ~608 minecraft:light_gray_concrete replace
fill ~256 ~148 ~607 ~256 ~148 ~608 minecraft:light_gray_concrete replace
fill ~265 ~148 ~607 ~265 ~148 ~608 minecraft:light_gray_concrete replace
fill ~268 ~148 ~607 ~268 ~148 ~608 minecraft:light_gray_concrete replace
fill ~120 ~148 ~610 ~263 ~148 ~610 minecraft:light_gray_concrete replace
fill ~247 ~148 ~611 ~247 ~148 ~612 minecraft:light_gray_concrete replace
fill ~256 ~148 ~611 ~256 ~148 ~612 minecraft:light_gray_concrete replace
fill ~262 ~148 ~611 ~262 ~148 ~612 minecraft:light_gray_concrete replace
fill ~132 ~148 ~646 ~278 ~148 ~646 minecraft:light_gray_concrete replace
fill ~277 ~148 ~647 ~277 ~148 ~648 minecraft:light_gray_concrete replace
fill ~84 ~148 ~650 ~230 ~148 ~650 minecraft:light_gray_concrete replace
fill ~85 ~148 ~651 ~85 ~148 ~652 minecraft:light_gray_concrete replace
fill ~88 ~148 ~651 ~88 ~148 ~652 minecraft:light_gray_concrete replace
fill ~91 ~148 ~651 ~91 ~148 ~652 minecraft:light_gray_concrete replace
fill ~94 ~148 ~651 ~94 ~148 ~652 minecraft:light_gray_concrete replace
fill ~97 ~148 ~651 ~97 ~148 ~652 minecraft:light_gray_concrete replace
fill ~100 ~148 ~651 ~100 ~148 ~652 minecraft:light_gray_concrete replace
fill ~103 ~148 ~651 ~103 ~148 ~652 minecraft:light_gray_concrete replace
fill ~106 ~148 ~651 ~106 ~148 ~652 minecraft:light_gray_concrete replace
fill ~109 ~148 ~651 ~109 ~148 ~652 minecraft:light_gray_concrete replace
fill ~112 ~148 ~651 ~112 ~148 ~652 minecraft:light_gray_concrete replace
fill ~115 ~148 ~651 ~115 ~148 ~652 minecraft:light_gray_concrete replace
fill ~118 ~148 ~651 ~118 ~148 ~652 minecraft:light_gray_concrete replace
fill ~121 ~148 ~651 ~121 ~148 ~652 minecraft:light_gray_concrete replace
fill ~124 ~148 ~651 ~124 ~148 ~652 minecraft:light_gray_concrete replace
fill ~127 ~148 ~651 ~127 ~148 ~652 minecraft:light_gray_concrete replace
fill ~130 ~148 ~651 ~130 ~148 ~652 minecraft:light_gray_concrete replace
fill ~133 ~148 ~651 ~133 ~148 ~652 minecraft:light_gray_concrete replace
fill ~136 ~148 ~651 ~136 ~148 ~652 minecraft:light_gray_concrete replace
fill ~139 ~148 ~651 ~139 ~148 ~652 minecraft:light_gray_concrete replace
fill ~142 ~148 ~651 ~142 ~148 ~652 minecraft:light_gray_concrete replace
fill ~145 ~148 ~651 ~145 ~148 ~652 minecraft:light_gray_concrete replace
fill ~148 ~148 ~651 ~148 ~148 ~652 minecraft:light_gray_concrete replace
fill ~151 ~148 ~651 ~151 ~148 ~652 minecraft:light_gray_concrete replace
fill ~154 ~148 ~651 ~154 ~148 ~652 minecraft:light_gray_concrete replace
fill ~157 ~148 ~651 ~157 ~148 ~652 minecraft:light_gray_concrete replace
fill ~160 ~148 ~651 ~160 ~148 ~652 minecraft:light_gray_concrete replace
fill ~163 ~148 ~651 ~163 ~148 ~652 minecraft:light_gray_concrete replace
fill ~166 ~148 ~651 ~166 ~148 ~652 minecraft:light_gray_concrete replace
fill ~169 ~148 ~651 ~169 ~148 ~652 minecraft:light_gray_concrete replace
fill ~172 ~148 ~651 ~172 ~148 ~652 minecraft:light_gray_concrete replace
fill ~175 ~148 ~651 ~175 ~148 ~652 minecraft:light_gray_concrete replace
fill ~178 ~148 ~651 ~178 ~148 ~652 minecraft:light_gray_concrete replace
fill ~181 ~148 ~651 ~181 ~148 ~652 minecraft:light_gray_concrete replace
fill ~184 ~148 ~651 ~184 ~148 ~652 minecraft:light_gray_concrete replace
fill ~187 ~148 ~651 ~187 ~148 ~652 minecraft:light_gray_concrete replace
fill ~190 ~148 ~651 ~190 ~148 ~652 minecraft:light_gray_concrete replace
fill ~193 ~148 ~651 ~193 ~148 ~652 minecraft:light_gray_concrete replace
fill ~196 ~148 ~651 ~196 ~148 ~652 minecraft:light_gray_concrete replace
fill ~199 ~148 ~651 ~199 ~148 ~652 minecraft:light_gray_concrete replace
fill ~202 ~148 ~651 ~202 ~148 ~652 minecraft:light_gray_concrete replace
fill ~205 ~148 ~651 ~205 ~148 ~652 minecraft:light_gray_concrete replace
fill ~208 ~148 ~651 ~208 ~148 ~652 minecraft:light_gray_concrete replace
fill ~211 ~148 ~651 ~211 ~148 ~652 minecraft:light_gray_concrete replace
fill ~214 ~148 ~651 ~214 ~148 ~652 minecraft:light_gray_concrete replace
fill ~217 ~148 ~651 ~217 ~148 ~652 minecraft:light_gray_concrete replace
fill ~220 ~148 ~651 ~220 ~148 ~652 minecraft:light_gray_concrete replace
fill ~223 ~148 ~651 ~223 ~148 ~652 minecraft:light_gray_concrete replace
fill ~226 ~148 ~651 ~226 ~148 ~652 minecraft:light_gray_concrete replace
fill ~229 ~148 ~651 ~229 ~148 ~652 minecraft:light_gray_concrete replace
fill ~126 ~148 ~654 ~272 ~148 ~654 minecraft:light_gray_concrete replace
fill ~271 ~148 ~655 ~271 ~148 ~656 minecraft:light_gray_concrete replace
fill ~129 ~148 ~662 ~275 ~148 ~662 minecraft:light_gray_concrete replace
fill ~274 ~148 ~663 ~274 ~148 ~664 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~105 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~120 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~122 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~137 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~156 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~171 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~173 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~188 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~207 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~222 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~224 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~232 ~149 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~149 ~400 minecraft:light_gray_concrete replace
setblock ~85 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~88 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~91 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~94 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~97 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~100 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~106 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~109 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~112 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~118 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~121 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~124 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~127 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~130 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~136 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~142 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~145 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~148 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~160 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~163 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~172 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~175 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~178 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~181 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~184 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~187 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~193 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~196 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~199 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~202 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~208 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~211 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~214 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~223 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~226 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~229 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~85 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~91 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~94 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~100 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~106 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~109 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~112 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~118 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~121 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~124 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~127 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~130 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~136 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~142 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~145 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~148 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~160 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~163 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~172 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~175 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~178 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~181 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~184 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~187 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~193 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~196 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~199 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~202 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~208 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~211 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~214 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~223 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~226 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~229 ~149 ~448 minecraft:light_gray_concrete replace
setblock ~79 ~149 ~452 minecraft:light_gray_concrete replace
setblock ~85 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~88 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~91 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~94 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~97 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~100 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~109 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~112 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~118 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~121 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~124 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~127 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~130 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~136 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~142 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~145 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~148 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~160 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~163 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~172 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~175 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~178 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~181 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~184 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~187 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~193 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~196 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~199 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~202 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~208 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~211 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~214 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~223 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~226 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~229 ~149 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~108 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~123 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~125 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~140 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~142 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~159 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~174 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~176 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~191 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~193 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~208 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~210 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~225 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~227 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~242 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~244 ~149 ~482 minecraft:light_gray_concrete replace
setblock ~235 ~149 ~484 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~120 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~135 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~137 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~152 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~171 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~186 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~188 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~203 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~222 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~237 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~239 ~149 ~502 minecraft:light_gray_concrete replace
setblock ~241 ~149 ~504 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~504 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~117 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~132 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~134 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~149 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~168 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~183 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~185 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~200 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~202 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~219 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~234 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~236 ~149 ~514 minecraft:light_gray_concrete replace
setblock ~238 ~149 ~516 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~516 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~117 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~132 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~134 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~149 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~168 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~183 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~185 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~200 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~202 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~219 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~234 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~236 ~149 ~538 minecraft:light_gray_concrete replace
setblock ~244 ~149 ~540 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~123 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~138 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~140 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~155 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~546 minecraft:light_gray_concrete replace
