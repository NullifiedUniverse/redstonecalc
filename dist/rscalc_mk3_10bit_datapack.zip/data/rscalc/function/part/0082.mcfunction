setblock ~169 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~57 ~642 ~184 ~57 ~642 minecraft:redstone_wire replace
setblock ~186 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~57 ~642 ~201 ~57 ~642 minecraft:redstone_wire replace
setblock ~203 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~57 ~642 ~218 ~57 ~642 minecraft:redstone_wire replace
setblock ~220 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~57 ~642 ~228 ~57 ~642 minecraft:redstone_wire replace
setblock ~211 ~57 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~57 ~646 ~211 ~57 ~646 minecraft:redstone_wire replace
setblock ~212 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~57 ~646 ~226 ~57 ~646 minecraft:redstone_wire replace
setblock ~228 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~57 ~646 ~243 ~57 ~646 minecraft:redstone_wire replace
setblock ~245 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~57 ~646 ~260 ~57 ~646 minecraft:redstone_wire replace
setblock ~262 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~57 ~646 ~277 ~57 ~646 minecraft:redstone_wire replace
setblock ~279 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~57 ~646 ~294 ~57 ~646 minecraft:redstone_wire replace
setblock ~296 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~57 ~646 ~311 ~57 ~646 minecraft:redstone_wire replace
setblock ~313 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~57 ~646 ~321 ~57 ~646 minecraft:redstone_wire replace
setblock ~79 ~57 ~649 minecraft:redstone_wire replace
fill ~78 ~57 ~650 ~86 ~57 ~650 minecraft:redstone_wire replace
setblock ~88 ~57 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~57 ~650 ~96 ~57 ~650 minecraft:redstone_wire replace
setblock ~187 ~57 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~57 ~654 ~199 ~57 ~654 minecraft:redstone_wire replace
setblock ~201 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~57 ~654 ~216 ~57 ~654 minecraft:redstone_wire replace
setblock ~218 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~57 ~654 ~233 ~57 ~654 minecraft:redstone_wire replace
setblock ~235 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~57 ~654 ~250 ~57 ~654 minecraft:redstone_wire replace
setblock ~252 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~57 ~654 ~267 ~57 ~654 minecraft:redstone_wire replace
setblock ~269 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~57 ~654 ~284 ~57 ~654 minecraft:redstone_wire replace
setblock ~286 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~57 ~654 ~294 ~57 ~654 minecraft:redstone_wire replace
setblock ~208 ~57 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~57 ~658 ~208 ~57 ~658 minecraft:redstone_wire replace
setblock ~209 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~658 ~223 ~57 ~658 minecraft:redstone_wire replace
setblock ~225 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~57 ~658 ~240 ~57 ~658 minecraft:redstone_wire replace
setblock ~242 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~57 ~658 ~257 ~57 ~658 minecraft:redstone_wire replace
setblock ~259 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~57 ~658 ~274 ~57 ~658 minecraft:redstone_wire replace
setblock ~276 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~57 ~658 ~291 ~57 ~658 minecraft:redstone_wire replace
setblock ~293 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~57 ~658 ~308 ~57 ~658 minecraft:redstone_wire replace
setblock ~310 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~57 ~658 ~318 ~57 ~658 minecraft:redstone_wire replace
setblock ~169 ~58 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~58 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~58 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~58 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~58 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~58 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~58 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~58 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~58 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~58 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~58 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~58 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~58 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~58 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~58 ~396 minecraft:redstone_wire replace
setblock ~79 ~58 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~416 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~420 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~424 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~58 ~428 minecraft:redstone_wire replace
setblock ~136 ~58 ~432 minecraft:redstone_wire replace
setblock ~157 ~58 ~436 minecraft:redstone_wire replace
setblock ~166 ~58 ~440 minecraft:redstone_wire replace
setblock ~79 ~58 ~444 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~452 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~456 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~460 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~58 ~464 minecraft:redstone_wire replace
setblock ~130 ~58 ~468 minecraft:redstone_wire replace
setblock ~154 ~58 ~472 minecraft:redstone_wire replace
setblock ~181 ~58 ~476 minecraft:redstone_wire replace
setblock ~205 ~58 ~480 minecraft:redstone_wire replace
setblock ~79 ~58 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~488 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~500 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~58 ~504 minecraft:redstone_wire replace
setblock ~127 ~58 ~508 minecraft:redstone_wire replace
setblock ~151 ~58 ~512 minecraft:redstone_wire replace
setblock ~178 ~58 ~516 minecraft:redstone_wire replace
setblock ~202 ~58 ~520 minecraft:redstone_wire replace
setblock ~79 ~58 ~524 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~58 ~544 minecraft:redstone_wire replace
setblock ~124 ~58 ~548 minecraft:redstone_wire replace
setblock ~145 ~58 ~552 minecraft:redstone_wire replace
setblock ~175 ~58 ~556 minecraft:redstone_wire replace
setblock ~196 ~58 ~560 minecraft:redstone_wire replace
setblock ~79 ~58 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~576 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~58 ~584 minecraft:redstone_wire replace
setblock ~121 ~58 ~588 minecraft:redstone_wire replace
setblock ~142 ~58 ~592 minecraft:redstone_wire replace
setblock ~172 ~58 ~596 minecraft:redstone_wire replace
setblock ~193 ~58 ~600 minecraft:redstone_wire replace
setblock ~82 ~58 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~58 ~620 minecraft:redstone_wire replace
setblock ~115 ~58 ~624 minecraft:redstone_wire replace
setblock ~148 ~58 ~628 minecraft:redstone_wire replace
setblock ~160 ~58 ~632 minecraft:redstone_wire replace
setblock ~184 ~58 ~636 minecraft:redstone_wire replace
setblock ~133 ~58 ~640 minecraft:redstone_wire replace
setblock ~211 ~58 ~644 minecraft:redstone_wire replace
setblock ~79 ~58 ~648 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~58 ~652 minecraft:redstone_wire replace
setblock ~208 ~58 ~656 minecraft:redstone_wire replace
fill ~168 ~59 ~72 ~168 ~59 ~84 minecraft:redstone_wire replace
setblock ~168 ~59 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~88 ~168 ~59 ~100 minecraft:redstone_wire replace
setblock ~168 ~59 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~104 ~168 ~59 ~116 minecraft:redstone_wire replace
setblock ~168 ~59 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~120 ~168 ~59 ~132 minecraft:redstone_wire replace
setblock ~168 ~59 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~136 ~168 ~59 ~148 minecraft:redstone_wire replace
setblock ~168 ~59 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~152 ~168 ~59 ~164 minecraft:redstone_wire replace
setblock ~168 ~59 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~168 ~168 ~59 ~180 minecraft:redstone_wire replace
setblock ~168 ~59 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~184 ~168 ~59 ~196 minecraft:redstone_wire replace
setblock ~168 ~59 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~200 ~168 ~59 ~212 minecraft:redstone_wire replace
setblock ~168 ~59 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~216 ~168 ~59 ~228 minecraft:redstone_wire replace
setblock ~168 ~59 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~232 ~168 ~59 ~244 minecraft:redstone_wire replace
fill ~78 ~59 ~244 ~78 ~59 ~256 minecraft:redstone_wire replace
setblock ~168 ~59 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~248 ~168 ~59 ~260 minecraft:redstone_wire replace
setblock ~78 ~59 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~260 ~78 ~59 ~272 minecraft:redstone_wire replace
setblock ~168 ~59 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~264 ~81 ~59 ~276 minecraft:redstone_wire replace
fill ~168 ~59 ~264 ~168 ~59 ~276 minecraft:redstone_wire replace
setblock ~78 ~59 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~276 ~78 ~59 ~288 minecraft:redstone_wire replace
setblock ~81 ~59 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~280 ~81 ~59 ~292 minecraft:redstone_wire replace
fill ~84 ~59 ~280 ~84 ~59 ~292 minecraft:redstone_wire replace
fill ~168 ~59 ~280 ~168 ~59 ~292 minecraft:redstone_wire replace
setblock ~78 ~59 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~292 ~78 ~59 ~304 minecraft:redstone_wire replace
fill ~87 ~59 ~292 ~87 ~59 ~304 minecraft:redstone_wire replace
setblock ~81 ~59 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~296 ~81 ~59 ~308 minecraft:redstone_wire replace
fill ~84 ~59 ~296 ~84 ~59 ~308 minecraft:redstone_wire replace
fill ~168 ~59 ~296 ~168 ~59 ~308 minecraft:redstone_wire replace
setblock ~78 ~59 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~308 ~78 ~59 ~320 minecraft:redstone_wire replace
fill ~87 ~59 ~308 ~87 ~59 ~320 minecraft:redstone_wire replace
setblock ~81 ~59 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~312 ~81 ~59 ~324 minecraft:redstone_wire replace
fill ~84 ~59 ~312 ~84 ~59 ~324 minecraft:redstone_wire replace
fill ~168 ~59 ~312 ~168 ~59 ~324 minecraft:redstone_wire replace
fill ~90 ~59 ~316 ~90 ~59 ~328 minecraft:redstone_wire replace
fill ~99 ~59 ~320 ~99 ~59 ~326 minecraft:redstone_wire replace
setblock ~78 ~59 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~324 ~78 ~59 ~336 minecraft:redstone_wire replace
fill ~87 ~59 ~324 ~87 ~59 ~336 minecraft:redstone_wire replace
setblock ~81 ~59 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~328 ~81 ~59 ~340 minecraft:redstone_wire replace
fill ~84 ~59 ~328 ~84 ~59 ~340 minecraft:redstone_wire replace
setblock ~99 ~59 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~328 ~168 ~59 ~340 minecraft:redstone_wire replace
setblock ~90 ~59 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~332 ~90 ~59 ~344 minecraft:redstone_wire replace
fill ~117 ~59 ~336 ~117 ~59 ~342 minecraft:redstone_wire replace
setblock ~78 ~59 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~340 ~78 ~59 ~352 minecraft:redstone_wire replace
fill ~87 ~59 ~340 ~87 ~59 ~352 minecraft:redstone_wire replace
setblock ~81 ~59 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~344 ~81 ~59 ~356 minecraft:redstone_wire replace
fill ~84 ~59 ~344 ~84 ~59 ~356 minecraft:redstone_wire replace
setblock ~117 ~59 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~344 ~168 ~59 ~356 minecraft:redstone_wire replace
setblock ~90 ~59 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~348 ~90 ~59 ~360 minecraft:redstone_wire replace
fill ~162 ~59 ~352 ~162 ~59 ~358 minecraft:redstone_wire replace
setblock ~78 ~59 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~356 ~78 ~59 ~368 minecraft:redstone_wire replace
fill ~87 ~59 ~356 ~87 ~59 ~368 minecraft:redstone_wire replace
setblock ~81 ~59 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~360 ~81 ~59 ~372 minecraft:redstone_wire replace
fill ~84 ~59 ~360 ~84 ~59 ~372 minecraft:redstone_wire replace
setblock ~162 ~59 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~360 ~168 ~59 ~372 minecraft:redstone_wire replace
fill ~198 ~59 ~360 ~198 ~59 ~372 minecraft:redstone_wire replace
setblock ~90 ~59 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~364 ~90 ~59 ~376 minecraft:redstone_wire replace
fill ~138 ~59 ~368 ~138 ~59 ~374 minecraft:redstone_wire replace
setblock ~78 ~59 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~372 ~78 ~59 ~384 minecraft:redstone_wire replace
fill ~87 ~59 ~372 ~87 ~59 ~384 minecraft:redstone_wire replace
setblock ~81 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~376 ~81 ~59 ~388 minecraft:redstone_wire replace
fill ~84 ~59 ~376 ~84 ~59 ~388 minecraft:redstone_wire replace
setblock ~138 ~59 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~376 ~168 ~59 ~388 minecraft:redstone_wire replace
fill ~198 ~59 ~376 ~198 ~59 ~388 minecraft:redstone_wire replace
setblock ~90 ~59 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~380 ~90 ~59 ~392 minecraft:redstone_wire replace
setblock ~78 ~59 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~388 ~78 ~59 ~400 minecraft:redstone_wire replace
fill ~87 ~59 ~388 ~87 ~59 ~400 minecraft:redstone_wire replace
setblock ~198 ~59 ~389 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~59 ~390 ~198 ~59 ~392 minecraft:redstone_wire replace
fill ~81 ~59 ~392 ~81 ~59 ~404 minecraft:redstone_wire replace
fill ~84 ~59 ~392 ~84 ~59 ~404 minecraft:redstone_wire replace
fill ~168 ~59 ~392 ~168 ~59 ~396 minecraft:redstone_wire replace
setblock ~90 ~59 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~396 ~90 ~59 ~408 minecraft:redstone_wire replace
fill ~189 ~59 ~396 ~189 ~59 ~400 minecraft:redstone_wire replace
setblock ~78 ~59 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~404 ~78 ~59 ~416 minecraft:redstone_wire replace
fill ~87 ~59 ~404 ~87 ~59 ~416 minecraft:redstone_wire replace
setblock ~81 ~59 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~408 ~81 ~59 ~420 minecraft:redstone_wire replace
fill ~84 ~59 ~408 ~84 ~59 ~420 minecraft:redstone_wire replace
setblock ~90 ~59 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~412 ~90 ~59 ~424 minecraft:redstone_wire replace
setblock ~78 ~59 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~420 ~78 ~59 ~432 minecraft:redstone_wire replace
fill ~87 ~59 ~420 ~87 ~59 ~432 minecraft:redstone_wire replace
setblock ~81 ~59 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~424 ~81 ~59 ~436 minecraft:redstone_wire replace
fill ~84 ~59 ~424 ~84 ~59 ~436 minecraft:redstone_wire replace
setblock ~90 ~59 ~425 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~426 ~90 ~59 ~438 minecraft:redstone_wire replace
fill ~111 ~59 ~428 ~111 ~59 ~432 minecraft:redstone_wire replace
fill ~135 ~59 ~432 ~135 ~59 ~436 minecraft:redstone_wire replace
setblock ~78 ~59 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~436 ~78 ~59 ~448 minecraft:redstone_wire replace
fill ~87 ~59 ~436 ~87 ~59 ~448 minecraft:redstone_wire replace
fill ~156 ~59 ~436 ~156 ~59 ~440 minecraft:redstone_wire replace
setblock ~81 ~59 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~440 ~81 ~59 ~452 minecraft:redstone_wire replace
fill ~84 ~59 ~440 ~84 ~59 ~452 minecraft:redstone_wire replace
setblock ~90 ~59 ~440 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~59 ~440 ~165 ~59 ~444 minecraft:redstone_wire replace
fill ~90 ~59 ~442 ~90 ~59 ~454 minecraft:redstone_wire replace
setblock ~78 ~59 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~452 ~78 ~59 ~464 minecraft:redstone_wire replace
fill ~87 ~59 ~452 ~87 ~59 ~464 minecraft:redstone_wire replace
setblock ~84 ~59 ~453 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~454 ~84 ~59 ~466 minecraft:redstone_wire replace
fill ~81 ~59 ~456 ~81 ~59 ~468 minecraft:redstone_wire replace
setblock ~90 ~59 ~456 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~458 ~90 ~59 ~470 minecraft:redstone_wire replace
fill ~108 ~59 ~464 ~108 ~59 ~468 minecraft:redstone_wire replace
setblock ~78 ~59 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~468 ~78 ~59 ~480 minecraft:redstone_wire replace
setblock ~84 ~59 ~468 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~468 ~87 ~59 ~480 minecraft:redstone_wire replace
fill ~129 ~59 ~468 ~129 ~59 ~472 minecraft:redstone_wire replace
setblock ~81 ~59 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~470 ~84 ~59 ~482 minecraft:redstone_wire replace
fill ~81 ~59 ~472 ~81 ~59 ~484 minecraft:redstone_wire replace
setblock ~90 ~59 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~59 ~472 ~153 ~59 ~476 minecraft:redstone_wire replace
fill ~90 ~59 ~474 ~90 ~59 ~486 minecraft:redstone_wire replace
fill ~180 ~59 ~476 ~180 ~59 ~480 minecraft:redstone_wire replace
fill ~204 ~59 ~480 ~204 ~59 ~484 minecraft:redstone_wire replace
setblock ~78 ~59 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~484 ~78 ~59 ~496 minecraft:redstone_wire replace
setblock ~84 ~59 ~484 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~484 ~87 ~59 ~496 minecraft:redstone_wire replace
setblock ~81 ~59 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~486 ~84 ~59 ~498 minecraft:redstone_wire replace
fill ~81 ~59 ~488 ~81 ~59 ~500 minecraft:redstone_wire replace
setblock ~90 ~59 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~490 ~90 ~59 ~502 minecraft:redstone_wire replace
setblock ~87 ~59 ~497 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~59 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~498 ~87 ~59 ~510 minecraft:redstone_wire replace
fill ~78 ~59 ~500 ~78 ~59 ~512 minecraft:redstone_wire replace
setblock ~84 ~59 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~502 ~84 ~59 ~514 minecraft:redstone_wire replace
fill ~81 ~59 ~504 ~81 ~59 ~516 minecraft:redstone_wire replace
setblock ~90 ~59 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~59 ~504 ~105 ~59 ~508 minecraft:redstone_wire replace
fill ~90 ~59 ~506 ~90 ~59 ~518 minecraft:redstone_wire replace
fill ~126 ~59 ~508 ~126 ~59 ~512 minecraft:redstone_wire replace
setblock ~87 ~59 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~59 ~512 ~150 ~59 ~516 minecraft:redstone_wire replace
setblock ~78 ~59 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~514 ~87 ~59 ~526 minecraft:redstone_wire replace
fill ~78 ~59 ~516 ~78 ~59 ~528 minecraft:redstone_wire replace
setblock ~84 ~59 ~516 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~59 ~516 ~177 ~59 ~520 minecraft:redstone_wire replace
setblock ~81 ~59 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~518 ~84 ~59 ~530 minecraft:redstone_wire replace
fill ~81 ~59 ~520 ~81 ~59 ~532 minecraft:redstone_wire replace
setblock ~90 ~59 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~59 ~520 ~201 ~59 ~524 minecraft:redstone_wire replace
fill ~90 ~59 ~522 ~90 ~59 ~534 minecraft:redstone_wire replace
setblock ~87 ~59 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~59 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~530 ~87 ~59 ~542 minecraft:redstone_wire replace
setblock ~84 ~59 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~532 ~78 ~59 ~544 minecraft:redstone_wire replace
fill ~84 ~59 ~532 ~84 ~59 ~544 minecraft:redstone_wire replace
setblock ~81 ~59 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~536 ~81 ~59 ~548 minecraft:redstone_wire replace
setblock ~90 ~59 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~538 ~90 ~59 ~550 minecraft:redstone_wire replace
setblock ~87 ~59 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~59 ~544 ~102 ~59 ~548 minecraft:redstone_wire replace
setblock ~78 ~59 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~546 ~87 ~59 ~558 minecraft:redstone_wire replace
fill ~78 ~59 ~548 ~78 ~59 ~560 minecraft:redstone_wire replace
fill ~84 ~59 ~548 ~84 ~59 ~560 minecraft:redstone_wire replace
fill ~123 ~59 ~548 ~123 ~59 ~552 minecraft:redstone_wire replace
setblock ~81 ~59 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~552 ~81 ~59 ~564 minecraft:redstone_wire replace
setblock ~90 ~59 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~59 ~552 ~144 ~59 ~556 minecraft:redstone_wire replace
fill ~90 ~59 ~554 ~90 ~59 ~566 minecraft:redstone_wire replace
fill ~174 ~59 ~556 ~174 ~59 ~560 minecraft:redstone_wire replace
setblock ~87 ~59 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~59 ~560 ~195 ~59 ~564 minecraft:redstone_wire replace
setblock ~78 ~59 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~562 ~87 ~59 ~574 minecraft:redstone_wire replace
fill ~78 ~59 ~564 ~78 ~59 ~576 minecraft:redstone_wire replace
fill ~84 ~59 ~564 ~84 ~59 ~576 minecraft:redstone_wire replace
setblock ~81 ~59 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~568 ~81 ~59 ~580 minecraft:redstone_wire replace
setblock ~90 ~59 ~568 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~570 ~90 ~59 ~582 minecraft:redstone_wire replace
setblock ~87 ~59 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~576 ~87 ~59 ~588 minecraft:redstone_wire replace
setblock ~78 ~59 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~580 ~78 ~59 ~592 minecraft:redstone_wire replace
fill ~84 ~59 ~580 ~84 ~59 ~592 minecraft:redstone_wire replace
setblock ~81 ~59 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~584 ~81 ~59 ~596 minecraft:redstone_wire replace
setblock ~90 ~59 ~584 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~59 ~584 ~96 ~59 ~588 minecraft:redstone_wire replace
fill ~90 ~59 ~586 ~90 ~59 ~598 minecraft:redstone_wire replace
fill ~120 ~59 ~588 ~120 ~59 ~592 minecraft:redstone_wire replace
setblock ~87 ~59 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~592 ~87 ~59 ~604 minecraft:redstone_wire replace
fill ~141 ~59 ~592 ~141 ~59 ~596 minecraft:redstone_wire replace
setblock ~78 ~59 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~596 ~78 ~59 ~608 minecraft:redstone_wire replace
fill ~84 ~59 ~596 ~84 ~59 ~608 minecraft:redstone_wire replace
fill ~171 ~59 ~596 ~171 ~59 ~600 minecraft:redstone_wire replace
setblock ~81 ~59 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~600 ~81 ~59 ~606 minecraft:redstone_wire replace
setblock ~90 ~59 ~600 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~59 ~600 ~192 ~59 ~604 minecraft:redstone_wire replace
fill ~90 ~59 ~602 ~90 ~59 ~614 minecraft:redstone_wire replace
setblock ~87 ~59 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~608 ~87 ~59 ~614 minecraft:redstone_wire replace
setblock ~84 ~59 ~609 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~59 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~610 ~84 ~59 ~612 minecraft:redstone_wire replace
fill ~78 ~59 ~612 ~78 ~59 ~624 minecraft:redstone_wire replace
setblock ~90 ~59 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~616 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~616 ~90 ~59 ~620 minecraft:redstone_wire replace
fill ~93 ~59 ~620 ~93 ~59 ~624 minecraft:redstone_wire replace
fill ~114 ~59 ~624 ~114 ~59 ~628 minecraft:redstone_wire replace
setblock ~78 ~59 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~628 ~78 ~59 ~640 minecraft:redstone_wire replace
fill ~147 ~59 ~628 ~147 ~59 ~632 minecraft:redstone_wire replace
fill ~159 ~59 ~632 ~159 ~59 ~636 minecraft:redstone_wire replace
fill ~183 ~59 ~636 ~183 ~59 ~640 minecraft:redstone_wire replace
fill ~132 ~59 ~640 ~132 ~59 ~644 minecraft:redstone_wire replace
setblock ~78 ~59 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~644 ~78 ~59 ~650 minecraft:redstone_wire replace
fill ~210 ~59 ~644 ~210 ~59 ~648 minecraft:redstone_wire replace
setblock ~78 ~59 ~652 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~59 ~652 ~186 ~59 ~656 minecraft:redstone_wire replace
fill ~207 ~59 ~656 ~207 ~59 ~660 minecraft:redstone_wire replace
setblock ~99 ~60 ~329 minecraft:redstone_wire replace
setblock ~117 ~60 ~345 minecraft:redstone_wire replace
setblock ~162 ~60 ~361 minecraft:redstone_wire replace
setblock ~138 ~60 ~377 minecraft:redstone_wire replace
setblock ~198 ~60 ~393 minecraft:redstone_wire replace
setblock ~168 ~60 ~397 minecraft:redstone_wire replace
setblock ~189 ~60 ~401 minecraft:redstone_wire replace
setblock ~111 ~60 ~433 minecraft:redstone_wire replace
setblock ~135 ~60 ~437 minecraft:redstone_wire replace
setblock ~156 ~60 ~441 minecraft:redstone_wire replace
setblock ~165 ~60 ~445 minecraft:redstone_wire replace
setblock ~108 ~60 ~469 minecraft:redstone_wire replace
setblock ~129 ~60 ~473 minecraft:redstone_wire replace
setblock ~153 ~60 ~477 minecraft:redstone_wire replace
setblock ~180 ~60 ~481 minecraft:redstone_wire replace
setblock ~204 ~60 ~485 minecraft:redstone_wire replace
setblock ~105 ~60 ~509 minecraft:redstone_wire replace
setblock ~126 ~60 ~513 minecraft:redstone_wire replace
setblock ~150 ~60 ~517 minecraft:redstone_wire replace
setblock ~177 ~60 ~521 minecraft:redstone_wire replace
setblock ~201 ~60 ~525 minecraft:redstone_wire replace
setblock ~102 ~60 ~549 minecraft:redstone_wire replace
setblock ~123 ~60 ~553 minecraft:redstone_wire replace
setblock ~144 ~60 ~557 minecraft:redstone_wire replace
setblock ~174 ~60 ~561 minecraft:redstone_wire replace
setblock ~195 ~60 ~565 minecraft:redstone_wire replace
setblock ~96 ~60 ~589 minecraft:redstone_wire replace
setblock ~120 ~60 ~593 minecraft:redstone_wire replace
setblock ~141 ~60 ~597 minecraft:redstone_wire replace
setblock ~171 ~60 ~601 minecraft:redstone_wire replace
setblock ~192 ~60 ~605 minecraft:redstone_wire replace
setblock ~81 ~60 ~609 minecraft:redstone_wire replace
setblock ~84 ~60 ~613 minecraft:redstone_wire replace
setblock ~87 ~60 ~617 minecraft:redstone_wire replace
setblock ~90 ~60 ~621 minecraft:redstone_wire replace
setblock ~93 ~60 ~625 minecraft:redstone_wire replace
setblock ~114 ~60 ~629 minecraft:redstone_wire replace
setblock ~147 ~60 ~633 minecraft:redstone_wire replace
setblock ~159 ~60 ~637 minecraft:redstone_wire replace
setblock ~183 ~60 ~641 minecraft:redstone_wire replace
setblock ~132 ~60 ~645 minecraft:redstone_wire replace
setblock ~210 ~60 ~649 minecraft:redstone_wire replace
setblock ~78 ~60 ~653 minecraft:redstone_wire replace
setblock ~186 ~60 ~657 minecraft:redstone_wire replace
setblock ~207 ~60 ~661 minecraft:redstone_wire replace
fill ~99 ~61 ~330 ~104 ~61 ~330 minecraft:redstone_wire replace
setblock ~103 ~61 ~331 minecraft:redstone_wire replace
fill ~117 ~61 ~346 ~122 ~61 ~346 minecraft:redstone_wire replace
setblock ~121 ~61 ~347 minecraft:redstone_wire replace
fill ~162 ~61 ~362 ~164 ~61 ~362 minecraft:redstone_wire replace
setblock ~163 ~61 ~363 minecraft:redstone_wire replace
fill ~138 ~61 ~378 ~140 ~61 ~378 minecraft:redstone_wire replace
setblock ~139 ~61 ~379 minecraft:redstone_wire replace
fill ~186 ~61 ~394 ~187 ~61 ~394 minecraft:redstone_wire replace
setblock ~188 ~61 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~61 ~394 ~206 ~61 ~394 minecraft:redstone_wire replace
setblock ~207 ~61 ~394 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~61 ~394 ~212 ~61 ~394 minecraft:redstone_wire replace
setblock ~187 ~61 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~190 ~61 ~395 minecraft:redstone_wire replace
setblock ~208 ~61 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~211 ~61 ~395 minecraft:redstone_wire replace
fill ~81 ~61 ~398 ~90 ~61 ~398 minecraft:redstone_wire replace
setblock ~92 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~61 ~398 ~107 ~61 ~398 minecraft:redstone_wire replace
setblock ~109 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~61 ~398 ~124 ~61 ~398 minecraft:redstone_wire replace
setblock ~126 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~61 ~398 ~141 ~61 ~398 minecraft:redstone_wire replace
setblock ~143 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~61 ~398 ~158 ~61 ~398 minecraft:redstone_wire replace
setblock ~160 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~61 ~398 ~174 ~61 ~398 minecraft:redstone_wire replace
setblock ~176 ~61 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~61 ~398 ~191 ~61 ~398 minecraft:redstone_wire replace
setblock ~193 ~61 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~61 ~398 ~208 ~61 ~398 minecraft:redstone_wire replace
setblock ~209 ~61 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~61 ~398 ~212 ~61 ~398 minecraft:redstone_wire replace
setblock ~82 ~61 ~399 minecraft:redstone_wire replace
setblock ~208 ~61 ~399 minecraft:redstone_wire replace
setblock ~211 ~61 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~61 ~402 ~191 ~61 ~402 minecraft:redstone_wire replace
setblock ~187 ~61 ~403 minecraft:redstone_wire replace
setblock ~190 ~61 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~61 ~434 ~116 ~61 ~434 minecraft:redstone_wire replace
setblock ~115 ~61 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~61 ~438 ~137 ~61 ~438 minecraft:redstone_wire replace
setblock ~136 ~61 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~61 ~442 ~158 ~61 ~442 minecraft:redstone_wire replace
setblock ~157 ~61 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~61 ~446 ~167 ~61 ~446 minecraft:redstone_wire replace
setblock ~166 ~61 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~61 ~470 ~113 ~61 ~470 minecraft:redstone_wire replace
setblock ~112 ~61 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~61 ~474 ~134 ~61 ~474 minecraft:redstone_wire replace
setblock ~133 ~61 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~61 ~478 ~155 ~61 ~478 minecraft:redstone_wire replace
setblock ~154 ~61 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~61 ~482 ~180 ~61 ~482 minecraft:redstone_wire replace
setblock ~178 ~61 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~61 ~486 ~206 ~61 ~486 minecraft:redstone_wire replace
setblock ~205 ~61 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~61 ~510 ~110 ~61 ~510 minecraft:redstone_wire replace
setblock ~109 ~61 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~61 ~514 ~131 ~61 ~514 minecraft:redstone_wire replace
setblock ~130 ~61 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~61 ~518 ~152 ~61 ~518 minecraft:redstone_wire replace
setblock ~151 ~61 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~61 ~522 ~177 ~61 ~522 minecraft:redstone_wire replace
setblock ~175 ~61 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~61 ~526 ~203 ~61 ~526 minecraft:redstone_wire replace
setblock ~202 ~61 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~61 ~550 ~107 ~61 ~550 minecraft:redstone_wire replace
setblock ~106 ~61 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~61 ~554 ~128 ~61 ~554 minecraft:redstone_wire replace
setblock ~127 ~61 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~61 ~558 ~146 ~61 ~558 minecraft:redstone_wire replace
setblock ~145 ~61 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~61 ~562 ~174 ~61 ~562 minecraft:redstone_wire replace
setblock ~172 ~61 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~61 ~566 ~197 ~61 ~566 minecraft:redstone_wire replace
setblock ~196 ~61 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~61 ~590 ~101 ~61 ~590 minecraft:redstone_wire replace
setblock ~100 ~61 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~61 ~594 ~125 ~61 ~594 minecraft:redstone_wire replace
setblock ~124 ~61 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~61 ~598 ~143 ~61 ~598 minecraft:redstone_wire replace
setblock ~142 ~61 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~61 ~602 ~171 ~61 ~602 minecraft:redstone_wire replace
setblock ~169 ~61 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~61 ~606 ~194 ~61 ~606 minecraft:redstone_wire replace
setblock ~193 ~61 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~61 ~610 ~86 ~61 ~610 minecraft:redstone_wire replace
setblock ~85 ~61 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~61 ~614 ~89 ~61 ~614 minecraft:redstone_wire replace
setblock ~88 ~61 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~61 ~618 ~92 ~61 ~618 minecraft:redstone_wire replace
setblock ~91 ~61 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~61 ~622 ~95 ~61 ~622 minecraft:redstone_wire replace
setblock ~94 ~61 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~61 ~626 ~98 ~61 ~626 minecraft:redstone_wire replace
setblock ~97 ~61 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~61 ~630 ~119 ~61 ~630 minecraft:redstone_wire replace
setblock ~118 ~61 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~61 ~634 ~149 ~61 ~634 minecraft:redstone_wire replace
setblock ~148 ~61 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~61 ~638 ~161 ~61 ~638 minecraft:redstone_wire replace
setblock ~160 ~61 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~61 ~642 ~183 ~61 ~642 minecraft:redstone_wire replace
setblock ~181 ~61 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~61 ~646 ~88 ~61 ~646 minecraft:redstone_wire replace
