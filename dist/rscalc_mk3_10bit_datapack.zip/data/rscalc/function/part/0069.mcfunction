setblock ~229 ~33 ~301 minecraft:redstone_wire replace
setblock ~262 ~33 ~301 minecraft:redstone_wire replace
setblock ~283 ~33 ~301 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~33 ~301 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~33 ~302 ~249 ~33 ~302 minecraft:redstone_wire replace
setblock ~251 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~33 ~302 ~266 ~33 ~302 minecraft:redstone_wire replace
setblock ~268 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~33 ~302 ~283 ~33 ~302 minecraft:redstone_wire replace
setblock ~284 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~33 ~302 ~298 ~33 ~302 minecraft:redstone_wire replace
setblock ~300 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~33 ~302 ~315 ~33 ~302 minecraft:redstone_wire replace
setblock ~317 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~319 ~33 ~302 ~332 ~33 ~302 minecraft:redstone_wire replace
setblock ~333 ~33 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~33 ~302 ~335 ~33 ~302 minecraft:redstone_wire replace
setblock ~265 ~33 ~309 minecraft:redstone_wire replace
setblock ~316 ~33 ~309 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~325 ~33 ~309 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~33 ~309 minecraft:redstone_wire replace
fill ~264 ~33 ~310 ~279 ~33 ~310 minecraft:redstone_wire replace
setblock ~281 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~33 ~310 ~296 ~33 ~310 minecraft:redstone_wire replace
setblock ~298 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~33 ~310 ~313 ~33 ~310 minecraft:redstone_wire replace
setblock ~314 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~33 ~310 ~328 ~33 ~310 minecraft:redstone_wire replace
setblock ~330 ~33 ~310 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~332 ~33 ~310 ~341 ~33 ~310 minecraft:redstone_wire replace
setblock ~319 ~33 ~317 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~33 ~317 minecraft:redstone_wire replace
setblock ~343 ~33 ~317 minecraft:redstone_wire replace
fill ~273 ~33 ~318 ~285 ~33 ~318 minecraft:redstone_wire replace
setblock ~287 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~289 ~33 ~318 ~302 ~33 ~318 minecraft:redstone_wire replace
setblock ~304 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~306 ~33 ~318 ~319 ~33 ~318 minecraft:redstone_wire replace
setblock ~320 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~321 ~33 ~318 ~334 ~33 ~318 minecraft:redstone_wire replace
setblock ~335 ~33 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~336 ~33 ~318 ~344 ~33 ~318 minecraft:redstone_wire replace
setblock ~286 ~33 ~325 minecraft:redstone_wire replace
setblock ~328 ~33 ~325 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~33 ~325 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~33 ~325 minecraft:redstone_wire replace
fill ~279 ~33 ~326 ~291 ~33 ~326 minecraft:redstone_wire replace
setblock ~293 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~33 ~326 ~308 ~33 ~326 minecraft:redstone_wire replace
setblock ~310 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~326 ~325 ~33 ~326 minecraft:redstone_wire replace
setblock ~326 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~33 ~326 ~340 ~33 ~326 minecraft:redstone_wire replace
setblock ~342 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~33 ~326 ~357 ~33 ~326 minecraft:redstone_wire replace
setblock ~359 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~361 ~33 ~326 ~374 ~33 ~326 minecraft:redstone_wire replace
setblock ~376 ~33 ~326 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~378 ~33 ~326 ~389 ~33 ~326 minecraft:redstone_wire replace
setblock ~355 ~33 ~333 minecraft:redstone_wire replace
setblock ~361 ~33 ~333 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~33 ~333 minecraft:redstone_wire replace
fill ~294 ~33 ~334 ~306 ~33 ~334 minecraft:redstone_wire replace
setblock ~308 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~33 ~334 ~323 ~33 ~334 minecraft:redstone_wire replace
setblock ~325 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~33 ~334 ~340 ~33 ~334 minecraft:redstone_wire replace
setblock ~342 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~33 ~334 ~357 ~33 ~334 minecraft:redstone_wire replace
setblock ~359 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~361 ~33 ~334 ~374 ~33 ~334 minecraft:redstone_wire replace
setblock ~376 ~33 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~378 ~33 ~334 ~380 ~33 ~334 minecraft:redstone_wire replace
setblock ~91 ~33 ~341 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~33 ~342 ~92 ~33 ~342 minecraft:redstone_wire replace
setblock ~115 ~33 ~345 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~33 ~346 ~116 ~33 ~346 minecraft:redstone_wire replace
setblock ~139 ~33 ~349 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~33 ~350 ~140 ~33 ~350 minecraft:redstone_wire replace
setblock ~187 ~33 ~353 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~33 ~354 ~171 ~33 ~354 minecraft:redstone_wire replace
setblock ~173 ~33 ~354 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~33 ~354 ~188 ~33 ~354 minecraft:redstone_wire replace
setblock ~217 ~33 ~357 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~33 ~358 ~195 ~33 ~358 minecraft:redstone_wire replace
setblock ~197 ~33 ~358 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~199 ~33 ~358 ~212 ~33 ~358 minecraft:redstone_wire replace
setblock ~214 ~33 ~358 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~216 ~33 ~358 ~218 ~33 ~358 minecraft:redstone_wire replace
setblock ~244 ~33 ~361 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~219 ~33 ~362 ~225 ~33 ~362 minecraft:redstone_wire replace
setblock ~227 ~33 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~33 ~362 ~242 ~33 ~362 minecraft:redstone_wire replace
setblock ~243 ~33 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~33 ~362 ~245 ~33 ~362 minecraft:redstone_wire replace
setblock ~280 ~33 ~365 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~33 ~366 ~249 ~33 ~366 minecraft:redstone_wire replace
setblock ~251 ~33 ~366 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~33 ~366 ~266 ~33 ~366 minecraft:redstone_wire replace
setblock ~268 ~33 ~366 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~33 ~366 ~281 ~33 ~366 minecraft:redstone_wire replace
setblock ~310 ~33 ~369 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~261 ~33 ~370 ~267 ~33 ~370 minecraft:redstone_wire replace
setblock ~269 ~33 ~370 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~271 ~33 ~370 ~284 ~33 ~370 minecraft:redstone_wire replace
setblock ~286 ~33 ~370 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~33 ~370 ~301 ~33 ~370 minecraft:redstone_wire replace
setblock ~303 ~33 ~370 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~305 ~33 ~370 ~311 ~33 ~370 minecraft:redstone_wire replace
setblock ~346 ~33 ~373 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~33 ~374 ~291 ~33 ~374 minecraft:redstone_wire replace
setblock ~293 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~33 ~374 ~308 ~33 ~374 minecraft:redstone_wire replace
setblock ~310 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~374 ~325 ~33 ~374 minecraft:redstone_wire replace
setblock ~327 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~33 ~374 ~342 ~33 ~374 minecraft:redstone_wire replace
setblock ~344 ~33 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~346 ~33 ~374 ~347 ~33 ~374 minecraft:redstone_wire replace
setblock ~88 ~33 ~377 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~33 ~378 ~89 ~33 ~378 minecraft:redstone_wire replace
setblock ~112 ~33 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~33 ~382 ~113 ~33 ~382 minecraft:redstone_wire replace
setblock ~136 ~33 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~33 ~386 ~134 ~33 ~386 minecraft:redstone_wire replace
setblock ~135 ~33 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~33 ~386 ~137 ~33 ~386 minecraft:redstone_wire replace
setblock ~184 ~33 ~389 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~33 ~390 ~168 ~33 ~390 minecraft:redstone_wire replace
setblock ~170 ~33 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~33 ~390 ~185 ~33 ~390 minecraft:redstone_wire replace
setblock ~208 ~33 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~33 ~394 ~192 ~33 ~394 minecraft:redstone_wire replace
setblock ~194 ~33 ~394 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~33 ~394 ~209 ~33 ~394 minecraft:redstone_wire replace
setblock ~238 ~33 ~397 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~33 ~398 ~216 ~33 ~398 minecraft:redstone_wire replace
setblock ~218 ~33 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~33 ~398 ~233 ~33 ~398 minecraft:redstone_wire replace
setblock ~235 ~33 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~33 ~398 ~239 ~33 ~398 minecraft:redstone_wire replace
setblock ~277 ~33 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~240 ~33 ~402 ~246 ~33 ~402 minecraft:redstone_wire replace
setblock ~248 ~33 ~402 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~33 ~402 ~263 ~33 ~402 minecraft:redstone_wire replace
setblock ~265 ~33 ~402 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~33 ~402 ~278 ~33 ~402 minecraft:redstone_wire replace
setblock ~307 ~33 ~405 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~33 ~406 ~264 ~33 ~406 minecraft:redstone_wire replace
setblock ~266 ~33 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~33 ~406 ~281 ~33 ~406 minecraft:redstone_wire replace
setblock ~283 ~33 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~33 ~406 ~298 ~33 ~406 minecraft:redstone_wire replace
setblock ~300 ~33 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~302 ~33 ~406 ~308 ~33 ~406 minecraft:redstone_wire replace
setblock ~370 ~33 ~409 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~303 ~33 ~410 ~309 ~33 ~410 minecraft:redstone_wire replace
setblock ~311 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~313 ~33 ~410 ~326 ~33 ~410 minecraft:redstone_wire replace
setblock ~328 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~33 ~410 ~343 ~33 ~410 minecraft:redstone_wire replace
setblock ~345 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~347 ~33 ~410 ~360 ~33 ~410 minecraft:redstone_wire replace
setblock ~362 ~33 ~410 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~364 ~33 ~410 ~371 ~33 ~410 minecraft:redstone_wire replace
setblock ~394 ~33 ~413 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~321 ~33 ~414 ~327 ~33 ~414 minecraft:redstone_wire replace
setblock ~329 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~33 ~414 ~344 ~33 ~414 minecraft:redstone_wire replace
setblock ~346 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~33 ~414 ~361 ~33 ~414 minecraft:redstone_wire replace
setblock ~363 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~365 ~33 ~414 ~378 ~33 ~414 minecraft:redstone_wire replace
setblock ~380 ~33 ~414 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~382 ~33 ~414 ~395 ~33 ~414 minecraft:redstone_wire replace
setblock ~85 ~33 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~33 ~418 ~86 ~33 ~418 minecraft:redstone_wire replace
setblock ~109 ~33 ~421 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~33 ~422 ~110 ~33 ~422 minecraft:redstone_wire replace
setblock ~133 ~33 ~425 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~33 ~426 ~129 ~33 ~426 minecraft:redstone_wire replace
setblock ~131 ~33 ~426 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~33 ~426 ~134 ~33 ~426 minecraft:redstone_wire replace
setblock ~166 ~33 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~33 ~430 ~164 ~33 ~430 minecraft:redstone_wire replace
setblock ~165 ~33 ~430 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~166 ~33 ~430 ~167 ~33 ~430 minecraft:redstone_wire replace
setblock ~205 ~33 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~33 ~434 ~189 ~33 ~434 minecraft:redstone_wire replace
setblock ~191 ~33 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~33 ~434 ~206 ~33 ~434 minecraft:redstone_wire replace
setblock ~235 ~33 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~33 ~438 ~213 ~33 ~438 minecraft:redstone_wire replace
setblock ~215 ~33 ~438 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~33 ~438 ~230 ~33 ~438 minecraft:redstone_wire replace
setblock ~232 ~33 ~438 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~33 ~438 ~236 ~33 ~438 minecraft:redstone_wire replace
setblock ~274 ~33 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~33 ~442 ~237 ~33 ~442 minecraft:redstone_wire replace
setblock ~239 ~33 ~442 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~33 ~442 ~254 ~33 ~442 minecraft:redstone_wire replace
setblock ~256 ~33 ~442 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~258 ~33 ~442 ~271 ~33 ~442 minecraft:redstone_wire replace
setblock ~272 ~33 ~442 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~33 ~442 ~275 ~33 ~442 minecraft:redstone_wire replace
setblock ~298 ~33 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~255 ~33 ~446 ~261 ~33 ~446 minecraft:redstone_wire replace
setblock ~263 ~33 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~33 ~446 ~278 ~33 ~446 minecraft:redstone_wire replace
setblock ~280 ~33 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~33 ~446 ~295 ~33 ~446 minecraft:redstone_wire replace
setblock ~296 ~33 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~33 ~446 ~299 ~33 ~446 minecraft:redstone_wire replace
setblock ~367 ~33 ~449 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~300 ~33 ~450 ~306 ~33 ~450 minecraft:redstone_wire replace
setblock ~308 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~33 ~450 ~323 ~33 ~450 minecraft:redstone_wire replace
setblock ~325 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~33 ~450 ~340 ~33 ~450 minecraft:redstone_wire replace
setblock ~342 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~344 ~33 ~450 ~357 ~33 ~450 minecraft:redstone_wire replace
setblock ~359 ~33 ~450 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~361 ~33 ~450 ~368 ~33 ~450 minecraft:redstone_wire replace
setblock ~391 ~33 ~453 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~33 ~454 ~324 ~33 ~454 minecraft:redstone_wire replace
setblock ~326 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~328 ~33 ~454 ~341 ~33 ~454 minecraft:redstone_wire replace
setblock ~343 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~345 ~33 ~454 ~358 ~33 ~454 minecraft:redstone_wire replace
setblock ~360 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~362 ~33 ~454 ~375 ~33 ~454 minecraft:redstone_wire replace
setblock ~377 ~33 ~454 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~379 ~33 ~454 ~392 ~33 ~454 minecraft:redstone_wire replace
setblock ~82 ~33 ~457 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~33 ~458 ~83 ~33 ~458 minecraft:redstone_wire replace
setblock ~106 ~33 ~461 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~33 ~462 ~107 ~33 ~462 minecraft:redstone_wire replace
setblock ~130 ~33 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~33 ~466 ~126 ~33 ~466 minecraft:redstone_wire replace
setblock ~128 ~33 ~466 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~33 ~466 ~131 ~33 ~466 minecraft:redstone_wire replace
setblock ~160 ~33 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~33 ~470 ~153 ~33 ~470 minecraft:redstone_wire replace
setblock ~155 ~33 ~470 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~33 ~470 ~161 ~33 ~470 minecraft:redstone_wire replace
setblock ~199 ~33 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~33 ~474 ~186 ~33 ~474 minecraft:redstone_wire replace
setblock ~188 ~33 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~190 ~33 ~474 ~200 ~33 ~474 minecraft:redstone_wire replace
setblock ~232 ~33 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~33 ~478 ~210 ~33 ~478 minecraft:redstone_wire replace
setblock ~212 ~33 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~214 ~33 ~478 ~227 ~33 ~478 minecraft:redstone_wire replace
setblock ~229 ~33 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~231 ~33 ~478 ~233 ~33 ~478 minecraft:redstone_wire replace
setblock ~271 ~33 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~33 ~482 ~234 ~33 ~482 minecraft:redstone_wire replace
setblock ~236 ~33 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~33 ~482 ~251 ~33 ~482 minecraft:redstone_wire replace
setblock ~253 ~33 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~33 ~482 ~268 ~33 ~482 minecraft:redstone_wire replace
setblock ~269 ~33 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~33 ~482 ~272 ~33 ~482 minecraft:redstone_wire replace
setblock ~292 ~33 ~485 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~33 ~486 ~255 ~33 ~486 minecraft:redstone_wire replace
setblock ~257 ~33 ~486 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~33 ~486 ~272 ~33 ~486 minecraft:redstone_wire replace
setblock ~274 ~33 ~486 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~33 ~486 ~289 ~33 ~486 minecraft:redstone_wire replace
setblock ~290 ~33 ~486 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~33 ~486 ~293 ~33 ~486 minecraft:redstone_wire replace
setblock ~364 ~33 ~489 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~291 ~33 ~490 ~297 ~33 ~490 minecraft:redstone_wire replace
setblock ~299 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~301 ~33 ~490 ~314 ~33 ~490 minecraft:redstone_wire replace
setblock ~316 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~33 ~490 ~331 ~33 ~490 minecraft:redstone_wire replace
setblock ~333 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~335 ~33 ~490 ~348 ~33 ~490 minecraft:redstone_wire replace
setblock ~350 ~33 ~490 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~352 ~33 ~490 ~365 ~33 ~490 minecraft:redstone_wire replace
setblock ~385 ~33 ~493 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~33 ~494 ~321 ~33 ~494 minecraft:redstone_wire replace
setblock ~323 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~325 ~33 ~494 ~338 ~33 ~494 minecraft:redstone_wire replace
setblock ~340 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~33 ~494 ~355 ~33 ~494 minecraft:redstone_wire replace
setblock ~357 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~359 ~33 ~494 ~372 ~33 ~494 minecraft:redstone_wire replace
setblock ~374 ~33 ~494 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~376 ~33 ~494 ~386 ~33 ~494 minecraft:redstone_wire replace
setblock ~79 ~33 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~33 ~498 ~80 ~33 ~498 minecraft:redstone_wire replace
setblock ~103 ~33 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~33 ~502 ~104 ~33 ~502 minecraft:redstone_wire replace
setblock ~127 ~33 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~33 ~506 ~123 ~33 ~506 minecraft:redstone_wire replace
setblock ~125 ~33 ~506 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~33 ~506 ~128 ~33 ~506 minecraft:redstone_wire replace
setblock ~154 ~33 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~33 ~510 ~147 ~33 ~510 minecraft:redstone_wire replace
setblock ~149 ~33 ~510 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~151 ~33 ~510 ~155 ~33 ~510 minecraft:redstone_wire replace
setblock ~193 ~33 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~33 ~514 ~183 ~33 ~514 minecraft:redstone_wire replace
setblock ~185 ~33 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~33 ~514 ~194 ~33 ~514 minecraft:redstone_wire replace
setblock ~223 ~33 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~33 ~518 ~201 ~33 ~518 minecraft:redstone_wire replace
setblock ~203 ~33 ~518 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~33 ~518 ~218 ~33 ~518 minecraft:redstone_wire replace
setblock ~220 ~33 ~518 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~222 ~33 ~518 ~224 ~33 ~518 minecraft:redstone_wire replace
setblock ~268 ~33 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~225 ~33 ~522 ~231 ~33 ~522 minecraft:redstone_wire replace
setblock ~233 ~33 ~522 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~33 ~522 ~248 ~33 ~522 minecraft:redstone_wire replace
setblock ~250 ~33 ~522 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~33 ~522 ~265 ~33 ~522 minecraft:redstone_wire replace
setblock ~266 ~33 ~522 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~267 ~33 ~522 ~269 ~33 ~522 minecraft:redstone_wire replace
setblock ~289 ~33 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~33 ~526 ~252 ~33 ~526 minecraft:redstone_wire replace
setblock ~254 ~33 ~526 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~256 ~33 ~526 ~269 ~33 ~526 minecraft:redstone_wire replace
setblock ~271 ~33 ~526 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~33 ~526 ~286 ~33 ~526 minecraft:redstone_wire replace
setblock ~287 ~33 ~526 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~33 ~526 ~290 ~33 ~526 minecraft:redstone_wire replace
setblock ~358 ~33 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~288 ~33 ~530 ~294 ~33 ~530 minecraft:redstone_wire replace
setblock ~296 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~33 ~530 ~311 ~33 ~530 minecraft:redstone_wire replace
setblock ~313 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~33 ~530 ~328 ~33 ~530 minecraft:redstone_wire replace
setblock ~330 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~332 ~33 ~530 ~345 ~33 ~530 minecraft:redstone_wire replace
setblock ~347 ~33 ~530 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~349 ~33 ~530 ~359 ~33 ~530 minecraft:redstone_wire replace
setblock ~382 ~33 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~33 ~534 ~318 ~33 ~534 minecraft:redstone_wire replace
setblock ~320 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~322 ~33 ~534 ~335 ~33 ~534 minecraft:redstone_wire replace
setblock ~337 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~339 ~33 ~534 ~352 ~33 ~534 minecraft:redstone_wire replace
setblock ~354 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~356 ~33 ~534 ~369 ~33 ~534 minecraft:redstone_wire replace
setblock ~371 ~33 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~373 ~33 ~534 ~383 ~33 ~534 minecraft:redstone_wire replace
setblock ~100 ~33 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~33 ~538 ~101 ~33 ~538 minecraft:redstone_wire replace
setblock ~124 ~33 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~33 ~542 ~120 ~33 ~542 minecraft:redstone_wire replace
setblock ~122 ~33 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~33 ~542 ~125 ~33 ~542 minecraft:redstone_wire replace
setblock ~148 ~33 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~33 ~546 ~144 ~33 ~546 minecraft:redstone_wire replace
setblock ~146 ~33 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~33 ~546 ~149 ~33 ~546 minecraft:redstone_wire replace
setblock ~190 ~33 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~33 ~550 ~174 ~33 ~550 minecraft:redstone_wire replace
setblock ~176 ~33 ~550 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~33 ~550 ~191 ~33 ~550 minecraft:redstone_wire replace
setblock ~220 ~33 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~33 ~554 ~198 ~33 ~554 minecraft:redstone_wire replace
setblock ~200 ~33 ~554 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~202 ~33 ~554 ~215 ~33 ~554 minecraft:redstone_wire replace
setblock ~217 ~33 ~554 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~219 ~33 ~554 ~221 ~33 ~554 minecraft:redstone_wire replace
setblock ~250 ~33 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~222 ~33 ~558 ~228 ~33 ~558 minecraft:redstone_wire replace
setblock ~230 ~33 ~558 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~33 ~558 ~245 ~33 ~558 minecraft:redstone_wire replace
setblock ~247 ~33 ~558 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~33 ~558 ~251 ~33 ~558 minecraft:redstone_wire replace
setblock ~295 ~33 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~33 ~562 ~258 ~33 ~562 minecraft:redstone_wire replace
setblock ~260 ~33 ~562 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~33 ~562 ~275 ~33 ~562 minecraft:redstone_wire replace
setblock ~277 ~33 ~562 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~33 ~562 ~292 ~33 ~562 minecraft:redstone_wire replace
setblock ~293 ~33 ~562 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~294 ~33 ~562 ~296 ~33 ~562 minecraft:redstone_wire replace
setblock ~313 ~33 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~33 ~566 ~276 ~33 ~566 minecraft:redstone_wire replace
setblock ~278 ~33 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~33 ~566 ~293 ~33 ~566 minecraft:redstone_wire replace
setblock ~295 ~33 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~33 ~566 ~310 ~33 ~566 minecraft:redstone_wire replace
setblock ~311 ~33 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~566 ~314 ~33 ~566 minecraft:redstone_wire replace
setblock ~373 ~33 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~306 ~33 ~570 ~312 ~33 ~570 minecraft:redstone_wire replace
setblock ~314 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~316 ~33 ~570 ~329 ~33 ~570 minecraft:redstone_wire replace
setblock ~331 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~333 ~33 ~570 ~346 ~33 ~570 minecraft:redstone_wire replace
setblock ~348 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~350 ~33 ~570 ~363 ~33 ~570 minecraft:redstone_wire replace
setblock ~365 ~33 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~367 ~33 ~570 ~374 ~33 ~570 minecraft:redstone_wire replace
setblock ~163 ~33 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~33 ~574 ~161 ~33 ~574 minecraft:redstone_wire replace
setblock ~162 ~33 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~163 ~33 ~574 ~164 ~33 ~574 minecraft:redstone_wire replace
setblock ~400 ~33 ~577 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~327 ~33 ~578 ~333 ~33 ~578 minecraft:redstone_wire replace
setblock ~335 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~33 ~578 ~350 ~33 ~578 minecraft:redstone_wire replace
setblock ~352 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~33 ~578 ~367 ~33 ~578 minecraft:redstone_wire replace
setblock ~369 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~371 ~33 ~578 ~384 ~33 ~578 minecraft:redstone_wire replace
setblock ~386 ~33 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~388 ~33 ~578 ~401 ~33 ~578 minecraft:redstone_wire replace
setblock ~97 ~33 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~33 ~582 ~98 ~33 ~582 minecraft:redstone_wire replace
setblock ~376 ~33 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~309 ~33 ~586 ~315 ~33 ~586 minecraft:redstone_wire replace
setblock ~317 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~319 ~33 ~586 ~332 ~33 ~586 minecraft:redstone_wire replace
setblock ~334 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~336 ~33 ~586 ~349 ~33 ~586 minecraft:redstone_wire replace
setblock ~351 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~353 ~33 ~586 ~366 ~33 ~586 minecraft:redstone_wire replace
setblock ~368 ~33 ~586 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~370 ~33 ~586 ~377 ~33 ~586 minecraft:redstone_wire replace
setblock ~397 ~33 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~33 ~590 ~330 ~33 ~590 minecraft:redstone_wire replace
setblock ~332 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~33 ~590 ~347 ~33 ~590 minecraft:redstone_wire replace
setblock ~349 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~33 ~590 ~364 ~33 ~590 minecraft:redstone_wire replace
setblock ~366 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~368 ~33 ~590 ~381 ~33 ~590 minecraft:redstone_wire replace
setblock ~383 ~33 ~590 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~385 ~33 ~590 ~398 ~33 ~590 minecraft:redstone_wire replace
setblock ~94 ~34 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~34 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~34 ~8 minecraft:redstone_wire replace
setblock ~178 ~34 ~8 minecraft:redstone_wire replace
setblock ~118 ~34 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~34 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~34 ~16 minecraft:redstone_wire replace
setblock ~211 ~34 ~16 minecraft:redstone_wire replace
setblock ~145 ~34 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~34 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~34 ~24 minecraft:redstone_wire replace
setblock ~253 ~34 ~24 minecraft:redstone_wire replace
setblock ~175 ~34 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~34 ~32 minecraft:redstone_wire replace
setblock ~259 ~34 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~34 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~34 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~34 ~40 minecraft:redstone_wire replace
setblock ~301 ~34 ~40 minecraft:redstone_wire replace
setblock ~229 ~34 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~34 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~34 ~48 minecraft:redstone_wire replace
setblock ~331 ~34 ~48 minecraft:redstone_wire replace
setblock ~265 ~34 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~34 ~56 minecraft:redstone_wire replace
setblock ~322 ~34 ~56 minecraft:redstone_wire replace
setblock ~340 ~34 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~34 ~60 minecraft:redstone_wire replace
setblock ~337 ~34 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~34 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~34 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~34 ~72 minecraft:redstone_wire replace
setblock ~352 ~34 ~72 minecraft:redstone_wire replace
setblock ~388 ~34 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~34 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~34 ~76 minecraft:redstone_wire replace
setblock ~379 ~34 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~34 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~34 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~34 ~256 minecraft:redstone_wire replace
setblock ~181 ~34 ~256 minecraft:redstone_wire replace
setblock ~157 ~34 ~264 minecraft:redstone_wire replace
setblock ~118 ~34 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~34 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~34 ~268 minecraft:redstone_wire replace
setblock ~214 ~34 ~268 minecraft:redstone_wire replace
setblock ~145 ~34 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~34 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~34 ~276 minecraft:redstone_wire replace
setblock ~256 ~34 ~276 minecraft:redstone_wire replace
setblock ~175 ~34 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~34 ~284 minecraft:redstone_wire replace
setblock ~259 ~34 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~34 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~34 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~34 ~292 minecraft:redstone_wire replace
setblock ~304 ~34 ~292 minecraft:redstone_wire replace
setblock ~229 ~34 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~34 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~34 ~300 minecraft:redstone_wire replace
setblock ~334 ~34 ~300 minecraft:redstone_wire replace
setblock ~265 ~34 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~34 ~308 minecraft:redstone_wire replace
setblock ~325 ~34 ~308 minecraft:redstone_wire replace
setblock ~340 ~34 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~34 ~316 minecraft:redstone_wire replace
setblock ~337 ~34 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~34 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~34 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~34 ~324 minecraft:redstone_wire replace
setblock ~349 ~34 ~324 minecraft:redstone_wire replace
setblock ~388 ~34 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~34 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~34 ~332 minecraft:redstone_wire replace
setblock ~379 ~34 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~34 ~340 minecraft:redstone_wire replace
setblock ~115 ~34 ~344 minecraft:redstone_wire replace
setblock ~139 ~34 ~348 minecraft:redstone_wire replace
setblock ~187 ~34 ~352 minecraft:redstone_wire replace
setblock ~217 ~34 ~356 minecraft:redstone_wire replace
setblock ~244 ~34 ~360 minecraft:redstone_wire replace
setblock ~280 ~34 ~364 minecraft:redstone_wire replace
setblock ~310 ~34 ~368 minecraft:redstone_wire replace
setblock ~346 ~34 ~372 minecraft:redstone_wire replace
setblock ~88 ~34 ~376 minecraft:redstone_wire replace
setblock ~112 ~34 ~380 minecraft:redstone_wire replace
setblock ~136 ~34 ~384 minecraft:redstone_wire replace
setblock ~184 ~34 ~388 minecraft:redstone_wire replace
setblock ~208 ~34 ~392 minecraft:redstone_wire replace
setblock ~238 ~34 ~396 minecraft:redstone_wire replace
setblock ~277 ~34 ~400 minecraft:redstone_wire replace
setblock ~307 ~34 ~404 minecraft:redstone_wire replace
setblock ~370 ~34 ~408 minecraft:redstone_wire replace
setblock ~394 ~34 ~412 minecraft:redstone_wire replace
setblock ~85 ~34 ~416 minecraft:redstone_wire replace
setblock ~109 ~34 ~420 minecraft:redstone_wire replace
setblock ~133 ~34 ~424 minecraft:redstone_wire replace
setblock ~166 ~34 ~428 minecraft:redstone_wire replace
setblock ~205 ~34 ~432 minecraft:redstone_wire replace
setblock ~235 ~34 ~436 minecraft:redstone_wire replace
setblock ~274 ~34 ~440 minecraft:redstone_wire replace
setblock ~298 ~34 ~444 minecraft:redstone_wire replace
setblock ~367 ~34 ~448 minecraft:redstone_wire replace
setblock ~391 ~34 ~452 minecraft:redstone_wire replace
setblock ~82 ~34 ~456 minecraft:redstone_wire replace
setblock ~106 ~34 ~460 minecraft:redstone_wire replace
setblock ~130 ~34 ~464 minecraft:redstone_wire replace
setblock ~160 ~34 ~468 minecraft:redstone_wire replace
setblock ~199 ~34 ~472 minecraft:redstone_wire replace
setblock ~232 ~34 ~476 minecraft:redstone_wire replace
setblock ~271 ~34 ~480 minecraft:redstone_wire replace
setblock ~292 ~34 ~484 minecraft:redstone_wire replace
setblock ~364 ~34 ~488 minecraft:redstone_wire replace
setblock ~385 ~34 ~492 minecraft:redstone_wire replace
setblock ~79 ~34 ~496 minecraft:redstone_wire replace
setblock ~103 ~34 ~500 minecraft:redstone_wire replace
setblock ~127 ~34 ~504 minecraft:redstone_wire replace
setblock ~154 ~34 ~508 minecraft:redstone_wire replace
setblock ~193 ~34 ~512 minecraft:redstone_wire replace
setblock ~223 ~34 ~516 minecraft:redstone_wire replace
setblock ~268 ~34 ~520 minecraft:redstone_wire replace
setblock ~289 ~34 ~524 minecraft:redstone_wire replace
setblock ~358 ~34 ~528 minecraft:redstone_wire replace
setblock ~382 ~34 ~532 minecraft:redstone_wire replace
setblock ~100 ~34 ~536 minecraft:redstone_wire replace
setblock ~124 ~34 ~540 minecraft:redstone_wire replace
setblock ~148 ~34 ~544 minecraft:redstone_wire replace
setblock ~190 ~34 ~548 minecraft:redstone_wire replace
setblock ~220 ~34 ~552 minecraft:redstone_wire replace
setblock ~250 ~34 ~556 minecraft:redstone_wire replace
setblock ~295 ~34 ~560 minecraft:redstone_wire replace
setblock ~313 ~34 ~564 minecraft:redstone_wire replace
setblock ~373 ~34 ~568 minecraft:redstone_wire replace
setblock ~163 ~34 ~572 minecraft:redstone_wire replace
setblock ~400 ~34 ~576 minecraft:redstone_wire replace
setblock ~97 ~34 ~580 minecraft:redstone_wire replace
setblock ~376 ~34 ~584 minecraft:redstone_wire replace
setblock ~397 ~34 ~588 minecraft:redstone_wire replace
fill ~93 ~35 ~8 ~93 ~35 ~20 minecraft:redstone_wire replace
fill ~120 ~35 ~8 ~120 ~35 ~20 minecraft:redstone_wire replace
fill ~150 ~35 ~8 ~150 ~35 ~20 minecraft:redstone_wire replace
fill ~177 ~35 ~8 ~177 ~35 ~12 minecraft:redstone_wire replace
fill ~117 ~35 ~16 ~117 ~35 ~28 minecraft:redstone_wire replace
fill ~141 ~35 ~16 ~141 ~35 ~28 minecraft:redstone_wire replace
fill ~171 ~35 ~16 ~171 ~35 ~28 minecraft:redstone_wire replace
fill ~210 ~35 ~16 ~210 ~35 ~20 minecraft:redstone_wire replace
setblock ~93 ~35 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~35 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~35 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~35 ~24 ~93 ~35 ~36 minecraft:redstone_wire replace
fill ~120 ~35 ~24 ~120 ~35 ~36 minecraft:redstone_wire replace
fill ~144 ~35 ~24 ~144 ~35 ~36 minecraft:redstone_wire replace
fill ~150 ~35 ~24 ~150 ~35 ~36 minecraft:redstone_wire replace
fill ~168 ~35 ~24 ~168 ~35 ~36 minecraft:redstone_wire replace
fill ~201 ~35 ~24 ~201 ~35 ~36 minecraft:redstone_wire replace
fill ~252 ~35 ~24 ~252 ~35 ~28 minecraft:redstone_wire replace
setblock ~117 ~35 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~35 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~35 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~35 ~32 ~117 ~35 ~44 minecraft:redstone_wire replace
fill ~141 ~35 ~32 ~141 ~35 ~44 minecraft:redstone_wire replace
fill ~171 ~35 ~32 ~171 ~35 ~44 minecraft:redstone_wire replace
fill ~174 ~35 ~32 ~174 ~35 ~44 minecraft:redstone_wire replace
