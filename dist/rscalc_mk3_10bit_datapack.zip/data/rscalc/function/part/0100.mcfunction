setblock ~177 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~488 ~108 ~155 ~500 minecraft:redstone_wire replace
fill ~111 ~155 ~488 ~111 ~155 ~500 minecraft:redstone_wire replace
fill ~114 ~155 ~488 ~114 ~155 ~500 minecraft:redstone_wire replace
fill ~117 ~155 ~488 ~117 ~155 ~500 minecraft:redstone_wire replace
fill ~120 ~155 ~488 ~120 ~155 ~500 minecraft:redstone_wire replace
fill ~123 ~155 ~488 ~123 ~155 ~500 minecraft:redstone_wire replace
fill ~126 ~155 ~488 ~126 ~155 ~500 minecraft:redstone_wire replace
fill ~129 ~155 ~488 ~129 ~155 ~500 minecraft:redstone_wire replace
fill ~132 ~155 ~488 ~132 ~155 ~500 minecraft:redstone_wire replace
fill ~135 ~155 ~488 ~135 ~155 ~500 minecraft:redstone_wire replace
fill ~138 ~155 ~488 ~138 ~155 ~500 minecraft:redstone_wire replace
fill ~141 ~155 ~488 ~141 ~155 ~500 minecraft:redstone_wire replace
fill ~144 ~155 ~488 ~144 ~155 ~500 minecraft:redstone_wire replace
fill ~147 ~155 ~488 ~147 ~155 ~500 minecraft:redstone_wire replace
fill ~150 ~155 ~488 ~150 ~155 ~500 minecraft:redstone_wire replace
fill ~153 ~155 ~488 ~153 ~155 ~500 minecraft:redstone_wire replace
fill ~156 ~155 ~488 ~156 ~155 ~500 minecraft:redstone_wire replace
fill ~159 ~155 ~488 ~159 ~155 ~500 minecraft:redstone_wire replace
fill ~162 ~155 ~488 ~162 ~155 ~500 minecraft:redstone_wire replace
fill ~165 ~155 ~488 ~165 ~155 ~500 minecraft:redstone_wire replace
fill ~168 ~155 ~488 ~168 ~155 ~500 minecraft:redstone_wire replace
fill ~171 ~155 ~488 ~171 ~155 ~500 minecraft:redstone_wire replace
fill ~174 ~155 ~488 ~174 ~155 ~500 minecraft:redstone_wire replace
fill ~177 ~155 ~488 ~177 ~155 ~500 minecraft:redstone_wire replace
fill ~180 ~155 ~488 ~180 ~155 ~500 minecraft:redstone_wire replace
fill ~183 ~155 ~488 ~183 ~155 ~500 minecraft:redstone_wire replace
fill ~186 ~155 ~488 ~186 ~155 ~500 minecraft:redstone_wire replace
fill ~189 ~155 ~488 ~189 ~155 ~500 minecraft:redstone_wire replace
fill ~192 ~155 ~488 ~192 ~155 ~500 minecraft:redstone_wire replace
fill ~195 ~155 ~488 ~195 ~155 ~500 minecraft:redstone_wire replace
fill ~198 ~155 ~488 ~198 ~155 ~500 minecraft:redstone_wire replace
fill ~201 ~155 ~488 ~201 ~155 ~500 minecraft:redstone_wire replace
fill ~204 ~155 ~488 ~204 ~155 ~500 minecraft:redstone_wire replace
fill ~207 ~155 ~488 ~207 ~155 ~500 minecraft:redstone_wire replace
fill ~210 ~155 ~488 ~210 ~155 ~500 minecraft:redstone_wire replace
fill ~213 ~155 ~488 ~213 ~155 ~500 minecraft:redstone_wire replace
fill ~216 ~155 ~488 ~216 ~155 ~500 minecraft:redstone_wire replace
fill ~219 ~155 ~488 ~219 ~155 ~500 minecraft:redstone_wire replace
fill ~222 ~155 ~488 ~222 ~155 ~500 minecraft:redstone_wire replace
fill ~225 ~155 ~488 ~225 ~155 ~500 minecraft:redstone_wire replace
fill ~228 ~155 ~488 ~228 ~155 ~500 minecraft:redstone_wire replace
fill ~231 ~155 ~488 ~231 ~155 ~500 minecraft:redstone_wire replace
fill ~234 ~155 ~488 ~234 ~155 ~500 minecraft:redstone_wire replace
fill ~237 ~155 ~488 ~237 ~155 ~500 minecraft:redstone_wire replace
fill ~240 ~155 ~488 ~240 ~155 ~500 minecraft:redstone_wire replace
fill ~243 ~155 ~488 ~243 ~155 ~500 minecraft:redstone_wire replace
fill ~246 ~155 ~488 ~246 ~155 ~500 minecraft:redstone_wire replace
fill ~249 ~155 ~488 ~249 ~155 ~500 minecraft:redstone_wire replace
fill ~252 ~155 ~488 ~252 ~155 ~500 minecraft:redstone_wire replace
setblock ~108 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~504 ~108 ~155 ~516 minecraft:redstone_wire replace
fill ~111 ~155 ~504 ~111 ~155 ~516 minecraft:redstone_wire replace
fill ~114 ~155 ~504 ~114 ~155 ~516 minecraft:redstone_wire replace
fill ~117 ~155 ~504 ~117 ~155 ~516 minecraft:redstone_wire replace
fill ~120 ~155 ~504 ~120 ~155 ~516 minecraft:redstone_wire replace
fill ~123 ~155 ~504 ~123 ~155 ~516 minecraft:redstone_wire replace
fill ~126 ~155 ~504 ~126 ~155 ~516 minecraft:redstone_wire replace
fill ~129 ~155 ~504 ~129 ~155 ~516 minecraft:redstone_wire replace
fill ~132 ~155 ~504 ~132 ~155 ~516 minecraft:redstone_wire replace
fill ~135 ~155 ~504 ~135 ~155 ~516 minecraft:redstone_wire replace
fill ~138 ~155 ~504 ~138 ~155 ~516 minecraft:redstone_wire replace
fill ~141 ~155 ~504 ~141 ~155 ~516 minecraft:redstone_wire replace
fill ~144 ~155 ~504 ~144 ~155 ~516 minecraft:redstone_wire replace
fill ~147 ~155 ~504 ~147 ~155 ~516 minecraft:redstone_wire replace
fill ~150 ~155 ~504 ~150 ~155 ~516 minecraft:redstone_wire replace
fill ~153 ~155 ~504 ~153 ~155 ~516 minecraft:redstone_wire replace
fill ~156 ~155 ~504 ~156 ~155 ~516 minecraft:redstone_wire replace
fill ~159 ~155 ~504 ~159 ~155 ~516 minecraft:redstone_wire replace
fill ~162 ~155 ~504 ~162 ~155 ~516 minecraft:redstone_wire replace
fill ~165 ~155 ~504 ~165 ~155 ~516 minecraft:redstone_wire replace
fill ~168 ~155 ~504 ~168 ~155 ~516 minecraft:redstone_wire replace
fill ~171 ~155 ~504 ~171 ~155 ~516 minecraft:redstone_wire replace
fill ~174 ~155 ~504 ~174 ~155 ~516 minecraft:redstone_wire replace
fill ~177 ~155 ~504 ~177 ~155 ~516 minecraft:redstone_wire replace
fill ~180 ~155 ~504 ~180 ~155 ~516 minecraft:redstone_wire replace
fill ~183 ~155 ~504 ~183 ~155 ~516 minecraft:redstone_wire replace
fill ~186 ~155 ~504 ~186 ~155 ~516 minecraft:redstone_wire replace
fill ~189 ~155 ~504 ~189 ~155 ~516 minecraft:redstone_wire replace
fill ~192 ~155 ~504 ~192 ~155 ~516 minecraft:redstone_wire replace
fill ~195 ~155 ~504 ~195 ~155 ~516 minecraft:redstone_wire replace
fill ~198 ~155 ~504 ~198 ~155 ~516 minecraft:redstone_wire replace
fill ~201 ~155 ~504 ~201 ~155 ~516 minecraft:redstone_wire replace
fill ~204 ~155 ~504 ~204 ~155 ~516 minecraft:redstone_wire replace
fill ~207 ~155 ~504 ~207 ~155 ~516 minecraft:redstone_wire replace
fill ~210 ~155 ~504 ~210 ~155 ~516 minecraft:redstone_wire replace
fill ~213 ~155 ~504 ~213 ~155 ~516 minecraft:redstone_wire replace
fill ~216 ~155 ~504 ~216 ~155 ~516 minecraft:redstone_wire replace
fill ~219 ~155 ~504 ~219 ~155 ~516 minecraft:redstone_wire replace
fill ~222 ~155 ~504 ~222 ~155 ~516 minecraft:redstone_wire replace
fill ~225 ~155 ~504 ~225 ~155 ~516 minecraft:redstone_wire replace
fill ~228 ~155 ~504 ~228 ~155 ~516 minecraft:redstone_wire replace
fill ~231 ~155 ~504 ~231 ~155 ~516 minecraft:redstone_wire replace
fill ~234 ~155 ~504 ~234 ~155 ~516 minecraft:redstone_wire replace
fill ~237 ~155 ~504 ~237 ~155 ~516 minecraft:redstone_wire replace
fill ~240 ~155 ~504 ~240 ~155 ~516 minecraft:redstone_wire replace
fill ~243 ~155 ~504 ~243 ~155 ~516 minecraft:redstone_wire replace
fill ~246 ~155 ~504 ~246 ~155 ~516 minecraft:redstone_wire replace
fill ~249 ~155 ~504 ~249 ~155 ~516 minecraft:redstone_wire replace
fill ~252 ~155 ~504 ~252 ~155 ~516 minecraft:redstone_wire replace
setblock ~108 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~520 ~108 ~155 ~532 minecraft:redstone_wire replace
fill ~111 ~155 ~520 ~111 ~155 ~532 minecraft:redstone_wire replace
fill ~114 ~155 ~520 ~114 ~155 ~532 minecraft:redstone_wire replace
fill ~117 ~155 ~520 ~117 ~155 ~532 minecraft:redstone_wire replace
fill ~120 ~155 ~520 ~120 ~155 ~532 minecraft:redstone_wire replace
fill ~123 ~155 ~520 ~123 ~155 ~532 minecraft:redstone_wire replace
fill ~126 ~155 ~520 ~126 ~155 ~532 minecraft:redstone_wire replace
fill ~129 ~155 ~520 ~129 ~155 ~532 minecraft:redstone_wire replace
fill ~132 ~155 ~520 ~132 ~155 ~532 minecraft:redstone_wire replace
fill ~135 ~155 ~520 ~135 ~155 ~532 minecraft:redstone_wire replace
fill ~138 ~155 ~520 ~138 ~155 ~532 minecraft:redstone_wire replace
fill ~141 ~155 ~520 ~141 ~155 ~532 minecraft:redstone_wire replace
fill ~144 ~155 ~520 ~144 ~155 ~532 minecraft:redstone_wire replace
fill ~147 ~155 ~520 ~147 ~155 ~532 minecraft:redstone_wire replace
fill ~150 ~155 ~520 ~150 ~155 ~532 minecraft:redstone_wire replace
fill ~153 ~155 ~520 ~153 ~155 ~532 minecraft:redstone_wire replace
fill ~156 ~155 ~520 ~156 ~155 ~532 minecraft:redstone_wire replace
fill ~159 ~155 ~520 ~159 ~155 ~532 minecraft:redstone_wire replace
fill ~162 ~155 ~520 ~162 ~155 ~532 minecraft:redstone_wire replace
fill ~165 ~155 ~520 ~165 ~155 ~532 minecraft:redstone_wire replace
fill ~168 ~155 ~520 ~168 ~155 ~532 minecraft:redstone_wire replace
fill ~171 ~155 ~520 ~171 ~155 ~532 minecraft:redstone_wire replace
fill ~174 ~155 ~520 ~174 ~155 ~532 minecraft:redstone_wire replace
fill ~177 ~155 ~520 ~177 ~155 ~532 minecraft:redstone_wire replace
fill ~180 ~155 ~520 ~180 ~155 ~532 minecraft:redstone_wire replace
fill ~183 ~155 ~520 ~183 ~155 ~532 minecraft:redstone_wire replace
fill ~186 ~155 ~520 ~186 ~155 ~532 minecraft:redstone_wire replace
fill ~189 ~155 ~520 ~189 ~155 ~532 minecraft:redstone_wire replace
fill ~192 ~155 ~520 ~192 ~155 ~532 minecraft:redstone_wire replace
fill ~195 ~155 ~520 ~195 ~155 ~532 minecraft:redstone_wire replace
fill ~198 ~155 ~520 ~198 ~155 ~532 minecraft:redstone_wire replace
fill ~201 ~155 ~520 ~201 ~155 ~532 minecraft:redstone_wire replace
fill ~204 ~155 ~520 ~204 ~155 ~532 minecraft:redstone_wire replace
fill ~207 ~155 ~520 ~207 ~155 ~532 minecraft:redstone_wire replace
fill ~210 ~155 ~520 ~210 ~155 ~532 minecraft:redstone_wire replace
fill ~213 ~155 ~520 ~213 ~155 ~532 minecraft:redstone_wire replace
fill ~216 ~155 ~520 ~216 ~155 ~532 minecraft:redstone_wire replace
fill ~219 ~155 ~520 ~219 ~155 ~532 minecraft:redstone_wire replace
fill ~222 ~155 ~520 ~222 ~155 ~532 minecraft:redstone_wire replace
fill ~225 ~155 ~520 ~225 ~155 ~532 minecraft:redstone_wire replace
fill ~228 ~155 ~520 ~228 ~155 ~532 minecraft:redstone_wire replace
fill ~231 ~155 ~520 ~231 ~155 ~532 minecraft:redstone_wire replace
fill ~234 ~155 ~520 ~234 ~155 ~532 minecraft:redstone_wire replace
fill ~237 ~155 ~520 ~237 ~155 ~532 minecraft:redstone_wire replace
fill ~240 ~155 ~520 ~240 ~155 ~532 minecraft:redstone_wire replace
fill ~243 ~155 ~520 ~243 ~155 ~532 minecraft:redstone_wire replace
fill ~246 ~155 ~520 ~246 ~155 ~532 minecraft:redstone_wire replace
fill ~249 ~155 ~520 ~249 ~155 ~532 minecraft:redstone_wire replace
fill ~252 ~155 ~520 ~252 ~155 ~532 minecraft:redstone_wire replace
setblock ~108 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~533 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~155 ~534 ~108 ~155 ~536 minecraft:redstone_wire replace
fill ~111 ~155 ~534 ~111 ~155 ~540 minecraft:redstone_wire replace
fill ~114 ~155 ~534 ~114 ~155 ~542 minecraft:redstone_wire replace
fill ~117 ~155 ~534 ~117 ~155 ~546 minecraft:redstone_wire replace
fill ~120 ~155 ~534 ~120 ~155 ~546 minecraft:redstone_wire replace
fill ~123 ~155 ~534 ~123 ~155 ~546 minecraft:redstone_wire replace
fill ~126 ~155 ~534 ~126 ~155 ~546 minecraft:redstone_wire replace
fill ~129 ~155 ~534 ~129 ~155 ~546 minecraft:redstone_wire replace
fill ~132 ~155 ~534 ~132 ~155 ~546 minecraft:redstone_wire replace
fill ~135 ~155 ~534 ~135 ~155 ~546 minecraft:redstone_wire replace
fill ~138 ~155 ~534 ~138 ~155 ~546 minecraft:redstone_wire replace
fill ~141 ~155 ~534 ~141 ~155 ~546 minecraft:redstone_wire replace
fill ~144 ~155 ~534 ~144 ~155 ~546 minecraft:redstone_wire replace
fill ~147 ~155 ~534 ~147 ~155 ~546 minecraft:redstone_wire replace
fill ~150 ~155 ~534 ~150 ~155 ~546 minecraft:redstone_wire replace
fill ~153 ~155 ~534 ~153 ~155 ~546 minecraft:redstone_wire replace
fill ~156 ~155 ~534 ~156 ~155 ~546 minecraft:redstone_wire replace
fill ~159 ~155 ~534 ~159 ~155 ~546 minecraft:redstone_wire replace
fill ~162 ~155 ~534 ~162 ~155 ~546 minecraft:redstone_wire replace
fill ~165 ~155 ~534 ~165 ~155 ~546 minecraft:redstone_wire replace
fill ~168 ~155 ~534 ~168 ~155 ~546 minecraft:redstone_wire replace
fill ~171 ~155 ~534 ~171 ~155 ~546 minecraft:redstone_wire replace
fill ~174 ~155 ~534 ~174 ~155 ~546 minecraft:redstone_wire replace
fill ~177 ~155 ~534 ~177 ~155 ~546 minecraft:redstone_wire replace
fill ~180 ~155 ~534 ~180 ~155 ~546 minecraft:redstone_wire replace
fill ~183 ~155 ~534 ~183 ~155 ~546 minecraft:redstone_wire replace
fill ~186 ~155 ~534 ~186 ~155 ~546 minecraft:redstone_wire replace
fill ~189 ~155 ~534 ~189 ~155 ~546 minecraft:redstone_wire replace
fill ~192 ~155 ~534 ~192 ~155 ~546 minecraft:redstone_wire replace
fill ~195 ~155 ~534 ~195 ~155 ~546 minecraft:redstone_wire replace
fill ~198 ~155 ~534 ~198 ~155 ~546 minecraft:redstone_wire replace
fill ~201 ~155 ~534 ~201 ~155 ~546 minecraft:redstone_wire replace
fill ~204 ~155 ~534 ~204 ~155 ~546 minecraft:redstone_wire replace
fill ~207 ~155 ~534 ~207 ~155 ~546 minecraft:redstone_wire replace
fill ~210 ~155 ~534 ~210 ~155 ~546 minecraft:redstone_wire replace
fill ~213 ~155 ~534 ~213 ~155 ~546 minecraft:redstone_wire replace
fill ~216 ~155 ~534 ~216 ~155 ~546 minecraft:redstone_wire replace
fill ~219 ~155 ~534 ~219 ~155 ~546 minecraft:redstone_wire replace
fill ~222 ~155 ~534 ~222 ~155 ~546 minecraft:redstone_wire replace
fill ~225 ~155 ~534 ~225 ~155 ~546 minecraft:redstone_wire replace
fill ~228 ~155 ~534 ~228 ~155 ~546 minecraft:redstone_wire replace
fill ~231 ~155 ~534 ~231 ~155 ~546 minecraft:redstone_wire replace
fill ~234 ~155 ~534 ~234 ~155 ~546 minecraft:redstone_wire replace
fill ~237 ~155 ~534 ~237 ~155 ~546 minecraft:redstone_wire replace
fill ~240 ~155 ~534 ~240 ~155 ~546 minecraft:redstone_wire replace
fill ~243 ~155 ~534 ~243 ~155 ~546 minecraft:redstone_wire replace
fill ~246 ~155 ~534 ~246 ~155 ~546 minecraft:redstone_wire replace
fill ~249 ~155 ~534 ~249 ~155 ~546 minecraft:redstone_wire replace
fill ~252 ~155 ~534 ~252 ~155 ~546 minecraft:redstone_wire replace
fill ~255 ~155 ~536 ~255 ~155 ~548 minecraft:redstone_wire replace
fill ~258 ~155 ~536 ~258 ~155 ~548 minecraft:redstone_wire replace
fill ~261 ~155 ~536 ~261 ~155 ~548 minecraft:redstone_wire replace
fill ~264 ~155 ~536 ~264 ~155 ~548 minecraft:redstone_wire replace
fill ~267 ~155 ~536 ~267 ~155 ~548 minecraft:redstone_wire replace
fill ~270 ~155 ~536 ~270 ~155 ~548 minecraft:redstone_wire replace
fill ~273 ~155 ~536 ~273 ~155 ~548 minecraft:redstone_wire replace
fill ~276 ~155 ~536 ~276 ~155 ~548 minecraft:redstone_wire replace
fill ~279 ~155 ~536 ~279 ~155 ~548 minecraft:redstone_wire replace
fill ~282 ~155 ~536 ~282 ~155 ~548 minecraft:redstone_wire replace
fill ~285 ~155 ~536 ~285 ~155 ~548 minecraft:redstone_wire replace
fill ~288 ~155 ~536 ~288 ~155 ~548 minecraft:redstone_wire replace
fill ~291 ~155 ~536 ~291 ~155 ~548 minecraft:redstone_wire replace
fill ~294 ~155 ~536 ~294 ~155 ~548 minecraft:redstone_wire replace
fill ~297 ~155 ~536 ~297 ~155 ~548 minecraft:redstone_wire replace
fill ~300 ~155 ~536 ~300 ~155 ~548 minecraft:redstone_wire replace
fill ~303 ~155 ~536 ~303 ~155 ~548 minecraft:redstone_wire replace
fill ~306 ~155 ~536 ~306 ~155 ~548 minecraft:redstone_wire replace
fill ~309 ~155 ~536 ~309 ~155 ~548 minecraft:redstone_wire replace
fill ~312 ~155 ~536 ~312 ~155 ~548 minecraft:redstone_wire replace
fill ~315 ~155 ~536 ~315 ~155 ~548 minecraft:redstone_wire replace
fill ~318 ~155 ~536 ~318 ~155 ~548 minecraft:redstone_wire replace
fill ~321 ~155 ~536 ~321 ~155 ~548 minecraft:redstone_wire replace
fill ~324 ~155 ~536 ~324 ~155 ~548 minecraft:redstone_wire replace
fill ~327 ~155 ~536 ~327 ~155 ~548 minecraft:redstone_wire replace
fill ~330 ~155 ~536 ~330 ~155 ~548 minecraft:redstone_wire replace
fill ~333 ~155 ~536 ~333 ~155 ~548 minecraft:redstone_wire replace
fill ~336 ~155 ~536 ~336 ~155 ~548 minecraft:redstone_wire replace
fill ~339 ~155 ~536 ~339 ~155 ~548 minecraft:redstone_wire replace
fill ~342 ~155 ~536 ~342 ~155 ~548 minecraft:redstone_wire replace
fill ~345 ~155 ~536 ~345 ~155 ~548 minecraft:redstone_wire replace
fill ~348 ~155 ~536 ~348 ~155 ~548 minecraft:redstone_wire replace
fill ~351 ~155 ~536 ~351 ~155 ~548 minecraft:redstone_wire replace
fill ~354 ~155 ~536 ~354 ~155 ~548 minecraft:redstone_wire replace
fill ~357 ~155 ~536 ~357 ~155 ~548 minecraft:redstone_wire replace
fill ~360 ~155 ~536 ~360 ~155 ~548 minecraft:redstone_wire replace
fill ~363 ~155 ~536 ~363 ~155 ~548 minecraft:redstone_wire replace
fill ~366 ~155 ~536 ~366 ~155 ~548 minecraft:redstone_wire replace
fill ~369 ~155 ~536 ~369 ~155 ~548 minecraft:redstone_wire replace
fill ~372 ~155 ~536 ~372 ~155 ~548 minecraft:redstone_wire replace
fill ~375 ~155 ~536 ~375 ~155 ~548 minecraft:redstone_wire replace
fill ~378 ~155 ~536 ~378 ~155 ~548 minecraft:redstone_wire replace
fill ~381 ~155 ~536 ~381 ~155 ~548 minecraft:redstone_wire replace
fill ~384 ~155 ~536 ~384 ~155 ~548 minecraft:redstone_wire replace
fill ~387 ~155 ~536 ~387 ~155 ~548 minecraft:redstone_wire replace
fill ~390 ~155 ~536 ~390 ~155 ~548 minecraft:redstone_wire replace
fill ~393 ~155 ~536 ~393 ~155 ~548 minecraft:redstone_wire replace
fill ~396 ~155 ~536 ~396 ~155 ~548 minecraft:redstone_wire replace
fill ~399 ~155 ~536 ~399 ~155 ~548 minecraft:redstone_wire replace
setblock ~114 ~155 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~548 minecraft:redstone_wire replace
setblock ~120 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~548 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~155 ~550 ~120 ~155 ~552 minecraft:redstone_wire replace
fill ~123 ~155 ~550 ~123 ~155 ~556 minecraft:redstone_wire replace
fill ~126 ~155 ~550 ~126 ~155 ~558 minecraft:redstone_wire replace
fill ~129 ~155 ~550 ~129 ~155 ~562 minecraft:redstone_wire replace
fill ~132 ~155 ~550 ~132 ~155 ~562 minecraft:redstone_wire replace
fill ~135 ~155 ~550 ~135 ~155 ~562 minecraft:redstone_wire replace
fill ~138 ~155 ~550 ~138 ~155 ~562 minecraft:redstone_wire replace
fill ~141 ~155 ~550 ~141 ~155 ~562 minecraft:redstone_wire replace
fill ~144 ~155 ~550 ~144 ~155 ~562 minecraft:redstone_wire replace
fill ~147 ~155 ~550 ~147 ~155 ~562 minecraft:redstone_wire replace
fill ~150 ~155 ~550 ~150 ~155 ~562 minecraft:redstone_wire replace
fill ~153 ~155 ~550 ~153 ~155 ~562 minecraft:redstone_wire replace
fill ~156 ~155 ~550 ~156 ~155 ~562 minecraft:redstone_wire replace
fill ~159 ~155 ~550 ~159 ~155 ~562 minecraft:redstone_wire replace
fill ~162 ~155 ~550 ~162 ~155 ~562 minecraft:redstone_wire replace
fill ~165 ~155 ~550 ~165 ~155 ~562 minecraft:redstone_wire replace
fill ~168 ~155 ~550 ~168 ~155 ~562 minecraft:redstone_wire replace
fill ~171 ~155 ~550 ~171 ~155 ~562 minecraft:redstone_wire replace
fill ~174 ~155 ~550 ~174 ~155 ~562 minecraft:redstone_wire replace
fill ~177 ~155 ~550 ~177 ~155 ~562 minecraft:redstone_wire replace
fill ~180 ~155 ~550 ~180 ~155 ~562 minecraft:redstone_wire replace
fill ~183 ~155 ~550 ~183 ~155 ~562 minecraft:redstone_wire replace
fill ~186 ~155 ~550 ~186 ~155 ~562 minecraft:redstone_wire replace
fill ~189 ~155 ~550 ~189 ~155 ~562 minecraft:redstone_wire replace
fill ~192 ~155 ~550 ~192 ~155 ~562 minecraft:redstone_wire replace
fill ~195 ~155 ~550 ~195 ~155 ~562 minecraft:redstone_wire replace
fill ~198 ~155 ~550 ~198 ~155 ~562 minecraft:redstone_wire replace
fill ~201 ~155 ~550 ~201 ~155 ~562 minecraft:redstone_wire replace
fill ~204 ~155 ~550 ~204 ~155 ~562 minecraft:redstone_wire replace
fill ~207 ~155 ~550 ~207 ~155 ~562 minecraft:redstone_wire replace
fill ~210 ~155 ~550 ~210 ~155 ~562 minecraft:redstone_wire replace
fill ~213 ~155 ~550 ~213 ~155 ~562 minecraft:redstone_wire replace
fill ~216 ~155 ~550 ~216 ~155 ~562 minecraft:redstone_wire replace
fill ~219 ~155 ~550 ~219 ~155 ~562 minecraft:redstone_wire replace
fill ~222 ~155 ~550 ~222 ~155 ~562 minecraft:redstone_wire replace
fill ~225 ~155 ~550 ~225 ~155 ~562 minecraft:redstone_wire replace
fill ~228 ~155 ~550 ~228 ~155 ~562 minecraft:redstone_wire replace
fill ~231 ~155 ~550 ~231 ~155 ~562 minecraft:redstone_wire replace
fill ~234 ~155 ~550 ~234 ~155 ~562 minecraft:redstone_wire replace
fill ~237 ~155 ~550 ~237 ~155 ~562 minecraft:redstone_wire replace
fill ~240 ~155 ~550 ~240 ~155 ~562 minecraft:redstone_wire replace
fill ~243 ~155 ~550 ~243 ~155 ~562 minecraft:redstone_wire replace
fill ~246 ~155 ~550 ~246 ~155 ~562 minecraft:redstone_wire replace
fill ~249 ~155 ~550 ~249 ~155 ~562 minecraft:redstone_wire replace
fill ~252 ~155 ~550 ~252 ~155 ~562 minecraft:redstone_wire replace
setblock ~255 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~155 ~552 ~255 ~155 ~564 minecraft:redstone_wire replace
fill ~258 ~155 ~552 ~258 ~155 ~564 minecraft:redstone_wire replace
fill ~261 ~155 ~552 ~261 ~155 ~564 minecraft:redstone_wire replace
fill ~264 ~155 ~552 ~264 ~155 ~564 minecraft:redstone_wire replace
fill ~267 ~155 ~552 ~267 ~155 ~564 minecraft:redstone_wire replace
fill ~270 ~155 ~552 ~270 ~155 ~564 minecraft:redstone_wire replace
fill ~273 ~155 ~552 ~273 ~155 ~564 minecraft:redstone_wire replace
fill ~276 ~155 ~552 ~276 ~155 ~564 minecraft:redstone_wire replace
fill ~279 ~155 ~552 ~279 ~155 ~564 minecraft:redstone_wire replace
fill ~282 ~155 ~552 ~282 ~155 ~564 minecraft:redstone_wire replace
fill ~285 ~155 ~552 ~285 ~155 ~564 minecraft:redstone_wire replace
fill ~288 ~155 ~552 ~288 ~155 ~564 minecraft:redstone_wire replace
fill ~291 ~155 ~552 ~291 ~155 ~564 minecraft:redstone_wire replace
fill ~294 ~155 ~552 ~294 ~155 ~564 minecraft:redstone_wire replace
fill ~297 ~155 ~552 ~297 ~155 ~564 minecraft:redstone_wire replace
fill ~300 ~155 ~552 ~300 ~155 ~564 minecraft:redstone_wire replace
fill ~303 ~155 ~552 ~303 ~155 ~564 minecraft:redstone_wire replace
fill ~306 ~155 ~552 ~306 ~155 ~564 minecraft:redstone_wire replace
fill ~309 ~155 ~552 ~309 ~155 ~564 minecraft:redstone_wire replace
fill ~312 ~155 ~552 ~312 ~155 ~564 minecraft:redstone_wire replace
fill ~315 ~155 ~552 ~315 ~155 ~564 minecraft:redstone_wire replace
fill ~318 ~155 ~552 ~318 ~155 ~564 minecraft:redstone_wire replace
fill ~321 ~155 ~552 ~321 ~155 ~564 minecraft:redstone_wire replace
fill ~324 ~155 ~552 ~324 ~155 ~564 minecraft:redstone_wire replace
fill ~327 ~155 ~552 ~327 ~155 ~564 minecraft:redstone_wire replace
fill ~330 ~155 ~552 ~330 ~155 ~564 minecraft:redstone_wire replace
fill ~333 ~155 ~552 ~333 ~155 ~564 minecraft:redstone_wire replace
fill ~336 ~155 ~552 ~336 ~155 ~564 minecraft:redstone_wire replace
fill ~339 ~155 ~552 ~339 ~155 ~564 minecraft:redstone_wire replace
fill ~342 ~155 ~552 ~342 ~155 ~564 minecraft:redstone_wire replace
fill ~345 ~155 ~552 ~345 ~155 ~564 minecraft:redstone_wire replace
fill ~348 ~155 ~552 ~348 ~155 ~564 minecraft:redstone_wire replace
fill ~351 ~155 ~552 ~351 ~155 ~564 minecraft:redstone_wire replace
fill ~354 ~155 ~552 ~354 ~155 ~564 minecraft:redstone_wire replace
fill ~357 ~155 ~552 ~357 ~155 ~564 minecraft:redstone_wire replace
fill ~360 ~155 ~552 ~360 ~155 ~564 minecraft:redstone_wire replace
fill ~363 ~155 ~552 ~363 ~155 ~564 minecraft:redstone_wire replace
fill ~366 ~155 ~552 ~366 ~155 ~564 minecraft:redstone_wire replace
fill ~369 ~155 ~552 ~369 ~155 ~564 minecraft:redstone_wire replace
fill ~372 ~155 ~552 ~372 ~155 ~564 minecraft:redstone_wire replace
