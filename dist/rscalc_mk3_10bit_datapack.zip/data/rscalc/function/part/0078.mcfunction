setblock ~296 ~49 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~49 ~46 ~303 ~49 ~46 minecraft:redstone_wire replace
setblock ~259 ~49 ~49 minecraft:redstone_wire replace
fill ~258 ~49 ~50 ~261 ~49 ~50 minecraft:redstone_wire replace
setblock ~263 ~49 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~49 ~50 ~278 ~49 ~50 minecraft:redstone_wire replace
setblock ~280 ~49 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~49 ~50 ~288 ~49 ~50 minecraft:redstone_wire replace
setblock ~259 ~49 ~57 minecraft:redstone_wire replace
fill ~258 ~49 ~58 ~264 ~49 ~58 minecraft:redstone_wire replace
setblock ~266 ~49 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~49 ~58 ~281 ~49 ~58 minecraft:redstone_wire replace
setblock ~283 ~49 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~49 ~58 ~291 ~49 ~58 minecraft:redstone_wire replace
setblock ~274 ~49 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~49 ~74 ~274 ~49 ~74 minecraft:redstone_wire replace
setblock ~276 ~49 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~49 ~74 ~291 ~49 ~74 minecraft:redstone_wire replace
setblock ~293 ~49 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~49 ~74 ~308 ~49 ~74 minecraft:redstone_wire replace
setblock ~310 ~49 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~49 ~74 ~318 ~49 ~74 minecraft:redstone_wire replace
setblock ~94 ~49 ~241 minecraft:redstone_wire replace
fill ~93 ~49 ~242 ~96 ~49 ~242 minecraft:redstone_wire replace
setblock ~94 ~49 ~245 minecraft:redstone_wire replace
fill ~93 ~49 ~246 ~95 ~49 ~246 minecraft:redstone_wire replace
setblock ~118 ~49 ~261 minecraft:redstone_wire replace
setblock ~117 ~49 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~49 ~262 ~123 ~49 ~262 minecraft:redstone_wire replace
setblock ~118 ~49 ~265 minecraft:redstone_wire replace
fill ~117 ~49 ~266 ~120 ~49 ~266 minecraft:redstone_wire replace
setblock ~139 ~49 ~277 minecraft:redstone_wire replace
fill ~138 ~49 ~278 ~140 ~49 ~278 minecraft:redstone_wire replace
setblock ~141 ~49 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~49 ~278 ~147 ~49 ~278 minecraft:redstone_wire replace
setblock ~139 ~49 ~281 minecraft:redstone_wire replace
fill ~138 ~49 ~282 ~144 ~49 ~282 minecraft:redstone_wire replace
setblock ~157 ~49 ~289 minecraft:redstone_wire replace
fill ~156 ~49 ~290 ~168 ~49 ~290 minecraft:redstone_wire replace
setblock ~157 ~49 ~293 minecraft:redstone_wire replace
fill ~156 ~49 ~294 ~158 ~49 ~294 minecraft:redstone_wire replace
setblock ~159 ~49 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~49 ~294 ~165 ~49 ~294 minecraft:redstone_wire replace
setblock ~262 ~49 ~297 minecraft:redstone_wire replace
fill ~261 ~49 ~298 ~271 ~49 ~298 minecraft:redstone_wire replace
setblock ~273 ~49 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~49 ~298 ~288 ~49 ~298 minecraft:redstone_wire replace
setblock ~290 ~49 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~49 ~298 ~297 ~49 ~298 minecraft:redstone_wire replace
setblock ~259 ~49 ~301 minecraft:redstone_wire replace
fill ~258 ~49 ~302 ~266 ~49 ~302 minecraft:redstone_wire replace
setblock ~268 ~49 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~49 ~302 ~282 ~49 ~302 minecraft:redstone_wire replace
setblock ~214 ~49 ~305 minecraft:redstone_wire replace
fill ~213 ~49 ~306 ~216 ~49 ~306 minecraft:redstone_wire replace
setblock ~218 ~49 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~49 ~306 ~231 ~49 ~306 minecraft:redstone_wire replace
setblock ~193 ~49 ~309 minecraft:redstone_wire replace
fill ~192 ~49 ~310 ~193 ~49 ~310 minecraft:redstone_wire replace
setblock ~194 ~49 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~49 ~310 ~207 ~49 ~310 minecraft:redstone_wire replace
setblock ~172 ~49 ~313 minecraft:redstone_wire replace
fill ~171 ~49 ~314 ~172 ~49 ~314 minecraft:redstone_wire replace
setblock ~173 ~49 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~49 ~314 ~186 ~49 ~314 minecraft:redstone_wire replace
setblock ~172 ~49 ~317 minecraft:redstone_wire replace
fill ~171 ~49 ~318 ~183 ~49 ~318 minecraft:redstone_wire replace
setblock ~193 ~49 ~325 minecraft:redstone_wire replace
fill ~192 ~49 ~326 ~200 ~49 ~326 minecraft:redstone_wire replace
setblock ~202 ~49 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~49 ~326 ~210 ~49 ~326 minecraft:redstone_wire replace
setblock ~196 ~49 ~337 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~49 ~338 ~203 ~49 ~338 minecraft:redstone_wire replace
setblock ~205 ~49 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~49 ~338 ~213 ~49 ~338 minecraft:redstone_wire replace
setblock ~214 ~49 ~341 minecraft:redstone_wire replace
setblock ~213 ~49 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~49 ~342 ~227 ~49 ~342 minecraft:redstone_wire replace
setblock ~229 ~49 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~49 ~342 ~237 ~49 ~342 minecraft:redstone_wire replace
setblock ~217 ~49 ~353 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~49 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~49 ~354 ~230 ~49 ~354 minecraft:redstone_wire replace
setblock ~232 ~49 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~49 ~354 ~240 ~49 ~354 minecraft:redstone_wire replace
setblock ~262 ~49 ~361 minecraft:redstone_wire replace
fill ~261 ~49 ~362 ~262 ~49 ~362 minecraft:redstone_wire replace
setblock ~264 ~49 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~49 ~362 ~279 ~49 ~362 minecraft:redstone_wire replace
setblock ~281 ~49 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~49 ~362 ~296 ~49 ~362 minecraft:redstone_wire replace
setblock ~298 ~49 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~49 ~362 ~306 ~49 ~362 minecraft:redstone_wire replace
setblock ~265 ~49 ~365 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~49 ~366 ~265 ~49 ~366 minecraft:redstone_wire replace
setblock ~267 ~49 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~49 ~366 ~282 ~49 ~366 minecraft:redstone_wire replace
setblock ~284 ~49 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~49 ~366 ~299 ~49 ~366 minecraft:redstone_wire replace
setblock ~301 ~49 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~49 ~366 ~309 ~49 ~366 minecraft:redstone_wire replace
setblock ~259 ~49 ~373 minecraft:redstone_wire replace
fill ~258 ~49 ~374 ~267 ~49 ~374 minecraft:redstone_wire replace
setblock ~269 ~49 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~49 ~374 ~284 ~49 ~374 minecraft:redstone_wire replace
setblock ~286 ~49 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~49 ~374 ~294 ~49 ~374 minecraft:redstone_wire replace
setblock ~235 ~49 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~234 ~49 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~49 ~382 ~248 ~49 ~382 minecraft:redstone_wire replace
setblock ~250 ~49 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~49 ~382 ~258 ~49 ~382 minecraft:redstone_wire replace
setblock ~289 ~49 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~288 ~49 ~386 ~289 ~49 ~386 minecraft:redstone_wire replace
setblock ~291 ~49 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~49 ~386 ~306 ~49 ~386 minecraft:redstone_wire replace
setblock ~308 ~49 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~49 ~386 ~323 ~49 ~386 minecraft:redstone_wire replace
setblock ~325 ~49 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~49 ~386 ~333 ~49 ~386 minecraft:redstone_wire replace
setblock ~310 ~49 ~389 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~309 ~49 ~390 ~310 ~49 ~390 minecraft:redstone_wire replace
setblock ~312 ~49 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~49 ~390 ~327 ~49 ~390 minecraft:redstone_wire replace
setblock ~329 ~49 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~49 ~390 ~344 ~49 ~390 minecraft:redstone_wire replace
setblock ~346 ~49 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~49 ~390 ~354 ~49 ~390 minecraft:redstone_wire replace
setblock ~277 ~49 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~49 ~394 ~277 ~49 ~394 minecraft:redstone_wire replace
setblock ~279 ~49 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~49 ~394 ~294 ~49 ~394 minecraft:redstone_wire replace
setblock ~296 ~49 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~49 ~394 ~311 ~49 ~394 minecraft:redstone_wire replace
setblock ~313 ~49 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~49 ~394 ~321 ~49 ~394 minecraft:redstone_wire replace
setblock ~301 ~49 ~397 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~300 ~49 ~398 ~301 ~49 ~398 minecraft:redstone_wire replace
setblock ~303 ~49 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~49 ~398 ~318 ~49 ~398 minecraft:redstone_wire replace
setblock ~320 ~49 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~49 ~398 ~335 ~49 ~398 minecraft:redstone_wire replace
setblock ~337 ~49 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~49 ~398 ~345 ~49 ~398 minecraft:redstone_wire replace
setblock ~271 ~49 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~49 ~402 ~271 ~49 ~402 minecraft:redstone_wire replace
setblock ~273 ~49 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~49 ~402 ~288 ~49 ~402 minecraft:redstone_wire replace
setblock ~290 ~49 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~49 ~402 ~305 ~49 ~402 minecraft:redstone_wire replace
setblock ~307 ~49 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~309 ~49 ~402 ~315 ~49 ~402 minecraft:redstone_wire replace
setblock ~91 ~49 ~409 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~49 ~410 ~92 ~49 ~410 minecraft:redstone_wire replace
setblock ~115 ~49 ~413 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~49 ~414 ~117 ~49 ~414 minecraft:redstone_wire replace
setblock ~136 ~49 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~49 ~418 ~141 ~49 ~418 minecraft:redstone_wire replace
setblock ~163 ~49 ~421 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~49 ~422 ~164 ~49 ~422 minecraft:redstone_wire replace
setblock ~166 ~49 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~49 ~422 ~174 ~49 ~422 minecraft:redstone_wire replace
setblock ~184 ~49 ~425 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~49 ~426 ~188 ~49 ~426 minecraft:redstone_wire replace
setblock ~190 ~49 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~49 ~426 ~198 ~49 ~426 minecraft:redstone_wire replace
setblock ~208 ~49 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~49 ~430 ~215 ~49 ~430 minecraft:redstone_wire replace
setblock ~217 ~49 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~49 ~430 ~225 ~49 ~430 minecraft:redstone_wire replace
setblock ~232 ~49 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~231 ~49 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~49 ~434 ~245 ~49 ~434 minecraft:redstone_wire replace
setblock ~247 ~49 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~49 ~434 ~255 ~49 ~434 minecraft:redstone_wire replace
setblock ~253 ~49 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~49 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~49 ~438 ~266 ~49 ~438 minecraft:redstone_wire replace
setblock ~268 ~49 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~49 ~438 ~276 ~49 ~438 minecraft:redstone_wire replace
setblock ~268 ~49 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~49 ~442 ~268 ~49 ~442 minecraft:redstone_wire replace
setblock ~270 ~49 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~49 ~442 ~285 ~49 ~442 minecraft:redstone_wire replace
setblock ~287 ~49 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~49 ~442 ~302 ~49 ~442 minecraft:redstone_wire replace
setblock ~304 ~49 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~49 ~442 ~312 ~49 ~442 minecraft:redstone_wire replace
setblock ~88 ~49 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~49 ~446 ~89 ~49 ~446 minecraft:redstone_wire replace
setblock ~112 ~49 ~449 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~49 ~450 ~114 ~49 ~450 minecraft:redstone_wire replace
setblock ~133 ~49 ~453 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~49 ~454 ~138 ~49 ~454 minecraft:redstone_wire replace
setblock ~160 ~49 ~457 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~49 ~458 ~161 ~49 ~458 minecraft:redstone_wire replace
setblock ~163 ~49 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~49 ~458 ~171 ~49 ~458 minecraft:redstone_wire replace
setblock ~181 ~49 ~461 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~49 ~462 ~185 ~49 ~462 minecraft:redstone_wire replace
setblock ~187 ~49 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~49 ~462 ~195 ~49 ~462 minecraft:redstone_wire replace
setblock ~205 ~49 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~49 ~466 ~212 ~49 ~466 minecraft:redstone_wire replace
setblock ~214 ~49 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~49 ~466 ~222 ~49 ~466 minecraft:redstone_wire replace
setblock ~229 ~49 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~49 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~49 ~470 ~242 ~49 ~470 minecraft:redstone_wire replace
setblock ~244 ~49 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~49 ~470 ~252 ~49 ~470 minecraft:redstone_wire replace
setblock ~250 ~49 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~249 ~49 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~49 ~474 ~263 ~49 ~474 minecraft:redstone_wire replace
setblock ~265 ~49 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~49 ~474 ~273 ~49 ~474 minecraft:redstone_wire replace
setblock ~292 ~49 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~291 ~49 ~478 ~292 ~49 ~478 minecraft:redstone_wire replace
setblock ~294 ~49 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~49 ~478 ~309 ~49 ~478 minecraft:redstone_wire replace
setblock ~311 ~49 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~49 ~478 ~326 ~49 ~478 minecraft:redstone_wire replace
setblock ~328 ~49 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~49 ~478 ~336 ~49 ~478 minecraft:redstone_wire replace
setblock ~316 ~49 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~49 ~482 ~316 ~49 ~482 minecraft:redstone_wire replace
setblock ~318 ~49 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~320 ~49 ~482 ~333 ~49 ~482 minecraft:redstone_wire replace
setblock ~335 ~49 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~49 ~482 ~350 ~49 ~482 minecraft:redstone_wire replace
setblock ~352 ~49 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~49 ~482 ~360 ~49 ~482 minecraft:redstone_wire replace
setblock ~85 ~49 ~485 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~49 ~486 ~86 ~49 ~486 minecraft:redstone_wire replace
setblock ~109 ~49 ~489 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~49 ~490 ~111 ~49 ~490 minecraft:redstone_wire replace
setblock ~130 ~49 ~493 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~49 ~494 ~135 ~49 ~494 minecraft:redstone_wire replace
setblock ~154 ~49 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~49 ~498 ~154 ~49 ~498 minecraft:redstone_wire replace
setblock ~155 ~49 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~49 ~498 ~162 ~49 ~498 minecraft:redstone_wire replace
setblock ~178 ~49 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~49 ~502 ~182 ~49 ~502 minecraft:redstone_wire replace
setblock ~184 ~49 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~49 ~502 ~192 ~49 ~502 minecraft:redstone_wire replace
setblock ~202 ~49 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~49 ~506 ~209 ~49 ~506 minecraft:redstone_wire replace
setblock ~211 ~49 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~49 ~506 ~219 ~49 ~506 minecraft:redstone_wire replace
setblock ~226 ~49 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~49 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~49 ~510 ~239 ~49 ~510 minecraft:redstone_wire replace
setblock ~241 ~49 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~49 ~510 ~249 ~49 ~510 minecraft:redstone_wire replace
setblock ~247 ~49 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~246 ~49 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~49 ~514 ~260 ~49 ~514 minecraft:redstone_wire replace
setblock ~262 ~49 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~49 ~514 ~270 ~49 ~514 minecraft:redstone_wire replace
setblock ~286 ~49 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~49 ~518 ~286 ~49 ~518 minecraft:redstone_wire replace
setblock ~288 ~49 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~49 ~518 ~303 ~49 ~518 minecraft:redstone_wire replace
setblock ~305 ~49 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~49 ~518 ~320 ~49 ~518 minecraft:redstone_wire replace
setblock ~322 ~49 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~49 ~518 ~330 ~49 ~518 minecraft:redstone_wire replace
setblock ~313 ~49 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~49 ~522 ~313 ~49 ~522 minecraft:redstone_wire replace
setblock ~315 ~49 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~49 ~522 ~330 ~49 ~522 minecraft:redstone_wire replace
setblock ~332 ~49 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~49 ~522 ~347 ~49 ~522 minecraft:redstone_wire replace
setblock ~349 ~49 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~49 ~522 ~357 ~49 ~522 minecraft:redstone_wire replace
setblock ~82 ~49 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~49 ~526 ~83 ~49 ~526 minecraft:redstone_wire replace
setblock ~106 ~49 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~49 ~530 ~108 ~49 ~530 minecraft:redstone_wire replace
setblock ~127 ~49 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~49 ~534 ~132 ~49 ~534 minecraft:redstone_wire replace
setblock ~148 ~49 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~49 ~538 ~148 ~49 ~538 minecraft:redstone_wire replace
setblock ~149 ~49 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~49 ~538 ~156 ~49 ~538 minecraft:redstone_wire replace
setblock ~175 ~49 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~49 ~542 ~179 ~49 ~542 minecraft:redstone_wire replace
setblock ~181 ~49 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~49 ~542 ~189 ~49 ~542 minecraft:redstone_wire replace
setblock ~199 ~49 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~49 ~546 ~206 ~49 ~546 minecraft:redstone_wire replace
setblock ~208 ~49 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~49 ~546 ~216 ~49 ~546 minecraft:redstone_wire replace
setblock ~223 ~49 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~49 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~49 ~550 ~236 ~49 ~550 minecraft:redstone_wire replace
setblock ~238 ~49 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~49 ~550 ~246 ~49 ~550 minecraft:redstone_wire replace
setblock ~241 ~49 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~240 ~49 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~49 ~554 ~254 ~49 ~554 minecraft:redstone_wire replace
setblock ~256 ~49 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~49 ~554 ~264 ~49 ~554 minecraft:redstone_wire replace
setblock ~283 ~49 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~49 ~558 ~283 ~49 ~558 minecraft:redstone_wire replace
setblock ~285 ~49 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~287 ~49 ~558 ~300 ~49 ~558 minecraft:redstone_wire replace
setblock ~302 ~49 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~49 ~558 ~317 ~49 ~558 minecraft:redstone_wire replace
setblock ~319 ~49 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~49 ~558 ~327 ~49 ~558 minecraft:redstone_wire replace
setblock ~307 ~49 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~306 ~49 ~562 ~307 ~49 ~562 minecraft:redstone_wire replace
setblock ~309 ~49 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~311 ~49 ~562 ~324 ~49 ~562 minecraft:redstone_wire replace
setblock ~326 ~49 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~328 ~49 ~562 ~341 ~49 ~562 minecraft:redstone_wire replace
setblock ~343 ~49 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~345 ~49 ~562 ~351 ~49 ~562 minecraft:redstone_wire replace
setblock ~79 ~49 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~49 ~566 ~80 ~49 ~566 minecraft:redstone_wire replace
setblock ~103 ~49 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~49 ~570 ~105 ~49 ~570 minecraft:redstone_wire replace
setblock ~124 ~49 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~49 ~574 ~129 ~49 ~574 minecraft:redstone_wire replace
setblock ~145 ~49 ~577 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~49 ~578 ~145 ~49 ~578 minecraft:redstone_wire replace
setblock ~146 ~49 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~49 ~578 ~153 ~49 ~578 minecraft:redstone_wire replace
setblock ~169 ~49 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~49 ~582 ~170 ~49 ~582 minecraft:redstone_wire replace
setblock ~172 ~49 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~49 ~582 ~180 ~49 ~582 minecraft:redstone_wire replace
setblock ~190 ~49 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~49 ~586 ~194 ~49 ~586 minecraft:redstone_wire replace
setblock ~196 ~49 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~49 ~586 ~204 ~49 ~586 minecraft:redstone_wire replace
setblock ~220 ~49 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~49 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~49 ~590 ~233 ~49 ~590 minecraft:redstone_wire replace
setblock ~235 ~49 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~49 ~590 ~243 ~49 ~590 minecraft:redstone_wire replace
setblock ~238 ~49 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~237 ~49 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~49 ~594 ~251 ~49 ~594 minecraft:redstone_wire replace
setblock ~253 ~49 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~49 ~594 ~261 ~49 ~594 minecraft:redstone_wire replace
setblock ~280 ~49 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~49 ~598 ~280 ~49 ~598 minecraft:redstone_wire replace
setblock ~282 ~49 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~284 ~49 ~598 ~297 ~49 ~598 minecraft:redstone_wire replace
setblock ~299 ~49 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~49 ~598 ~314 ~49 ~598 minecraft:redstone_wire replace
setblock ~316 ~49 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~49 ~598 ~324 ~49 ~598 minecraft:redstone_wire replace
setblock ~304 ~49 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~303 ~49 ~602 ~304 ~49 ~602 minecraft:redstone_wire replace
setblock ~306 ~49 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~49 ~602 ~321 ~49 ~602 minecraft:redstone_wire replace
setblock ~323 ~49 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~325 ~49 ~602 ~338 ~49 ~602 minecraft:redstone_wire replace
setblock ~340 ~49 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~342 ~49 ~602 ~348 ~49 ~602 minecraft:redstone_wire replace
setblock ~100 ~49 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~49 ~606 ~102 ~49 ~606 minecraft:redstone_wire replace
setblock ~121 ~49 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~49 ~610 ~126 ~49 ~610 minecraft:redstone_wire replace
setblock ~142 ~49 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~49 ~614 ~142 ~49 ~614 minecraft:redstone_wire replace
setblock ~143 ~49 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~49 ~614 ~150 ~49 ~614 minecraft:redstone_wire replace
setblock ~166 ~49 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~49 ~618 ~167 ~49 ~618 minecraft:redstone_wire replace
setblock ~169 ~49 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~49 ~618 ~177 ~49 ~618 minecraft:redstone_wire replace
setblock ~187 ~49 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~49 ~622 ~191 ~49 ~622 minecraft:redstone_wire replace
setblock ~193 ~49 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~49 ~622 ~201 ~49 ~622 minecraft:redstone_wire replace
setblock ~211 ~49 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~49 ~626 ~218 ~49 ~626 minecraft:redstone_wire replace
setblock ~220 ~49 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~49 ~626 ~228 ~49 ~626 minecraft:redstone_wire replace
setblock ~244 ~49 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~49 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~49 ~630 ~257 ~49 ~630 minecraft:redstone_wire replace
setblock ~259 ~49 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~49 ~630 ~267 ~49 ~630 minecraft:redstone_wire replace
setblock ~256 ~49 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~49 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~49 ~634 ~269 ~49 ~634 minecraft:redstone_wire replace
setblock ~271 ~49 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~49 ~634 ~279 ~49 ~634 minecraft:redstone_wire replace
setblock ~295 ~49 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~294 ~49 ~638 ~295 ~49 ~638 minecraft:redstone_wire replace
setblock ~297 ~49 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~299 ~49 ~638 ~312 ~49 ~638 minecraft:redstone_wire replace
setblock ~314 ~49 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~316 ~49 ~638 ~329 ~49 ~638 minecraft:redstone_wire replace
setblock ~331 ~49 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~333 ~49 ~638 ~339 ~49 ~638 minecraft:redstone_wire replace
setblock ~151 ~49 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~49 ~642 ~151 ~49 ~642 minecraft:redstone_wire replace
setblock ~152 ~49 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~49 ~642 ~159 ~49 ~642 minecraft:redstone_wire replace
setblock ~322 ~49 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~321 ~49 ~646 ~322 ~49 ~646 minecraft:redstone_wire replace
setblock ~324 ~49 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~326 ~49 ~646 ~339 ~49 ~646 minecraft:redstone_wire replace
setblock ~341 ~49 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~49 ~646 ~356 ~49 ~646 minecraft:redstone_wire replace
setblock ~358 ~49 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~360 ~49 ~646 ~366 ~49 ~646 minecraft:redstone_wire replace
setblock ~97 ~49 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~49 ~650 ~99 ~49 ~650 minecraft:redstone_wire replace
setblock ~298 ~49 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~49 ~654 ~298 ~49 ~654 minecraft:redstone_wire replace
setblock ~300 ~49 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~49 ~654 ~315 ~49 ~654 minecraft:redstone_wire replace
setblock ~317 ~49 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~49 ~654 ~332 ~49 ~654 minecraft:redstone_wire replace
setblock ~334 ~49 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~49 ~654 ~342 ~49 ~654 minecraft:redstone_wire replace
setblock ~319 ~49 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~49 ~658 ~319 ~49 ~658 minecraft:redstone_wire replace
setblock ~321 ~49 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~323 ~49 ~658 ~336 ~49 ~658 minecraft:redstone_wire replace
setblock ~338 ~49 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~340 ~49 ~658 ~353 ~49 ~658 minecraft:redstone_wire replace
setblock ~355 ~49 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~357 ~49 ~658 ~363 ~49 ~658 minecraft:redstone_wire replace
setblock ~262 ~50 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~50 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~50 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~50 ~72 minecraft:redstone_wire replace
setblock ~94 ~50 ~240 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~50 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~50 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~50 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~50 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~50 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~50 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~50 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~50 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~50 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~50 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~50 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~50 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~50 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~50 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~50 ~336 minecraft:redstone_wire replace
setblock ~214 ~50 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~50 ~352 minecraft:redstone_wire replace
setblock ~262 ~50 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~50 ~364 minecraft:redstone_wire replace
setblock ~259 ~50 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~50 ~380 minecraft:redstone_wire replace
setblock ~289 ~50 ~384 minecraft:redstone_wire replace
setblock ~310 ~50 ~388 minecraft:redstone_wire replace
setblock ~277 ~50 ~392 minecraft:redstone_wire replace
setblock ~301 ~50 ~396 minecraft:redstone_wire replace
setblock ~271 ~50 ~400 minecraft:redstone_wire replace
setblock ~91 ~50 ~408 minecraft:redstone_wire replace
setblock ~115 ~50 ~412 minecraft:redstone_wire replace
setblock ~136 ~50 ~416 minecraft:redstone_wire replace
setblock ~163 ~50 ~420 minecraft:redstone_wire replace
setblock ~184 ~50 ~424 minecraft:redstone_wire replace
setblock ~208 ~50 ~428 minecraft:redstone_wire replace
setblock ~232 ~50 ~432 minecraft:redstone_wire replace
setblock ~253 ~50 ~436 minecraft:redstone_wire replace
setblock ~268 ~50 ~440 minecraft:redstone_wire replace
setblock ~88 ~50 ~444 minecraft:redstone_wire replace
setblock ~112 ~50 ~448 minecraft:redstone_wire replace
setblock ~133 ~50 ~452 minecraft:redstone_wire replace
setblock ~160 ~50 ~456 minecraft:redstone_wire replace
setblock ~181 ~50 ~460 minecraft:redstone_wire replace
setblock ~205 ~50 ~464 minecraft:redstone_wire replace
setblock ~229 ~50 ~468 minecraft:redstone_wire replace
setblock ~250 ~50 ~472 minecraft:redstone_wire replace
setblock ~292 ~50 ~476 minecraft:redstone_wire replace
setblock ~316 ~50 ~480 minecraft:redstone_wire replace
setblock ~85 ~50 ~484 minecraft:redstone_wire replace
setblock ~109 ~50 ~488 minecraft:redstone_wire replace
setblock ~130 ~50 ~492 minecraft:redstone_wire replace
setblock ~154 ~50 ~496 minecraft:redstone_wire replace
setblock ~178 ~50 ~500 minecraft:redstone_wire replace
setblock ~202 ~50 ~504 minecraft:redstone_wire replace
setblock ~226 ~50 ~508 minecraft:redstone_wire replace
setblock ~247 ~50 ~512 minecraft:redstone_wire replace
setblock ~286 ~50 ~516 minecraft:redstone_wire replace
setblock ~313 ~50 ~520 minecraft:redstone_wire replace
setblock ~82 ~50 ~524 minecraft:redstone_wire replace
setblock ~106 ~50 ~528 minecraft:redstone_wire replace
setblock ~127 ~50 ~532 minecraft:redstone_wire replace
setblock ~148 ~50 ~536 minecraft:redstone_wire replace
setblock ~175 ~50 ~540 minecraft:redstone_wire replace
setblock ~199 ~50 ~544 minecraft:redstone_wire replace
setblock ~223 ~50 ~548 minecraft:redstone_wire replace
setblock ~241 ~50 ~552 minecraft:redstone_wire replace
setblock ~283 ~50 ~556 minecraft:redstone_wire replace
setblock ~307 ~50 ~560 minecraft:redstone_wire replace
setblock ~79 ~50 ~564 minecraft:redstone_wire replace
setblock ~103 ~50 ~568 minecraft:redstone_wire replace
setblock ~124 ~50 ~572 minecraft:redstone_wire replace
setblock ~145 ~50 ~576 minecraft:redstone_wire replace
setblock ~169 ~50 ~580 minecraft:redstone_wire replace
setblock ~190 ~50 ~584 minecraft:redstone_wire replace
setblock ~220 ~50 ~588 minecraft:redstone_wire replace
setblock ~238 ~50 ~592 minecraft:redstone_wire replace
setblock ~280 ~50 ~596 minecraft:redstone_wire replace
setblock ~304 ~50 ~600 minecraft:redstone_wire replace
setblock ~100 ~50 ~604 minecraft:redstone_wire replace
setblock ~121 ~50 ~608 minecraft:redstone_wire replace
setblock ~142 ~50 ~612 minecraft:redstone_wire replace
setblock ~166 ~50 ~616 minecraft:redstone_wire replace
setblock ~187 ~50 ~620 minecraft:redstone_wire replace
setblock ~211 ~50 ~624 minecraft:redstone_wire replace
setblock ~244 ~50 ~628 minecraft:redstone_wire replace
setblock ~256 ~50 ~632 minecraft:redstone_wire replace
setblock ~295 ~50 ~636 minecraft:redstone_wire replace
setblock ~151 ~50 ~640 minecraft:redstone_wire replace
setblock ~322 ~50 ~644 minecraft:redstone_wire replace
setblock ~97 ~50 ~648 minecraft:redstone_wire replace
setblock ~298 ~50 ~652 minecraft:redstone_wire replace
setblock ~319 ~50 ~656 minecraft:redstone_wire replace
fill ~261 ~51 ~32 ~261 ~51 ~44 minecraft:redstone_wire replace
fill ~258 ~51 ~36 ~258 ~51 ~48 minecraft:redstone_wire replace
fill ~213 ~51 ~40 ~213 ~51 ~52 minecraft:redstone_wire replace
setblock ~261 ~51 ~45 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~46 ~261 ~51 ~58 minecraft:redstone_wire replace
setblock ~258 ~51 ~49 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~50 ~258 ~51 ~62 minecraft:redstone_wire replace
setblock ~213 ~51 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~56 ~213 ~51 ~68 minecraft:redstone_wire replace
setblock ~261 ~51 ~60 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~62 ~261 ~51 ~74 minecraft:redstone_wire replace
setblock ~258 ~51 ~64 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~66 ~258 ~51 ~78 minecraft:redstone_wire replace
setblock ~213 ~51 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~72 ~213 ~51 ~84 minecraft:redstone_wire replace
fill ~273 ~51 ~72 ~273 ~51 ~76 minecraft:redstone_wire replace
setblock ~261 ~51 ~76 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~78 ~261 ~51 ~90 minecraft:redstone_wire replace
setblock ~258 ~51 ~80 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~82 ~258 ~51 ~94 minecraft:redstone_wire replace
setblock ~213 ~51 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~88 ~213 ~51 ~100 minecraft:redstone_wire replace
setblock ~261 ~51 ~92 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~94 ~261 ~51 ~106 minecraft:redstone_wire replace
setblock ~258 ~51 ~96 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~98 ~258 ~51 ~110 minecraft:redstone_wire replace
setblock ~213 ~51 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~104 ~213 ~51 ~116 minecraft:redstone_wire replace
setblock ~261 ~51 ~108 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~110 ~261 ~51 ~122 minecraft:redstone_wire replace
setblock ~258 ~51 ~112 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~114 ~258 ~51 ~126 minecraft:redstone_wire replace
setblock ~213 ~51 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~120 ~213 ~51 ~132 minecraft:redstone_wire replace
setblock ~261 ~51 ~124 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~126 ~261 ~51 ~138 minecraft:redstone_wire replace
setblock ~258 ~51 ~128 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~130 ~258 ~51 ~142 minecraft:redstone_wire replace
setblock ~213 ~51 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~136 ~213 ~51 ~148 minecraft:redstone_wire replace
setblock ~261 ~51 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~142 ~261 ~51 ~154 minecraft:redstone_wire replace
setblock ~258 ~51 ~144 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~146 ~258 ~51 ~158 minecraft:redstone_wire replace
setblock ~213 ~51 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~152 ~213 ~51 ~164 minecraft:redstone_wire replace
setblock ~261 ~51 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~158 ~261 ~51 ~170 minecraft:redstone_wire replace
setblock ~258 ~51 ~160 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~162 ~258 ~51 ~174 minecraft:redstone_wire replace
setblock ~213 ~51 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~168 ~213 ~51 ~180 minecraft:redstone_wire replace
setblock ~261 ~51 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~174 ~261 ~51 ~186 minecraft:redstone_wire replace
setblock ~258 ~51 ~176 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~178 ~258 ~51 ~190 minecraft:redstone_wire replace
setblock ~213 ~51 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~184 ~213 ~51 ~196 minecraft:redstone_wire replace
setblock ~261 ~51 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~190 ~261 ~51 ~202 minecraft:redstone_wire replace
setblock ~258 ~51 ~192 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~194 ~258 ~51 ~206 minecraft:redstone_wire replace
setblock ~213 ~51 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~200 ~213 ~51 ~212 minecraft:redstone_wire replace
setblock ~261 ~51 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~51 ~206 ~261 ~51 ~218 minecraft:redstone_wire replace
setblock ~258 ~51 ~208 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~51 ~210 ~258 ~51 ~222 minecraft:redstone_wire replace
setblock ~213 ~51 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~51 ~216 ~213 ~51 ~228 minecraft:redstone_wire replace
setblock ~261 ~51 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
