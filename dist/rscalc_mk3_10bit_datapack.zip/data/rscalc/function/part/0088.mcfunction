setblock ~78 ~120 ~503 minecraft:redstone_wire replace
setblock ~90 ~120 ~507 minecraft:redstone_wire replace
setblock ~93 ~120 ~511 minecraft:redstone_wire replace
setblock ~123 ~120 ~515 minecraft:redstone_wire replace
setblock ~114 ~120 ~519 minecraft:redstone_wire replace
setblock ~111 ~120 ~523 minecraft:redstone_wire replace
setblock ~108 ~120 ~527 minecraft:redstone_wire replace
setblock ~105 ~120 ~531 minecraft:redstone_wire replace
setblock ~102 ~120 ~535 minecraft:redstone_wire replace
setblock ~99 ~120 ~539 minecraft:redstone_wire replace
setblock ~96 ~120 ~543 minecraft:redstone_wire replace
setblock ~129 ~120 ~559 minecraft:redstone_wire replace
setblock ~117 ~120 ~563 minecraft:redstone_wire replace
setblock ~126 ~120 ~575 minecraft:redstone_wire replace
setblock ~147 ~120 ~591 minecraft:redstone_wire replace
setblock ~141 ~120 ~595 minecraft:redstone_wire replace
setblock ~138 ~120 ~599 minecraft:redstone_wire replace
setblock ~135 ~120 ~603 minecraft:redstone_wire replace
setblock ~132 ~120 ~607 minecraft:redstone_wire replace
setblock ~150 ~120 ~619 minecraft:redstone_wire replace
setblock ~144 ~120 ~623 minecraft:redstone_wire replace
setblock ~159 ~120 ~643 minecraft:redstone_wire replace
setblock ~84 ~120 ~647 minecraft:redstone_wire replace
setblock ~153 ~120 ~651 minecraft:redstone_wire replace
setblock ~156 ~120 ~659 minecraft:redstone_wire replace
setblock ~106 ~121 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~121 ~382 ~110 ~121 ~382 minecraft:redstone_wire replace
setblock ~112 ~121 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~121 ~382 ~120 ~121 ~382 minecraft:redstone_wire replace
setblock ~82 ~121 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~121 ~394 ~83 ~121 ~394 minecraft:redstone_wire replace
setblock ~88 ~121 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~121 ~498 ~89 ~121 ~498 minecraft:redstone_wire replace
setblock ~79 ~121 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~121 ~502 ~80 ~121 ~502 minecraft:redstone_wire replace
setblock ~91 ~121 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~121 ~506 ~92 ~121 ~506 minecraft:redstone_wire replace
setblock ~94 ~121 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~121 ~510 ~95 ~121 ~510 minecraft:redstone_wire replace
setblock ~109 ~121 ~513 minecraft:redstone_wire replace
fill ~108 ~121 ~514 ~109 ~121 ~514 minecraft:redstone_wire replace
setblock ~110 ~121 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~121 ~514 ~123 ~121 ~514 minecraft:redstone_wire replace
setblock ~103 ~121 ~517 minecraft:redstone_wire replace
fill ~102 ~121 ~518 ~103 ~121 ~518 minecraft:redstone_wire replace
setblock ~105 ~121 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~121 ~518 ~114 ~121 ~518 minecraft:redstone_wire replace
setblock ~103 ~121 ~521 minecraft:redstone_wire replace
fill ~102 ~121 ~522 ~111 ~121 ~522 minecraft:redstone_wire replace
setblock ~100 ~121 ~525 minecraft:redstone_wire replace
fill ~99 ~121 ~526 ~108 ~121 ~526 minecraft:redstone_wire replace
setblock ~100 ~121 ~529 minecraft:redstone_wire replace
fill ~99 ~121 ~530 ~105 ~121 ~530 minecraft:redstone_wire replace
setblock ~100 ~121 ~533 minecraft:redstone_wire replace
fill ~99 ~121 ~534 ~102 ~121 ~534 minecraft:redstone_wire replace
setblock ~97 ~121 ~537 minecraft:redstone_wire replace
fill ~96 ~121 ~538 ~99 ~121 ~538 minecraft:redstone_wire replace
setblock ~97 ~121 ~541 minecraft:redstone_wire replace
fill ~96 ~121 ~542 ~98 ~121 ~542 minecraft:redstone_wire replace
setblock ~109 ~121 ~557 minecraft:redstone_wire replace
fill ~108 ~121 ~558 ~113 ~121 ~558 minecraft:redstone_wire replace
setblock ~115 ~121 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~121 ~558 ~129 ~121 ~558 minecraft:redstone_wire replace
setblock ~103 ~121 ~561 minecraft:redstone_wire replace
fill ~102 ~121 ~562 ~103 ~121 ~562 minecraft:redstone_wire replace
setblock ~104 ~121 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~121 ~562 ~117 ~121 ~562 minecraft:redstone_wire replace
setblock ~109 ~121 ~573 minecraft:redstone_wire replace
fill ~108 ~121 ~574 ~110 ~121 ~574 minecraft:redstone_wire replace
setblock ~112 ~121 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~121 ~574 ~126 ~121 ~574 minecraft:redstone_wire replace
setblock ~121 ~121 ~589 minecraft:redstone_wire replace
fill ~120 ~121 ~590 ~131 ~121 ~590 minecraft:redstone_wire replace
setblock ~133 ~121 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~121 ~590 ~147 ~121 ~590 minecraft:redstone_wire replace
setblock ~118 ~121 ~593 minecraft:redstone_wire replace
fill ~117 ~121 ~594 ~125 ~121 ~594 minecraft:redstone_wire replace
setblock ~127 ~121 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~121 ~594 ~141 ~121 ~594 minecraft:redstone_wire replace
setblock ~115 ~121 ~597 minecraft:redstone_wire replace
fill ~114 ~121 ~598 ~127 ~121 ~598 minecraft:redstone_wire replace
setblock ~129 ~121 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~121 ~598 ~138 ~121 ~598 minecraft:redstone_wire replace
setblock ~115 ~121 ~601 minecraft:redstone_wire replace
fill ~114 ~121 ~602 ~120 ~121 ~602 minecraft:redstone_wire replace
setblock ~122 ~121 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~121 ~602 ~135 ~121 ~602 minecraft:redstone_wire replace
setblock ~112 ~121 ~605 minecraft:redstone_wire replace
fill ~111 ~121 ~606 ~116 ~121 ~606 minecraft:redstone_wire replace
setblock ~118 ~121 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~121 ~606 ~132 ~121 ~606 minecraft:redstone_wire replace
setblock ~121 ~121 ~617 minecraft:redstone_wire replace
fill ~120 ~121 ~618 ~122 ~121 ~618 minecraft:redstone_wire replace
setblock ~123 ~121 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~121 ~618 ~136 ~121 ~618 minecraft:redstone_wire replace
setblock ~138 ~121 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~121 ~618 ~150 ~121 ~618 minecraft:redstone_wire replace
setblock ~118 ~121 ~621 minecraft:redstone_wire replace
fill ~117 ~121 ~622 ~128 ~121 ~622 minecraft:redstone_wire replace
setblock ~130 ~121 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~121 ~622 ~144 ~121 ~622 minecraft:redstone_wire replace
setblock ~130 ~121 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~121 ~642 ~132 ~121 ~642 minecraft:redstone_wire replace
setblock ~134 ~121 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~121 ~642 ~149 ~121 ~642 minecraft:redstone_wire replace
setblock ~151 ~121 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~121 ~642 ~159 ~121 ~642 minecraft:redstone_wire replace
setblock ~85 ~121 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~121 ~646 ~86 ~121 ~646 minecraft:redstone_wire replace
setblock ~124 ~121 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~121 ~650 ~126 ~121 ~650 minecraft:redstone_wire replace
setblock ~128 ~121 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~121 ~650 ~143 ~121 ~650 minecraft:redstone_wire replace
setblock ~145 ~121 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~121 ~650 ~153 ~121 ~650 minecraft:redstone_wire replace
setblock ~127 ~121 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~121 ~658 ~129 ~121 ~658 minecraft:redstone_wire replace
setblock ~131 ~121 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~121 ~658 ~146 ~121 ~658 minecraft:redstone_wire replace
setblock ~148 ~121 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~121 ~658 ~156 ~121 ~658 minecraft:redstone_wire replace
setblock ~106 ~122 ~380 minecraft:redstone_wire replace
setblock ~82 ~122 ~392 minecraft:redstone_wire replace
setblock ~88 ~122 ~496 minecraft:redstone_wire replace
setblock ~79 ~122 ~500 minecraft:redstone_wire replace
setblock ~91 ~122 ~504 minecraft:redstone_wire replace
setblock ~94 ~122 ~508 minecraft:redstone_wire replace
setblock ~109 ~122 ~512 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~122 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~122 ~520 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~122 ~524 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~122 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~122 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~122 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~122 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~122 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~122 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~122 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~122 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~122 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~122 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~122 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~122 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~122 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~122 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~122 ~640 minecraft:redstone_wire replace
setblock ~85 ~122 ~644 minecraft:redstone_wire replace
setblock ~124 ~122 ~648 minecraft:redstone_wire replace
setblock ~127 ~122 ~656 minecraft:redstone_wire replace
fill ~105 ~123 ~380 ~105 ~123 ~384 minecraft:redstone_wire replace
fill ~81 ~123 ~392 ~81 ~123 ~396 minecraft:redstone_wire replace
fill ~87 ~123 ~496 ~87 ~123 ~500 minecraft:redstone_wire replace
fill ~78 ~123 ~500 ~78 ~123 ~504 minecraft:redstone_wire replace
fill ~90 ~123 ~504 ~90 ~123 ~508 minecraft:redstone_wire replace
fill ~93 ~123 ~508 ~93 ~123 ~512 minecraft:redstone_wire replace
fill ~108 ~123 ~512 ~108 ~123 ~524 minecraft:redstone_wire replace
fill ~102 ~123 ~516 ~102 ~123 ~528 minecraft:redstone_wire replace
fill ~99 ~123 ~524 ~99 ~123 ~534 minecraft:redstone_wire replace
setblock ~108 ~123 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~528 ~108 ~123 ~540 minecraft:redstone_wire replace
setblock ~102 ~123 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~123 ~532 ~102 ~123 ~544 minecraft:redstone_wire replace
fill ~96 ~123 ~536 ~96 ~123 ~542 minecraft:redstone_wire replace
setblock ~99 ~123 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~123 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~123 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~544 ~108 ~123 ~556 minecraft:redstone_wire replace
setblock ~102 ~123 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~123 ~548 ~102 ~123 ~560 minecraft:redstone_wire replace
setblock ~108 ~123 ~557 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~558 ~108 ~123 ~570 minecraft:redstone_wire replace
setblock ~102 ~123 ~561 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~123 ~562 ~102 ~123 ~564 minecraft:redstone_wire replace
setblock ~108 ~123 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~572 ~108 ~123 ~576 minecraft:redstone_wire replace
fill ~120 ~123 ~588 ~120 ~123 ~600 minecraft:redstone_wire replace
fill ~117 ~123 ~592 ~117 ~123 ~604 minecraft:redstone_wire replace
fill ~114 ~123 ~596 ~114 ~123 ~602 minecraft:redstone_wire replace
setblock ~120 ~123 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~123 ~604 ~111 ~123 ~608 minecraft:redstone_wire replace
setblock ~114 ~123 ~604 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~123 ~604 ~120 ~123 ~616 minecraft:redstone_wire replace
setblock ~117 ~123 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~123 ~608 ~117 ~123 ~620 minecraft:redstone_wire replace
setblock ~120 ~123 ~617 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~123 ~618 ~120 ~123 ~620 minecraft:redstone_wire replace
setblock ~117 ~123 ~621 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~123 ~622 ~117 ~123 ~624 minecraft:redstone_wire replace
fill ~129 ~123 ~640 ~129 ~123 ~644 minecraft:redstone_wire replace
fill ~84 ~123 ~644 ~84 ~123 ~648 minecraft:redstone_wire replace
fill ~123 ~123 ~648 ~123 ~123 ~652 minecraft:redstone_wire replace
fill ~126 ~123 ~656 ~126 ~123 ~660 minecraft:redstone_wire replace
setblock ~105 ~124 ~385 minecraft:redstone_wire replace
setblock ~81 ~124 ~397 minecraft:redstone_wire replace
setblock ~87 ~124 ~501 minecraft:redstone_wire replace
setblock ~78 ~124 ~505 minecraft:redstone_wire replace
setblock ~90 ~124 ~509 minecraft:redstone_wire replace
setblock ~93 ~124 ~513 minecraft:redstone_wire replace
setblock ~99 ~124 ~537 minecraft:redstone_wire replace
setblock ~96 ~124 ~545 minecraft:redstone_wire replace
setblock ~102 ~124 ~565 minecraft:redstone_wire replace
setblock ~108 ~124 ~577 minecraft:redstone_wire replace
setblock ~114 ~124 ~605 minecraft:redstone_wire replace
setblock ~111 ~124 ~609 minecraft:redstone_wire replace
setblock ~120 ~124 ~621 minecraft:redstone_wire replace
setblock ~117 ~124 ~625 minecraft:redstone_wire replace
setblock ~129 ~124 ~645 minecraft:redstone_wire replace
setblock ~84 ~124 ~649 minecraft:redstone_wire replace
setblock ~123 ~124 ~653 minecraft:redstone_wire replace
setblock ~126 ~124 ~661 minecraft:redstone_wire replace
fill ~105 ~125 ~386 ~111 ~125 ~386 minecraft:redstone_wire replace
setblock ~113 ~125 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~125 ~386 ~119 ~125 ~386 minecraft:redstone_wire replace
setblock ~118 ~125 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~125 ~398 ~83 ~125 ~398 minecraft:redstone_wire replace
setblock ~82 ~125 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~125 ~502 ~89 ~125 ~502 minecraft:redstone_wire replace
setblock ~88 ~125 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~125 ~506 ~80 ~125 ~506 minecraft:redstone_wire replace
setblock ~79 ~125 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~125 ~510 ~92 ~125 ~510 minecraft:redstone_wire replace
setblock ~91 ~125 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~125 ~514 ~98 ~125 ~514 minecraft:redstone_wire replace
setblock ~99 ~125 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~100 ~125 ~514 ~112 ~125 ~514 minecraft:redstone_wire replace
setblock ~113 ~125 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~114 ~125 ~514 ~122 ~125 ~514 minecraft:redstone_wire replace
setblock ~94 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~125 ~515 minecraft:redstone_wire replace
setblock ~100 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~125 ~515 minecraft:redstone_wire replace
setblock ~106 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~125 ~515 minecraft:redstone_wire replace
setblock ~121 ~125 ~515 minecraft:redstone_wire replace
fill ~93 ~125 ~538 ~110 ~125 ~538 minecraft:redstone_wire replace
setblock ~111 ~125 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~125 ~538 ~124 ~125 ~538 minecraft:redstone_wire replace
setblock ~125 ~125 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~125 ~538 ~128 ~125 ~538 minecraft:redstone_wire replace
setblock ~94 ~125 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~125 ~539 minecraft:redstone_wire replace
setblock ~103 ~125 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~125 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~125 ~539 minecraft:redstone_wire replace
setblock ~115 ~125 ~539 minecraft:redstone_wire replace
setblock ~127 ~125 ~539 minecraft:redstone_wire replace
fill ~93 ~125 ~546 ~107 ~125 ~546 minecraft:redstone_wire replace
setblock ~108 ~125 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~125 ~546 ~121 ~125 ~546 minecraft:redstone_wire replace
setblock ~122 ~125 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~125 ~546 ~125 ~125 ~546 minecraft:redstone_wire replace
setblock ~94 ~125 ~547 minecraft:redstone_wire replace
setblock ~97 ~125 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~125 ~547 minecraft:redstone_wire replace
setblock ~109 ~125 ~547 minecraft:redstone_wire replace
setblock ~115 ~125 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~125 ~547 minecraft:redstone_wire replace
fill ~96 ~125 ~566 ~110 ~125 ~566 minecraft:redstone_wire replace
setblock ~111 ~125 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~125 ~566 ~124 ~125 ~566 minecraft:redstone_wire replace
setblock ~125 ~125 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~125 ~566 ~128 ~125 ~566 minecraft:redstone_wire replace
setblock ~97 ~125 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~125 ~567 minecraft:redstone_wire replace
setblock ~106 ~125 ~567 minecraft:redstone_wire replace
setblock ~112 ~125 ~567 minecraft:redstone_wire replace
setblock ~115 ~125 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~125 ~567 minecraft:redstone_wire replace
setblock ~127 ~125 ~567 minecraft:redstone_wire replace
fill ~108 ~125 ~578 ~114 ~125 ~578 minecraft:redstone_wire replace
setblock ~116 ~125 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~125 ~578 ~131 ~125 ~578 minecraft:redstone_wire replace
setblock ~132 ~125 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~125 ~578 ~146 ~125 ~578 minecraft:redstone_wire replace
setblock ~147 ~125 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~125 ~578 ~161 ~125 ~578 minecraft:redstone_wire replace
setblock ~130 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~125 ~579 minecraft:redstone_wire replace
setblock ~136 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~125 ~579 minecraft:redstone_wire replace
setblock ~142 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~125 ~579 minecraft:redstone_wire replace
setblock ~160 ~125 ~579 minecraft:redstone_wire replace
fill ~114 ~125 ~606 ~126 ~125 ~606 minecraft:redstone_wire replace
setblock ~128 ~125 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~125 ~606 ~143 ~125 ~606 minecraft:redstone_wire replace
setblock ~145 ~125 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~125 ~606 ~160 ~125 ~606 minecraft:redstone_wire replace
setblock ~161 ~125 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~125 ~606 ~164 ~125 ~606 minecraft:redstone_wire replace
setblock ~130 ~125 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~125 ~607 minecraft:redstone_wire replace
setblock ~139 ~125 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~125 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~125 ~607 minecraft:redstone_wire replace
setblock ~151 ~125 ~607 minecraft:redstone_wire replace
setblock ~163 ~125 ~607 minecraft:redstone_wire replace
fill ~111 ~125 ~610 ~117 ~125 ~610 minecraft:redstone_wire replace
setblock ~119 ~125 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~125 ~610 ~134 ~125 ~610 minecraft:redstone_wire replace
setblock ~136 ~125 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~138 ~125 ~610 ~151 ~125 ~610 minecraft:redstone_wire replace
setblock ~152 ~125 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~125 ~610 ~158 ~125 ~610 minecraft:redstone_wire replace
setblock ~130 ~125 ~611 minecraft:redstone_wire replace
setblock ~133 ~125 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~125 ~611 minecraft:redstone_wire replace
setblock ~145 ~125 ~611 minecraft:redstone_wire replace
setblock ~151 ~125 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~125 ~611 minecraft:redstone_wire replace
fill ~120 ~125 ~622 ~129 ~125 ~622 minecraft:redstone_wire replace
setblock ~131 ~125 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~125 ~622 ~146 ~125 ~622 minecraft:redstone_wire replace
setblock ~148 ~125 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~125 ~622 ~155 ~125 ~622 minecraft:redstone_wire replace
setblock ~154 ~125 ~623 minecraft:redstone_wire replace
fill ~117 ~125 ~626 ~126 ~125 ~626 minecraft:redstone_wire replace
setblock ~128 ~125 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~125 ~626 ~143 ~125 ~626 minecraft:redstone_wire replace
setblock ~145 ~125 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~125 ~626 ~160 ~125 ~626 minecraft:redstone_wire replace
setblock ~161 ~125 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~125 ~626 ~164 ~125 ~626 minecraft:redstone_wire replace
setblock ~133 ~125 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~125 ~627 minecraft:redstone_wire replace
setblock ~142 ~125 ~627 minecraft:redstone_wire replace
setblock ~148 ~125 ~627 minecraft:redstone_wire replace
setblock ~151 ~125 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~125 ~627 minecraft:redstone_wire replace
setblock ~163 ~125 ~627 minecraft:redstone_wire replace
fill ~129 ~125 ~646 ~135 ~125 ~646 minecraft:redstone_wire replace
setblock ~137 ~125 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~125 ~646 ~152 ~125 ~646 minecraft:redstone_wire replace
setblock ~154 ~125 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~125 ~646 ~169 ~125 ~646 minecraft:redstone_wire replace
setblock ~170 ~125 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~125 ~646 ~173 ~125 ~646 minecraft:redstone_wire replace
setblock ~172 ~125 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~125 ~650 ~86 ~125 ~650 minecraft:redstone_wire replace
setblock ~85 ~125 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~125 ~654 ~129 ~125 ~654 minecraft:redstone_wire replace
setblock ~131 ~125 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~125 ~654 ~146 ~125 ~654 minecraft:redstone_wire replace
setblock ~148 ~125 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~125 ~654 ~163 ~125 ~654 minecraft:redstone_wire replace
setblock ~164 ~125 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~125 ~654 ~167 ~125 ~654 minecraft:redstone_wire replace
setblock ~166 ~125 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~125 ~662 ~132 ~125 ~662 minecraft:redstone_wire replace
setblock ~134 ~125 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~125 ~662 ~149 ~125 ~662 minecraft:redstone_wire replace
setblock ~151 ~125 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~125 ~662 ~166 ~125 ~662 minecraft:redstone_wire replace
setblock ~167 ~125 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~168 ~125 ~662 ~170 ~125 ~662 minecraft:redstone_wire replace
setblock ~169 ~125 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~126 ~388 minecraft:redstone_wire replace
setblock ~82 ~126 ~400 minecraft:redstone_wire replace
setblock ~88 ~126 ~504 minecraft:redstone_wire replace
setblock ~79 ~126 ~508 minecraft:redstone_wire replace
setblock ~91 ~126 ~512 minecraft:redstone_wire replace
setblock ~94 ~126 ~516 minecraft:redstone_wire replace
setblock ~97 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~126 ~516 minecraft:redstone_wire replace
setblock ~103 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~126 ~516 minecraft:redstone_wire replace
setblock ~109 ~126 ~516 minecraft:redstone_wire replace
setblock ~112 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~126 ~540 minecraft:redstone_wire replace
setblock ~100 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~126 ~540 minecraft:redstone_wire replace
setblock ~106 ~126 ~540 minecraft:redstone_wire replace
setblock ~112 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~126 ~548 minecraft:redstone_wire replace
setblock ~103 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~126 ~548 minecraft:redstone_wire replace
setblock ~124 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~126 ~568 minecraft:redstone_wire replace
setblock ~100 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~126 ~568 minecraft:redstone_wire replace
setblock ~121 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~126 ~580 minecraft:redstone_wire replace
setblock ~133 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~126 ~580 minecraft:redstone_wire replace
setblock ~139 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~126 ~580 minecraft:redstone_wire replace
setblock ~145 ~126 ~580 minecraft:redstone_wire replace
setblock ~148 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~126 ~608 minecraft:redstone_wire replace
setblock ~136 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~126 ~608 minecraft:redstone_wire replace
setblock ~142 ~126 ~608 minecraft:redstone_wire replace
setblock ~148 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~126 ~612 minecraft:redstone_wire replace
setblock ~139 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~126 ~612 minecraft:redstone_wire replace
setblock ~157 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~126 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~126 ~628 minecraft:redstone_wire replace
setblock ~136 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~126 ~628 minecraft:redstone_wire replace
setblock ~160 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~126 ~648 minecraft:redstone_wire replace
setblock ~85 ~126 ~652 minecraft:redstone_wire replace
setblock ~166 ~126 ~656 minecraft:redstone_wire replace
setblock ~169 ~126 ~664 minecraft:redstone_wire replace
fill ~117 ~127 ~384 ~117 ~127 ~388 minecraft:redstone_wire replace
fill ~81 ~127 ~396 ~81 ~127 ~400 minecraft:redstone_wire replace
setblock ~87 ~127 ~472 minecraft:redstone_wire replace
setblock ~87 ~127 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~127 ~476 minecraft:redstone_wire replace
fill ~87 ~127 ~476 ~87 ~127 ~488 minecraft:redstone_wire replace
setblock ~78 ~127 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~127 ~480 ~78 ~127 ~492 minecraft:redstone_wire replace
setblock ~90 ~127 ~480 minecraft:redstone_wire replace
setblock ~90 ~127 ~482 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~127 ~484 ~90 ~127 ~496 minecraft:redstone_wire replace
fill ~120 ~127 ~484 ~120 ~127 ~488 minecraft:redstone_wire replace
fill ~111 ~127 ~488 ~111 ~127 ~490 minecraft:redstone_wire replace
setblock ~87 ~127 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~127 ~492 ~87 ~127 ~504 minecraft:redstone_wire replace
setblock ~108 ~127 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~127 ~492 ~120 ~127 ~504 minecraft:redstone_wire replace
setblock ~78 ~127 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~127 ~494 ~108 ~127 ~500 minecraft:redstone_wire replace
fill ~111 ~127 ~494 ~111 ~127 ~506 minecraft:redstone_wire replace
fill ~78 ~127 ~496 ~78 ~127 ~508 minecraft:redstone_wire replace
setblock ~105 ~127 ~496 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~127 ~498 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~127 ~498 ~105 ~127 ~506 minecraft:redstone_wire replace
fill ~90 ~127 ~500 ~90 ~127 ~512 minecraft:redstone_wire replace
setblock ~102 ~127 ~500 minecraft:redstone_wire replace
setblock ~102 ~127 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~127 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~127 ~504 ~99 ~127 ~506 minecraft:redstone_wire replace
fill ~102 ~127 ~504 ~102 ~127 ~516 minecraft:redstone_wire replace
fill ~108 ~127 ~504 ~108 ~127 ~516 minecraft:redstone_wire replace
setblock ~120 ~127 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~127 ~508 ~120 ~127 ~520 minecraft:redstone_wire replace
fill ~96 ~127 ~510 ~96 ~127 ~520 minecraft:redstone_wire replace
fill ~99 ~127 ~510 ~99 ~127 ~522 minecraft:redstone_wire replace
fill ~105 ~127 ~510 ~105 ~127 ~522 minecraft:redstone_wire replace
fill ~111 ~127 ~510 ~111 ~127 ~522 minecraft:redstone_wire replace
fill ~93 ~127 ~512 ~93 ~127 ~516 minecraft:redstone_wire replace
setblock ~93 ~127 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~127 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~127 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~127 ~520 ~93 ~127 ~532 minecraft:redstone_wire replace
fill ~102 ~127 ~520 ~102 ~127 ~532 minecraft:redstone_wire replace
fill ~108 ~127 ~520 ~108 ~127 ~532 minecraft:redstone_wire replace
setblock ~96 ~127 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~127 ~524 ~96 ~127 ~536 minecraft:redstone_wire replace
setblock ~99 ~127 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~127 ~524 ~120 ~127 ~536 minecraft:redstone_wire replace
fill ~99 ~127 ~526 ~99 ~127 ~538 minecraft:redstone_wire replace
fill ~105 ~127 ~526 ~105 ~127 ~538 minecraft:redstone_wire replace
fill ~111 ~127 ~526 ~111 ~127 ~538 minecraft:redstone_wire replace
fill ~126 ~127 ~532 ~126 ~127 ~538 minecraft:redstone_wire replace
setblock ~93 ~127 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~127 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~127 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~127 ~536 ~93 ~127 ~548 minecraft:redstone_wire replace
fill ~102 ~127 ~536 ~102 ~127 ~548 minecraft:redstone_wire replace
fill ~108 ~127 ~536 ~108 ~127 ~548 minecraft:redstone_wire replace
fill ~114 ~127 ~536 ~114 ~127 ~538 minecraft:redstone_wire replace
setblock ~96 ~127 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~127 ~540 ~96 ~127 ~552 minecraft:redstone_wire replace
fill ~99 ~127 ~540 ~99 ~127 ~552 minecraft:redstone_wire replace
fill ~105 ~127 ~540 ~105 ~127 ~552 minecraft:redstone_wire replace
fill ~111 ~127 ~540 ~111 ~127 ~552 minecraft:redstone_wire replace
fill ~114 ~127 ~540 ~114 ~127 ~552 minecraft:redstone_wire replace
fill ~120 ~127 ~540 ~120 ~127 ~552 minecraft:redstone_wire replace
fill ~126 ~127 ~540 ~126 ~127 ~552 minecraft:redstone_wire replace
fill ~123 ~127 ~544 ~123 ~127 ~548 minecraft:redstone_wire replace
setblock ~159 ~127 ~548 minecraft:redstone_wire replace
setblock ~159 ~127 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~127 ~552 ~159 ~127 ~564 minecraft:redstone_wire replace
setblock ~96 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~127 ~554 ~147 ~127 ~564 minecraft:redstone_wire replace
fill ~96 ~127 ~556 ~96 ~127 ~568 minecraft:redstone_wire replace
fill ~99 ~127 ~556 ~99 ~127 ~568 minecraft:redstone_wire replace
fill ~105 ~127 ~556 ~105 ~127 ~568 minecraft:redstone_wire replace
fill ~111 ~127 ~556 ~111 ~127 ~568 minecraft:redstone_wire replace
fill ~114 ~127 ~556 ~114 ~127 ~568 minecraft:redstone_wire replace
fill ~120 ~127 ~556 ~120 ~127 ~568 minecraft:redstone_wire replace
fill ~126 ~127 ~556 ~126 ~127 ~568 minecraft:redstone_wire replace
setblock ~144 ~127 ~556 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~127 ~558 ~144 ~127 ~564 minecraft:redstone_wire replace
fill ~141 ~127 ~560 ~141 ~127 ~564 minecraft:redstone_wire replace
setblock ~138 ~127 ~564 minecraft:redstone_wire replace
setblock ~138 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~568 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~127 ~568 ~138 ~127 ~580 minecraft:redstone_wire replace
fill ~141 ~127 ~568 ~141 ~127 ~580 minecraft:redstone_wire replace
fill ~144 ~127 ~568 ~144 ~127 ~580 minecraft:redstone_wire replace
fill ~147 ~127 ~568 ~147 ~127 ~580 minecraft:redstone_wire replace
fill ~159 ~127 ~568 ~159 ~127 ~580 minecraft:redstone_wire replace
fill ~135 ~127 ~570 ~135 ~127 ~580 minecraft:redstone_wire replace
setblock ~132 ~127 ~572 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~127 ~574 ~132 ~127 ~580 minecraft:redstone_wire replace
fill ~129 ~127 ~576 ~129 ~127 ~580 minecraft:redstone_wire replace
setblock ~129 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~127 ~584 ~129 ~127 ~596 minecraft:redstone_wire replace
fill ~132 ~127 ~584 ~132 ~127 ~596 minecraft:redstone_wire replace
fill ~135 ~127 ~584 ~135 ~127 ~596 minecraft:redstone_wire replace
fill ~138 ~127 ~584 ~138 ~127 ~596 minecraft:redstone_wire replace
fill ~141 ~127 ~584 ~141 ~127 ~596 minecraft:redstone_wire replace
fill ~144 ~127 ~584 ~144 ~127 ~596 minecraft:redstone_wire replace
fill ~147 ~127 ~584 ~147 ~127 ~596 minecraft:redstone_wire replace
fill ~159 ~127 ~584 ~159 ~127 ~596 minecraft:redstone_wire replace
setblock ~129 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~127 ~600 ~129 ~127 ~612 minecraft:redstone_wire replace
fill ~132 ~127 ~600 ~132 ~127 ~612 minecraft:redstone_wire replace
fill ~135 ~127 ~600 ~135 ~127 ~612 minecraft:redstone_wire replace
fill ~138 ~127 ~600 ~138 ~127 ~612 minecraft:redstone_wire replace
fill ~141 ~127 ~600 ~141 ~127 ~612 minecraft:redstone_wire replace
fill ~144 ~127 ~600 ~144 ~127 ~612 minecraft:redstone_wire replace
fill ~147 ~127 ~600 ~147 ~127 ~612 minecraft:redstone_wire replace
fill ~159 ~127 ~600 ~159 ~127 ~612 minecraft:redstone_wire replace
setblock ~162 ~127 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~127 ~602 ~162 ~127 ~612 minecraft:redstone_wire replace
setblock ~150 ~127 ~604 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~127 ~606 ~150 ~127 ~612 minecraft:redstone_wire replace
fill ~156 ~127 ~608 ~156 ~127 ~612 minecraft:redstone_wire replace
setblock ~132 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~127 ~616 ~132 ~127 ~628 minecraft:redstone_wire replace
fill ~135 ~127 ~616 ~135 ~127 ~628 minecraft:redstone_wire replace
fill ~141 ~127 ~616 ~141 ~127 ~628 minecraft:redstone_wire replace
fill ~147 ~127 ~616 ~147 ~127 ~628 minecraft:redstone_wire replace
fill ~150 ~127 ~616 ~150 ~127 ~628 minecraft:redstone_wire replace
fill ~159 ~127 ~616 ~159 ~127 ~628 minecraft:redstone_wire replace
fill ~162 ~127 ~616 ~162 ~127 ~628 minecraft:redstone_wire replace
fill ~153 ~127 ~620 ~153 ~127 ~624 minecraft:redstone_wire replace
fill ~171 ~127 ~644 ~171 ~127 ~648 minecraft:redstone_wire replace
fill ~84 ~127 ~648 ~84 ~127 ~652 minecraft:redstone_wire replace
fill ~165 ~127 ~652 ~165 ~127 ~656 minecraft:redstone_wire replace
