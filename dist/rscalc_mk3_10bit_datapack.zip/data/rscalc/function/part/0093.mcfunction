setblock ~130 ~150 ~476 minecraft:redstone_wire replace
setblock ~133 ~150 ~476 minecraft:redstone_wire replace
setblock ~136 ~150 ~476 minecraft:redstone_wire replace
setblock ~139 ~150 ~476 minecraft:redstone_wire replace
setblock ~142 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~150 ~476 minecraft:redstone_wire replace
setblock ~157 ~150 ~476 minecraft:redstone_wire replace
setblock ~160 ~150 ~476 minecraft:redstone_wire replace
setblock ~163 ~150 ~476 minecraft:redstone_wire replace
setblock ~166 ~150 ~476 minecraft:redstone_wire replace
setblock ~169 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~150 ~476 minecraft:redstone_wire replace
setblock ~178 ~150 ~476 minecraft:redstone_wire replace
setblock ~181 ~150 ~476 minecraft:redstone_wire replace
setblock ~184 ~150 ~476 minecraft:redstone_wire replace
setblock ~187 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~150 ~476 minecraft:redstone_wire replace
setblock ~193 ~150 ~476 minecraft:redstone_wire replace
setblock ~196 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~150 ~476 minecraft:redstone_wire replace
setblock ~208 ~150 ~476 minecraft:redstone_wire replace
setblock ~211 ~150 ~476 minecraft:redstone_wire replace
setblock ~214 ~150 ~476 minecraft:redstone_wire replace
setblock ~217 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~150 ~476 minecraft:redstone_wire replace
setblock ~229 ~150 ~476 minecraft:redstone_wire replace
setblock ~235 ~150 ~484 minecraft:redstone_wire replace
setblock ~247 ~150 ~484 minecraft:redstone_wire replace
setblock ~241 ~150 ~504 minecraft:redstone_wire replace
setblock ~247 ~150 ~504 minecraft:redstone_wire replace
setblock ~238 ~150 ~516 minecraft:redstone_wire replace
setblock ~247 ~150 ~516 minecraft:redstone_wire replace
setblock ~244 ~150 ~540 minecraft:redstone_wire replace
setblock ~247 ~150 ~540 minecraft:redstone_wire replace
setblock ~247 ~150 ~548 minecraft:redstone_wire replace
setblock ~250 ~150 ~548 minecraft:redstone_wire replace
setblock ~256 ~150 ~548 minecraft:redstone_wire replace
setblock ~247 ~150 ~572 minecraft:redstone_wire replace
setblock ~256 ~150 ~572 minecraft:redstone_wire replace
setblock ~259 ~150 ~572 minecraft:redstone_wire replace
setblock ~247 ~150 ~580 minecraft:redstone_wire replace
setblock ~253 ~150 ~580 minecraft:redstone_wire replace
setblock ~256 ~150 ~580 minecraft:redstone_wire replace
setblock ~247 ~150 ~608 minecraft:redstone_wire replace
setblock ~256 ~150 ~608 minecraft:redstone_wire replace
setblock ~265 ~150 ~608 minecraft:redstone_wire replace
setblock ~268 ~150 ~608 minecraft:redstone_wire replace
setblock ~247 ~150 ~612 minecraft:redstone_wire replace
setblock ~256 ~150 ~612 minecraft:redstone_wire replace
setblock ~262 ~150 ~612 minecraft:redstone_wire replace
setblock ~277 ~150 ~648 minecraft:redstone_wire replace
setblock ~85 ~150 ~652 minecraft:redstone_wire replace
setblock ~88 ~150 ~652 minecraft:redstone_wire replace
setblock ~91 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~150 ~652 minecraft:redstone_wire replace
setblock ~100 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~150 ~652 minecraft:redstone_wire replace
setblock ~106 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~150 ~652 minecraft:redstone_wire replace
setblock ~112 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~150 ~652 minecraft:redstone_wire replace
setblock ~118 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~150 ~652 minecraft:redstone_wire replace
setblock ~124 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~150 ~652 minecraft:redstone_wire replace
setblock ~130 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~150 ~652 minecraft:redstone_wire replace
setblock ~136 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~150 ~652 minecraft:redstone_wire replace
setblock ~145 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~150 ~652 minecraft:redstone_wire replace
setblock ~151 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~150 ~652 minecraft:redstone_wire replace
setblock ~157 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~150 ~652 minecraft:redstone_wire replace
setblock ~163 ~150 ~652 minecraft:redstone_wire replace
setblock ~166 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~150 ~652 minecraft:redstone_wire replace
setblock ~175 ~150 ~652 minecraft:redstone_wire replace
setblock ~178 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~150 ~652 minecraft:redstone_wire replace
setblock ~184 ~150 ~652 minecraft:redstone_wire replace
setblock ~187 ~150 ~652 minecraft:redstone_wire replace
setblock ~190 ~150 ~652 minecraft:redstone_wire replace
setblock ~193 ~150 ~652 minecraft:redstone_wire replace
setblock ~196 ~150 ~652 minecraft:redstone_wire replace
setblock ~199 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~150 ~652 minecraft:redstone_wire replace
setblock ~205 ~150 ~652 minecraft:redstone_wire replace
setblock ~208 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~150 ~652 minecraft:redstone_wire replace
setblock ~214 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~150 ~652 minecraft:redstone_wire replace
setblock ~220 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~150 ~652 minecraft:redstone_wire replace
setblock ~226 ~150 ~652 minecraft:redstone_wire replace
setblock ~229 ~150 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~150 ~656 minecraft:redstone_wire replace
setblock ~274 ~150 ~664 minecraft:redstone_wire replace
setblock ~231 ~151 ~232 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~151 ~234 ~231 ~151 ~244 minecraft:redstone_wire replace
fill ~81 ~151 ~236 ~81 ~151 ~240 minecraft:redstone_wire replace
setblock ~228 ~151 ~240 minecraft:redstone_wire replace
setblock ~228 ~151 ~241 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~242 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~151 ~242 ~228 ~151 ~254 minecraft:redstone_wire replace
fill ~81 ~151 ~244 ~81 ~151 ~256 minecraft:redstone_wire replace
setblock ~225 ~151 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~225 ~151 ~246 ~225 ~151 ~254 minecraft:redstone_wire replace
setblock ~231 ~151 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~222 ~151 ~248 ~222 ~151 ~254 minecraft:redstone_wire replace
fill ~231 ~151 ~248 ~231 ~151 ~260 minecraft:redstone_wire replace
fill ~219 ~151 ~252 ~219 ~151 ~254 minecraft:redstone_wire replace
setblock ~216 ~151 ~256 minecraft:redstone_wire replace
setblock ~219 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~151 ~258 ~216 ~151 ~270 minecraft:redstone_wire replace
fill ~219 ~151 ~258 ~219 ~151 ~270 minecraft:redstone_wire replace
fill ~222 ~151 ~258 ~222 ~151 ~270 minecraft:redstone_wire replace
fill ~225 ~151 ~258 ~225 ~151 ~270 minecraft:redstone_wire replace
fill ~228 ~151 ~258 ~228 ~151 ~270 minecraft:redstone_wire replace
fill ~81 ~151 ~260 ~81 ~151 ~272 minecraft:redstone_wire replace
setblock ~213 ~151 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~213 ~151 ~262 ~213 ~151 ~270 minecraft:redstone_wire replace
setblock ~231 ~151 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~151 ~264 ~210 ~151 ~270 minecraft:redstone_wire replace
fill ~231 ~151 ~264 ~231 ~151 ~276 minecraft:redstone_wire replace
fill ~207 ~151 ~268 ~207 ~151 ~270 minecraft:redstone_wire replace
setblock ~204 ~151 ~272 minecraft:redstone_wire replace
setblock ~207 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~274 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~151 ~274 ~204 ~151 ~286 minecraft:redstone_wire replace
fill ~207 ~151 ~274 ~207 ~151 ~286 minecraft:redstone_wire replace
fill ~210 ~151 ~274 ~210 ~151 ~286 minecraft:redstone_wire replace
fill ~213 ~151 ~274 ~213 ~151 ~286 minecraft:redstone_wire replace
fill ~216 ~151 ~274 ~216 ~151 ~286 minecraft:redstone_wire replace
fill ~219 ~151 ~274 ~219 ~151 ~286 minecraft:redstone_wire replace
fill ~222 ~151 ~274 ~222 ~151 ~286 minecraft:redstone_wire replace
fill ~225 ~151 ~274 ~225 ~151 ~286 minecraft:redstone_wire replace
fill ~228 ~151 ~274 ~228 ~151 ~286 minecraft:redstone_wire replace
fill ~81 ~151 ~276 ~81 ~151 ~288 minecraft:redstone_wire replace
setblock ~201 ~151 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~151 ~278 ~201 ~151 ~286 minecraft:redstone_wire replace
setblock ~231 ~151 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~151 ~280 ~198 ~151 ~286 minecraft:redstone_wire replace
fill ~231 ~151 ~280 ~231 ~151 ~292 minecraft:redstone_wire replace
fill ~195 ~151 ~284 ~195 ~151 ~286 minecraft:redstone_wire replace
setblock ~192 ~151 ~288 minecraft:redstone_wire replace
setblock ~195 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~289 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~290 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~151 ~290 ~192 ~151 ~302 minecraft:redstone_wire replace
fill ~195 ~151 ~290 ~195 ~151 ~302 minecraft:redstone_wire replace
fill ~198 ~151 ~290 ~198 ~151 ~302 minecraft:redstone_wire replace
fill ~201 ~151 ~290 ~201 ~151 ~302 minecraft:redstone_wire replace
fill ~204 ~151 ~290 ~204 ~151 ~302 minecraft:redstone_wire replace
fill ~207 ~151 ~290 ~207 ~151 ~302 minecraft:redstone_wire replace
fill ~210 ~151 ~290 ~210 ~151 ~302 minecraft:redstone_wire replace
fill ~213 ~151 ~290 ~213 ~151 ~302 minecraft:redstone_wire replace
fill ~216 ~151 ~290 ~216 ~151 ~302 minecraft:redstone_wire replace
fill ~219 ~151 ~290 ~219 ~151 ~302 minecraft:redstone_wire replace
fill ~222 ~151 ~290 ~222 ~151 ~302 minecraft:redstone_wire replace
fill ~225 ~151 ~290 ~225 ~151 ~302 minecraft:redstone_wire replace
fill ~228 ~151 ~290 ~228 ~151 ~302 minecraft:redstone_wire replace
fill ~81 ~151 ~292 ~81 ~151 ~304 minecraft:redstone_wire replace
setblock ~189 ~151 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~151 ~294 ~189 ~151 ~302 minecraft:redstone_wire replace
setblock ~231 ~151 ~294 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~151 ~296 ~186 ~151 ~302 minecraft:redstone_wire replace
fill ~231 ~151 ~296 ~231 ~151 ~308 minecraft:redstone_wire replace
fill ~183 ~151 ~300 ~183 ~151 ~302 minecraft:redstone_wire replace
setblock ~180 ~151 ~304 minecraft:redstone_wire replace
setblock ~183 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~305 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~306 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~151 ~306 ~180 ~151 ~318 minecraft:redstone_wire replace
fill ~183 ~151 ~306 ~183 ~151 ~318 minecraft:redstone_wire replace
fill ~186 ~151 ~306 ~186 ~151 ~318 minecraft:redstone_wire replace
fill ~189 ~151 ~306 ~189 ~151 ~318 minecraft:redstone_wire replace
fill ~192 ~151 ~306 ~192 ~151 ~318 minecraft:redstone_wire replace
fill ~195 ~151 ~306 ~195 ~151 ~318 minecraft:redstone_wire replace
fill ~198 ~151 ~306 ~198 ~151 ~318 minecraft:redstone_wire replace
fill ~201 ~151 ~306 ~201 ~151 ~318 minecraft:redstone_wire replace
fill ~204 ~151 ~306 ~204 ~151 ~318 minecraft:redstone_wire replace
fill ~207 ~151 ~306 ~207 ~151 ~318 minecraft:redstone_wire replace
fill ~210 ~151 ~306 ~210 ~151 ~318 minecraft:redstone_wire replace
fill ~213 ~151 ~306 ~213 ~151 ~318 minecraft:redstone_wire replace
fill ~216 ~151 ~306 ~216 ~151 ~318 minecraft:redstone_wire replace
fill ~219 ~151 ~306 ~219 ~151 ~318 minecraft:redstone_wire replace
fill ~222 ~151 ~306 ~222 ~151 ~318 minecraft:redstone_wire replace
fill ~225 ~151 ~306 ~225 ~151 ~318 minecraft:redstone_wire replace
fill ~228 ~151 ~306 ~228 ~151 ~318 minecraft:redstone_wire replace
fill ~81 ~151 ~308 ~81 ~151 ~320 minecraft:redstone_wire replace
setblock ~177 ~151 ~308 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~151 ~310 ~177 ~151 ~318 minecraft:redstone_wire replace
setblock ~231 ~151 ~310 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~151 ~312 ~174 ~151 ~318 minecraft:redstone_wire replace
fill ~231 ~151 ~312 ~231 ~151 ~324 minecraft:redstone_wire replace
fill ~171 ~151 ~316 ~171 ~151 ~318 minecraft:redstone_wire replace
setblock ~168 ~151 ~320 minecraft:redstone_wire replace
setblock ~171 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~321 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~322 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~168 ~151 ~322 ~168 ~151 ~334 minecraft:redstone_wire replace
fill ~171 ~151 ~322 ~171 ~151 ~334 minecraft:redstone_wire replace
fill ~174 ~151 ~322 ~174 ~151 ~334 minecraft:redstone_wire replace
fill ~177 ~151 ~322 ~177 ~151 ~334 minecraft:redstone_wire replace
fill ~180 ~151 ~322 ~180 ~151 ~334 minecraft:redstone_wire replace
fill ~183 ~151 ~322 ~183 ~151 ~334 minecraft:redstone_wire replace
fill ~186 ~151 ~322 ~186 ~151 ~334 minecraft:redstone_wire replace
fill ~189 ~151 ~322 ~189 ~151 ~334 minecraft:redstone_wire replace
fill ~192 ~151 ~322 ~192 ~151 ~334 minecraft:redstone_wire replace
fill ~195 ~151 ~322 ~195 ~151 ~334 minecraft:redstone_wire replace
fill ~198 ~151 ~322 ~198 ~151 ~334 minecraft:redstone_wire replace
fill ~201 ~151 ~322 ~201 ~151 ~334 minecraft:redstone_wire replace
fill ~204 ~151 ~322 ~204 ~151 ~334 minecraft:redstone_wire replace
fill ~207 ~151 ~322 ~207 ~151 ~334 minecraft:redstone_wire replace
fill ~210 ~151 ~322 ~210 ~151 ~334 minecraft:redstone_wire replace
fill ~213 ~151 ~322 ~213 ~151 ~334 minecraft:redstone_wire replace
fill ~216 ~151 ~322 ~216 ~151 ~334 minecraft:redstone_wire replace
fill ~219 ~151 ~322 ~219 ~151 ~334 minecraft:redstone_wire replace
fill ~222 ~151 ~322 ~222 ~151 ~334 minecraft:redstone_wire replace
fill ~225 ~151 ~322 ~225 ~151 ~334 minecraft:redstone_wire replace
fill ~228 ~151 ~322 ~228 ~151 ~334 minecraft:redstone_wire replace
fill ~81 ~151 ~324 ~81 ~151 ~336 minecraft:redstone_wire replace
setblock ~165 ~151 ~324 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~151 ~326 ~165 ~151 ~334 minecraft:redstone_wire replace
setblock ~231 ~151 ~326 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~151 ~328 ~162 ~151 ~334 minecraft:redstone_wire replace
fill ~231 ~151 ~328 ~231 ~151 ~340 minecraft:redstone_wire replace
fill ~159 ~151 ~332 ~159 ~151 ~334 minecraft:redstone_wire replace
setblock ~156 ~151 ~336 minecraft:redstone_wire replace
setblock ~159 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~337 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~338 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~151 ~338 ~156 ~151 ~350 minecraft:redstone_wire replace
fill ~159 ~151 ~338 ~159 ~151 ~350 minecraft:redstone_wire replace
fill ~162 ~151 ~338 ~162 ~151 ~350 minecraft:redstone_wire replace
fill ~165 ~151 ~338 ~165 ~151 ~350 minecraft:redstone_wire replace
fill ~168 ~151 ~338 ~168 ~151 ~350 minecraft:redstone_wire replace
fill ~171 ~151 ~338 ~171 ~151 ~350 minecraft:redstone_wire replace
fill ~174 ~151 ~338 ~174 ~151 ~350 minecraft:redstone_wire replace
fill ~177 ~151 ~338 ~177 ~151 ~350 minecraft:redstone_wire replace
fill ~180 ~151 ~338 ~180 ~151 ~350 minecraft:redstone_wire replace
fill ~183 ~151 ~338 ~183 ~151 ~350 minecraft:redstone_wire replace
fill ~186 ~151 ~338 ~186 ~151 ~350 minecraft:redstone_wire replace
fill ~189 ~151 ~338 ~189 ~151 ~350 minecraft:redstone_wire replace
fill ~192 ~151 ~338 ~192 ~151 ~350 minecraft:redstone_wire replace
fill ~195 ~151 ~338 ~195 ~151 ~350 minecraft:redstone_wire replace
fill ~198 ~151 ~338 ~198 ~151 ~350 minecraft:redstone_wire replace
fill ~201 ~151 ~338 ~201 ~151 ~350 minecraft:redstone_wire replace
fill ~204 ~151 ~338 ~204 ~151 ~350 minecraft:redstone_wire replace
fill ~207 ~151 ~338 ~207 ~151 ~350 minecraft:redstone_wire replace
fill ~210 ~151 ~338 ~210 ~151 ~350 minecraft:redstone_wire replace
fill ~213 ~151 ~338 ~213 ~151 ~350 minecraft:redstone_wire replace
fill ~216 ~151 ~338 ~216 ~151 ~350 minecraft:redstone_wire replace
fill ~219 ~151 ~338 ~219 ~151 ~350 minecraft:redstone_wire replace
fill ~222 ~151 ~338 ~222 ~151 ~350 minecraft:redstone_wire replace
fill ~225 ~151 ~338 ~225 ~151 ~350 minecraft:redstone_wire replace
fill ~228 ~151 ~338 ~228 ~151 ~350 minecraft:redstone_wire replace
fill ~81 ~151 ~340 ~81 ~151 ~352 minecraft:redstone_wire replace
setblock ~153 ~151 ~340 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~151 ~342 ~153 ~151 ~350 minecraft:redstone_wire replace
setblock ~231 ~151 ~342 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~151 ~344 ~150 ~151 ~350 minecraft:redstone_wire replace
fill ~231 ~151 ~344 ~231 ~151 ~356 minecraft:redstone_wire replace
fill ~147 ~151 ~348 ~147 ~151 ~350 minecraft:redstone_wire replace
setblock ~144 ~151 ~352 minecraft:redstone_wire replace
setblock ~147 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~352 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~353 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~354 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~151 ~354 ~144 ~151 ~366 minecraft:redstone_wire replace
fill ~147 ~151 ~354 ~147 ~151 ~366 minecraft:redstone_wire replace
fill ~150 ~151 ~354 ~150 ~151 ~366 minecraft:redstone_wire replace
fill ~153 ~151 ~354 ~153 ~151 ~366 minecraft:redstone_wire replace
fill ~156 ~151 ~354 ~156 ~151 ~366 minecraft:redstone_wire replace
fill ~159 ~151 ~354 ~159 ~151 ~366 minecraft:redstone_wire replace
fill ~162 ~151 ~354 ~162 ~151 ~366 minecraft:redstone_wire replace
fill ~165 ~151 ~354 ~165 ~151 ~366 minecraft:redstone_wire replace
fill ~168 ~151 ~354 ~168 ~151 ~366 minecraft:redstone_wire replace
fill ~171 ~151 ~354 ~171 ~151 ~366 minecraft:redstone_wire replace
fill ~174 ~151 ~354 ~174 ~151 ~366 minecraft:redstone_wire replace
fill ~177 ~151 ~354 ~177 ~151 ~366 minecraft:redstone_wire replace
fill ~180 ~151 ~354 ~180 ~151 ~366 minecraft:redstone_wire replace
fill ~183 ~151 ~354 ~183 ~151 ~366 minecraft:redstone_wire replace
fill ~186 ~151 ~354 ~186 ~151 ~366 minecraft:redstone_wire replace
fill ~189 ~151 ~354 ~189 ~151 ~366 minecraft:redstone_wire replace
fill ~192 ~151 ~354 ~192 ~151 ~366 minecraft:redstone_wire replace
fill ~195 ~151 ~354 ~195 ~151 ~366 minecraft:redstone_wire replace
fill ~198 ~151 ~354 ~198 ~151 ~366 minecraft:redstone_wire replace
fill ~201 ~151 ~354 ~201 ~151 ~366 minecraft:redstone_wire replace
fill ~204 ~151 ~354 ~204 ~151 ~366 minecraft:redstone_wire replace
fill ~207 ~151 ~354 ~207 ~151 ~366 minecraft:redstone_wire replace
fill ~210 ~151 ~354 ~210 ~151 ~366 minecraft:redstone_wire replace
fill ~213 ~151 ~354 ~213 ~151 ~366 minecraft:redstone_wire replace
fill ~216 ~151 ~354 ~216 ~151 ~366 minecraft:redstone_wire replace
fill ~219 ~151 ~354 ~219 ~151 ~366 minecraft:redstone_wire replace
fill ~222 ~151 ~354 ~222 ~151 ~366 minecraft:redstone_wire replace
fill ~225 ~151 ~354 ~225 ~151 ~366 minecraft:redstone_wire replace
fill ~228 ~151 ~354 ~228 ~151 ~366 minecraft:redstone_wire replace
fill ~81 ~151 ~356 ~81 ~151 ~368 minecraft:redstone_wire replace
setblock ~141 ~151 ~356 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~151 ~358 ~141 ~151 ~366 minecraft:redstone_wire replace
setblock ~231 ~151 ~358 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~151 ~360 ~138 ~151 ~366 minecraft:redstone_wire replace
fill ~231 ~151 ~360 ~231 ~151 ~372 minecraft:redstone_wire replace
fill ~135 ~151 ~364 ~135 ~151 ~366 minecraft:redstone_wire replace
setblock ~132 ~151 ~368 minecraft:redstone_wire replace
setblock ~135 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~369 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~370 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~151 ~370 ~132 ~151 ~382 minecraft:redstone_wire replace
fill ~135 ~151 ~370 ~135 ~151 ~382 minecraft:redstone_wire replace
fill ~138 ~151 ~370 ~138 ~151 ~382 minecraft:redstone_wire replace
fill ~141 ~151 ~370 ~141 ~151 ~382 minecraft:redstone_wire replace
fill ~144 ~151 ~370 ~144 ~151 ~382 minecraft:redstone_wire replace
fill ~147 ~151 ~370 ~147 ~151 ~382 minecraft:redstone_wire replace
fill ~150 ~151 ~370 ~150 ~151 ~382 minecraft:redstone_wire replace
fill ~153 ~151 ~370 ~153 ~151 ~382 minecraft:redstone_wire replace
fill ~156 ~151 ~370 ~156 ~151 ~382 minecraft:redstone_wire replace
fill ~159 ~151 ~370 ~159 ~151 ~382 minecraft:redstone_wire replace
fill ~162 ~151 ~370 ~162 ~151 ~382 minecraft:redstone_wire replace
fill ~165 ~151 ~370 ~165 ~151 ~382 minecraft:redstone_wire replace
fill ~168 ~151 ~370 ~168 ~151 ~382 minecraft:redstone_wire replace
fill ~171 ~151 ~370 ~171 ~151 ~382 minecraft:redstone_wire replace
fill ~174 ~151 ~370 ~174 ~151 ~382 minecraft:redstone_wire replace
fill ~177 ~151 ~370 ~177 ~151 ~382 minecraft:redstone_wire replace
fill ~180 ~151 ~370 ~180 ~151 ~382 minecraft:redstone_wire replace
fill ~183 ~151 ~370 ~183 ~151 ~382 minecraft:redstone_wire replace
fill ~186 ~151 ~370 ~186 ~151 ~382 minecraft:redstone_wire replace
fill ~189 ~151 ~370 ~189 ~151 ~382 minecraft:redstone_wire replace
fill ~192 ~151 ~370 ~192 ~151 ~382 minecraft:redstone_wire replace
fill ~195 ~151 ~370 ~195 ~151 ~382 minecraft:redstone_wire replace
fill ~198 ~151 ~370 ~198 ~151 ~382 minecraft:redstone_wire replace
fill ~201 ~151 ~370 ~201 ~151 ~382 minecraft:redstone_wire replace
fill ~204 ~151 ~370 ~204 ~151 ~382 minecraft:redstone_wire replace
fill ~207 ~151 ~370 ~207 ~151 ~382 minecraft:redstone_wire replace
fill ~210 ~151 ~370 ~210 ~151 ~382 minecraft:redstone_wire replace
fill ~213 ~151 ~370 ~213 ~151 ~382 minecraft:redstone_wire replace
fill ~216 ~151 ~370 ~216 ~151 ~382 minecraft:redstone_wire replace
fill ~219 ~151 ~370 ~219 ~151 ~382 minecraft:redstone_wire replace
fill ~222 ~151 ~370 ~222 ~151 ~382 minecraft:redstone_wire replace
fill ~225 ~151 ~370 ~225 ~151 ~382 minecraft:redstone_wire replace
fill ~228 ~151 ~370 ~228 ~151 ~382 minecraft:redstone_wire replace
fill ~81 ~151 ~372 ~81 ~151 ~384 minecraft:redstone_wire replace
setblock ~129 ~151 ~372 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~151 ~374 ~129 ~151 ~382 minecraft:redstone_wire replace
setblock ~231 ~151 ~374 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~151 ~376 ~126 ~151 ~382 minecraft:redstone_wire replace
fill ~231 ~151 ~376 ~231 ~151 ~388 minecraft:redstone_wire replace
fill ~123 ~151 ~380 ~123 ~151 ~382 minecraft:redstone_wire replace
setblock ~120 ~151 ~384 minecraft:redstone_wire replace
setblock ~123 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~81 ~151 ~386 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~151 ~386 ~120 ~151 ~398 minecraft:redstone_wire replace
fill ~123 ~151 ~386 ~123 ~151 ~398 minecraft:redstone_wire replace
fill ~126 ~151 ~386 ~126 ~151 ~398 minecraft:redstone_wire replace
fill ~129 ~151 ~386 ~129 ~151 ~398 minecraft:redstone_wire replace
fill ~132 ~151 ~386 ~132 ~151 ~398 minecraft:redstone_wire replace
fill ~135 ~151 ~386 ~135 ~151 ~398 minecraft:redstone_wire replace
fill ~138 ~151 ~386 ~138 ~151 ~398 minecraft:redstone_wire replace
fill ~141 ~151 ~386 ~141 ~151 ~398 minecraft:redstone_wire replace
fill ~144 ~151 ~386 ~144 ~151 ~398 minecraft:redstone_wire replace
fill ~147 ~151 ~386 ~147 ~151 ~398 minecraft:redstone_wire replace
fill ~150 ~151 ~386 ~150 ~151 ~398 minecraft:redstone_wire replace
fill ~153 ~151 ~386 ~153 ~151 ~398 minecraft:redstone_wire replace
fill ~156 ~151 ~386 ~156 ~151 ~398 minecraft:redstone_wire replace
fill ~159 ~151 ~386 ~159 ~151 ~398 minecraft:redstone_wire replace
fill ~162 ~151 ~386 ~162 ~151 ~398 minecraft:redstone_wire replace
fill ~165 ~151 ~386 ~165 ~151 ~398 minecraft:redstone_wire replace
fill ~168 ~151 ~386 ~168 ~151 ~398 minecraft:redstone_wire replace
fill ~171 ~151 ~386 ~171 ~151 ~398 minecraft:redstone_wire replace
fill ~174 ~151 ~386 ~174 ~151 ~398 minecraft:redstone_wire replace
fill ~177 ~151 ~386 ~177 ~151 ~398 minecraft:redstone_wire replace
fill ~180 ~151 ~386 ~180 ~151 ~398 minecraft:redstone_wire replace
fill ~183 ~151 ~386 ~183 ~151 ~398 minecraft:redstone_wire replace
fill ~186 ~151 ~386 ~186 ~151 ~398 minecraft:redstone_wire replace
fill ~189 ~151 ~386 ~189 ~151 ~398 minecraft:redstone_wire replace
fill ~192 ~151 ~386 ~192 ~151 ~398 minecraft:redstone_wire replace
fill ~195 ~151 ~386 ~195 ~151 ~398 minecraft:redstone_wire replace
fill ~198 ~151 ~386 ~198 ~151 ~398 minecraft:redstone_wire replace
fill ~201 ~151 ~386 ~201 ~151 ~398 minecraft:redstone_wire replace
fill ~204 ~151 ~386 ~204 ~151 ~398 minecraft:redstone_wire replace
fill ~207 ~151 ~386 ~207 ~151 ~398 minecraft:redstone_wire replace
fill ~210 ~151 ~386 ~210 ~151 ~398 minecraft:redstone_wire replace
fill ~213 ~151 ~386 ~213 ~151 ~398 minecraft:redstone_wire replace
fill ~216 ~151 ~386 ~216 ~151 ~398 minecraft:redstone_wire replace
fill ~219 ~151 ~386 ~219 ~151 ~398 minecraft:redstone_wire replace
fill ~222 ~151 ~386 ~222 ~151 ~398 minecraft:redstone_wire replace
fill ~225 ~151 ~386 ~225 ~151 ~398 minecraft:redstone_wire replace
fill ~228 ~151 ~386 ~228 ~151 ~398 minecraft:redstone_wire replace
fill ~81 ~151 ~388 ~81 ~151 ~400 minecraft:redstone_wire replace
setblock ~117 ~151 ~388 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~151 ~390 ~117 ~151 ~398 minecraft:redstone_wire replace
fill ~114 ~151 ~392 ~114 ~151 ~398 minecraft:redstone_wire replace
fill ~111 ~151 ~396 ~111 ~151 ~398 minecraft:redstone_wire replace
setblock ~108 ~151 ~400 minecraft:redstone_wire replace
setblock ~111 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
