setblock ~177 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~217 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~217 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~217 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~233 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~233 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~249 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~249 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~255 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~255 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~255 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~257 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~257 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~257 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~259 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~259 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~265 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~267 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~267 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~267 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~271 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~271 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~273 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~273 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~275 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~275 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~279 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~279 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~279 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~281 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~283 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~283 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~287 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~287 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~289 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~289 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~291 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~293 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~297 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~301 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~301 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~303 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~305 minecraft:light_gray_concrete replace
fill ~78 ~20 ~10 ~80 ~20 ~10 minecraft:light_gray_concrete replace
fill ~79 ~20 ~11 ~79 ~20 ~12 minecraft:light_gray_concrete replace
fill ~102 ~20 ~14 ~108 ~20 ~14 minecraft:light_gray_concrete replace
fill ~103 ~20 ~15 ~103 ~20 ~16 minecraft:light_gray_concrete replace
fill ~90 ~20 ~18 ~93 ~20 ~18 minecraft:light_gray_concrete replace
fill ~91 ~20 ~19 ~91 ~20 ~20 minecraft:light_gray_concrete replace
fill ~108 ~20 ~22 ~114 ~20 ~22 minecraft:light_gray_concrete replace
fill ~109 ~20 ~23 ~109 ~20 ~24 minecraft:light_gray_concrete replace
fill ~105 ~20 ~26 ~111 ~20 ~26 minecraft:light_gray_concrete replace
fill ~106 ~20 ~27 ~106 ~20 ~28 minecraft:light_gray_concrete replace
fill ~123 ~20 ~30 ~132 ~20 ~30 minecraft:light_gray_concrete replace
fill ~124 ~20 ~31 ~124 ~20 ~32 minecraft:light_gray_concrete replace
fill ~126 ~20 ~34 ~135 ~20 ~34 minecraft:light_gray_concrete replace
fill ~127 ~20 ~35 ~127 ~20 ~36 minecraft:light_gray_concrete replace
fill ~144 ~20 ~38 ~153 ~20 ~38 minecraft:light_gray_concrete replace
fill ~145 ~20 ~39 ~145 ~20 ~40 minecraft:light_gray_concrete replace
fill ~150 ~20 ~42 ~159 ~20 ~42 minecraft:light_gray_concrete replace
fill ~151 ~20 ~43 ~151 ~20 ~44 minecraft:light_gray_concrete replace
fill ~168 ~20 ~46 ~174 ~20 ~46 minecraft:light_gray_concrete replace
fill ~169 ~20 ~47 ~169 ~20 ~48 minecraft:light_gray_concrete replace
fill ~174 ~20 ~50 ~183 ~20 ~50 minecraft:light_gray_concrete replace
fill ~175 ~20 ~51 ~175 ~20 ~52 minecraft:light_gray_concrete replace
fill ~198 ~20 ~54 ~204 ~20 ~54 minecraft:light_gray_concrete replace
fill ~199 ~20 ~55 ~199 ~20 ~56 minecraft:light_gray_concrete replace
fill ~207 ~20 ~58 ~210 ~20 ~58 minecraft:light_gray_concrete replace
fill ~208 ~20 ~59 ~208 ~20 ~60 minecraft:light_gray_concrete replace
fill ~231 ~20 ~62 ~237 ~20 ~62 minecraft:light_gray_concrete replace
fill ~232 ~20 ~63 ~232 ~20 ~64 minecraft:light_gray_concrete replace
fill ~240 ~20 ~66 ~249 ~20 ~66 minecraft:light_gray_concrete replace
fill ~241 ~20 ~67 ~241 ~20 ~68 minecraft:light_gray_concrete replace
fill ~255 ~20 ~70 ~264 ~20 ~70 minecraft:light_gray_concrete replace
fill ~256 ~20 ~71 ~256 ~20 ~72 minecraft:light_gray_concrete replace
fill ~225 ~20 ~74 ~231 ~20 ~74 minecraft:light_gray_concrete replace
fill ~226 ~20 ~75 ~226 ~20 ~76 minecraft:light_gray_concrete replace
fill ~261 ~20 ~78 ~270 ~20 ~78 minecraft:light_gray_concrete replace
fill ~262 ~20 ~79 ~262 ~20 ~80 minecraft:light_gray_concrete replace
fill ~249 ~20 ~82 ~258 ~20 ~82 minecraft:light_gray_concrete replace
fill ~250 ~20 ~83 ~250 ~20 ~84 minecraft:light_gray_concrete replace
fill ~273 ~20 ~86 ~285 ~20 ~86 minecraft:light_gray_concrete replace
fill ~274 ~20 ~87 ~274 ~20 ~88 minecraft:light_gray_concrete replace
fill ~81 ~20 ~90 ~83 ~20 ~90 minecraft:light_gray_concrete replace
fill ~82 ~20 ~91 ~82 ~20 ~92 minecraft:light_gray_concrete replace
fill ~84 ~20 ~94 ~86 ~20 ~94 minecraft:light_gray_concrete replace
fill ~85 ~20 ~95 ~85 ~20 ~96 minecraft:light_gray_concrete replace
fill ~87 ~20 ~98 ~89 ~20 ~98 minecraft:light_gray_concrete replace
fill ~88 ~20 ~99 ~88 ~20 ~100 minecraft:light_gray_concrete replace
fill ~87 ~20 ~102 ~90 ~20 ~102 minecraft:light_gray_concrete replace
fill ~88 ~20 ~103 ~88 ~20 ~104 minecraft:light_gray_concrete replace
fill ~120 ~20 ~106 ~129 ~20 ~106 minecraft:light_gray_concrete replace
fill ~121 ~20 ~107 ~121 ~20 ~108 minecraft:light_gray_concrete replace
fill ~93 ~20 ~110 ~96 ~20 ~110 minecraft:light_gray_concrete replace
fill ~94 ~20 ~111 ~94 ~20 ~112 minecraft:light_gray_concrete replace
fill ~96 ~20 ~114 ~99 ~20 ~114 minecraft:light_gray_concrete replace
fill ~97 ~20 ~115 ~97 ~20 ~116 minecraft:light_gray_concrete replace
fill ~99 ~20 ~118 ~102 ~20 ~118 minecraft:light_gray_concrete replace
fill ~100 ~20 ~119 ~100 ~20 ~120 minecraft:light_gray_concrete replace
fill ~99 ~20 ~122 ~105 ~20 ~122 minecraft:light_gray_concrete replace
fill ~100 ~20 ~123 ~100 ~20 ~124 minecraft:light_gray_concrete replace
fill ~132 ~20 ~126 ~141 ~20 ~126 minecraft:light_gray_concrete replace
fill ~133 ~20 ~127 ~133 ~20 ~128 minecraft:light_gray_concrete replace
fill ~111 ~20 ~130 ~117 ~20 ~130 minecraft:light_gray_concrete replace
fill ~112 ~20 ~131 ~112 ~20 ~132 minecraft:light_gray_concrete replace
fill ~114 ~20 ~134 ~120 ~20 ~134 minecraft:light_gray_concrete replace
fill ~115 ~20 ~135 ~115 ~20 ~136 minecraft:light_gray_concrete replace
fill ~117 ~20 ~138 ~123 ~20 ~138 minecraft:light_gray_concrete replace
fill ~118 ~20 ~139 ~118 ~20 ~140 minecraft:light_gray_concrete replace
fill ~117 ~20 ~142 ~126 ~20 ~142 minecraft:light_gray_concrete replace
fill ~118 ~20 ~143 ~118 ~20 ~144 minecraft:light_gray_concrete replace
fill ~147 ~20 ~146 ~156 ~20 ~146 minecraft:light_gray_concrete replace
fill ~148 ~20 ~147 ~148 ~20 ~148 minecraft:light_gray_concrete replace
fill ~129 ~20 ~150 ~138 ~20 ~150 minecraft:light_gray_concrete replace
fill ~130 ~20 ~151 ~130 ~20 ~152 minecraft:light_gray_concrete replace
fill ~138 ~20 ~154 ~144 ~20 ~154 minecraft:light_gray_concrete replace
fill ~139 ~20 ~155 ~139 ~20 ~156 minecraft:light_gray_concrete replace
fill ~141 ~20 ~158 ~147 ~20 ~158 minecraft:light_gray_concrete replace
fill ~142 ~20 ~159 ~142 ~20 ~160 minecraft:light_gray_concrete replace
fill ~141 ~20 ~162 ~150 ~20 ~162 minecraft:light_gray_concrete replace
fill ~142 ~20 ~163 ~142 ~20 ~164 minecraft:light_gray_concrete replace
fill ~180 ~20 ~166 ~189 ~20 ~166 minecraft:light_gray_concrete replace
fill ~181 ~20 ~167 ~181 ~20 ~168 minecraft:light_gray_concrete replace
fill ~153 ~20 ~170 ~162 ~20 ~170 minecraft:light_gray_concrete replace
fill ~154 ~20 ~171 ~154 ~20 ~172 minecraft:light_gray_concrete replace
fill ~156 ~20 ~174 ~165 ~20 ~174 minecraft:light_gray_concrete replace
fill ~157 ~20 ~175 ~157 ~20 ~176 minecraft:light_gray_concrete replace
fill ~159 ~20 ~178 ~168 ~20 ~178 minecraft:light_gray_concrete replace
fill ~160 ~20 ~179 ~160 ~20 ~180 minecraft:light_gray_concrete replace
fill ~159 ~20 ~182 ~171 ~20 ~182 minecraft:light_gray_concrete replace
fill ~160 ~20 ~183 ~160 ~20 ~184 minecraft:light_gray_concrete replace
fill ~201 ~20 ~186 ~207 ~20 ~186 minecraft:light_gray_concrete replace
fill ~202 ~20 ~187 ~202 ~20 ~188 minecraft:light_gray_concrete replace
fill ~189 ~20 ~190 ~192 ~20 ~190 minecraft:light_gray_concrete replace
fill ~190 ~20 ~191 ~190 ~20 ~192 minecraft:light_gray_concrete replace
fill ~192 ~20 ~194 ~195 ~20 ~194 minecraft:light_gray_concrete replace
fill ~193 ~20 ~195 ~193 ~20 ~196 minecraft:light_gray_concrete replace
fill ~195 ~20 ~198 ~198 ~20 ~198 minecraft:light_gray_concrete replace
fill ~196 ~20 ~199 ~196 ~20 ~200 minecraft:light_gray_concrete replace
fill ~195 ~20 ~202 ~201 ~20 ~202 minecraft:light_gray_concrete replace
fill ~196 ~20 ~203 ~196 ~20 ~204 minecraft:light_gray_concrete replace
fill ~216 ~20 ~206 ~219 ~20 ~206 minecraft:light_gray_concrete replace
fill ~217 ~20 ~207 ~217 ~20 ~208 minecraft:light_gray_concrete replace
fill ~210 ~20 ~210 ~213 ~20 ~210 minecraft:light_gray_concrete replace
fill ~211 ~20 ~211 ~211 ~20 ~212 minecraft:light_gray_concrete replace
fill ~213 ~20 ~214 ~216 ~20 ~214 minecraft:light_gray_concrete replace
fill ~214 ~20 ~215 ~214 ~20 ~216 minecraft:light_gray_concrete replace
fill ~219 ~20 ~218 ~222 ~20 ~218 minecraft:light_gray_concrete replace
fill ~220 ~20 ~219 ~220 ~20 ~220 minecraft:light_gray_concrete replace
fill ~219 ~20 ~222 ~225 ~20 ~222 minecraft:light_gray_concrete replace
fill ~220 ~20 ~223 ~220 ~20 ~224 minecraft:light_gray_concrete replace
fill ~243 ~20 ~226 ~252 ~20 ~226 minecraft:light_gray_concrete replace
fill ~244 ~20 ~227 ~244 ~20 ~228 minecraft:light_gray_concrete replace
fill ~246 ~20 ~230 ~255 ~20 ~230 minecraft:light_gray_concrete replace
fill ~247 ~20 ~231 ~247 ~20 ~232 minecraft:light_gray_concrete replace
fill ~258 ~20 ~234 ~267 ~20 ~234 minecraft:light_gray_concrete replace
fill ~259 ~20 ~235 ~259 ~20 ~236 minecraft:light_gray_concrete replace
fill ~267 ~20 ~238 ~276 ~20 ~238 minecraft:light_gray_concrete replace
fill ~268 ~20 ~239 ~268 ~20 ~240 minecraft:light_gray_concrete replace
fill ~270 ~20 ~242 ~279 ~20 ~242 minecraft:light_gray_concrete replace
fill ~271 ~20 ~243 ~271 ~20 ~244 minecraft:light_gray_concrete replace
fill ~270 ~20 ~246 ~282 ~20 ~246 minecraft:light_gray_concrete replace
fill ~271 ~20 ~247 ~271 ~20 ~248 minecraft:light_gray_concrete replace
fill ~228 ~20 ~250 ~234 ~20 ~250 minecraft:light_gray_concrete replace
fill ~229 ~20 ~251 ~229 ~20 ~252 minecraft:light_gray_concrete replace
fill ~234 ~20 ~254 ~240 ~20 ~254 minecraft:light_gray_concrete replace
fill ~235 ~20 ~255 ~235 ~20 ~256 minecraft:light_gray_concrete replace
fill ~237 ~20 ~258 ~243 ~20 ~258 minecraft:light_gray_concrete replace
fill ~238 ~20 ~259 ~238 ~20 ~260 minecraft:light_gray_concrete replace
fill ~237 ~20 ~262 ~246 ~20 ~262 minecraft:light_gray_concrete replace
fill ~238 ~20 ~263 ~238 ~20 ~264 minecraft:light_gray_concrete replace
fill ~252 ~20 ~266 ~261 ~20 ~266 minecraft:light_gray_concrete replace
fill ~253 ~20 ~267 ~253 ~20 ~268 minecraft:light_gray_concrete replace
fill ~264 ~20 ~270 ~273 ~20 ~270 minecraft:light_gray_concrete replace
fill ~265 ~20 ~271 ~265 ~20 ~272 minecraft:light_gray_concrete replace
fill ~276 ~20 ~274 ~288 ~20 ~274 minecraft:light_gray_concrete replace
fill ~277 ~20 ~275 ~277 ~20 ~276 minecraft:light_gray_concrete replace
fill ~279 ~20 ~278 ~291 ~20 ~278 minecraft:light_gray_concrete replace
fill ~280 ~20 ~279 ~280 ~20 ~280 minecraft:light_gray_concrete replace
fill ~282 ~20 ~282 ~294 ~20 ~282 minecraft:light_gray_concrete replace
fill ~283 ~20 ~283 ~283 ~20 ~284 minecraft:light_gray_concrete replace
fill ~282 ~20 ~286 ~297 ~20 ~286 minecraft:light_gray_concrete replace
fill ~283 ~20 ~287 ~283 ~20 ~288 minecraft:light_gray_concrete replace
fill ~135 ~20 ~290 ~206 ~20 ~290 minecraft:light_gray_concrete replace
fill ~136 ~20 ~291 ~136 ~20 ~292 minecraft:light_gray_concrete replace
fill ~163 ~20 ~291 ~163 ~20 ~292 minecraft:light_gray_concrete replace
fill ~166 ~20 ~291 ~166 ~20 ~292 minecraft:light_gray_concrete replace
fill ~172 ~20 ~291 ~172 ~20 ~292 minecraft:light_gray_concrete replace
fill ~178 ~20 ~291 ~178 ~20 ~292 minecraft:light_gray_concrete replace
fill ~184 ~20 ~291 ~184 ~20 ~292 minecraft:light_gray_concrete replace
fill ~187 ~20 ~291 ~187 ~20 ~292 minecraft:light_gray_concrete replace
fill ~205 ~20 ~291 ~205 ~20 ~292 minecraft:light_gray_concrete replace
fill ~135 ~20 ~294 ~206 ~20 ~294 minecraft:light_gray_concrete replace
fill ~136 ~20 ~295 ~136 ~20 ~296 minecraft:light_gray_concrete replace
fill ~163 ~20 ~295 ~163 ~20 ~296 minecraft:light_gray_concrete replace
fill ~166 ~20 ~295 ~166 ~20 ~296 minecraft:light_gray_concrete replace
fill ~172 ~20 ~295 ~172 ~20 ~296 minecraft:light_gray_concrete replace
fill ~178 ~20 ~295 ~178 ~20 ~296 minecraft:light_gray_concrete replace
fill ~184 ~20 ~295 ~184 ~20 ~296 minecraft:light_gray_concrete replace
fill ~187 ~20 ~295 ~187 ~20 ~296 minecraft:light_gray_concrete replace
fill ~205 ~20 ~295 ~205 ~20 ~296 minecraft:light_gray_concrete replace
fill ~162 ~20 ~298 ~206 ~20 ~298 minecraft:light_gray_concrete replace
fill ~163 ~20 ~299 ~163 ~20 ~300 minecraft:light_gray_concrete replace
fill ~166 ~20 ~299 ~166 ~20 ~300 minecraft:light_gray_concrete replace
fill ~172 ~20 ~299 ~172 ~20 ~300 minecraft:light_gray_concrete replace
fill ~178 ~20 ~299 ~178 ~20 ~300 minecraft:light_gray_concrete replace
fill ~184 ~20 ~299 ~184 ~20 ~300 minecraft:light_gray_concrete replace
fill ~187 ~20 ~299 ~187 ~20 ~300 minecraft:light_gray_concrete replace
fill ~205 ~20 ~299 ~205 ~20 ~300 minecraft:light_gray_concrete replace
fill ~285 ~20 ~302 ~300 ~20 ~302 minecraft:light_gray_concrete replace
fill ~286 ~20 ~303 ~286 ~20 ~304 minecraft:light_gray_concrete replace
fill ~222 ~20 ~306 ~228 ~20 ~306 minecraft:light_gray_concrete replace
fill ~223 ~20 ~307 ~223 ~20 ~308 minecraft:light_gray_concrete replace
setblock ~79 ~21 ~12 minecraft:light_gray_concrete replace
setblock ~103 ~21 ~16 minecraft:light_gray_concrete replace
setblock ~91 ~21 ~20 minecraft:light_gray_concrete replace
setblock ~109 ~21 ~24 minecraft:light_gray_concrete replace
setblock ~106 ~21 ~28 minecraft:light_gray_concrete replace
setblock ~124 ~21 ~32 minecraft:light_gray_concrete replace
setblock ~127 ~21 ~36 minecraft:light_gray_concrete replace
setblock ~145 ~21 ~40 minecraft:light_gray_concrete replace
setblock ~151 ~21 ~44 minecraft:light_gray_concrete replace
setblock ~169 ~21 ~48 minecraft:light_gray_concrete replace
setblock ~175 ~21 ~52 minecraft:light_gray_concrete replace
setblock ~199 ~21 ~56 minecraft:light_gray_concrete replace
setblock ~208 ~21 ~60 minecraft:light_gray_concrete replace
setblock ~232 ~21 ~64 minecraft:light_gray_concrete replace
setblock ~241 ~21 ~68 minecraft:light_gray_concrete replace
setblock ~256 ~21 ~72 minecraft:light_gray_concrete replace
setblock ~226 ~21 ~76 minecraft:light_gray_concrete replace
setblock ~262 ~21 ~80 minecraft:light_gray_concrete replace
setblock ~250 ~21 ~84 minecraft:light_gray_concrete replace
setblock ~274 ~21 ~88 minecraft:light_gray_concrete replace
setblock ~82 ~21 ~92 minecraft:light_gray_concrete replace
setblock ~85 ~21 ~96 minecraft:light_gray_concrete replace
setblock ~88 ~21 ~100 minecraft:light_gray_concrete replace
setblock ~88 ~21 ~104 minecraft:light_gray_concrete replace
setblock ~121 ~21 ~108 minecraft:light_gray_concrete replace
setblock ~94 ~21 ~112 minecraft:light_gray_concrete replace
setblock ~97 ~21 ~116 minecraft:light_gray_concrete replace
setblock ~100 ~21 ~120 minecraft:light_gray_concrete replace
setblock ~100 ~21 ~124 minecraft:light_gray_concrete replace
setblock ~133 ~21 ~128 minecraft:light_gray_concrete replace
setblock ~112 ~21 ~132 minecraft:light_gray_concrete replace
setblock ~115 ~21 ~136 minecraft:light_gray_concrete replace
setblock ~118 ~21 ~140 minecraft:light_gray_concrete replace
setblock ~118 ~21 ~144 minecraft:light_gray_concrete replace
setblock ~148 ~21 ~148 minecraft:light_gray_concrete replace
setblock ~130 ~21 ~152 minecraft:light_gray_concrete replace
setblock ~139 ~21 ~156 minecraft:light_gray_concrete replace
setblock ~142 ~21 ~160 minecraft:light_gray_concrete replace
setblock ~142 ~21 ~164 minecraft:light_gray_concrete replace
setblock ~181 ~21 ~168 minecraft:light_gray_concrete replace
setblock ~154 ~21 ~172 minecraft:light_gray_concrete replace
setblock ~157 ~21 ~176 minecraft:light_gray_concrete replace
setblock ~160 ~21 ~180 minecraft:light_gray_concrete replace
setblock ~160 ~21 ~184 minecraft:light_gray_concrete replace
setblock ~202 ~21 ~188 minecraft:light_gray_concrete replace
setblock ~190 ~21 ~192 minecraft:light_gray_concrete replace
setblock ~193 ~21 ~196 minecraft:light_gray_concrete replace
setblock ~196 ~21 ~200 minecraft:light_gray_concrete replace
setblock ~196 ~21 ~204 minecraft:light_gray_concrete replace
setblock ~217 ~21 ~208 minecraft:light_gray_concrete replace
setblock ~211 ~21 ~212 minecraft:light_gray_concrete replace
setblock ~214 ~21 ~216 minecraft:light_gray_concrete replace
setblock ~220 ~21 ~220 minecraft:light_gray_concrete replace
setblock ~220 ~21 ~224 minecraft:light_gray_concrete replace
setblock ~244 ~21 ~228 minecraft:light_gray_concrete replace
setblock ~247 ~21 ~232 minecraft:light_gray_concrete replace
setblock ~259 ~21 ~236 minecraft:light_gray_concrete replace
setblock ~268 ~21 ~240 minecraft:light_gray_concrete replace
setblock ~271 ~21 ~244 minecraft:light_gray_concrete replace
setblock ~272 ~21 ~246 minecraft:light_gray_concrete replace
setblock ~274 ~21 ~246 minecraft:light_gray_concrete replace
setblock ~271 ~21 ~248 minecraft:light_gray_concrete replace
setblock ~229 ~21 ~252 minecraft:light_gray_concrete replace
setblock ~235 ~21 ~256 minecraft:light_gray_concrete replace
setblock ~238 ~21 ~260 minecraft:light_gray_concrete replace
setblock ~238 ~21 ~264 minecraft:light_gray_concrete replace
setblock ~253 ~21 ~268 minecraft:light_gray_concrete replace
setblock ~265 ~21 ~272 minecraft:light_gray_concrete replace
setblock ~277 ~21 ~276 minecraft:light_gray_concrete replace
setblock ~280 ~21 ~280 minecraft:light_gray_concrete replace
setblock ~283 ~21 ~284 minecraft:light_gray_concrete replace
setblock ~287 ~21 ~286 minecraft:light_gray_concrete replace
setblock ~289 ~21 ~286 minecraft:light_gray_concrete replace
setblock ~283 ~21 ~288 minecraft:light_gray_concrete replace
setblock ~147 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~149 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~190 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~192 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~136 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~163 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~166 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~172 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~178 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~184 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~187 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~205 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~140 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~142 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~157 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~159 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~201 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~203 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~136 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~163 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~166 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~172 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~178 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~184 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~187 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~205 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~194 ~21 ~298 minecraft:light_gray_concrete replace
setblock ~196 ~21 ~298 minecraft:light_gray_concrete replace
setblock ~163 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~166 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~172 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~178 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~184 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~187 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~205 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~286 ~21 ~304 minecraft:light_gray_concrete replace
setblock ~223 ~21 ~308 minecraft:light_gray_concrete replace
fill ~78 ~22 ~8 ~78 ~22 ~12 minecraft:light_gray_concrete replace
fill ~102 ~22 ~12 ~102 ~22 ~16 minecraft:light_gray_concrete replace
fill ~90 ~22 ~16 ~90 ~22 ~20 minecraft:light_gray_concrete replace
fill ~108 ~22 ~20 ~108 ~22 ~24 minecraft:light_gray_concrete replace
fill ~105 ~22 ~24 ~105 ~22 ~28 minecraft:light_gray_concrete replace
fill ~123 ~22 ~28 ~123 ~22 ~32 minecraft:light_gray_concrete replace
fill ~126 ~22 ~32 ~126 ~22 ~36 minecraft:light_gray_concrete replace
fill ~144 ~22 ~36 ~144 ~22 ~40 minecraft:light_gray_concrete replace
fill ~150 ~22 ~40 ~150 ~22 ~44 minecraft:light_gray_concrete replace
fill ~168 ~22 ~44 ~168 ~22 ~48 minecraft:light_gray_concrete replace
fill ~174 ~22 ~48 ~174 ~22 ~52 minecraft:light_gray_concrete replace
fill ~198 ~22 ~52 ~198 ~22 ~56 minecraft:light_gray_concrete replace
fill ~207 ~22 ~56 ~207 ~22 ~60 minecraft:light_gray_concrete replace
fill ~231 ~22 ~60 ~231 ~22 ~64 minecraft:light_gray_concrete replace
fill ~240 ~22 ~64 ~240 ~22 ~68 minecraft:light_gray_concrete replace
fill ~255 ~22 ~68 ~255 ~22 ~72 minecraft:light_gray_concrete replace
fill ~225 ~22 ~72 ~225 ~22 ~76 minecraft:light_gray_concrete replace
fill ~261 ~22 ~76 ~261 ~22 ~80 minecraft:light_gray_concrete replace
fill ~249 ~22 ~80 ~249 ~22 ~84 minecraft:light_gray_concrete replace
fill ~273 ~22 ~84 ~273 ~22 ~88 minecraft:light_gray_concrete replace
fill ~81 ~22 ~88 ~81 ~22 ~92 minecraft:light_gray_concrete replace
fill ~84 ~22 ~92 ~84 ~22 ~96 minecraft:light_gray_concrete replace
fill ~87 ~22 ~96 ~87 ~22 ~104 minecraft:light_gray_concrete replace
fill ~120 ~22 ~104 ~120 ~22 ~108 minecraft:light_gray_concrete replace
fill ~93 ~22 ~108 ~93 ~22 ~112 minecraft:light_gray_concrete replace
fill ~96 ~22 ~112 ~96 ~22 ~116 minecraft:light_gray_concrete replace
fill ~99 ~22 ~116 ~99 ~22 ~124 minecraft:light_gray_concrete replace
fill ~132 ~22 ~124 ~132 ~22 ~128 minecraft:light_gray_concrete replace
fill ~111 ~22 ~128 ~111 ~22 ~132 minecraft:light_gray_concrete replace
fill ~114 ~22 ~132 ~114 ~22 ~136 minecraft:light_gray_concrete replace
fill ~117 ~22 ~136 ~117 ~22 ~144 minecraft:light_gray_concrete replace
fill ~147 ~22 ~144 ~147 ~22 ~148 minecraft:light_gray_concrete replace
fill ~129 ~22 ~148 ~129 ~22 ~152 minecraft:light_gray_concrete replace
fill ~138 ~22 ~152 ~138 ~22 ~156 minecraft:light_gray_concrete replace
fill ~141 ~22 ~156 ~141 ~22 ~164 minecraft:light_gray_concrete replace
fill ~180 ~22 ~160 ~180 ~22 ~168 minecraft:light_gray_concrete replace
fill ~153 ~22 ~164 ~153 ~22 ~172 minecraft:light_gray_concrete replace
fill ~156 ~22 ~168 ~156 ~22 ~176 minecraft:light_gray_concrete replace
fill ~159 ~22 ~172 ~159 ~22 ~184 minecraft:light_gray_concrete replace
fill ~201 ~22 ~176 ~201 ~22 ~188 minecraft:light_gray_concrete replace
fill ~189 ~22 ~180 ~189 ~22 ~192 minecraft:light_gray_concrete replace
fill ~192 ~22 ~184 ~192 ~22 ~196 minecraft:light_gray_concrete replace
fill ~195 ~22 ~188 ~195 ~22 ~204 minecraft:light_gray_concrete replace
fill ~216 ~22 ~192 ~216 ~22 ~208 minecraft:light_gray_concrete replace
fill ~210 ~22 ~196 ~210 ~22 ~212 minecraft:light_gray_concrete replace
fill ~213 ~22 ~200 ~213 ~22 ~216 minecraft:light_gray_concrete replace
fill ~219 ~22 ~204 ~219 ~22 ~224 minecraft:light_gray_concrete replace
fill ~243 ~22 ~208 ~243 ~22 ~228 minecraft:light_gray_concrete replace
fill ~246 ~22 ~212 ~246 ~22 ~232 minecraft:light_gray_concrete replace
fill ~258 ~22 ~216 ~258 ~22 ~236 minecraft:light_gray_concrete replace
fill ~267 ~22 ~220 ~267 ~22 ~240 minecraft:light_gray_concrete replace
fill ~270 ~22 ~224 ~270 ~22 ~248 minecraft:light_gray_concrete replace
fill ~228 ~22 ~228 ~228 ~22 ~252 minecraft:light_gray_concrete replace
fill ~234 ~22 ~232 ~234 ~22 ~256 minecraft:light_gray_concrete replace
fill ~237 ~22 ~236 ~237 ~22 ~264 minecraft:light_gray_concrete replace
fill ~252 ~22 ~240 ~252 ~22 ~268 minecraft:light_gray_concrete replace
fill ~264 ~22 ~244 ~264 ~22 ~272 minecraft:light_gray_concrete replace
fill ~276 ~22 ~248 ~276 ~22 ~276 minecraft:light_gray_concrete replace
fill ~279 ~22 ~252 ~279 ~22 ~280 minecraft:light_gray_concrete replace
fill ~282 ~22 ~256 ~282 ~22 ~288 minecraft:light_gray_concrete replace
fill ~204 ~22 ~260 ~204 ~22 ~300 minecraft:light_gray_concrete replace
fill ~186 ~22 ~264 ~186 ~22 ~300 minecraft:light_gray_concrete replace
fill ~183 ~22 ~268 ~183 ~22 ~300 minecraft:light_gray_concrete replace
fill ~177 ~22 ~272 ~177 ~22 ~300 minecraft:light_gray_concrete replace
fill ~171 ~22 ~276 ~171 ~22 ~300 minecraft:light_gray_concrete replace
fill ~165 ~22 ~280 ~165 ~22 ~300 minecraft:light_gray_concrete replace
fill ~162 ~22 ~284 ~162 ~22 ~300 minecraft:light_gray_concrete replace
fill ~135 ~22 ~288 ~135 ~22 ~296 minecraft:light_gray_concrete replace
fill ~285 ~22 ~300 ~285 ~22 ~304 minecraft:light_gray_concrete replace
fill ~222 ~22 ~304 ~222 ~22 ~308 minecraft:light_gray_concrete replace
setblock ~78 ~23 ~7 minecraft:light_gray_concrete replace
setblock ~102 ~23 ~11 minecraft:light_gray_concrete replace
setblock ~90 ~23 ~15 minecraft:light_gray_concrete replace
setblock ~108 ~23 ~19 minecraft:light_gray_concrete replace
setblock ~105 ~23 ~23 minecraft:light_gray_concrete replace
setblock ~123 ~23 ~27 minecraft:light_gray_concrete replace
setblock ~126 ~23 ~31 minecraft:light_gray_concrete replace
setblock ~144 ~23 ~35 minecraft:light_gray_concrete replace
setblock ~150 ~23 ~39 minecraft:light_gray_concrete replace
setblock ~168 ~23 ~43 minecraft:light_gray_concrete replace
setblock ~174 ~23 ~47 minecraft:light_gray_concrete replace
setblock ~198 ~23 ~51 minecraft:light_gray_concrete replace
setblock ~207 ~23 ~55 minecraft:light_gray_concrete replace
setblock ~231 ~23 ~59 minecraft:light_gray_concrete replace
setblock ~240 ~23 ~63 minecraft:light_gray_concrete replace
setblock ~255 ~23 ~67 minecraft:light_gray_concrete replace
setblock ~225 ~23 ~71 minecraft:light_gray_concrete replace
setblock ~261 ~23 ~75 minecraft:light_gray_concrete replace
setblock ~249 ~23 ~79 minecraft:light_gray_concrete replace
setblock ~273 ~23 ~83 minecraft:light_gray_concrete replace
setblock ~81 ~23 ~87 minecraft:light_gray_concrete replace
setblock ~84 ~23 ~91 minecraft:light_gray_concrete replace
setblock ~82 ~23 ~92 minecraft:light_gray_concrete replace
setblock ~87 ~23 ~95 minecraft:light_gray_concrete replace
setblock ~87 ~23 ~97 minecraft:light_gray_concrete replace
setblock ~88 ~23 ~100 minecraft:light_gray_concrete replace
setblock ~120 ~23 ~103 minecraft:light_gray_concrete replace
setblock ~88 ~23 ~104 minecraft:light_gray_concrete replace
setblock ~93 ~23 ~107 minecraft:light_gray_concrete replace
