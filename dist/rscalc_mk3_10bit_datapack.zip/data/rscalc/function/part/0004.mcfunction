fill ~210 ~32 ~398 ~239 ~32 ~398 minecraft:light_gray_concrete replace
fill ~277 ~32 ~400 ~277 ~32 ~401 minecraft:light_gray_concrete replace
fill ~240 ~32 ~402 ~278 ~32 ~402 minecraft:light_gray_concrete replace
fill ~307 ~32 ~404 ~307 ~32 ~405 minecraft:light_gray_concrete replace
fill ~258 ~32 ~406 ~308 ~32 ~406 minecraft:light_gray_concrete replace
fill ~370 ~32 ~408 ~370 ~32 ~409 minecraft:light_gray_concrete replace
fill ~303 ~32 ~410 ~371 ~32 ~410 minecraft:light_gray_concrete replace
fill ~394 ~32 ~412 ~394 ~32 ~413 minecraft:light_gray_concrete replace
fill ~321 ~32 ~414 ~395 ~32 ~414 minecraft:light_gray_concrete replace
fill ~85 ~32 ~416 ~85 ~32 ~417 minecraft:light_gray_concrete replace
fill ~84 ~32 ~418 ~86 ~32 ~418 minecraft:light_gray_concrete replace
fill ~109 ~32 ~420 ~109 ~32 ~421 minecraft:light_gray_concrete replace
fill ~105 ~32 ~422 ~110 ~32 ~422 minecraft:light_gray_concrete replace
fill ~133 ~32 ~424 ~133 ~32 ~425 minecraft:light_gray_concrete replace
fill ~123 ~32 ~426 ~134 ~32 ~426 minecraft:light_gray_concrete replace
fill ~166 ~32 ~428 ~166 ~32 ~429 minecraft:light_gray_concrete replace
fill ~159 ~32 ~430 ~167 ~32 ~430 minecraft:light_gray_concrete replace
fill ~205 ~32 ~432 ~205 ~32 ~433 minecraft:light_gray_concrete replace
fill ~183 ~32 ~434 ~206 ~32 ~434 minecraft:light_gray_concrete replace
fill ~235 ~32 ~436 ~235 ~32 ~437 minecraft:light_gray_concrete replace
fill ~207 ~32 ~438 ~236 ~32 ~438 minecraft:light_gray_concrete replace
fill ~274 ~32 ~440 ~274 ~32 ~441 minecraft:light_gray_concrete replace
fill ~231 ~32 ~442 ~275 ~32 ~442 minecraft:light_gray_concrete replace
fill ~298 ~32 ~444 ~298 ~32 ~445 minecraft:light_gray_concrete replace
fill ~255 ~32 ~446 ~299 ~32 ~446 minecraft:light_gray_concrete replace
fill ~367 ~32 ~448 ~367 ~32 ~449 minecraft:light_gray_concrete replace
fill ~300 ~32 ~450 ~368 ~32 ~450 minecraft:light_gray_concrete replace
fill ~391 ~32 ~452 ~391 ~32 ~453 minecraft:light_gray_concrete replace
fill ~318 ~32 ~454 ~392 ~32 ~454 minecraft:light_gray_concrete replace
fill ~82 ~32 ~456 ~82 ~32 ~457 minecraft:light_gray_concrete replace
fill ~81 ~32 ~458 ~83 ~32 ~458 minecraft:light_gray_concrete replace
fill ~106 ~32 ~460 ~106 ~32 ~461 minecraft:light_gray_concrete replace
fill ~102 ~32 ~462 ~107 ~32 ~462 minecraft:light_gray_concrete replace
fill ~130 ~32 ~464 ~130 ~32 ~465 minecraft:light_gray_concrete replace
fill ~120 ~32 ~466 ~131 ~32 ~466 minecraft:light_gray_concrete replace
fill ~160 ~32 ~468 ~160 ~32 ~469 minecraft:light_gray_concrete replace
fill ~147 ~32 ~470 ~161 ~32 ~470 minecraft:light_gray_concrete replace
fill ~199 ~32 ~472 ~199 ~32 ~473 minecraft:light_gray_concrete replace
fill ~180 ~32 ~474 ~200 ~32 ~474 minecraft:light_gray_concrete replace
fill ~232 ~32 ~476 ~232 ~32 ~477 minecraft:light_gray_concrete replace
fill ~204 ~32 ~478 ~233 ~32 ~478 minecraft:light_gray_concrete replace
fill ~271 ~32 ~480 ~271 ~32 ~481 minecraft:light_gray_concrete replace
fill ~228 ~32 ~482 ~272 ~32 ~482 minecraft:light_gray_concrete replace
fill ~292 ~32 ~484 ~292 ~32 ~485 minecraft:light_gray_concrete replace
fill ~249 ~32 ~486 ~293 ~32 ~486 minecraft:light_gray_concrete replace
fill ~364 ~32 ~488 ~364 ~32 ~489 minecraft:light_gray_concrete replace
fill ~291 ~32 ~490 ~365 ~32 ~490 minecraft:light_gray_concrete replace
fill ~385 ~32 ~492 ~385 ~32 ~493 minecraft:light_gray_concrete replace
fill ~315 ~32 ~494 ~386 ~32 ~494 minecraft:light_gray_concrete replace
fill ~79 ~32 ~496 ~79 ~32 ~497 minecraft:light_gray_concrete replace
fill ~78 ~32 ~498 ~80 ~32 ~498 minecraft:light_gray_concrete replace
fill ~103 ~32 ~500 ~103 ~32 ~501 minecraft:light_gray_concrete replace
fill ~99 ~32 ~502 ~104 ~32 ~502 minecraft:light_gray_concrete replace
fill ~127 ~32 ~504 ~127 ~32 ~505 minecraft:light_gray_concrete replace
fill ~117 ~32 ~506 ~128 ~32 ~506 minecraft:light_gray_concrete replace
fill ~154 ~32 ~508 ~154 ~32 ~509 minecraft:light_gray_concrete replace
fill ~141 ~32 ~510 ~155 ~32 ~510 minecraft:light_gray_concrete replace
fill ~193 ~32 ~512 ~193 ~32 ~513 minecraft:light_gray_concrete replace
fill ~177 ~32 ~514 ~194 ~32 ~514 minecraft:light_gray_concrete replace
fill ~223 ~32 ~516 ~223 ~32 ~517 minecraft:light_gray_concrete replace
fill ~195 ~32 ~518 ~224 ~32 ~518 minecraft:light_gray_concrete replace
fill ~268 ~32 ~520 ~268 ~32 ~521 minecraft:light_gray_concrete replace
fill ~225 ~32 ~522 ~269 ~32 ~522 minecraft:light_gray_concrete replace
fill ~289 ~32 ~524 ~289 ~32 ~525 minecraft:light_gray_concrete replace
fill ~246 ~32 ~526 ~290 ~32 ~526 minecraft:light_gray_concrete replace
fill ~358 ~32 ~528 ~358 ~32 ~529 minecraft:light_gray_concrete replace
fill ~288 ~32 ~530 ~359 ~32 ~530 minecraft:light_gray_concrete replace
fill ~382 ~32 ~532 ~382 ~32 ~533 minecraft:light_gray_concrete replace
fill ~312 ~32 ~534 ~383 ~32 ~534 minecraft:light_gray_concrete replace
fill ~100 ~32 ~536 ~100 ~32 ~537 minecraft:light_gray_concrete replace
fill ~96 ~32 ~538 ~101 ~32 ~538 minecraft:light_gray_concrete replace
fill ~124 ~32 ~540 ~124 ~32 ~541 minecraft:light_gray_concrete replace
fill ~114 ~32 ~542 ~125 ~32 ~542 minecraft:light_gray_concrete replace
fill ~148 ~32 ~544 ~148 ~32 ~545 minecraft:light_gray_concrete replace
fill ~138 ~32 ~546 ~149 ~32 ~546 minecraft:light_gray_concrete replace
fill ~190 ~32 ~548 ~190 ~32 ~549 minecraft:light_gray_concrete replace
fill ~168 ~32 ~550 ~191 ~32 ~550 minecraft:light_gray_concrete replace
fill ~220 ~32 ~552 ~220 ~32 ~553 minecraft:light_gray_concrete replace
fill ~192 ~32 ~554 ~221 ~32 ~554 minecraft:light_gray_concrete replace
fill ~250 ~32 ~556 ~250 ~32 ~557 minecraft:light_gray_concrete replace
fill ~222 ~32 ~558 ~251 ~32 ~558 minecraft:light_gray_concrete replace
fill ~295 ~32 ~560 ~295 ~32 ~561 minecraft:light_gray_concrete replace
fill ~252 ~32 ~562 ~296 ~32 ~562 minecraft:light_gray_concrete replace
fill ~313 ~32 ~564 ~313 ~32 ~565 minecraft:light_gray_concrete replace
fill ~270 ~32 ~566 ~314 ~32 ~566 minecraft:light_gray_concrete replace
fill ~373 ~32 ~568 ~373 ~32 ~569 minecraft:light_gray_concrete replace
fill ~306 ~32 ~570 ~374 ~32 ~570 minecraft:light_gray_concrete replace
fill ~163 ~32 ~572 ~163 ~32 ~573 minecraft:light_gray_concrete replace
fill ~156 ~32 ~574 ~164 ~32 ~574 minecraft:light_gray_concrete replace
fill ~400 ~32 ~576 ~400 ~32 ~577 minecraft:light_gray_concrete replace
fill ~327 ~32 ~578 ~401 ~32 ~578 minecraft:light_gray_concrete replace
fill ~97 ~32 ~580 ~97 ~32 ~581 minecraft:light_gray_concrete replace
fill ~93 ~32 ~582 ~98 ~32 ~582 minecraft:light_gray_concrete replace
fill ~376 ~32 ~584 ~376 ~32 ~585 minecraft:light_gray_concrete replace
fill ~309 ~32 ~586 ~377 ~32 ~586 minecraft:light_gray_concrete replace
fill ~397 ~32 ~588 ~397 ~32 ~589 minecraft:light_gray_concrete replace
fill ~324 ~32 ~590 ~398 ~32 ~590 minecraft:light_gray_concrete replace
setblock ~94 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~151 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~178 ~33 ~8 minecraft:light_gray_concrete replace
setblock ~100 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~102 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~117 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~119 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~133 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~135 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~165 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~167 ~33 ~10 minecraft:light_gray_concrete replace
setblock ~118 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~142 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~172 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~211 ~33 ~16 minecraft:light_gray_concrete replace
setblock ~126 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~128 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~157 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~159 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~174 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~176 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~191 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~193 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~208 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~210 ~33 ~18 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~169 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~253 ~33 ~24 minecraft:light_gray_concrete replace
setblock ~162 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~164 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~178 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~180 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~195 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~197 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~212 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~246 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~248 ~33 ~26 minecraft:light_gray_concrete replace
setblock ~175 ~33 ~32 minecraft:light_gray_concrete replace
setblock ~241 ~33 ~32 minecraft:light_gray_concrete replace
setblock ~259 ~33 ~32 minecraft:light_gray_concrete replace
setblock ~189 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~191 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~205 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~207 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~222 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~224 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~254 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~34 minecraft:light_gray_concrete replace
setblock ~196 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~226 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~247 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~301 ~33 ~40 minecraft:light_gray_concrete replace
setblock ~204 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~206 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~220 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~222 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~237 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~239 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~254 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~271 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~273 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~288 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~290 ~33 ~42 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~262 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~283 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~48 minecraft:light_gray_concrete replace
setblock ~241 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~243 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~258 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~260 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~275 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~277 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~311 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~50 minecraft:light_gray_concrete replace
setblock ~265 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~322 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~340 ~33 ~56 minecraft:light_gray_concrete replace
setblock ~270 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~272 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~288 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~302 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~304 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~318 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~320 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~336 ~33 ~58 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~60 minecraft:light_gray_concrete replace
setblock ~337 ~33 ~60 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~60 minecraft:light_gray_concrete replace
setblock ~283 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~285 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~300 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~302 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~332 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~62 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~352 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~388 ~33 ~72 minecraft:light_gray_concrete replace
setblock ~289 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~291 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~306 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~308 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~323 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~325 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~340 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~342 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~357 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~359 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~374 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~376 ~33 ~74 minecraft:light_gray_concrete replace
setblock ~355 ~33 ~76 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~76 minecraft:light_gray_concrete replace
setblock ~379 ~33 ~76 minecraft:light_gray_concrete replace
setblock ~303 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~305 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~321 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~335 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~337 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~351 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~353 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~369 ~33 ~78 minecraft:light_gray_concrete replace
setblock ~94 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~151 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~181 ~33 ~256 minecraft:light_gray_concrete replace
setblock ~100 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~102 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~117 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~119 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~147 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~162 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~164 ~33 ~258 minecraft:light_gray_concrete replace
setblock ~157 ~33 ~264 minecraft:light_gray_concrete replace
setblock ~151 ~33 ~266 minecraft:light_gray_concrete replace
setblock ~153 ~33 ~266 minecraft:light_gray_concrete replace
setblock ~118 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~142 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~172 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~268 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~123 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~138 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~140 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~166 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~168 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~183 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~185 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~200 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~270 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~169 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~276 minecraft:light_gray_concrete replace
setblock ~159 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~161 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~187 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~189 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~204 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~206 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~221 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~223 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~238 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~240 ~33 ~278 minecraft:light_gray_concrete replace
setblock ~175 ~33 ~284 minecraft:light_gray_concrete replace
setblock ~241 ~33 ~284 minecraft:light_gray_concrete replace
setblock ~259 ~33 ~284 minecraft:light_gray_concrete replace
setblock ~186 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~188 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~216 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~233 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~248 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~286 minecraft:light_gray_concrete replace
setblock ~196 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~226 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~247 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~304 ~33 ~292 minecraft:light_gray_concrete replace
setblock ~201 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~203 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~261 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~263 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~278 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~280 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~295 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~297 ~33 ~294 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~262 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~283 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~300 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~252 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~267 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~269 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~299 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~301 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~318 ~33 ~302 minecraft:light_gray_concrete replace
setblock ~265 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~325 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~340 ~33 ~308 minecraft:light_gray_concrete replace
setblock ~280 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~282 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~297 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~299 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~329 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~310 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~316 minecraft:light_gray_concrete replace
setblock ~337 ~33 ~316 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~316 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~288 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~303 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~305 ~33 ~318 minecraft:light_gray_concrete replace
setblock ~286 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~349 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~388 ~33 ~324 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~311 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~360 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~375 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~377 ~33 ~326 minecraft:light_gray_concrete replace
setblock ~355 ~33 ~332 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~332 minecraft:light_gray_concrete replace
setblock ~379 ~33 ~332 minecraft:light_gray_concrete replace
setblock ~307 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~324 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~360 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~375 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~377 ~33 ~334 minecraft:light_gray_concrete replace
setblock ~91 ~33 ~340 minecraft:light_gray_concrete replace
setblock ~115 ~33 ~344 minecraft:light_gray_concrete replace
setblock ~139 ~33 ~348 minecraft:light_gray_concrete replace
setblock ~187 ~33 ~352 minecraft:light_gray_concrete replace
setblock ~172 ~33 ~354 minecraft:light_gray_concrete replace
setblock ~174 ~33 ~354 minecraft:light_gray_concrete replace
setblock ~217 ~33 ~356 minecraft:light_gray_concrete replace
setblock ~196 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~198 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~213 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~215 ~33 ~358 minecraft:light_gray_concrete replace
setblock ~244 ~33 ~360 minecraft:light_gray_concrete replace
setblock ~226 ~33 ~362 minecraft:light_gray_concrete replace
setblock ~228 ~33 ~362 minecraft:light_gray_concrete replace
setblock ~280 ~33 ~364 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~252 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~267 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~269 ~33 ~366 minecraft:light_gray_concrete replace
setblock ~310 ~33 ~368 minecraft:light_gray_concrete replace
setblock ~268 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~270 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~285 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~287 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~302 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~304 ~33 ~370 minecraft:light_gray_concrete replace
setblock ~346 ~33 ~372 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~311 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~345 ~33 ~374 minecraft:light_gray_concrete replace
setblock ~88 ~33 ~376 minecraft:light_gray_concrete replace
setblock ~112 ~33 ~380 minecraft:light_gray_concrete replace
setblock ~136 ~33 ~384 minecraft:light_gray_concrete replace
setblock ~184 ~33 ~388 minecraft:light_gray_concrete replace
setblock ~169 ~33 ~390 minecraft:light_gray_concrete replace
setblock ~171 ~33 ~390 minecraft:light_gray_concrete replace
setblock ~208 ~33 ~392 minecraft:light_gray_concrete replace
setblock ~193 ~33 ~394 minecraft:light_gray_concrete replace
setblock ~195 ~33 ~394 minecraft:light_gray_concrete replace
setblock ~238 ~33 ~396 minecraft:light_gray_concrete replace
setblock ~217 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~219 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~234 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~236 ~33 ~398 minecraft:light_gray_concrete replace
setblock ~277 ~33 ~400 minecraft:light_gray_concrete replace
setblock ~247 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~249 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~264 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~266 ~33 ~402 minecraft:light_gray_concrete replace
setblock ~307 ~33 ~404 minecraft:light_gray_concrete replace
setblock ~265 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~267 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~282 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~284 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~299 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~301 ~33 ~406 minecraft:light_gray_concrete replace
setblock ~370 ~33 ~408 minecraft:light_gray_concrete replace
setblock ~310 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~312 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~327 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~329 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~344 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~346 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~363 ~33 ~410 minecraft:light_gray_concrete replace
setblock ~394 ~33 ~412 minecraft:light_gray_concrete replace
setblock ~328 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~330 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~345 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~347 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~362 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~364 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~379 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~381 ~33 ~414 minecraft:light_gray_concrete replace
setblock ~85 ~33 ~416 minecraft:light_gray_concrete replace
setblock ~109 ~33 ~420 minecraft:light_gray_concrete replace
setblock ~133 ~33 ~424 minecraft:light_gray_concrete replace
setblock ~130 ~33 ~426 minecraft:light_gray_concrete replace
setblock ~132 ~33 ~426 minecraft:light_gray_concrete replace
setblock ~166 ~33 ~428 minecraft:light_gray_concrete replace
setblock ~205 ~33 ~432 minecraft:light_gray_concrete replace
setblock ~190 ~33 ~434 minecraft:light_gray_concrete replace
setblock ~192 ~33 ~434 minecraft:light_gray_concrete replace
setblock ~235 ~33 ~436 minecraft:light_gray_concrete replace
setblock ~214 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~216 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~233 ~33 ~438 minecraft:light_gray_concrete replace
setblock ~274 ~33 ~440 minecraft:light_gray_concrete replace
setblock ~238 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~240 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~255 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~257 ~33 ~442 minecraft:light_gray_concrete replace
setblock ~298 ~33 ~444 minecraft:light_gray_concrete replace
setblock ~262 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~264 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~279 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~281 ~33 ~446 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~448 minecraft:light_gray_concrete replace
setblock ~307 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~309 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~324 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~326 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~343 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~360 ~33 ~450 minecraft:light_gray_concrete replace
setblock ~391 ~33 ~452 minecraft:light_gray_concrete replace
setblock ~325 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~327 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~342 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~344 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~359 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~361 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~376 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~378 ~33 ~454 minecraft:light_gray_concrete replace
setblock ~82 ~33 ~456 minecraft:light_gray_concrete replace
setblock ~106 ~33 ~460 minecraft:light_gray_concrete replace
setblock ~130 ~33 ~464 minecraft:light_gray_concrete replace
setblock ~127 ~33 ~466 minecraft:light_gray_concrete replace
setblock ~129 ~33 ~466 minecraft:light_gray_concrete replace
setblock ~160 ~33 ~468 minecraft:light_gray_concrete replace
setblock ~154 ~33 ~470 minecraft:light_gray_concrete replace
setblock ~156 ~33 ~470 minecraft:light_gray_concrete replace
setblock ~199 ~33 ~472 minecraft:light_gray_concrete replace
setblock ~187 ~33 ~474 minecraft:light_gray_concrete replace
setblock ~189 ~33 ~474 minecraft:light_gray_concrete replace
setblock ~232 ~33 ~476 minecraft:light_gray_concrete replace
setblock ~211 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~213 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~228 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~230 ~33 ~478 minecraft:light_gray_concrete replace
setblock ~271 ~33 ~480 minecraft:light_gray_concrete replace
setblock ~235 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~237 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~252 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~254 ~33 ~482 minecraft:light_gray_concrete replace
setblock ~292 ~33 ~484 minecraft:light_gray_concrete replace
setblock ~256 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~258 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~273 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~275 ~33 ~486 minecraft:light_gray_concrete replace
setblock ~364 ~33 ~488 minecraft:light_gray_concrete replace
setblock ~298 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~300 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~315 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~317 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~332 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~349 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~351 ~33 ~490 minecraft:light_gray_concrete replace
setblock ~385 ~33 ~492 minecraft:light_gray_concrete replace
setblock ~322 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~324 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~339 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~341 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~356 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~373 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~375 ~33 ~494 minecraft:light_gray_concrete replace
setblock ~79 ~33 ~496 minecraft:light_gray_concrete replace
setblock ~103 ~33 ~500 minecraft:light_gray_concrete replace
setblock ~127 ~33 ~504 minecraft:light_gray_concrete replace
setblock ~124 ~33 ~506 minecraft:light_gray_concrete replace
setblock ~126 ~33 ~506 minecraft:light_gray_concrete replace
setblock ~154 ~33 ~508 minecraft:light_gray_concrete replace
setblock ~148 ~33 ~510 minecraft:light_gray_concrete replace
setblock ~150 ~33 ~510 minecraft:light_gray_concrete replace
setblock ~193 ~33 ~512 minecraft:light_gray_concrete replace
setblock ~184 ~33 ~514 minecraft:light_gray_concrete replace
setblock ~186 ~33 ~514 minecraft:light_gray_concrete replace
setblock ~223 ~33 ~516 minecraft:light_gray_concrete replace
setblock ~202 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~204 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~219 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~221 ~33 ~518 minecraft:light_gray_concrete replace
setblock ~268 ~33 ~520 minecraft:light_gray_concrete replace
setblock ~232 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~234 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~249 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~251 ~33 ~522 minecraft:light_gray_concrete replace
setblock ~289 ~33 ~524 minecraft:light_gray_concrete replace
setblock ~253 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~255 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~270 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~272 ~33 ~526 minecraft:light_gray_concrete replace
setblock ~358 ~33 ~528 minecraft:light_gray_concrete replace
setblock ~295 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~297 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~312 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~314 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~329 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~346 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~348 ~33 ~530 minecraft:light_gray_concrete replace
setblock ~382 ~33 ~532 minecraft:light_gray_concrete replace
setblock ~319 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~321 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~336 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~338 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~353 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~355 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~370 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~372 ~33 ~534 minecraft:light_gray_concrete replace
setblock ~100 ~33 ~536 minecraft:light_gray_concrete replace
setblock ~124 ~33 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~33 ~542 minecraft:light_gray_concrete replace
setblock ~123 ~33 ~542 minecraft:light_gray_concrete replace
setblock ~148 ~33 ~544 minecraft:light_gray_concrete replace
setblock ~145 ~33 ~546 minecraft:light_gray_concrete replace
setblock ~147 ~33 ~546 minecraft:light_gray_concrete replace
setblock ~190 ~33 ~548 minecraft:light_gray_concrete replace
setblock ~175 ~33 ~550 minecraft:light_gray_concrete replace
setblock ~177 ~33 ~550 minecraft:light_gray_concrete replace
setblock ~220 ~33 ~552 minecraft:light_gray_concrete replace
setblock ~199 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~201 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~216 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~218 ~33 ~554 minecraft:light_gray_concrete replace
setblock ~250 ~33 ~556 minecraft:light_gray_concrete replace
setblock ~229 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~231 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~246 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~248 ~33 ~558 minecraft:light_gray_concrete replace
setblock ~295 ~33 ~560 minecraft:light_gray_concrete replace
setblock ~259 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~261 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~276 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~278 ~33 ~562 minecraft:light_gray_concrete replace
setblock ~313 ~33 ~564 minecraft:light_gray_concrete replace
setblock ~277 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~279 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~294 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~296 ~33 ~566 minecraft:light_gray_concrete replace
setblock ~373 ~33 ~568 minecraft:light_gray_concrete replace
setblock ~313 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~315 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~330 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~332 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~347 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~349 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~364 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~366 ~33 ~570 minecraft:light_gray_concrete replace
setblock ~163 ~33 ~572 minecraft:light_gray_concrete replace
setblock ~400 ~33 ~576 minecraft:light_gray_concrete replace
setblock ~334 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~336 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~351 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~353 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~368 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~370 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~385 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~387 ~33 ~578 minecraft:light_gray_concrete replace
setblock ~97 ~33 ~580 minecraft:light_gray_concrete replace
setblock ~376 ~33 ~584 minecraft:light_gray_concrete replace
setblock ~316 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~318 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~333 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~335 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~350 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~352 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~369 ~33 ~586 minecraft:light_gray_concrete replace
setblock ~397 ~33 ~588 minecraft:light_gray_concrete replace
setblock ~331 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~333 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~348 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~350 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~365 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~367 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~382 ~33 ~590 minecraft:light_gray_concrete replace
setblock ~384 ~33 ~590 minecraft:light_gray_concrete replace
fill ~93 ~34 ~8 ~93 ~34 ~260 minecraft:light_gray_concrete replace
fill ~120 ~34 ~8 ~120 ~34 ~264 minecraft:light_gray_concrete replace
fill ~150 ~34 ~8 ~150 ~34 ~268 minecraft:light_gray_concrete replace
fill ~177 ~34 ~8 ~177 ~34 ~12 minecraft:light_gray_concrete replace
fill ~117 ~34 ~16 ~117 ~34 ~280 minecraft:light_gray_concrete replace
fill ~141 ~34 ~16 ~141 ~34 ~284 minecraft:light_gray_concrete replace
fill ~171 ~34 ~16 ~171 ~34 ~288 minecraft:light_gray_concrete replace
fill ~210 ~34 ~16 ~210 ~34 ~20 minecraft:light_gray_concrete replace
fill ~144 ~34 ~24 ~144 ~34 ~296 minecraft:light_gray_concrete replace
fill ~168 ~34 ~24 ~168 ~34 ~300 minecraft:light_gray_concrete replace
fill ~201 ~34 ~24 ~201 ~34 ~304 minecraft:light_gray_concrete replace
fill ~252 ~34 ~24 ~252 ~34 ~28 minecraft:light_gray_concrete replace
fill ~174 ~34 ~32 ~174 ~34 ~312 minecraft:light_gray_concrete replace
fill ~240 ~34 ~32 ~240 ~34 ~316 minecraft:light_gray_concrete replace
fill ~258 ~34 ~32 ~258 ~34 ~320 minecraft:light_gray_concrete replace
fill ~195 ~34 ~40 ~195 ~34 ~324 minecraft:light_gray_concrete replace
fill ~225 ~34 ~40 ~225 ~34 ~328 minecraft:light_gray_concrete replace
fill ~246 ~34 ~40 ~246 ~34 ~332 minecraft:light_gray_concrete replace
fill ~300 ~34 ~40 ~300 ~34 ~44 minecraft:light_gray_concrete replace
fill ~228 ~34 ~48 ~228 ~34 ~340 minecraft:light_gray_concrete replace
fill ~261 ~34 ~48 ~261 ~34 ~344 minecraft:light_gray_concrete replace
fill ~282 ~34 ~48 ~282 ~34 ~348 minecraft:light_gray_concrete replace
fill ~330 ~34 ~48 ~330 ~34 ~52 minecraft:light_gray_concrete replace
fill ~264 ~34 ~56 ~264 ~34 ~356 minecraft:light_gray_concrete replace
fill ~315 ~34 ~56 ~315 ~34 ~360 minecraft:light_gray_concrete replace
fill ~321 ~34 ~56 ~321 ~34 ~60 minecraft:light_gray_concrete replace
fill ~339 ~34 ~56 ~339 ~34 ~368 minecraft:light_gray_concrete replace
fill ~318 ~34 ~60 ~318 ~34 ~372 minecraft:light_gray_concrete replace
fill ~336 ~34 ~60 ~336 ~34 ~376 minecraft:light_gray_concrete replace
fill ~342 ~34 ~60 ~342 ~34 ~380 minecraft:light_gray_concrete replace
fill ~285 ~34 ~72 ~285 ~34 ~384 minecraft:light_gray_concrete replace
fill ~327 ~34 ~72 ~327 ~34 ~388 minecraft:light_gray_concrete replace
fill ~351 ~34 ~72 ~351 ~34 ~76 minecraft:light_gray_concrete replace
fill ~387 ~34 ~72 ~387 ~34 ~396 minecraft:light_gray_concrete replace
fill ~354 ~34 ~76 ~354 ~34 ~400 minecraft:light_gray_concrete replace
fill ~360 ~34 ~76 ~360 ~34 ~404 minecraft:light_gray_concrete replace
fill ~378 ~34 ~76 ~378 ~34 ~408 minecraft:light_gray_concrete replace
fill ~180 ~34 ~256 ~180 ~34 ~272 minecraft:light_gray_concrete replace
fill ~156 ~34 ~264 ~156 ~34 ~276 minecraft:light_gray_concrete replace
fill ~213 ~34 ~268 ~213 ~34 ~292 minecraft:light_gray_concrete replace
fill ~255 ~34 ~276 ~255 ~34 ~308 minecraft:light_gray_concrete replace
fill ~303 ~34 ~292 ~303 ~34 ~336 minecraft:light_gray_concrete replace
fill ~333 ~34 ~300 ~333 ~34 ~352 minecraft:light_gray_concrete replace
fill ~324 ~34 ~308 ~324 ~34 ~364 minecraft:light_gray_concrete replace
fill ~348 ~34 ~324 ~348 ~34 ~392 minecraft:light_gray_concrete replace
fill ~90 ~34 ~340 ~90 ~34 ~412 minecraft:light_gray_concrete replace
fill ~114 ~34 ~344 ~114 ~34 ~416 minecraft:light_gray_concrete replace
fill ~138 ~34 ~348 ~138 ~34 ~420 minecraft:light_gray_concrete replace
fill ~186 ~34 ~352 ~186 ~34 ~424 minecraft:light_gray_concrete replace
fill ~216 ~34 ~356 ~216 ~34 ~428 minecraft:light_gray_concrete replace
fill ~243 ~34 ~360 ~243 ~34 ~432 minecraft:light_gray_concrete replace
fill ~279 ~34 ~364 ~279 ~34 ~436 minecraft:light_gray_concrete replace
fill ~309 ~34 ~368 ~309 ~34 ~440 minecraft:light_gray_concrete replace
fill ~345 ~34 ~372 ~345 ~34 ~444 minecraft:light_gray_concrete replace
fill ~87 ~34 ~376 ~87 ~34 ~448 minecraft:light_gray_concrete replace
fill ~111 ~34 ~380 ~111 ~34 ~452 minecraft:light_gray_concrete replace
fill ~135 ~34 ~384 ~135 ~34 ~456 minecraft:light_gray_concrete replace
fill ~183 ~34 ~388 ~183 ~34 ~460 minecraft:light_gray_concrete replace
fill ~207 ~34 ~392 ~207 ~34 ~464 minecraft:light_gray_concrete replace
fill ~237 ~34 ~396 ~237 ~34 ~468 minecraft:light_gray_concrete replace
fill ~276 ~34 ~400 ~276 ~34 ~472 minecraft:light_gray_concrete replace
fill ~306 ~34 ~404 ~306 ~34 ~476 minecraft:light_gray_concrete replace
fill ~369 ~34 ~408 ~369 ~34 ~480 minecraft:light_gray_concrete replace
fill ~393 ~34 ~412 ~393 ~34 ~484 minecraft:light_gray_concrete replace
fill ~84 ~34 ~416 ~84 ~34 ~488 minecraft:light_gray_concrete replace
fill ~108 ~34 ~420 ~108 ~34 ~492 minecraft:light_gray_concrete replace
fill ~132 ~34 ~424 ~132 ~34 ~496 minecraft:light_gray_concrete replace
fill ~165 ~34 ~428 ~165 ~34 ~500 minecraft:light_gray_concrete replace
fill ~204 ~34 ~432 ~204 ~34 ~504 minecraft:light_gray_concrete replace
fill ~234 ~34 ~436 ~234 ~34 ~508 minecraft:light_gray_concrete replace
fill ~273 ~34 ~440 ~273 ~34 ~512 minecraft:light_gray_concrete replace
fill ~297 ~34 ~444 ~297 ~34 ~516 minecraft:light_gray_concrete replace
fill ~366 ~34 ~448 ~366 ~34 ~520 minecraft:light_gray_concrete replace
fill ~390 ~34 ~452 ~390 ~34 ~524 minecraft:light_gray_concrete replace
fill ~81 ~34 ~456 ~81 ~34 ~528 minecraft:light_gray_concrete replace
fill ~105 ~34 ~460 ~105 ~34 ~532 minecraft:light_gray_concrete replace
fill ~129 ~34 ~464 ~129 ~34 ~536 minecraft:light_gray_concrete replace
fill ~159 ~34 ~468 ~159 ~34 ~540 minecraft:light_gray_concrete replace
fill ~198 ~34 ~472 ~198 ~34 ~544 minecraft:light_gray_concrete replace
fill ~231 ~34 ~476 ~231 ~34 ~548 minecraft:light_gray_concrete replace
fill ~270 ~34 ~480 ~270 ~34 ~552 minecraft:light_gray_concrete replace
fill ~291 ~34 ~484 ~291 ~34 ~556 minecraft:light_gray_concrete replace
fill ~363 ~34 ~488 ~363 ~34 ~560 minecraft:light_gray_concrete replace
fill ~384 ~34 ~492 ~384 ~34 ~564 minecraft:light_gray_concrete replace
fill ~78 ~34 ~496 ~78 ~34 ~568 minecraft:light_gray_concrete replace
fill ~102 ~34 ~500 ~102 ~34 ~572 minecraft:light_gray_concrete replace
fill ~126 ~34 ~504 ~126 ~34 ~576 minecraft:light_gray_concrete replace
fill ~153 ~34 ~508 ~153 ~34 ~580 minecraft:light_gray_concrete replace
fill ~192 ~34 ~512 ~192 ~34 ~584 minecraft:light_gray_concrete replace
fill ~222 ~34 ~516 ~222 ~34 ~588 minecraft:light_gray_concrete replace
fill ~267 ~34 ~520 ~267 ~34 ~592 minecraft:light_gray_concrete replace
fill ~288 ~34 ~524 ~288 ~34 ~596 minecraft:light_gray_concrete replace
fill ~357 ~34 ~528 ~357 ~34 ~600 minecraft:light_gray_concrete replace
fill ~381 ~34 ~532 ~381 ~34 ~604 minecraft:light_gray_concrete replace
fill ~99 ~34 ~536 ~99 ~34 ~608 minecraft:light_gray_concrete replace
fill ~123 ~34 ~540 ~123 ~34 ~612 minecraft:light_gray_concrete replace
fill ~147 ~34 ~544 ~147 ~34 ~616 minecraft:light_gray_concrete replace
fill ~189 ~34 ~548 ~189 ~34 ~620 minecraft:light_gray_concrete replace
fill ~219 ~34 ~552 ~219 ~34 ~624 minecraft:light_gray_concrete replace
fill ~249 ~34 ~556 ~249 ~34 ~628 minecraft:light_gray_concrete replace
fill ~294 ~34 ~560 ~294 ~34 ~632 minecraft:light_gray_concrete replace
fill ~312 ~34 ~564 ~312 ~34 ~636 minecraft:light_gray_concrete replace
fill ~372 ~34 ~568 ~372 ~34 ~640 minecraft:light_gray_concrete replace
fill ~162 ~34 ~572 ~162 ~34 ~644 minecraft:light_gray_concrete replace
fill ~399 ~34 ~576 ~399 ~34 ~648 minecraft:light_gray_concrete replace
fill ~96 ~34 ~580 ~96 ~34 ~652 minecraft:light_gray_concrete replace
fill ~375 ~34 ~584 ~375 ~34 ~656 minecraft:light_gray_concrete replace
fill ~396 ~34 ~588 ~396 ~34 ~660 minecraft:light_gray_concrete replace
setblock ~94 ~35 ~8 minecraft:light_gray_concrete replace
setblock ~121 ~35 ~8 minecraft:light_gray_concrete replace
setblock ~177 ~35 ~13 minecraft:light_gray_concrete replace
setblock ~118 ~35 ~16 minecraft:light_gray_concrete replace
setblock ~142 ~35 ~16 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~210 ~35 ~21 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~23 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~23 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~23 minecraft:light_gray_concrete replace
setblock ~145 ~35 ~24 minecraft:light_gray_concrete replace
setblock ~169 ~35 ~24 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~252 ~35 ~29 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~31 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~31 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~31 minecraft:light_gray_concrete replace
setblock ~175 ~35 ~32 minecraft:light_gray_concrete replace
setblock ~259 ~35 ~32 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~37 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~39 minecraft:light_gray_concrete replace
setblock ~196 ~35 ~40 minecraft:light_gray_concrete replace
setblock ~226 ~35 ~40 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~300 ~35 ~45 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~47 minecraft:light_gray_concrete replace
setblock ~229 ~35 ~48 minecraft:light_gray_concrete replace
setblock ~262 ~35 ~48 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~330 ~35 ~53 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~55 minecraft:light_gray_concrete replace
setblock ~265 ~35 ~56 minecraft:light_gray_concrete replace
setblock ~340 ~35 ~56 minecraft:light_gray_concrete replace
setblock ~337 ~35 ~60 minecraft:light_gray_concrete replace
setblock ~343 ~35 ~60 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~321 ~35 ~61 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~63 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~69 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~71 minecraft:light_gray_concrete replace
setblock ~286 ~35 ~72 minecraft:light_gray_concrete replace
setblock ~388 ~35 ~72 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~73 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~73 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~73 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~75 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~75 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~75 minecraft:light_gray_concrete replace
setblock ~355 ~35 ~76 minecraft:light_gray_concrete replace
setblock ~379 ~35 ~76 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~351 ~35 ~77 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~79 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~85 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~87 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~89 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~91 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~93 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~95 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~101 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~103 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~105 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~107 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~109 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~111 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~117 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~119 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~121 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~121 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~121 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~121 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~121 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~121 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~123 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~123 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~123 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~123 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~123 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~123 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~125 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~127 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~133 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~135 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~137 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~137 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~137 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~137 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~137 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~137 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~139 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~139 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~139 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~139 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~139 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~139 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~141 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~143 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~149 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~151 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~153 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~153 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~153 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~153 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~153 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~153 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~155 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~155 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~155 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~155 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~155 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~155 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~157 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~159 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~165 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~167 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~169 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~169 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~169 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~169 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~169 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~169 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~171 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~171 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~171 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~171 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~171 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~171 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~173 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~175 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~181 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~183 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~185 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~185 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~185 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~185 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~185 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~185 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~187 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~187 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~187 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~187 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~187 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~187 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~189 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~191 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~197 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~199 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~201 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~201 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~201 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~201 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~201 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~201 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~203 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~203 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~203 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~203 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~203 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~203 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~205 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~207 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~213 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~215 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~217 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~217 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~217 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~217 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~217 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~217 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~219 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~219 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~219 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~219 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~219 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~219 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~221 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~223 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~229 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~231 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~233 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~233 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~233 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~233 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~233 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~233 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~235 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~235 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~235 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~235 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~235 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~235 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~237 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~239 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~245 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~247 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~249 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~249 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~249 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~249 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~249 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~249 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~251 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~251 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~251 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~251 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~251 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~251 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~253 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~255 minecraft:light_gray_concrete replace
setblock ~94 ~35 ~256 minecraft:light_gray_concrete replace
setblock ~121 ~35 ~256 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~259 minecraft:light_gray_concrete replace
setblock ~93 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~261 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~263 minecraft:light_gray_concrete replace
setblock ~120 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~265 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~267 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~267 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~267 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~267 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~267 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~267 minecraft:light_gray_concrete replace
setblock ~118 ~35 ~268 minecraft:light_gray_concrete replace
setblock ~142 ~35 ~268 minecraft:light_gray_concrete replace
setblock ~150 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~180 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~269 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~180 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~271 minecraft:light_gray_concrete replace
setblock ~180 ~35 ~273 minecraft:light_gray_concrete replace
setblock ~156 ~35 ~275 minecraft:light_gray_concrete replace
setblock ~145 ~35 ~276 minecraft:light_gray_concrete replace
setblock ~169 ~35 ~276 minecraft:light_gray_concrete replace
setblock ~156 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~277 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~279 minecraft:light_gray_concrete replace
setblock ~117 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~213 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~281 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~213 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~283 minecraft:light_gray_concrete replace
setblock ~175 ~35 ~284 minecraft:light_gray_concrete replace
setblock ~259 ~35 ~284 minecraft:light_gray_concrete replace
setblock ~141 ~35 ~285 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~285 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~285 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~285 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~285 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~287 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~287 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~287 minecraft:light_gray_concrete replace
setblock ~171 ~35 ~289 minecraft:light_gray_concrete replace
setblock ~255 ~35 ~289 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~291 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~291 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~291 minecraft:light_gray_concrete replace
setblock ~213 ~35 ~291 minecraft:light_gray_concrete replace
setblock ~255 ~35 ~291 minecraft:light_gray_concrete replace
setblock ~196 ~35 ~292 minecraft:light_gray_concrete replace
setblock ~226 ~35 ~292 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~213 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~293 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~295 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~295 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~295 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~295 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~295 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~295 minecraft:light_gray_concrete replace
setblock ~144 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~297 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~299 minecraft:light_gray_concrete replace
setblock ~229 ~35 ~300 minecraft:light_gray_concrete replace
setblock ~262 ~35 ~300 minecraft:light_gray_concrete replace
setblock ~168 ~35 ~301 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~301 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~301 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~301 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~303 minecraft:light_gray_concrete replace
setblock ~201 ~35 ~305 minecraft:light_gray_concrete replace
setblock ~255 ~35 ~305 minecraft:light_gray_concrete replace
setblock ~303 ~35 ~305 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~307 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~307 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~307 minecraft:light_gray_concrete replace
setblock ~255 ~35 ~307 minecraft:light_gray_concrete replace
setblock ~303 ~35 ~307 minecraft:light_gray_concrete replace
setblock ~265 ~35 ~308 minecraft:light_gray_concrete replace
setblock ~340 ~35 ~308 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~255 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~309 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~311 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~311 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~311 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~311 minecraft:light_gray_concrete replace
setblock ~174 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~313 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~315 minecraft:light_gray_concrete replace
setblock ~337 ~35 ~316 minecraft:light_gray_concrete replace
setblock ~343 ~35 ~316 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~317 minecraft:light_gray_concrete replace
setblock ~240 ~35 ~317 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~317 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~317 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~317 minecraft:light_gray_concrete replace
setblock ~258 ~35 ~321 minecraft:light_gray_concrete replace
setblock ~303 ~35 ~321 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~321 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~303 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~323 minecraft:light_gray_concrete replace
setblock ~286 ~35 ~324 minecraft:light_gray_concrete replace
setblock ~388 ~35 ~324 minecraft:light_gray_concrete replace
setblock ~195 ~35 ~325 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~325 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~325 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~325 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~325 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~325 minecraft:light_gray_concrete replace
setblock ~225 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~329 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~331 minecraft:light_gray_concrete replace
setblock ~355 ~35 ~332 minecraft:light_gray_concrete replace
setblock ~379 ~35 ~332 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~333 minecraft:light_gray_concrete replace
setblock ~246 ~35 ~333 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~333 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~333 minecraft:light_gray_concrete replace
setblock ~303 ~35 ~335 minecraft:light_gray_concrete replace
setblock ~303 ~35 ~337 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~337 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~337 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~339 minecraft:light_gray_concrete replace
setblock ~228 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~341 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~343 minecraft:light_gray_concrete replace
setblock ~261 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~345 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~347 minecraft:light_gray_concrete replace
setblock ~282 ~35 ~349 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~353 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~353 minecraft:light_gray_concrete replace
setblock ~333 ~35 ~353 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~353 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~355 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~264 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~357 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~359 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~315 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~361 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~363 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~365 minecraft:light_gray_concrete replace
setblock ~324 ~35 ~365 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~367 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~367 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~369 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~369 minecraft:light_gray_concrete replace
setblock ~339 ~35 ~369 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~369 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~371 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~373 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~373 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~373 minecraft:light_gray_concrete replace
setblock ~318 ~35 ~373 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~373 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~373 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~375 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~375 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~375 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~336 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~377 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~379 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~379 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~379 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~379 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~379 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~379 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~381 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~381 minecraft:light_gray_concrete replace
setblock ~342 ~35 ~381 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~383 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~383 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~383 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~385 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~385 minecraft:light_gray_concrete replace
setblock ~285 ~35 ~385 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~385 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~385 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~387 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~387 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~387 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~387 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~387 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~389 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~389 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~389 minecraft:light_gray_concrete replace
setblock ~327 ~35 ~389 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~389 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~391 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~391 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~391 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~348 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~393 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~395 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~395 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~395 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~395 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~395 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~395 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~397 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~397 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~397 minecraft:light_gray_concrete replace
setblock ~387 ~35 ~397 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~399 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~399 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~399 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~401 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~401 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~401 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~401 minecraft:light_gray_concrete replace
setblock ~354 ~35 ~401 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~403 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~403 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~403 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~403 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~403 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~405 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~405 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~405 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~405 minecraft:light_gray_concrete replace
setblock ~360 ~35 ~405 minecraft:light_gray_concrete replace
setblock ~87 ~35 ~407 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~407 minecraft:light_gray_concrete replace
setblock ~207 ~35 ~407 minecraft:light_gray_concrete replace
setblock ~243 ~35 ~407 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~407 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~409 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~409 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~409 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~409 minecraft:light_gray_concrete replace
setblock ~378 ~35 ~409 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~411 minecraft:light_gray_concrete replace
setblock ~111 ~35 ~411 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~411 minecraft:light_gray_concrete replace
setblock ~237 ~35 ~411 minecraft:light_gray_concrete replace
setblock ~279 ~35 ~411 minecraft:light_gray_concrete replace
setblock ~90 ~35 ~413 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~413 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~413 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~413 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~413 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~415 minecraft:light_gray_concrete replace
setblock ~135 ~35 ~415 minecraft:light_gray_concrete replace
setblock ~186 ~35 ~415 minecraft:light_gray_concrete replace
setblock ~276 ~35 ~415 minecraft:light_gray_concrete replace
setblock ~309 ~35 ~415 minecraft:light_gray_concrete replace
setblock ~114 ~35 ~417 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~417 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~417 minecraft:light_gray_concrete replace
setblock ~306 ~35 ~417 minecraft:light_gray_concrete replace
setblock ~345 ~35 ~417 minecraft:light_gray_concrete replace
setblock ~138 ~35 ~419 minecraft:light_gray_concrete replace
setblock ~183 ~35 ~419 minecraft:light_gray_concrete replace
setblock ~216 ~35 ~419 minecraft:light_gray_concrete replace
