fill ~117 ~140 ~622 ~176 ~140 ~622 minecraft:light_gray_concrete replace
fill ~157 ~140 ~623 ~157 ~140 ~624 minecraft:light_gray_concrete replace
fill ~160 ~140 ~623 ~160 ~140 ~624 minecraft:light_gray_concrete replace
fill ~163 ~140 ~623 ~163 ~140 ~624 minecraft:light_gray_concrete replace
fill ~166 ~140 ~623 ~166 ~140 ~624 minecraft:light_gray_concrete replace
fill ~169 ~140 ~623 ~169 ~140 ~624 minecraft:light_gray_concrete replace
fill ~172 ~140 ~623 ~172 ~140 ~624 minecraft:light_gray_concrete replace
fill ~175 ~140 ~623 ~175 ~140 ~624 minecraft:light_gray_concrete replace
fill ~129 ~140 ~646 ~185 ~140 ~646 minecraft:light_gray_concrete replace
fill ~184 ~140 ~647 ~184 ~140 ~648 minecraft:light_gray_concrete replace
fill ~84 ~140 ~650 ~86 ~140 ~650 minecraft:light_gray_concrete replace
fill ~85 ~140 ~651 ~85 ~140 ~652 minecraft:light_gray_concrete replace
fill ~123 ~140 ~654 ~179 ~140 ~654 minecraft:light_gray_concrete replace
fill ~178 ~140 ~655 ~178 ~140 ~656 minecraft:light_gray_concrete replace
fill ~126 ~140 ~662 ~182 ~140 ~662 minecraft:light_gray_concrete replace
fill ~181 ~140 ~663 ~181 ~140 ~664 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~386 minecraft:light_gray_concrete replace
setblock ~108 ~141 ~386 minecraft:light_gray_concrete replace
setblock ~112 ~141 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~141 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~91 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~94 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~100 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~103 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~115 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~79 ~141 ~452 minecraft:light_gray_concrete replace
setblock ~88 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~94 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~97 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~100 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~88 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~91 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~97 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~91 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~115 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~514 minecraft:light_gray_concrete replace
setblock ~111 ~141 ~514 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~139 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~142 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~148 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~123 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~140 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~142 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~145 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~154 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~120 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~135 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~137 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~145 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~123 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~140 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~145 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~148 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~123 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~140 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~157 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~160 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~163 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~172 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~129 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~144 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~146 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~160 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~163 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~169 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~175 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~126 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~141 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~143 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~157 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~160 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~163 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~169 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~172 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~175 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~153 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~155 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~170 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~172 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~184 ~141 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~141 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~132 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~147 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~149 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~164 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~178 ~141 ~656 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~135 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~150 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~152 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~167 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~169 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~181 ~141 ~664 minecraft:light_gray_concrete replace
fill ~111 ~142 ~384 ~111 ~142 ~388 minecraft:light_gray_concrete replace
fill ~81 ~142 ~396 ~81 ~142 ~400 minecraft:light_gray_concrete replace
fill ~114 ~142 ~416 ~114 ~142 ~504 minecraft:light_gray_concrete replace
fill ~105 ~142 ~420 ~105 ~142 ~504 minecraft:light_gray_concrete replace
fill ~102 ~142 ~424 ~102 ~142 ~484 minecraft:light_gray_concrete replace
fill ~99 ~142 ~428 ~99 ~142 ~504 minecraft:light_gray_concrete replace
fill ~96 ~142 ~432 ~96 ~142 ~484 minecraft:light_gray_concrete replace
fill ~93 ~142 ~436 ~93 ~142 ~504 minecraft:light_gray_concrete replace
fill ~90 ~142 ~440 ~90 ~142 ~504 minecraft:light_gray_concrete replace
fill ~87 ~142 ~444 ~87 ~142 ~484 minecraft:light_gray_concrete replace
fill ~78 ~142 ~448 ~78 ~142 ~452 minecraft:light_gray_concrete replace
fill ~120 ~142 ~468 ~120 ~142 ~504 minecraft:light_gray_concrete replace
fill ~108 ~142 ~472 ~108 ~142 ~504 minecraft:light_gray_concrete replace
fill ~117 ~142 ~480 ~117 ~142 ~484 minecraft:light_gray_concrete replace
fill ~147 ~142 ~484 ~147 ~142 ~568 minecraft:light_gray_concrete replace
fill ~141 ~142 ~488 ~141 ~142 ~568 minecraft:light_gray_concrete replace
fill ~138 ~142 ~492 ~138 ~142 ~548 minecraft:light_gray_concrete replace
fill ~135 ~142 ~496 ~135 ~142 ~568 minecraft:light_gray_concrete replace
fill ~132 ~142 ~500 ~132 ~142 ~548 minecraft:light_gray_concrete replace
fill ~129 ~142 ~504 ~129 ~142 ~568 minecraft:light_gray_concrete replace
fill ~126 ~142 ~508 ~126 ~142 ~568 minecraft:light_gray_concrete replace
fill ~123 ~142 ~512 ~123 ~142 ~548 minecraft:light_gray_concrete replace
fill ~153 ~142 ~532 ~153 ~142 ~568 minecraft:light_gray_concrete replace
fill ~144 ~142 ~536 ~144 ~142 ~568 minecraft:light_gray_concrete replace
fill ~150 ~142 ~544 ~150 ~142 ~548 minecraft:light_gray_concrete replace
fill ~171 ~142 ~560 ~171 ~142 ~624 minecraft:light_gray_concrete replace
fill ~165 ~142 ~564 ~165 ~142 ~624 minecraft:light_gray_concrete replace
fill ~162 ~142 ~568 ~162 ~142 ~624 minecraft:light_gray_concrete replace
fill ~159 ~142 ~572 ~159 ~142 ~624 minecraft:light_gray_concrete replace
fill ~156 ~142 ~576 ~156 ~142 ~624 minecraft:light_gray_concrete replace
fill ~174 ~142 ~604 ~174 ~142 ~624 minecraft:light_gray_concrete replace
fill ~168 ~142 ~608 ~168 ~142 ~624 minecraft:light_gray_concrete replace
fill ~183 ~142 ~644 ~183 ~142 ~648 minecraft:light_gray_concrete replace
fill ~84 ~142 ~648 ~84 ~142 ~652 minecraft:light_gray_concrete replace
fill ~177 ~142 ~652 ~177 ~142 ~656 minecraft:light_gray_concrete replace
fill ~180 ~142 ~660 ~180 ~142 ~664 minecraft:light_gray_concrete replace
setblock ~111 ~143 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~143 ~395 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~415 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~417 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~419 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~423 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~425 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~425 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~427 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~427 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~429 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~431 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~435 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~437 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~437 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~439 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~439 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~439 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~441 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~441 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~78 ~143 ~447 minecraft:light_gray_concrete replace
setblock ~91 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~106 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~115 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~453 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~453 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~453 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~455 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~455 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~455 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~457 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~457 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~461 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~461 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~461 minecraft:light_gray_concrete replace
setblock ~120 ~143 ~467 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~469 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~469 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~469 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~108 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~473 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~473 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~475 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~475 minecraft:light_gray_concrete replace
setblock ~94 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~109 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~121 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~117 ~143 ~479 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~483 minecraft:light_gray_concrete replace
setblock ~88 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~97 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~487 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~108 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~120 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~120 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~493 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~493 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~495 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~497 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~499 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~501 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~501 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~503 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~503 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~503 minecraft:light_gray_concrete replace
setblock ~94 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~115 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~121 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~505 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~511 minecraft:light_gray_concrete replace
setblock ~127 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~133 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~142 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~148 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~517 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~517 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~517 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~519 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~519 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~519 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~521 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~521 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~525 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~525 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~525 minecraft:light_gray_concrete replace
setblock ~153 ~143 ~531 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~533 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~533 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~533 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~144 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~537 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~537 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~539 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~539 minecraft:light_gray_concrete replace
setblock ~130 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~142 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~145 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~154 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~150 ~143 ~543 minecraft:light_gray_concrete replace
setblock ~124 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~133 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~144 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~153 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~559 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~563 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~563 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~565 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~565 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~567 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~567 minecraft:light_gray_concrete replace
setblock ~130 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~136 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~148 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~569 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~571 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~573 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~575 minecraft:light_gray_concrete replace
setblock ~157 ~143 ~580 minecraft:light_gray_concrete replace
setblock ~166 ~143 ~580 minecraft:light_gray_concrete replace
setblock ~172 ~143 ~580 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~593 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~593 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~597 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~597 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~597 minecraft:light_gray_concrete replace
setblock ~174 ~143 ~603 minecraft:light_gray_concrete replace
setblock ~168 ~143 ~607 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~609 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~609 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~611 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~611 minecraft:light_gray_concrete replace
setblock ~160 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~166 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~169 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~175 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~160 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~163 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~166 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~172 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~175 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~183 ~143 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~143 ~647 minecraft:light_gray_concrete replace
setblock ~177 ~143 ~651 minecraft:light_gray_concrete replace
setblock ~180 ~143 ~659 minecraft:light_gray_concrete replace
fill ~97 ~144 ~380 ~97 ~144 ~381 minecraft:light_gray_concrete replace
fill ~96 ~144 ~382 ~111 ~144 ~382 minecraft:light_gray_concrete replace
fill ~82 ~144 ~392 ~82 ~144 ~393 minecraft:light_gray_concrete replace
fill ~81 ~144 ~394 ~83 ~144 ~394 minecraft:light_gray_concrete replace
fill ~100 ~144 ~412 ~100 ~144 ~413 minecraft:light_gray_concrete replace
fill ~99 ~144 ~414 ~114 ~144 ~414 minecraft:light_gray_concrete replace
fill ~94 ~144 ~416 ~94 ~144 ~417 minecraft:light_gray_concrete replace
fill ~93 ~144 ~418 ~105 ~144 ~418 minecraft:light_gray_concrete replace
fill ~94 ~144 ~420 ~94 ~144 ~421 minecraft:light_gray_concrete replace
fill ~93 ~144 ~422 ~102 ~144 ~422 minecraft:light_gray_concrete replace
fill ~91 ~144 ~424 ~91 ~144 ~425 minecraft:light_gray_concrete replace
fill ~90 ~144 ~426 ~99 ~144 ~426 minecraft:light_gray_concrete replace
fill ~91 ~144 ~428 ~91 ~144 ~429 minecraft:light_gray_concrete replace
fill ~90 ~144 ~430 ~96 ~144 ~430 minecraft:light_gray_concrete replace
fill ~88 ~144 ~432 ~88 ~144 ~433 minecraft:light_gray_concrete replace
fill ~87 ~144 ~434 ~93 ~144 ~434 minecraft:light_gray_concrete replace
fill ~88 ~144 ~436 ~88 ~144 ~437 minecraft:light_gray_concrete replace
fill ~87 ~144 ~438 ~90 ~144 ~438 minecraft:light_gray_concrete replace
fill ~88 ~144 ~440 ~88 ~144 ~441 minecraft:light_gray_concrete replace
fill ~87 ~144 ~442 ~89 ~144 ~442 minecraft:light_gray_concrete replace
fill ~79 ~144 ~444 ~79 ~144 ~445 minecraft:light_gray_concrete replace
fill ~78 ~144 ~446 ~80 ~144 ~446 minecraft:light_gray_concrete replace
fill ~100 ~144 ~464 ~100 ~144 ~465 minecraft:light_gray_concrete replace
fill ~99 ~144 ~466 ~120 ~144 ~466 minecraft:light_gray_concrete replace
fill ~94 ~144 ~468 ~94 ~144 ~469 minecraft:light_gray_concrete replace
fill ~93 ~144 ~470 ~108 ~144 ~470 minecraft:light_gray_concrete replace
fill ~100 ~144 ~476 ~100 ~144 ~477 minecraft:light_gray_concrete replace
fill ~99 ~144 ~478 ~117 ~144 ~478 minecraft:light_gray_concrete replace
fill ~112 ~144 ~480 ~112 ~144 ~481 minecraft:light_gray_concrete replace
fill ~111 ~144 ~482 ~147 ~144 ~482 minecraft:light_gray_concrete replace
fill ~109 ~144 ~484 ~109 ~144 ~485 minecraft:light_gray_concrete replace
fill ~108 ~144 ~486 ~141 ~144 ~486 minecraft:light_gray_concrete replace
fill ~109 ~144 ~488 ~109 ~144 ~489 minecraft:light_gray_concrete replace
fill ~108 ~144 ~490 ~138 ~144 ~490 minecraft:light_gray_concrete replace
fill ~106 ~144 ~492 ~106 ~144 ~493 minecraft:light_gray_concrete replace
fill ~105 ~144 ~494 ~135 ~144 ~494 minecraft:light_gray_concrete replace
fill ~106 ~144 ~496 ~106 ~144 ~497 minecraft:light_gray_concrete replace
fill ~105 ~144 ~498 ~132 ~144 ~498 minecraft:light_gray_concrete replace
fill ~103 ~144 ~500 ~103 ~144 ~501 minecraft:light_gray_concrete replace
fill ~102 ~144 ~502 ~129 ~144 ~502 minecraft:light_gray_concrete replace
fill ~103 ~144 ~504 ~103 ~144 ~505 minecraft:light_gray_concrete replace
fill ~102 ~144 ~506 ~126 ~144 ~506 minecraft:light_gray_concrete replace
fill ~103 ~144 ~508 ~103 ~144 ~509 minecraft:light_gray_concrete replace
fill ~102 ~144 ~510 ~123 ~144 ~510 minecraft:light_gray_concrete replace
fill ~112 ~144 ~528 ~112 ~144 ~529 minecraft:light_gray_concrete replace
fill ~111 ~144 ~530 ~153 ~144 ~530 minecraft:light_gray_concrete replace
fill ~109 ~144 ~532 ~109 ~144 ~533 minecraft:light_gray_concrete replace
fill ~108 ~144 ~534 ~144 ~144 ~534 minecraft:light_gray_concrete replace
fill ~112 ~144 ~540 ~112 ~144 ~541 minecraft:light_gray_concrete replace
fill ~111 ~144 ~542 ~150 ~144 ~542 minecraft:light_gray_concrete replace
fill ~124 ~144 ~556 ~124 ~144 ~557 minecraft:light_gray_concrete replace
fill ~123 ~144 ~558 ~171 ~144 ~558 minecraft:light_gray_concrete replace
fill ~121 ~144 ~560 ~121 ~144 ~561 minecraft:light_gray_concrete replace
fill ~120 ~144 ~562 ~165 ~144 ~562 minecraft:light_gray_concrete replace
fill ~118 ~144 ~564 ~118 ~144 ~565 minecraft:light_gray_concrete replace
fill ~117 ~144 ~566 ~162 ~144 ~566 minecraft:light_gray_concrete replace
fill ~115 ~144 ~568 ~115 ~144 ~569 minecraft:light_gray_concrete replace
fill ~114 ~144 ~570 ~159 ~144 ~570 minecraft:light_gray_concrete replace
fill ~115 ~144 ~572 ~115 ~144 ~573 minecraft:light_gray_concrete replace
fill ~114 ~144 ~574 ~156 ~144 ~574 minecraft:light_gray_concrete replace
fill ~124 ~144 ~600 ~124 ~144 ~601 minecraft:light_gray_concrete replace
fill ~123 ~144 ~602 ~174 ~144 ~602 minecraft:light_gray_concrete replace
fill ~121 ~144 ~604 ~121 ~144 ~605 minecraft:light_gray_concrete replace
fill ~120 ~144 ~606 ~168 ~144 ~606 minecraft:light_gray_concrete replace
fill ~133 ~144 ~640 ~133 ~144 ~641 minecraft:light_gray_concrete replace
fill ~132 ~144 ~642 ~183 ~144 ~642 minecraft:light_gray_concrete replace
fill ~85 ~144 ~644 ~85 ~144 ~645 minecraft:light_gray_concrete replace
fill ~84 ~144 ~646 ~86 ~144 ~646 minecraft:light_gray_concrete replace
fill ~127 ~144 ~648 ~127 ~144 ~649 minecraft:light_gray_concrete replace
fill ~126 ~144 ~650 ~177 ~144 ~650 minecraft:light_gray_concrete replace
fill ~130 ~144 ~656 ~130 ~144 ~657 minecraft:light_gray_concrete replace
fill ~129 ~144 ~658 ~180 ~144 ~658 minecraft:light_gray_concrete replace
setblock ~97 ~145 ~380 minecraft:light_gray_concrete replace
setblock ~102 ~145 ~382 minecraft:light_gray_concrete replace
setblock ~104 ~145 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~145 ~392 minecraft:light_gray_concrete replace
setblock ~100 ~145 ~412 minecraft:light_gray_concrete replace
setblock ~94 ~145 ~416 minecraft:light_gray_concrete replace
setblock ~97 ~145 ~418 minecraft:light_gray_concrete replace
setblock ~99 ~145 ~418 minecraft:light_gray_concrete replace
setblock ~94 ~145 ~420 minecraft:light_gray_concrete replace
setblock ~91 ~145 ~424 minecraft:light_gray_concrete replace
setblock ~91 ~145 ~428 minecraft:light_gray_concrete replace
setblock ~88 ~145 ~432 minecraft:light_gray_concrete replace
setblock ~88 ~145 ~436 minecraft:light_gray_concrete replace
setblock ~88 ~145 ~440 minecraft:light_gray_concrete replace
setblock ~79 ~145 ~444 minecraft:light_gray_concrete replace
setblock ~100 ~145 ~464 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~466 minecraft:light_gray_concrete replace
setblock ~114 ~145 ~466 minecraft:light_gray_concrete replace
setblock ~94 ~145 ~468 minecraft:light_gray_concrete replace
setblock ~96 ~145 ~470 minecraft:light_gray_concrete replace
setblock ~98 ~145 ~470 minecraft:light_gray_concrete replace
setblock ~100 ~145 ~476 minecraft:light_gray_concrete replace
setblock ~108 ~145 ~478 minecraft:light_gray_concrete replace
setblock ~110 ~145 ~478 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~480 minecraft:light_gray_concrete replace
setblock ~120 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~122 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~137 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~139 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~109 ~145 ~484 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~114 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~129 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~131 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~109 ~145 ~488 minecraft:light_gray_concrete replace
setblock ~123 ~145 ~490 minecraft:light_gray_concrete replace
setblock ~125 ~145 ~490 minecraft:light_gray_concrete replace
setblock ~106 ~145 ~492 minecraft:light_gray_concrete replace
setblock ~120 ~145 ~494 minecraft:light_gray_concrete replace
setblock ~122 ~145 ~494 minecraft:light_gray_concrete replace
setblock ~106 ~145 ~496 minecraft:light_gray_concrete replace
setblock ~118 ~145 ~498 minecraft:light_gray_concrete replace
setblock ~120 ~145 ~498 minecraft:light_gray_concrete replace
setblock ~103 ~145 ~500 minecraft:light_gray_concrete replace
setblock ~117 ~145 ~502 minecraft:light_gray_concrete replace
setblock ~119 ~145 ~502 minecraft:light_gray_concrete replace
setblock ~103 ~145 ~504 minecraft:light_gray_concrete replace
setblock ~111 ~145 ~506 minecraft:light_gray_concrete replace
setblock ~113 ~145 ~506 minecraft:light_gray_concrete replace
setblock ~103 ~145 ~508 minecraft:light_gray_concrete replace
setblock ~114 ~145 ~510 minecraft:light_gray_concrete replace
setblock ~116 ~145 ~510 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~528 minecraft:light_gray_concrete replace
setblock ~128 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~130 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~145 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~147 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~109 ~145 ~532 minecraft:light_gray_concrete replace
setblock ~115 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~117 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~132 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~540 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~126 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~141 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~143 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~556 minecraft:light_gray_concrete replace
setblock ~125 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~142 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~144 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~159 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~161 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~121 ~145 ~560 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~136 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~151 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~153 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~118 ~145 ~564 minecraft:light_gray_concrete replace
setblock ~130 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~132 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~147 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~149 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~115 ~145 ~568 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~129 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~144 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~146 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~115 ~145 ~572 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~129 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~144 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~146 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~600 minecraft:light_gray_concrete replace
setblock ~132 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~149 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~151 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~166 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~168 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~121 ~145 ~604 minecraft:light_gray_concrete replace
setblock ~122 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~139 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~141 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~156 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~158 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~133 ~145 ~640 minecraft:light_gray_concrete replace
setblock ~140 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~142 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~157 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~159 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~174 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~176 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~145 ~644 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~648 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~136 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~151 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~153 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~168 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~170 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~130 ~145 ~656 minecraft:light_gray_concrete replace
setblock ~137 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~139 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~154 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~156 ~145 ~658 minecraft:light_gray_concrete replace
