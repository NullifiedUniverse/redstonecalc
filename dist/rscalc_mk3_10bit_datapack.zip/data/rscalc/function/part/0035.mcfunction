setblock ~476 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~494 ~442 ~169 ~504 minecraft:redstone_wire replace
fill ~450 ~169 ~494 ~450 ~169 ~504 minecraft:redstone_wire replace
fill ~456 ~169 ~494 ~456 ~169 ~504 minecraft:redstone_wire replace
fill ~462 ~169 ~494 ~462 ~169 ~504 minecraft:redstone_wire replace
fill ~470 ~169 ~494 ~470 ~169 ~504 minecraft:redstone_wire replace
fill ~476 ~169 ~494 ~476 ~169 ~504 minecraft:redstone_wire replace
fill ~502 ~169 ~494 ~502 ~169 ~504 minecraft:redstone_wire replace
setblock ~446 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~498 ~446 ~169 ~508 minecraft:redstone_wire replace
fill ~452 ~169 ~498 ~452 ~169 ~508 minecraft:redstone_wire replace
fill ~454 ~169 ~498 ~454 ~169 ~508 minecraft:redstone_wire replace
fill ~464 ~169 ~498 ~464 ~169 ~508 minecraft:redstone_wire replace
fill ~466 ~169 ~498 ~466 ~169 ~508 minecraft:redstone_wire replace
fill ~468 ~169 ~498 ~468 ~169 ~508 minecraft:redstone_wire replace
fill ~478 ~169 ~498 ~478 ~169 ~508 minecraft:redstone_wire replace
fill ~480 ~169 ~498 ~480 ~169 ~508 minecraft:redstone_wire replace
setblock ~440 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~502 ~440 ~169 ~512 minecraft:redstone_wire replace
fill ~444 ~169 ~502 ~444 ~169 ~512 minecraft:redstone_wire replace
fill ~448 ~169 ~502 ~448 ~169 ~512 minecraft:redstone_wire replace
fill ~458 ~169 ~502 ~458 ~169 ~512 minecraft:redstone_wire replace
fill ~460 ~169 ~502 ~460 ~169 ~512 minecraft:redstone_wire replace
fill ~472 ~169 ~502 ~472 ~169 ~512 minecraft:redstone_wire replace
fill ~474 ~169 ~502 ~474 ~169 ~512 minecraft:redstone_wire replace
setblock ~442 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~506 ~442 ~169 ~516 minecraft:redstone_wire replace
fill ~450 ~169 ~506 ~450 ~169 ~516 minecraft:redstone_wire replace
fill ~456 ~169 ~506 ~456 ~169 ~516 minecraft:redstone_wire replace
fill ~462 ~169 ~506 ~462 ~169 ~516 minecraft:redstone_wire replace
fill ~470 ~169 ~506 ~470 ~169 ~516 minecraft:redstone_wire replace
fill ~476 ~169 ~506 ~476 ~169 ~516 minecraft:redstone_wire replace
fill ~502 ~169 ~506 ~502 ~169 ~516 minecraft:redstone_wire replace
setblock ~446 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~510 ~446 ~169 ~520 minecraft:redstone_wire replace
fill ~452 ~169 ~510 ~452 ~169 ~520 minecraft:redstone_wire replace
fill ~454 ~169 ~510 ~454 ~169 ~520 minecraft:redstone_wire replace
fill ~464 ~169 ~510 ~464 ~169 ~520 minecraft:redstone_wire replace
fill ~466 ~169 ~510 ~466 ~169 ~520 minecraft:redstone_wire replace
fill ~468 ~169 ~510 ~468 ~169 ~520 minecraft:redstone_wire replace
fill ~478 ~169 ~510 ~478 ~169 ~520 minecraft:redstone_wire replace
fill ~480 ~169 ~510 ~480 ~169 ~520 minecraft:redstone_wire replace
setblock ~440 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~514 ~440 ~169 ~524 minecraft:redstone_wire replace
fill ~444 ~169 ~514 ~444 ~169 ~524 minecraft:redstone_wire replace
fill ~448 ~169 ~514 ~448 ~169 ~524 minecraft:redstone_wire replace
fill ~458 ~169 ~514 ~458 ~169 ~524 minecraft:redstone_wire replace
fill ~460 ~169 ~514 ~460 ~169 ~524 minecraft:redstone_wire replace
fill ~472 ~169 ~514 ~472 ~169 ~524 minecraft:redstone_wire replace
fill ~474 ~169 ~514 ~474 ~169 ~524 minecraft:redstone_wire replace
setblock ~442 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~518 ~442 ~169 ~528 minecraft:redstone_wire replace
fill ~450 ~169 ~518 ~450 ~169 ~528 minecraft:redstone_wire replace
fill ~456 ~169 ~518 ~456 ~169 ~528 minecraft:redstone_wire replace
fill ~462 ~169 ~518 ~462 ~169 ~528 minecraft:redstone_wire replace
fill ~470 ~169 ~518 ~470 ~169 ~528 minecraft:redstone_wire replace
fill ~476 ~169 ~518 ~476 ~169 ~528 minecraft:redstone_wire replace
fill ~502 ~169 ~518 ~502 ~169 ~528 minecraft:redstone_wire replace
setblock ~446 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~522 ~446 ~169 ~532 minecraft:redstone_wire replace
fill ~452 ~169 ~522 ~452 ~169 ~532 minecraft:redstone_wire replace
fill ~454 ~169 ~522 ~454 ~169 ~532 minecraft:redstone_wire replace
fill ~464 ~169 ~522 ~464 ~169 ~532 minecraft:redstone_wire replace
fill ~466 ~169 ~522 ~466 ~169 ~532 minecraft:redstone_wire replace
fill ~468 ~169 ~522 ~468 ~169 ~532 minecraft:redstone_wire replace
fill ~478 ~169 ~522 ~478 ~169 ~532 minecraft:redstone_wire replace
fill ~480 ~169 ~522 ~480 ~169 ~532 minecraft:redstone_wire replace
setblock ~440 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~526 ~440 ~169 ~536 minecraft:redstone_wire replace
fill ~444 ~169 ~526 ~444 ~169 ~536 minecraft:redstone_wire replace
fill ~448 ~169 ~526 ~448 ~169 ~536 minecraft:redstone_wire replace
fill ~458 ~169 ~526 ~458 ~169 ~536 minecraft:redstone_wire replace
fill ~460 ~169 ~526 ~460 ~169 ~536 minecraft:redstone_wire replace
fill ~472 ~169 ~526 ~472 ~169 ~536 minecraft:redstone_wire replace
fill ~474 ~169 ~526 ~474 ~169 ~536 minecraft:redstone_wire replace
setblock ~442 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~530 ~442 ~169 ~540 minecraft:redstone_wire replace
fill ~450 ~169 ~530 ~450 ~169 ~540 minecraft:redstone_wire replace
fill ~456 ~169 ~530 ~456 ~169 ~540 minecraft:redstone_wire replace
fill ~462 ~169 ~530 ~462 ~169 ~540 minecraft:redstone_wire replace
fill ~470 ~169 ~530 ~470 ~169 ~540 minecraft:redstone_wire replace
fill ~476 ~169 ~530 ~476 ~169 ~540 minecraft:redstone_wire replace
fill ~502 ~169 ~530 ~502 ~169 ~540 minecraft:redstone_wire replace
setblock ~446 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~534 ~446 ~169 ~544 minecraft:redstone_wire replace
fill ~452 ~169 ~534 ~452 ~169 ~544 minecraft:redstone_wire replace
fill ~454 ~169 ~534 ~454 ~169 ~544 minecraft:redstone_wire replace
fill ~464 ~169 ~534 ~464 ~169 ~544 minecraft:redstone_wire replace
fill ~466 ~169 ~534 ~466 ~169 ~544 minecraft:redstone_wire replace
fill ~478 ~169 ~534 ~478 ~169 ~544 minecraft:redstone_wire replace
fill ~480 ~169 ~534 ~480 ~169 ~544 minecraft:redstone_wire replace
setblock ~440 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~538 ~440 ~169 ~548 minecraft:redstone_wire replace
fill ~444 ~169 ~538 ~444 ~169 ~548 minecraft:redstone_wire replace
fill ~448 ~169 ~538 ~448 ~169 ~548 minecraft:redstone_wire replace
fill ~458 ~169 ~538 ~458 ~169 ~548 minecraft:redstone_wire replace
fill ~460 ~169 ~538 ~460 ~169 ~548 minecraft:redstone_wire replace
fill ~472 ~169 ~538 ~472 ~169 ~548 minecraft:redstone_wire replace
fill ~474 ~169 ~538 ~474 ~169 ~548 minecraft:redstone_wire replace
setblock ~442 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~542 ~442 ~169 ~552 minecraft:redstone_wire replace
fill ~450 ~169 ~542 ~450 ~169 ~552 minecraft:redstone_wire replace
fill ~456 ~169 ~542 ~456 ~169 ~552 minecraft:redstone_wire replace
fill ~462 ~169 ~542 ~462 ~169 ~552 minecraft:redstone_wire replace
fill ~470 ~169 ~542 ~470 ~169 ~552 minecraft:redstone_wire replace
fill ~476 ~169 ~542 ~476 ~169 ~552 minecraft:redstone_wire replace
fill ~502 ~169 ~542 ~502 ~169 ~552 minecraft:redstone_wire replace
setblock ~446 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~546 ~446 ~169 ~556 minecraft:redstone_wire replace
fill ~452 ~169 ~546 ~452 ~169 ~556 minecraft:redstone_wire replace
fill ~454 ~169 ~546 ~454 ~169 ~556 minecraft:redstone_wire replace
fill ~464 ~169 ~546 ~464 ~169 ~556 minecraft:redstone_wire replace
fill ~466 ~169 ~546 ~466 ~169 ~556 minecraft:redstone_wire replace
fill ~478 ~169 ~546 ~478 ~169 ~556 minecraft:redstone_wire replace
fill ~480 ~169 ~546 ~480 ~169 ~556 minecraft:redstone_wire replace
setblock ~440 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~550 ~440 ~169 ~560 minecraft:redstone_wire replace
fill ~444 ~169 ~550 ~444 ~169 ~560 minecraft:redstone_wire replace
fill ~448 ~169 ~550 ~448 ~169 ~560 minecraft:redstone_wire replace
fill ~458 ~169 ~550 ~458 ~169 ~560 minecraft:redstone_wire replace
fill ~460 ~169 ~550 ~460 ~169 ~560 minecraft:redstone_wire replace
fill ~472 ~169 ~550 ~472 ~169 ~560 minecraft:redstone_wire replace
fill ~474 ~169 ~550 ~474 ~169 ~560 minecraft:redstone_wire replace
setblock ~442 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~553 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~554 ~442 ~169 ~564 minecraft:redstone_wire replace
fill ~450 ~169 ~554 ~450 ~169 ~564 minecraft:redstone_wire replace
fill ~456 ~169 ~554 ~456 ~169 ~564 minecraft:redstone_wire replace
fill ~462 ~169 ~554 ~462 ~169 ~564 minecraft:redstone_wire replace
fill ~470 ~169 ~554 ~470 ~169 ~564 minecraft:redstone_wire replace
fill ~476 ~169 ~554 ~476 ~169 ~564 minecraft:redstone_wire replace
fill ~502 ~169 ~554 ~502 ~169 ~564 minecraft:redstone_wire replace
setblock ~446 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~557 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~558 ~446 ~169 ~568 minecraft:redstone_wire replace
fill ~452 ~169 ~558 ~452 ~169 ~568 minecraft:redstone_wire replace
fill ~454 ~169 ~558 ~454 ~169 ~568 minecraft:redstone_wire replace
fill ~464 ~169 ~558 ~464 ~169 ~568 minecraft:redstone_wire replace
fill ~466 ~169 ~558 ~466 ~169 ~568 minecraft:redstone_wire replace
fill ~478 ~169 ~558 ~478 ~169 ~568 minecraft:redstone_wire replace
fill ~480 ~169 ~558 ~480 ~169 ~568 minecraft:redstone_wire replace
setblock ~440 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~561 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~562 ~440 ~169 ~572 minecraft:redstone_wire replace
fill ~444 ~169 ~562 ~444 ~169 ~572 minecraft:redstone_wire replace
fill ~448 ~169 ~562 ~448 ~169 ~572 minecraft:redstone_wire replace
fill ~458 ~169 ~562 ~458 ~169 ~572 minecraft:redstone_wire replace
fill ~460 ~169 ~562 ~460 ~169 ~572 minecraft:redstone_wire replace
fill ~472 ~169 ~562 ~472 ~169 ~572 minecraft:redstone_wire replace
fill ~474 ~169 ~562 ~474 ~169 ~572 minecraft:redstone_wire replace
setblock ~442 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~565 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~566 ~442 ~169 ~576 minecraft:redstone_wire replace
fill ~450 ~169 ~566 ~450 ~169 ~576 minecraft:redstone_wire replace
fill ~456 ~169 ~566 ~456 ~169 ~576 minecraft:redstone_wire replace
fill ~462 ~169 ~566 ~462 ~169 ~576 minecraft:redstone_wire replace
fill ~476 ~169 ~566 ~476 ~169 ~576 minecraft:redstone_wire replace
fill ~502 ~169 ~566 ~502 ~169 ~576 minecraft:redstone_wire replace
setblock ~446 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~569 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~570 ~446 ~169 ~580 minecraft:redstone_wire replace
fill ~452 ~169 ~570 ~452 ~169 ~580 minecraft:redstone_wire replace
fill ~454 ~169 ~570 ~454 ~169 ~580 minecraft:redstone_wire replace
fill ~464 ~169 ~570 ~464 ~169 ~580 minecraft:redstone_wire replace
fill ~466 ~169 ~570 ~466 ~169 ~580 minecraft:redstone_wire replace
fill ~478 ~169 ~570 ~478 ~169 ~580 minecraft:redstone_wire replace
fill ~480 ~169 ~570 ~480 ~169 ~580 minecraft:redstone_wire replace
setblock ~440 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~573 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~574 ~440 ~169 ~584 minecraft:redstone_wire replace
fill ~444 ~169 ~574 ~444 ~169 ~584 minecraft:redstone_wire replace
fill ~448 ~169 ~574 ~448 ~169 ~584 minecraft:redstone_wire replace
fill ~458 ~169 ~574 ~458 ~169 ~584 minecraft:redstone_wire replace
fill ~460 ~169 ~574 ~460 ~169 ~584 minecraft:redstone_wire replace
fill ~472 ~169 ~574 ~472 ~169 ~584 minecraft:redstone_wire replace
fill ~474 ~169 ~574 ~474 ~169 ~584 minecraft:redstone_wire replace
setblock ~442 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~577 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~578 ~442 ~169 ~588 minecraft:redstone_wire replace
fill ~450 ~169 ~578 ~450 ~169 ~588 minecraft:redstone_wire replace
fill ~456 ~169 ~578 ~456 ~169 ~588 minecraft:redstone_wire replace
fill ~462 ~169 ~578 ~462 ~169 ~588 minecraft:redstone_wire replace
fill ~476 ~169 ~578 ~476 ~169 ~588 minecraft:redstone_wire replace
fill ~502 ~169 ~578 ~502 ~169 ~588 minecraft:redstone_wire replace
setblock ~446 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~581 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~582 ~446 ~169 ~592 minecraft:redstone_wire replace
fill ~452 ~169 ~582 ~452 ~169 ~592 minecraft:redstone_wire replace
fill ~454 ~169 ~582 ~454 ~169 ~592 minecraft:redstone_wire replace
fill ~464 ~169 ~582 ~464 ~169 ~592 minecraft:redstone_wire replace
fill ~466 ~169 ~582 ~466 ~169 ~592 minecraft:redstone_wire replace
fill ~478 ~169 ~582 ~478 ~169 ~592 minecraft:redstone_wire replace
fill ~480 ~169 ~582 ~480 ~169 ~592 minecraft:redstone_wire replace
setblock ~440 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~585 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~586 ~440 ~169 ~596 minecraft:redstone_wire replace
fill ~444 ~169 ~586 ~444 ~169 ~596 minecraft:redstone_wire replace
fill ~448 ~169 ~586 ~448 ~169 ~596 minecraft:redstone_wire replace
fill ~458 ~169 ~586 ~458 ~169 ~596 minecraft:redstone_wire replace
fill ~460 ~169 ~586 ~460 ~169 ~596 minecraft:redstone_wire replace
fill ~472 ~169 ~586 ~472 ~169 ~596 minecraft:redstone_wire replace
fill ~474 ~169 ~586 ~474 ~169 ~596 minecraft:redstone_wire replace
setblock ~442 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~589 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~590 ~442 ~169 ~600 minecraft:redstone_wire replace
fill ~450 ~169 ~590 ~450 ~169 ~600 minecraft:redstone_wire replace
fill ~456 ~169 ~590 ~456 ~169 ~600 minecraft:redstone_wire replace
fill ~462 ~169 ~590 ~462 ~169 ~600 minecraft:redstone_wire replace
fill ~476 ~169 ~590 ~476 ~169 ~600 minecraft:redstone_wire replace
fill ~502 ~169 ~590 ~502 ~169 ~600 minecraft:redstone_wire replace
setblock ~446 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~593 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~594 ~446 ~169 ~604 minecraft:redstone_wire replace
fill ~452 ~169 ~594 ~452 ~169 ~604 minecraft:redstone_wire replace
fill ~454 ~169 ~594 ~454 ~169 ~604 minecraft:redstone_wire replace
fill ~464 ~169 ~594 ~464 ~169 ~604 minecraft:redstone_wire replace
fill ~466 ~169 ~594 ~466 ~169 ~604 minecraft:redstone_wire replace
fill ~478 ~169 ~594 ~478 ~169 ~604 minecraft:redstone_wire replace
fill ~480 ~169 ~594 ~480 ~169 ~604 minecraft:redstone_wire replace
setblock ~440 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~597 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~598 ~440 ~169 ~608 minecraft:redstone_wire replace
fill ~444 ~169 ~598 ~444 ~169 ~608 minecraft:redstone_wire replace
fill ~448 ~169 ~598 ~448 ~169 ~608 minecraft:redstone_wire replace
fill ~458 ~169 ~598 ~458 ~169 ~608 minecraft:redstone_wire replace
fill ~460 ~169 ~598 ~460 ~169 ~608 minecraft:redstone_wire replace
fill ~474 ~169 ~598 ~474 ~169 ~608 minecraft:redstone_wire replace
setblock ~442 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~601 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~602 ~442 ~169 ~612 minecraft:redstone_wire replace
fill ~450 ~169 ~602 ~450 ~169 ~612 minecraft:redstone_wire replace
fill ~456 ~169 ~602 ~456 ~169 ~612 minecraft:redstone_wire replace
fill ~462 ~169 ~602 ~462 ~169 ~612 minecraft:redstone_wire replace
fill ~476 ~169 ~602 ~476 ~169 ~612 minecraft:redstone_wire replace
fill ~502 ~169 ~602 ~502 ~169 ~612 minecraft:redstone_wire replace
setblock ~446 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~605 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~606 ~446 ~169 ~616 minecraft:redstone_wire replace
fill ~452 ~169 ~606 ~452 ~169 ~616 minecraft:redstone_wire replace
fill ~454 ~169 ~606 ~454 ~169 ~616 minecraft:redstone_wire replace
fill ~464 ~169 ~606 ~464 ~169 ~616 minecraft:redstone_wire replace
fill ~466 ~169 ~606 ~466 ~169 ~616 minecraft:redstone_wire replace
fill ~478 ~169 ~606 ~478 ~169 ~616 minecraft:redstone_wire replace
fill ~480 ~169 ~606 ~480 ~169 ~616 minecraft:redstone_wire replace
setblock ~440 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~609 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~610 ~440 ~169 ~620 minecraft:redstone_wire replace
fill ~444 ~169 ~610 ~444 ~169 ~620 minecraft:redstone_wire replace
fill ~448 ~169 ~610 ~448 ~169 ~620 minecraft:redstone_wire replace
fill ~458 ~169 ~610 ~458 ~169 ~620 minecraft:redstone_wire replace
fill ~460 ~169 ~610 ~460 ~169 ~620 minecraft:redstone_wire replace
fill ~474 ~169 ~610 ~474 ~169 ~620 minecraft:redstone_wire replace
setblock ~442 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~613 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~614 ~442 ~169 ~624 minecraft:redstone_wire replace
fill ~450 ~169 ~614 ~450 ~169 ~624 minecraft:redstone_wire replace
fill ~456 ~169 ~614 ~456 ~169 ~624 minecraft:redstone_wire replace
fill ~462 ~169 ~614 ~462 ~169 ~624 minecraft:redstone_wire replace
fill ~476 ~169 ~614 ~476 ~169 ~624 minecraft:redstone_wire replace
fill ~502 ~169 ~614 ~502 ~169 ~624 minecraft:redstone_wire replace
setblock ~446 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~617 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~618 ~446 ~169 ~628 minecraft:redstone_wire replace
fill ~452 ~169 ~618 ~452 ~169 ~628 minecraft:redstone_wire replace
fill ~454 ~169 ~618 ~454 ~169 ~628 minecraft:redstone_wire replace
fill ~464 ~169 ~618 ~464 ~169 ~628 minecraft:redstone_wire replace
fill ~466 ~169 ~618 ~466 ~169 ~628 minecraft:redstone_wire replace
fill ~478 ~169 ~618 ~478 ~169 ~628 minecraft:redstone_wire replace
fill ~480 ~169 ~618 ~480 ~169 ~628 minecraft:redstone_wire replace
setblock ~440 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~621 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~622 ~440 ~169 ~632 minecraft:redstone_wire replace
fill ~444 ~169 ~622 ~444 ~169 ~632 minecraft:redstone_wire replace
fill ~448 ~169 ~622 ~448 ~169 ~632 minecraft:redstone_wire replace
fill ~458 ~169 ~622 ~458 ~169 ~632 minecraft:redstone_wire replace
fill ~460 ~169 ~622 ~460 ~169 ~632 minecraft:redstone_wire replace
fill ~474 ~169 ~622 ~474 ~169 ~632 minecraft:redstone_wire replace
setblock ~442 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~625 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~626 ~442 ~169 ~636 minecraft:redstone_wire replace
fill ~450 ~169 ~626 ~450 ~169 ~636 minecraft:redstone_wire replace
fill ~456 ~169 ~626 ~456 ~169 ~636 minecraft:redstone_wire replace
fill ~462 ~169 ~626 ~462 ~169 ~636 minecraft:redstone_wire replace
fill ~476 ~169 ~626 ~476 ~169 ~636 minecraft:redstone_wire replace
fill ~502 ~169 ~626 ~502 ~169 ~636 minecraft:redstone_wire replace
setblock ~446 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~629 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~630 ~446 ~169 ~640 minecraft:redstone_wire replace
fill ~452 ~169 ~630 ~452 ~169 ~640 minecraft:redstone_wire replace
fill ~454 ~169 ~630 ~454 ~169 ~640 minecraft:redstone_wire replace
fill ~464 ~169 ~630 ~464 ~169 ~640 minecraft:redstone_wire replace
fill ~466 ~169 ~630 ~466 ~169 ~640 minecraft:redstone_wire replace
fill ~478 ~169 ~630 ~478 ~169 ~640 minecraft:redstone_wire replace
fill ~480 ~169 ~630 ~480 ~169 ~640 minecraft:redstone_wire replace
setblock ~440 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~633 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~634 ~440 ~169 ~644 minecraft:redstone_wire replace
fill ~444 ~169 ~634 ~444 ~169 ~644 minecraft:redstone_wire replace
fill ~448 ~169 ~634 ~448 ~169 ~644 minecraft:redstone_wire replace
fill ~458 ~169 ~634 ~458 ~169 ~644 minecraft:redstone_wire replace
fill ~460 ~169 ~634 ~460 ~169 ~644 minecraft:redstone_wire replace
setblock ~442 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~637 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~638 ~442 ~169 ~648 minecraft:redstone_wire replace
fill ~450 ~169 ~638 ~450 ~169 ~648 minecraft:redstone_wire replace
fill ~456 ~169 ~638 ~456 ~169 ~648 minecraft:redstone_wire replace
fill ~462 ~169 ~638 ~462 ~169 ~648 minecraft:redstone_wire replace
fill ~476 ~169 ~638 ~476 ~169 ~648 minecraft:redstone_wire replace
fill ~502 ~169 ~638 ~502 ~169 ~648 minecraft:redstone_wire replace
setblock ~446 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~641 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~642 ~446 ~169 ~652 minecraft:redstone_wire replace
fill ~452 ~169 ~642 ~452 ~169 ~652 minecraft:redstone_wire replace
fill ~454 ~169 ~642 ~454 ~169 ~652 minecraft:redstone_wire replace
fill ~464 ~169 ~642 ~464 ~169 ~652 minecraft:redstone_wire replace
fill ~466 ~169 ~642 ~466 ~169 ~652 minecraft:redstone_wire replace
fill ~478 ~169 ~642 ~478 ~169 ~652 minecraft:redstone_wire replace
fill ~480 ~169 ~642 ~480 ~169 ~652 minecraft:redstone_wire replace
setblock ~440 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~645 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~646 ~440 ~169 ~656 minecraft:redstone_wire replace
fill ~444 ~169 ~646 ~444 ~169 ~656 minecraft:redstone_wire replace
fill ~448 ~169 ~646 ~448 ~169 ~656 minecraft:redstone_wire replace
fill ~458 ~169 ~646 ~458 ~169 ~656 minecraft:redstone_wire replace
fill ~460 ~169 ~646 ~460 ~169 ~656 minecraft:redstone_wire replace
setblock ~442 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~649 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~650 ~442 ~169 ~660 minecraft:redstone_wire replace
fill ~450 ~169 ~650 ~450 ~169 ~660 minecraft:redstone_wire replace
fill ~456 ~169 ~650 ~456 ~169 ~660 minecraft:redstone_wire replace
fill ~462 ~169 ~650 ~462 ~169 ~660 minecraft:redstone_wire replace
fill ~476 ~169 ~650 ~476 ~169 ~660 minecraft:redstone_wire replace
fill ~502 ~169 ~650 ~502 ~169 ~660 minecraft:redstone_wire replace
setblock ~446 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~653 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~654 ~446 ~169 ~664 minecraft:redstone_wire replace
fill ~452 ~169 ~654 ~452 ~169 ~664 minecraft:redstone_wire replace
fill ~454 ~169 ~654 ~454 ~169 ~664 minecraft:redstone_wire replace
fill ~464 ~169 ~654 ~464 ~169 ~664 minecraft:redstone_wire replace
fill ~466 ~169 ~654 ~466 ~169 ~664 minecraft:redstone_wire replace
fill ~478 ~169 ~654 ~478 ~169 ~664 minecraft:redstone_wire replace
fill ~480 ~169 ~654 ~480 ~169 ~664 minecraft:redstone_wire replace
setblock ~440 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~657 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~658 ~440 ~169 ~668 minecraft:redstone_wire replace
fill ~444 ~169 ~658 ~444 ~169 ~668 minecraft:redstone_wire replace
fill ~448 ~169 ~658 ~448 ~169 ~668 minecraft:redstone_wire replace
fill ~458 ~169 ~658 ~458 ~169 ~668 minecraft:redstone_wire replace
fill ~460 ~169 ~658 ~460 ~169 ~668 minecraft:redstone_wire replace
setblock ~442 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~661 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~662 ~442 ~169 ~672 minecraft:redstone_wire replace
fill ~450 ~169 ~662 ~450 ~169 ~672 minecraft:redstone_wire replace
fill ~456 ~169 ~662 ~456 ~169 ~672 minecraft:redstone_wire replace
fill ~462 ~169 ~662 ~462 ~169 ~672 minecraft:redstone_wire replace
fill ~502 ~169 ~662 ~502 ~169 ~672 minecraft:redstone_wire replace
setblock ~446 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~665 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~666 ~446 ~169 ~676 minecraft:redstone_wire replace
fill ~452 ~169 ~666 ~452 ~169 ~676 minecraft:redstone_wire replace
fill ~454 ~169 ~666 ~454 ~169 ~676 minecraft:redstone_wire replace
fill ~464 ~169 ~666 ~464 ~169 ~676 minecraft:redstone_wire replace
fill ~466 ~169 ~666 ~466 ~169 ~676 minecraft:redstone_wire replace
fill ~478 ~169 ~666 ~478 ~169 ~676 minecraft:redstone_wire replace
fill ~480 ~169 ~666 ~480 ~169 ~676 minecraft:redstone_wire replace
setblock ~440 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~669 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~670 ~440 ~169 ~680 minecraft:redstone_wire replace
fill ~444 ~169 ~670 ~444 ~169 ~680 minecraft:redstone_wire replace
fill ~448 ~169 ~670 ~448 ~169 ~680 minecraft:redstone_wire replace
fill ~458 ~169 ~670 ~458 ~169 ~680 minecraft:redstone_wire replace
fill ~460 ~169 ~670 ~460 ~169 ~680 minecraft:redstone_wire replace
setblock ~442 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~673 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~674 ~442 ~169 ~684 minecraft:redstone_wire replace
fill ~450 ~169 ~674 ~450 ~169 ~684 minecraft:redstone_wire replace
fill ~456 ~169 ~674 ~456 ~169 ~684 minecraft:redstone_wire replace
fill ~462 ~169 ~674 ~462 ~169 ~684 minecraft:redstone_wire replace
fill ~502 ~169 ~674 ~502 ~169 ~684 minecraft:redstone_wire replace
setblock ~446 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~677 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~678 ~446 ~169 ~688 minecraft:redstone_wire replace
fill ~452 ~169 ~678 ~452 ~169 ~688 minecraft:redstone_wire replace
fill ~454 ~169 ~678 ~454 ~169 ~688 minecraft:redstone_wire replace
fill ~464 ~169 ~678 ~464 ~169 ~688 minecraft:redstone_wire replace
fill ~466 ~169 ~678 ~466 ~169 ~688 minecraft:redstone_wire replace
fill ~480 ~169 ~678 ~480 ~169 ~688 minecraft:redstone_wire replace
setblock ~440 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~681 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~682 ~440 ~169 ~692 minecraft:redstone_wire replace
fill ~444 ~169 ~682 ~444 ~169 ~692 minecraft:redstone_wire replace
fill ~448 ~169 ~682 ~448 ~169 ~692 minecraft:redstone_wire replace
fill ~458 ~169 ~682 ~458 ~169 ~692 minecraft:redstone_wire replace
fill ~460 ~169 ~682 ~460 ~169 ~692 minecraft:redstone_wire replace
setblock ~442 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~685 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~686 ~442 ~169 ~696 minecraft:redstone_wire replace
fill ~450 ~169 ~686 ~450 ~169 ~696 minecraft:redstone_wire replace
fill ~456 ~169 ~686 ~456 ~169 ~696 minecraft:redstone_wire replace
fill ~462 ~169 ~686 ~462 ~169 ~696 minecraft:redstone_wire replace
fill ~502 ~169 ~686 ~502 ~169 ~696 minecraft:redstone_wire replace
setblock ~446 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~689 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~690 ~446 ~169 ~700 minecraft:redstone_wire replace
fill ~452 ~169 ~690 ~452 ~169 ~700 minecraft:redstone_wire replace
fill ~454 ~169 ~690 ~454 ~169 ~700 minecraft:redstone_wire replace
fill ~464 ~169 ~690 ~464 ~169 ~700 minecraft:redstone_wire replace
fill ~466 ~169 ~690 ~466 ~169 ~700 minecraft:redstone_wire replace
fill ~480 ~169 ~690 ~480 ~169 ~700 minecraft:redstone_wire replace
setblock ~440 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~693 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~694 ~440 ~169 ~704 minecraft:redstone_wire replace
fill ~444 ~169 ~694 ~444 ~169 ~704 minecraft:redstone_wire replace
fill ~448 ~169 ~694 ~448 ~169 ~704 minecraft:redstone_wire replace
fill ~458 ~169 ~694 ~458 ~169 ~704 minecraft:redstone_wire replace
fill ~460 ~169 ~694 ~460 ~169 ~704 minecraft:redstone_wire replace
setblock ~442 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~697 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~698 ~442 ~169 ~708 minecraft:redstone_wire replace
fill ~450 ~169 ~698 ~450 ~169 ~708 minecraft:redstone_wire replace
fill ~456 ~169 ~698 ~456 ~169 ~708 minecraft:redstone_wire replace
fill ~462 ~169 ~698 ~462 ~169 ~708 minecraft:redstone_wire replace
fill ~502 ~169 ~698 ~502 ~169 ~708 minecraft:redstone_wire replace
setblock ~446 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~701 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~702 ~446 ~169 ~712 minecraft:redstone_wire replace
fill ~452 ~169 ~702 ~452 ~169 ~712 minecraft:redstone_wire replace
fill ~454 ~169 ~702 ~454 ~169 ~712 minecraft:redstone_wire replace
fill ~464 ~169 ~702 ~464 ~169 ~712 minecraft:redstone_wire replace
fill ~466 ~169 ~702 ~466 ~169 ~712 minecraft:redstone_wire replace
setblock ~440 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~705 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~706 ~440 ~169 ~716 minecraft:redstone_wire replace
fill ~444 ~169 ~706 ~444 ~169 ~716 minecraft:redstone_wire replace
fill ~448 ~169 ~706 ~448 ~169 ~716 minecraft:redstone_wire replace
fill ~458 ~169 ~706 ~458 ~169 ~716 minecraft:redstone_wire replace
fill ~460 ~169 ~706 ~460 ~169 ~716 minecraft:redstone_wire replace
setblock ~442 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~709 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~710 ~442 ~169 ~720 minecraft:redstone_wire replace
fill ~450 ~169 ~710 ~450 ~169 ~720 minecraft:redstone_wire replace
fill ~456 ~169 ~710 ~456 ~169 ~720 minecraft:redstone_wire replace
fill ~462 ~169 ~710 ~462 ~169 ~720 minecraft:redstone_wire replace
fill ~502 ~169 ~710 ~502 ~169 ~720 minecraft:redstone_wire replace
setblock ~446 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~713 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~714 ~446 ~169 ~724 minecraft:redstone_wire replace
fill ~452 ~169 ~714 ~452 ~169 ~724 minecraft:redstone_wire replace
fill ~454 ~169 ~714 ~454 ~169 ~724 minecraft:redstone_wire replace
fill ~464 ~169 ~714 ~464 ~169 ~724 minecraft:redstone_wire replace
fill ~466 ~169 ~714 ~466 ~169 ~724 minecraft:redstone_wire replace
setblock ~440 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~717 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~718 ~440 ~169 ~728 minecraft:redstone_wire replace
fill ~444 ~169 ~718 ~444 ~169 ~728 minecraft:redstone_wire replace
fill ~448 ~169 ~718 ~448 ~169 ~728 minecraft:redstone_wire replace
fill ~458 ~169 ~718 ~458 ~169 ~728 minecraft:redstone_wire replace
fill ~460 ~169 ~718 ~460 ~169 ~728 minecraft:redstone_wire replace
setblock ~442 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~721 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~722 ~442 ~169 ~732 minecraft:redstone_wire replace
fill ~450 ~169 ~722 ~450 ~169 ~732 minecraft:redstone_wire replace
fill ~456 ~169 ~722 ~456 ~169 ~732 minecraft:redstone_wire replace
fill ~462 ~169 ~722 ~462 ~169 ~732 minecraft:redstone_wire replace
fill ~502 ~169 ~722 ~502 ~169 ~732 minecraft:redstone_wire replace
setblock ~446 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~725 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~726 ~446 ~169 ~736 minecraft:redstone_wire replace
fill ~452 ~169 ~726 ~452 ~169 ~736 minecraft:redstone_wire replace
fill ~454 ~169 ~726 ~454 ~169 ~736 minecraft:redstone_wire replace
fill ~464 ~169 ~726 ~464 ~169 ~736 minecraft:redstone_wire replace
fill ~466 ~169 ~726 ~466 ~169 ~736 minecraft:redstone_wire replace
setblock ~440 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~729 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~444 ~169 ~730 ~444 ~169 ~740 minecraft:redstone_wire replace
fill ~448 ~169 ~730 ~448 ~169 ~740 minecraft:redstone_wire replace
fill ~458 ~169 ~730 ~458 ~169 ~740 minecraft:redstone_wire replace
fill ~460 ~169 ~730 ~460 ~169 ~740 minecraft:redstone_wire replace
setblock ~442 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~733 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~450 ~169 ~734 ~450 ~169 ~744 minecraft:redstone_wire replace
fill ~456 ~169 ~734 ~456 ~169 ~744 minecraft:redstone_wire replace
fill ~462 ~169 ~734 ~462 ~169 ~744 minecraft:redstone_wire replace
fill ~502 ~169 ~734 ~502 ~169 ~744 minecraft:redstone_wire replace
setblock ~446 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~737 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~738 ~446 ~169 ~748 minecraft:redstone_wire replace
fill ~452 ~169 ~738 ~452 ~169 ~748 minecraft:redstone_wire replace
fill ~454 ~169 ~738 ~454 ~169 ~748 minecraft:redstone_wire replace
fill ~464 ~169 ~738 ~464 ~169 ~748 minecraft:redstone_wire replace
fill ~466 ~169 ~738 ~466 ~169 ~748 minecraft:redstone_wire replace
setblock ~444 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~741 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~448 ~169 ~742 ~448 ~169 ~752 minecraft:redstone_wire replace
fill ~458 ~169 ~742 ~458 ~169 ~752 minecraft:redstone_wire replace
fill ~460 ~169 ~742 ~460 ~169 ~752 minecraft:redstone_wire replace
setblock ~450 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~745 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~450 ~169 ~746 ~450 ~169 ~756 minecraft:redstone_wire replace
fill ~456 ~169 ~746 ~456 ~169 ~756 minecraft:redstone_wire replace
fill ~462 ~169 ~746 ~462 ~169 ~756 minecraft:redstone_wire replace
fill ~502 ~169 ~746 ~502 ~169 ~756 minecraft:redstone_wire replace
setblock ~446 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~749 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~750 ~452 ~169 ~760 minecraft:redstone_wire replace
fill ~454 ~169 ~750 ~454 ~169 ~760 minecraft:redstone_wire replace
fill ~464 ~169 ~750 ~464 ~169 ~760 minecraft:redstone_wire replace
fill ~466 ~169 ~750 ~466 ~169 ~760 minecraft:redstone_wire replace
setblock ~448 ~169 ~753 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~753 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~753 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~754 ~458 ~169 ~764 minecraft:redstone_wire replace
fill ~460 ~169 ~754 ~460 ~169 ~764 minecraft:redstone_wire replace
setblock ~450 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~456 ~169 ~758 ~456 ~169 ~768 minecraft:redstone_wire replace
fill ~462 ~169 ~758 ~462 ~169 ~768 minecraft:redstone_wire replace
fill ~502 ~169 ~758 ~502 ~169 ~768 minecraft:redstone_wire replace
setblock ~452 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~762 ~452 ~169 ~772 minecraft:redstone_wire replace
fill ~464 ~169 ~762 ~464 ~169 ~772 minecraft:redstone_wire replace
fill ~466 ~169 ~762 ~466 ~169 ~772 minecraft:redstone_wire replace
setblock ~458 ~169 ~765 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~765 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~766 ~458 ~169 ~776 minecraft:redstone_wire replace
fill ~460 ~169 ~766 ~460 ~169 ~776 minecraft:redstone_wire replace
setblock ~456 ~169 ~769 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~769 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~769 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~456 ~169 ~770 ~456 ~169 ~780 minecraft:redstone_wire replace
fill ~462 ~169 ~770 ~462 ~169 ~780 minecraft:redstone_wire replace
fill ~502 ~169 ~770 ~502 ~169 ~780 minecraft:redstone_wire replace
setblock ~452 ~169 ~773 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~773 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~773 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~774 ~452 ~169 ~784 minecraft:redstone_wire replace
fill ~464 ~169 ~774 ~464 ~169 ~784 minecraft:redstone_wire replace
fill ~466 ~169 ~774 ~466 ~169 ~784 minecraft:redstone_wire replace
setblock ~458 ~169 ~777 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~777 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~778 ~458 ~169 ~788 minecraft:redstone_wire replace
fill ~460 ~169 ~778 ~460 ~169 ~788 minecraft:redstone_wire replace
setblock ~456 ~169 ~781 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~781 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~781 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~456 ~169 ~782 ~456 ~169 ~792 minecraft:redstone_wire replace
fill ~462 ~169 ~782 ~462 ~169 ~792 minecraft:redstone_wire replace
fill ~502 ~169 ~782 ~502 ~169 ~792 minecraft:redstone_wire replace
setblock ~452 ~169 ~785 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~785 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~785 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~786 ~452 ~169 ~796 minecraft:redstone_wire replace
fill ~464 ~169 ~786 ~464 ~169 ~796 minecraft:redstone_wire replace
fill ~466 ~169 ~786 ~466 ~169 ~796 minecraft:redstone_wire replace
setblock ~458 ~169 ~789 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~789 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~790 ~458 ~169 ~800 minecraft:redstone_wire replace
fill ~460 ~169 ~790 ~460 ~169 ~800 minecraft:redstone_wire replace
setblock ~456 ~169 ~793 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~793 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~793 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~794 ~462 ~169 ~804 minecraft:redstone_wire replace
fill ~502 ~169 ~794 ~502 ~169 ~804 minecraft:redstone_wire replace
setblock ~452 ~169 ~797 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~797 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~797 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~798 ~452 ~169 ~808 minecraft:redstone_wire replace
fill ~464 ~169 ~798 ~464 ~169 ~808 minecraft:redstone_wire replace
fill ~466 ~169 ~798 ~466 ~169 ~808 minecraft:redstone_wire replace
setblock ~458 ~169 ~801 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~801 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~802 ~458 ~169 ~812 minecraft:redstone_wire replace
fill ~460 ~169 ~802 ~460 ~169 ~812 minecraft:redstone_wire replace
setblock ~462 ~169 ~805 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~805 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~806 ~462 ~169 ~816 minecraft:redstone_wire replace
fill ~502 ~169 ~806 ~502 ~169 ~816 minecraft:redstone_wire replace
setblock ~452 ~169 ~809 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~809 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~809 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~810 ~452 ~169 ~820 minecraft:redstone_wire replace
fill ~464 ~169 ~810 ~464 ~169 ~820 minecraft:redstone_wire replace
fill ~466 ~169 ~810 ~466 ~169 ~820 minecraft:redstone_wire replace
setblock ~458 ~169 ~813 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~813 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~814 ~458 ~169 ~824 minecraft:redstone_wire replace
fill ~460 ~169 ~814 ~460 ~169 ~824 minecraft:redstone_wire replace
setblock ~462 ~169 ~817 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~817 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~818 ~462 ~169 ~828 minecraft:redstone_wire replace
fill ~502 ~169 ~818 ~502 ~169 ~828 minecraft:redstone_wire replace
setblock ~452 ~169 ~821 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~821 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~821 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~822 ~452 ~169 ~832 minecraft:redstone_wire replace
fill ~464 ~169 ~822 ~464 ~169 ~832 minecraft:redstone_wire replace
fill ~466 ~169 ~822 ~466 ~169 ~832 minecraft:redstone_wire replace
setblock ~458 ~169 ~825 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~825 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~460 ~169 ~826 ~460 ~169 ~836 minecraft:redstone_wire replace
setblock ~462 ~169 ~829 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~829 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~830 ~462 ~169 ~840 minecraft:redstone_wire replace
fill ~502 ~169 ~830 ~502 ~169 ~840 minecraft:redstone_wire replace
setblock ~452 ~169 ~833 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~833 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~833 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~834 ~452 ~169 ~844 minecraft:redstone_wire replace
fill ~464 ~169 ~834 ~464 ~169 ~844 minecraft:redstone_wire replace
fill ~466 ~169 ~834 ~466 ~169 ~844 minecraft:redstone_wire replace
setblock ~460 ~169 ~837 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~460 ~169 ~838 ~460 ~169 ~848 minecraft:redstone_wire replace
setblock ~462 ~169 ~841 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~841 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~842 ~462 ~169 ~852 minecraft:redstone_wire replace
fill ~502 ~169 ~842 ~502 ~169 ~852 minecraft:redstone_wire replace
setblock ~452 ~169 ~845 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~845 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~845 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~846 ~452 ~169 ~856 minecraft:redstone_wire replace
fill ~464 ~169 ~846 ~464 ~169 ~856 minecraft:redstone_wire replace
fill ~466 ~169 ~846 ~466 ~169 ~856 minecraft:redstone_wire replace
setblock ~460 ~169 ~849 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~460 ~169 ~850 ~460 ~169 ~860 minecraft:redstone_wire replace
setblock ~462 ~169 ~853 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~853 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~854 ~462 ~169 ~864 minecraft:redstone_wire replace
fill ~502 ~169 ~854 ~502 ~169 ~864 minecraft:redstone_wire replace
setblock ~452 ~169 ~857 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~857 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~857 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~858 ~452 ~169 ~868 minecraft:redstone_wire replace
fill ~464 ~169 ~858 ~464 ~169 ~868 minecraft:redstone_wire replace
fill ~466 ~169 ~858 ~466 ~169 ~868 minecraft:redstone_wire replace
setblock ~460 ~169 ~861 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~865 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~865 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~866 ~462 ~169 ~876 minecraft:redstone_wire replace
fill ~502 ~169 ~866 ~502 ~169 ~876 minecraft:redstone_wire replace
setblock ~452 ~169 ~869 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~869 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~869 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~870 ~452 ~169 ~880 minecraft:redstone_wire replace
fill ~464 ~169 ~870 ~464 ~169 ~880 minecraft:redstone_wire replace
fill ~466 ~169 ~870 ~466 ~169 ~880 minecraft:redstone_wire replace
setblock ~462 ~169 ~877 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~877 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~878 ~462 ~169 ~888 minecraft:redstone_wire replace
fill ~502 ~169 ~878 ~502 ~169 ~888 minecraft:redstone_wire replace
setblock ~452 ~169 ~881 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~881 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~881 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~882 ~452 ~169 ~892 minecraft:redstone_wire replace
fill ~464 ~169 ~882 ~464 ~169 ~892 minecraft:redstone_wire replace
fill ~466 ~169 ~882 ~466 ~169 ~892 minecraft:redstone_wire replace
setblock ~462 ~169 ~889 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~889 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~890 ~502 ~169 ~900 minecraft:redstone_wire replace
setblock ~452 ~169 ~893 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~893 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~893 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~894 ~452 ~169 ~904 minecraft:redstone_wire replace
fill ~464 ~169 ~894 ~464 ~169 ~904 minecraft:redstone_wire replace
fill ~466 ~169 ~894 ~466 ~169 ~904 minecraft:redstone_wire replace
setblock ~502 ~169 ~901 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~902 ~502 ~169 ~912 minecraft:redstone_wire replace
setblock ~452 ~169 ~905 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~905 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~905 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~906 ~452 ~169 ~916 minecraft:redstone_wire replace
fill ~466 ~169 ~906 ~466 ~169 ~916 minecraft:redstone_wire replace
setblock ~502 ~169 ~913 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~914 ~502 ~169 ~924 minecraft:redstone_wire replace
setblock ~452 ~169 ~917 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~917 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~918 ~452 ~169 ~928 minecraft:redstone_wire replace
fill ~466 ~169 ~918 ~466 ~169 ~928 minecraft:redstone_wire replace
setblock ~502 ~169 ~925 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~926 ~502 ~169 ~936 minecraft:redstone_wire replace
setblock ~452 ~169 ~929 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~929 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~930 ~452 ~169 ~940 minecraft:redstone_wire replace
setblock ~502 ~169 ~937 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~938 ~502 ~169 ~948 minecraft:redstone_wire replace
setblock ~452 ~169 ~941 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~942 ~452 ~169 ~952 minecraft:redstone_wire replace
setblock ~502 ~169 ~949 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~950 ~502 ~169 ~960 minecraft:redstone_wire replace
setblock ~452 ~169 ~953 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~954 ~452 ~169 ~964 minecraft:redstone_wire replace
setblock ~502 ~169 ~961 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~965 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~440 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~496 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~496 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~499 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~173 ~2 ~510 ~173 ~2 minecraft:redstone_wire replace
setblock ~511 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~173 ~2 ~522 ~173 ~2 minecraft:redstone_wire replace
setblock ~523 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~173 ~2 ~534 ~173 ~2 minecraft:redstone_wire replace
setblock ~535 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~536 ~173 ~2 ~546 ~173 ~2 minecraft:redstone_wire replace
setblock ~547 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~548 ~173 ~2 ~553 ~173 ~2 minecraft:redstone_wire replace
setblock ~501 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~173 ~4 ~512 ~173 ~4 minecraft:redstone_wire replace
setblock ~513 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~173 ~4 ~524 ~173 ~4 minecraft:redstone_wire replace
setblock ~525 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~173 ~4 ~536 ~173 ~4 minecraft:redstone_wire replace
setblock ~537 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~538 ~173 ~4 ~548 ~173 ~4 minecraft:redstone_wire replace
setblock ~549 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~550 ~173 ~4 ~553 ~173 ~4 minecraft:redstone_wire replace
setblock ~503 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~173 ~6 ~514 ~173 ~6 minecraft:redstone_wire replace
setblock ~515 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~173 ~6 ~526 ~173 ~6 minecraft:redstone_wire replace
setblock ~527 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~173 ~6 ~538 ~173 ~6 minecraft:redstone_wire replace
setblock ~539 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~540 ~173 ~6 ~550 ~173 ~6 minecraft:redstone_wire replace
setblock ~551 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~552 ~173 ~6 ~553 ~173 ~6 minecraft:redstone_wire replace
setblock ~497 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~173 ~8 ~508 ~173 ~8 minecraft:redstone_wire replace
setblock ~509 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~173 ~8 ~520 ~173 ~8 minecraft:redstone_wire replace
setblock ~521 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~173 ~8 ~532 ~173 ~8 minecraft:redstone_wire replace
setblock ~533 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~534 ~173 ~8 ~544 ~173 ~8 minecraft:redstone_wire replace
setblock ~545 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~546 ~173 ~8 ~553 ~173 ~8 minecraft:redstone_wire replace
setblock ~440 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~495 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~177 ~2 ~506 ~177 ~2 minecraft:redstone_wire replace
setblock ~507 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~177 ~2 ~518 ~177 ~2 minecraft:redstone_wire replace
setblock ~519 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~177 ~2 ~530 ~177 ~2 minecraft:redstone_wire replace
setblock ~531 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~177 ~2 ~542 ~177 ~2 minecraft:redstone_wire replace
setblock ~543 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~544 ~177 ~2 ~547 ~177 ~2 minecraft:redstone_wire replace
setblock ~485 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~177 ~4 ~496 ~177 ~4 minecraft:redstone_wire replace
setblock ~497 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~177 ~4 ~508 ~177 ~4 minecraft:redstone_wire replace
setblock ~509 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~177 ~4 ~520 ~177 ~4 minecraft:redstone_wire replace
setblock ~521 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~177 ~4 ~532 ~177 ~4 minecraft:redstone_wire replace
setblock ~533 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~534 ~177 ~4 ~544 ~177 ~4 minecraft:redstone_wire replace
setblock ~545 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~493 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~177 ~6 ~504 ~177 ~6 minecraft:redstone_wire replace
setblock ~505 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~177 ~6 ~516 ~177 ~6 minecraft:redstone_wire replace
setblock ~517 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~177 ~6 ~528 ~177 ~6 minecraft:redstone_wire replace
setblock ~529 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~177 ~6 ~540 ~177 ~6 minecraft:redstone_wire replace
setblock ~541 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~542 ~177 ~6 ~549 ~177 ~6 minecraft:redstone_wire replace
setblock ~483 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~177 ~8 ~494 ~177 ~8 minecraft:redstone_wire replace
setblock ~495 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~177 ~8 ~506 ~177 ~8 minecraft:redstone_wire replace
setblock ~507 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~177 ~8 ~518 ~177 ~8 minecraft:redstone_wire replace
setblock ~519 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~177 ~8 ~530 ~177 ~8 minecraft:redstone_wire replace
setblock ~531 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~177 ~8 ~542 ~177 ~8 minecraft:redstone_wire replace
setblock ~543 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~544 ~177 ~8 ~547 ~177 ~8 minecraft:redstone_wire replace
setblock ~487 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~177 ~10 ~498 ~177 ~10 minecraft:redstone_wire replace
setblock ~499 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~177 ~10 ~510 ~177 ~10 minecraft:redstone_wire replace
setblock ~511 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~177 ~10 ~522 ~177 ~10 minecraft:redstone_wire replace
setblock ~523 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~177 ~10 ~534 ~177 ~10 minecraft:redstone_wire replace
setblock ~535 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~536 ~177 ~10 ~545 ~177 ~10 minecraft:redstone_wire replace
setblock ~491 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~177 ~12 ~502 ~177 ~12 minecraft:redstone_wire replace
setblock ~503 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~177 ~12 ~514 ~177 ~12 minecraft:redstone_wire replace
setblock ~515 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~177 ~12 ~526 ~177 ~12 minecraft:redstone_wire replace
setblock ~527 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~177 ~12 ~538 ~177 ~12 minecraft:redstone_wire replace
setblock ~539 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~540 ~177 ~12 ~549 ~177 ~12 minecraft:redstone_wire replace
setblock ~489 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~177 ~14 ~500 ~177 ~14 minecraft:redstone_wire replace
setblock ~501 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~177 ~14 ~512 ~177 ~14 minecraft:redstone_wire replace
setblock ~513 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~177 ~14 ~524 ~177 ~14 minecraft:redstone_wire replace
setblock ~525 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~177 ~14 ~536 ~177 ~14 minecraft:redstone_wire replace
setblock ~537 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~538 ~177 ~14 ~547 ~177 ~14 minecraft:redstone_wire replace
setblock ~440 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~469 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~181 ~2 ~480 ~181 ~2 minecraft:redstone_wire replace
setblock ~481 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~181 ~2 ~492 ~181 ~2 minecraft:redstone_wire replace
setblock ~493 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~181 ~2 ~504 ~181 ~2 minecraft:redstone_wire replace
setblock ~505 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~181 ~2 ~516 ~181 ~2 minecraft:redstone_wire replace
setblock ~517 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~181 ~2 ~528 ~181 ~2 minecraft:redstone_wire replace
setblock ~529 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~181 ~2 ~539 ~181 ~2 minecraft:redstone_wire replace
setblock ~479 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~181 ~4 ~490 ~181 ~4 minecraft:redstone_wire replace
setblock ~491 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~181 ~4 ~502 ~181 ~4 minecraft:redstone_wire replace
setblock ~503 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~181 ~4 ~514 ~181 ~4 minecraft:redstone_wire replace
setblock ~515 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~181 ~4 ~526 ~181 ~4 minecraft:redstone_wire replace
setblock ~527 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~181 ~4 ~537 ~181 ~4 minecraft:redstone_wire replace
setblock ~471 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~472 ~181 ~6 ~482 ~181 ~6 minecraft:redstone_wire replace
setblock ~483 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~181 ~6 ~494 ~181 ~6 minecraft:redstone_wire replace
setblock ~495 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~181 ~6 ~506 ~181 ~6 minecraft:redstone_wire replace
setblock ~507 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~181 ~6 ~518 ~181 ~6 minecraft:redstone_wire replace
setblock ~519 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~181 ~6 ~530 ~181 ~6 minecraft:redstone_wire replace
setblock ~531 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~181 ~6 ~541 ~181 ~6 minecraft:redstone_wire replace
setblock ~481 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~181 ~8 ~492 ~181 ~8 minecraft:redstone_wire replace
setblock ~493 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~181 ~8 ~504 ~181 ~8 minecraft:redstone_wire replace
setblock ~505 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~181 ~8 ~516 ~181 ~8 minecraft:redstone_wire replace
setblock ~517 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~181 ~8 ~528 ~181 ~8 minecraft:redstone_wire replace
setblock ~529 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~181 ~8 ~539 ~181 ~8 minecraft:redstone_wire replace
setblock ~477 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~181 ~10 ~488 ~181 ~10 minecraft:redstone_wire replace
setblock ~489 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~181 ~10 ~500 ~181 ~10 minecraft:redstone_wire replace
setblock ~501 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~181 ~10 ~512 ~181 ~10 minecraft:redstone_wire replace
setblock ~513 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~181 ~10 ~524 ~181 ~10 minecraft:redstone_wire replace
setblock ~525 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~181 ~10 ~536 ~181 ~10 minecraft:redstone_wire replace
setblock ~537 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~473 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~474 ~181 ~12 ~484 ~181 ~12 minecraft:redstone_wire replace
setblock ~485 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~181 ~12 ~496 ~181 ~12 minecraft:redstone_wire replace
setblock ~497 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~181 ~12 ~508 ~181 ~12 minecraft:redstone_wire replace
setblock ~509 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~181 ~12 ~520 ~181 ~12 minecraft:redstone_wire replace
setblock ~521 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~181 ~12 ~532 ~181 ~12 minecraft:redstone_wire replace
setblock ~533 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~534 ~181 ~12 ~541 ~181 ~12 minecraft:redstone_wire replace
setblock ~475 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~181 ~14 ~486 ~181 ~14 minecraft:redstone_wire replace
setblock ~487 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~181 ~14 ~498 ~181 ~14 minecraft:redstone_wire replace
setblock ~499 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~181 ~14 ~510 ~181 ~14 minecraft:redstone_wire replace
setblock ~511 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~181 ~14 ~522 ~181 ~14 minecraft:redstone_wire replace
setblock ~523 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~181 ~14 ~534 ~181 ~14 minecraft:redstone_wire replace
setblock ~535 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~536 ~181 ~14 ~539 ~181 ~14 minecraft:redstone_wire replace
setblock ~440 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~184 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~184 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~184 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~184 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~455 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~456 ~185 ~2 ~466 ~185 ~2 minecraft:redstone_wire replace
setblock ~467 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~468 ~185 ~2 ~478 ~185 ~2 minecraft:redstone_wire replace
setblock ~479 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~185 ~2 ~490 ~185 ~2 minecraft:redstone_wire replace
setblock ~491 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~185 ~2 ~502 ~185 ~2 minecraft:redstone_wire replace
setblock ~503 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~185 ~2 ~514 ~185 ~2 minecraft:redstone_wire replace
setblock ~515 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~185 ~2 ~526 ~185 ~2 minecraft:redstone_wire replace
setblock ~527 ~185 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~185 ~2 ~531 ~185 ~2 minecraft:redstone_wire replace
setblock ~465 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~466 ~185 ~4 ~476 ~185 ~4 minecraft:redstone_wire replace
setblock ~477 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~185 ~4 ~488 ~185 ~4 minecraft:redstone_wire replace
setblock ~489 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~185 ~4 ~500 ~185 ~4 minecraft:redstone_wire replace
setblock ~501 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~185 ~4 ~512 ~185 ~4 minecraft:redstone_wire replace
setblock ~513 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~185 ~4 ~524 ~185 ~4 minecraft:redstone_wire replace
setblock ~525 ~185 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~185 ~4 ~529 ~185 ~4 minecraft:redstone_wire replace
setblock ~457 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~185 ~6 ~468 ~185 ~6 minecraft:redstone_wire replace
setblock ~469 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~185 ~6 ~480 ~185 ~6 minecraft:redstone_wire replace
setblock ~481 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~185 ~6 ~492 ~185 ~6 minecraft:redstone_wire replace
setblock ~493 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~185 ~6 ~504 ~185 ~6 minecraft:redstone_wire replace
setblock ~505 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~185 ~6 ~516 ~185 ~6 minecraft:redstone_wire replace
setblock ~517 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~185 ~6 ~528 ~185 ~6 minecraft:redstone_wire replace
setblock ~529 ~185 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~185 ~6 ~533 ~185 ~6 minecraft:redstone_wire replace
setblock ~467 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~468 ~185 ~8 ~478 ~185 ~8 minecraft:redstone_wire replace
setblock ~479 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~185 ~8 ~490 ~185 ~8 minecraft:redstone_wire replace
setblock ~491 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~185 ~8 ~502 ~185 ~8 minecraft:redstone_wire replace
setblock ~503 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~185 ~8 ~514 ~185 ~8 minecraft:redstone_wire replace
setblock ~515 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~185 ~8 ~526 ~185 ~8 minecraft:redstone_wire replace
setblock ~527 ~185 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~185 ~8 ~531 ~185 ~8 minecraft:redstone_wire replace
setblock ~463 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~185 ~10 ~474 ~185 ~10 minecraft:redstone_wire replace
setblock ~475 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~185 ~10 ~486 ~185 ~10 minecraft:redstone_wire replace
setblock ~487 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~185 ~10 ~498 ~185 ~10 minecraft:redstone_wire replace
setblock ~499 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~185 ~10 ~510 ~185 ~10 minecraft:redstone_wire replace
setblock ~511 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~185 ~10 ~522 ~185 ~10 minecraft:redstone_wire replace
setblock ~523 ~185 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~185 ~10 ~529 ~185 ~10 minecraft:redstone_wire replace
setblock ~459 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~460 ~185 ~12 ~470 ~185 ~12 minecraft:redstone_wire replace
setblock ~471 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~472 ~185 ~12 ~482 ~185 ~12 minecraft:redstone_wire replace
setblock ~483 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~185 ~12 ~494 ~185 ~12 minecraft:redstone_wire replace
setblock ~495 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~185 ~12 ~506 ~185 ~12 minecraft:redstone_wire replace
setblock ~507 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~185 ~12 ~518 ~185 ~12 minecraft:redstone_wire replace
setblock ~519 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~185 ~12 ~530 ~185 ~12 minecraft:redstone_wire replace
setblock ~531 ~185 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~185 ~12 ~533 ~185 ~12 minecraft:redstone_wire replace
setblock ~461 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~462 ~185 ~14 ~472 ~185 ~14 minecraft:redstone_wire replace
setblock ~473 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~474 ~185 ~14 ~484 ~185 ~14 minecraft:redstone_wire replace
setblock ~485 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~185 ~14 ~496 ~185 ~14 minecraft:redstone_wire replace
setblock ~497 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~185 ~14 ~508 ~185 ~14 minecraft:redstone_wire replace
setblock ~509 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~185 ~14 ~520 ~185 ~14 minecraft:redstone_wire replace
setblock ~521 ~185 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~185 ~14 ~531 ~185 ~14 minecraft:redstone_wire replace
setblock ~440 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~186 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~186 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~186 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~186 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~188 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~188 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~188 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~188 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~441 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~442 ~189 ~2 ~452 ~189 ~2 minecraft:redstone_wire replace
setblock ~453 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~454 ~189 ~2 ~464 ~189 ~2 minecraft:redstone_wire replace
setblock ~465 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~466 ~189 ~2 ~476 ~189 ~2 minecraft:redstone_wire replace
setblock ~477 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~189 ~2 ~488 ~189 ~2 minecraft:redstone_wire replace
setblock ~489 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~189 ~2 ~500 ~189 ~2 minecraft:redstone_wire replace
setblock ~501 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~189 ~2 ~512 ~189 ~2 minecraft:redstone_wire replace
setblock ~513 ~189 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~189 ~2 ~523 ~189 ~2 minecraft:redstone_wire replace
setblock ~451 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~189 ~4 ~462 ~189 ~4 minecraft:redstone_wire replace
setblock ~463 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~189 ~4 ~474 ~189 ~4 minecraft:redstone_wire replace
setblock ~475 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~189 ~4 ~486 ~189 ~4 minecraft:redstone_wire replace
setblock ~487 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~189 ~4 ~498 ~189 ~4 minecraft:redstone_wire replace
setblock ~499 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~189 ~4 ~510 ~189 ~4 minecraft:redstone_wire replace
setblock ~511 ~189 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~189 ~4 ~521 ~189 ~4 minecraft:redstone_wire replace
setblock ~443 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~444 ~189 ~6 ~454 ~189 ~6 minecraft:redstone_wire replace
setblock ~455 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~456 ~189 ~6 ~466 ~189 ~6 minecraft:redstone_wire replace
setblock ~467 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~468 ~189 ~6 ~478 ~189 ~6 minecraft:redstone_wire replace
setblock ~479 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~189 ~6 ~490 ~189 ~6 minecraft:redstone_wire replace
setblock ~491 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~189 ~6 ~502 ~189 ~6 minecraft:redstone_wire replace
setblock ~503 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~189 ~6 ~514 ~189 ~6 minecraft:redstone_wire replace
setblock ~515 ~189 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~189 ~6 ~525 ~189 ~6 minecraft:redstone_wire replace
setblock ~453 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~454 ~189 ~8 ~464 ~189 ~8 minecraft:redstone_wire replace
setblock ~465 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~466 ~189 ~8 ~476 ~189 ~8 minecraft:redstone_wire replace
setblock ~477 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~189 ~8 ~488 ~189 ~8 minecraft:redstone_wire replace
setblock ~489 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~189 ~8 ~500 ~189 ~8 minecraft:redstone_wire replace
setblock ~501 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~189 ~8 ~512 ~189 ~8 minecraft:redstone_wire replace
setblock ~513 ~189 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~189 ~8 ~523 ~189 ~8 minecraft:redstone_wire replace
setblock ~449 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~450 ~189 ~10 ~460 ~189 ~10 minecraft:redstone_wire replace
setblock ~461 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~462 ~189 ~10 ~472 ~189 ~10 minecraft:redstone_wire replace
setblock ~473 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~474 ~189 ~10 ~484 ~189 ~10 minecraft:redstone_wire replace
setblock ~485 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~189 ~10 ~496 ~189 ~10 minecraft:redstone_wire replace
setblock ~497 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~189 ~10 ~508 ~189 ~10 minecraft:redstone_wire replace
setblock ~509 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~189 ~10 ~520 ~189 ~10 minecraft:redstone_wire replace
setblock ~521 ~189 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~445 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~189 ~12 ~456 ~189 ~12 minecraft:redstone_wire replace
setblock ~457 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~189 ~12 ~468 ~189 ~12 minecraft:redstone_wire replace
setblock ~469 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~189 ~12 ~480 ~189 ~12 minecraft:redstone_wire replace
setblock ~481 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~189 ~12 ~492 ~189 ~12 minecraft:redstone_wire replace
setblock ~493 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~189 ~12 ~504 ~189 ~12 minecraft:redstone_wire replace
setblock ~505 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~189 ~12 ~516 ~189 ~12 minecraft:redstone_wire replace
setblock ~517 ~189 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~189 ~12 ~525 ~189 ~12 minecraft:redstone_wire replace
setblock ~447 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~448 ~189 ~14 ~458 ~189 ~14 minecraft:redstone_wire replace
setblock ~459 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~460 ~189 ~14 ~470 ~189 ~14 minecraft:redstone_wire replace
setblock ~471 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~472 ~189 ~14 ~482 ~189 ~14 minecraft:redstone_wire replace
setblock ~483 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~189 ~14 ~494 ~189 ~14 minecraft:redstone_wire replace
setblock ~495 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~189 ~14 ~506 ~189 ~14 minecraft:redstone_wire replace
setblock ~507 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~189 ~14 ~518 ~189 ~14 minecraft:redstone_wire replace
setblock ~519 ~189 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~189 ~14 ~523 ~189 ~14 minecraft:redstone_wire replace
setblock ~524 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~190 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~190 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~190 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~190 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~192 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~522 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~530 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~192 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~526 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~534 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~192 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~524 ~192 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~532 ~192 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~192 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~192 ~14 minecraft:redstone_torch[lit=true] replace
fill ~523 ~194 ~2 ~525 ~194 ~2 minecraft:redstone_wire replace
fill ~531 ~194 ~2 ~533 ~194 ~2 minecraft:redstone_wire replace
fill ~539 ~194 ~2 ~541 ~194 ~2 minecraft:redstone_wire replace
fill ~547 ~194 ~2 ~549 ~194 ~2 minecraft:redstone_wire replace
fill ~522 ~194 ~3 ~522 ~194 ~7 minecraft:redstone_wire replace
fill ~526 ~194 ~3 ~526 ~194 ~7 minecraft:redstone_wire replace
fill ~530 ~194 ~3 ~530 ~194 ~7 minecraft:redstone_wire replace
fill ~534 ~194 ~3 ~534 ~194 ~7 minecraft:redstone_wire replace
fill ~538 ~194 ~3 ~538 ~194 ~7 minecraft:redstone_wire replace
fill ~542 ~194 ~3 ~542 ~194 ~7 minecraft:redstone_wire replace
fill ~546 ~194 ~3 ~546 ~194 ~7 minecraft:redstone_wire replace
fill ~550 ~194 ~3 ~550 ~194 ~7 minecraft:redstone_wire replace
fill ~523 ~194 ~8 ~525 ~194 ~8 minecraft:redstone_wire replace
fill ~531 ~194 ~8 ~533 ~194 ~8 minecraft:redstone_wire replace
fill ~539 ~194 ~8 ~541 ~194 ~8 minecraft:redstone_wire replace
fill ~547 ~194 ~8 ~549 ~194 ~8 minecraft:redstone_wire replace
fill ~522 ~194 ~9 ~522 ~194 ~13 minecraft:redstone_wire replace
fill ~526 ~194 ~9 ~526 ~194 ~13 minecraft:redstone_wire replace
fill ~530 ~194 ~9 ~530 ~194 ~13 minecraft:redstone_wire replace
fill ~534 ~194 ~9 ~534 ~194 ~13 minecraft:redstone_wire replace
fill ~538 ~194 ~9 ~538 ~194 ~13 minecraft:redstone_wire replace
fill ~542 ~194 ~9 ~542 ~194 ~13 minecraft:redstone_wire replace
fill ~546 ~194 ~9 ~546 ~194 ~13 minecraft:redstone_wire replace
fill ~550 ~194 ~9 ~550 ~194 ~13 minecraft:redstone_wire replace
fill ~523 ~194 ~14 ~525 ~194 ~14 minecraft:redstone_wire replace
fill ~531 ~194 ~14 ~533 ~194 ~14 minecraft:redstone_wire replace
fill ~539 ~194 ~14 ~541 ~194 ~14 minecraft:redstone_wire replace
fill ~547 ~194 ~14 ~549 ~194 ~14 minecraft:redstone_wire replace
