fill ~132 ~70 ~384 ~132 ~70 ~648 minecraft:light_gray_concrete replace
fill ~114 ~70 ~392 ~114 ~70 ~648 minecraft:light_gray_concrete replace
fill ~84 ~70 ~396 ~84 ~70 ~400 minecraft:light_gray_concrete replace
fill ~126 ~70 ~484 ~126 ~70 ~488 minecraft:light_gray_concrete replace
fill ~123 ~70 ~524 ~123 ~70 ~528 minecraft:light_gray_concrete replace
fill ~120 ~70 ~564 ~120 ~70 ~568 minecraft:light_gray_concrete replace
fill ~117 ~70 ~600 ~117 ~70 ~608 minecraft:light_gray_concrete replace
fill ~87 ~70 ~604 ~87 ~70 ~612 minecraft:light_gray_concrete replace
fill ~90 ~70 ~608 ~90 ~70 ~616 minecraft:light_gray_concrete replace
fill ~93 ~70 ~612 ~93 ~70 ~620 minecraft:light_gray_concrete replace
fill ~96 ~70 ~616 ~96 ~70 ~624 minecraft:light_gray_concrete replace
fill ~99 ~70 ~620 ~99 ~70 ~628 minecraft:light_gray_concrete replace
fill ~102 ~70 ~624 ~102 ~70 ~632 minecraft:light_gray_concrete replace
fill ~129 ~70 ~628 ~129 ~70 ~636 minecraft:light_gray_concrete replace
fill ~78 ~70 ~632 ~78 ~70 ~636 minecraft:light_gray_concrete replace
fill ~105 ~70 ~636 ~105 ~70 ~640 minecraft:light_gray_concrete replace
fill ~108 ~70 ~640 ~108 ~70 ~644 minecraft:light_gray_concrete replace
fill ~138 ~70 ~648 ~138 ~70 ~652 minecraft:light_gray_concrete replace
fill ~81 ~70 ~652 ~81 ~70 ~656 minecraft:light_gray_concrete replace
fill ~111 ~70 ~656 ~111 ~70 ~660 minecraft:light_gray_concrete replace
fill ~135 ~70 ~660 ~135 ~70 ~664 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~383 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~385 minecraft:light_gray_concrete replace
setblock ~133 ~71 ~388 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~391 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~393 minecraft:light_gray_concrete replace
setblock ~84 ~71 ~395 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~395 minecraft:light_gray_concrete replace
setblock ~115 ~71 ~396 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~409 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~409 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~411 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~411 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~425 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~425 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~427 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~441 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~441 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~443 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~443 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~457 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~457 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~459 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~459 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~473 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~473 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~475 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~475 minecraft:light_gray_concrete replace
setblock ~126 ~71 ~483 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~489 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~489 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~491 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~491 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~505 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~505 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~507 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~507 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~521 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~521 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~523 minecraft:light_gray_concrete replace
setblock ~123 ~71 ~523 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~523 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~537 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~537 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~539 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~539 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~553 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~553 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~555 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~555 minecraft:light_gray_concrete replace
setblock ~120 ~71 ~563 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~569 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~569 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~571 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~571 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~585 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~585 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~587 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~587 minecraft:light_gray_concrete replace
setblock ~117 ~71 ~599 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~601 minecraft:light_gray_concrete replace
setblock ~117 ~71 ~601 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~601 minecraft:light_gray_concrete replace
setblock ~87 ~71 ~603 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~603 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~603 minecraft:light_gray_concrete replace
setblock ~87 ~71 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~71 ~607 minecraft:light_gray_concrete replace
setblock ~90 ~71 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~71 ~611 minecraft:light_gray_concrete replace
setblock ~93 ~71 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~71 ~615 minecraft:light_gray_concrete replace
setblock ~96 ~71 ~617 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~617 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~71 ~619 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~619 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~619 minecraft:light_gray_concrete replace
setblock ~99 ~71 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~71 ~623 minecraft:light_gray_concrete replace
setblock ~102 ~71 ~625 minecraft:light_gray_concrete replace
setblock ~129 ~71 ~627 minecraft:light_gray_concrete replace
setblock ~129 ~71 ~629 minecraft:light_gray_concrete replace
setblock ~78 ~71 ~631 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~633 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~633 minecraft:light_gray_concrete replace
setblock ~105 ~71 ~635 minecraft:light_gray_concrete replace
setblock ~114 ~71 ~635 minecraft:light_gray_concrete replace
setblock ~132 ~71 ~635 minecraft:light_gray_concrete replace
setblock ~130 ~71 ~636 minecraft:light_gray_concrete replace
setblock ~108 ~71 ~639 minecraft:light_gray_concrete replace
setblock ~138 ~71 ~647 minecraft:light_gray_concrete replace
setblock ~81 ~71 ~651 minecraft:light_gray_concrete replace
setblock ~111 ~71 ~655 minecraft:light_gray_concrete replace
setblock ~135 ~71 ~659 minecraft:light_gray_concrete replace
fill ~115 ~72 ~380 ~115 ~72 ~381 minecraft:light_gray_concrete replace
fill ~114 ~72 ~382 ~132 ~72 ~382 minecraft:light_gray_concrete replace
fill ~109 ~72 ~388 ~109 ~72 ~389 minecraft:light_gray_concrete replace
fill ~108 ~72 ~390 ~114 ~72 ~390 minecraft:light_gray_concrete replace
fill ~85 ~72 ~392 ~85 ~72 ~393 minecraft:light_gray_concrete replace
fill ~84 ~72 ~394 ~86 ~72 ~394 minecraft:light_gray_concrete replace
fill ~109 ~72 ~480 ~109 ~72 ~481 minecraft:light_gray_concrete replace
fill ~108 ~72 ~482 ~126 ~72 ~482 minecraft:light_gray_concrete replace
fill ~109 ~72 ~520 ~109 ~72 ~521 minecraft:light_gray_concrete replace
fill ~108 ~72 ~522 ~123 ~72 ~522 minecraft:light_gray_concrete replace
fill ~109 ~72 ~560 ~109 ~72 ~561 minecraft:light_gray_concrete replace
fill ~108 ~72 ~562 ~120 ~72 ~562 minecraft:light_gray_concrete replace
fill ~109 ~72 ~596 ~109 ~72 ~597 minecraft:light_gray_concrete replace
fill ~108 ~72 ~598 ~117 ~72 ~598 minecraft:light_gray_concrete replace
fill ~88 ~72 ~600 ~88 ~72 ~601 minecraft:light_gray_concrete replace
fill ~87 ~72 ~602 ~89 ~72 ~602 minecraft:light_gray_concrete replace
fill ~91 ~72 ~604 ~91 ~72 ~605 minecraft:light_gray_concrete replace
fill ~90 ~72 ~606 ~92 ~72 ~606 minecraft:light_gray_concrete replace
fill ~94 ~72 ~608 ~94 ~72 ~609 minecraft:light_gray_concrete replace
fill ~93 ~72 ~610 ~95 ~72 ~610 minecraft:light_gray_concrete replace
fill ~97 ~72 ~612 ~97 ~72 ~613 minecraft:light_gray_concrete replace
fill ~96 ~72 ~614 ~98 ~72 ~614 minecraft:light_gray_concrete replace
fill ~100 ~72 ~616 ~100 ~72 ~617 minecraft:light_gray_concrete replace
fill ~99 ~72 ~618 ~101 ~72 ~618 minecraft:light_gray_concrete replace
fill ~103 ~72 ~620 ~103 ~72 ~621 minecraft:light_gray_concrete replace
fill ~102 ~72 ~622 ~104 ~72 ~622 minecraft:light_gray_concrete replace
fill ~112 ~72 ~624 ~112 ~72 ~625 minecraft:light_gray_concrete replace
fill ~111 ~72 ~626 ~129 ~72 ~626 minecraft:light_gray_concrete replace
fill ~79 ~72 ~628 ~79 ~72 ~629 minecraft:light_gray_concrete replace
fill ~78 ~72 ~630 ~80 ~72 ~630 minecraft:light_gray_concrete replace
fill ~106 ~72 ~632 ~106 ~72 ~633 minecraft:light_gray_concrete replace
fill ~105 ~72 ~634 ~107 ~72 ~634 minecraft:light_gray_concrete replace
fill ~109 ~72 ~636 ~109 ~72 ~637 minecraft:light_gray_concrete replace
fill ~108 ~72 ~638 ~110 ~72 ~638 minecraft:light_gray_concrete replace
fill ~121 ~72 ~644 ~121 ~72 ~645 minecraft:light_gray_concrete replace
fill ~120 ~72 ~646 ~138 ~72 ~646 minecraft:light_gray_concrete replace
fill ~82 ~72 ~648 ~82 ~72 ~649 minecraft:light_gray_concrete replace
fill ~81 ~72 ~650 ~83 ~72 ~650 minecraft:light_gray_concrete replace
fill ~109 ~72 ~652 ~109 ~72 ~653 minecraft:light_gray_concrete replace
fill ~108 ~72 ~654 ~111 ~72 ~654 minecraft:light_gray_concrete replace
fill ~118 ~72 ~656 ~118 ~72 ~657 minecraft:light_gray_concrete replace
fill ~117 ~72 ~658 ~135 ~72 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~73 ~380 minecraft:light_gray_concrete replace
setblock ~117 ~73 ~382 minecraft:light_gray_concrete replace
setblock ~119 ~73 ~382 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~388 minecraft:light_gray_concrete replace
setblock ~85 ~73 ~392 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~480 minecraft:light_gray_concrete replace
setblock ~117 ~73 ~482 minecraft:light_gray_concrete replace
setblock ~119 ~73 ~482 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~520 minecraft:light_gray_concrete replace
setblock ~114 ~73 ~522 minecraft:light_gray_concrete replace
setblock ~116 ~73 ~522 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~560 minecraft:light_gray_concrete replace
setblock ~111 ~73 ~562 minecraft:light_gray_concrete replace
setblock ~113 ~73 ~562 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~596 minecraft:light_gray_concrete replace
setblock ~88 ~73 ~600 minecraft:light_gray_concrete replace
setblock ~91 ~73 ~604 minecraft:light_gray_concrete replace
setblock ~94 ~73 ~608 minecraft:light_gray_concrete replace
setblock ~97 ~73 ~612 minecraft:light_gray_concrete replace
setblock ~100 ~73 ~616 minecraft:light_gray_concrete replace
setblock ~103 ~73 ~620 minecraft:light_gray_concrete replace
setblock ~112 ~73 ~624 minecraft:light_gray_concrete replace
setblock ~114 ~73 ~626 minecraft:light_gray_concrete replace
setblock ~116 ~73 ~626 minecraft:light_gray_concrete replace
setblock ~79 ~73 ~628 minecraft:light_gray_concrete replace
setblock ~106 ~73 ~632 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~636 minecraft:light_gray_concrete replace
setblock ~121 ~73 ~644 minecraft:light_gray_concrete replace
setblock ~129 ~73 ~646 minecraft:light_gray_concrete replace
setblock ~131 ~73 ~646 minecraft:light_gray_concrete replace
setblock ~82 ~73 ~648 minecraft:light_gray_concrete replace
setblock ~109 ~73 ~652 minecraft:light_gray_concrete replace
setblock ~118 ~73 ~656 minecraft:light_gray_concrete replace
setblock ~126 ~73 ~658 minecraft:light_gray_concrete replace
setblock ~128 ~73 ~658 minecraft:light_gray_concrete replace
fill ~114 ~74 ~380 ~114 ~74 ~384 minecraft:light_gray_concrete replace
fill ~108 ~74 ~388 ~108 ~74 ~656 minecraft:light_gray_concrete replace
fill ~84 ~74 ~392 ~84 ~74 ~396 minecraft:light_gray_concrete replace
fill ~87 ~74 ~600 ~87 ~74 ~604 minecraft:light_gray_concrete replace
fill ~90 ~74 ~604 ~90 ~74 ~608 minecraft:light_gray_concrete replace
fill ~93 ~74 ~608 ~93 ~74 ~612 minecraft:light_gray_concrete replace
fill ~96 ~74 ~612 ~96 ~74 ~616 minecraft:light_gray_concrete replace
fill ~99 ~74 ~616 ~99 ~74 ~620 minecraft:light_gray_concrete replace
fill ~102 ~74 ~620 ~102 ~74 ~624 minecraft:light_gray_concrete replace
fill ~111 ~74 ~624 ~111 ~74 ~628 minecraft:light_gray_concrete replace
fill ~78 ~74 ~628 ~78 ~74 ~632 minecraft:light_gray_concrete replace
fill ~105 ~74 ~632 ~105 ~74 ~636 minecraft:light_gray_concrete replace
fill ~120 ~74 ~644 ~120 ~74 ~648 minecraft:light_gray_concrete replace
fill ~81 ~74 ~648 ~81 ~74 ~652 minecraft:light_gray_concrete replace
fill ~117 ~74 ~656 ~117 ~74 ~660 minecraft:light_gray_concrete replace
setblock ~115 ~75 ~380 minecraft:light_gray_concrete replace
setblock ~114 ~75 ~385 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~388 minecraft:light_gray_concrete replace
setblock ~84 ~75 ~397 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~401 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~403 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~417 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~419 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~433 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~435 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~449 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~451 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~465 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~467 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~480 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~495 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~497 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~511 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~513 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~520 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~543 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~545 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~560 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~573 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~575 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~589 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~591 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~596 minecraft:light_gray_concrete replace
setblock ~87 ~75 ~605 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~605 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~607 minecraft:light_gray_concrete replace
setblock ~90 ~75 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~75 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~75 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~75 ~621 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~621 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~623 minecraft:light_gray_concrete replace
setblock ~112 ~75 ~624 minecraft:light_gray_concrete replace
setblock ~102 ~75 ~625 minecraft:light_gray_concrete replace
setblock ~111 ~75 ~629 minecraft:light_gray_concrete replace
setblock ~78 ~75 ~633 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~636 minecraft:light_gray_concrete replace
setblock ~105 ~75 ~637 minecraft:light_gray_concrete replace
setblock ~120 ~75 ~649 minecraft:light_gray_concrete replace
setblock ~109 ~75 ~652 minecraft:light_gray_concrete replace
setblock ~81 ~75 ~653 minecraft:light_gray_concrete replace
setblock ~108 ~75 ~657 minecraft:light_gray_concrete replace
setblock ~117 ~75 ~661 minecraft:light_gray_concrete replace
fill ~114 ~76 ~386 ~116 ~76 ~386 minecraft:light_gray_concrete replace
fill ~115 ~76 ~387 ~115 ~76 ~388 minecraft:light_gray_concrete replace
fill ~81 ~76 ~398 ~84 ~76 ~398 minecraft:light_gray_concrete replace
fill ~82 ~76 ~399 ~82 ~76 ~400 minecraft:light_gray_concrete replace
fill ~78 ~76 ~606 ~89 ~76 ~606 minecraft:light_gray_concrete replace
fill ~79 ~76 ~607 ~79 ~76 ~608 minecraft:light_gray_concrete replace
fill ~88 ~76 ~607 ~88 ~76 ~608 minecraft:light_gray_concrete replace
fill ~78 ~76 ~610 ~92 ~76 ~610 minecraft:light_gray_concrete replace
fill ~79 ~76 ~611 ~79 ~76 ~612 minecraft:light_gray_concrete replace
fill ~91 ~76 ~611 ~91 ~76 ~612 minecraft:light_gray_concrete replace
fill ~78 ~76 ~614 ~95 ~76 ~614 minecraft:light_gray_concrete replace
fill ~79 ~76 ~615 ~79 ~76 ~616 minecraft:light_gray_concrete replace
fill ~94 ~76 ~615 ~94 ~76 ~616 minecraft:light_gray_concrete replace
fill ~78 ~76 ~618 ~98 ~76 ~618 minecraft:light_gray_concrete replace
fill ~79 ~76 ~619 ~79 ~76 ~620 minecraft:light_gray_concrete replace
fill ~97 ~76 ~619 ~97 ~76 ~620 minecraft:light_gray_concrete replace
fill ~78 ~76 ~622 ~101 ~76 ~622 minecraft:light_gray_concrete replace
fill ~79 ~76 ~623 ~79 ~76 ~624 minecraft:light_gray_concrete replace
fill ~100 ~76 ~623 ~100 ~76 ~624 minecraft:light_gray_concrete replace
fill ~78 ~76 ~626 ~104 ~76 ~626 minecraft:light_gray_concrete replace
fill ~79 ~76 ~627 ~79 ~76 ~628 minecraft:light_gray_concrete replace
fill ~103 ~76 ~627 ~103 ~76 ~628 minecraft:light_gray_concrete replace
fill ~108 ~76 ~630 ~111 ~76 ~630 minecraft:light_gray_concrete replace
fill ~109 ~76 ~631 ~109 ~76 ~632 minecraft:light_gray_concrete replace
fill ~78 ~76 ~634 ~80 ~76 ~634 minecraft:light_gray_concrete replace
fill ~79 ~76 ~635 ~79 ~76 ~636 minecraft:light_gray_concrete replace
fill ~78 ~76 ~638 ~107 ~76 ~638 minecraft:light_gray_concrete replace
fill ~79 ~76 ~639 ~79 ~76 ~640 minecraft:light_gray_concrete replace
fill ~106 ~76 ~639 ~106 ~76 ~640 minecraft:light_gray_concrete replace
fill ~120 ~76 ~650 ~125 ~76 ~650 minecraft:light_gray_concrete replace
fill ~124 ~76 ~651 ~124 ~76 ~652 minecraft:light_gray_concrete replace
fill ~78 ~76 ~654 ~86 ~76 ~654 minecraft:light_gray_concrete replace
fill ~79 ~76 ~655 ~79 ~76 ~656 minecraft:light_gray_concrete replace
fill ~85 ~76 ~655 ~85 ~76 ~656 minecraft:light_gray_concrete replace
fill ~78 ~76 ~658 ~119 ~76 ~658 minecraft:light_gray_concrete replace
fill ~79 ~76 ~659 ~79 ~76 ~660 minecraft:light_gray_concrete replace
fill ~112 ~76 ~659 ~112 ~76 ~660 minecraft:light_gray_concrete replace
fill ~118 ~76 ~659 ~118 ~76 ~660 minecraft:light_gray_concrete replace
fill ~117 ~76 ~662 ~122 ~76 ~662 minecraft:light_gray_concrete replace
fill ~121 ~76 ~663 ~121 ~76 ~664 minecraft:light_gray_concrete replace
setblock ~115 ~77 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~77 ~400 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~608 minecraft:light_gray_concrete replace
setblock ~88 ~77 ~608 minecraft:light_gray_concrete replace
setblock ~81 ~77 ~610 minecraft:light_gray_concrete replace
setblock ~83 ~77 ~610 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~612 minecraft:light_gray_concrete replace
setblock ~91 ~77 ~612 minecraft:light_gray_concrete replace
setblock ~84 ~77 ~614 minecraft:light_gray_concrete replace
setblock ~86 ~77 ~614 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~616 minecraft:light_gray_concrete replace
setblock ~94 ~77 ~616 minecraft:light_gray_concrete replace
setblock ~87 ~77 ~618 minecraft:light_gray_concrete replace
setblock ~89 ~77 ~618 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~620 minecraft:light_gray_concrete replace
setblock ~97 ~77 ~620 minecraft:light_gray_concrete replace
setblock ~90 ~77 ~622 minecraft:light_gray_concrete replace
setblock ~92 ~77 ~622 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~624 minecraft:light_gray_concrete replace
setblock ~100 ~77 ~624 minecraft:light_gray_concrete replace
setblock ~93 ~77 ~626 minecraft:light_gray_concrete replace
setblock ~95 ~77 ~626 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~628 minecraft:light_gray_concrete replace
setblock ~103 ~77 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~77 ~632 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~636 minecraft:light_gray_concrete replace
setblock ~96 ~77 ~638 minecraft:light_gray_concrete replace
setblock ~98 ~77 ~638 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~640 minecraft:light_gray_concrete replace
setblock ~106 ~77 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~77 ~652 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~656 minecraft:light_gray_concrete replace
setblock ~85 ~77 ~656 minecraft:light_gray_concrete replace
setblock ~82 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~84 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~99 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~101 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~117 ~77 ~658 minecraft:light_gray_concrete replace
setblock ~79 ~77 ~660 minecraft:light_gray_concrete replace
setblock ~112 ~77 ~660 minecraft:light_gray_concrete replace
setblock ~118 ~77 ~660 minecraft:light_gray_concrete replace
setblock ~121 ~77 ~664 minecraft:light_gray_concrete replace
fill ~114 ~78 ~384 ~114 ~78 ~388 minecraft:light_gray_concrete replace
fill ~81 ~78 ~396 ~81 ~78 ~400 minecraft:light_gray_concrete replace
fill ~87 ~78 ~600 ~87 ~78 ~608 minecraft:light_gray_concrete replace
fill ~78 ~78 ~604 ~78 ~78 ~660 minecraft:light_gray_concrete replace
fill ~90 ~78 ~608 ~90 ~78 ~612 minecraft:light_gray_concrete replace
fill ~93 ~78 ~612 ~93 ~78 ~616 minecraft:light_gray_concrete replace
fill ~96 ~78 ~616 ~96 ~78 ~620 minecraft:light_gray_concrete replace
fill ~99 ~78 ~620 ~99 ~78 ~624 minecraft:light_gray_concrete replace
fill ~102 ~78 ~624 ~102 ~78 ~628 minecraft:light_gray_concrete replace
fill ~108 ~78 ~628 ~108 ~78 ~632 minecraft:light_gray_concrete replace
fill ~105 ~78 ~636 ~105 ~78 ~640 minecraft:light_gray_concrete replace
fill ~123 ~78 ~644 ~123 ~78 ~652 minecraft:light_gray_concrete replace
fill ~84 ~78 ~648 ~84 ~78 ~656 minecraft:light_gray_concrete replace
fill ~117 ~78 ~652 ~117 ~78 ~660 minecraft:light_gray_concrete replace
fill ~111 ~78 ~656 ~111 ~78 ~660 minecraft:light_gray_concrete replace
fill ~120 ~78 ~660 ~120 ~78 ~664 minecraft:light_gray_concrete replace
setblock ~114 ~79 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~79 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~79 ~599 minecraft:light_gray_concrete replace
setblock ~87 ~79 ~601 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~603 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~79 ~607 minecraft:light_gray_concrete replace
setblock ~93 ~79 ~611 minecraft:light_gray_concrete replace
setblock ~96 ~79 ~615 minecraft:light_gray_concrete replace
setblock ~99 ~79 ~619 minecraft:light_gray_concrete replace
setblock ~102 ~79 ~623 minecraft:light_gray_concrete replace
setblock ~108 ~79 ~627 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~629 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~631 minecraft:light_gray_concrete replace
setblock ~105 ~79 ~635 minecraft:light_gray_concrete replace
setblock ~123 ~79 ~643 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~645 minecraft:light_gray_concrete replace
setblock ~123 ~79 ~645 minecraft:light_gray_concrete replace
setblock ~78 ~79 ~647 minecraft:light_gray_concrete replace
setblock ~84 ~79 ~647 minecraft:light_gray_concrete replace
setblock ~84 ~79 ~649 minecraft:light_gray_concrete replace
setblock ~117 ~79 ~651 minecraft:light_gray_concrete replace
setblock ~117 ~79 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~79 ~655 minecraft:light_gray_concrete replace
setblock ~120 ~79 ~659 minecraft:light_gray_concrete replace
setblock ~112 ~79 ~660 minecraft:light_gray_concrete replace
fill ~115 ~80 ~380 ~115 ~80 ~381 minecraft:light_gray_concrete replace
fill ~114 ~80 ~382 ~116 ~80 ~382 minecraft:light_gray_concrete replace
fill ~82 ~80 ~392 ~82 ~80 ~393 minecraft:light_gray_concrete replace
fill ~81 ~80 ~394 ~83 ~80 ~394 minecraft:light_gray_concrete replace
fill ~88 ~80 ~596 ~88 ~80 ~597 minecraft:light_gray_concrete replace
fill ~87 ~80 ~598 ~89 ~80 ~598 minecraft:light_gray_concrete replace
fill ~79 ~80 ~600 ~79 ~80 ~601 minecraft:light_gray_concrete replace
fill ~78 ~80 ~602 ~80 ~80 ~602 minecraft:light_gray_concrete replace
fill ~91 ~80 ~604 ~91 ~80 ~605 minecraft:light_gray_concrete replace
fill ~90 ~80 ~606 ~92 ~80 ~606 minecraft:light_gray_concrete replace
fill ~94 ~80 ~608 ~94 ~80 ~609 minecraft:light_gray_concrete replace
fill ~93 ~80 ~610 ~95 ~80 ~610 minecraft:light_gray_concrete replace
fill ~97 ~80 ~612 ~97 ~80 ~613 minecraft:light_gray_concrete replace
fill ~96 ~80 ~614 ~98 ~80 ~614 minecraft:light_gray_concrete replace
fill ~100 ~80 ~616 ~100 ~80 ~617 minecraft:light_gray_concrete replace
fill ~99 ~80 ~618 ~101 ~80 ~618 minecraft:light_gray_concrete replace
fill ~103 ~80 ~620 ~103 ~80 ~621 minecraft:light_gray_concrete replace
fill ~102 ~80 ~622 ~104 ~80 ~622 minecraft:light_gray_concrete replace
fill ~109 ~80 ~624 ~109 ~80 ~625 minecraft:light_gray_concrete replace
fill ~108 ~80 ~626 ~110 ~80 ~626 minecraft:light_gray_concrete replace
fill ~106 ~80 ~632 ~106 ~80 ~633 minecraft:light_gray_concrete replace
fill ~105 ~80 ~634 ~107 ~80 ~634 minecraft:light_gray_concrete replace
fill ~124 ~80 ~640 ~124 ~80 ~641 minecraft:light_gray_concrete replace
fill ~123 ~80 ~642 ~125 ~80 ~642 minecraft:light_gray_concrete replace
fill ~85 ~80 ~644 ~85 ~80 ~645 minecraft:light_gray_concrete replace
fill ~84 ~80 ~646 ~86 ~80 ~646 minecraft:light_gray_concrete replace
fill ~118 ~80 ~648 ~118 ~80 ~649 minecraft:light_gray_concrete replace
fill ~117 ~80 ~650 ~119 ~80 ~650 minecraft:light_gray_concrete replace
fill ~112 ~80 ~652 ~112 ~80 ~653 minecraft:light_gray_concrete replace
fill ~111 ~80 ~654 ~113 ~80 ~654 minecraft:light_gray_concrete replace
fill ~121 ~80 ~656 ~121 ~80 ~657 minecraft:light_gray_concrete replace
fill ~120 ~80 ~658 ~122 ~80 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~81 ~380 minecraft:light_gray_concrete replace
setblock ~82 ~81 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~81 ~596 minecraft:light_gray_concrete replace
setblock ~79 ~81 ~600 minecraft:light_gray_concrete replace
setblock ~91 ~81 ~604 minecraft:light_gray_concrete replace
setblock ~94 ~81 ~608 minecraft:light_gray_concrete replace
setblock ~97 ~81 ~612 minecraft:light_gray_concrete replace
setblock ~100 ~81 ~616 minecraft:light_gray_concrete replace
setblock ~103 ~81 ~620 minecraft:light_gray_concrete replace
setblock ~109 ~81 ~624 minecraft:light_gray_concrete replace
setblock ~106 ~81 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~81 ~640 minecraft:light_gray_concrete replace
setblock ~85 ~81 ~644 minecraft:light_gray_concrete replace
setblock ~118 ~81 ~648 minecraft:light_gray_concrete replace
setblock ~112 ~81 ~652 minecraft:light_gray_concrete replace
setblock ~121 ~81 ~656 minecraft:light_gray_concrete replace
fill ~114 ~82 ~380 ~114 ~82 ~384 minecraft:light_gray_concrete replace
fill ~81 ~82 ~392 ~81 ~82 ~396 minecraft:light_gray_concrete replace
fill ~87 ~82 ~596 ~87 ~82 ~600 minecraft:light_gray_concrete replace
fill ~78 ~82 ~600 ~78 ~82 ~604 minecraft:light_gray_concrete replace
fill ~90 ~82 ~604 ~90 ~82 ~608 minecraft:light_gray_concrete replace
fill ~93 ~82 ~608 ~93 ~82 ~612 minecraft:light_gray_concrete replace
fill ~96 ~82 ~612 ~96 ~82 ~616 minecraft:light_gray_concrete replace
fill ~99 ~82 ~616 ~99 ~82 ~620 minecraft:light_gray_concrete replace
fill ~102 ~82 ~620 ~102 ~82 ~624 minecraft:light_gray_concrete replace
fill ~108 ~82 ~624 ~108 ~82 ~628 minecraft:light_gray_concrete replace
fill ~105 ~82 ~632 ~105 ~82 ~636 minecraft:light_gray_concrete replace
fill ~123 ~82 ~640 ~123 ~82 ~644 minecraft:light_gray_concrete replace
fill ~84 ~82 ~644 ~84 ~82 ~648 minecraft:light_gray_concrete replace
fill ~117 ~82 ~648 ~117 ~82 ~652 minecraft:light_gray_concrete replace
fill ~111 ~82 ~652 ~111 ~82 ~656 minecraft:light_gray_concrete replace
fill ~120 ~82 ~656 ~120 ~82 ~660 minecraft:light_gray_concrete replace
setblock ~114 ~83 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~83 ~397 minecraft:light_gray_concrete replace
setblock ~79 ~83 ~600 minecraft:light_gray_concrete replace
setblock ~87 ~83 ~601 minecraft:light_gray_concrete replace
setblock ~78 ~83 ~605 minecraft:light_gray_concrete replace
setblock ~90 ~83 ~609 minecraft:light_gray_concrete replace
setblock ~93 ~83 ~613 minecraft:light_gray_concrete replace
setblock ~96 ~83 ~617 minecraft:light_gray_concrete replace
setblock ~99 ~83 ~621 minecraft:light_gray_concrete replace
setblock ~102 ~83 ~625 minecraft:light_gray_concrete replace
setblock ~108 ~83 ~629 minecraft:light_gray_concrete replace
setblock ~105 ~83 ~637 minecraft:light_gray_concrete replace
setblock ~123 ~83 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~83 ~649 minecraft:light_gray_concrete replace
setblock ~112 ~83 ~652 minecraft:light_gray_concrete replace
setblock ~117 ~83 ~653 minecraft:light_gray_concrete replace
setblock ~111 ~83 ~657 minecraft:light_gray_concrete replace
setblock ~120 ~83 ~661 minecraft:light_gray_concrete replace
fill ~114 ~84 ~386 ~116 ~84 ~386 minecraft:light_gray_concrete replace
fill ~115 ~84 ~387 ~115 ~84 ~388 minecraft:light_gray_concrete replace
fill ~81 ~84 ~398 ~83 ~84 ~398 minecraft:light_gray_concrete replace
fill ~82 ~84 ~399 ~82 ~84 ~400 minecraft:light_gray_concrete replace
fill ~87 ~84 ~602 ~89 ~84 ~602 minecraft:light_gray_concrete replace
fill ~88 ~84 ~603 ~88 ~84 ~604 minecraft:light_gray_concrete replace
fill ~78 ~84 ~606 ~80 ~84 ~606 minecraft:light_gray_concrete replace
fill ~79 ~84 ~607 ~79 ~84 ~608 minecraft:light_gray_concrete replace
fill ~90 ~84 ~610 ~92 ~84 ~610 minecraft:light_gray_concrete replace
fill ~91 ~84 ~611 ~91 ~84 ~612 minecraft:light_gray_concrete replace
fill ~93 ~84 ~614 ~95 ~84 ~614 minecraft:light_gray_concrete replace
fill ~94 ~84 ~615 ~94 ~84 ~616 minecraft:light_gray_concrete replace
fill ~96 ~84 ~618 ~98 ~84 ~618 minecraft:light_gray_concrete replace
fill ~97 ~84 ~619 ~97 ~84 ~620 minecraft:light_gray_concrete replace
fill ~99 ~84 ~622 ~101 ~84 ~622 minecraft:light_gray_concrete replace
fill ~100 ~84 ~623 ~100 ~84 ~624 minecraft:light_gray_concrete replace
fill ~102 ~84 ~626 ~104 ~84 ~626 minecraft:light_gray_concrete replace
fill ~103 ~84 ~627 ~103 ~84 ~628 minecraft:light_gray_concrete replace
fill ~108 ~84 ~630 ~110 ~84 ~630 minecraft:light_gray_concrete replace
fill ~109 ~84 ~631 ~109 ~84 ~632 minecraft:light_gray_concrete replace
fill ~105 ~84 ~638 ~107 ~84 ~638 minecraft:light_gray_concrete replace
fill ~106 ~84 ~639 ~106 ~84 ~640 minecraft:light_gray_concrete replace
fill ~123 ~84 ~646 ~125 ~84 ~646 minecraft:light_gray_concrete replace
fill ~124 ~84 ~647 ~124 ~84 ~648 minecraft:light_gray_concrete replace
fill ~84 ~84 ~650 ~86 ~84 ~650 minecraft:light_gray_concrete replace
fill ~85 ~84 ~651 ~85 ~84 ~652 minecraft:light_gray_concrete replace
fill ~117 ~84 ~654 ~119 ~84 ~654 minecraft:light_gray_concrete replace
fill ~118 ~84 ~655 ~118 ~84 ~656 minecraft:light_gray_concrete replace
fill ~111 ~84 ~658 ~113 ~84 ~658 minecraft:light_gray_concrete replace
fill ~112 ~84 ~659 ~112 ~84 ~660 minecraft:light_gray_concrete replace
fill ~120 ~84 ~662 ~122 ~84 ~662 minecraft:light_gray_concrete replace
fill ~121 ~84 ~663 ~121 ~84 ~664 minecraft:light_gray_concrete replace
setblock ~115 ~85 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~85 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~85 ~604 minecraft:light_gray_concrete replace
setblock ~79 ~85 ~608 minecraft:light_gray_concrete replace
setblock ~91 ~85 ~612 minecraft:light_gray_concrete replace
setblock ~94 ~85 ~616 minecraft:light_gray_concrete replace
setblock ~97 ~85 ~620 minecraft:light_gray_concrete replace
setblock ~100 ~85 ~624 minecraft:light_gray_concrete replace
setblock ~103 ~85 ~628 minecraft:light_gray_concrete replace
setblock ~109 ~85 ~632 minecraft:light_gray_concrete replace
setblock ~106 ~85 ~640 minecraft:light_gray_concrete replace
setblock ~124 ~85 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~85 ~652 minecraft:light_gray_concrete replace
setblock ~118 ~85 ~656 minecraft:light_gray_concrete replace
setblock ~112 ~85 ~660 minecraft:light_gray_concrete replace
setblock ~121 ~85 ~664 minecraft:light_gray_concrete replace
fill ~114 ~86 ~384 ~114 ~86 ~388 minecraft:light_gray_concrete replace
fill ~81 ~86 ~396 ~81 ~86 ~400 minecraft:light_gray_concrete replace
fill ~87 ~86 ~600 ~87 ~86 ~604 minecraft:light_gray_concrete replace
fill ~78 ~86 ~604 ~78 ~86 ~608 minecraft:light_gray_concrete replace
fill ~90 ~86 ~608 ~90 ~86 ~612 minecraft:light_gray_concrete replace
fill ~93 ~86 ~612 ~93 ~86 ~616 minecraft:light_gray_concrete replace
fill ~96 ~86 ~616 ~96 ~86 ~620 minecraft:light_gray_concrete replace
fill ~99 ~86 ~620 ~99 ~86 ~624 minecraft:light_gray_concrete replace
fill ~102 ~86 ~624 ~102 ~86 ~628 minecraft:light_gray_concrete replace
fill ~108 ~86 ~628 ~108 ~86 ~632 minecraft:light_gray_concrete replace
fill ~105 ~86 ~636 ~105 ~86 ~640 minecraft:light_gray_concrete replace
fill ~123 ~86 ~644 ~123 ~86 ~648 minecraft:light_gray_concrete replace
fill ~84 ~86 ~648 ~84 ~86 ~652 minecraft:light_gray_concrete replace
fill ~117 ~86 ~652 ~117 ~86 ~656 minecraft:light_gray_concrete replace
fill ~111 ~86 ~656 ~111 ~86 ~660 minecraft:light_gray_concrete replace
fill ~120 ~86 ~660 ~120 ~86 ~664 minecraft:light_gray_concrete replace
setblock ~114 ~87 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~87 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~87 ~599 minecraft:light_gray_concrete replace
setblock ~78 ~87 ~603 minecraft:light_gray_concrete replace
setblock ~90 ~87 ~607 minecraft:light_gray_concrete replace
setblock ~93 ~87 ~611 minecraft:light_gray_concrete replace
setblock ~96 ~87 ~615 minecraft:light_gray_concrete replace
setblock ~99 ~87 ~619 minecraft:light_gray_concrete replace
setblock ~102 ~87 ~623 minecraft:light_gray_concrete replace
setblock ~108 ~87 ~627 minecraft:light_gray_concrete replace
setblock ~105 ~87 ~635 minecraft:light_gray_concrete replace
setblock ~123 ~87 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~87 ~647 minecraft:light_gray_concrete replace
setblock ~117 ~87 ~651 minecraft:light_gray_concrete replace
setblock ~111 ~87 ~655 minecraft:light_gray_concrete replace
setblock ~120 ~87 ~659 minecraft:light_gray_concrete replace
setblock ~112 ~87 ~660 minecraft:light_gray_concrete replace
fill ~115 ~88 ~380 ~115 ~88 ~381 minecraft:light_gray_concrete replace
fill ~114 ~88 ~382 ~116 ~88 ~382 minecraft:light_gray_concrete replace
fill ~82 ~88 ~392 ~82 ~88 ~393 minecraft:light_gray_concrete replace
fill ~81 ~88 ~394 ~83 ~88 ~394 minecraft:light_gray_concrete replace
fill ~88 ~88 ~596 ~88 ~88 ~597 minecraft:light_gray_concrete replace
fill ~87 ~88 ~598 ~89 ~88 ~598 minecraft:light_gray_concrete replace
fill ~79 ~88 ~600 ~79 ~88 ~601 minecraft:light_gray_concrete replace
fill ~78 ~88 ~602 ~80 ~88 ~602 minecraft:light_gray_concrete replace
fill ~91 ~88 ~604 ~91 ~88 ~605 minecraft:light_gray_concrete replace
fill ~90 ~88 ~606 ~92 ~88 ~606 minecraft:light_gray_concrete replace
fill ~94 ~88 ~608 ~94 ~88 ~609 minecraft:light_gray_concrete replace
fill ~93 ~88 ~610 ~95 ~88 ~610 minecraft:light_gray_concrete replace
fill ~97 ~88 ~612 ~97 ~88 ~613 minecraft:light_gray_concrete replace
fill ~96 ~88 ~614 ~98 ~88 ~614 minecraft:light_gray_concrete replace
fill ~100 ~88 ~616 ~100 ~88 ~617 minecraft:light_gray_concrete replace
fill ~99 ~88 ~618 ~101 ~88 ~618 minecraft:light_gray_concrete replace
fill ~103 ~88 ~620 ~103 ~88 ~621 minecraft:light_gray_concrete replace
fill ~102 ~88 ~622 ~104 ~88 ~622 minecraft:light_gray_concrete replace
fill ~109 ~88 ~624 ~109 ~88 ~625 minecraft:light_gray_concrete replace
fill ~108 ~88 ~626 ~110 ~88 ~626 minecraft:light_gray_concrete replace
fill ~106 ~88 ~632 ~106 ~88 ~633 minecraft:light_gray_concrete replace
fill ~105 ~88 ~634 ~107 ~88 ~634 minecraft:light_gray_concrete replace
fill ~124 ~88 ~640 ~124 ~88 ~641 minecraft:light_gray_concrete replace
fill ~123 ~88 ~642 ~125 ~88 ~642 minecraft:light_gray_concrete replace
fill ~85 ~88 ~644 ~85 ~88 ~645 minecraft:light_gray_concrete replace
fill ~84 ~88 ~646 ~86 ~88 ~646 minecraft:light_gray_concrete replace
fill ~118 ~88 ~648 ~118 ~88 ~649 minecraft:light_gray_concrete replace
fill ~117 ~88 ~650 ~119 ~88 ~650 minecraft:light_gray_concrete replace
fill ~112 ~88 ~652 ~112 ~88 ~653 minecraft:light_gray_concrete replace
fill ~111 ~88 ~654 ~113 ~88 ~654 minecraft:light_gray_concrete replace
fill ~121 ~88 ~656 ~121 ~88 ~657 minecraft:light_gray_concrete replace
fill ~120 ~88 ~658 ~122 ~88 ~658 minecraft:light_gray_concrete replace
setblock ~115 ~89 ~380 minecraft:light_gray_concrete replace
setblock ~82 ~89 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~89 ~596 minecraft:light_gray_concrete replace
setblock ~79 ~89 ~600 minecraft:light_gray_concrete replace
setblock ~91 ~89 ~604 minecraft:light_gray_concrete replace
setblock ~94 ~89 ~608 minecraft:light_gray_concrete replace
setblock ~97 ~89 ~612 minecraft:light_gray_concrete replace
setblock ~100 ~89 ~616 minecraft:light_gray_concrete replace
setblock ~103 ~89 ~620 minecraft:light_gray_concrete replace
setblock ~109 ~89 ~624 minecraft:light_gray_concrete replace
setblock ~106 ~89 ~632 minecraft:light_gray_concrete replace
setblock ~124 ~89 ~640 minecraft:light_gray_concrete replace
setblock ~85 ~89 ~644 minecraft:light_gray_concrete replace
setblock ~118 ~89 ~648 minecraft:light_gray_concrete replace
setblock ~112 ~89 ~652 minecraft:light_gray_concrete replace
setblock ~121 ~89 ~656 minecraft:light_gray_concrete replace
fill ~114 ~90 ~380 ~114 ~90 ~384 minecraft:light_gray_concrete replace
fill ~81 ~90 ~392 ~81 ~90 ~396 minecraft:light_gray_concrete replace
fill ~87 ~90 ~596 ~87 ~90 ~600 minecraft:light_gray_concrete replace
fill ~78 ~90 ~600 ~78 ~90 ~604 minecraft:light_gray_concrete replace
fill ~90 ~90 ~604 ~90 ~90 ~608 minecraft:light_gray_concrete replace
fill ~93 ~90 ~608 ~93 ~90 ~612 minecraft:light_gray_concrete replace
