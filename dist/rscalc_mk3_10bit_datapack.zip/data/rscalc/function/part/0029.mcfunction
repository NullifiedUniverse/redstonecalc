setblock ~171 ~152 ~315 minecraft:redstone_wire replace
setblock ~168 ~152 ~319 minecraft:redstone_wire replace
setblock ~165 ~152 ~323 minecraft:redstone_wire replace
setblock ~162 ~152 ~327 minecraft:redstone_wire replace
setblock ~159 ~152 ~331 minecraft:redstone_wire replace
setblock ~156 ~152 ~335 minecraft:redstone_wire replace
setblock ~153 ~152 ~339 minecraft:redstone_wire replace
setblock ~150 ~152 ~343 minecraft:redstone_wire replace
setblock ~147 ~152 ~347 minecraft:redstone_wire replace
setblock ~144 ~152 ~351 minecraft:redstone_wire replace
setblock ~141 ~152 ~355 minecraft:redstone_wire replace
setblock ~138 ~152 ~359 minecraft:redstone_wire replace
setblock ~135 ~152 ~363 minecraft:redstone_wire replace
setblock ~132 ~152 ~367 minecraft:redstone_wire replace
setblock ~129 ~152 ~371 minecraft:redstone_wire replace
setblock ~126 ~152 ~375 minecraft:redstone_wire replace
setblock ~123 ~152 ~379 minecraft:redstone_wire replace
setblock ~120 ~152 ~383 minecraft:redstone_wire replace
setblock ~117 ~152 ~387 minecraft:redstone_wire replace
setblock ~114 ~152 ~391 minecraft:redstone_wire replace
setblock ~111 ~152 ~395 minecraft:redstone_wire replace
setblock ~108 ~152 ~399 minecraft:redstone_wire replace
setblock ~105 ~152 ~403 minecraft:redstone_wire replace
setblock ~102 ~152 ~407 minecraft:redstone_wire replace
setblock ~99 ~152 ~411 minecraft:redstone_wire replace
setblock ~96 ~152 ~415 minecraft:redstone_wire replace
setblock ~93 ~152 ~419 minecraft:redstone_wire replace
setblock ~90 ~152 ~423 minecraft:redstone_wire replace
setblock ~87 ~152 ~427 minecraft:redstone_wire replace
setblock ~84 ~152 ~431 minecraft:redstone_wire replace
setblock ~78 ~152 ~447 minecraft:redstone_wire replace
setblock ~246 ~152 ~475 minecraft:redstone_wire replace
setblock ~234 ~152 ~479 minecraft:redstone_wire replace
setblock ~240 ~152 ~499 minecraft:redstone_wire replace
setblock ~237 ~152 ~511 minecraft:redstone_wire replace
setblock ~243 ~152 ~535 minecraft:redstone_wire replace
setblock ~255 ~152 ~539 minecraft:redstone_wire replace
setblock ~249 ~152 ~543 minecraft:redstone_wire replace
setblock ~258 ~152 ~567 minecraft:redstone_wire replace
setblock ~252 ~152 ~575 minecraft:redstone_wire replace
setblock ~267 ~152 ~599 minecraft:redstone_wire replace
setblock ~264 ~152 ~603 minecraft:redstone_wire replace
setblock ~261 ~152 ~607 minecraft:redstone_wire replace
setblock ~276 ~152 ~643 minecraft:redstone_wire replace
setblock ~270 ~152 ~651 minecraft:redstone_wire replace
setblock ~273 ~152 ~659 minecraft:redstone_wire replace
setblock ~106 ~153 ~229 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~153 ~230 ~113 ~153 ~230 minecraft:redstone_wire replace
setblock ~115 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~153 ~230 ~130 ~153 ~230 minecraft:redstone_wire replace
setblock ~132 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~153 ~230 ~147 ~153 ~230 minecraft:redstone_wire replace
setblock ~149 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~153 ~230 ~164 ~153 ~230 minecraft:redstone_wire replace
setblock ~166 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~153 ~230 ~181 ~153 ~230 minecraft:redstone_wire replace
setblock ~183 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~153 ~230 ~198 ~153 ~230 minecraft:redstone_wire replace
setblock ~200 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~153 ~230 ~215 ~153 ~230 minecraft:redstone_wire replace
setblock ~217 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~153 ~230 ~231 ~153 ~230 minecraft:redstone_wire replace
setblock ~82 ~153 ~233 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~153 ~234 ~83 ~153 ~234 minecraft:redstone_wire replace
setblock ~103 ~153 ~237 minecraft:redstone_wire replace
fill ~102 ~153 ~238 ~111 ~153 ~238 minecraft:redstone_wire replace
setblock ~113 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~153 ~238 ~128 ~153 ~238 minecraft:redstone_wire replace
setblock ~130 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~153 ~238 ~145 ~153 ~238 minecraft:redstone_wire replace
setblock ~147 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~153 ~238 ~162 ~153 ~238 minecraft:redstone_wire replace
setblock ~164 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~153 ~238 ~179 ~153 ~238 minecraft:redstone_wire replace
setblock ~181 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~153 ~238 ~196 ~153 ~238 minecraft:redstone_wire replace
setblock ~198 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~153 ~238 ~213 ~153 ~238 minecraft:redstone_wire replace
setblock ~215 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~153 ~238 ~228 ~153 ~238 minecraft:redstone_wire replace
setblock ~103 ~153 ~241 minecraft:redstone_wire replace
fill ~102 ~153 ~242 ~107 ~153 ~242 minecraft:redstone_wire replace
setblock ~109 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~242 ~124 ~153 ~242 minecraft:redstone_wire replace
setblock ~126 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~242 ~141 ~153 ~242 minecraft:redstone_wire replace
setblock ~143 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~242 ~158 ~153 ~242 minecraft:redstone_wire replace
setblock ~160 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~153 ~242 ~175 ~153 ~242 minecraft:redstone_wire replace
setblock ~177 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~153 ~242 ~192 ~153 ~242 minecraft:redstone_wire replace
setblock ~194 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~153 ~242 ~209 ~153 ~242 minecraft:redstone_wire replace
setblock ~211 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~153 ~242 ~225 ~153 ~242 minecraft:redstone_wire replace
setblock ~103 ~153 ~245 minecraft:redstone_wire replace
fill ~102 ~153 ~246 ~111 ~153 ~246 minecraft:redstone_wire replace
setblock ~113 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~153 ~246 ~128 ~153 ~246 minecraft:redstone_wire replace
setblock ~130 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~153 ~246 ~145 ~153 ~246 minecraft:redstone_wire replace
setblock ~147 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~153 ~246 ~162 ~153 ~246 minecraft:redstone_wire replace
setblock ~164 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~153 ~246 ~179 ~153 ~246 minecraft:redstone_wire replace
setblock ~181 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~153 ~246 ~196 ~153 ~246 minecraft:redstone_wire replace
setblock ~198 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~153 ~246 ~213 ~153 ~246 minecraft:redstone_wire replace
setblock ~215 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~153 ~246 ~222 ~153 ~246 minecraft:redstone_wire replace
setblock ~103 ~153 ~249 minecraft:redstone_wire replace
fill ~102 ~153 ~250 ~104 ~153 ~250 minecraft:redstone_wire replace
setblock ~106 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~153 ~250 ~121 ~153 ~250 minecraft:redstone_wire replace
setblock ~123 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~153 ~250 ~138 ~153 ~250 minecraft:redstone_wire replace
setblock ~140 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~153 ~250 ~155 ~153 ~250 minecraft:redstone_wire replace
setblock ~157 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~250 ~172 ~153 ~250 minecraft:redstone_wire replace
setblock ~174 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~153 ~250 ~189 ~153 ~250 minecraft:redstone_wire replace
setblock ~191 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~153 ~250 ~206 ~153 ~250 minecraft:redstone_wire replace
setblock ~208 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~153 ~250 ~219 ~153 ~250 minecraft:redstone_wire replace
setblock ~103 ~153 ~253 minecraft:redstone_wire replace
setblock ~102 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~153 ~254 ~116 ~153 ~254 minecraft:redstone_wire replace
setblock ~118 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~153 ~254 ~133 ~153 ~254 minecraft:redstone_wire replace
setblock ~135 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~153 ~254 ~150 ~153 ~254 minecraft:redstone_wire replace
setblock ~152 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~153 ~254 ~167 ~153 ~254 minecraft:redstone_wire replace
setblock ~169 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~254 ~184 ~153 ~254 minecraft:redstone_wire replace
setblock ~186 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~153 ~254 ~201 ~153 ~254 minecraft:redstone_wire replace
setblock ~203 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~153 ~254 ~216 ~153 ~254 minecraft:redstone_wire replace
setblock ~103 ~153 ~257 minecraft:redstone_wire replace
fill ~102 ~153 ~258 ~112 ~153 ~258 minecraft:redstone_wire replace
setblock ~114 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~258 ~129 ~153 ~258 minecraft:redstone_wire replace
setblock ~131 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~258 ~146 ~153 ~258 minecraft:redstone_wire replace
setblock ~148 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~153 ~258 ~163 ~153 ~258 minecraft:redstone_wire replace
setblock ~165 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~153 ~258 ~180 ~153 ~258 minecraft:redstone_wire replace
setblock ~182 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~153 ~258 ~197 ~153 ~258 minecraft:redstone_wire replace
setblock ~199 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~153 ~258 ~213 ~153 ~258 minecraft:redstone_wire replace
setblock ~103 ~153 ~261 minecraft:redstone_wire replace
setblock ~102 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~153 ~262 ~116 ~153 ~262 minecraft:redstone_wire replace
setblock ~118 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~153 ~262 ~133 ~153 ~262 minecraft:redstone_wire replace
setblock ~135 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~153 ~262 ~150 ~153 ~262 minecraft:redstone_wire replace
setblock ~152 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~153 ~262 ~167 ~153 ~262 minecraft:redstone_wire replace
setblock ~169 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~262 ~184 ~153 ~262 minecraft:redstone_wire replace
setblock ~186 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~153 ~262 ~201 ~153 ~262 minecraft:redstone_wire replace
setblock ~203 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~153 ~262 ~210 ~153 ~262 minecraft:redstone_wire replace
setblock ~100 ~153 ~265 minecraft:redstone_wire replace
fill ~99 ~153 ~266 ~109 ~153 ~266 minecraft:redstone_wire replace
setblock ~111 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~153 ~266 ~126 ~153 ~266 minecraft:redstone_wire replace
setblock ~128 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~153 ~266 ~143 ~153 ~266 minecraft:redstone_wire replace
setblock ~145 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~266 ~160 ~153 ~266 minecraft:redstone_wire replace
setblock ~162 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~153 ~266 ~177 ~153 ~266 minecraft:redstone_wire replace
setblock ~179 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~153 ~266 ~194 ~153 ~266 minecraft:redstone_wire replace
setblock ~196 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~153 ~266 ~207 ~153 ~266 minecraft:redstone_wire replace
setblock ~100 ~153 ~269 minecraft:redstone_wire replace
fill ~99 ~153 ~270 ~104 ~153 ~270 minecraft:redstone_wire replace
setblock ~106 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~153 ~270 ~121 ~153 ~270 minecraft:redstone_wire replace
setblock ~123 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~153 ~270 ~138 ~153 ~270 minecraft:redstone_wire replace
setblock ~140 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~153 ~270 ~155 ~153 ~270 minecraft:redstone_wire replace
setblock ~157 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~270 ~172 ~153 ~270 minecraft:redstone_wire replace
setblock ~174 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~153 ~270 ~189 ~153 ~270 minecraft:redstone_wire replace
setblock ~191 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~153 ~270 ~204 ~153 ~270 minecraft:redstone_wire replace
setblock ~100 ~153 ~273 minecraft:redstone_wire replace
fill ~99 ~153 ~274 ~100 ~153 ~274 minecraft:redstone_wire replace
setblock ~102 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~274 ~117 ~153 ~274 minecraft:redstone_wire replace
setblock ~119 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~274 ~134 ~153 ~274 minecraft:redstone_wire replace
setblock ~136 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~153 ~274 ~151 ~153 ~274 minecraft:redstone_wire replace
setblock ~153 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~153 ~274 ~168 ~153 ~274 minecraft:redstone_wire replace
setblock ~170 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~153 ~274 ~185 ~153 ~274 minecraft:redstone_wire replace
setblock ~187 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~153 ~274 ~201 ~153 ~274 minecraft:redstone_wire replace
setblock ~100 ~153 ~277 minecraft:redstone_wire replace
fill ~99 ~153 ~278 ~104 ~153 ~278 minecraft:redstone_wire replace
setblock ~106 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~153 ~278 ~121 ~153 ~278 minecraft:redstone_wire replace
setblock ~123 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~153 ~278 ~138 ~153 ~278 minecraft:redstone_wire replace
setblock ~140 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~153 ~278 ~155 ~153 ~278 minecraft:redstone_wire replace
setblock ~157 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~278 ~172 ~153 ~278 minecraft:redstone_wire replace
setblock ~174 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~153 ~278 ~189 ~153 ~278 minecraft:redstone_wire replace
setblock ~191 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~153 ~278 ~198 ~153 ~278 minecraft:redstone_wire replace
setblock ~100 ~153 ~281 minecraft:redstone_wire replace
fill ~99 ~153 ~282 ~103 ~153 ~282 minecraft:redstone_wire replace
setblock ~105 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~153 ~282 ~119 ~153 ~282 minecraft:redstone_wire replace
setblock ~121 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~282 ~135 ~153 ~282 minecraft:redstone_wire replace
setblock ~137 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~153 ~282 ~151 ~153 ~282 minecraft:redstone_wire replace
setblock ~153 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~153 ~282 ~167 ~153 ~282 minecraft:redstone_wire replace
setblock ~169 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~282 ~183 ~153 ~282 minecraft:redstone_wire replace
setblock ~185 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~153 ~282 ~195 ~153 ~282 minecraft:redstone_wire replace
setblock ~100 ~153 ~285 minecraft:redstone_wire replace
fill ~99 ~153 ~286 ~109 ~153 ~286 minecraft:redstone_wire replace
setblock ~111 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~153 ~286 ~126 ~153 ~286 minecraft:redstone_wire replace
setblock ~128 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~153 ~286 ~143 ~153 ~286 minecraft:redstone_wire replace
setblock ~145 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~286 ~160 ~153 ~286 minecraft:redstone_wire replace
setblock ~162 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~153 ~286 ~177 ~153 ~286 minecraft:redstone_wire replace
setblock ~179 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~153 ~286 ~192 ~153 ~286 minecraft:redstone_wire replace
setblock ~97 ~153 ~289 minecraft:redstone_wire replace
fill ~96 ~153 ~290 ~105 ~153 ~290 minecraft:redstone_wire replace
setblock ~107 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~153 ~290 ~122 ~153 ~290 minecraft:redstone_wire replace
setblock ~124 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~153 ~290 ~139 ~153 ~290 minecraft:redstone_wire replace
setblock ~141 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~153 ~290 ~156 ~153 ~290 minecraft:redstone_wire replace
setblock ~158 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~153 ~290 ~173 ~153 ~290 minecraft:redstone_wire replace
setblock ~175 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~153 ~290 ~189 ~153 ~290 minecraft:redstone_wire replace
setblock ~97 ~153 ~293 minecraft:redstone_wire replace
fill ~96 ~153 ~294 ~109 ~153 ~294 minecraft:redstone_wire replace
setblock ~111 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~153 ~294 ~126 ~153 ~294 minecraft:redstone_wire replace
setblock ~128 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~153 ~294 ~143 ~153 ~294 minecraft:redstone_wire replace
setblock ~145 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~294 ~160 ~153 ~294 minecraft:redstone_wire replace
setblock ~162 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~153 ~294 ~177 ~153 ~294 minecraft:redstone_wire replace
setblock ~179 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~153 ~294 ~186 ~153 ~294 minecraft:redstone_wire replace
setblock ~97 ~153 ~297 minecraft:redstone_wire replace
fill ~96 ~153 ~298 ~102 ~153 ~298 minecraft:redstone_wire replace
setblock ~104 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~153 ~298 ~119 ~153 ~298 minecraft:redstone_wire replace
setblock ~121 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~298 ~136 ~153 ~298 minecraft:redstone_wire replace
setblock ~138 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~153 ~298 ~153 ~153 ~298 minecraft:redstone_wire replace
setblock ~155 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~153 ~298 ~170 ~153 ~298 minecraft:redstone_wire replace
setblock ~172 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~153 ~298 ~183 ~153 ~298 minecraft:redstone_wire replace
setblock ~97 ~153 ~301 minecraft:redstone_wire replace
fill ~96 ~153 ~302 ~97 ~153 ~302 minecraft:redstone_wire replace
setblock ~99 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~153 ~302 ~114 ~153 ~302 minecraft:redstone_wire replace
setblock ~116 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~153 ~302 ~131 ~153 ~302 minecraft:redstone_wire replace
setblock ~133 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~153 ~302 ~148 ~153 ~302 minecraft:redstone_wire replace
setblock ~150 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~153 ~302 ~165 ~153 ~302 minecraft:redstone_wire replace
setblock ~167 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~153 ~302 ~180 ~153 ~302 minecraft:redstone_wire replace
setblock ~94 ~153 ~305 minecraft:redstone_wire replace
fill ~93 ~153 ~306 ~95 ~153 ~306 minecraft:redstone_wire replace
setblock ~96 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~306 ~110 ~153 ~306 minecraft:redstone_wire replace
setblock ~112 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~306 ~127 ~153 ~306 minecraft:redstone_wire replace
setblock ~129 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~153 ~306 ~144 ~153 ~306 minecraft:redstone_wire replace
setblock ~146 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~153 ~306 ~161 ~153 ~306 minecraft:redstone_wire replace
setblock ~163 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~153 ~306 ~177 ~153 ~306 minecraft:redstone_wire replace
setblock ~94 ~153 ~309 minecraft:redstone_wire replace
fill ~93 ~153 ~310 ~97 ~153 ~310 minecraft:redstone_wire replace
setblock ~99 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~153 ~310 ~114 ~153 ~310 minecraft:redstone_wire replace
setblock ~116 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~153 ~310 ~131 ~153 ~310 minecraft:redstone_wire replace
setblock ~133 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~153 ~310 ~148 ~153 ~310 minecraft:redstone_wire replace
setblock ~150 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~153 ~310 ~165 ~153 ~310 minecraft:redstone_wire replace
setblock ~167 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~153 ~310 ~174 ~153 ~310 minecraft:redstone_wire replace
setblock ~94 ~153 ~313 minecraft:redstone_wire replace
setblock ~93 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~153 ~314 ~107 ~153 ~314 minecraft:redstone_wire replace
setblock ~109 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~314 ~124 ~153 ~314 minecraft:redstone_wire replace
setblock ~126 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~314 ~141 ~153 ~314 minecraft:redstone_wire replace
setblock ~143 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~314 ~158 ~153 ~314 minecraft:redstone_wire replace
setblock ~160 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~153 ~314 ~171 ~153 ~314 minecraft:redstone_wire replace
setblock ~94 ~153 ~317 minecraft:redstone_wire replace
fill ~93 ~153 ~318 ~102 ~153 ~318 minecraft:redstone_wire replace
setblock ~104 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~153 ~318 ~119 ~153 ~318 minecraft:redstone_wire replace
setblock ~121 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~318 ~136 ~153 ~318 minecraft:redstone_wire replace
setblock ~138 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~153 ~318 ~153 ~153 ~318 minecraft:redstone_wire replace
setblock ~155 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~153 ~318 ~168 ~153 ~318 minecraft:redstone_wire replace
setblock ~94 ~153 ~321 minecraft:redstone_wire replace
fill ~93 ~153 ~322 ~98 ~153 ~322 minecraft:redstone_wire replace
setblock ~100 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~153 ~322 ~115 ~153 ~322 minecraft:redstone_wire replace
setblock ~117 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~153 ~322 ~132 ~153 ~322 minecraft:redstone_wire replace
setblock ~134 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~153 ~322 ~149 ~153 ~322 minecraft:redstone_wire replace
setblock ~151 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~153 ~322 ~165 ~153 ~322 minecraft:redstone_wire replace
setblock ~94 ~153 ~325 minecraft:redstone_wire replace
fill ~93 ~153 ~326 ~102 ~153 ~326 minecraft:redstone_wire replace
setblock ~104 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~153 ~326 ~119 ~153 ~326 minecraft:redstone_wire replace
setblock ~121 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~326 ~136 ~153 ~326 minecraft:redstone_wire replace
setblock ~138 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~153 ~326 ~153 ~153 ~326 minecraft:redstone_wire replace
setblock ~155 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~153 ~326 ~162 ~153 ~326 minecraft:redstone_wire replace
setblock ~94 ~153 ~329 minecraft:redstone_wire replace
fill ~93 ~153 ~330 ~95 ~153 ~330 minecraft:redstone_wire replace
setblock ~97 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~153 ~330 ~112 ~153 ~330 minecraft:redstone_wire replace
setblock ~114 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~330 ~129 ~153 ~330 minecraft:redstone_wire replace
setblock ~131 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~330 ~146 ~153 ~330 minecraft:redstone_wire replace
setblock ~148 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~153 ~330 ~159 ~153 ~330 minecraft:redstone_wire replace
setblock ~91 ~153 ~333 minecraft:redstone_wire replace
fill ~90 ~153 ~334 ~92 ~153 ~334 minecraft:redstone_wire replace
setblock ~93 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~153 ~334 ~107 ~153 ~334 minecraft:redstone_wire replace
setblock ~109 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~334 ~124 ~153 ~334 minecraft:redstone_wire replace
setblock ~126 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~334 ~141 ~153 ~334 minecraft:redstone_wire replace
setblock ~143 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~334 ~156 ~153 ~334 minecraft:redstone_wire replace
setblock ~91 ~153 ~337 minecraft:redstone_wire replace
fill ~90 ~153 ~338 ~103 ~153 ~338 minecraft:redstone_wire replace
setblock ~105 ~153 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~153 ~338 ~120 ~153 ~338 minecraft:redstone_wire replace
setblock ~122 ~153 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~153 ~338 ~137 ~153 ~338 minecraft:redstone_wire replace
setblock ~139 ~153 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~153 ~338 ~153 ~153 ~338 minecraft:redstone_wire replace
setblock ~91 ~153 ~341 minecraft:redstone_wire replace
fill ~90 ~153 ~342 ~92 ~153 ~342 minecraft:redstone_wire replace
setblock ~93 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~153 ~342 ~107 ~153 ~342 minecraft:redstone_wire replace
setblock ~109 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~342 ~124 ~153 ~342 minecraft:redstone_wire replace
setblock ~126 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~342 ~141 ~153 ~342 minecraft:redstone_wire replace
setblock ~143 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~342 ~150 ~153 ~342 minecraft:redstone_wire replace
setblock ~91 ~153 ~345 minecraft:redstone_wire replace
fill ~90 ~153 ~346 ~100 ~153 ~346 minecraft:redstone_wire replace
setblock ~102 ~153 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~346 ~117 ~153 ~346 minecraft:redstone_wire replace
setblock ~119 ~153 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~346 ~134 ~153 ~346 minecraft:redstone_wire replace
setblock ~136 ~153 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~153 ~346 ~147 ~153 ~346 minecraft:redstone_wire replace
setblock ~91 ~153 ~349 minecraft:redstone_wire replace
fill ~90 ~153 ~350 ~95 ~153 ~350 minecraft:redstone_wire replace
setblock ~97 ~153 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~153 ~350 ~112 ~153 ~350 minecraft:redstone_wire replace
setblock ~114 ~153 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~350 ~129 ~153 ~350 minecraft:redstone_wire replace
setblock ~131 ~153 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~350 ~144 ~153 ~350 minecraft:redstone_wire replace
setblock ~91 ~153 ~353 minecraft:redstone_wire replace
fill ~90 ~153 ~354 ~91 ~153 ~354 minecraft:redstone_wire replace
setblock ~93 ~153 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~153 ~354 ~108 ~153 ~354 minecraft:redstone_wire replace
setblock ~110 ~153 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~153 ~354 ~125 ~153 ~354 minecraft:redstone_wire replace
setblock ~127 ~153 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~153 ~354 ~141 ~153 ~354 minecraft:redstone_wire replace
setblock ~91 ~153 ~357 minecraft:redstone_wire replace
fill ~90 ~153 ~358 ~95 ~153 ~358 minecraft:redstone_wire replace
setblock ~97 ~153 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~153 ~358 ~112 ~153 ~358 minecraft:redstone_wire replace
setblock ~114 ~153 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~358 ~129 ~153 ~358 minecraft:redstone_wire replace
setblock ~131 ~153 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~358 ~138 ~153 ~358 minecraft:redstone_wire replace
setblock ~91 ~153 ~361 minecraft:redstone_wire replace
fill ~90 ~153 ~362 ~91 ~153 ~362 minecraft:redstone_wire replace
setblock ~93 ~153 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~153 ~362 ~107 ~153 ~362 minecraft:redstone_wire replace
setblock ~109 ~153 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~362 ~123 ~153 ~362 minecraft:redstone_wire replace
setblock ~125 ~153 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~153 ~362 ~135 ~153 ~362 minecraft:redstone_wire replace
setblock ~91 ~153 ~365 minecraft:redstone_wire replace
fill ~90 ~153 ~366 ~100 ~153 ~366 minecraft:redstone_wire replace
setblock ~102 ~153 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~366 ~117 ~153 ~366 minecraft:redstone_wire replace
setblock ~119 ~153 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~366 ~132 ~153 ~366 minecraft:redstone_wire replace
setblock ~88 ~153 ~369 minecraft:redstone_wire replace
fill ~87 ~153 ~370 ~96 ~153 ~370 minecraft:redstone_wire replace
setblock ~98 ~153 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~153 ~370 ~113 ~153 ~370 minecraft:redstone_wire replace
setblock ~115 ~153 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~153 ~370 ~129 ~153 ~370 minecraft:redstone_wire replace
setblock ~88 ~153 ~373 minecraft:redstone_wire replace
fill ~87 ~153 ~374 ~100 ~153 ~374 minecraft:redstone_wire replace
setblock ~102 ~153 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~374 ~117 ~153 ~374 minecraft:redstone_wire replace
setblock ~119 ~153 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~374 ~126 ~153 ~374 minecraft:redstone_wire replace
setblock ~88 ~153 ~377 minecraft:redstone_wire replace
fill ~87 ~153 ~378 ~93 ~153 ~378 minecraft:redstone_wire replace
setblock ~95 ~153 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~378 ~110 ~153 ~378 minecraft:redstone_wire replace
setblock ~112 ~153 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~378 ~123 ~153 ~378 minecraft:redstone_wire replace
setblock ~88 ~153 ~381 minecraft:redstone_wire replace
fill ~87 ~153 ~382 ~88 ~153 ~382 minecraft:redstone_wire replace
setblock ~90 ~153 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~153 ~382 ~105 ~153 ~382 minecraft:redstone_wire replace
setblock ~107 ~153 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~153 ~382 ~120 ~153 ~382 minecraft:redstone_wire replace
setblock ~88 ~153 ~385 minecraft:redstone_wire replace
setblock ~87 ~153 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~153 ~386 ~101 ~153 ~386 minecraft:redstone_wire replace
setblock ~103 ~153 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~153 ~386 ~117 ~153 ~386 minecraft:redstone_wire replace
setblock ~88 ~153 ~389 minecraft:redstone_wire replace
fill ~87 ~153 ~390 ~88 ~153 ~390 minecraft:redstone_wire replace
setblock ~90 ~153 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~153 ~390 ~105 ~153 ~390 minecraft:redstone_wire replace
setblock ~107 ~153 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~153 ~390 ~114 ~153 ~390 minecraft:redstone_wire replace
setblock ~88 ~153 ~393 minecraft:redstone_wire replace
fill ~87 ~153 ~394 ~98 ~153 ~394 minecraft:redstone_wire replace
setblock ~100 ~153 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~153 ~394 ~111 ~153 ~394 minecraft:redstone_wire replace
setblock ~88 ~153 ~397 minecraft:redstone_wire replace
fill ~87 ~153 ~398 ~93 ~153 ~398 minecraft:redstone_wire replace
setblock ~95 ~153 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~398 ~108 ~153 ~398 minecraft:redstone_wire replace
setblock ~85 ~153 ~401 minecraft:redstone_wire replace
fill ~84 ~153 ~402 ~89 ~153 ~402 minecraft:redstone_wire replace
setblock ~91 ~153 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~153 ~402 ~105 ~153 ~402 minecraft:redstone_wire replace
setblock ~85 ~153 ~405 minecraft:redstone_wire replace
fill ~84 ~153 ~406 ~93 ~153 ~406 minecraft:redstone_wire replace
setblock ~95 ~153 ~406 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~406 ~102 ~153 ~406 minecraft:redstone_wire replace
setblock ~85 ~153 ~409 minecraft:redstone_wire replace
fill ~84 ~153 ~410 ~86 ~153 ~410 minecraft:redstone_wire replace
setblock ~88 ~153 ~410 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~153 ~410 ~99 ~153 ~410 minecraft:redstone_wire replace
setblock ~85 ~153 ~413 minecraft:redstone_wire replace
setblock ~84 ~153 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~153 ~414 ~96 ~153 ~414 minecraft:redstone_wire replace
setblock ~85 ~153 ~417 minecraft:redstone_wire replace
fill ~84 ~153 ~418 ~93 ~153 ~418 minecraft:redstone_wire replace
setblock ~85 ~153 ~421 minecraft:redstone_wire replace
setblock ~84 ~153 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~153 ~422 ~90 ~153 ~422 minecraft:redstone_wire replace
setblock ~85 ~153 ~425 minecraft:redstone_wire replace
fill ~84 ~153 ~426 ~87 ~153 ~426 minecraft:redstone_wire replace
setblock ~85 ~153 ~429 minecraft:redstone_wire replace
fill ~84 ~153 ~430 ~86 ~153 ~430 minecraft:redstone_wire replace
setblock ~79 ~153 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~153 ~446 ~80 ~153 ~446 minecraft:redstone_wire replace
setblock ~109 ~153 ~473 minecraft:redstone_wire replace
setblock ~112 ~153 ~473 minecraft:redstone_wire replace
setblock ~115 ~153 ~473 minecraft:redstone_wire replace
setblock ~118 ~153 ~473 minecraft:redstone_wire replace
setblock ~121 ~153 ~473 minecraft:redstone_wire replace
setblock ~124 ~153 ~473 minecraft:redstone_wire replace
setblock ~127 ~153 ~473 minecraft:redstone_wire replace
setblock ~130 ~153 ~473 minecraft:redstone_wire replace
setblock ~133 ~153 ~473 minecraft:redstone_wire replace
setblock ~136 ~153 ~473 minecraft:redstone_wire replace
setblock ~139 ~153 ~473 minecraft:redstone_wire replace
setblock ~142 ~153 ~473 minecraft:redstone_wire replace
setblock ~145 ~153 ~473 minecraft:redstone_wire replace
setblock ~148 ~153 ~473 minecraft:redstone_wire replace
setblock ~151 ~153 ~473 minecraft:redstone_wire replace
setblock ~154 ~153 ~473 minecraft:redstone_wire replace
setblock ~157 ~153 ~473 minecraft:redstone_wire replace
setblock ~160 ~153 ~473 minecraft:redstone_wire replace
setblock ~163 ~153 ~473 minecraft:redstone_wire replace
setblock ~166 ~153 ~473 minecraft:redstone_wire replace
setblock ~169 ~153 ~473 minecraft:redstone_wire replace
setblock ~172 ~153 ~473 minecraft:redstone_wire replace
setblock ~175 ~153 ~473 minecraft:redstone_wire replace
setblock ~178 ~153 ~473 minecraft:redstone_wire replace
setblock ~181 ~153 ~473 minecraft:redstone_wire replace
setblock ~184 ~153 ~473 minecraft:redstone_wire replace
setblock ~187 ~153 ~473 minecraft:redstone_wire replace
setblock ~190 ~153 ~473 minecraft:redstone_wire replace
setblock ~193 ~153 ~473 minecraft:redstone_wire replace
setblock ~196 ~153 ~473 minecraft:redstone_wire replace
setblock ~199 ~153 ~473 minecraft:redstone_wire replace
setblock ~202 ~153 ~473 minecraft:redstone_wire replace
setblock ~205 ~153 ~473 minecraft:redstone_wire replace
setblock ~208 ~153 ~473 minecraft:redstone_wire replace
setblock ~211 ~153 ~473 minecraft:redstone_wire replace
setblock ~214 ~153 ~473 minecraft:redstone_wire replace
setblock ~217 ~153 ~473 minecraft:redstone_wire replace
setblock ~220 ~153 ~473 minecraft:redstone_wire replace
setblock ~223 ~153 ~473 minecraft:redstone_wire replace
setblock ~226 ~153 ~473 minecraft:redstone_wire replace
setblock ~229 ~153 ~473 minecraft:redstone_wire replace
setblock ~232 ~153 ~473 minecraft:redstone_wire replace
setblock ~235 ~153 ~473 minecraft:redstone_wire replace
setblock ~238 ~153 ~473 minecraft:redstone_wire replace
setblock ~241 ~153 ~473 minecraft:redstone_wire replace
setblock ~244 ~153 ~473 minecraft:redstone_wire replace
setblock ~247 ~153 ~473 minecraft:redstone_wire replace
setblock ~250 ~153 ~473 minecraft:redstone_wire replace
setblock ~253 ~153 ~473 minecraft:redstone_wire replace
fill ~108 ~153 ~474 ~112 ~153 ~474 minecraft:redstone_wire replace
setblock ~113 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~474 ~127 ~153 ~474 minecraft:redstone_wire replace
setblock ~128 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~153 ~474 ~142 ~153 ~474 minecraft:redstone_wire replace
setblock ~143 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~153 ~474 ~157 ~153 ~474 minecraft:redstone_wire replace
setblock ~158 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~474 ~172 ~153 ~474 minecraft:redstone_wire replace
setblock ~173 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~153 ~474 ~187 ~153 ~474 minecraft:redstone_wire replace
setblock ~188 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~153 ~474 ~202 ~153 ~474 minecraft:redstone_wire replace
setblock ~203 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~153 ~474 ~217 ~153 ~474 minecraft:redstone_wire replace
setblock ~218 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~153 ~474 ~232 ~153 ~474 minecraft:redstone_wire replace
setblock ~233 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~153 ~474 ~254 ~153 ~474 minecraft:redstone_wire replace
setblock ~109 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~153 ~477 minecraft:redstone_wire replace
setblock ~118 ~153 ~477 minecraft:redstone_wire replace
setblock ~121 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~124 ~153 ~477 minecraft:redstone_wire replace
setblock ~127 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~153 ~477 minecraft:redstone_wire replace
setblock ~133 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~477 minecraft:redstone_wire replace
setblock ~139 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~153 ~477 minecraft:redstone_wire replace
setblock ~145 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~153 ~477 minecraft:redstone_wire replace
setblock ~151 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~154 ~153 ~477 minecraft:redstone_wire replace
setblock ~157 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~477 minecraft:redstone_wire replace
setblock ~163 ~153 ~477 minecraft:redstone_wire replace
setblock ~166 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~153 ~477 minecraft:redstone_wire replace
setblock ~172 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~175 ~153 ~477 minecraft:redstone_wire replace
setblock ~178 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~153 ~477 minecraft:redstone_wire replace
setblock ~184 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~153 ~477 minecraft:redstone_wire replace
setblock ~193 ~153 ~477 minecraft:redstone_wire replace
setblock ~196 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~199 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~153 ~477 minecraft:redstone_wire replace
setblock ~205 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~214 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~153 ~477 minecraft:redstone_wire replace
setblock ~226 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~229 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~232 ~153 ~477 minecraft:redstone_wire replace
setblock ~235 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~153 ~477 minecraft:redstone_wire replace
setblock ~241 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~153 ~477 minecraft:redstone_wire replace
setblock ~247 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~250 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~153 ~477 minecraft:redstone_wire replace
fill ~108 ~153 ~478 ~121 ~153 ~478 minecraft:redstone_wire replace
setblock ~122 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~478 ~136 ~153 ~478 minecraft:redstone_wire replace
setblock ~137 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~153 ~478 ~151 ~153 ~478 minecraft:redstone_wire replace
setblock ~152 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~153 ~478 ~166 ~153 ~478 minecraft:redstone_wire replace
setblock ~167 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~153 ~478 ~181 ~153 ~478 minecraft:redstone_wire replace
setblock ~182 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~153 ~478 ~196 ~153 ~478 minecraft:redstone_wire replace
setblock ~197 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~153 ~478 ~211 ~153 ~478 minecraft:redstone_wire replace
setblock ~212 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~153 ~478 ~226 ~153 ~478 minecraft:redstone_wire replace
setblock ~227 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~153 ~478 ~239 ~153 ~478 minecraft:redstone_wire replace
setblock ~240 ~153 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~153 ~478 ~253 ~153 ~478 minecraft:redstone_wire replace
setblock ~254 ~153 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~109 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~118 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~121 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~124 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~127 ~153 ~497 minecraft:redstone_wire replace
setblock ~130 ~153 ~497 minecraft:redstone_wire replace
setblock ~133 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~145 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~151 ~153 ~497 minecraft:redstone_wire replace
setblock ~154 ~153 ~497 minecraft:redstone_wire replace
setblock ~157 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~163 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~166 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~172 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~175 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~178 ~153 ~497 minecraft:redstone_wire replace
setblock ~181 ~153 ~497 minecraft:redstone_wire replace
setblock ~184 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~193 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~196 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~199 ~153 ~497 minecraft:redstone_wire replace
setblock ~202 ~153 ~497 minecraft:redstone_wire replace
setblock ~205 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~214 ~153 ~497 minecraft:redstone_wire replace
setblock ~217 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~226 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~229 ~153 ~497 minecraft:redstone_wire replace
setblock ~232 ~153 ~497 minecraft:redstone_wire replace
setblock ~235 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~241 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~247 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~250 ~153 ~497 minecraft:redstone_wire replace
setblock ~253 ~153 ~497 minecraft:redstone_wire replace
fill ~108 ~153 ~498 ~112 ~153 ~498 minecraft:redstone_wire replace
setblock ~113 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~498 ~127 ~153 ~498 minecraft:redstone_wire replace
setblock ~128 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~153 ~498 ~142 ~153 ~498 minecraft:redstone_wire replace
setblock ~143 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~153 ~498 ~157 ~153 ~498 minecraft:redstone_wire replace
setblock ~158 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~498 ~172 ~153 ~498 minecraft:redstone_wire replace
setblock ~173 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~153 ~498 ~187 ~153 ~498 minecraft:redstone_wire replace
setblock ~188 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~153 ~498 ~202 ~153 ~498 minecraft:redstone_wire replace
setblock ~203 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~153 ~498 ~217 ~153 ~498 minecraft:redstone_wire replace
setblock ~218 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~153 ~498 ~232 ~153 ~498 minecraft:redstone_wire replace
setblock ~233 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~153 ~498 ~245 ~153 ~498 minecraft:redstone_wire replace
setblock ~246 ~153 ~498 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~153 ~498 ~254 ~153 ~498 minecraft:redstone_wire replace
setblock ~109 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~509 minecraft:redstone_wire replace
setblock ~115 ~153 ~509 minecraft:redstone_wire replace
setblock ~118 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~121 ~153 ~509 minecraft:redstone_wire replace
setblock ~124 ~153 ~509 minecraft:redstone_wire replace
setblock ~127 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~133 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~153 ~509 minecraft:redstone_wire replace
setblock ~142 ~153 ~509 minecraft:redstone_wire replace
setblock ~145 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~153 ~509 minecraft:redstone_wire replace
setblock ~151 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~154 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~157 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~163 ~153 ~509 minecraft:redstone_wire replace
setblock ~166 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~172 ~153 ~509 minecraft:redstone_wire replace
setblock ~175 ~153 ~509 minecraft:redstone_wire replace
setblock ~178 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~184 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~509 minecraft:redstone_wire replace
setblock ~190 ~153 ~509 minecraft:redstone_wire replace
setblock ~193 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~196 ~153 ~509 minecraft:redstone_wire replace
setblock ~199 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~205 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~509 minecraft:redstone_wire replace
setblock ~211 ~153 ~509 minecraft:redstone_wire replace
setblock ~214 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~226 ~153 ~509 minecraft:redstone_wire replace
setblock ~229 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~232 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~235 ~153 ~509 minecraft:redstone_wire replace
setblock ~238 ~153 ~509 minecraft:redstone_wire replace
setblock ~241 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~247 ~153 ~509 minecraft:redstone_wire replace
setblock ~250 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~153 ~510 ~109 ~153 ~510 minecraft:redstone_wire replace
setblock ~110 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~510 ~124 ~153 ~510 minecraft:redstone_wire replace
setblock ~125 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~153 ~510 ~139 ~153 ~510 minecraft:redstone_wire replace
setblock ~140 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~153 ~510 ~154 ~153 ~510 minecraft:redstone_wire replace
setblock ~155 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~153 ~510 ~169 ~153 ~510 minecraft:redstone_wire replace
setblock ~170 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~510 ~184 ~153 ~510 minecraft:redstone_wire replace
setblock ~185 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~153 ~510 ~199 ~153 ~510 minecraft:redstone_wire replace
setblock ~200 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~153 ~510 ~214 ~153 ~510 minecraft:redstone_wire replace
setblock ~215 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~153 ~510 ~229 ~153 ~510 minecraft:redstone_wire replace
setblock ~230 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~153 ~510 ~242 ~153 ~510 minecraft:redstone_wire replace
setblock ~243 ~153 ~510 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~153 ~510 ~254 ~153 ~510 minecraft:redstone_wire replace
setblock ~109 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~118 ~153 ~533 minecraft:redstone_wire replace
setblock ~121 ~153 ~533 minecraft:redstone_wire replace
setblock ~124 ~153 ~533 minecraft:redstone_wire replace
setblock ~127 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~133 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~145 ~153 ~533 minecraft:redstone_wire replace
setblock ~148 ~153 ~533 minecraft:redstone_wire replace
setblock ~151 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~154 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~157 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~163 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~166 ~153 ~533 minecraft:redstone_wire replace
setblock ~169 ~153 ~533 minecraft:redstone_wire replace
setblock ~172 ~153 ~533 minecraft:redstone_wire replace
setblock ~175 ~153 ~533 minecraft:redstone_wire replace
setblock ~178 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~184 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~193 ~153 ~533 minecraft:redstone_wire replace
setblock ~196 ~153 ~533 minecraft:redstone_wire replace
setblock ~199 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~205 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~153 ~533 minecraft:redstone_wire replace
setblock ~214 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~533 minecraft:redstone_wire replace
setblock ~223 ~153 ~533 minecraft:redstone_wire replace
setblock ~226 ~153 ~533 minecraft:redstone_wire replace
setblock ~229 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~232 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~235 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~241 ~153 ~533 minecraft:redstone_wire replace
setblock ~244 ~153 ~533 minecraft:redstone_wire replace
setblock ~247 ~153 ~533 minecraft:redstone_wire replace
setblock ~250 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~153 ~534 ~115 ~153 ~534 minecraft:redstone_wire replace
setblock ~116 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~153 ~534 ~130 ~153 ~534 minecraft:redstone_wire replace
setblock ~131 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~153 ~534 ~145 ~153 ~534 minecraft:redstone_wire replace
setblock ~146 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~534 ~160 ~153 ~534 minecraft:redstone_wire replace
setblock ~161 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~153 ~534 ~175 ~153 ~534 minecraft:redstone_wire replace
setblock ~176 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~153 ~534 ~190 ~153 ~534 minecraft:redstone_wire replace
setblock ~191 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~153 ~534 ~205 ~153 ~534 minecraft:redstone_wire replace
setblock ~206 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~153 ~534 ~220 ~153 ~534 minecraft:redstone_wire replace
setblock ~221 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~153 ~534 ~235 ~153 ~534 minecraft:redstone_wire replace
setblock ~236 ~153 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~153 ~534 ~248 ~153 ~534 minecraft:redstone_wire replace
setblock ~249 ~153 ~534 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~250 ~153 ~534 ~254 ~153 ~534 minecraft:redstone_wire replace
setblock ~256 ~153 ~537 minecraft:redstone_wire replace
setblock ~259 ~153 ~537 minecraft:redstone_wire replace
setblock ~262 ~153 ~537 minecraft:redstone_wire replace
setblock ~265 ~153 ~537 minecraft:redstone_wire replace
setblock ~268 ~153 ~537 minecraft:redstone_wire replace
setblock ~271 ~153 ~537 minecraft:redstone_wire replace
setblock ~274 ~153 ~537 minecraft:redstone_wire replace
setblock ~277 ~153 ~537 minecraft:redstone_wire replace
setblock ~280 ~153 ~537 minecraft:redstone_wire replace
setblock ~283 ~153 ~537 minecraft:redstone_wire replace
setblock ~286 ~153 ~537 minecraft:redstone_wire replace
setblock ~289 ~153 ~537 minecraft:redstone_wire replace
setblock ~292 ~153 ~537 minecraft:redstone_wire replace
setblock ~295 ~153 ~537 minecraft:redstone_wire replace
setblock ~298 ~153 ~537 minecraft:redstone_wire replace
setblock ~301 ~153 ~537 minecraft:redstone_wire replace
setblock ~304 ~153 ~537 minecraft:redstone_wire replace
setblock ~307 ~153 ~537 minecraft:redstone_wire replace
setblock ~310 ~153 ~537 minecraft:redstone_wire replace
setblock ~313 ~153 ~537 minecraft:redstone_wire replace
setblock ~316 ~153 ~537 minecraft:redstone_wire replace
setblock ~319 ~153 ~537 minecraft:redstone_wire replace
setblock ~322 ~153 ~537 minecraft:redstone_wire replace
setblock ~325 ~153 ~537 minecraft:redstone_wire replace
setblock ~328 ~153 ~537 minecraft:redstone_wire replace
setblock ~331 ~153 ~537 minecraft:redstone_wire replace
setblock ~334 ~153 ~537 minecraft:redstone_wire replace
setblock ~337 ~153 ~537 minecraft:redstone_wire replace
setblock ~340 ~153 ~537 minecraft:redstone_wire replace
setblock ~343 ~153 ~537 minecraft:redstone_wire replace
setblock ~346 ~153 ~537 minecraft:redstone_wire replace
setblock ~349 ~153 ~537 minecraft:redstone_wire replace
setblock ~352 ~153 ~537 minecraft:redstone_wire replace
setblock ~355 ~153 ~537 minecraft:redstone_wire replace
setblock ~358 ~153 ~537 minecraft:redstone_wire replace
setblock ~361 ~153 ~537 minecraft:redstone_wire replace
setblock ~364 ~153 ~537 minecraft:redstone_wire replace
setblock ~367 ~153 ~537 minecraft:redstone_wire replace
setblock ~370 ~153 ~537 minecraft:redstone_wire replace
setblock ~373 ~153 ~537 minecraft:redstone_wire replace
setblock ~376 ~153 ~537 minecraft:redstone_wire replace
setblock ~379 ~153 ~537 minecraft:redstone_wire replace
setblock ~382 ~153 ~537 minecraft:redstone_wire replace
setblock ~385 ~153 ~537 minecraft:redstone_wire replace
setblock ~388 ~153 ~537 minecraft:redstone_wire replace
setblock ~391 ~153 ~537 minecraft:redstone_wire replace
setblock ~394 ~153 ~537 minecraft:redstone_wire replace
setblock ~397 ~153 ~537 minecraft:redstone_wire replace
setblock ~400 ~153 ~537 minecraft:redstone_wire replace
fill ~255 ~153 ~538 ~266 ~153 ~538 minecraft:redstone_wire replace
setblock ~267 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~153 ~538 ~280 ~153 ~538 minecraft:redstone_wire replace
setblock ~281 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~153 ~538 ~295 ~153 ~538 minecraft:redstone_wire replace
setblock ~296 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~153 ~538 ~310 ~153 ~538 minecraft:redstone_wire replace
setblock ~311 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~153 ~538 ~325 ~153 ~538 minecraft:redstone_wire replace
setblock ~326 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~153 ~538 ~340 ~153 ~538 minecraft:redstone_wire replace
setblock ~341 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~153 ~538 ~355 ~153 ~538 minecraft:redstone_wire replace
setblock ~356 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~357 ~153 ~538 ~370 ~153 ~538 minecraft:redstone_wire replace
setblock ~371 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~372 ~153 ~538 ~385 ~153 ~538 minecraft:redstone_wire replace
setblock ~386 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~387 ~153 ~538 ~400 ~153 ~538 minecraft:redstone_wire replace
setblock ~401 ~153 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~256 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~153 ~541 minecraft:redstone_wire replace
setblock ~265 ~153 ~541 minecraft:redstone_wire replace
setblock ~268 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~271 ~153 ~541 minecraft:redstone_wire replace
setblock ~274 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~153 ~541 minecraft:redstone_wire replace
setblock ~280 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~541 minecraft:redstone_wire replace
setblock ~286 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~289 ~153 ~541 minecraft:redstone_wire replace
setblock ~292 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~153 ~541 minecraft:redstone_wire replace
setblock ~298 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~153 ~541 minecraft:redstone_wire replace
setblock ~304 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~541 minecraft:redstone_wire replace
setblock ~310 ~153 ~541 minecraft:redstone_wire replace
setblock ~313 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~153 ~541 minecraft:redstone_wire replace
setblock ~319 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~153 ~541 minecraft:redstone_wire replace
setblock ~325 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~328 ~153 ~541 minecraft:redstone_wire replace
setblock ~331 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~153 ~541 minecraft:redstone_wire replace
setblock ~340 ~153 ~541 minecraft:redstone_wire replace
setblock ~343 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~346 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~153 ~541 minecraft:redstone_wire replace
setblock ~352 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~358 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~361 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~364 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~370 ~153 ~541 minecraft:redstone_wire replace
setblock ~373 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~376 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~153 ~541 minecraft:redstone_wire replace
setblock ~382 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~385 ~153 ~541 minecraft:redstone_wire replace
setblock ~388 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~391 ~153 ~541 minecraft:redstone_wire replace
setblock ~394 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~397 ~153 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~400 ~153 ~541 minecraft:redstone_wire replace
fill ~249 ~153 ~542 ~254 ~153 ~542 minecraft:redstone_wire replace
setblock ~255 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~256 ~153 ~542 ~268 ~153 ~542 minecraft:redstone_wire replace
setblock ~269 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~153 ~542 ~283 ~153 ~542 minecraft:redstone_wire replace
setblock ~284 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~153 ~542 ~298 ~153 ~542 minecraft:redstone_wire replace
setblock ~299 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~153 ~542 ~313 ~153 ~542 minecraft:redstone_wire replace
setblock ~314 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~315 ~153 ~542 ~328 ~153 ~542 minecraft:redstone_wire replace
setblock ~329 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~153 ~542 ~343 ~153 ~542 minecraft:redstone_wire replace
setblock ~344 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~345 ~153 ~542 ~358 ~153 ~542 minecraft:redstone_wire replace
setblock ~359 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~360 ~153 ~542 ~373 ~153 ~542 minecraft:redstone_wire replace
setblock ~374 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~375 ~153 ~542 ~388 ~153 ~542 minecraft:redstone_wire replace
setblock ~389 ~153 ~542 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~390 ~153 ~542 ~401 ~153 ~542 minecraft:redstone_wire replace
setblock ~256 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~265 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~268 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~271 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~274 ~153 ~565 minecraft:redstone_wire replace
setblock ~277 ~153 ~565 minecraft:redstone_wire replace
setblock ~280 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~289 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~298 ~153 ~565 minecraft:redstone_wire replace
setblock ~301 ~153 ~565 minecraft:redstone_wire replace
setblock ~304 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~310 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~319 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~325 ~153 ~565 minecraft:redstone_wire replace
setblock ~328 ~153 ~565 minecraft:redstone_wire replace
setblock ~331 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~343 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~346 ~153 ~565 minecraft:redstone_wire replace
setblock ~349 ~153 ~565 minecraft:redstone_wire replace
setblock ~352 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~358 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~361 ~153 ~565 minecraft:redstone_wire replace
setblock ~364 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~370 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~373 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~376 ~153 ~565 minecraft:redstone_wire replace
setblock ~379 ~153 ~565 minecraft:redstone_wire replace
setblock ~382 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~385 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~391 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~394 ~153 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~397 ~153 ~565 minecraft:redstone_wire replace
setblock ~400 ~153 ~565 minecraft:redstone_wire replace
fill ~255 ~153 ~566 ~263 ~153 ~566 minecraft:redstone_wire replace
setblock ~264 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~153 ~566 ~277 ~153 ~566 minecraft:redstone_wire replace
setblock ~278 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~153 ~566 ~292 ~153 ~566 minecraft:redstone_wire replace
setblock ~293 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~294 ~153 ~566 ~307 ~153 ~566 minecraft:redstone_wire replace
setblock ~308 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~153 ~566 ~322 ~153 ~566 minecraft:redstone_wire replace
setblock ~323 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~324 ~153 ~566 ~337 ~153 ~566 minecraft:redstone_wire replace
setblock ~338 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~339 ~153 ~566 ~352 ~153 ~566 minecraft:redstone_wire replace
setblock ~353 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~153 ~566 ~367 ~153 ~566 minecraft:redstone_wire replace
setblock ~368 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~369 ~153 ~566 ~382 ~153 ~566 minecraft:redstone_wire replace
setblock ~383 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~384 ~153 ~566 ~397 ~153 ~566 minecraft:redstone_wire replace
setblock ~398 ~153 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~399 ~153 ~566 ~401 ~153 ~566 minecraft:redstone_wire replace
setblock ~256 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~573 minecraft:redstone_wire replace
setblock ~262 ~153 ~573 minecraft:redstone_wire replace
setblock ~265 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~268 ~153 ~573 minecraft:redstone_wire replace
setblock ~271 ~153 ~573 minecraft:redstone_wire replace
setblock ~274 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~280 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~153 ~573 minecraft:redstone_wire replace
setblock ~289 ~153 ~573 minecraft:redstone_wire replace
setblock ~292 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~295 ~153 ~573 minecraft:redstone_wire replace
setblock ~298 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~310 ~153 ~573 minecraft:redstone_wire replace
setblock ~313 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~316 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~319 ~153 ~573 minecraft:redstone_wire replace
setblock ~322 ~153 ~573 minecraft:redstone_wire replace
setblock ~325 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~328 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~573 minecraft:redstone_wire replace
setblock ~337 ~153 ~573 minecraft:redstone_wire replace
setblock ~340 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~343 ~153 ~573 minecraft:redstone_wire replace
setblock ~346 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~573 minecraft:redstone_wire replace
setblock ~358 ~153 ~573 minecraft:redstone_wire replace
setblock ~361 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~364 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~370 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~373 ~153 ~573 minecraft:redstone_wire replace
setblock ~376 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~382 ~153 ~573 minecraft:redstone_wire replace
setblock ~385 ~153 ~573 minecraft:redstone_wire replace
setblock ~388 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~391 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~394 ~153 ~573 minecraft:redstone_wire replace
setblock ~397 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~400 ~153 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~153 ~574 ~257 ~153 ~574 minecraft:redstone_wire replace
setblock ~258 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~259 ~153 ~574 ~271 ~153 ~574 minecraft:redstone_wire replace
setblock ~272 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~153 ~574 ~286 ~153 ~574 minecraft:redstone_wire replace
setblock ~287 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~288 ~153 ~574 ~301 ~153 ~574 minecraft:redstone_wire replace
setblock ~302 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~153 ~574 ~316 ~153 ~574 minecraft:redstone_wire replace
setblock ~317 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~153 ~574 ~331 ~153 ~574 minecraft:redstone_wire replace
setblock ~332 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~333 ~153 ~574 ~346 ~153 ~574 minecraft:redstone_wire replace
setblock ~347 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~153 ~574 ~361 ~153 ~574 minecraft:redstone_wire replace
setblock ~362 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~363 ~153 ~574 ~376 ~153 ~574 minecraft:redstone_wire replace
setblock ~377 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~378 ~153 ~574 ~391 ~153 ~574 minecraft:redstone_wire replace
setblock ~392 ~153 ~574 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~393 ~153 ~574 ~401 ~153 ~574 minecraft:redstone_wire replace
setblock ~403 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~406 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~409 ~153 ~597 minecraft:redstone_wire replace
setblock ~412 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~415 ~153 ~597 minecraft:redstone_wire replace
setblock ~418 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~421 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~424 ~153 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~153 ~598 ~279 ~153 ~598 minecraft:redstone_wire replace
setblock ~281 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~153 ~598 ~296 ~153 ~598 minecraft:redstone_wire replace
setblock ~298 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~153 ~598 ~313 ~153 ~598 minecraft:redstone_wire replace
setblock ~315 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~153 ~598 ~330 ~153 ~598 minecraft:redstone_wire replace
setblock ~332 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~153 ~598 ~347 ~153 ~598 minecraft:redstone_wire replace
setblock ~349 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~153 ~598 ~364 ~153 ~598 minecraft:redstone_wire replace
setblock ~366 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~368 ~153 ~598 ~381 ~153 ~598 minecraft:redstone_wire replace
setblock ~383 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~385 ~153 ~598 ~398 ~153 ~598 minecraft:redstone_wire replace
setblock ~400 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~402 ~153 ~598 ~415 ~153 ~598 minecraft:redstone_wire replace
setblock ~416 ~153 ~598 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~417 ~153 ~598 ~425 ~153 ~598 minecraft:redstone_wire replace
setblock ~403 ~153 ~601 minecraft:redstone_wire replace
setblock ~406 ~153 ~601 minecraft:redstone_wire replace
setblock ~409 ~153 ~601 minecraft:redstone_wire replace
setblock ~412 ~153 ~601 minecraft:redstone_wire replace
setblock ~415 ~153 ~601 minecraft:redstone_wire replace
setblock ~418 ~153 ~601 minecraft:redstone_wire replace
setblock ~421 ~153 ~601 minecraft:redstone_wire replace
setblock ~424 ~153 ~601 minecraft:redstone_wire replace
fill ~264 ~153 ~602 ~270 ~153 ~602 minecraft:redstone_wire replace
setblock ~272 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~274 ~153 ~602 ~287 ~153 ~602 minecraft:redstone_wire replace
setblock ~289 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~153 ~602 ~304 ~153 ~602 minecraft:redstone_wire replace
setblock ~306 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~308 ~153 ~602 ~321 ~153 ~602 minecraft:redstone_wire replace
setblock ~323 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~325 ~153 ~602 ~338 ~153 ~602 minecraft:redstone_wire replace
setblock ~340 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~153 ~602 ~355 ~153 ~602 minecraft:redstone_wire replace
setblock ~357 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~359 ~153 ~602 ~372 ~153 ~602 minecraft:redstone_wire replace
setblock ~374 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~376 ~153 ~602 ~389 ~153 ~602 minecraft:redstone_wire replace
setblock ~391 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~393 ~153 ~602 ~406 ~153 ~602 minecraft:redstone_wire replace
setblock ~407 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~408 ~153 ~602 ~421 ~153 ~602 minecraft:redstone_wire replace
setblock ~422 ~153 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~423 ~153 ~602 ~425 ~153 ~602 minecraft:redstone_wire replace
setblock ~256 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~262 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~265 ~153 ~605 minecraft:redstone_wire replace
setblock ~268 ~153 ~605 minecraft:redstone_wire replace
setblock ~271 ~153 ~605 minecraft:redstone_wire replace
setblock ~274 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~277 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~280 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~283 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~286 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~289 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~292 ~153 ~605 minecraft:redstone_wire replace
setblock ~295 ~153 ~605 minecraft:redstone_wire replace
setblock ~298 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~307 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~310 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~313 ~153 ~605 minecraft:redstone_wire replace
setblock ~316 ~153 ~605 minecraft:redstone_wire replace
setblock ~319 ~153 ~605 minecraft:redstone_wire replace
setblock ~322 ~153 ~605 minecraft:redstone_wire replace
setblock ~325 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~328 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~334 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~153 ~605 minecraft:redstone_wire replace
setblock ~343 ~153 ~605 minecraft:redstone_wire replace
setblock ~346 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~349 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~355 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~358 ~153 ~605 minecraft:redstone_wire replace
setblock ~361 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~364 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~367 ~153 ~605 minecraft:redstone_wire replace
setblock ~370 ~153 ~605 minecraft:redstone_wire replace
setblock ~373 ~153 ~605 minecraft:redstone_wire replace
setblock ~376 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~382 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~385 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~153 ~605 minecraft:redstone_wire replace
setblock ~391 ~153 ~605 minecraft:redstone_wire replace
setblock ~394 ~153 ~605 minecraft:redstone_wire replace
setblock ~397 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~400 ~153 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~255 ~153 ~606 ~266 ~153 ~606 minecraft:redstone_wire replace
setblock ~267 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~268 ~153 ~606 ~280 ~153 ~606 minecraft:redstone_wire replace
setblock ~281 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~282 ~153 ~606 ~295 ~153 ~606 minecraft:redstone_wire replace
setblock ~296 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~153 ~606 ~310 ~153 ~606 minecraft:redstone_wire replace
setblock ~311 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~153 ~606 ~325 ~153 ~606 minecraft:redstone_wire replace
setblock ~326 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~153 ~606 ~340 ~153 ~606 minecraft:redstone_wire replace
setblock ~341 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~153 ~606 ~355 ~153 ~606 minecraft:redstone_wire replace
setblock ~356 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~357 ~153 ~606 ~370 ~153 ~606 minecraft:redstone_wire replace
setblock ~371 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~372 ~153 ~606 ~385 ~153 ~606 minecraft:redstone_wire replace
setblock ~386 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~387 ~153 ~606 ~400 ~153 ~606 minecraft:redstone_wire replace
setblock ~401 ~153 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~433 ~153 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~153 ~642 ~282 ~153 ~642 minecraft:redstone_wire replace
setblock ~284 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~153 ~642 ~299 ~153 ~642 minecraft:redstone_wire replace
setblock ~301 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~153 ~642 ~316 ~153 ~642 minecraft:redstone_wire replace
setblock ~318 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~320 ~153 ~642 ~333 ~153 ~642 minecraft:redstone_wire replace
setblock ~335 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~153 ~642 ~350 ~153 ~642 minecraft:redstone_wire replace
setblock ~352 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~153 ~642 ~367 ~153 ~642 minecraft:redstone_wire replace
setblock ~369 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~371 ~153 ~642 ~384 ~153 ~642 minecraft:redstone_wire replace
setblock ~386 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~388 ~153 ~642 ~401 ~153 ~642 minecraft:redstone_wire replace
setblock ~403 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~405 ~153 ~642 ~418 ~153 ~642 minecraft:redstone_wire replace
setblock ~420 ~153 ~642 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~422 ~153 ~642 ~434 ~153 ~642 minecraft:redstone_wire replace
setblock ~427 ~153 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~153 ~650 ~276 ~153 ~650 minecraft:redstone_wire replace
setblock ~278 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~153 ~650 ~293 ~153 ~650 minecraft:redstone_wire replace
setblock ~295 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~153 ~650 ~310 ~153 ~650 minecraft:redstone_wire replace
setblock ~312 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~153 ~650 ~327 ~153 ~650 minecraft:redstone_wire replace
setblock ~329 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~153 ~650 ~344 ~153 ~650 minecraft:redstone_wire replace
setblock ~346 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~348 ~153 ~650 ~361 ~153 ~650 minecraft:redstone_wire replace
setblock ~363 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~365 ~153 ~650 ~378 ~153 ~650 minecraft:redstone_wire replace
setblock ~380 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~382 ~153 ~650 ~395 ~153 ~650 minecraft:redstone_wire replace
setblock ~397 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~399 ~153 ~650 ~412 ~153 ~650 minecraft:redstone_wire replace
setblock ~414 ~153 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~416 ~153 ~650 ~428 ~153 ~650 minecraft:redstone_wire replace
setblock ~430 ~153 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~153 ~658 ~279 ~153 ~658 minecraft:redstone_wire replace
setblock ~281 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~283 ~153 ~658 ~296 ~153 ~658 minecraft:redstone_wire replace
setblock ~298 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~300 ~153 ~658 ~313 ~153 ~658 minecraft:redstone_wire replace
setblock ~315 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~317 ~153 ~658 ~330 ~153 ~658 minecraft:redstone_wire replace
setblock ~332 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~153 ~658 ~347 ~153 ~658 minecraft:redstone_wire replace
setblock ~349 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~351 ~153 ~658 ~364 ~153 ~658 minecraft:redstone_wire replace
setblock ~366 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~368 ~153 ~658 ~381 ~153 ~658 minecraft:redstone_wire replace
setblock ~383 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~385 ~153 ~658 ~398 ~153 ~658 minecraft:redstone_wire replace
setblock ~400 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~402 ~153 ~658 ~415 ~153 ~658 minecraft:redstone_wire replace
setblock ~417 ~153 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~419 ~153 ~658 ~431 ~153 ~658 minecraft:redstone_wire replace
setblock ~106 ~154 ~228 minecraft:redstone_wire replace
setblock ~82 ~154 ~232 minecraft:redstone_wire replace
setblock ~103 ~154 ~236 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~240 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~154 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~154 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~154 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~154 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~348 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~154 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~384 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~154 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~400 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~404 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~416 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~420 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~424 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~154 ~428 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~154 ~444 minecraft:redstone_wire replace
setblock ~109 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~154 ~476 minecraft:redstone_wire replace
setblock ~112 ~154 ~476 minecraft:redstone_wire replace
setblock ~115 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~154 ~476 minecraft:redstone_wire replace
setblock ~124 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~476 minecraft:redstone_wire replace
setblock ~130 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~154 ~476 minecraft:redstone_wire replace
setblock ~136 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~154 ~476 minecraft:redstone_wire replace
setblock ~142 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~154 ~476 minecraft:redstone_wire replace
setblock ~148 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~476 minecraft:redstone_wire replace
setblock ~154 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~154 ~476 minecraft:redstone_wire replace
setblock ~160 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~154 ~476 minecraft:redstone_wire replace
setblock ~169 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~154 ~476 minecraft:redstone_wire replace
setblock ~175 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~476 minecraft:redstone_wire replace
setblock ~181 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~154 ~476 minecraft:redstone_wire replace
setblock ~187 ~154 ~476 minecraft:redstone_wire replace
setblock ~190 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~154 ~476 minecraft:redstone_wire replace
setblock ~199 ~154 ~476 minecraft:redstone_wire replace
setblock ~202 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~154 ~476 minecraft:redstone_wire replace
setblock ~208 ~154 ~476 minecraft:redstone_wire replace
setblock ~211 ~154 ~476 minecraft:redstone_wire replace
setblock ~214 ~154 ~476 minecraft:redstone_wire replace
setblock ~217 ~154 ~476 minecraft:redstone_wire replace
setblock ~220 ~154 ~476 minecraft:redstone_wire replace
setblock ~223 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~154 ~476 minecraft:redstone_wire replace
setblock ~229 ~154 ~476 minecraft:redstone_wire replace
setblock ~232 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~154 ~476 minecraft:redstone_wire replace
setblock ~238 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~154 ~476 minecraft:redstone_wire replace
setblock ~244 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~154 ~476 minecraft:redstone_wire replace
setblock ~250 ~154 ~476 minecraft:redstone_wire replace
setblock ~253 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~154 ~496 minecraft:redstone_wire replace
setblock ~112 ~154 ~496 minecraft:redstone_wire replace
setblock ~115 ~154 ~496 minecraft:redstone_wire replace
setblock ~118 ~154 ~496 minecraft:redstone_wire replace
setblock ~121 ~154 ~496 minecraft:redstone_wire replace
setblock ~124 ~154 ~496 minecraft:redstone_wire replace
setblock ~127 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~154 ~496 minecraft:redstone_wire replace
setblock ~136 ~154 ~496 minecraft:redstone_wire replace
setblock ~139 ~154 ~496 minecraft:redstone_wire replace
setblock ~142 ~154 ~496 minecraft:redstone_wire replace
setblock ~145 ~154 ~496 minecraft:redstone_wire replace
setblock ~148 ~154 ~496 minecraft:redstone_wire replace
setblock ~151 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~154 ~496 minecraft:redstone_wire replace
setblock ~160 ~154 ~496 minecraft:redstone_wire replace
setblock ~163 ~154 ~496 minecraft:redstone_wire replace
setblock ~166 ~154 ~496 minecraft:redstone_wire replace
setblock ~169 ~154 ~496 minecraft:redstone_wire replace
setblock ~172 ~154 ~496 minecraft:redstone_wire replace
setblock ~175 ~154 ~496 minecraft:redstone_wire replace
setblock ~178 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~154 ~496 minecraft:redstone_wire replace
setblock ~187 ~154 ~496 minecraft:redstone_wire replace
setblock ~190 ~154 ~496 minecraft:redstone_wire replace
setblock ~193 ~154 ~496 minecraft:redstone_wire replace
setblock ~196 ~154 ~496 minecraft:redstone_wire replace
setblock ~199 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~154 ~496 minecraft:redstone_wire replace
setblock ~208 ~154 ~496 minecraft:redstone_wire replace
setblock ~211 ~154 ~496 minecraft:redstone_wire replace
setblock ~214 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~154 ~496 minecraft:redstone_wire replace
setblock ~220 ~154 ~496 minecraft:redstone_wire replace
setblock ~223 ~154 ~496 minecraft:redstone_wire replace
setblock ~226 ~154 ~496 minecraft:redstone_wire replace
setblock ~229 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~154 ~496 minecraft:redstone_wire replace
setblock ~238 ~154 ~496 minecraft:redstone_wire replace
setblock ~241 ~154 ~496 minecraft:redstone_wire replace
setblock ~244 ~154 ~496 minecraft:redstone_wire replace
setblock ~247 ~154 ~496 minecraft:redstone_wire replace
setblock ~250 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~154 ~508 minecraft:redstone_wire replace
setblock ~112 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~154 ~508 minecraft:redstone_wire replace
setblock ~121 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~508 minecraft:redstone_wire replace
setblock ~130 ~154 ~508 minecraft:redstone_wire replace
setblock ~133 ~154 ~508 minecraft:redstone_wire replace
setblock ~136 ~154 ~508 minecraft:redstone_wire replace
setblock ~139 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~154 ~508 minecraft:redstone_wire replace
setblock ~148 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~508 minecraft:redstone_wire replace
setblock ~154 ~154 ~508 minecraft:redstone_wire replace
setblock ~157 ~154 ~508 minecraft:redstone_wire replace
setblock ~160 ~154 ~508 minecraft:redstone_wire replace
setblock ~163 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~154 ~508 minecraft:redstone_wire replace
setblock ~169 ~154 ~508 minecraft:redstone_wire replace
setblock ~172 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~508 minecraft:redstone_wire replace
setblock ~181 ~154 ~508 minecraft:redstone_wire replace
setblock ~184 ~154 ~508 minecraft:redstone_wire replace
setblock ~187 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~154 ~508 minecraft:redstone_wire replace
setblock ~196 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~154 ~508 minecraft:redstone_wire replace
setblock ~202 ~154 ~508 minecraft:redstone_wire replace
setblock ~205 ~154 ~508 minecraft:redstone_wire replace
setblock ~208 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~154 ~508 minecraft:redstone_wire replace
setblock ~217 ~154 ~508 minecraft:redstone_wire replace
setblock ~220 ~154 ~508 minecraft:redstone_wire replace
setblock ~223 ~154 ~508 minecraft:redstone_wire replace
setblock ~226 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~154 ~508 minecraft:redstone_wire replace
setblock ~232 ~154 ~508 minecraft:redstone_wire replace
setblock ~235 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~154 ~508 minecraft:redstone_wire replace
setblock ~244 ~154 ~508 minecraft:redstone_wire replace
setblock ~247 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~154 ~508 minecraft:redstone_wire replace
setblock ~253 ~154 ~508 minecraft:redstone_wire replace
setblock ~109 ~154 ~532 minecraft:redstone_wire replace
setblock ~112 ~154 ~532 minecraft:redstone_wire replace
setblock ~115 ~154 ~532 minecraft:redstone_wire replace
setblock ~118 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~532 minecraft:redstone_wire replace
setblock ~130 ~154 ~532 minecraft:redstone_wire replace
setblock ~133 ~154 ~532 minecraft:redstone_wire replace
setblock ~136 ~154 ~532 minecraft:redstone_wire replace
setblock ~139 ~154 ~532 minecraft:redstone_wire replace
setblock ~142 ~154 ~532 minecraft:redstone_wire replace
setblock ~145 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~532 minecraft:redstone_wire replace
setblock ~154 ~154 ~532 minecraft:redstone_wire replace
setblock ~157 ~154 ~532 minecraft:redstone_wire replace
setblock ~160 ~154 ~532 minecraft:redstone_wire replace
setblock ~163 ~154 ~532 minecraft:redstone_wire replace
setblock ~166 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~532 minecraft:redstone_wire replace
setblock ~181 ~154 ~532 minecraft:redstone_wire replace
setblock ~184 ~154 ~532 minecraft:redstone_wire replace
setblock ~187 ~154 ~532 minecraft:redstone_wire replace
setblock ~190 ~154 ~532 minecraft:redstone_wire replace
setblock ~193 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~154 ~532 minecraft:redstone_wire replace
setblock ~202 ~154 ~532 minecraft:redstone_wire replace
setblock ~205 ~154 ~532 minecraft:redstone_wire replace
setblock ~208 ~154 ~532 minecraft:redstone_wire replace
setblock ~211 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~154 ~532 minecraft:redstone_wire replace
setblock ~217 ~154 ~532 minecraft:redstone_wire replace
setblock ~220 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~154 ~532 minecraft:redstone_wire replace
setblock ~232 ~154 ~532 minecraft:redstone_wire replace
setblock ~235 ~154 ~532 minecraft:redstone_wire replace
setblock ~238 ~154 ~532 minecraft:redstone_wire replace
setblock ~241 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~154 ~532 minecraft:redstone_wire replace
setblock ~253 ~154 ~532 minecraft:redstone_wire replace
setblock ~256 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~313 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~346 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~358 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~364 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~367 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~370 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~373 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~379 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~382 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~385 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~388 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~391 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~394 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~397 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~400 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~540 minecraft:redstone_wire replace
setblock ~259 ~154 ~540 minecraft:redstone_wire replace
setblock ~262 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~154 ~540 minecraft:redstone_wire replace
setblock ~271 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~540 minecraft:redstone_wire replace
setblock ~277 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~154 ~540 minecraft:redstone_wire replace
setblock ~283 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~154 ~540 minecraft:redstone_wire replace
setblock ~289 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~154 ~540 minecraft:redstone_wire replace
setblock ~295 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~540 minecraft:redstone_wire replace
setblock ~301 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~154 ~540 minecraft:redstone_wire replace
setblock ~307 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~313 ~154 ~540 minecraft:redstone_wire replace
setblock ~316 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~154 ~540 minecraft:redstone_wire replace
setblock ~322 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~540 minecraft:redstone_wire replace
setblock ~328 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~154 ~540 minecraft:redstone_wire replace
setblock ~334 ~154 ~540 minecraft:redstone_wire replace
setblock ~337 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~154 ~540 minecraft:redstone_wire replace
setblock ~346 ~154 ~540 minecraft:redstone_wire replace
setblock ~349 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~154 ~540 minecraft:redstone_wire replace
setblock ~355 ~154 ~540 minecraft:redstone_wire replace
setblock ~358 ~154 ~540 minecraft:redstone_wire replace
setblock ~361 ~154 ~540 minecraft:redstone_wire replace
setblock ~364 ~154 ~540 minecraft:redstone_wire replace
setblock ~367 ~154 ~540 minecraft:redstone_wire replace
setblock ~370 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~373 ~154 ~540 minecraft:redstone_wire replace
setblock ~376 ~154 ~540 minecraft:redstone_wire replace
setblock ~379 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~382 ~154 ~540 minecraft:redstone_wire replace
setblock ~385 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~388 ~154 ~540 minecraft:redstone_wire replace
setblock ~391 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~394 ~154 ~540 minecraft:redstone_wire replace
setblock ~397 ~154 ~540 minecraft:redstone_wire replace
setblock ~400 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~564 minecraft:redstone_wire replace
setblock ~259 ~154 ~564 minecraft:redstone_wire replace
setblock ~262 ~154 ~564 minecraft:redstone_wire replace
setblock ~265 ~154 ~564 minecraft:redstone_wire replace
setblock ~268 ~154 ~564 minecraft:redstone_wire replace
setblock ~271 ~154 ~564 minecraft:redstone_wire replace
setblock ~274 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~154 ~564 minecraft:redstone_wire replace
setblock ~283 ~154 ~564 minecraft:redstone_wire replace
setblock ~286 ~154 ~564 minecraft:redstone_wire replace
setblock ~289 ~154 ~564 minecraft:redstone_wire replace
setblock ~292 ~154 ~564 minecraft:redstone_wire replace
setblock ~295 ~154 ~564 minecraft:redstone_wire replace
setblock ~298 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~154 ~564 minecraft:redstone_wire replace
setblock ~307 ~154 ~564 minecraft:redstone_wire replace
setblock ~310 ~154 ~564 minecraft:redstone_wire replace
setblock ~313 ~154 ~564 minecraft:redstone_wire replace
setblock ~316 ~154 ~564 minecraft:redstone_wire replace
setblock ~319 ~154 ~564 minecraft:redstone_wire replace
setblock ~322 ~154 ~564 minecraft:redstone_wire replace
setblock ~325 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~154 ~564 minecraft:redstone_wire replace
setblock ~334 ~154 ~564 minecraft:redstone_wire replace
setblock ~337 ~154 ~564 minecraft:redstone_wire replace
setblock ~340 ~154 ~564 minecraft:redstone_wire replace
setblock ~343 ~154 ~564 minecraft:redstone_wire replace
setblock ~346 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~154 ~564 minecraft:redstone_wire replace
setblock ~355 ~154 ~564 minecraft:redstone_wire replace
setblock ~358 ~154 ~564 minecraft:redstone_wire replace
setblock ~361 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~364 ~154 ~564 minecraft:redstone_wire replace
setblock ~367 ~154 ~564 minecraft:redstone_wire replace
setblock ~370 ~154 ~564 minecraft:redstone_wire replace
setblock ~373 ~154 ~564 minecraft:redstone_wire replace
setblock ~376 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~379 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~382 ~154 ~564 minecraft:redstone_wire replace
setblock ~385 ~154 ~564 minecraft:redstone_wire replace
setblock ~388 ~154 ~564 minecraft:redstone_wire replace
setblock ~391 ~154 ~564 minecraft:redstone_wire replace
setblock ~394 ~154 ~564 minecraft:redstone_wire replace
setblock ~397 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~400 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~572 minecraft:redstone_wire replace
setblock ~259 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~154 ~572 minecraft:redstone_wire replace
setblock ~268 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~572 minecraft:redstone_wire replace
setblock ~277 ~154 ~572 minecraft:redstone_wire replace
setblock ~280 ~154 ~572 minecraft:redstone_wire replace
setblock ~283 ~154 ~572 minecraft:redstone_wire replace
setblock ~286 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~154 ~572 minecraft:redstone_wire replace
setblock ~295 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~572 minecraft:redstone_wire replace
setblock ~301 ~154 ~572 minecraft:redstone_wire replace
setblock ~304 ~154 ~572 minecraft:redstone_wire replace
setblock ~307 ~154 ~572 minecraft:redstone_wire replace
setblock ~310 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~313 ~154 ~572 minecraft:redstone_wire replace
setblock ~316 ~154 ~572 minecraft:redstone_wire replace
setblock ~319 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~572 minecraft:redstone_wire replace
setblock ~328 ~154 ~572 minecraft:redstone_wire replace
setblock ~331 ~154 ~572 minecraft:redstone_wire replace
setblock ~334 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~154 ~572 minecraft:redstone_wire replace
setblock ~343 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~346 ~154 ~572 minecraft:redstone_wire replace
setblock ~349 ~154 ~572 minecraft:redstone_wire replace
setblock ~352 ~154 ~572 minecraft:redstone_wire replace
setblock ~355 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~358 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~154 ~572 minecraft:redstone_wire replace
setblock ~364 ~154 ~572 minecraft:redstone_wire replace
setblock ~367 ~154 ~572 minecraft:redstone_wire replace
setblock ~370 ~154 ~572 minecraft:redstone_wire replace
setblock ~373 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~154 ~572 minecraft:redstone_wire replace
setblock ~379 ~154 ~572 minecraft:redstone_wire replace
setblock ~382 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~385 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~388 ~154 ~572 minecraft:redstone_wire replace
setblock ~391 ~154 ~572 minecraft:redstone_wire replace
setblock ~394 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~397 ~154 ~572 minecraft:redstone_wire replace
setblock ~400 ~154 ~572 minecraft:redstone_wire replace
setblock ~403 ~154 ~596 minecraft:redstone_wire replace
setblock ~406 ~154 ~596 minecraft:redstone_wire replace
setblock ~409 ~154 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~412 ~154 ~596 minecraft:redstone_wire replace
setblock ~415 ~154 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~418 ~154 ~596 minecraft:redstone_wire replace
setblock ~421 ~154 ~596 minecraft:redstone_wire replace
setblock ~424 ~154 ~596 minecraft:redstone_wire replace
setblock ~403 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~406 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~409 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~412 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~415 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~418 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~421 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~424 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~604 minecraft:redstone_wire replace
setblock ~259 ~154 ~604 minecraft:redstone_wire replace
setblock ~262 ~154 ~604 minecraft:redstone_wire replace
setblock ~265 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~604 minecraft:redstone_wire replace
setblock ~277 ~154 ~604 minecraft:redstone_wire replace
setblock ~280 ~154 ~604 minecraft:redstone_wire replace
setblock ~283 ~154 ~604 minecraft:redstone_wire replace
setblock ~286 ~154 ~604 minecraft:redstone_wire replace
setblock ~289 ~154 ~604 minecraft:redstone_wire replace
setblock ~292 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~604 minecraft:redstone_wire replace
setblock ~301 ~154 ~604 minecraft:redstone_wire replace
setblock ~304 ~154 ~604 minecraft:redstone_wire replace
setblock ~307 ~154 ~604 minecraft:redstone_wire replace
setblock ~310 ~154 ~604 minecraft:redstone_wire replace
setblock ~313 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~604 minecraft:redstone_wire replace
setblock ~328 ~154 ~604 minecraft:redstone_wire replace
setblock ~331 ~154 ~604 minecraft:redstone_wire replace
setblock ~334 ~154 ~604 minecraft:redstone_wire replace
setblock ~337 ~154 ~604 minecraft:redstone_wire replace
setblock ~340 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~346 ~154 ~604 minecraft:redstone_wire replace
setblock ~349 ~154 ~604 minecraft:redstone_wire replace
setblock ~352 ~154 ~604 minecraft:redstone_wire replace
setblock ~355 ~154 ~604 minecraft:redstone_wire replace
setblock ~358 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~154 ~604 minecraft:redstone_wire replace
setblock ~364 ~154 ~604 minecraft:redstone_wire replace
setblock ~367 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~370 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~373 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~154 ~604 minecraft:redstone_wire replace
setblock ~379 ~154 ~604 minecraft:redstone_wire replace
setblock ~382 ~154 ~604 minecraft:redstone_wire replace
setblock ~385 ~154 ~604 minecraft:redstone_wire replace
setblock ~388 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~391 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~394 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~397 ~154 ~604 minecraft:redstone_wire replace
setblock ~400 ~154 ~604 minecraft:redstone_wire replace
setblock ~433 ~154 ~640 minecraft:redstone_wire replace
setblock ~427 ~154 ~648 minecraft:redstone_wire replace
setblock ~430 ~154 ~656 minecraft:redstone_wire replace
fill ~105 ~155 ~228 ~105 ~155 ~232 minecraft:redstone_wire replace
fill ~81 ~155 ~232 ~81 ~155 ~236 minecraft:redstone_wire replace
fill ~102 ~155 ~236 ~102 ~155 ~248 minecraft:redstone_wire replace
setblock ~102 ~155 ~249 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~155 ~250 ~102 ~155 ~262 minecraft:redstone_wire replace
setblock ~102 ~155 ~263 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~155 ~264 ~99 ~155 ~276 minecraft:redstone_wire replace
setblock ~102 ~155 ~264 minecraft:redstone_wire replace
setblock ~99 ~155 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~155 ~278 ~99 ~155 ~286 minecraft:redstone_wire replace
fill ~96 ~155 ~288 ~96 ~155 ~300 minecraft:redstone_wire replace
setblock ~99 ~155 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~155 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~155 ~302 ~96 ~155 ~304 minecraft:redstone_wire replace
fill ~93 ~155 ~304 ~93 ~155 ~316 minecraft:redstone_wire replace
setblock ~93 ~155 ~317 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~155 ~318 ~93 ~155 ~330 minecraft:redstone_wire replace
setblock ~93 ~155 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~155 ~332 ~90 ~155 ~344 minecraft:redstone_wire replace
setblock ~93 ~155 ~332 minecraft:redstone_wire replace
setblock ~90 ~155 ~345 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~155 ~346 ~90 ~155 ~358 minecraft:redstone_wire replace
setblock ~90 ~155 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~155 ~360 ~90 ~155 ~366 minecraft:redstone_wire replace
fill ~87 ~155 ~368 ~87 ~155 ~380 minecraft:redstone_wire replace
setblock ~90 ~155 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~155 ~381 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~155 ~382 ~87 ~155 ~394 minecraft:redstone_wire replace
setblock ~87 ~155 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~155 ~396 ~87 ~155 ~400 minecraft:redstone_wire replace
fill ~84 ~155 ~400 ~84 ~155 ~412 minecraft:redstone_wire replace
setblock ~84 ~155 ~413 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~155 ~414 ~84 ~155 ~426 minecraft:redstone_wire replace
setblock ~84 ~155 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~155 ~428 ~84 ~155 ~432 minecraft:redstone_wire replace
fill ~78 ~155 ~444 ~78 ~155 ~448 minecraft:redstone_wire replace
fill ~108 ~155 ~472 ~108 ~155 ~484 minecraft:redstone_wire replace
fill ~111 ~155 ~472 ~111 ~155 ~484 minecraft:redstone_wire replace
fill ~114 ~155 ~472 ~114 ~155 ~484 minecraft:redstone_wire replace
fill ~117 ~155 ~472 ~117 ~155 ~484 minecraft:redstone_wire replace
fill ~120 ~155 ~472 ~120 ~155 ~484 minecraft:redstone_wire replace
fill ~123 ~155 ~472 ~123 ~155 ~484 minecraft:redstone_wire replace
fill ~126 ~155 ~472 ~126 ~155 ~484 minecraft:redstone_wire replace
fill ~129 ~155 ~472 ~129 ~155 ~484 minecraft:redstone_wire replace
fill ~132 ~155 ~472 ~132 ~155 ~484 minecraft:redstone_wire replace
fill ~135 ~155 ~472 ~135 ~155 ~484 minecraft:redstone_wire replace
fill ~138 ~155 ~472 ~138 ~155 ~484 minecraft:redstone_wire replace
fill ~141 ~155 ~472 ~141 ~155 ~484 minecraft:redstone_wire replace
fill ~144 ~155 ~472 ~144 ~155 ~484 minecraft:redstone_wire replace
fill ~147 ~155 ~472 ~147 ~155 ~484 minecraft:redstone_wire replace
fill ~150 ~155 ~472 ~150 ~155 ~484 minecraft:redstone_wire replace
fill ~153 ~155 ~472 ~153 ~155 ~484 minecraft:redstone_wire replace
fill ~156 ~155 ~472 ~156 ~155 ~484 minecraft:redstone_wire replace
fill ~159 ~155 ~472 ~159 ~155 ~484 minecraft:redstone_wire replace
fill ~162 ~155 ~472 ~162 ~155 ~484 minecraft:redstone_wire replace
fill ~165 ~155 ~472 ~165 ~155 ~484 minecraft:redstone_wire replace
fill ~168 ~155 ~472 ~168 ~155 ~484 minecraft:redstone_wire replace
fill ~171 ~155 ~472 ~171 ~155 ~484 minecraft:redstone_wire replace
fill ~174 ~155 ~472 ~174 ~155 ~484 minecraft:redstone_wire replace
fill ~177 ~155 ~472 ~177 ~155 ~484 minecraft:redstone_wire replace
fill ~180 ~155 ~472 ~180 ~155 ~484 minecraft:redstone_wire replace
fill ~183 ~155 ~472 ~183 ~155 ~484 minecraft:redstone_wire replace
fill ~186 ~155 ~472 ~186 ~155 ~484 minecraft:redstone_wire replace
fill ~189 ~155 ~472 ~189 ~155 ~484 minecraft:redstone_wire replace
fill ~192 ~155 ~472 ~192 ~155 ~484 minecraft:redstone_wire replace
fill ~195 ~155 ~472 ~195 ~155 ~484 minecraft:redstone_wire replace
fill ~198 ~155 ~472 ~198 ~155 ~484 minecraft:redstone_wire replace
fill ~201 ~155 ~472 ~201 ~155 ~484 minecraft:redstone_wire replace
fill ~204 ~155 ~472 ~204 ~155 ~484 minecraft:redstone_wire replace
fill ~207 ~155 ~472 ~207 ~155 ~484 minecraft:redstone_wire replace
fill ~210 ~155 ~472 ~210 ~155 ~484 minecraft:redstone_wire replace
fill ~213 ~155 ~472 ~213 ~155 ~484 minecraft:redstone_wire replace
fill ~216 ~155 ~472 ~216 ~155 ~484 minecraft:redstone_wire replace
fill ~219 ~155 ~472 ~219 ~155 ~484 minecraft:redstone_wire replace
fill ~222 ~155 ~472 ~222 ~155 ~484 minecraft:redstone_wire replace
fill ~225 ~155 ~472 ~225 ~155 ~484 minecraft:redstone_wire replace
fill ~228 ~155 ~472 ~228 ~155 ~484 minecraft:redstone_wire replace
fill ~231 ~155 ~472 ~231 ~155 ~484 minecraft:redstone_wire replace
fill ~234 ~155 ~472 ~234 ~155 ~484 minecraft:redstone_wire replace
fill ~237 ~155 ~472 ~237 ~155 ~484 minecraft:redstone_wire replace
fill ~240 ~155 ~472 ~240 ~155 ~484 minecraft:redstone_wire replace
fill ~243 ~155 ~472 ~243 ~155 ~484 minecraft:redstone_wire replace
fill ~246 ~155 ~472 ~246 ~155 ~484 minecraft:redstone_wire replace
fill ~249 ~155 ~472 ~249 ~155 ~484 minecraft:redstone_wire replace
fill ~252 ~155 ~472 ~252 ~155 ~484 minecraft:redstone_wire replace
setblock ~108 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
