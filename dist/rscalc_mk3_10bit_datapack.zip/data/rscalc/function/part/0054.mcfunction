setblock ~546 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~179 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~179 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~179 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~179 ~14 minecraft:light_gray_concrete replace
fill ~469 ~180 ~2 ~539 ~180 ~2 minecraft:light_gray_concrete replace
fill ~479 ~180 ~4 ~537 ~180 ~4 minecraft:light_gray_concrete replace
fill ~471 ~180 ~6 ~541 ~180 ~6 minecraft:light_gray_concrete replace
fill ~481 ~180 ~8 ~539 ~180 ~8 minecraft:light_gray_concrete replace
fill ~477 ~180 ~10 ~537 ~180 ~10 minecraft:light_gray_concrete replace
fill ~473 ~180 ~12 ~541 ~180 ~12 minecraft:light_gray_concrete replace
fill ~475 ~180 ~14 ~539 ~180 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~183 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~183 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~183 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~183 ~14 minecraft:light_gray_concrete replace
fill ~455 ~184 ~2 ~531 ~184 ~2 minecraft:light_gray_concrete replace
fill ~465 ~184 ~4 ~529 ~184 ~4 minecraft:light_gray_concrete replace
fill ~457 ~184 ~6 ~533 ~184 ~6 minecraft:light_gray_concrete replace
fill ~467 ~184 ~8 ~531 ~184 ~8 minecraft:light_gray_concrete replace
fill ~463 ~184 ~10 ~529 ~184 ~10 minecraft:light_gray_concrete replace
fill ~459 ~184 ~12 ~533 ~184 ~12 minecraft:light_gray_concrete replace
fill ~461 ~184 ~14 ~531 ~184 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~187 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~187 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~187 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~187 ~14 minecraft:light_gray_concrete replace
fill ~441 ~188 ~2 ~523 ~188 ~2 minecraft:light_gray_concrete replace
fill ~451 ~188 ~4 ~521 ~188 ~4 minecraft:light_gray_concrete replace
fill ~443 ~188 ~6 ~525 ~188 ~6 minecraft:light_gray_concrete replace
fill ~453 ~188 ~8 ~523 ~188 ~8 minecraft:light_gray_concrete replace
fill ~449 ~188 ~10 ~521 ~188 ~10 minecraft:light_gray_concrete replace
fill ~445 ~188 ~12 ~525 ~188 ~12 minecraft:light_gray_concrete replace
fill ~447 ~188 ~14 ~523 ~188 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~524 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~522 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~526 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~524 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~522 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~526 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~524 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~524 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~522 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~526 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~524 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~522 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~526 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~524 ~191 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~191 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~191 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~191 ~14 minecraft:light_gray_concrete replace
fill ~523 ~193 ~2 ~525 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~531 ~193 ~2 ~533 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~539 ~193 ~2 ~541 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~547 ~193 ~2 ~549 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~522 ~193 ~3 ~522 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~526 ~193 ~3 ~526 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~530 ~193 ~3 ~530 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~534 ~193 ~3 ~534 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~538 ~193 ~3 ~538 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~542 ~193 ~3 ~542 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~546 ~193 ~3 ~546 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~550 ~193 ~3 ~550 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~4 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~6 minecraft:redstone_lamp[lit=false] replace
fill ~523 ~193 ~8 ~525 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~531 ~193 ~8 ~533 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~539 ~193 ~8 ~541 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~547 ~193 ~8 ~549 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~522 ~193 ~9 ~522 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~526 ~193 ~9 ~526 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~530 ~193 ~9 ~530 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~534 ~193 ~9 ~534 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~538 ~193 ~9 ~538 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~542 ~193 ~9 ~542 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~546 ~193 ~9 ~546 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~550 ~193 ~9 ~550 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~523 ~193 ~14 ~525 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~531 ~193 ~14 ~533 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~539 ~193 ~14 ~541 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~547 ~193 ~14 ~549 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~53 ~1 ~94 ~55 ~1 ~94 minecraft:redstone_wire replace
setblock ~56 ~1 ~94 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~94 minecraft:redstone_wire replace
setblock ~58 ~1 ~94 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~49 ~1 ~96 ~55 ~1 ~96 minecraft:redstone_wire replace
setblock ~56 ~1 ~96 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~96 minecraft:redstone_wire replace
setblock ~58 ~1 ~96 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~45 ~1 ~98 ~55 ~1 ~98 minecraft:redstone_wire replace
setblock ~56 ~1 ~98 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~98 minecraft:redstone_wire replace
setblock ~58 ~1 ~98 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~41 ~1 ~100 ~43 ~1 ~100 minecraft:redstone_wire replace
setblock ~44 ~1 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~100 ~55 ~1 ~100 minecraft:redstone_wire replace
setblock ~56 ~1 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~100 minecraft:redstone_wire replace
setblock ~58 ~1 ~100 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~37 ~1 ~102 ~43 ~1 ~102 minecraft:redstone_wire replace
setblock ~44 ~1 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~102 ~55 ~1 ~102 minecraft:redstone_wire replace
setblock ~56 ~1 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~102 minecraft:redstone_wire replace
setblock ~58 ~1 ~102 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~33 ~1 ~104 ~43 ~1 ~104 minecraft:redstone_wire replace
setblock ~44 ~1 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~104 ~55 ~1 ~104 minecraft:redstone_wire replace
setblock ~56 ~1 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~104 minecraft:redstone_wire replace
setblock ~58 ~1 ~104 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~29 ~1 ~106 ~31 ~1 ~106 minecraft:redstone_wire replace
setblock ~32 ~1 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~106 ~43 ~1 ~106 minecraft:redstone_wire replace
setblock ~44 ~1 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~106 ~55 ~1 ~106 minecraft:redstone_wire replace
setblock ~56 ~1 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~106 minecraft:redstone_wire replace
setblock ~58 ~1 ~106 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~25 ~1 ~108 ~31 ~1 ~108 minecraft:redstone_wire replace
setblock ~32 ~1 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~108 ~43 ~1 ~108 minecraft:redstone_wire replace
setblock ~44 ~1 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~108 ~55 ~1 ~108 minecraft:redstone_wire replace
setblock ~56 ~1 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~108 minecraft:redstone_wire replace
setblock ~58 ~1 ~108 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~21 ~1 ~110 ~31 ~1 ~110 minecraft:redstone_wire replace
setblock ~32 ~1 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~110 ~43 ~1 ~110 minecraft:redstone_wire replace
setblock ~44 ~1 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~110 ~55 ~1 ~110 minecraft:redstone_wire replace
setblock ~56 ~1 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~110 minecraft:redstone_wire replace
setblock ~58 ~1 ~110 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~17 ~1 ~112 ~19 ~1 ~112 minecraft:redstone_wire replace
setblock ~20 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~112 ~31 ~1 ~112 minecraft:redstone_wire replace
setblock ~32 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~112 ~43 ~1 ~112 minecraft:redstone_wire replace
setblock ~44 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~112 ~55 ~1 ~112 minecraft:redstone_wire replace
setblock ~56 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~112 minecraft:redstone_wire replace
setblock ~58 ~1 ~112 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~13 ~1 ~114 ~19 ~1 ~114 minecraft:redstone_wire replace
setblock ~20 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~114 ~31 ~1 ~114 minecraft:redstone_wire replace
setblock ~32 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~114 ~43 ~1 ~114 minecraft:redstone_wire replace
setblock ~44 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~114 ~55 ~1 ~114 minecraft:redstone_wire replace
setblock ~56 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~114 minecraft:redstone_wire replace
setblock ~58 ~1 ~114 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~9 ~1 ~116 ~19 ~1 ~116 minecraft:redstone_wire replace
setblock ~20 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~116 ~31 ~1 ~116 minecraft:redstone_wire replace
setblock ~32 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~116 ~43 ~1 ~116 minecraft:redstone_wire replace
setblock ~44 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~116 ~55 ~1 ~116 minecraft:redstone_wire replace
setblock ~56 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~116 minecraft:redstone_wire replace
setblock ~58 ~1 ~116 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~5 ~1 ~118 ~7 ~1 ~118 minecraft:redstone_wire replace
setblock ~8 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~1 ~118 ~19 ~1 ~118 minecraft:redstone_wire replace
setblock ~20 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~118 ~31 ~1 ~118 minecraft:redstone_wire replace
setblock ~32 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~118 ~43 ~1 ~118 minecraft:redstone_wire replace
setblock ~44 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~118 ~55 ~1 ~118 minecraft:redstone_wire replace
setblock ~56 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~118 minecraft:redstone_wire replace
setblock ~58 ~1 ~118 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~1 ~1 ~120 ~7 ~1 ~120 minecraft:redstone_wire replace
setblock ~8 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~1 ~120 ~19 ~1 ~120 minecraft:redstone_wire replace
setblock ~20 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~120 ~31 ~1 ~120 minecraft:redstone_wire replace
setblock ~32 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~120 ~43 ~1 ~120 minecraft:redstone_wire replace
setblock ~44 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~120 ~55 ~1 ~120 minecraft:redstone_wire replace
setblock ~56 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~120 minecraft:redstone_wire replace
setblock ~58 ~1 ~120 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~52 ~2 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~2 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~2 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~2 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~2 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~2 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~2 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~2 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~2 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~2 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~2 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~2 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~2 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~2 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~4 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~4 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~4 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~4 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~4 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~4 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~4 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~4 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~4 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~4 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~4 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~4 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~4 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~4 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~55 ~5 ~94 minecraft:redstone_wire replace
setblock ~56 ~5 ~94 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~94 minecraft:redstone_wire replace
setblock ~58 ~5 ~94 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~51 ~5 ~96 ~55 ~5 ~96 minecraft:redstone_wire replace
setblock ~56 ~5 ~96 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~96 minecraft:redstone_wire replace
setblock ~58 ~5 ~96 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~47 ~5 ~98 ~55 ~5 ~98 minecraft:redstone_wire replace
setblock ~56 ~5 ~98 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~98 minecraft:redstone_wire replace
setblock ~58 ~5 ~98 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~43 ~5 ~100 minecraft:redstone_wire replace
setblock ~44 ~5 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~100 ~55 ~5 ~100 minecraft:redstone_wire replace
setblock ~56 ~5 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~100 minecraft:redstone_wire replace
setblock ~58 ~5 ~100 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~39 ~5 ~102 ~43 ~5 ~102 minecraft:redstone_wire replace
setblock ~44 ~5 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~102 ~55 ~5 ~102 minecraft:redstone_wire replace
setblock ~56 ~5 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~102 minecraft:redstone_wire replace
setblock ~58 ~5 ~102 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~35 ~5 ~104 ~43 ~5 ~104 minecraft:redstone_wire replace
setblock ~44 ~5 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~104 ~55 ~5 ~104 minecraft:redstone_wire replace
setblock ~56 ~5 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~104 minecraft:redstone_wire replace
setblock ~58 ~5 ~104 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~31 ~5 ~106 minecraft:redstone_wire replace
setblock ~32 ~5 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~106 ~43 ~5 ~106 minecraft:redstone_wire replace
setblock ~44 ~5 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~106 ~55 ~5 ~106 minecraft:redstone_wire replace
setblock ~56 ~5 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~106 minecraft:redstone_wire replace
setblock ~58 ~5 ~106 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~27 ~5 ~108 ~31 ~5 ~108 minecraft:redstone_wire replace
setblock ~32 ~5 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~108 ~43 ~5 ~108 minecraft:redstone_wire replace
setblock ~44 ~5 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~108 ~55 ~5 ~108 minecraft:redstone_wire replace
setblock ~56 ~5 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~108 minecraft:redstone_wire replace
setblock ~58 ~5 ~108 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~23 ~5 ~110 ~31 ~5 ~110 minecraft:redstone_wire replace
setblock ~32 ~5 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~110 ~43 ~5 ~110 minecraft:redstone_wire replace
setblock ~44 ~5 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~110 ~55 ~5 ~110 minecraft:redstone_wire replace
setblock ~56 ~5 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~110 minecraft:redstone_wire replace
setblock ~58 ~5 ~110 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~19 ~5 ~112 minecraft:redstone_wire replace
setblock ~20 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~112 ~31 ~5 ~112 minecraft:redstone_wire replace
setblock ~32 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~112 ~43 ~5 ~112 minecraft:redstone_wire replace
setblock ~44 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~112 ~55 ~5 ~112 minecraft:redstone_wire replace
setblock ~56 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~112 minecraft:redstone_wire replace
setblock ~58 ~5 ~112 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~15 ~5 ~114 ~19 ~5 ~114 minecraft:redstone_wire replace
setblock ~20 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~114 ~31 ~5 ~114 minecraft:redstone_wire replace
setblock ~32 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~114 ~43 ~5 ~114 minecraft:redstone_wire replace
setblock ~44 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~114 ~55 ~5 ~114 minecraft:redstone_wire replace
setblock ~56 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~114 minecraft:redstone_wire replace
setblock ~58 ~5 ~114 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~11 ~5 ~116 ~19 ~5 ~116 minecraft:redstone_wire replace
setblock ~20 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~116 ~31 ~5 ~116 minecraft:redstone_wire replace
setblock ~32 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~116 ~43 ~5 ~116 minecraft:redstone_wire replace
setblock ~44 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~116 ~55 ~5 ~116 minecraft:redstone_wire replace
setblock ~56 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~116 minecraft:redstone_wire replace
setblock ~58 ~5 ~116 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~7 ~5 ~118 minecraft:redstone_wire replace
setblock ~8 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~5 ~118 ~19 ~5 ~118 minecraft:redstone_wire replace
setblock ~20 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~118 ~31 ~5 ~118 minecraft:redstone_wire replace
setblock ~32 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~118 ~43 ~5 ~118 minecraft:redstone_wire replace
setblock ~44 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~118 ~55 ~5 ~118 minecraft:redstone_wire replace
setblock ~56 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~118 minecraft:redstone_wire replace
setblock ~58 ~5 ~118 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~3 ~5 ~120 ~7 ~5 ~120 minecraft:redstone_wire replace
setblock ~8 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~5 ~120 ~19 ~5 ~120 minecraft:redstone_wire replace
setblock ~20 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~120 ~31 ~5 ~120 minecraft:redstone_wire replace
setblock ~32 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~120 ~43 ~5 ~120 minecraft:redstone_wire replace
setblock ~44 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~120 ~55 ~5 ~120 minecraft:redstone_wire replace
setblock ~56 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~120 minecraft:redstone_wire replace
setblock ~58 ~5 ~120 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~52 ~6 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~6 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~6 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~6 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~6 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~6 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~6 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~6 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~6 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~38 ~6 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~6 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~6 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~6 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~6 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~6 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~6 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~6 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~6 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~6 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~6 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~6 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~6 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~6 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~6 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~6 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~6 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~6 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~6 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~8 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~8 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~8 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~8 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~8 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~8 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~8 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~8 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~8 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~38 ~8 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~8 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~8 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~8 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~8 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~8 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~8 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~8 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~8 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~8 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~8 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~8 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~8 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~8 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~8 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~8 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~8 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~8 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~8 ~120 minecraft:redstone_torch[lit=true] replace
fill ~38 ~9 ~3 ~38 ~9 ~4 minecraft:redstone_wire replace
setblock ~38 ~9 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~38 ~9 ~6 ~38 ~9 ~16 minecraft:redstone_wire replace
setblock ~34 ~9 ~7 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~34 ~9 ~8 ~34 ~9 ~18 minecraft:redstone_wire replace
fill ~30 ~9 ~11 ~30 ~9 ~20 minecraft:redstone_wire replace
fill ~26 ~9 ~15 ~26 ~9 ~22 minecraft:redstone_wire replace
setblock ~38 ~9 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~38 ~9 ~18 ~38 ~9 ~28 minecraft:redstone_wire replace
fill ~22 ~9 ~19 ~22 ~9 ~24 minecraft:redstone_wire replace
