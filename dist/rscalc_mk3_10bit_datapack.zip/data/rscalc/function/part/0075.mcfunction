setblock ~252 ~39 ~307 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~308 ~243 ~39 ~320 minecraft:redstone_wire replace
fill ~246 ~39 ~308 ~246 ~39 ~320 minecraft:redstone_wire replace
fill ~249 ~39 ~308 ~249 ~39 ~320 minecraft:redstone_wire replace
fill ~252 ~39 ~308 ~252 ~39 ~320 minecraft:redstone_wire replace
setblock ~258 ~39 ~308 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~39 ~310 ~258 ~39 ~322 minecraft:redstone_wire replace
setblock ~186 ~39 ~312 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~39 ~314 ~186 ~39 ~320 minecraft:redstone_wire replace
setblock ~324 ~39 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~316 ~324 ~39 ~328 minecraft:redstone_wire replace
setblock ~348 ~39 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~318 ~315 ~39 ~330 minecraft:redstone_wire replace
fill ~318 ~39 ~318 ~318 ~39 ~330 minecraft:redstone_wire replace
setblock ~333 ~39 ~318 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~318 ~348 ~39 ~330 minecraft:redstone_wire replace
fill ~255 ~39 ~320 ~255 ~39 ~324 minecraft:redstone_wire replace
setblock ~330 ~39 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~320 ~333 ~39 ~332 minecraft:redstone_wire replace
fill ~330 ~39 ~322 ~330 ~39 ~334 minecraft:redstone_wire replace
setblock ~201 ~39 ~324 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~258 ~39 ~324 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~39 ~326 ~201 ~39 ~336 minecraft:redstone_wire replace
fill ~258 ~39 ~326 ~258 ~39 ~338 minecraft:redstone_wire replace
fill ~222 ~39 ~328 ~222 ~39 ~332 minecraft:redstone_wire replace
setblock ~324 ~39 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~39 ~332 ~279 ~39 ~336 minecraft:redstone_wire replace
setblock ~315 ~39 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~332 ~324 ~39 ~344 minecraft:redstone_wire replace
setblock ~348 ~39 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~334 ~315 ~39 ~346 minecraft:redstone_wire replace
fill ~318 ~39 ~334 ~318 ~39 ~346 minecraft:redstone_wire replace
setblock ~333 ~39 ~334 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~334 ~348 ~39 ~346 minecraft:redstone_wire replace
setblock ~330 ~39 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~336 ~333 ~39 ~348 minecraft:redstone_wire replace
fill ~330 ~39 ~338 ~330 ~39 ~350 minecraft:redstone_wire replace
setblock ~258 ~39 ~339 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~39 ~340 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~39 ~340 ~258 ~39 ~352 minecraft:redstone_wire replace
fill ~225 ~39 ~342 ~225 ~39 ~352 minecraft:redstone_wire replace
fill ~261 ~39 ~344 ~261 ~39 ~348 minecraft:redstone_wire replace
setblock ~324 ~39 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~39 ~348 ~297 ~39 ~352 minecraft:redstone_wire replace
setblock ~315 ~39 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~348 ~324 ~39 ~360 minecraft:redstone_wire replace
setblock ~348 ~39 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~350 ~315 ~39 ~362 minecraft:redstone_wire replace
fill ~318 ~39 ~350 ~318 ~39 ~362 minecraft:redstone_wire replace
setblock ~333 ~39 ~350 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~350 ~348 ~39 ~362 minecraft:redstone_wire replace
setblock ~330 ~39 ~351 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~352 ~330 ~39 ~364 minecraft:redstone_wire replace
fill ~333 ~39 ~352 ~333 ~39 ~364 minecraft:redstone_wire replace
setblock ~264 ~39 ~356 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~39 ~358 ~264 ~39 ~364 minecraft:redstone_wire replace
fill ~321 ~39 ~360 ~321 ~39 ~364 minecraft:redstone_wire replace
setblock ~324 ~39 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~364 ~315 ~39 ~376 minecraft:redstone_wire replace
fill ~318 ~39 ~364 ~318 ~39 ~376 minecraft:redstone_wire replace
fill ~324 ~39 ~364 ~324 ~39 ~376 minecraft:redstone_wire replace
setblock ~336 ~39 ~364 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~348 ~39 ~364 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~336 ~39 ~366 ~336 ~39 ~372 minecraft:redstone_wire replace
fill ~348 ~39 ~366 ~348 ~39 ~378 minecraft:redstone_wire replace
setblock ~339 ~39 ~368 minecraft:redstone_wire replace
setblock ~339 ~39 ~370 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~39 ~372 ~312 ~39 ~376 minecraft:redstone_wire replace
fill ~339 ~39 ~372 ~339 ~39 ~384 minecraft:redstone_wire replace
fill ~327 ~39 ~376 ~327 ~39 ~380 minecraft:redstone_wire replace
setblock ~348 ~39 ~380 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~382 ~348 ~39 ~394 minecraft:redstone_wire replace
setblock ~285 ~39 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~39 ~386 ~285 ~39 ~392 minecraft:redstone_wire replace
fill ~363 ~39 ~388 ~363 ~39 ~392 minecraft:redstone_wire replace
setblock ~384 ~39 ~392 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~384 ~39 ~394 ~384 ~39 ~400 minecraft:redstone_wire replace
setblock ~348 ~39 ~395 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~396 ~348 ~39 ~408 minecraft:redstone_wire replace
setblock ~351 ~39 ~396 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~351 ~39 ~398 ~351 ~39 ~404 minecraft:redstone_wire replace
setblock ~375 ~39 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~375 ~39 ~402 ~375 ~39 ~412 minecraft:redstone_wire replace
fill ~345 ~39 ~404 ~345 ~39 ~408 minecraft:redstone_wire replace
fill ~90 ~39 ~412 ~90 ~39 ~416 minecraft:redstone_wire replace
fill ~117 ~39 ~416 ~117 ~39 ~420 minecraft:redstone_wire replace
fill ~144 ~39 ~420 ~144 ~39 ~424 minecraft:redstone_wire replace
fill ~192 ~39 ~424 ~192 ~39 ~428 minecraft:redstone_wire replace
fill ~213 ~39 ~428 ~213 ~39 ~432 minecraft:redstone_wire replace
fill ~237 ~39 ~432 ~237 ~39 ~436 minecraft:redstone_wire replace
fill ~282 ~39 ~436 ~282 ~39 ~440 minecraft:redstone_wire replace
fill ~306 ~39 ~440 ~306 ~39 ~444 minecraft:redstone_wire replace
fill ~342 ~39 ~444 ~342 ~39 ~448 minecraft:redstone_wire replace
fill ~87 ~39 ~448 ~87 ~39 ~452 minecraft:redstone_wire replace
fill ~114 ~39 ~452 ~114 ~39 ~456 minecraft:redstone_wire replace
fill ~141 ~39 ~456 ~141 ~39 ~460 minecraft:redstone_wire replace
fill ~189 ~39 ~460 ~189 ~39 ~464 minecraft:redstone_wire replace
fill ~210 ~39 ~464 ~210 ~39 ~468 minecraft:redstone_wire replace
fill ~234 ~39 ~468 ~234 ~39 ~472 minecraft:redstone_wire replace
fill ~276 ~39 ~472 ~276 ~39 ~476 minecraft:redstone_wire replace
fill ~303 ~39 ~476 ~303 ~39 ~480 minecraft:redstone_wire replace
fill ~366 ~39 ~480 ~366 ~39 ~484 minecraft:redstone_wire replace
fill ~390 ~39 ~484 ~390 ~39 ~488 minecraft:redstone_wire replace
fill ~84 ~39 ~488 ~84 ~39 ~492 minecraft:redstone_wire replace
fill ~111 ~39 ~492 ~111 ~39 ~496 minecraft:redstone_wire replace
fill ~138 ~39 ~496 ~138 ~39 ~500 minecraft:redstone_wire replace
fill ~171 ~39 ~500 ~171 ~39 ~504 minecraft:redstone_wire replace
fill ~207 ~39 ~504 ~207 ~39 ~508 minecraft:redstone_wire replace
fill ~231 ~39 ~508 ~231 ~39 ~512 minecraft:redstone_wire replace
fill ~273 ~39 ~512 ~273 ~39 ~516 minecraft:redstone_wire replace
fill ~300 ~39 ~516 ~300 ~39 ~520 minecraft:redstone_wire replace
fill ~360 ~39 ~520 ~360 ~39 ~524 minecraft:redstone_wire replace
fill ~387 ~39 ~524 ~387 ~39 ~528 minecraft:redstone_wire replace
fill ~81 ~39 ~528 ~81 ~39 ~532 minecraft:redstone_wire replace
fill ~108 ~39 ~532 ~108 ~39 ~536 minecraft:redstone_wire replace
fill ~135 ~39 ~536 ~135 ~39 ~540 minecraft:redstone_wire replace
fill ~165 ~39 ~540 ~165 ~39 ~544 minecraft:redstone_wire replace
fill ~204 ~39 ~544 ~204 ~39 ~548 minecraft:redstone_wire replace
fill ~228 ~39 ~548 ~228 ~39 ~552 minecraft:redstone_wire replace
fill ~270 ~39 ~552 ~270 ~39 ~556 minecraft:redstone_wire replace
fill ~291 ~39 ~556 ~291 ~39 ~560 minecraft:redstone_wire replace
fill ~357 ~39 ~560 ~357 ~39 ~564 minecraft:redstone_wire replace
fill ~381 ~39 ~564 ~381 ~39 ~568 minecraft:redstone_wire replace
fill ~78 ~39 ~568 ~78 ~39 ~572 minecraft:redstone_wire replace
fill ~105 ~39 ~572 ~105 ~39 ~576 minecraft:redstone_wire replace
fill ~132 ~39 ~576 ~132 ~39 ~580 minecraft:redstone_wire replace
fill ~162 ~39 ~580 ~162 ~39 ~584 minecraft:redstone_wire replace
fill ~198 ~39 ~584 ~198 ~39 ~588 minecraft:redstone_wire replace
fill ~219 ~39 ~588 ~219 ~39 ~592 minecraft:redstone_wire replace
fill ~267 ~39 ~592 ~267 ~39 ~596 minecraft:redstone_wire replace
fill ~288 ~39 ~596 ~288 ~39 ~600 minecraft:redstone_wire replace
fill ~354 ~39 ~600 ~354 ~39 ~604 minecraft:redstone_wire replace
fill ~378 ~39 ~604 ~378 ~39 ~608 minecraft:redstone_wire replace
fill ~102 ~39 ~608 ~102 ~39 ~612 minecraft:redstone_wire replace
fill ~129 ~39 ~612 ~129 ~39 ~616 minecraft:redstone_wire replace
fill ~159 ~39 ~616 ~159 ~39 ~620 minecraft:redstone_wire replace
fill ~195 ~39 ~620 ~195 ~39 ~624 minecraft:redstone_wire replace
fill ~216 ~39 ~624 ~216 ~39 ~628 minecraft:redstone_wire replace
fill ~240 ~39 ~628 ~240 ~39 ~632 minecraft:redstone_wire replace
fill ~294 ~39 ~632 ~294 ~39 ~636 minecraft:redstone_wire replace
fill ~309 ~39 ~636 ~309 ~39 ~640 minecraft:redstone_wire replace
fill ~369 ~39 ~640 ~369 ~39 ~644 minecraft:redstone_wire replace
fill ~168 ~39 ~644 ~168 ~39 ~648 minecraft:redstone_wire replace
fill ~396 ~39 ~648 ~396 ~39 ~652 minecraft:redstone_wire replace
fill ~99 ~39 ~652 ~99 ~39 ~656 minecraft:redstone_wire replace
fill ~372 ~39 ~656 ~372 ~39 ~660 minecraft:redstone_wire replace
fill ~393 ~39 ~660 ~393 ~39 ~664 minecraft:redstone_wire replace
setblock ~243 ~40 ~3 minecraft:redstone_wire replace
setblock ~174 ~40 ~7 minecraft:redstone_wire replace
setblock ~147 ~40 ~11 minecraft:redstone_wire replace
setblock ~246 ~40 ~15 minecraft:redstone_wire replace
setblock ~177 ~40 ~19 minecraft:redstone_wire replace
setblock ~249 ~40 ~27 minecraft:redstone_wire replace
setblock ~330 ~40 ~35 minecraft:redstone_wire replace
setblock ~315 ~40 ~39 minecraft:redstone_wire replace
setblock ~258 ~40 ~43 minecraft:redstone_wire replace
setblock ~333 ~40 ~47 minecraft:redstone_wire replace
setblock ~318 ~40 ~51 minecraft:redstone_wire replace
setblock ~324 ~40 ~59 minecraft:redstone_wire replace
setblock ~348 ~40 ~75 minecraft:redstone_wire replace
setblock ~93 ~40 ~247 minecraft:redstone_wire replace
setblock ~123 ~40 ~251 minecraft:redstone_wire replace
setblock ~252 ~40 ~255 minecraft:redstone_wire replace
setblock ~183 ~40 ~259 minecraft:redstone_wire replace
setblock ~153 ~40 ~263 minecraft:redstone_wire replace
setblock ~126 ~40 ~267 minecraft:redstone_wire replace
setblock ~96 ~40 ~275 minecraft:redstone_wire replace
setblock ~120 ~40 ~279 minecraft:redstone_wire replace
setblock ~150 ~40 ~283 minecraft:redstone_wire replace
setblock ~156 ~40 ~295 minecraft:redstone_wire replace
setblock ~180 ~40 ~299 minecraft:redstone_wire replace
setblock ~186 ~40 ~311 minecraft:redstone_wire replace
setblock ~255 ~40 ~319 minecraft:redstone_wire replace
setblock ~201 ~40 ~323 minecraft:redstone_wire replace
setblock ~222 ~40 ~327 minecraft:redstone_wire replace
setblock ~279 ~40 ~331 minecraft:redstone_wire replace
setblock ~225 ~40 ~339 minecraft:redstone_wire replace
setblock ~261 ~40 ~343 minecraft:redstone_wire replace
setblock ~297 ~40 ~347 minecraft:redstone_wire replace
setblock ~264 ~40 ~355 minecraft:redstone_wire replace
setblock ~321 ~40 ~359 minecraft:redstone_wire replace
setblock ~336 ~40 ~363 minecraft:redstone_wire replace
setblock ~339 ~40 ~367 minecraft:redstone_wire replace
setblock ~312 ~40 ~371 minecraft:redstone_wire replace
setblock ~327 ~40 ~375 minecraft:redstone_wire replace
setblock ~285 ~40 ~383 minecraft:redstone_wire replace
setblock ~363 ~40 ~387 minecraft:redstone_wire replace
setblock ~384 ~40 ~391 minecraft:redstone_wire replace
setblock ~351 ~40 ~395 minecraft:redstone_wire replace
setblock ~375 ~40 ~399 minecraft:redstone_wire replace
setblock ~345 ~40 ~403 minecraft:redstone_wire replace
setblock ~90 ~40 ~411 minecraft:redstone_wire replace
setblock ~117 ~40 ~415 minecraft:redstone_wire replace
setblock ~144 ~40 ~419 minecraft:redstone_wire replace
setblock ~192 ~40 ~423 minecraft:redstone_wire replace
setblock ~213 ~40 ~427 minecraft:redstone_wire replace
setblock ~237 ~40 ~431 minecraft:redstone_wire replace
setblock ~282 ~40 ~435 minecraft:redstone_wire replace
setblock ~306 ~40 ~439 minecraft:redstone_wire replace
setblock ~342 ~40 ~443 minecraft:redstone_wire replace
setblock ~87 ~40 ~447 minecraft:redstone_wire replace
setblock ~114 ~40 ~451 minecraft:redstone_wire replace
setblock ~141 ~40 ~455 minecraft:redstone_wire replace
setblock ~189 ~40 ~459 minecraft:redstone_wire replace
setblock ~210 ~40 ~463 minecraft:redstone_wire replace
setblock ~234 ~40 ~467 minecraft:redstone_wire replace
setblock ~276 ~40 ~471 minecraft:redstone_wire replace
setblock ~303 ~40 ~475 minecraft:redstone_wire replace
setblock ~366 ~40 ~479 minecraft:redstone_wire replace
setblock ~390 ~40 ~483 minecraft:redstone_wire replace
setblock ~84 ~40 ~487 minecraft:redstone_wire replace
setblock ~111 ~40 ~491 minecraft:redstone_wire replace
setblock ~138 ~40 ~495 minecraft:redstone_wire replace
setblock ~171 ~40 ~499 minecraft:redstone_wire replace
setblock ~207 ~40 ~503 minecraft:redstone_wire replace
setblock ~231 ~40 ~507 minecraft:redstone_wire replace
setblock ~273 ~40 ~511 minecraft:redstone_wire replace
setblock ~300 ~40 ~515 minecraft:redstone_wire replace
setblock ~360 ~40 ~519 minecraft:redstone_wire replace
setblock ~387 ~40 ~523 minecraft:redstone_wire replace
setblock ~81 ~40 ~527 minecraft:redstone_wire replace
setblock ~108 ~40 ~531 minecraft:redstone_wire replace
setblock ~135 ~40 ~535 minecraft:redstone_wire replace
setblock ~165 ~40 ~539 minecraft:redstone_wire replace
setblock ~204 ~40 ~543 minecraft:redstone_wire replace
setblock ~228 ~40 ~547 minecraft:redstone_wire replace
setblock ~270 ~40 ~551 minecraft:redstone_wire replace
setblock ~291 ~40 ~555 minecraft:redstone_wire replace
setblock ~357 ~40 ~559 minecraft:redstone_wire replace
setblock ~381 ~40 ~563 minecraft:redstone_wire replace
setblock ~78 ~40 ~567 minecraft:redstone_wire replace
setblock ~105 ~40 ~571 minecraft:redstone_wire replace
setblock ~132 ~40 ~575 minecraft:redstone_wire replace
setblock ~162 ~40 ~579 minecraft:redstone_wire replace
setblock ~198 ~40 ~583 minecraft:redstone_wire replace
setblock ~219 ~40 ~587 minecraft:redstone_wire replace
setblock ~267 ~40 ~591 minecraft:redstone_wire replace
setblock ~288 ~40 ~595 minecraft:redstone_wire replace
setblock ~354 ~40 ~599 minecraft:redstone_wire replace
setblock ~378 ~40 ~603 minecraft:redstone_wire replace
setblock ~102 ~40 ~607 minecraft:redstone_wire replace
setblock ~129 ~40 ~611 minecraft:redstone_wire replace
setblock ~159 ~40 ~615 minecraft:redstone_wire replace
setblock ~195 ~40 ~619 minecraft:redstone_wire replace
setblock ~216 ~40 ~623 minecraft:redstone_wire replace
setblock ~240 ~40 ~627 minecraft:redstone_wire replace
setblock ~294 ~40 ~631 minecraft:redstone_wire replace
setblock ~309 ~40 ~635 minecraft:redstone_wire replace
setblock ~369 ~40 ~639 minecraft:redstone_wire replace
setblock ~168 ~40 ~643 minecraft:redstone_wire replace
setblock ~396 ~40 ~647 minecraft:redstone_wire replace
setblock ~99 ~40 ~651 minecraft:redstone_wire replace
setblock ~372 ~40 ~655 minecraft:redstone_wire replace
setblock ~393 ~40 ~659 minecraft:redstone_wire replace
setblock ~226 ~41 ~1 minecraft:redstone_wire replace
fill ~225 ~41 ~2 ~228 ~41 ~2 minecraft:redstone_wire replace
setblock ~230 ~41 ~2 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~41 ~2 ~243 ~41 ~2 minecraft:redstone_wire replace
setblock ~166 ~41 ~5 minecraft:redstone_wire replace
fill ~165 ~41 ~6 ~174 ~41 ~6 minecraft:redstone_wire replace
setblock ~145 ~41 ~9 minecraft:redstone_wire replace
fill ~144 ~41 ~10 ~147 ~41 ~10 minecraft:redstone_wire replace
setblock ~226 ~41 ~13 minecraft:redstone_wire replace
fill ~225 ~41 ~14 ~233 ~41 ~14 minecraft:redstone_wire replace
setblock ~235 ~41 ~14 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~41 ~14 ~246 ~41 ~14 minecraft:redstone_wire replace
setblock ~166 ~41 ~17 minecraft:redstone_wire replace
fill ~165 ~41 ~18 ~167 ~41 ~18 minecraft:redstone_wire replace
setblock ~169 ~41 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~41 ~18 ~177 ~41 ~18 minecraft:redstone_wire replace
setblock ~226 ~41 ~25 minecraft:redstone_wire replace
setblock ~225 ~41 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~41 ~26 ~239 ~41 ~26 minecraft:redstone_wire replace
setblock ~241 ~41 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~41 ~26 ~249 ~41 ~26 minecraft:redstone_wire replace
setblock ~301 ~41 ~33 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~300 ~41 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~41 ~34 ~314 ~41 ~34 minecraft:redstone_wire replace
setblock ~316 ~41 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~41 ~34 ~330 ~41 ~34 minecraft:redstone_wire replace
setblock ~286 ~41 ~37 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~41 ~38 ~287 ~41 ~38 minecraft:redstone_wire replace
setblock ~288 ~41 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~41 ~38 ~302 ~41 ~38 minecraft:redstone_wire replace
setblock ~304 ~41 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~41 ~38 ~315 ~41 ~38 minecraft:redstone_wire replace
setblock ~229 ~41 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~41 ~42 ~232 ~41 ~42 minecraft:redstone_wire replace
setblock ~234 ~41 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~41 ~42 ~249 ~41 ~42 minecraft:redstone_wire replace
setblock ~251 ~41 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~41 ~42 ~258 ~41 ~42 minecraft:redstone_wire replace
setblock ~304 ~41 ~45 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~303 ~41 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~41 ~46 ~317 ~41 ~46 minecraft:redstone_wire replace
setblock ~319 ~41 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~41 ~46 ~333 ~41 ~46 minecraft:redstone_wire replace
setblock ~289 ~41 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~288 ~41 ~50 ~292 ~41 ~50 minecraft:redstone_wire replace
setblock ~294 ~41 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~41 ~50 ~309 ~41 ~50 minecraft:redstone_wire replace
setblock ~311 ~41 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~41 ~50 ~318 ~41 ~50 minecraft:redstone_wire replace
setblock ~295 ~41 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~294 ~41 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~41 ~58 ~308 ~41 ~58 minecraft:redstone_wire replace
setblock ~310 ~41 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~41 ~58 ~324 ~41 ~58 minecraft:redstone_wire replace
setblock ~319 ~41 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~41 ~74 ~320 ~41 ~74 minecraft:redstone_wire replace
setblock ~321 ~41 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~41 ~74 ~334 ~41 ~74 minecraft:redstone_wire replace
setblock ~336 ~41 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~338 ~41 ~74 ~348 ~41 ~74 minecraft:redstone_wire replace
setblock ~94 ~41 ~245 minecraft:redstone_wire replace
fill ~93 ~41 ~246 ~95 ~41 ~246 minecraft:redstone_wire replace
setblock ~124 ~41 ~249 minecraft:redstone_wire replace
fill ~123 ~41 ~250 ~125 ~41 ~250 minecraft:redstone_wire replace
setblock ~226 ~41 ~253 minecraft:redstone_wire replace
fill ~225 ~41 ~254 ~226 ~41 ~254 minecraft:redstone_wire replace
setblock ~228 ~41 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~41 ~254 ~243 ~41 ~254 minecraft:redstone_wire replace
setblock ~245 ~41 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~41 ~254 ~252 ~41 ~254 minecraft:redstone_wire replace
setblock ~166 ~41 ~257 minecraft:redstone_wire replace
fill ~165 ~41 ~258 ~170 ~41 ~258 minecraft:redstone_wire replace
setblock ~172 ~41 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~41 ~258 ~183 ~41 ~258 minecraft:redstone_wire replace
setblock ~145 ~41 ~261 minecraft:redstone_wire replace
fill ~144 ~41 ~262 ~153 ~41 ~262 minecraft:redstone_wire replace
setblock ~124 ~41 ~265 minecraft:redstone_wire replace
fill ~123 ~41 ~266 ~126 ~41 ~266 minecraft:redstone_wire replace
setblock ~97 ~41 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~41 ~274 ~98 ~41 ~274 minecraft:redstone_wire replace
setblock ~121 ~41 ~277 minecraft:redstone_wire replace
fill ~120 ~41 ~278 ~122 ~41 ~278 minecraft:redstone_wire replace
setblock ~145 ~41 ~281 minecraft:redstone_wire replace
fill ~144 ~41 ~282 ~150 ~41 ~282 minecraft:redstone_wire replace
setblock ~148 ~41 ~293 minecraft:redstone_wire replace
fill ~147 ~41 ~294 ~156 ~41 ~294 minecraft:redstone_wire replace
setblock ~166 ~41 ~297 minecraft:redstone_wire replace
fill ~165 ~41 ~298 ~170 ~41 ~298 minecraft:redstone_wire replace
setblock ~172 ~41 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~41 ~298 ~180 ~41 ~298 minecraft:redstone_wire replace
setblock ~169 ~41 ~309 minecraft:redstone_wire replace
fill ~168 ~41 ~310 ~170 ~41 ~310 minecraft:redstone_wire replace
setblock ~172 ~41 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~41 ~310 ~186 ~41 ~310 minecraft:redstone_wire replace
setblock ~226 ~41 ~317 minecraft:redstone_wire replace
fill ~225 ~41 ~318 ~228 ~41 ~318 minecraft:redstone_wire replace
setblock ~230 ~41 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~41 ~318 ~245 ~41 ~318 minecraft:redstone_wire replace
setblock ~247 ~41 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~41 ~318 ~255 ~41 ~318 minecraft:redstone_wire replace
setblock ~184 ~41 ~321 minecraft:redstone_wire replace
fill ~183 ~41 ~322 ~185 ~41 ~322 minecraft:redstone_wire replace
setblock ~187 ~41 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~41 ~322 ~201 ~41 ~322 minecraft:redstone_wire replace
setblock ~205 ~41 ~325 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~41 ~326 ~212 ~41 ~326 minecraft:redstone_wire replace
setblock ~214 ~41 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~41 ~326 ~222 ~41 ~326 minecraft:redstone_wire replace
setblock ~250 ~41 ~329 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~41 ~330 ~252 ~41 ~330 minecraft:redstone_wire replace
setblock ~254 ~41 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~41 ~330 ~269 ~41 ~330 minecraft:redstone_wire replace
setblock ~271 ~41 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~41 ~330 ~279 ~41 ~330 minecraft:redstone_wire replace
setblock ~208 ~41 ~337 minecraft:redstone_wire replace
fill ~207 ~41 ~338 ~209 ~41 ~338 minecraft:redstone_wire replace
setblock ~211 ~41 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~41 ~338 ~225 ~41 ~338 minecraft:redstone_wire replace
setblock ~232 ~41 ~341 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~41 ~342 ~234 ~41 ~342 minecraft:redstone_wire replace
setblock ~236 ~41 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~41 ~342 ~251 ~41 ~342 minecraft:redstone_wire replace
setblock ~253 ~41 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~41 ~342 ~261 ~41 ~342 minecraft:redstone_wire replace
setblock ~268 ~41 ~345 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~41 ~346 ~270 ~41 ~346 minecraft:redstone_wire replace
setblock ~272 ~41 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~41 ~346 ~287 ~41 ~346 minecraft:redstone_wire replace
setblock ~289 ~41 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~41 ~346 ~297 ~41 ~346 minecraft:redstone_wire replace
setblock ~235 ~41 ~353 minecraft:redstone_wire replace
setblock ~234 ~41 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~41 ~354 ~248 ~41 ~354 minecraft:redstone_wire replace
setblock ~250 ~41 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~41 ~354 ~264 ~41 ~354 minecraft:redstone_wire replace
setblock ~292 ~41 ~357 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~291 ~41 ~358 ~294 ~41 ~358 minecraft:redstone_wire replace
setblock ~296 ~41 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~41 ~358 ~311 ~41 ~358 minecraft:redstone_wire replace
setblock ~313 ~41 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~41 ~358 ~321 ~41 ~358 minecraft:redstone_wire replace
setblock ~307 ~41 ~361 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~306 ~41 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~41 ~362 ~320 ~41 ~362 minecraft:redstone_wire replace
setblock ~322 ~41 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~41 ~362 ~336 ~41 ~362 minecraft:redstone_wire replace
setblock ~310 ~41 ~365 minecraft:redstone_wire replace
fill ~309 ~41 ~366 ~311 ~41 ~366 minecraft:redstone_wire replace
setblock ~312 ~41 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~41 ~366 ~325 ~41 ~366 minecraft:redstone_wire replace
setblock ~327 ~41 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~41 ~366 ~339 ~41 ~366 minecraft:redstone_wire replace
setblock ~283 ~41 ~369 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~41 ~370 ~285 ~41 ~370 minecraft:redstone_wire replace
setblock ~287 ~41 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~41 ~370 ~302 ~41 ~370 minecraft:redstone_wire replace
setblock ~304 ~41 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~41 ~370 ~312 ~41 ~370 minecraft:redstone_wire replace
setblock ~298 ~41 ~373 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~41 ~374 ~300 ~41 ~374 minecraft:redstone_wire replace
setblock ~302 ~41 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~41 ~374 ~317 ~41 ~374 minecraft:redstone_wire replace
setblock ~319 ~41 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~41 ~374 ~327 ~41 ~374 minecraft:redstone_wire replace
setblock ~256 ~41 ~381 minecraft:redstone_wire replace
setblock ~255 ~41 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~41 ~382 ~269 ~41 ~382 minecraft:redstone_wire replace
setblock ~271 ~41 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~41 ~382 ~285 ~41 ~382 minecraft:redstone_wire replace
setblock ~334 ~41 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~41 ~386 ~336 ~41 ~386 minecraft:redstone_wire replace
setblock ~338 ~41 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~340 ~41 ~386 ~353 ~41 ~386 minecraft:redstone_wire replace
setblock ~355 ~41 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~357 ~41 ~386 ~363 ~41 ~386 minecraft:redstone_wire replace
setblock ~355 ~41 ~389 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~354 ~41 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~355 ~41 ~390 ~368 ~41 ~390 minecraft:redstone_wire replace
setblock ~370 ~41 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~372 ~41 ~390 ~384 ~41 ~390 minecraft:redstone_wire replace
setblock ~322 ~41 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~321 ~41 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~41 ~394 ~335 ~41 ~394 minecraft:redstone_wire replace
setblock ~337 ~41 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~41 ~394 ~351 ~41 ~394 minecraft:redstone_wire replace
setblock ~346 ~41 ~397 minecraft:redstone_wire replace
setblock ~345 ~41 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~41 ~398 ~359 ~41 ~398 minecraft:redstone_wire replace
setblock ~361 ~41 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~41 ~398 ~375 ~41 ~398 minecraft:redstone_wire replace
setblock ~316 ~41 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~41 ~402 ~318 ~41 ~402 minecraft:redstone_wire replace
setblock ~320 ~41 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~41 ~402 ~335 ~41 ~402 minecraft:redstone_wire replace
setblock ~337 ~41 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~41 ~402 ~345 ~41 ~402 minecraft:redstone_wire replace
setblock ~91 ~41 ~409 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~41 ~410 ~92 ~41 ~410 minecraft:redstone_wire replace
setblock ~118 ~41 ~413 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~41 ~414 ~119 ~41 ~414 minecraft:redstone_wire replace
setblock ~142 ~41 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~41 ~418 ~144 ~41 ~418 minecraft:redstone_wire replace
setblock ~175 ~41 ~421 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~41 ~422 ~182 ~41 ~422 minecraft:redstone_wire replace
setblock ~184 ~41 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~41 ~422 ~192 ~41 ~422 minecraft:redstone_wire replace
setblock ~196 ~41 ~425 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~41 ~426 ~203 ~41 ~426 minecraft:redstone_wire replace
setblock ~205 ~41 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~41 ~426 ~213 ~41 ~426 minecraft:redstone_wire replace
setblock ~220 ~41 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~219 ~41 ~430 ~227 ~41 ~430 minecraft:redstone_wire replace
setblock ~229 ~41 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~41 ~430 ~237 ~41 ~430 minecraft:redstone_wire replace
setblock ~253 ~41 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~41 ~434 ~255 ~41 ~434 minecraft:redstone_wire replace
setblock ~257 ~41 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~41 ~434 ~272 ~41 ~434 minecraft:redstone_wire replace
setblock ~274 ~41 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~41 ~434 ~282 ~41 ~434 minecraft:redstone_wire replace
setblock ~277 ~41 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~41 ~438 ~279 ~41 ~438 minecraft:redstone_wire replace
setblock ~281 ~41 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~41 ~438 ~296 ~41 ~438 minecraft:redstone_wire replace
setblock ~298 ~41 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~41 ~438 ~306 ~41 ~438 minecraft:redstone_wire replace
setblock ~313 ~41 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~41 ~442 ~315 ~41 ~442 minecraft:redstone_wire replace
setblock ~317 ~41 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~41 ~442 ~332 ~41 ~442 minecraft:redstone_wire replace
setblock ~334 ~41 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~41 ~442 ~342 ~41 ~442 minecraft:redstone_wire replace
setblock ~88 ~41 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~41 ~446 ~89 ~41 ~446 minecraft:redstone_wire replace
setblock ~115 ~41 ~449 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~41 ~450 ~116 ~41 ~450 minecraft:redstone_wire replace
setblock ~139 ~41 ~453 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~41 ~454 ~141 ~41 ~454 minecraft:redstone_wire replace
setblock ~172 ~41 ~457 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~41 ~458 ~179 ~41 ~458 minecraft:redstone_wire replace
setblock ~181 ~41 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~41 ~458 ~189 ~41 ~458 minecraft:redstone_wire replace
setblock ~193 ~41 ~461 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~41 ~462 ~200 ~41 ~462 minecraft:redstone_wire replace
setblock ~202 ~41 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~41 ~462 ~210 ~41 ~462 minecraft:redstone_wire replace
setblock ~217 ~41 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~41 ~466 ~224 ~41 ~466 minecraft:redstone_wire replace
setblock ~226 ~41 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~41 ~466 ~234 ~41 ~466 minecraft:redstone_wire replace
setblock ~247 ~41 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~41 ~470 ~249 ~41 ~470 minecraft:redstone_wire replace
setblock ~251 ~41 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~41 ~470 ~266 ~41 ~470 minecraft:redstone_wire replace
setblock ~268 ~41 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~41 ~470 ~276 ~41 ~470 minecraft:redstone_wire replace
setblock ~274 ~41 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~41 ~474 ~276 ~41 ~474 minecraft:redstone_wire replace
setblock ~278 ~41 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~41 ~474 ~293 ~41 ~474 minecraft:redstone_wire replace
setblock ~295 ~41 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~41 ~474 ~303 ~41 ~474 minecraft:redstone_wire replace
setblock ~337 ~41 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~336 ~41 ~478 ~339 ~41 ~478 minecraft:redstone_wire replace
setblock ~341 ~41 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~41 ~478 ~356 ~41 ~478 minecraft:redstone_wire replace
setblock ~358 ~41 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~360 ~41 ~478 ~366 ~41 ~478 minecraft:redstone_wire replace
setblock ~361 ~41 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~360 ~41 ~482 ~363 ~41 ~482 minecraft:redstone_wire replace
setblock ~365 ~41 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~367 ~41 ~482 ~380 ~41 ~482 minecraft:redstone_wire replace
setblock ~382 ~41 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~384 ~41 ~482 ~390 ~41 ~482 minecraft:redstone_wire replace
setblock ~85 ~41 ~485 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~41 ~486 ~86 ~41 ~486 minecraft:redstone_wire replace
setblock ~112 ~41 ~489 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~41 ~490 ~113 ~41 ~490 minecraft:redstone_wire replace
setblock ~136 ~41 ~493 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~41 ~494 ~138 ~41 ~494 minecraft:redstone_wire replace
setblock ~163 ~41 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~41 ~498 ~163 ~41 ~498 minecraft:redstone_wire replace
setblock ~164 ~41 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~41 ~498 ~171 ~41 ~498 minecraft:redstone_wire replace
setblock ~190 ~41 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~41 ~502 ~197 ~41 ~502 minecraft:redstone_wire replace
setblock ~199 ~41 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~41 ~502 ~207 ~41 ~502 minecraft:redstone_wire replace
setblock ~214 ~41 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~213 ~41 ~506 ~221 ~41 ~506 minecraft:redstone_wire replace
setblock ~223 ~41 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~41 ~506 ~231 ~41 ~506 minecraft:redstone_wire replace
setblock ~244 ~41 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~41 ~510 ~246 ~41 ~510 minecraft:redstone_wire replace
setblock ~248 ~41 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~41 ~510 ~263 ~41 ~510 minecraft:redstone_wire replace
setblock ~265 ~41 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~41 ~510 ~273 ~41 ~510 minecraft:redstone_wire replace
setblock ~271 ~41 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~41 ~514 ~273 ~41 ~514 minecraft:redstone_wire replace
setblock ~275 ~41 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~41 ~514 ~290 ~41 ~514 minecraft:redstone_wire replace
setblock ~292 ~41 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~41 ~514 ~300 ~41 ~514 minecraft:redstone_wire replace
setblock ~331 ~41 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~41 ~518 ~333 ~41 ~518 minecraft:redstone_wire replace
setblock ~335 ~41 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~41 ~518 ~350 ~41 ~518 minecraft:redstone_wire replace
setblock ~352 ~41 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~41 ~518 ~360 ~41 ~518 minecraft:redstone_wire replace
setblock ~358 ~41 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~357 ~41 ~522 ~360 ~41 ~522 minecraft:redstone_wire replace
setblock ~362 ~41 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~364 ~41 ~522 ~377 ~41 ~522 minecraft:redstone_wire replace
setblock ~379 ~41 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~381 ~41 ~522 ~387 ~41 ~522 minecraft:redstone_wire replace
setblock ~82 ~41 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~41 ~526 ~83 ~41 ~526 minecraft:redstone_wire replace
setblock ~109 ~41 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~41 ~530 ~110 ~41 ~530 minecraft:redstone_wire replace
setblock ~133 ~41 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~41 ~534 ~135 ~41 ~534 minecraft:redstone_wire replace
setblock ~157 ~41 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~41 ~538 ~157 ~41 ~538 minecraft:redstone_wire replace
setblock ~158 ~41 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~41 ~538 ~165 ~41 ~538 minecraft:redstone_wire replace
setblock ~187 ~41 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~41 ~542 ~194 ~41 ~542 minecraft:redstone_wire replace
setblock ~196 ~41 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~41 ~542 ~204 ~41 ~542 minecraft:redstone_wire replace
setblock ~211 ~41 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~41 ~546 ~218 ~41 ~546 minecraft:redstone_wire replace
setblock ~220 ~41 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~41 ~546 ~228 ~41 ~546 minecraft:redstone_wire replace
setblock ~241 ~41 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~240 ~41 ~550 ~243 ~41 ~550 minecraft:redstone_wire replace
setblock ~245 ~41 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~41 ~550 ~260 ~41 ~550 minecraft:redstone_wire replace
setblock ~262 ~41 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~41 ~550 ~270 ~41 ~550 minecraft:redstone_wire replace
