fill ~279 ~17 ~70 ~284 ~17 ~70 minecraft:redstone_wire replace
setblock ~256 ~17 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~268 ~17 ~71 minecraft:redstone_wire replace
setblock ~277 ~17 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~280 ~17 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~283 ~17 ~71 minecraft:redstone_wire replace
fill ~77 ~17 ~74 ~89 ~17 ~74 minecraft:redstone_wire replace
setblock ~91 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~74 ~105 ~17 ~74 minecraft:redstone_wire replace
setblock ~107 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~74 ~121 ~17 ~74 minecraft:redstone_wire replace
setblock ~123 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~74 ~137 ~17 ~74 minecraft:redstone_wire replace
setblock ~139 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~74 ~153 ~17 ~74 minecraft:redstone_wire replace
setblock ~155 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~74 ~169 ~17 ~74 minecraft:redstone_wire replace
setblock ~171 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~74 ~185 ~17 ~74 minecraft:redstone_wire replace
setblock ~187 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~74 ~201 ~17 ~74 minecraft:redstone_wire replace
setblock ~203 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~74 ~217 ~17 ~74 minecraft:redstone_wire replace
setblock ~219 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~74 ~233 ~17 ~74 minecraft:redstone_wire replace
setblock ~234 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~17 ~74 ~247 ~17 ~74 minecraft:redstone_wire replace
setblock ~248 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~17 ~74 ~262 ~17 ~74 minecraft:redstone_wire replace
setblock ~263 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~235 ~17 ~75 minecraft:redstone_wire replace
setblock ~241 ~17 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~244 ~17 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~17 ~75 minecraft:redstone_wire replace
setblock ~262 ~17 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~78 ~89 ~17 ~78 minecraft:redstone_wire replace
setblock ~91 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~78 ~105 ~17 ~78 minecraft:redstone_wire replace
setblock ~107 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~78 ~121 ~17 ~78 minecraft:redstone_wire replace
setblock ~123 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~78 ~137 ~17 ~78 minecraft:redstone_wire replace
setblock ~139 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~78 ~153 ~17 ~78 minecraft:redstone_wire replace
setblock ~155 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~78 ~169 ~17 ~78 minecraft:redstone_wire replace
setblock ~171 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~78 ~185 ~17 ~78 minecraft:redstone_wire replace
setblock ~187 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~78 ~201 ~17 ~78 minecraft:redstone_wire replace
setblock ~203 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~78 ~217 ~17 ~78 minecraft:redstone_wire replace
setblock ~219 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~78 ~233 ~17 ~78 minecraft:redstone_wire replace
setblock ~235 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~17 ~78 ~249 ~17 ~78 minecraft:redstone_wire replace
setblock ~251 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~17 ~78 ~265 ~17 ~78 minecraft:redstone_wire replace
setblock ~267 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~17 ~78 ~281 ~17 ~78 minecraft:redstone_wire replace
setblock ~283 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~17 ~78 ~298 ~17 ~78 minecraft:redstone_wire replace
setblock ~299 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~274 ~17 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~289 ~17 ~79 minecraft:redstone_wire replace
setblock ~292 ~17 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~295 ~17 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~298 ~17 ~79 minecraft:redstone_wire replace
fill ~78 ~17 ~82 ~90 ~17 ~82 minecraft:redstone_wire replace
setblock ~92 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~82 ~107 ~17 ~82 minecraft:redstone_wire replace
setblock ~109 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~82 ~124 ~17 ~82 minecraft:redstone_wire replace
setblock ~126 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~82 ~141 ~17 ~82 minecraft:redstone_wire replace
setblock ~143 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~82 ~158 ~17 ~82 minecraft:redstone_wire replace
setblock ~160 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~82 ~175 ~17 ~82 minecraft:redstone_wire replace
setblock ~177 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~82 ~192 ~17 ~82 minecraft:redstone_wire replace
setblock ~194 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~82 ~209 ~17 ~82 minecraft:redstone_wire replace
setblock ~211 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~82 ~226 ~17 ~82 minecraft:redstone_wire replace
setblock ~228 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~82 ~243 ~17 ~82 minecraft:redstone_wire replace
setblock ~245 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~82 ~260 ~17 ~82 minecraft:redstone_wire replace
setblock ~262 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~82 ~277 ~17 ~82 minecraft:redstone_wire replace
setblock ~279 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~82 ~294 ~17 ~82 minecraft:redstone_wire replace
setblock ~296 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~82 ~302 ~17 ~82 minecraft:redstone_wire replace
setblock ~301 ~17 ~83 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~17 ~86 ~90 ~17 ~86 minecraft:redstone_wire replace
setblock ~92 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~86 ~107 ~17 ~86 minecraft:redstone_wire replace
setblock ~109 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~86 ~124 ~17 ~86 minecraft:redstone_wire replace
setblock ~126 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~86 ~141 ~17 ~86 minecraft:redstone_wire replace
setblock ~143 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~86 ~158 ~17 ~86 minecraft:redstone_wire replace
setblock ~160 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~86 ~175 ~17 ~86 minecraft:redstone_wire replace
setblock ~177 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~86 ~192 ~17 ~86 minecraft:redstone_wire replace
setblock ~194 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~86 ~209 ~17 ~86 minecraft:redstone_wire replace
setblock ~211 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~86 ~226 ~17 ~86 minecraft:redstone_wire replace
setblock ~228 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~86 ~243 ~17 ~86 minecraft:redstone_wire replace
setblock ~245 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~86 ~260 ~17 ~86 minecraft:redstone_wire replace
setblock ~262 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~86 ~277 ~17 ~86 minecraft:redstone_wire replace
setblock ~279 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~86 ~294 ~17 ~86 minecraft:redstone_wire replace
setblock ~296 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~86 ~302 ~17 ~86 minecraft:redstone_wire replace
setblock ~301 ~17 ~87 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~63 ~17 ~90 ~63 ~17 ~100 minecraft:redstone_wire replace
fill ~78 ~17 ~90 ~90 ~17 ~90 minecraft:redstone_wire replace
setblock ~92 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~90 ~107 ~17 ~90 minecraft:redstone_wire replace
setblock ~109 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~90 ~124 ~17 ~90 minecraft:redstone_wire replace
setblock ~126 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~90 ~141 ~17 ~90 minecraft:redstone_wire replace
setblock ~143 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~90 ~158 ~17 ~90 minecraft:redstone_wire replace
setblock ~160 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~90 ~175 ~17 ~90 minecraft:redstone_wire replace
setblock ~177 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~90 ~192 ~17 ~90 minecraft:redstone_wire replace
setblock ~194 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~90 ~209 ~17 ~90 minecraft:redstone_wire replace
setblock ~211 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~90 ~226 ~17 ~90 minecraft:redstone_wire replace
setblock ~228 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~90 ~243 ~17 ~90 minecraft:redstone_wire replace
setblock ~245 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~90 ~260 ~17 ~90 minecraft:redstone_wire replace
setblock ~262 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~90 ~277 ~17 ~90 minecraft:redstone_wire replace
setblock ~279 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~90 ~294 ~17 ~90 minecraft:redstone_wire replace
setblock ~296 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~90 ~302 ~17 ~90 minecraft:redstone_wire replace
setblock ~301 ~17 ~91 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~94 minecraft:redstone_wire replace
setblock ~66 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~94 minecraft:redstone_wire replace
setblock ~68 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~94 minecraft:redstone_wire replace
setblock ~70 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~94 ~75 ~17 ~94 minecraft:redstone_wire replace
setblock ~76 ~17 ~94 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~94 ~90 ~17 ~94 minecraft:redstone_wire replace
setblock ~92 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~94 ~107 ~17 ~94 minecraft:redstone_wire replace
setblock ~109 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~94 ~124 ~17 ~94 minecraft:redstone_wire replace
setblock ~126 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~94 ~141 ~17 ~94 minecraft:redstone_wire replace
setblock ~143 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~94 ~158 ~17 ~94 minecraft:redstone_wire replace
setblock ~160 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~94 ~175 ~17 ~94 minecraft:redstone_wire replace
setblock ~177 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~94 ~192 ~17 ~94 minecraft:redstone_wire replace
setblock ~194 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~94 ~209 ~17 ~94 minecraft:redstone_wire replace
setblock ~211 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~94 ~226 ~17 ~94 minecraft:redstone_wire replace
setblock ~228 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~94 ~243 ~17 ~94 minecraft:redstone_wire replace
setblock ~245 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~94 ~260 ~17 ~94 minecraft:redstone_wire replace
setblock ~262 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~94 ~277 ~17 ~94 minecraft:redstone_wire replace
setblock ~279 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~94 ~294 ~17 ~94 minecraft:redstone_wire replace
setblock ~296 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~94 ~302 ~17 ~94 minecraft:redstone_wire replace
setblock ~76 ~17 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~301 ~17 ~95 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~98 minecraft:redstone_wire replace
setblock ~66 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~98 minecraft:redstone_wire replace
setblock ~68 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~98 minecraft:redstone_wire replace
setblock ~70 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~98 ~75 ~17 ~98 minecraft:redstone_wire replace
setblock ~76 ~17 ~98 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~98 ~90 ~17 ~98 minecraft:redstone_wire replace
setblock ~92 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~98 ~107 ~17 ~98 minecraft:redstone_wire replace
setblock ~109 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~98 ~124 ~17 ~98 minecraft:redstone_wire replace
setblock ~126 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~98 ~141 ~17 ~98 minecraft:redstone_wire replace
setblock ~143 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~98 ~158 ~17 ~98 minecraft:redstone_wire replace
setblock ~160 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~98 ~175 ~17 ~98 minecraft:redstone_wire replace
setblock ~177 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~98 ~192 ~17 ~98 minecraft:redstone_wire replace
setblock ~194 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~98 ~209 ~17 ~98 minecraft:redstone_wire replace
setblock ~211 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~98 ~226 ~17 ~98 minecraft:redstone_wire replace
setblock ~228 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~98 ~243 ~17 ~98 minecraft:redstone_wire replace
setblock ~245 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~98 ~260 ~17 ~98 minecraft:redstone_wire replace
setblock ~262 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~98 ~277 ~17 ~98 minecraft:redstone_wire replace
setblock ~279 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~98 ~294 ~17 ~98 minecraft:redstone_wire replace
setblock ~296 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~98 ~302 ~17 ~98 minecraft:redstone_wire replace
setblock ~76 ~17 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~187 ~17 ~99 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~99 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~101 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~63 ~17 ~102 ~63 ~17 ~112 minecraft:redstone_wire replace
setblock ~65 ~17 ~102 minecraft:redstone_wire replace
setblock ~66 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~102 minecraft:redstone_wire replace
setblock ~68 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~102 minecraft:redstone_wire replace
setblock ~70 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~102 ~75 ~17 ~102 minecraft:redstone_wire replace
setblock ~76 ~17 ~102 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~102 ~90 ~17 ~102 minecraft:redstone_wire replace
setblock ~92 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~102 ~107 ~17 ~102 minecraft:redstone_wire replace
setblock ~109 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~102 ~124 ~17 ~102 minecraft:redstone_wire replace
setblock ~126 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~102 ~141 ~17 ~102 minecraft:redstone_wire replace
setblock ~143 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~102 ~158 ~17 ~102 minecraft:redstone_wire replace
setblock ~160 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~102 ~175 ~17 ~102 minecraft:redstone_wire replace
setblock ~176 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~102 ~190 ~17 ~102 minecraft:redstone_wire replace
setblock ~192 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~102 ~207 ~17 ~102 minecraft:redstone_wire replace
setblock ~209 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~102 ~224 ~17 ~102 minecraft:redstone_wire replace
setblock ~226 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~102 ~241 ~17 ~102 minecraft:redstone_wire replace
setblock ~243 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~102 ~258 ~17 ~102 minecraft:redstone_wire replace
setblock ~260 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~102 ~275 ~17 ~102 minecraft:redstone_wire replace
setblock ~277 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~102 ~292 ~17 ~102 minecraft:redstone_wire replace
setblock ~294 ~17 ~102 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~102 ~302 ~17 ~102 minecraft:redstone_wire replace
setblock ~76 ~17 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~103 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~103 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~106 minecraft:redstone_wire replace
setblock ~66 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~106 minecraft:redstone_wire replace
setblock ~68 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~106 minecraft:redstone_wire replace
setblock ~70 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~106 ~75 ~17 ~106 minecraft:redstone_wire replace
setblock ~76 ~17 ~106 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~106 ~90 ~17 ~106 minecraft:redstone_wire replace
setblock ~92 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~106 ~107 ~17 ~106 minecraft:redstone_wire replace
setblock ~109 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~106 ~124 ~17 ~106 minecraft:redstone_wire replace
setblock ~126 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~106 ~141 ~17 ~106 minecraft:redstone_wire replace
setblock ~143 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~106 ~158 ~17 ~106 minecraft:redstone_wire replace
setblock ~160 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~106 ~175 ~17 ~106 minecraft:redstone_wire replace
setblock ~176 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~106 ~190 ~17 ~106 minecraft:redstone_wire replace
setblock ~192 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~106 ~207 ~17 ~106 minecraft:redstone_wire replace
setblock ~209 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~106 ~224 ~17 ~106 minecraft:redstone_wire replace
setblock ~226 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~106 ~241 ~17 ~106 minecraft:redstone_wire replace
setblock ~243 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~106 ~258 ~17 ~106 minecraft:redstone_wire replace
setblock ~260 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~106 ~275 ~17 ~106 minecraft:redstone_wire replace
setblock ~277 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~106 ~292 ~17 ~106 minecraft:redstone_wire replace
setblock ~294 ~17 ~106 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~106 ~302 ~17 ~106 minecraft:redstone_wire replace
setblock ~76 ~17 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~17 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~110 minecraft:redstone_wire replace
setblock ~66 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~110 minecraft:redstone_wire replace
setblock ~68 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~110 minecraft:redstone_wire replace
setblock ~70 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~110 ~75 ~17 ~110 minecraft:redstone_wire replace
setblock ~76 ~17 ~110 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~110 ~90 ~17 ~110 minecraft:redstone_wire replace
setblock ~92 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~110 ~107 ~17 ~110 minecraft:redstone_wire replace
setblock ~109 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~110 ~124 ~17 ~110 minecraft:redstone_wire replace
setblock ~126 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~110 ~141 ~17 ~110 minecraft:redstone_wire replace
setblock ~143 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~110 ~158 ~17 ~110 minecraft:redstone_wire replace
setblock ~160 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~110 ~175 ~17 ~110 minecraft:redstone_wire replace
setblock ~177 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~110 ~192 ~17 ~110 minecraft:redstone_wire replace
setblock ~194 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~110 ~209 ~17 ~110 minecraft:redstone_wire replace
setblock ~211 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~110 ~226 ~17 ~110 minecraft:redstone_wire replace
setblock ~228 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~110 ~243 ~17 ~110 minecraft:redstone_wire replace
setblock ~245 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~110 ~260 ~17 ~110 minecraft:redstone_wire replace
setblock ~262 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~110 ~277 ~17 ~110 minecraft:redstone_wire replace
setblock ~279 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~110 ~294 ~17 ~110 minecraft:redstone_wire replace
setblock ~296 ~17 ~110 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~110 ~302 ~17 ~110 minecraft:redstone_wire replace
setblock ~76 ~17 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~181 ~17 ~111 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~111 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~113 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~63 ~17 ~114 ~63 ~17 ~123 minecraft:redstone_wire replace
setblock ~65 ~17 ~114 minecraft:redstone_wire replace
setblock ~66 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~114 minecraft:redstone_wire replace
setblock ~68 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~114 minecraft:redstone_wire replace
setblock ~70 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~114 ~75 ~17 ~114 minecraft:redstone_wire replace
setblock ~76 ~17 ~114 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~114 ~90 ~17 ~114 minecraft:redstone_wire replace
setblock ~92 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~114 ~107 ~17 ~114 minecraft:redstone_wire replace
setblock ~109 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~114 ~124 ~17 ~114 minecraft:redstone_wire replace
setblock ~126 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~114 ~141 ~17 ~114 minecraft:redstone_wire replace
setblock ~143 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~114 ~158 ~17 ~114 minecraft:redstone_wire replace
setblock ~160 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~114 ~175 ~17 ~114 minecraft:redstone_wire replace
setblock ~177 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~114 ~192 ~17 ~114 minecraft:redstone_wire replace
setblock ~194 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~114 ~209 ~17 ~114 minecraft:redstone_wire replace
setblock ~211 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~114 ~226 ~17 ~114 minecraft:redstone_wire replace
setblock ~228 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~114 ~243 ~17 ~114 minecraft:redstone_wire replace
setblock ~245 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~114 ~260 ~17 ~114 minecraft:redstone_wire replace
setblock ~262 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~114 ~277 ~17 ~114 minecraft:redstone_wire replace
setblock ~279 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~114 ~294 ~17 ~114 minecraft:redstone_wire replace
setblock ~296 ~17 ~114 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~114 ~302 ~17 ~114 minecraft:redstone_wire replace
setblock ~76 ~17 ~115 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~181 ~17 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~17 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~118 minecraft:redstone_wire replace
setblock ~66 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~118 minecraft:redstone_wire replace
setblock ~68 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~118 minecraft:redstone_wire replace
setblock ~70 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~118 ~75 ~17 ~118 minecraft:redstone_wire replace
setblock ~76 ~17 ~118 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~118 ~90 ~17 ~118 minecraft:redstone_wire replace
setblock ~92 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~118 ~107 ~17 ~118 minecraft:redstone_wire replace
setblock ~109 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~118 ~124 ~17 ~118 minecraft:redstone_wire replace
setblock ~126 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~118 ~141 ~17 ~118 minecraft:redstone_wire replace
setblock ~143 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~118 ~158 ~17 ~118 minecraft:redstone_wire replace
setblock ~160 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~118 ~175 ~17 ~118 minecraft:redstone_wire replace
setblock ~176 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~118 ~190 ~17 ~118 minecraft:redstone_wire replace
setblock ~192 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~118 ~207 ~17 ~118 minecraft:redstone_wire replace
setblock ~209 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~118 ~224 ~17 ~118 minecraft:redstone_wire replace
setblock ~226 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~118 ~241 ~17 ~118 minecraft:redstone_wire replace
setblock ~243 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~118 ~258 ~17 ~118 minecraft:redstone_wire replace
setblock ~260 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~118 ~275 ~17 ~118 minecraft:redstone_wire replace
setblock ~277 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~118 ~292 ~17 ~118 minecraft:redstone_wire replace
setblock ~294 ~17 ~118 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~118 ~302 ~17 ~118 minecraft:redstone_wire replace
setblock ~76 ~17 ~119 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~119 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~17 ~119 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~119 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~122 minecraft:redstone_wire replace
setblock ~66 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~122 minecraft:redstone_wire replace
setblock ~68 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~122 minecraft:redstone_wire replace
setblock ~70 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~122 ~75 ~17 ~122 minecraft:redstone_wire replace
setblock ~76 ~17 ~122 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~122 ~90 ~17 ~122 minecraft:redstone_wire replace
setblock ~92 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~122 ~107 ~17 ~122 minecraft:redstone_wire replace
setblock ~109 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~122 ~124 ~17 ~122 minecraft:redstone_wire replace
setblock ~126 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~122 ~141 ~17 ~122 minecraft:redstone_wire replace
setblock ~143 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~122 ~158 ~17 ~122 minecraft:redstone_wire replace
setblock ~160 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~122 ~175 ~17 ~122 minecraft:redstone_wire replace
setblock ~176 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~17 ~122 ~190 ~17 ~122 minecraft:redstone_wire replace
setblock ~192 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~17 ~122 ~207 ~17 ~122 minecraft:redstone_wire replace
setblock ~209 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~122 ~224 ~17 ~122 minecraft:redstone_wire replace
setblock ~226 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~122 ~241 ~17 ~122 minecraft:redstone_wire replace
setblock ~243 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~122 ~258 ~17 ~122 minecraft:redstone_wire replace
setblock ~260 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~262 ~17 ~122 ~275 ~17 ~122 minecraft:redstone_wire replace
setblock ~277 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~122 ~292 ~17 ~122 minecraft:redstone_wire replace
setblock ~294 ~17 ~122 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~17 ~122 ~302 ~17 ~122 minecraft:redstone_wire replace
setblock ~76 ~17 ~123 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~178 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~301 ~17 ~123 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~124 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~63 ~17 ~125 minecraft:redstone_wire replace
fill ~78 ~17 ~126 ~90 ~17 ~126 minecraft:redstone_wire replace
setblock ~92 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~126 ~107 ~17 ~126 minecraft:redstone_wire replace
setblock ~109 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~126 ~124 ~17 ~126 minecraft:redstone_wire replace
setblock ~126 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~126 ~141 ~17 ~126 minecraft:redstone_wire replace
setblock ~143 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~126 ~158 ~17 ~126 minecraft:redstone_wire replace
setblock ~160 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~126 ~175 ~17 ~126 minecraft:redstone_wire replace
setblock ~177 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~126 ~192 ~17 ~126 minecraft:redstone_wire replace
setblock ~194 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~126 ~209 ~17 ~126 minecraft:redstone_wire replace
setblock ~211 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~126 ~226 ~17 ~126 minecraft:redstone_wire replace
setblock ~227 ~17 ~126 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~126 ~230 ~17 ~126 minecraft:redstone_wire replace
setblock ~229 ~17 ~127 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~79 ~18 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~18 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~18 ~4 minecraft:redstone_wire replace
setblock ~88 ~18 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~18 ~4 minecraft:redstone_wire replace
setblock ~109 ~18 ~4 minecraft:redstone_wire replace
setblock ~94 ~18 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~18 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~18 ~8 minecraft:redstone_wire replace
setblock ~103 ~18 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~18 ~8 minecraft:redstone_wire replace
setblock ~115 ~18 ~8 minecraft:redstone_wire replace
setblock ~112 ~18 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~18 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~18 ~12 minecraft:redstone_wire replace
setblock ~124 ~18 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~18 ~12 minecraft:redstone_wire replace
setblock ~133 ~18 ~12 minecraft:redstone_wire replace
setblock ~136 ~18 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~18 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~18 ~16 minecraft:redstone_wire replace
setblock ~148 ~18 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~18 ~16 minecraft:redstone_wire replace
setblock ~154 ~18 ~16 minecraft:redstone_wire replace
setblock ~160 ~18 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~18 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~18 ~20 minecraft:redstone_wire replace
setblock ~169 ~18 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~18 ~20 minecraft:redstone_wire replace
setblock ~175 ~18 ~20 minecraft:redstone_wire replace
setblock ~184 ~18 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~18 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~18 ~24 minecraft:redstone_wire replace
setblock ~199 ~18 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~18 ~24 minecraft:redstone_wire replace
setblock ~205 ~18 ~24 minecraft:redstone_wire replace
setblock ~211 ~18 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~18 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~18 ~28 minecraft:redstone_wire replace
setblock ~223 ~18 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~18 ~28 minecraft:redstone_wire replace
setblock ~238 ~18 ~28 minecraft:redstone_wire replace
setblock ~250 ~18 ~32 minecraft:redstone_wire replace
setblock ~265 ~18 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~18 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~18 ~32 minecraft:redstone_wire replace
setblock ~280 ~18 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~18 ~32 minecraft:redstone_wire replace
setblock ~232 ~18 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~18 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~18 ~36 minecraft:redstone_wire replace
setblock ~244 ~18 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~18 ~36 minecraft:redstone_wire replace
setblock ~271 ~18 ~36 minecraft:redstone_wire replace
setblock ~259 ~18 ~40 minecraft:redstone_wire replace
setblock ~286 ~18 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~18 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~18 ~40 minecraft:redstone_wire replace
setblock ~295 ~18 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~18 ~40 minecraft:redstone_wire replace
setblock ~82 ~18 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~18 ~44 minecraft:redstone_wire replace
setblock ~88 ~18 ~44 minecraft:redstone_wire replace
setblock ~91 ~18 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~18 ~44 minecraft:redstone_wire replace
setblock ~97 ~18 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~18 ~48 minecraft:redstone_wire replace
setblock ~103 ~18 ~48 minecraft:redstone_wire replace
setblock ~106 ~18 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~18 ~48 minecraft:redstone_wire replace
setblock ~118 ~18 ~52 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~18 ~52 minecraft:redstone_wire replace
setblock ~124 ~18 ~52 minecraft:redstone_wire replace
setblock ~127 ~18 ~52 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~18 ~52 minecraft:redstone_wire replace
setblock ~139 ~18 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~18 ~56 minecraft:redstone_wire replace
setblock ~148 ~18 ~56 minecraft:redstone_wire replace
setblock ~151 ~18 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~18 ~56 minecraft:redstone_wire replace
setblock ~163 ~18 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~18 ~60 minecraft:redstone_wire replace
setblock ~169 ~18 ~60 minecraft:redstone_wire replace
setblock ~172 ~18 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~18 ~60 minecraft:redstone_wire replace
setblock ~193 ~18 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~18 ~64 minecraft:redstone_wire replace
setblock ~199 ~18 ~64 minecraft:redstone_wire replace
setblock ~202 ~18 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~18 ~64 minecraft:redstone_wire replace
setblock ~214 ~18 ~68 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~18 ~68 minecraft:redstone_wire replace
setblock ~223 ~18 ~68 minecraft:redstone_wire replace
setblock ~226 ~18 ~68 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~18 ~68 minecraft:redstone_wire replace
setblock ~256 ~18 ~72 minecraft:redstone_wire replace
setblock ~268 ~18 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~18 ~72 minecraft:redstone_wire replace
setblock ~280 ~18 ~72 minecraft:redstone_wire replace
setblock ~283 ~18 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~18 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~18 ~76 minecraft:redstone_wire replace
setblock ~244 ~18 ~76 minecraft:redstone_wire replace
setblock ~247 ~18 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~18 ~76 minecraft:redstone_wire replace
setblock ~274 ~18 ~80 minecraft:redstone_wire replace
setblock ~289 ~18 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~18 ~80 minecraft:redstone_wire replace
setblock ~295 ~18 ~80 minecraft:redstone_wire replace
setblock ~298 ~18 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~18 ~84 minecraft:redstone_wire replace
setblock ~301 ~18 ~88 minecraft:redstone_wire replace
setblock ~301 ~18 ~92 minecraft:redstone_wire replace
setblock ~301 ~18 ~96 minecraft:redstone_wire replace
setblock ~187 ~18 ~100 minecraft:redstone_wire replace
setblock ~301 ~18 ~100 minecraft:redstone_wire replace
setblock ~178 ~18 ~104 minecraft:redstone_wire replace
setblock ~301 ~18 ~104 minecraft:redstone_wire replace
setblock ~178 ~18 ~108 minecraft:redstone_wire replace
setblock ~187 ~18 ~108 minecraft:redstone_wire replace
setblock ~301 ~18 ~108 minecraft:redstone_wire replace
setblock ~181 ~18 ~112 minecraft:redstone_wire replace
setblock ~301 ~18 ~112 minecraft:redstone_wire replace
setblock ~181 ~18 ~116 minecraft:redstone_wire replace
setblock ~187 ~18 ~116 minecraft:redstone_wire replace
setblock ~301 ~18 ~116 minecraft:redstone_wire replace
setblock ~178 ~18 ~120 minecraft:redstone_wire replace
setblock ~181 ~18 ~120 minecraft:redstone_wire replace
setblock ~301 ~18 ~120 minecraft:redstone_wire replace
setblock ~178 ~18 ~124 minecraft:redstone_wire replace
setblock ~181 ~18 ~124 minecraft:redstone_wire replace
setblock ~187 ~18 ~124 minecraft:redstone_wire replace
setblock ~301 ~18 ~124 minecraft:redstone_wire replace
setblock ~229 ~18 ~128 minecraft:redstone_wire replace
fill ~78 ~19 ~4 ~78 ~19 ~8 minecraft:redstone_wire replace
fill ~81 ~19 ~4 ~81 ~19 ~16 minecraft:redstone_wire replace
fill ~84 ~19 ~4 ~84 ~19 ~16 minecraft:redstone_wire replace
fill ~87 ~19 ~4 ~87 ~19 ~16 minecraft:redstone_wire replace
fill ~90 ~19 ~4 ~90 ~19 ~16 minecraft:redstone_wire replace
fill ~108 ~19 ~4 ~108 ~19 ~10 minecraft:redstone_wire replace
fill ~93 ~19 ~8 ~93 ~19 ~14 minecraft:redstone_wire replace
fill ~96 ~19 ~8 ~96 ~19 ~20 minecraft:redstone_wire replace
fill ~99 ~19 ~8 ~99 ~19 ~20 minecraft:redstone_wire replace
fill ~102 ~19 ~8 ~102 ~19 ~20 minecraft:redstone_wire replace
fill ~105 ~19 ~8 ~105 ~19 ~20 minecraft:redstone_wire replace
fill ~114 ~19 ~8 ~114 ~19 ~18 minecraft:redstone_wire replace
setblock ~108 ~19 ~12 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~19 ~12 ~111 ~19 ~22 minecraft:redstone_wire replace
fill ~117 ~19 ~12 ~117 ~19 ~24 minecraft:redstone_wire replace
fill ~120 ~19 ~12 ~120 ~19 ~24 minecraft:redstone_wire replace
fill ~123 ~19 ~12 ~123 ~19 ~24 minecraft:redstone_wire replace
fill ~126 ~19 ~12 ~126 ~19 ~24 minecraft:redstone_wire replace
fill ~132 ~19 ~12 ~132 ~19 ~24 minecraft:redstone_wire replace
setblock ~93 ~19 ~16 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~19 ~16 ~135 ~19 ~28 minecraft:redstone_wire replace
fill ~138 ~19 ~16 ~138 ~19 ~28 minecraft:redstone_wire replace
fill ~144 ~19 ~16 ~144 ~19 ~28 minecraft:redstone_wire replace
fill ~147 ~19 ~16 ~147 ~19 ~28 minecraft:redstone_wire replace
fill ~150 ~19 ~16 ~150 ~19 ~28 minecraft:redstone_wire replace
fill ~153 ~19 ~16 ~153 ~19 ~28 minecraft:redstone_wire replace
setblock ~81 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~20 ~81 ~19 ~32 minecraft:redstone_wire replace
fill ~84 ~19 ~20 ~84 ~19 ~32 minecraft:redstone_wire replace
fill ~87 ~19 ~20 ~87 ~19 ~32 minecraft:redstone_wire replace
fill ~90 ~19 ~20 ~90 ~19 ~32 minecraft:redstone_wire replace
setblock ~114 ~19 ~20 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~19 ~20 ~159 ~19 ~32 minecraft:redstone_wire replace
fill ~162 ~19 ~20 ~162 ~19 ~32 minecraft:redstone_wire replace
fill ~165 ~19 ~20 ~165 ~19 ~32 minecraft:redstone_wire replace
fill ~168 ~19 ~20 ~168 ~19 ~32 minecraft:redstone_wire replace
fill ~171 ~19 ~20 ~171 ~19 ~32 minecraft:redstone_wire replace
fill ~174 ~19 ~20 ~174 ~19 ~32 minecraft:redstone_wire replace
setblock ~96 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~24 ~96 ~19 ~36 minecraft:redstone_wire replace
fill ~99 ~19 ~24 ~99 ~19 ~36 minecraft:redstone_wire replace
fill ~102 ~19 ~24 ~102 ~19 ~36 minecraft:redstone_wire replace
fill ~105 ~19 ~24 ~105 ~19 ~36 minecraft:redstone_wire replace
setblock ~111 ~19 ~24 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~19 ~24 ~183 ~19 ~36 minecraft:redstone_wire replace
fill ~192 ~19 ~24 ~192 ~19 ~36 minecraft:redstone_wire replace
fill ~195 ~19 ~24 ~195 ~19 ~36 minecraft:redstone_wire replace
fill ~198 ~19 ~24 ~198 ~19 ~36 minecraft:redstone_wire replace
fill ~201 ~19 ~24 ~201 ~19 ~36 minecraft:redstone_wire replace
fill ~204 ~19 ~24 ~204 ~19 ~36 minecraft:redstone_wire replace
setblock ~117 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~19 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~28 ~117 ~19 ~40 minecraft:redstone_wire replace
fill ~120 ~19 ~28 ~120 ~19 ~40 minecraft:redstone_wire replace
fill ~123 ~19 ~28 ~123 ~19 ~40 minecraft:redstone_wire replace
fill ~126 ~19 ~28 ~126 ~19 ~40 minecraft:redstone_wire replace
setblock ~132 ~19 ~28 minecraft:redstone_wire replace
fill ~210 ~19 ~28 ~210 ~19 ~40 minecraft:redstone_wire replace
fill ~213 ~19 ~28 ~213 ~19 ~40 minecraft:redstone_wire replace
fill ~216 ~19 ~28 ~216 ~19 ~40 minecraft:redstone_wire replace
fill ~222 ~19 ~28 ~222 ~19 ~40 minecraft:redstone_wire replace
fill ~225 ~19 ~28 ~225 ~19 ~40 minecraft:redstone_wire replace
fill ~237 ~19 ~28 ~237 ~19 ~40 minecraft:redstone_wire replace
setblock ~135 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~19 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~19 ~32 minecraft:redstone_wire replace
fill ~138 ~19 ~32 ~138 ~19 ~44 minecraft:redstone_wire replace
fill ~144 ~19 ~32 ~144 ~19 ~44 minecraft:redstone_wire replace
fill ~147 ~19 ~32 ~147 ~19 ~44 minecraft:redstone_wire replace
fill ~150 ~19 ~32 ~150 ~19 ~44 minecraft:redstone_wire replace
fill ~153 ~19 ~32 ~153 ~19 ~36 minecraft:redstone_wire replace
fill ~249 ~19 ~32 ~249 ~19 ~44 minecraft:redstone_wire replace
fill ~264 ~19 ~32 ~264 ~19 ~44 minecraft:redstone_wire replace
fill ~267 ~19 ~32 ~267 ~19 ~44 minecraft:redstone_wire replace
fill ~276 ~19 ~32 ~276 ~19 ~44 minecraft:redstone_wire replace
fill ~279 ~19 ~32 ~279 ~19 ~44 minecraft:redstone_wire replace
fill ~282 ~19 ~32 ~282 ~19 ~44 minecraft:redstone_wire replace
setblock ~81 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~19 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~36 ~81 ~19 ~48 minecraft:redstone_wire replace
fill ~84 ~19 ~36 ~84 ~19 ~48 minecraft:redstone_wire replace
fill ~87 ~19 ~36 ~87 ~19 ~48 minecraft:redstone_wire replace
fill ~90 ~19 ~36 ~90 ~19 ~48 minecraft:redstone_wire replace
fill ~159 ~19 ~36 ~159 ~19 ~40 minecraft:redstone_wire replace
fill ~162 ~19 ~36 ~162 ~19 ~48 minecraft:redstone_wire replace
fill ~165 ~19 ~36 ~165 ~19 ~48 minecraft:redstone_wire replace
fill ~168 ~19 ~36 ~168 ~19 ~48 minecraft:redstone_wire replace
fill ~171 ~19 ~36 ~171 ~19 ~48 minecraft:redstone_wire replace
fill ~174 ~19 ~36 ~174 ~19 ~42 minecraft:redstone_wire replace
fill ~231 ~19 ~36 ~231 ~19 ~48 minecraft:redstone_wire replace
fill ~234 ~19 ~36 ~234 ~19 ~48 minecraft:redstone_wire replace
fill ~240 ~19 ~36 ~240 ~19 ~48 minecraft:redstone_wire replace
fill ~243 ~19 ~36 ~243 ~19 ~48 minecraft:redstone_wire replace
fill ~246 ~19 ~36 ~246 ~19 ~48 minecraft:redstone_wire replace
fill ~270 ~19 ~36 ~270 ~19 ~48 minecraft:redstone_wire replace
setblock ~96 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~19 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~40 ~96 ~19 ~52 minecraft:redstone_wire replace
fill ~99 ~19 ~40 ~99 ~19 ~52 minecraft:redstone_wire replace
fill ~102 ~19 ~40 ~102 ~19 ~52 minecraft:redstone_wire replace
fill ~105 ~19 ~40 ~105 ~19 ~52 minecraft:redstone_wire replace
fill ~183 ~19 ~40 ~183 ~19 ~46 minecraft:redstone_wire replace
fill ~192 ~19 ~40 ~192 ~19 ~52 minecraft:redstone_wire replace
fill ~195 ~19 ~40 ~195 ~19 ~52 minecraft:redstone_wire replace
fill ~198 ~19 ~40 ~198 ~19 ~52 minecraft:redstone_wire replace
fill ~201 ~19 ~40 ~201 ~19 ~52 minecraft:redstone_wire replace
fill ~204 ~19 ~40 ~204 ~19 ~50 minecraft:redstone_wire replace
fill ~258 ~19 ~40 ~258 ~19 ~52 minecraft:redstone_wire replace
fill ~285 ~19 ~40 ~285 ~19 ~52 minecraft:redstone_wire replace
fill ~288 ~19 ~40 ~288 ~19 ~52 minecraft:redstone_wire replace
fill ~291 ~19 ~40 ~291 ~19 ~52 minecraft:redstone_wire replace
fill ~294 ~19 ~40 ~294 ~19 ~52 minecraft:redstone_wire replace
fill ~297 ~19 ~40 ~297 ~19 ~52 minecraft:redstone_wire replace
setblock ~117 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~19 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~44 ~117 ~19 ~56 minecraft:redstone_wire replace
fill ~120 ~19 ~44 ~120 ~19 ~56 minecraft:redstone_wire replace
fill ~123 ~19 ~44 ~123 ~19 ~56 minecraft:redstone_wire replace
fill ~126 ~19 ~44 ~126 ~19 ~56 minecraft:redstone_wire replace
fill ~129 ~19 ~44 ~129 ~19 ~56 minecraft:redstone_wire replace
setblock ~174 ~19 ~44 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~19 ~44 ~210 ~19 ~54 minecraft:redstone_wire replace
fill ~213 ~19 ~44 ~213 ~19 ~56 minecraft:redstone_wire replace
fill ~216 ~19 ~44 ~216 ~19 ~56 minecraft:redstone_wire replace
fill ~222 ~19 ~44 ~222 ~19 ~56 minecraft:redstone_wire replace
fill ~225 ~19 ~44 ~225 ~19 ~56 minecraft:redstone_wire replace
fill ~237 ~19 ~44 ~237 ~19 ~56 minecraft:redstone_wire replace
setblock ~138 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~48 ~138 ~19 ~60 minecraft:redstone_wire replace
fill ~141 ~19 ~48 ~141 ~19 ~60 minecraft:redstone_wire replace
fill ~144 ~19 ~48 ~144 ~19 ~60 minecraft:redstone_wire replace
fill ~147 ~19 ~48 ~147 ~19 ~60 minecraft:redstone_wire replace
fill ~150 ~19 ~48 ~150 ~19 ~60 minecraft:redstone_wire replace
setblock ~183 ~19 ~48 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~19 ~48 ~249 ~19 ~60 minecraft:redstone_wire replace
fill ~264 ~19 ~48 ~264 ~19 ~60 minecraft:redstone_wire replace
fill ~267 ~19 ~48 ~267 ~19 ~60 minecraft:redstone_wire replace
fill ~276 ~19 ~48 ~276 ~19 ~60 minecraft:redstone_wire replace
fill ~279 ~19 ~48 ~279 ~19 ~60 minecraft:redstone_wire replace
fill ~282 ~19 ~48 ~282 ~19 ~60 minecraft:redstone_wire replace
setblock ~81 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~19 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~52 ~81 ~19 ~64 minecraft:redstone_wire replace
fill ~84 ~19 ~52 ~84 ~19 ~64 minecraft:redstone_wire replace
fill ~87 ~19 ~52 ~87 ~19 ~64 minecraft:redstone_wire replace
fill ~90 ~19 ~52 ~90 ~19 ~64 minecraft:redstone_wire replace
fill ~156 ~19 ~52 ~156 ~19 ~64 minecraft:redstone_wire replace
fill ~162 ~19 ~52 ~162 ~19 ~64 minecraft:redstone_wire replace
fill ~165 ~19 ~52 ~165 ~19 ~64 minecraft:redstone_wire replace
fill ~168 ~19 ~52 ~168 ~19 ~64 minecraft:redstone_wire replace
fill ~171 ~19 ~52 ~171 ~19 ~64 minecraft:redstone_wire replace
setblock ~204 ~19 ~52 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~19 ~52 ~231 ~19 ~64 minecraft:redstone_wire replace
fill ~234 ~19 ~52 ~234 ~19 ~64 minecraft:redstone_wire replace
fill ~240 ~19 ~52 ~240 ~19 ~64 minecraft:redstone_wire replace
fill ~243 ~19 ~52 ~243 ~19 ~64 minecraft:redstone_wire replace
fill ~246 ~19 ~52 ~246 ~19 ~64 minecraft:redstone_wire replace
fill ~270 ~19 ~52 ~270 ~19 ~64 minecraft:redstone_wire replace
setblock ~96 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~56 ~96 ~19 ~68 minecraft:redstone_wire replace
fill ~99 ~19 ~56 ~99 ~19 ~68 minecraft:redstone_wire replace
fill ~102 ~19 ~56 ~102 ~19 ~68 minecraft:redstone_wire replace
fill ~105 ~19 ~56 ~105 ~19 ~68 minecraft:redstone_wire replace
fill ~189 ~19 ~56 ~189 ~19 ~68 minecraft:redstone_wire replace
fill ~192 ~19 ~56 ~192 ~19 ~68 minecraft:redstone_wire replace
fill ~195 ~19 ~56 ~195 ~19 ~68 minecraft:redstone_wire replace
fill ~198 ~19 ~56 ~198 ~19 ~68 minecraft:redstone_wire replace
fill ~201 ~19 ~56 ~201 ~19 ~68 minecraft:redstone_wire replace
setblock ~210 ~19 ~56 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~19 ~56 ~258 ~19 ~68 minecraft:redstone_wire replace
fill ~285 ~19 ~56 ~285 ~19 ~68 minecraft:redstone_wire replace
fill ~288 ~19 ~56 ~288 ~19 ~68 minecraft:redstone_wire replace
fill ~291 ~19 ~56 ~291 ~19 ~68 minecraft:redstone_wire replace
fill ~294 ~19 ~56 ~294 ~19 ~68 minecraft:redstone_wire replace
fill ~297 ~19 ~56 ~297 ~19 ~68 minecraft:redstone_wire replace
setblock ~117 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~19 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~60 ~117 ~19 ~72 minecraft:redstone_wire replace
fill ~120 ~19 ~60 ~120 ~19 ~72 minecraft:redstone_wire replace
fill ~123 ~19 ~60 ~123 ~19 ~72 minecraft:redstone_wire replace
fill ~126 ~19 ~60 ~126 ~19 ~72 minecraft:redstone_wire replace
fill ~129 ~19 ~60 ~129 ~19 ~72 minecraft:redstone_wire replace
fill ~207 ~19 ~60 ~207 ~19 ~72 minecraft:redstone_wire replace
fill ~213 ~19 ~60 ~213 ~19 ~72 minecraft:redstone_wire replace
fill ~216 ~19 ~60 ~216 ~19 ~72 minecraft:redstone_wire replace
fill ~222 ~19 ~60 ~222 ~19 ~72 minecraft:redstone_wire replace
fill ~225 ~19 ~60 ~225 ~19 ~72 minecraft:redstone_wire replace
setblock ~237 ~19 ~60 minecraft:redstone_wire replace
setblock ~138 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~64 ~138 ~19 ~76 minecraft:redstone_wire replace
fill ~141 ~19 ~64 ~141 ~19 ~76 minecraft:redstone_wire replace
fill ~144 ~19 ~64 ~144 ~19 ~76 minecraft:redstone_wire replace
fill ~147 ~19 ~64 ~147 ~19 ~76 minecraft:redstone_wire replace
fill ~150 ~19 ~64 ~150 ~19 ~76 minecraft:redstone_wire replace
fill ~219 ~19 ~64 ~219 ~19 ~76 minecraft:redstone_wire replace
setblock ~249 ~19 ~64 minecraft:redstone_wire replace
fill ~264 ~19 ~64 ~264 ~19 ~68 minecraft:redstone_wire replace
fill ~267 ~19 ~64 ~267 ~19 ~76 minecraft:redstone_wire replace
fill ~276 ~19 ~64 ~276 ~19 ~76 minecraft:redstone_wire replace
fill ~279 ~19 ~64 ~279 ~19 ~76 minecraft:redstone_wire replace
fill ~282 ~19 ~64 ~282 ~19 ~76 minecraft:redstone_wire replace
setblock ~81 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~19 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~68 ~81 ~19 ~80 minecraft:redstone_wire replace
fill ~84 ~19 ~68 ~84 ~19 ~80 minecraft:redstone_wire replace
fill ~87 ~19 ~68 ~87 ~19 ~80 minecraft:redstone_wire replace
fill ~90 ~19 ~68 ~90 ~19 ~80 minecraft:redstone_wire replace
fill ~156 ~19 ~68 ~156 ~19 ~80 minecraft:redstone_wire replace
fill ~162 ~19 ~68 ~162 ~19 ~80 minecraft:redstone_wire replace
fill ~165 ~19 ~68 ~165 ~19 ~80 minecraft:redstone_wire replace
fill ~168 ~19 ~68 ~168 ~19 ~80 minecraft:redstone_wire replace
fill ~171 ~19 ~68 ~171 ~19 ~80 minecraft:redstone_wire replace
fill ~231 ~19 ~68 ~231 ~19 ~72 minecraft:redstone_wire replace
fill ~234 ~19 ~68 ~234 ~19 ~80 minecraft:redstone_wire replace
fill ~240 ~19 ~68 ~240 ~19 ~80 minecraft:redstone_wire replace
fill ~243 ~19 ~68 ~243 ~19 ~80 minecraft:redstone_wire replace
fill ~246 ~19 ~68 ~246 ~19 ~80 minecraft:redstone_wire replace
fill ~252 ~19 ~68 ~252 ~19 ~80 minecraft:redstone_wire replace
fill ~270 ~19 ~68 ~270 ~19 ~74 minecraft:redstone_wire replace
setblock ~96 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~72 ~96 ~19 ~84 minecraft:redstone_wire replace
fill ~99 ~19 ~72 ~99 ~19 ~84 minecraft:redstone_wire replace
fill ~102 ~19 ~72 ~102 ~19 ~84 minecraft:redstone_wire replace
fill ~105 ~19 ~72 ~105 ~19 ~84 minecraft:redstone_wire replace
fill ~189 ~19 ~72 ~189 ~19 ~84 minecraft:redstone_wire replace
fill ~192 ~19 ~72 ~192 ~19 ~84 minecraft:redstone_wire replace
fill ~195 ~19 ~72 ~195 ~19 ~84 minecraft:redstone_wire replace
fill ~198 ~19 ~72 ~198 ~19 ~84 minecraft:redstone_wire replace
fill ~201 ~19 ~72 ~201 ~19 ~84 minecraft:redstone_wire replace
fill ~255 ~19 ~72 ~255 ~19 ~84 minecraft:redstone_wire replace
fill ~258 ~19 ~72 ~258 ~19 ~78 minecraft:redstone_wire replace
fill ~285 ~19 ~72 ~285 ~19 ~82 minecraft:redstone_wire replace
fill ~288 ~19 ~72 ~288 ~19 ~84 minecraft:redstone_wire replace
fill ~291 ~19 ~72 ~291 ~19 ~84 minecraft:redstone_wire replace
fill ~294 ~19 ~72 ~294 ~19 ~84 minecraft:redstone_wire replace
fill ~297 ~19 ~72 ~297 ~19 ~84 minecraft:redstone_wire replace
setblock ~117 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~76 ~117 ~19 ~88 minecraft:redstone_wire replace
fill ~120 ~19 ~76 ~120 ~19 ~88 minecraft:redstone_wire replace
fill ~123 ~19 ~76 ~123 ~19 ~88 minecraft:redstone_wire replace
fill ~126 ~19 ~76 ~126 ~19 ~88 minecraft:redstone_wire replace
fill ~129 ~19 ~76 ~129 ~19 ~88 minecraft:redstone_wire replace
fill ~207 ~19 ~76 ~207 ~19 ~88 minecraft:redstone_wire replace
fill ~213 ~19 ~76 ~213 ~19 ~88 minecraft:redstone_wire replace
fill ~216 ~19 ~76 ~216 ~19 ~88 minecraft:redstone_wire replace
fill ~222 ~19 ~76 ~222 ~19 ~88 minecraft:redstone_wire replace
fill ~225 ~19 ~76 ~225 ~19 ~88 minecraft:redstone_wire replace
fill ~261 ~19 ~76 ~261 ~19 ~88 minecraft:redstone_wire replace
setblock ~270 ~19 ~76 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~80 ~138 ~19 ~92 minecraft:redstone_wire replace
fill ~141 ~19 ~80 ~141 ~19 ~92 minecraft:redstone_wire replace
fill ~144 ~19 ~80 ~144 ~19 ~92 minecraft:redstone_wire replace
fill ~147 ~19 ~80 ~147 ~19 ~92 minecraft:redstone_wire replace
fill ~150 ~19 ~80 ~150 ~19 ~92 minecraft:redstone_wire replace
fill ~219 ~19 ~80 ~219 ~19 ~92 minecraft:redstone_wire replace
setblock ~258 ~19 ~80 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~19 ~80 ~267 ~19 ~92 minecraft:redstone_wire replace
fill ~273 ~19 ~80 ~273 ~19 ~92 minecraft:redstone_wire replace
fill ~276 ~19 ~80 ~276 ~19 ~92 minecraft:redstone_wire replace
fill ~279 ~19 ~80 ~279 ~19 ~92 minecraft:redstone_wire replace
fill ~282 ~19 ~80 ~282 ~19 ~92 minecraft:redstone_wire replace
setblock ~81 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~19 ~84 ~81 ~19 ~88 minecraft:redstone_wire replace
fill ~84 ~19 ~84 ~84 ~19 ~90 minecraft:redstone_wire replace
fill ~87 ~19 ~84 ~87 ~19 ~94 minecraft:redstone_wire replace
fill ~90 ~19 ~84 ~90 ~19 ~96 minecraft:redstone_wire replace
fill ~156 ~19 ~84 ~156 ~19 ~96 minecraft:redstone_wire replace
fill ~162 ~19 ~84 ~162 ~19 ~96 minecraft:redstone_wire replace
fill ~165 ~19 ~84 ~165 ~19 ~96 minecraft:redstone_wire replace
fill ~168 ~19 ~84 ~168 ~19 ~96 minecraft:redstone_wire replace
fill ~171 ~19 ~84 ~171 ~19 ~96 minecraft:redstone_wire replace
fill ~234 ~19 ~84 ~234 ~19 ~96 minecraft:redstone_wire replace
fill ~240 ~19 ~84 ~240 ~19 ~96 minecraft:redstone_wire replace
fill ~243 ~19 ~84 ~243 ~19 ~96 minecraft:redstone_wire replace
fill ~246 ~19 ~84 ~246 ~19 ~96 minecraft:redstone_wire replace
fill ~252 ~19 ~84 ~252 ~19 ~96 minecraft:redstone_wire replace
setblock ~285 ~19 ~84 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~84 ~300 ~19 ~96 minecraft:redstone_wire replace
setblock ~96 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~88 ~96 ~19 ~100 minecraft:redstone_wire replace
fill ~99 ~19 ~88 ~99 ~19 ~100 minecraft:redstone_wire replace
fill ~102 ~19 ~88 ~102 ~19 ~100 minecraft:redstone_wire replace
fill ~105 ~19 ~88 ~105 ~19 ~100 minecraft:redstone_wire replace
fill ~189 ~19 ~88 ~189 ~19 ~100 minecraft:redstone_wire replace
fill ~192 ~19 ~88 ~192 ~19 ~100 minecraft:redstone_wire replace
fill ~195 ~19 ~88 ~195 ~19 ~100 minecraft:redstone_wire replace
fill ~198 ~19 ~88 ~198 ~19 ~100 minecraft:redstone_wire replace
fill ~201 ~19 ~88 ~201 ~19 ~100 minecraft:redstone_wire replace
fill ~255 ~19 ~88 ~255 ~19 ~100 minecraft:redstone_wire replace
fill ~288 ~19 ~88 ~288 ~19 ~100 minecraft:redstone_wire replace
fill ~291 ~19 ~88 ~291 ~19 ~100 minecraft:redstone_wire replace
fill ~294 ~19 ~88 ~294 ~19 ~100 minecraft:redstone_wire replace
fill ~297 ~19 ~88 ~297 ~19 ~100 minecraft:redstone_wire replace
setblock ~117 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~19 ~92 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~92 ~117 ~19 ~104 minecraft:redstone_wire replace
fill ~120 ~19 ~92 ~120 ~19 ~104 minecraft:redstone_wire replace
fill ~123 ~19 ~92 ~123 ~19 ~104 minecraft:redstone_wire replace
fill ~126 ~19 ~92 ~126 ~19 ~104 minecraft:redstone_wire replace
fill ~129 ~19 ~92 ~129 ~19 ~102 minecraft:redstone_wire replace
fill ~207 ~19 ~92 ~207 ~19 ~104 minecraft:redstone_wire replace
fill ~213 ~19 ~92 ~213 ~19 ~104 minecraft:redstone_wire replace
fill ~216 ~19 ~92 ~216 ~19 ~104 minecraft:redstone_wire replace
fill ~222 ~19 ~92 ~222 ~19 ~104 minecraft:redstone_wire replace
fill ~225 ~19 ~92 ~225 ~19 ~104 minecraft:redstone_wire replace
fill ~261 ~19 ~92 ~261 ~19 ~104 minecraft:redstone_wire replace
setblock ~138 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~19 ~96 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~96 ~138 ~19 ~108 minecraft:redstone_wire replace
fill ~141 ~19 ~96 ~141 ~19 ~108 minecraft:redstone_wire replace
fill ~144 ~19 ~96 ~144 ~19 ~108 minecraft:redstone_wire replace
fill ~147 ~19 ~96 ~147 ~19 ~108 minecraft:redstone_wire replace
fill ~150 ~19 ~96 ~150 ~19 ~108 minecraft:redstone_wire replace
fill ~219 ~19 ~96 ~219 ~19 ~108 minecraft:redstone_wire replace
fill ~267 ~19 ~96 ~267 ~19 ~108 minecraft:redstone_wire replace
fill ~273 ~19 ~96 ~273 ~19 ~108 minecraft:redstone_wire replace
fill ~276 ~19 ~96 ~276 ~19 ~108 minecraft:redstone_wire replace
fill ~279 ~19 ~96 ~279 ~19 ~108 minecraft:redstone_wire replace
fill ~282 ~19 ~96 ~282 ~19 ~108 minecraft:redstone_wire replace
setblock ~300 ~19 ~97 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~90 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~98 ~300 ~19 ~110 minecraft:redstone_wire replace
setblock ~90 ~19 ~100 minecraft:redstone_wire replace
fill ~156 ~19 ~100 ~156 ~19 ~112 minecraft:redstone_wire replace
fill ~162 ~19 ~100 ~162 ~19 ~112 minecraft:redstone_wire replace
fill ~165 ~19 ~100 ~165 ~19 ~112 minecraft:redstone_wire replace
fill ~168 ~19 ~100 ~168 ~19 ~112 minecraft:redstone_wire replace
fill ~171 ~19 ~100 ~171 ~19 ~112 minecraft:redstone_wire replace
fill ~186 ~19 ~100 ~186 ~19 ~112 minecraft:redstone_wire replace
fill ~234 ~19 ~100 ~234 ~19 ~112 minecraft:redstone_wire replace
fill ~240 ~19 ~100 ~240 ~19 ~112 minecraft:redstone_wire replace
fill ~243 ~19 ~100 ~243 ~19 ~112 minecraft:redstone_wire replace
fill ~246 ~19 ~100 ~246 ~19 ~112 minecraft:redstone_wire replace
fill ~252 ~19 ~100 ~252 ~19 ~112 minecraft:redstone_wire replace
setblock ~96 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~19 ~104 ~96 ~19 ~108 minecraft:redstone_wire replace
fill ~99 ~19 ~104 ~99 ~19 ~110 minecraft:redstone_wire replace
fill ~102 ~19 ~104 ~102 ~19 ~114 minecraft:redstone_wire replace
fill ~105 ~19 ~104 ~105 ~19 ~116 minecraft:redstone_wire replace
setblock ~129 ~19 ~104 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~104 ~177 ~19 ~116 minecraft:redstone_wire replace
fill ~189 ~19 ~104 ~189 ~19 ~116 minecraft:redstone_wire replace
fill ~192 ~19 ~104 ~192 ~19 ~116 minecraft:redstone_wire replace
fill ~195 ~19 ~104 ~195 ~19 ~116 minecraft:redstone_wire replace
fill ~198 ~19 ~104 ~198 ~19 ~116 minecraft:redstone_wire replace
fill ~201 ~19 ~104 ~201 ~19 ~116 minecraft:redstone_wire replace
fill ~255 ~19 ~104 ~255 ~19 ~116 minecraft:redstone_wire replace
fill ~288 ~19 ~104 ~288 ~19 ~116 minecraft:redstone_wire replace
fill ~291 ~19 ~104 ~291 ~19 ~116 minecraft:redstone_wire replace
fill ~294 ~19 ~104 ~294 ~19 ~116 minecraft:redstone_wire replace
fill ~297 ~19 ~104 ~297 ~19 ~116 minecraft:redstone_wire replace
setblock ~117 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~108 ~117 ~19 ~120 minecraft:redstone_wire replace
fill ~120 ~19 ~108 ~120 ~19 ~120 minecraft:redstone_wire replace
fill ~123 ~19 ~108 ~123 ~19 ~120 minecraft:redstone_wire replace
fill ~126 ~19 ~108 ~126 ~19 ~120 minecraft:redstone_wire replace
fill ~207 ~19 ~108 ~207 ~19 ~120 minecraft:redstone_wire replace
fill ~213 ~19 ~108 ~213 ~19 ~120 minecraft:redstone_wire replace
fill ~216 ~19 ~108 ~216 ~19 ~120 minecraft:redstone_wire replace
fill ~222 ~19 ~108 ~222 ~19 ~120 minecraft:redstone_wire replace
fill ~225 ~19 ~108 ~225 ~19 ~120 minecraft:redstone_wire replace
fill ~261 ~19 ~108 ~261 ~19 ~120 minecraft:redstone_wire replace
setblock ~138 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~111 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~19 ~112 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~19 ~112 ~138 ~19 ~124 minecraft:redstone_wire replace
fill ~141 ~19 ~112 ~141 ~19 ~122 minecraft:redstone_wire replace
fill ~144 ~19 ~112 ~144 ~19 ~124 minecraft:redstone_wire replace
fill ~147 ~19 ~112 ~147 ~19 ~124 minecraft:redstone_wire replace
fill ~150 ~19 ~112 ~150 ~19 ~124 minecraft:redstone_wire replace
fill ~180 ~19 ~112 ~180 ~19 ~124 minecraft:redstone_wire replace
fill ~219 ~19 ~112 ~219 ~19 ~124 minecraft:redstone_wire replace
fill ~267 ~19 ~112 ~267 ~19 ~124 minecraft:redstone_wire replace
fill ~273 ~19 ~112 ~273 ~19 ~124 minecraft:redstone_wire replace
fill ~276 ~19 ~112 ~276 ~19 ~124 minecraft:redstone_wire replace
fill ~279 ~19 ~112 ~279 ~19 ~124 minecraft:redstone_wire replace
fill ~282 ~19 ~112 ~282 ~19 ~124 minecraft:redstone_wire replace
fill ~300 ~19 ~112 ~300 ~19 ~124 minecraft:redstone_wire replace
setblock ~156 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~19 ~116 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~19 ~116 ~156 ~19 ~128 minecraft:redstone_wire replace
fill ~162 ~19 ~116 ~162 ~19 ~128 minecraft:redstone_wire replace
fill ~165 ~19 ~116 ~165 ~19 ~128 minecraft:redstone_wire replace
fill ~168 ~19 ~116 ~168 ~19 ~128 minecraft:redstone_wire replace
fill ~171 ~19 ~116 ~171 ~19 ~128 minecraft:redstone_wire replace
fill ~186 ~19 ~116 ~186 ~19 ~128 minecraft:redstone_wire replace
fill ~234 ~19 ~116 ~234 ~19 ~128 minecraft:redstone_wire replace
fill ~240 ~19 ~116 ~240 ~19 ~128 minecraft:redstone_wire replace
fill ~243 ~19 ~116 ~243 ~19 ~128 minecraft:redstone_wire replace
fill ~246 ~19 ~116 ~246 ~19 ~128 minecraft:redstone_wire replace
fill ~252 ~19 ~116 ~252 ~19 ~128 minecraft:redstone_wire replace
setblock ~105 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~19 ~120 minecraft:redstone_wire replace
fill ~177 ~19 ~120 ~177 ~19 ~132 minecraft:redstone_wire replace
fill ~189 ~19 ~120 ~189 ~19 ~132 minecraft:redstone_wire replace
fill ~192 ~19 ~120 ~192 ~19 ~132 minecraft:redstone_wire replace
fill ~195 ~19 ~120 ~195 ~19 ~132 minecraft:redstone_wire replace
fill ~198 ~19 ~120 ~198 ~19 ~132 minecraft:redstone_wire replace
fill ~201 ~19 ~120 ~201 ~19 ~132 minecraft:redstone_wire replace
fill ~255 ~19 ~120 ~255 ~19 ~132 minecraft:redstone_wire replace
fill ~288 ~19 ~120 ~288 ~19 ~132 minecraft:redstone_wire replace
fill ~291 ~19 ~120 ~291 ~19 ~132 minecraft:redstone_wire replace
fill ~294 ~19 ~120 ~294 ~19 ~132 minecraft:redstone_wire replace
fill ~297 ~19 ~120 ~297 ~19 ~132 minecraft:redstone_wire replace
setblock ~117 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~19 ~124 ~117 ~19 ~128 minecraft:redstone_wire replace
fill ~120 ~19 ~124 ~120 ~19 ~130 minecraft:redstone_wire replace
fill ~123 ~19 ~124 ~123 ~19 ~134 minecraft:redstone_wire replace
fill ~126 ~19 ~124 ~126 ~19 ~136 minecraft:redstone_wire replace
setblock ~141 ~19 ~124 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~124 ~207 ~19 ~136 minecraft:redstone_wire replace
fill ~213 ~19 ~124 ~213 ~19 ~136 minecraft:redstone_wire replace
fill ~216 ~19 ~124 ~216 ~19 ~136 minecraft:redstone_wire replace
fill ~222 ~19 ~124 ~222 ~19 ~136 minecraft:redstone_wire replace
fill ~225 ~19 ~124 ~225 ~19 ~136 minecraft:redstone_wire replace
fill ~261 ~19 ~124 ~261 ~19 ~136 minecraft:redstone_wire replace
setblock ~180 ~19 ~125 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~125 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~126 ~180 ~19 ~138 minecraft:redstone_wire replace
setblock ~219 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~126 ~300 ~19 ~138 minecraft:redstone_wire replace
fill ~138 ~19 ~128 ~138 ~19 ~140 minecraft:redstone_wire replace
fill ~144 ~19 ~128 ~144 ~19 ~140 minecraft:redstone_wire replace
fill ~147 ~19 ~128 ~147 ~19 ~140 minecraft:redstone_wire replace
fill ~150 ~19 ~128 ~150 ~19 ~140 minecraft:redstone_wire replace
fill ~219 ~19 ~128 ~219 ~19 ~140 minecraft:redstone_wire replace
fill ~228 ~19 ~128 ~228 ~19 ~140 minecraft:redstone_wire replace
fill ~267 ~19 ~128 ~267 ~19 ~140 minecraft:redstone_wire replace
fill ~273 ~19 ~128 ~273 ~19 ~140 minecraft:redstone_wire replace
fill ~276 ~19 ~128 ~276 ~19 ~140 minecraft:redstone_wire replace
fill ~279 ~19 ~128 ~279 ~19 ~140 minecraft:redstone_wire replace
fill ~282 ~19 ~128 ~282 ~19 ~140 minecraft:redstone_wire replace
setblock ~156 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~19 ~132 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~19 ~132 ~156 ~19 ~142 minecraft:redstone_wire replace
fill ~162 ~19 ~132 ~162 ~19 ~144 minecraft:redstone_wire replace
fill ~165 ~19 ~132 ~165 ~19 ~144 minecraft:redstone_wire replace
fill ~168 ~19 ~132 ~168 ~19 ~144 minecraft:redstone_wire replace
fill ~171 ~19 ~132 ~171 ~19 ~144 minecraft:redstone_wire replace
fill ~186 ~19 ~132 ~186 ~19 ~144 minecraft:redstone_wire replace
fill ~234 ~19 ~132 ~234 ~19 ~144 minecraft:redstone_wire replace
fill ~240 ~19 ~132 ~240 ~19 ~144 minecraft:redstone_wire replace
fill ~243 ~19 ~132 ~243 ~19 ~144 minecraft:redstone_wire replace
fill ~246 ~19 ~132 ~246 ~19 ~144 minecraft:redstone_wire replace
fill ~252 ~19 ~132 ~252 ~19 ~144 minecraft:redstone_wire replace
setblock ~177 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~19 ~136 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~136 ~177 ~19 ~148 minecraft:redstone_wire replace
fill ~189 ~19 ~136 ~189 ~19 ~148 minecraft:redstone_wire replace
fill ~192 ~19 ~136 ~192 ~19 ~148 minecraft:redstone_wire replace
fill ~195 ~19 ~136 ~195 ~19 ~148 minecraft:redstone_wire replace
fill ~198 ~19 ~136 ~198 ~19 ~148 minecraft:redstone_wire replace
fill ~201 ~19 ~136 ~201 ~19 ~148 minecraft:redstone_wire replace
fill ~255 ~19 ~136 ~255 ~19 ~148 minecraft:redstone_wire replace
fill ~288 ~19 ~136 ~288 ~19 ~148 minecraft:redstone_wire replace
fill ~291 ~19 ~136 ~291 ~19 ~148 minecraft:redstone_wire replace
fill ~294 ~19 ~136 ~294 ~19 ~148 minecraft:redstone_wire replace
fill ~297 ~19 ~136 ~297 ~19 ~148 minecraft:redstone_wire replace
setblock ~126 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~19 ~140 minecraft:redstone_wire replace
setblock ~180 ~19 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~140 ~207 ~19 ~152 minecraft:redstone_wire replace
fill ~213 ~19 ~140 ~213 ~19 ~152 minecraft:redstone_wire replace
fill ~216 ~19 ~140 ~216 ~19 ~152 minecraft:redstone_wire replace
fill ~222 ~19 ~140 ~222 ~19 ~152 minecraft:redstone_wire replace
fill ~225 ~19 ~140 ~225 ~19 ~152 minecraft:redstone_wire replace
fill ~261 ~19 ~140 ~261 ~19 ~152 minecraft:redstone_wire replace
setblock ~300 ~19 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~142 ~180 ~19 ~154 minecraft:redstone_wire replace
setblock ~219 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~142 ~300 ~19 ~154 minecraft:redstone_wire replace
fill ~138 ~19 ~144 ~138 ~19 ~148 minecraft:redstone_wire replace
fill ~144 ~19 ~144 ~144 ~19 ~150 minecraft:redstone_wire replace
fill ~147 ~19 ~144 ~147 ~19 ~154 minecraft:redstone_wire replace
fill ~150 ~19 ~144 ~150 ~19 ~156 minecraft:redstone_wire replace
setblock ~156 ~19 ~144 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~19 ~144 ~219 ~19 ~156 minecraft:redstone_wire replace
fill ~228 ~19 ~144 ~228 ~19 ~156 minecraft:redstone_wire replace
fill ~267 ~19 ~144 ~267 ~19 ~156 minecraft:redstone_wire replace
fill ~273 ~19 ~144 ~273 ~19 ~156 minecraft:redstone_wire replace
fill ~276 ~19 ~144 ~276 ~19 ~156 minecraft:redstone_wire replace
fill ~279 ~19 ~144 ~279 ~19 ~156 minecraft:redstone_wire replace
fill ~282 ~19 ~144 ~282 ~19 ~156 minecraft:redstone_wire replace
setblock ~162 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~146 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~19 ~148 ~162 ~19 ~160 minecraft:redstone_wire replace
fill ~165 ~19 ~148 ~165 ~19 ~160 minecraft:redstone_wire replace
fill ~168 ~19 ~148 ~168 ~19 ~160 minecraft:redstone_wire replace
fill ~171 ~19 ~148 ~171 ~19 ~160 minecraft:redstone_wire replace
fill ~186 ~19 ~148 ~186 ~19 ~160 minecraft:redstone_wire replace
fill ~234 ~19 ~148 ~234 ~19 ~160 minecraft:redstone_wire replace
fill ~240 ~19 ~148 ~240 ~19 ~160 minecraft:redstone_wire replace
fill ~243 ~19 ~148 ~243 ~19 ~160 minecraft:redstone_wire replace
fill ~246 ~19 ~148 ~246 ~19 ~160 minecraft:redstone_wire replace
fill ~252 ~19 ~148 ~252 ~19 ~160 minecraft:redstone_wire replace
setblock ~177 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~19 ~152 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~152 ~177 ~19 ~164 minecraft:redstone_wire replace
fill ~189 ~19 ~152 ~189 ~19 ~162 minecraft:redstone_wire replace
fill ~192 ~19 ~152 ~192 ~19 ~164 minecraft:redstone_wire replace
fill ~195 ~19 ~152 ~195 ~19 ~164 minecraft:redstone_wire replace
fill ~198 ~19 ~152 ~198 ~19 ~164 minecraft:redstone_wire replace
fill ~201 ~19 ~152 ~201 ~19 ~164 minecraft:redstone_wire replace
fill ~255 ~19 ~152 ~255 ~19 ~164 minecraft:redstone_wire replace
fill ~288 ~19 ~152 ~288 ~19 ~164 minecraft:redstone_wire replace
fill ~291 ~19 ~152 ~291 ~19 ~164 minecraft:redstone_wire replace
fill ~294 ~19 ~152 ~294 ~19 ~164 minecraft:redstone_wire replace
fill ~297 ~19 ~152 ~297 ~19 ~164 minecraft:redstone_wire replace
setblock ~207 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~154 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~19 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~156 ~207 ~19 ~168 minecraft:redstone_wire replace
fill ~213 ~19 ~156 ~213 ~19 ~168 minecraft:redstone_wire replace
fill ~216 ~19 ~156 ~216 ~19 ~168 minecraft:redstone_wire replace
fill ~222 ~19 ~156 ~222 ~19 ~168 minecraft:redstone_wire replace
fill ~225 ~19 ~156 ~225 ~19 ~168 minecraft:redstone_wire replace
fill ~261 ~19 ~156 ~261 ~19 ~168 minecraft:redstone_wire replace
setblock ~300 ~19 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~158 ~180 ~19 ~170 minecraft:redstone_wire replace
setblock ~219 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~158 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~158 ~300 ~19 ~170 minecraft:redstone_wire replace
setblock ~150 ~19 ~160 minecraft:redstone_wire replace
fill ~219 ~19 ~160 ~219 ~19 ~172 minecraft:redstone_wire replace
fill ~228 ~19 ~160 ~228 ~19 ~172 minecraft:redstone_wire replace
fill ~267 ~19 ~160 ~267 ~19 ~172 minecraft:redstone_wire replace
fill ~273 ~19 ~160 ~273 ~19 ~172 minecraft:redstone_wire replace
fill ~276 ~19 ~160 ~276 ~19 ~172 minecraft:redstone_wire replace
fill ~279 ~19 ~160 ~279 ~19 ~172 minecraft:redstone_wire replace
fill ~282 ~19 ~160 ~282 ~19 ~172 minecraft:redstone_wire replace
setblock ~162 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~162 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~19 ~164 ~162 ~19 ~168 minecraft:redstone_wire replace
fill ~165 ~19 ~164 ~165 ~19 ~170 minecraft:redstone_wire replace
fill ~168 ~19 ~164 ~168 ~19 ~174 minecraft:redstone_wire replace
fill ~171 ~19 ~164 ~171 ~19 ~176 minecraft:redstone_wire replace
fill ~186 ~19 ~164 ~186 ~19 ~176 minecraft:redstone_wire replace
setblock ~189 ~19 ~164 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~19 ~164 ~234 ~19 ~176 minecraft:redstone_wire replace
fill ~240 ~19 ~164 ~240 ~19 ~176 minecraft:redstone_wire replace
fill ~243 ~19 ~164 ~243 ~19 ~176 minecraft:redstone_wire replace
fill ~246 ~19 ~164 ~246 ~19 ~176 minecraft:redstone_wire replace
fill ~252 ~19 ~164 ~252 ~19 ~176 minecraft:redstone_wire replace
setblock ~177 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~168 ~177 ~19 ~180 minecraft:redstone_wire replace
fill ~192 ~19 ~168 ~192 ~19 ~180 minecraft:redstone_wire replace
fill ~195 ~19 ~168 ~195 ~19 ~180 minecraft:redstone_wire replace
fill ~198 ~19 ~168 ~198 ~19 ~180 minecraft:redstone_wire replace
fill ~201 ~19 ~168 ~201 ~19 ~180 minecraft:redstone_wire replace
fill ~255 ~19 ~168 ~255 ~19 ~180 minecraft:redstone_wire replace
fill ~288 ~19 ~168 ~288 ~19 ~180 minecraft:redstone_wire replace
fill ~291 ~19 ~168 ~291 ~19 ~180 minecraft:redstone_wire replace
fill ~294 ~19 ~168 ~294 ~19 ~180 minecraft:redstone_wire replace
fill ~297 ~19 ~168 ~297 ~19 ~180 minecraft:redstone_wire replace
setblock ~207 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~170 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~19 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~19 ~172 ~207 ~19 ~182 minecraft:redstone_wire replace
fill ~213 ~19 ~172 ~213 ~19 ~184 minecraft:redstone_wire replace
fill ~216 ~19 ~172 ~216 ~19 ~184 minecraft:redstone_wire replace
fill ~222 ~19 ~172 ~222 ~19 ~184 minecraft:redstone_wire replace
fill ~225 ~19 ~172 ~225 ~19 ~184 minecraft:redstone_wire replace
fill ~261 ~19 ~172 ~261 ~19 ~184 minecraft:redstone_wire replace
setblock ~300 ~19 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~174 ~180 ~19 ~186 minecraft:redstone_wire replace
setblock ~219 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~174 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~174 ~300 ~19 ~186 minecraft:redstone_wire replace
setblock ~168 ~19 ~176 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~19 ~176 ~219 ~19 ~188 minecraft:redstone_wire replace
fill ~228 ~19 ~176 ~228 ~19 ~188 minecraft:redstone_wire replace
fill ~267 ~19 ~176 ~267 ~19 ~188 minecraft:redstone_wire replace
fill ~273 ~19 ~176 ~273 ~19 ~188 minecraft:redstone_wire replace
fill ~276 ~19 ~176 ~276 ~19 ~188 minecraft:redstone_wire replace
fill ~279 ~19 ~176 ~279 ~19 ~188 minecraft:redstone_wire replace
fill ~282 ~19 ~176 ~282 ~19 ~188 minecraft:redstone_wire replace
setblock ~171 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~178 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~19 ~180 minecraft:redstone_wire replace
fill ~186 ~19 ~180 ~186 ~19 ~192 minecraft:redstone_wire replace
fill ~234 ~19 ~180 ~234 ~19 ~192 minecraft:redstone_wire replace
fill ~240 ~19 ~180 ~240 ~19 ~192 minecraft:redstone_wire replace
fill ~243 ~19 ~180 ~243 ~19 ~192 minecraft:redstone_wire replace
fill ~246 ~19 ~180 ~246 ~19 ~192 minecraft:redstone_wire replace
fill ~252 ~19 ~180 ~252 ~19 ~192 minecraft:redstone_wire replace
setblock ~177 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~184 ~177 ~19 ~196 minecraft:redstone_wire replace
fill ~192 ~19 ~184 ~192 ~19 ~188 minecraft:redstone_wire replace
fill ~195 ~19 ~184 ~195 ~19 ~190 minecraft:redstone_wire replace
fill ~198 ~19 ~184 ~198 ~19 ~194 minecraft:redstone_wire replace
fill ~201 ~19 ~184 ~201 ~19 ~196 minecraft:redstone_wire replace
setblock ~207 ~19 ~184 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~19 ~184 ~255 ~19 ~196 minecraft:redstone_wire replace
fill ~288 ~19 ~184 ~288 ~19 ~196 minecraft:redstone_wire replace
fill ~291 ~19 ~184 ~291 ~19 ~196 minecraft:redstone_wire replace
fill ~294 ~19 ~184 ~294 ~19 ~196 minecraft:redstone_wire replace
fill ~297 ~19 ~184 ~297 ~19 ~196 minecraft:redstone_wire replace
setblock ~213 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~186 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~19 ~188 ~213 ~19 ~200 minecraft:redstone_wire replace
fill ~216 ~19 ~188 ~216 ~19 ~200 minecraft:redstone_wire replace
fill ~222 ~19 ~188 ~222 ~19 ~200 minecraft:redstone_wire replace
fill ~225 ~19 ~188 ~225 ~19 ~200 minecraft:redstone_wire replace
fill ~261 ~19 ~188 ~261 ~19 ~200 minecraft:redstone_wire replace
setblock ~300 ~19 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~190 ~180 ~19 ~202 minecraft:redstone_wire replace
setblock ~219 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~190 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~190 ~300 ~19 ~202 minecraft:redstone_wire replace
setblock ~195 ~19 ~192 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~19 ~192 ~219 ~19 ~202 minecraft:redstone_wire replace
fill ~228 ~19 ~192 ~228 ~19 ~204 minecraft:redstone_wire replace
fill ~267 ~19 ~192 ~267 ~19 ~204 minecraft:redstone_wire replace
fill ~273 ~19 ~192 ~273 ~19 ~204 minecraft:redstone_wire replace
fill ~276 ~19 ~192 ~276 ~19 ~204 minecraft:redstone_wire replace
fill ~279 ~19 ~192 ~279 ~19 ~204 minecraft:redstone_wire replace
fill ~282 ~19 ~192 ~282 ~19 ~204 minecraft:redstone_wire replace
setblock ~186 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~194 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~196 ~186 ~19 ~208 minecraft:redstone_wire replace
setblock ~198 ~19 ~196 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~19 ~196 ~234 ~19 ~208 minecraft:redstone_wire replace
fill ~240 ~19 ~196 ~240 ~19 ~208 minecraft:redstone_wire replace
fill ~243 ~19 ~196 ~243 ~19 ~208 minecraft:redstone_wire replace
fill ~246 ~19 ~196 ~246 ~19 ~208 minecraft:redstone_wire replace
fill ~252 ~19 ~196 ~252 ~19 ~208 minecraft:redstone_wire replace
setblock ~177 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~200 ~177 ~19 ~212 minecraft:redstone_wire replace
setblock ~201 ~19 ~200 minecraft:redstone_wire replace
fill ~255 ~19 ~200 ~255 ~19 ~212 minecraft:redstone_wire replace
fill ~288 ~19 ~200 ~288 ~19 ~212 minecraft:redstone_wire replace
fill ~291 ~19 ~200 ~291 ~19 ~212 minecraft:redstone_wire replace
fill ~294 ~19 ~200 ~294 ~19 ~212 minecraft:redstone_wire replace
fill ~297 ~19 ~200 ~297 ~19 ~212 minecraft:redstone_wire replace
setblock ~213 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~202 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~19 ~204 ~213 ~19 ~208 minecraft:redstone_wire replace
fill ~216 ~19 ~204 ~216 ~19 ~210 minecraft:redstone_wire replace
setblock ~219 ~19 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~19 ~204 ~222 ~19 ~214 minecraft:redstone_wire replace
fill ~225 ~19 ~204 ~225 ~19 ~216 minecraft:redstone_wire replace
fill ~261 ~19 ~204 ~261 ~19 ~216 minecraft:redstone_wire replace
setblock ~300 ~19 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~206 ~180 ~19 ~218 minecraft:redstone_wire replace
setblock ~228 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~206 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~206 ~300 ~19 ~218 minecraft:redstone_wire replace
fill ~228 ~19 ~208 ~228 ~19 ~220 minecraft:redstone_wire replace
fill ~267 ~19 ~208 ~267 ~19 ~220 minecraft:redstone_wire replace
fill ~273 ~19 ~208 ~273 ~19 ~220 minecraft:redstone_wire replace
fill ~276 ~19 ~208 ~276 ~19 ~220 minecraft:redstone_wire replace
fill ~279 ~19 ~208 ~279 ~19 ~220 minecraft:redstone_wire replace
fill ~282 ~19 ~208 ~282 ~19 ~220 minecraft:redstone_wire replace
setblock ~186 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~19 ~210 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~212 ~186 ~19 ~224 minecraft:redstone_wire replace
setblock ~216 ~19 ~212 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~19 ~212 ~234 ~19 ~224 minecraft:redstone_wire replace
fill ~240 ~19 ~212 ~240 ~19 ~224 minecraft:redstone_wire replace
fill ~243 ~19 ~212 ~243 ~19 ~224 minecraft:redstone_wire replace
fill ~246 ~19 ~212 ~246 ~19 ~224 minecraft:redstone_wire replace
fill ~252 ~19 ~212 ~252 ~19 ~222 minecraft:redstone_wire replace
setblock ~177 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~216 ~177 ~19 ~228 minecraft:redstone_wire replace
setblock ~222 ~19 ~216 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~19 ~216 ~255 ~19 ~226 minecraft:redstone_wire replace
fill ~288 ~19 ~216 ~288 ~19 ~228 minecraft:redstone_wire replace
fill ~291 ~19 ~216 ~291 ~19 ~228 minecraft:redstone_wire replace
fill ~294 ~19 ~216 ~294 ~19 ~228 minecraft:redstone_wire replace
fill ~297 ~19 ~216 ~297 ~19 ~228 minecraft:redstone_wire replace
setblock ~225 ~19 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~19 ~218 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~19 ~220 minecraft:redstone_wire replace
fill ~261 ~19 ~220 ~261 ~19 ~232 minecraft:redstone_wire replace
setblock ~300 ~19 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~222 ~180 ~19 ~234 minecraft:redstone_wire replace
setblock ~228 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~222 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~222 ~300 ~19 ~234 minecraft:redstone_wire replace
fill ~228 ~19 ~224 ~228 ~19 ~236 minecraft:redstone_wire replace
setblock ~252 ~19 ~224 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~19 ~224 ~267 ~19 ~230 minecraft:redstone_wire replace
fill ~273 ~19 ~224 ~273 ~19 ~236 minecraft:redstone_wire replace
fill ~276 ~19 ~224 ~276 ~19 ~234 minecraft:redstone_wire replace
fill ~279 ~19 ~224 ~279 ~19 ~236 minecraft:redstone_wire replace
fill ~282 ~19 ~224 ~282 ~19 ~236 minecraft:redstone_wire replace
setblock ~186 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~226 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~228 ~186 ~19 ~240 minecraft:redstone_wire replace
fill ~234 ~19 ~228 ~234 ~19 ~240 minecraft:redstone_wire replace
fill ~240 ~19 ~228 ~240 ~19 ~240 minecraft:redstone_wire replace
fill ~243 ~19 ~228 ~243 ~19 ~240 minecraft:redstone_wire replace
fill ~246 ~19 ~228 ~246 ~19 ~240 minecraft:redstone_wire replace
setblock ~255 ~19 ~228 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~232 ~177 ~19 ~244 minecraft:redstone_wire replace
setblock ~267 ~19 ~232 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~19 ~232 ~288 ~19 ~244 minecraft:redstone_wire replace
fill ~291 ~19 ~232 ~291 ~19 ~244 minecraft:redstone_wire replace
fill ~294 ~19 ~232 ~294 ~19 ~244 minecraft:redstone_wire replace
fill ~297 ~19 ~232 ~297 ~19 ~244 minecraft:redstone_wire replace
setblock ~261 ~19 ~234 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~19 ~236 ~261 ~19 ~248 minecraft:redstone_wire replace
setblock ~276 ~19 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~238 ~180 ~19 ~250 minecraft:redstone_wire replace
setblock ~228 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~19 ~238 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~238 ~300 ~19 ~250 minecraft:redstone_wire replace
fill ~228 ~19 ~240 ~228 ~19 ~252 minecraft:redstone_wire replace
fill ~273 ~19 ~240 ~273 ~19 ~252 minecraft:redstone_wire replace
setblock ~279 ~19 ~240 minecraft:redstone_wire replace
fill ~282 ~19 ~240 ~282 ~19 ~244 minecraft:redstone_wire replace
setblock ~186 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~242 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~244 ~186 ~19 ~256 minecraft:redstone_wire replace
fill ~234 ~19 ~244 ~234 ~19 ~248 minecraft:redstone_wire replace
fill ~240 ~19 ~244 ~240 ~19 ~250 minecraft:redstone_wire replace
fill ~243 ~19 ~244 ~243 ~19 ~254 minecraft:redstone_wire replace
fill ~246 ~19 ~244 ~246 ~19 ~256 minecraft:redstone_wire replace
setblock ~177 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~248 ~177 ~19 ~260 minecraft:redstone_wire replace
fill ~288 ~19 ~248 ~288 ~19 ~260 minecraft:redstone_wire replace
fill ~291 ~19 ~248 ~291 ~19 ~260 minecraft:redstone_wire replace
fill ~294 ~19 ~248 ~294 ~19 ~260 minecraft:redstone_wire replace
fill ~297 ~19 ~248 ~297 ~19 ~260 minecraft:redstone_wire replace
setblock ~261 ~19 ~250 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~180 ~19 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~19 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~19 ~252 ~261 ~19 ~262 minecraft:redstone_wire replace
setblock ~300 ~19 ~252 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~254 ~180 ~19 ~266 minecraft:redstone_wire replace
setblock ~228 ~19 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~254 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~254 ~300 ~19 ~266 minecraft:redstone_wire replace
fill ~228 ~19 ~256 ~228 ~19 ~268 minecraft:redstone_wire replace
setblock ~243 ~19 ~256 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~19 ~256 ~273 ~19 ~266 minecraft:redstone_wire replace
setblock ~186 ~19 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~19 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~260 ~186 ~19 ~272 minecraft:redstone_wire replace
setblock ~246 ~19 ~260 minecraft:redstone_wire replace
setblock ~177 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~264 ~177 ~19 ~276 minecraft:redstone_wire replace
setblock ~261 ~19 ~264 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~19 ~264 ~288 ~19 ~270 minecraft:redstone_wire replace
fill ~291 ~19 ~264 ~291 ~19 ~274 minecraft:redstone_wire replace
fill ~294 ~19 ~264 ~294 ~19 ~276 minecraft:redstone_wire replace
fill ~297 ~19 ~264 ~297 ~19 ~276 minecraft:redstone_wire replace
setblock ~180 ~19 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~19 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~268 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~270 ~180 ~19 ~282 minecraft:redstone_wire replace
setblock ~228 ~19 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~270 ~300 ~19 ~282 minecraft:redstone_wire replace
fill ~228 ~19 ~272 ~228 ~19 ~284 minecraft:redstone_wire replace
setblock ~288 ~19 ~272 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~19 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~276 ~186 ~19 ~288 minecraft:redstone_wire replace
setblock ~291 ~19 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~19 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~19 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~19 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~19 ~280 ~177 ~19 ~286 minecraft:redstone_wire replace
setblock ~294 ~19 ~280 minecraft:redstone_wire replace
fill ~297 ~19 ~280 ~297 ~19 ~284 minecraft:redstone_wire replace
setblock ~180 ~19 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~284 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~19 ~286 ~180 ~19 ~292 minecraft:redstone_wire replace
setblock ~228 ~19 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~19 ~286 ~300 ~19 ~298 minecraft:redstone_wire replace
setblock ~177 ~19 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~19 ~288 ~228 ~19 ~300 minecraft:redstone_wire replace
setblock ~186 ~19 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~19 ~292 ~186 ~19 ~296 minecraft:redstone_wire replace
setblock ~300 ~19 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~19 ~300 minecraft:redstone_wire replace
setblock ~228 ~19 ~302 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~19 ~304 minecraft:redstone_wire replace
setblock ~78 ~20 ~9 minecraft:redstone_wire replace
setblock ~108 ~20 ~13 minecraft:redstone_wire replace
setblock ~93 ~20 ~17 minecraft:redstone_wire replace
setblock ~114 ~20 ~21 minecraft:redstone_wire replace
setblock ~111 ~20 ~25 minecraft:redstone_wire replace
setblock ~132 ~20 ~29 minecraft:redstone_wire replace
setblock ~135 ~20 ~33 minecraft:redstone_wire replace
setblock ~153 ~20 ~37 minecraft:redstone_wire replace
setblock ~159 ~20 ~41 minecraft:redstone_wire replace
setblock ~174 ~20 ~45 minecraft:redstone_wire replace
setblock ~183 ~20 ~49 minecraft:redstone_wire replace
setblock ~204 ~20 ~53 minecraft:redstone_wire replace
setblock ~210 ~20 ~57 minecraft:redstone_wire replace
setblock ~237 ~20 ~61 minecraft:redstone_wire replace
setblock ~249 ~20 ~65 minecraft:redstone_wire replace
setblock ~264 ~20 ~69 minecraft:redstone_wire replace
setblock ~231 ~20 ~73 minecraft:redstone_wire replace
setblock ~270 ~20 ~77 minecraft:redstone_wire replace
setblock ~258 ~20 ~81 minecraft:redstone_wire replace
setblock ~285 ~20 ~85 minecraft:redstone_wire replace
setblock ~81 ~20 ~89 minecraft:redstone_wire replace
setblock ~84 ~20 ~93 minecraft:redstone_wire replace
setblock ~87 ~20 ~97 minecraft:redstone_wire replace
setblock ~90 ~20 ~101 minecraft:redstone_wire replace
setblock ~129 ~20 ~105 minecraft:redstone_wire replace
setblock ~96 ~20 ~109 minecraft:redstone_wire replace
setblock ~99 ~20 ~113 minecraft:redstone_wire replace
setblock ~102 ~20 ~117 minecraft:redstone_wire replace
setblock ~105 ~20 ~121 minecraft:redstone_wire replace
setblock ~141 ~20 ~125 minecraft:redstone_wire replace
setblock ~117 ~20 ~129 minecraft:redstone_wire replace
setblock ~120 ~20 ~133 minecraft:redstone_wire replace
setblock ~123 ~20 ~137 minecraft:redstone_wire replace
setblock ~126 ~20 ~141 minecraft:redstone_wire replace
setblock ~156 ~20 ~145 minecraft:redstone_wire replace
setblock ~138 ~20 ~149 minecraft:redstone_wire replace
setblock ~144 ~20 ~153 minecraft:redstone_wire replace
setblock ~147 ~20 ~157 minecraft:redstone_wire replace
setblock ~150 ~20 ~161 minecraft:redstone_wire replace
setblock ~189 ~20 ~165 minecraft:redstone_wire replace
setblock ~162 ~20 ~169 minecraft:redstone_wire replace
setblock ~165 ~20 ~173 minecraft:redstone_wire replace
setblock ~168 ~20 ~177 minecraft:redstone_wire replace
setblock ~171 ~20 ~181 minecraft:redstone_wire replace
setblock ~207 ~20 ~185 minecraft:redstone_wire replace
setblock ~192 ~20 ~189 minecraft:redstone_wire replace
setblock ~195 ~20 ~193 minecraft:redstone_wire replace
setblock ~198 ~20 ~197 minecraft:redstone_wire replace
setblock ~201 ~20 ~201 minecraft:redstone_wire replace
setblock ~219 ~20 ~205 minecraft:redstone_wire replace
setblock ~213 ~20 ~209 minecraft:redstone_wire replace
setblock ~216 ~20 ~213 minecraft:redstone_wire replace
setblock ~222 ~20 ~217 minecraft:redstone_wire replace
setblock ~225 ~20 ~221 minecraft:redstone_wire replace
setblock ~252 ~20 ~225 minecraft:redstone_wire replace
setblock ~255 ~20 ~229 minecraft:redstone_wire replace
setblock ~267 ~20 ~233 minecraft:redstone_wire replace
setblock ~276 ~20 ~237 minecraft:redstone_wire replace
setblock ~279 ~20 ~241 minecraft:redstone_wire replace
setblock ~282 ~20 ~245 minecraft:redstone_wire replace
setblock ~234 ~20 ~249 minecraft:redstone_wire replace
setblock ~240 ~20 ~253 minecraft:redstone_wire replace
setblock ~243 ~20 ~257 minecraft:redstone_wire replace
setblock ~246 ~20 ~261 minecraft:redstone_wire replace
setblock ~261 ~20 ~265 minecraft:redstone_wire replace
setblock ~273 ~20 ~269 minecraft:redstone_wire replace
setblock ~288 ~20 ~273 minecraft:redstone_wire replace
setblock ~291 ~20 ~277 minecraft:redstone_wire replace
setblock ~294 ~20 ~281 minecraft:redstone_wire replace
setblock ~297 ~20 ~285 minecraft:redstone_wire replace
setblock ~177 ~20 ~289 minecraft:redstone_wire replace
setblock ~180 ~20 ~293 minecraft:redstone_wire replace
setblock ~186 ~20 ~297 minecraft:redstone_wire replace
setblock ~300 ~20 ~301 minecraft:redstone_wire replace
setblock ~228 ~20 ~305 minecraft:redstone_wire replace
fill ~78 ~21 ~10 ~80 ~21 ~10 minecraft:redstone_wire replace
setblock ~79 ~21 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~21 ~14 ~108 ~21 ~14 minecraft:redstone_wire replace
setblock ~103 ~21 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~21 ~18 ~93 ~21 ~18 minecraft:redstone_wire replace
setblock ~91 ~21 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~21 ~22 ~114 ~21 ~22 minecraft:redstone_wire replace
setblock ~109 ~21 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~21 ~26 ~111 ~21 ~26 minecraft:redstone_wire replace
setblock ~106 ~21 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~21 ~30 ~132 ~21 ~30 minecraft:redstone_wire replace
setblock ~124 ~21 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~21 ~34 ~135 ~21 ~34 minecraft:redstone_wire replace
setblock ~127 ~21 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~21 ~38 ~145 ~21 ~38 minecraft:redstone_wire replace
setblock ~146 ~21 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~21 ~38 ~153 ~21 ~38 minecraft:redstone_wire replace
setblock ~145 ~21 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~21 ~42 ~151 ~21 ~42 minecraft:redstone_wire replace
setblock ~152 ~21 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~21 ~42 ~159 ~21 ~42 minecraft:redstone_wire replace
setblock ~151 ~21 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~21 ~46 ~174 ~21 ~46 minecraft:redstone_wire replace
setblock ~169 ~21 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~21 ~50 ~183 ~21 ~50 minecraft:redstone_wire replace
setblock ~175 ~21 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~21 ~54 ~204 ~21 ~54 minecraft:redstone_wire replace
setblock ~199 ~21 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~21 ~58 ~210 ~21 ~58 minecraft:redstone_wire replace
setblock ~208 ~21 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~21 ~62 ~237 ~21 ~62 minecraft:redstone_wire replace
setblock ~232 ~21 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~21 ~66 ~249 ~21 ~66 minecraft:redstone_wire replace
setblock ~241 ~21 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~255 ~21 ~70 ~256 ~21 ~70 minecraft:redstone_wire replace
setblock ~257 ~21 ~70 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~21 ~70 ~264 ~21 ~70 minecraft:redstone_wire replace
setblock ~256 ~21 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~21 ~74 ~231 ~21 ~74 minecraft:redstone_wire replace
setblock ~226 ~21 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~261 ~21 ~78 ~270 ~21 ~78 minecraft:redstone_wire replace
setblock ~262 ~21 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~249 ~21 ~82 ~258 ~21 ~82 minecraft:redstone_wire replace
setblock ~250 ~21 ~83 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~21 ~86 ~285 ~21 ~86 minecraft:redstone_wire replace
setblock ~274 ~21 ~87 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~21 ~90 ~83 ~21 ~90 minecraft:redstone_wire replace
setblock ~82 ~21 ~91 minecraft:redstone_wire replace
fill ~84 ~21 ~94 ~86 ~21 ~94 minecraft:redstone_wire replace
setblock ~85 ~21 ~95 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~21 ~98 ~89 ~21 ~98 minecraft:redstone_wire replace
setblock ~88 ~21 ~99 minecraft:redstone_wire replace
fill ~87 ~21 ~102 ~90 ~21 ~102 minecraft:redstone_wire replace
setblock ~88 ~21 ~103 minecraft:redstone_wire replace
fill ~120 ~21 ~106 ~129 ~21 ~106 minecraft:redstone_wire replace
setblock ~121 ~21 ~107 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~21 ~110 ~96 ~21 ~110 minecraft:redstone_wire replace
setblock ~94 ~21 ~111 minecraft:redstone_wire replace
fill ~96 ~21 ~114 ~99 ~21 ~114 minecraft:redstone_wire replace
setblock ~97 ~21 ~115 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~21 ~118 ~102 ~21 ~118 minecraft:redstone_wire replace
setblock ~100 ~21 ~119 minecraft:redstone_wire replace
fill ~99 ~21 ~122 ~105 ~21 ~122 minecraft:redstone_wire replace
setblock ~100 ~21 ~123 minecraft:redstone_wire replace
fill ~132 ~21 ~126 ~141 ~21 ~126 minecraft:redstone_wire replace
setblock ~133 ~21 ~127 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~21 ~130 ~117 ~21 ~130 minecraft:redstone_wire replace
setblock ~112 ~21 ~131 minecraft:redstone_wire replace
fill ~114 ~21 ~134 ~120 ~21 ~134 minecraft:redstone_wire replace
setblock ~115 ~21 ~135 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~21 ~138 ~123 ~21 ~138 minecraft:redstone_wire replace
setblock ~118 ~21 ~139 minecraft:redstone_wire replace
fill ~117 ~21 ~142 ~126 ~21 ~142 minecraft:redstone_wire replace
setblock ~118 ~21 ~143 minecraft:redstone_wire replace
fill ~147 ~21 ~146 ~156 ~21 ~146 minecraft:redstone_wire replace
setblock ~148 ~21 ~147 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~21 ~150 ~130 ~21 ~150 minecraft:redstone_wire replace
setblock ~131 ~21 ~150 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~21 ~150 ~138 ~21 ~150 minecraft:redstone_wire replace
setblock ~130 ~21 ~151 minecraft:redstone_wire replace
fill ~138 ~21 ~154 ~144 ~21 ~154 minecraft:redstone_wire replace
setblock ~139 ~21 ~155 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~21 ~158 ~147 ~21 ~158 minecraft:redstone_wire replace
setblock ~142 ~21 ~159 minecraft:redstone_wire replace
fill ~141 ~21 ~162 ~150 ~21 ~162 minecraft:redstone_wire replace
setblock ~142 ~21 ~163 minecraft:redstone_wire replace
fill ~180 ~21 ~166 ~189 ~21 ~166 minecraft:redstone_wire replace
setblock ~181 ~21 ~167 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~21 ~170 ~154 ~21 ~170 minecraft:redstone_wire replace
setblock ~155 ~21 ~170 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~21 ~170 ~162 ~21 ~170 minecraft:redstone_wire replace
setblock ~154 ~21 ~171 minecraft:redstone_wire replace
fill ~156 ~21 ~174 ~165 ~21 ~174 minecraft:redstone_wire replace
setblock ~157 ~21 ~175 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~21 ~178 ~168 ~21 ~178 minecraft:redstone_wire replace
