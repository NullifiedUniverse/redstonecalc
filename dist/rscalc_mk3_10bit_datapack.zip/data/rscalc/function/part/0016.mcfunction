setblock ~123 ~163 ~662 minecraft:light_gray_concrete replace
setblock ~126 ~163 ~678 minecraft:light_gray_concrete replace
setblock ~129 ~163 ~702 minecraft:light_gray_concrete replace
setblock ~153 ~163 ~730 minecraft:light_gray_concrete replace
setblock ~156 ~163 ~734 minecraft:light_gray_concrete replace
setblock ~159 ~163 ~742 minecraft:light_gray_concrete replace
setblock ~162 ~163 ~750 minecraft:light_gray_concrete replace
setblock ~165 ~163 ~754 minecraft:light_gray_concrete replace
setblock ~168 ~163 ~758 minecraft:light_gray_concrete replace
setblock ~132 ~163 ~762 minecraft:light_gray_concrete replace
setblock ~135 ~163 ~794 minecraft:light_gray_concrete replace
setblock ~138 ~163 ~826 minecraft:light_gray_concrete replace
setblock ~141 ~163 ~862 minecraft:light_gray_concrete replace
setblock ~144 ~163 ~890 minecraft:light_gray_concrete replace
setblock ~147 ~163 ~906 minecraft:light_gray_concrete replace
setblock ~150 ~163 ~930 minecraft:light_gray_concrete replace
setblock ~171 ~163 ~962 minecraft:light_gray_concrete replace
setblock ~174 ~163 ~966 minecraft:light_gray_concrete replace
fill ~109 ~164 ~230 ~495 ~164 ~230 minecraft:light_gray_concrete replace
fill ~85 ~164 ~234 ~497 ~164 ~234 minecraft:light_gray_concrete replace
fill ~106 ~164 ~262 ~481 ~164 ~262 minecraft:light_gray_concrete replace
fill ~103 ~164 ~286 ~483 ~164 ~286 minecraft:light_gray_concrete replace
fill ~100 ~164 ~302 ~485 ~164 ~302 minecraft:light_gray_concrete replace
fill ~97 ~164 ~330 ~487 ~164 ~330 minecraft:light_gray_concrete replace
fill ~94 ~164 ~366 ~489 ~164 ~366 minecraft:light_gray_concrete replace
fill ~91 ~164 ~398 ~491 ~164 ~398 minecraft:light_gray_concrete replace
fill ~88 ~164 ~430 ~493 ~164 ~430 minecraft:light_gray_concrete replace
fill ~82 ~164 ~446 ~499 ~164 ~446 minecraft:light_gray_concrete replace
fill ~112 ~164 ~534 ~467 ~164 ~534 minecraft:light_gray_concrete replace
fill ~115 ~164 ~566 ~469 ~164 ~566 minecraft:light_gray_concrete replace
fill ~118 ~164 ~598 ~471 ~164 ~598 minecraft:light_gray_concrete replace
fill ~121 ~164 ~634 ~473 ~164 ~634 minecraft:light_gray_concrete replace
fill ~124 ~164 ~662 ~475 ~164 ~662 minecraft:light_gray_concrete replace
fill ~127 ~164 ~678 ~477 ~164 ~678 minecraft:light_gray_concrete replace
fill ~130 ~164 ~702 ~479 ~164 ~702 minecraft:light_gray_concrete replace
fill ~154 ~164 ~730 ~439 ~164 ~730 minecraft:light_gray_concrete replace
fill ~157 ~164 ~734 ~441 ~164 ~734 minecraft:light_gray_concrete replace
fill ~160 ~164 ~742 ~443 ~164 ~742 minecraft:light_gray_concrete replace
fill ~163 ~164 ~750 ~445 ~164 ~750 minecraft:light_gray_concrete replace
fill ~166 ~164 ~754 ~447 ~164 ~754 minecraft:light_gray_concrete replace
fill ~169 ~164 ~758 ~449 ~164 ~758 minecraft:light_gray_concrete replace
fill ~133 ~164 ~762 ~453 ~164 ~762 minecraft:light_gray_concrete replace
fill ~136 ~164 ~794 ~455 ~164 ~794 minecraft:light_gray_concrete replace
fill ~139 ~164 ~826 ~457 ~164 ~826 minecraft:light_gray_concrete replace
fill ~142 ~164 ~862 ~459 ~164 ~862 minecraft:light_gray_concrete replace
fill ~145 ~164 ~890 ~461 ~164 ~890 minecraft:light_gray_concrete replace
fill ~148 ~164 ~906 ~463 ~164 ~906 minecraft:light_gray_concrete replace
fill ~151 ~164 ~930 ~465 ~164 ~930 minecraft:light_gray_concrete replace
fill ~172 ~164 ~962 ~501 ~164 ~962 minecraft:light_gray_concrete replace
fill ~175 ~164 ~966 ~451 ~164 ~966 minecraft:light_gray_concrete replace
setblock ~108 ~165 ~230 minecraft:light_gray_concrete replace
setblock ~496 ~165 ~230 minecraft:light_gray_concrete replace
setblock ~84 ~165 ~234 minecraft:light_gray_concrete replace
setblock ~498 ~165 ~234 minecraft:light_gray_concrete replace
setblock ~105 ~165 ~262 minecraft:light_gray_concrete replace
setblock ~482 ~165 ~262 minecraft:light_gray_concrete replace
setblock ~102 ~165 ~286 minecraft:light_gray_concrete replace
setblock ~484 ~165 ~286 minecraft:light_gray_concrete replace
setblock ~99 ~165 ~302 minecraft:light_gray_concrete replace
setblock ~486 ~165 ~302 minecraft:light_gray_concrete replace
setblock ~96 ~165 ~330 minecraft:light_gray_concrete replace
setblock ~488 ~165 ~330 minecraft:light_gray_concrete replace
setblock ~93 ~165 ~366 minecraft:light_gray_concrete replace
setblock ~490 ~165 ~366 minecraft:light_gray_concrete replace
setblock ~90 ~165 ~398 minecraft:light_gray_concrete replace
setblock ~492 ~165 ~398 minecraft:light_gray_concrete replace
setblock ~87 ~165 ~430 minecraft:light_gray_concrete replace
setblock ~494 ~165 ~430 minecraft:light_gray_concrete replace
setblock ~81 ~165 ~446 minecraft:light_gray_concrete replace
setblock ~500 ~165 ~446 minecraft:light_gray_concrete replace
setblock ~111 ~165 ~534 minecraft:light_gray_concrete replace
setblock ~468 ~165 ~534 minecraft:light_gray_concrete replace
setblock ~114 ~165 ~566 minecraft:light_gray_concrete replace
setblock ~470 ~165 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~165 ~598 minecraft:light_gray_concrete replace
setblock ~472 ~165 ~598 minecraft:light_gray_concrete replace
setblock ~120 ~165 ~634 minecraft:light_gray_concrete replace
setblock ~474 ~165 ~634 minecraft:light_gray_concrete replace
setblock ~123 ~165 ~662 minecraft:light_gray_concrete replace
setblock ~476 ~165 ~662 minecraft:light_gray_concrete replace
setblock ~126 ~165 ~678 minecraft:light_gray_concrete replace
setblock ~478 ~165 ~678 minecraft:light_gray_concrete replace
setblock ~129 ~165 ~702 minecraft:light_gray_concrete replace
setblock ~480 ~165 ~702 minecraft:light_gray_concrete replace
setblock ~153 ~165 ~730 minecraft:light_gray_concrete replace
setblock ~440 ~165 ~730 minecraft:light_gray_concrete replace
setblock ~156 ~165 ~734 minecraft:light_gray_concrete replace
setblock ~442 ~165 ~734 minecraft:light_gray_concrete replace
setblock ~159 ~165 ~742 minecraft:light_gray_concrete replace
setblock ~444 ~165 ~742 minecraft:light_gray_concrete replace
setblock ~162 ~165 ~750 minecraft:light_gray_concrete replace
setblock ~446 ~165 ~750 minecraft:light_gray_concrete replace
setblock ~165 ~165 ~754 minecraft:light_gray_concrete replace
setblock ~448 ~165 ~754 minecraft:light_gray_concrete replace
setblock ~168 ~165 ~758 minecraft:light_gray_concrete replace
setblock ~450 ~165 ~758 minecraft:light_gray_concrete replace
setblock ~132 ~165 ~762 minecraft:light_gray_concrete replace
setblock ~454 ~165 ~762 minecraft:light_gray_concrete replace
setblock ~135 ~165 ~794 minecraft:light_gray_concrete replace
setblock ~456 ~165 ~794 minecraft:light_gray_concrete replace
setblock ~138 ~165 ~826 minecraft:light_gray_concrete replace
setblock ~458 ~165 ~826 minecraft:light_gray_concrete replace
setblock ~141 ~165 ~862 minecraft:light_gray_concrete replace
setblock ~460 ~165 ~862 minecraft:light_gray_concrete replace
setblock ~144 ~165 ~890 minecraft:light_gray_concrete replace
setblock ~462 ~165 ~890 minecraft:light_gray_concrete replace
setblock ~147 ~165 ~906 minecraft:light_gray_concrete replace
setblock ~464 ~165 ~906 minecraft:light_gray_concrete replace
setblock ~150 ~165 ~930 minecraft:light_gray_concrete replace
setblock ~466 ~165 ~930 minecraft:light_gray_concrete replace
setblock ~171 ~165 ~962 minecraft:light_gray_concrete replace
setblock ~502 ~165 ~962 minecraft:light_gray_concrete replace
setblock ~174 ~165 ~966 minecraft:light_gray_concrete replace
setblock ~452 ~165 ~966 minecraft:light_gray_concrete replace
setblock ~496 ~167 ~230 minecraft:light_gray_concrete replace
setblock ~498 ~167 ~234 minecraft:light_gray_concrete replace
setblock ~482 ~167 ~262 minecraft:light_gray_concrete replace
setblock ~484 ~167 ~286 minecraft:light_gray_concrete replace
setblock ~486 ~167 ~302 minecraft:light_gray_concrete replace
setblock ~488 ~167 ~330 minecraft:light_gray_concrete replace
setblock ~490 ~167 ~366 minecraft:light_gray_concrete replace
setblock ~492 ~167 ~398 minecraft:light_gray_concrete replace
setblock ~494 ~167 ~430 minecraft:light_gray_concrete replace
setblock ~500 ~167 ~446 minecraft:light_gray_concrete replace
setblock ~468 ~167 ~534 minecraft:light_gray_concrete replace
setblock ~470 ~167 ~566 minecraft:light_gray_concrete replace
setblock ~472 ~167 ~598 minecraft:light_gray_concrete replace
setblock ~474 ~167 ~634 minecraft:light_gray_concrete replace
setblock ~476 ~167 ~662 minecraft:light_gray_concrete replace
setblock ~478 ~167 ~678 minecraft:light_gray_concrete replace
setblock ~480 ~167 ~702 minecraft:light_gray_concrete replace
setblock ~440 ~167 ~730 minecraft:light_gray_concrete replace
setblock ~442 ~167 ~734 minecraft:light_gray_concrete replace
setblock ~444 ~167 ~742 minecraft:light_gray_concrete replace
setblock ~446 ~167 ~750 minecraft:light_gray_concrete replace
setblock ~448 ~167 ~754 minecraft:light_gray_concrete replace
setblock ~450 ~167 ~758 minecraft:light_gray_concrete replace
setblock ~454 ~167 ~762 minecraft:light_gray_concrete replace
setblock ~456 ~167 ~794 minecraft:light_gray_concrete replace
setblock ~458 ~167 ~826 minecraft:light_gray_concrete replace
setblock ~460 ~167 ~862 minecraft:light_gray_concrete replace
setblock ~462 ~167 ~890 minecraft:light_gray_concrete replace
setblock ~464 ~167 ~906 minecraft:light_gray_concrete replace
setblock ~466 ~167 ~930 minecraft:light_gray_concrete replace
setblock ~502 ~167 ~962 minecraft:light_gray_concrete replace
setblock ~452 ~167 ~966 minecraft:light_gray_concrete replace
fill ~440 ~168 ~3 ~440 ~168 ~729 minecraft:light_gray_concrete replace
fill ~454 ~168 ~3 ~454 ~168 ~761 minecraft:light_gray_concrete replace
fill ~468 ~168 ~3 ~468 ~168 ~533 minecraft:light_gray_concrete replace
fill ~494 ~168 ~3 ~494 ~168 ~429 minecraft:light_gray_concrete replace
fill ~498 ~168 ~3 ~498 ~168 ~233 minecraft:light_gray_concrete replace
fill ~450 ~168 ~5 ~450 ~168 ~757 minecraft:light_gray_concrete replace
fill ~464 ~168 ~5 ~464 ~168 ~905 minecraft:light_gray_concrete replace
fill ~478 ~168 ~5 ~478 ~168 ~677 minecraft:light_gray_concrete replace
fill ~484 ~168 ~5 ~484 ~168 ~285 minecraft:light_gray_concrete replace
fill ~500 ~168 ~5 ~500 ~168 ~445 minecraft:light_gray_concrete replace
fill ~442 ~168 ~7 ~442 ~168 ~733 minecraft:light_gray_concrete replace
fill ~456 ~168 ~7 ~456 ~168 ~793 minecraft:light_gray_concrete replace
fill ~470 ~168 ~7 ~470 ~168 ~565 minecraft:light_gray_concrete replace
fill ~492 ~168 ~7 ~492 ~168 ~397 minecraft:light_gray_concrete replace
fill ~502 ~168 ~7 ~502 ~168 ~961 minecraft:light_gray_concrete replace
fill ~452 ~168 ~9 ~452 ~168 ~965 minecraft:light_gray_concrete replace
fill ~466 ~168 ~9 ~466 ~168 ~929 minecraft:light_gray_concrete replace
fill ~480 ~168 ~9 ~480 ~168 ~701 minecraft:light_gray_concrete replace
fill ~482 ~168 ~9 ~482 ~168 ~261 minecraft:light_gray_concrete replace
fill ~496 ~168 ~9 ~496 ~168 ~229 minecraft:light_gray_concrete replace
fill ~448 ~168 ~11 ~448 ~168 ~753 minecraft:light_gray_concrete replace
fill ~462 ~168 ~11 ~462 ~168 ~889 minecraft:light_gray_concrete replace
fill ~476 ~168 ~11 ~476 ~168 ~661 minecraft:light_gray_concrete replace
fill ~486 ~168 ~11 ~486 ~168 ~301 minecraft:light_gray_concrete replace
fill ~444 ~168 ~13 ~444 ~168 ~741 minecraft:light_gray_concrete replace
fill ~458 ~168 ~13 ~458 ~168 ~825 minecraft:light_gray_concrete replace
fill ~472 ~168 ~13 ~472 ~168 ~597 minecraft:light_gray_concrete replace
fill ~490 ~168 ~13 ~490 ~168 ~365 minecraft:light_gray_concrete replace
fill ~446 ~168 ~15 ~446 ~168 ~749 minecraft:light_gray_concrete replace
fill ~460 ~168 ~15 ~460 ~168 ~861 minecraft:light_gray_concrete replace
fill ~474 ~168 ~15 ~474 ~168 ~633 minecraft:light_gray_concrete replace
fill ~488 ~168 ~15 ~488 ~168 ~329 minecraft:light_gray_concrete replace
setblock ~440 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~498 ~169 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~500 ~169 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~502 ~169 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~496 ~169 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~169 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~169 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~169 ~14 minecraft:light_gray_concrete replace
setblock ~496 ~169 ~230 minecraft:light_gray_concrete replace
setblock ~498 ~169 ~234 minecraft:light_gray_concrete replace
setblock ~482 ~169 ~262 minecraft:light_gray_concrete replace
setblock ~484 ~169 ~286 minecraft:light_gray_concrete replace
setblock ~486 ~169 ~302 minecraft:light_gray_concrete replace
setblock ~488 ~169 ~330 minecraft:light_gray_concrete replace
setblock ~490 ~169 ~366 minecraft:light_gray_concrete replace
setblock ~492 ~169 ~398 minecraft:light_gray_concrete replace
setblock ~494 ~169 ~430 minecraft:light_gray_concrete replace
setblock ~500 ~169 ~446 minecraft:light_gray_concrete replace
setblock ~468 ~169 ~534 minecraft:light_gray_concrete replace
setblock ~470 ~169 ~566 minecraft:light_gray_concrete replace
setblock ~472 ~169 ~598 minecraft:light_gray_concrete replace
setblock ~474 ~169 ~634 minecraft:light_gray_concrete replace
setblock ~476 ~169 ~662 minecraft:light_gray_concrete replace
setblock ~478 ~169 ~678 minecraft:light_gray_concrete replace
setblock ~480 ~169 ~702 minecraft:light_gray_concrete replace
setblock ~440 ~169 ~730 minecraft:light_gray_concrete replace
setblock ~442 ~169 ~734 minecraft:light_gray_concrete replace
setblock ~444 ~169 ~742 minecraft:light_gray_concrete replace
setblock ~446 ~169 ~750 minecraft:light_gray_concrete replace
setblock ~448 ~169 ~754 minecraft:light_gray_concrete replace
setblock ~450 ~169 ~758 minecraft:light_gray_concrete replace
setblock ~454 ~169 ~762 minecraft:light_gray_concrete replace
setblock ~456 ~169 ~794 minecraft:light_gray_concrete replace
setblock ~458 ~169 ~826 minecraft:light_gray_concrete replace
setblock ~460 ~169 ~862 minecraft:light_gray_concrete replace
setblock ~462 ~169 ~890 minecraft:light_gray_concrete replace
setblock ~464 ~169 ~906 minecraft:light_gray_concrete replace
setblock ~466 ~169 ~930 minecraft:light_gray_concrete replace
setblock ~502 ~169 ~962 minecraft:light_gray_concrete replace
setblock ~452 ~169 ~966 minecraft:light_gray_concrete replace
setblock ~440 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~498 ~171 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~500 ~171 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~502 ~171 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~496 ~171 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~171 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~171 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~171 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~171 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~171 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~171 ~14 minecraft:light_gray_concrete replace
fill ~499 ~172 ~2 ~553 ~172 ~2 minecraft:light_gray_concrete replace
fill ~501 ~172 ~4 ~553 ~172 ~4 minecraft:light_gray_concrete replace
fill ~503 ~172 ~6 ~553 ~172 ~6 minecraft:light_gray_concrete replace
fill ~497 ~172 ~8 ~553 ~172 ~8 minecraft:light_gray_concrete replace
setblock ~440 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~498 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~500 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~502 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~496 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~173 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~173 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~173 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~173 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~175 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~175 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~175 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~175 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~175 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~175 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~175 ~14 minecraft:light_gray_concrete replace
fill ~495 ~176 ~2 ~547 ~176 ~2 minecraft:light_gray_concrete replace
fill ~485 ~176 ~4 ~545 ~176 ~4 minecraft:light_gray_concrete replace
fill ~493 ~176 ~6 ~549 ~176 ~6 minecraft:light_gray_concrete replace
fill ~483 ~176 ~8 ~547 ~176 ~8 minecraft:light_gray_concrete replace
fill ~487 ~176 ~10 ~545 ~176 ~10 minecraft:light_gray_concrete replace
fill ~491 ~176 ~12 ~549 ~176 ~12 minecraft:light_gray_concrete replace
fill ~489 ~176 ~14 ~547 ~176 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~494 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~484 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~492 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~482 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~177 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~486 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~177 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~490 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~177 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~488 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~177 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~179 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~179 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~179 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~179 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~179 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~179 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~179 ~14 minecraft:light_gray_concrete replace
fill ~469 ~180 ~2 ~539 ~180 ~2 minecraft:light_gray_concrete replace
fill ~479 ~180 ~4 ~537 ~180 ~4 minecraft:light_gray_concrete replace
fill ~471 ~180 ~6 ~541 ~180 ~6 minecraft:light_gray_concrete replace
fill ~481 ~180 ~8 ~539 ~180 ~8 minecraft:light_gray_concrete replace
fill ~477 ~180 ~10 ~537 ~180 ~10 minecraft:light_gray_concrete replace
fill ~473 ~180 ~12 ~541 ~180 ~12 minecraft:light_gray_concrete replace
fill ~475 ~180 ~14 ~539 ~180 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~468 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~478 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~470 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~480 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~181 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~476 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~181 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~472 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~181 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~474 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~181 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~183 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~183 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~183 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~183 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~183 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~183 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~183 ~14 minecraft:light_gray_concrete replace
fill ~455 ~184 ~2 ~531 ~184 ~2 minecraft:light_gray_concrete replace
fill ~465 ~184 ~4 ~529 ~184 ~4 minecraft:light_gray_concrete replace
fill ~457 ~184 ~6 ~533 ~184 ~6 minecraft:light_gray_concrete replace
fill ~467 ~184 ~8 ~531 ~184 ~8 minecraft:light_gray_concrete replace
fill ~463 ~184 ~10 ~529 ~184 ~10 minecraft:light_gray_concrete replace
fill ~459 ~184 ~12 ~533 ~184 ~12 minecraft:light_gray_concrete replace
fill ~461 ~184 ~14 ~531 ~184 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~454 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~464 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~456 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~466 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~185 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~462 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~185 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~458 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~185 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~460 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~185 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~187 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~187 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~187 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~187 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~187 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~187 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~187 ~14 minecraft:light_gray_concrete replace
fill ~441 ~188 ~2 ~523 ~188 ~2 minecraft:light_gray_concrete replace
fill ~451 ~188 ~4 ~521 ~188 ~4 minecraft:light_gray_concrete replace
fill ~443 ~188 ~6 ~525 ~188 ~6 minecraft:light_gray_concrete replace
fill ~453 ~188 ~8 ~523 ~188 ~8 minecraft:light_gray_concrete replace
fill ~449 ~188 ~10 ~521 ~188 ~10 minecraft:light_gray_concrete replace
fill ~445 ~188 ~12 ~525 ~188 ~12 minecraft:light_gray_concrete replace
fill ~447 ~188 ~14 ~523 ~188 ~14 minecraft:light_gray_concrete replace
setblock ~440 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~524 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~2 minecraft:light_gray_concrete replace
setblock ~450 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~522 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~4 minecraft:light_gray_concrete replace
setblock ~442 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~526 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~6 minecraft:light_gray_concrete replace
setblock ~452 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~524 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~189 ~8 minecraft:light_gray_concrete replace
setblock ~448 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~522 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~189 ~10 minecraft:light_gray_concrete replace
setblock ~444 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~526 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~189 ~12 minecraft:light_gray_concrete replace
setblock ~446 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~524 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~189 ~14 minecraft:light_gray_concrete replace
setblock ~524 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~532 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~540 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~548 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~2 minecraft:light_gray_concrete replace
setblock ~522 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~530 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~538 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~546 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~4 minecraft:light_gray_concrete replace
setblock ~526 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~534 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~542 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~550 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~6 minecraft:light_gray_concrete replace
setblock ~524 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~532 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~540 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~548 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~554 ~191 ~8 minecraft:light_gray_concrete replace
setblock ~522 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~530 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~538 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~546 ~191 ~10 minecraft:light_gray_concrete replace
setblock ~526 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~534 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~542 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~550 ~191 ~12 minecraft:light_gray_concrete replace
setblock ~524 ~191 ~14 minecraft:light_gray_concrete replace
setblock ~532 ~191 ~14 minecraft:light_gray_concrete replace
setblock ~540 ~191 ~14 minecraft:light_gray_concrete replace
setblock ~548 ~191 ~14 minecraft:light_gray_concrete replace
fill ~523 ~193 ~2 ~525 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~531 ~193 ~2 ~533 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~539 ~193 ~2 ~541 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~547 ~193 ~2 ~549 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~2 minecraft:redstone_lamp[lit=false] replace
fill ~522 ~193 ~3 ~522 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~526 ~193 ~3 ~526 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~530 ~193 ~3 ~530 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~534 ~193 ~3 ~534 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~538 ~193 ~3 ~538 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~542 ~193 ~3 ~542 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~546 ~193 ~3 ~546 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
fill ~550 ~193 ~3 ~550 ~193 ~7 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~4 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~6 minecraft:redstone_lamp[lit=false] replace
fill ~523 ~193 ~8 ~525 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~531 ~193 ~8 ~533 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~539 ~193 ~8 ~541 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~547 ~193 ~8 ~549 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
setblock ~554 ~193 ~8 minecraft:redstone_lamp[lit=false] replace
fill ~522 ~193 ~9 ~522 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~526 ~193 ~9 ~526 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~530 ~193 ~9 ~530 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~534 ~193 ~9 ~534 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~538 ~193 ~9 ~538 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~542 ~193 ~9 ~542 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~546 ~193 ~9 ~546 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~550 ~193 ~9 ~550 ~193 ~13 minecraft:redstone_lamp[lit=false] replace
fill ~523 ~193 ~14 ~525 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~531 ~193 ~14 ~533 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~539 ~193 ~14 ~541 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~547 ~193 ~14 ~549 ~193 ~14 minecraft:redstone_lamp[lit=false] replace
fill ~53 ~1 ~94 ~55 ~1 ~94 minecraft:redstone_wire replace
setblock ~56 ~1 ~94 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~94 minecraft:redstone_wire replace
setblock ~58 ~1 ~94 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~49 ~1 ~96 ~55 ~1 ~96 minecraft:redstone_wire replace
setblock ~56 ~1 ~96 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~96 minecraft:redstone_wire replace
setblock ~58 ~1 ~96 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~45 ~1 ~98 ~55 ~1 ~98 minecraft:redstone_wire replace
setblock ~56 ~1 ~98 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~98 minecraft:redstone_wire replace
setblock ~58 ~1 ~98 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~41 ~1 ~100 ~43 ~1 ~100 minecraft:redstone_wire replace
setblock ~44 ~1 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~100 ~55 ~1 ~100 minecraft:redstone_wire replace
setblock ~56 ~1 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~100 minecraft:redstone_wire replace
setblock ~58 ~1 ~100 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~37 ~1 ~102 ~43 ~1 ~102 minecraft:redstone_wire replace
setblock ~44 ~1 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~102 ~55 ~1 ~102 minecraft:redstone_wire replace
setblock ~56 ~1 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~102 minecraft:redstone_wire replace
setblock ~58 ~1 ~102 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~33 ~1 ~104 ~43 ~1 ~104 minecraft:redstone_wire replace
setblock ~44 ~1 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~104 ~55 ~1 ~104 minecraft:redstone_wire replace
setblock ~56 ~1 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~104 minecraft:redstone_wire replace
setblock ~58 ~1 ~104 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~29 ~1 ~106 ~31 ~1 ~106 minecraft:redstone_wire replace
setblock ~32 ~1 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~106 ~43 ~1 ~106 minecraft:redstone_wire replace
setblock ~44 ~1 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~106 ~55 ~1 ~106 minecraft:redstone_wire replace
setblock ~56 ~1 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~106 minecraft:redstone_wire replace
setblock ~58 ~1 ~106 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~25 ~1 ~108 ~31 ~1 ~108 minecraft:redstone_wire replace
setblock ~32 ~1 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~108 ~43 ~1 ~108 minecraft:redstone_wire replace
setblock ~44 ~1 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~108 ~55 ~1 ~108 minecraft:redstone_wire replace
setblock ~56 ~1 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~108 minecraft:redstone_wire replace
setblock ~58 ~1 ~108 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~21 ~1 ~110 ~31 ~1 ~110 minecraft:redstone_wire replace
setblock ~32 ~1 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~110 ~43 ~1 ~110 minecraft:redstone_wire replace
setblock ~44 ~1 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~110 ~55 ~1 ~110 minecraft:redstone_wire replace
setblock ~56 ~1 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~110 minecraft:redstone_wire replace
setblock ~58 ~1 ~110 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~17 ~1 ~112 ~19 ~1 ~112 minecraft:redstone_wire replace
setblock ~20 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~112 ~31 ~1 ~112 minecraft:redstone_wire replace
setblock ~32 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~112 ~43 ~1 ~112 minecraft:redstone_wire replace
setblock ~44 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~112 ~55 ~1 ~112 minecraft:redstone_wire replace
setblock ~56 ~1 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~112 minecraft:redstone_wire replace
setblock ~58 ~1 ~112 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~13 ~1 ~114 ~19 ~1 ~114 minecraft:redstone_wire replace
setblock ~20 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~114 ~31 ~1 ~114 minecraft:redstone_wire replace
setblock ~32 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~114 ~43 ~1 ~114 minecraft:redstone_wire replace
setblock ~44 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~114 ~55 ~1 ~114 minecraft:redstone_wire replace
setblock ~56 ~1 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~114 minecraft:redstone_wire replace
setblock ~58 ~1 ~114 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~9 ~1 ~116 ~19 ~1 ~116 minecraft:redstone_wire replace
setblock ~20 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~116 ~31 ~1 ~116 minecraft:redstone_wire replace
setblock ~32 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~116 ~43 ~1 ~116 minecraft:redstone_wire replace
setblock ~44 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~116 ~55 ~1 ~116 minecraft:redstone_wire replace
setblock ~56 ~1 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~116 minecraft:redstone_wire replace
setblock ~58 ~1 ~116 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~5 ~1 ~118 ~7 ~1 ~118 minecraft:redstone_wire replace
setblock ~8 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~1 ~118 ~19 ~1 ~118 minecraft:redstone_wire replace
setblock ~20 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~118 ~31 ~1 ~118 minecraft:redstone_wire replace
setblock ~32 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~118 ~43 ~1 ~118 minecraft:redstone_wire replace
setblock ~44 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~118 ~55 ~1 ~118 minecraft:redstone_wire replace
setblock ~56 ~1 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~118 minecraft:redstone_wire replace
setblock ~58 ~1 ~118 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~1 ~1 ~120 ~7 ~1 ~120 minecraft:redstone_wire replace
setblock ~8 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~1 ~120 ~19 ~1 ~120 minecraft:redstone_wire replace
setblock ~20 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~1 ~120 ~31 ~1 ~120 minecraft:redstone_wire replace
setblock ~32 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~1 ~120 ~43 ~1 ~120 minecraft:redstone_wire replace
setblock ~44 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~1 ~120 ~55 ~1 ~120 minecraft:redstone_wire replace
setblock ~56 ~1 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~1 ~120 minecraft:redstone_wire replace
setblock ~58 ~1 ~120 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~52 ~2 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~2 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~2 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~2 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~2 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~2 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~2 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~2 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~2 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~2 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~2 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~2 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~2 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~2 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~4 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~4 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~4 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~4 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~4 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~4 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~4 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~4 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~4 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~4 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~4 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~4 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~4 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~4 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~55 ~5 ~94 minecraft:redstone_wire replace
setblock ~56 ~5 ~94 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~94 minecraft:redstone_wire replace
setblock ~58 ~5 ~94 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~51 ~5 ~96 ~55 ~5 ~96 minecraft:redstone_wire replace
setblock ~56 ~5 ~96 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~96 minecraft:redstone_wire replace
setblock ~58 ~5 ~96 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~47 ~5 ~98 ~55 ~5 ~98 minecraft:redstone_wire replace
setblock ~56 ~5 ~98 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~98 minecraft:redstone_wire replace
setblock ~58 ~5 ~98 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~43 ~5 ~100 minecraft:redstone_wire replace
setblock ~44 ~5 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~100 ~55 ~5 ~100 minecraft:redstone_wire replace
setblock ~56 ~5 ~100 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~100 minecraft:redstone_wire replace
setblock ~58 ~5 ~100 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~39 ~5 ~102 ~43 ~5 ~102 minecraft:redstone_wire replace
setblock ~44 ~5 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~102 ~55 ~5 ~102 minecraft:redstone_wire replace
setblock ~56 ~5 ~102 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~102 minecraft:redstone_wire replace
setblock ~58 ~5 ~102 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~35 ~5 ~104 ~43 ~5 ~104 minecraft:redstone_wire replace
setblock ~44 ~5 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~104 ~55 ~5 ~104 minecraft:redstone_wire replace
setblock ~56 ~5 ~104 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~104 minecraft:redstone_wire replace
setblock ~58 ~5 ~104 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~31 ~5 ~106 minecraft:redstone_wire replace
setblock ~32 ~5 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~106 ~43 ~5 ~106 minecraft:redstone_wire replace
setblock ~44 ~5 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~106 ~55 ~5 ~106 minecraft:redstone_wire replace
setblock ~56 ~5 ~106 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~106 minecraft:redstone_wire replace
setblock ~58 ~5 ~106 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~27 ~5 ~108 ~31 ~5 ~108 minecraft:redstone_wire replace
setblock ~32 ~5 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~108 ~43 ~5 ~108 minecraft:redstone_wire replace
setblock ~44 ~5 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~108 ~55 ~5 ~108 minecraft:redstone_wire replace
setblock ~56 ~5 ~108 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~108 minecraft:redstone_wire replace
setblock ~58 ~5 ~108 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~23 ~5 ~110 ~31 ~5 ~110 minecraft:redstone_wire replace
setblock ~32 ~5 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~110 ~43 ~5 ~110 minecraft:redstone_wire replace
setblock ~44 ~5 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~110 ~55 ~5 ~110 minecraft:redstone_wire replace
setblock ~56 ~5 ~110 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~110 minecraft:redstone_wire replace
setblock ~58 ~5 ~110 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~19 ~5 ~112 minecraft:redstone_wire replace
setblock ~20 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~112 ~31 ~5 ~112 minecraft:redstone_wire replace
setblock ~32 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~112 ~43 ~5 ~112 minecraft:redstone_wire replace
setblock ~44 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~112 ~55 ~5 ~112 minecraft:redstone_wire replace
setblock ~56 ~5 ~112 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~112 minecraft:redstone_wire replace
setblock ~58 ~5 ~112 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~15 ~5 ~114 ~19 ~5 ~114 minecraft:redstone_wire replace
setblock ~20 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~114 ~31 ~5 ~114 minecraft:redstone_wire replace
setblock ~32 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~114 ~43 ~5 ~114 minecraft:redstone_wire replace
setblock ~44 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~114 ~55 ~5 ~114 minecraft:redstone_wire replace
setblock ~56 ~5 ~114 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~114 minecraft:redstone_wire replace
setblock ~58 ~5 ~114 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~11 ~5 ~116 ~19 ~5 ~116 minecraft:redstone_wire replace
setblock ~20 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~116 ~31 ~5 ~116 minecraft:redstone_wire replace
setblock ~32 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~116 ~43 ~5 ~116 minecraft:redstone_wire replace
setblock ~44 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~116 ~55 ~5 ~116 minecraft:redstone_wire replace
setblock ~56 ~5 ~116 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~116 minecraft:redstone_wire replace
setblock ~58 ~5 ~116 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~7 ~5 ~118 minecraft:redstone_wire replace
setblock ~8 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~5 ~118 ~19 ~5 ~118 minecraft:redstone_wire replace
setblock ~20 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~118 ~31 ~5 ~118 minecraft:redstone_wire replace
setblock ~32 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~118 ~43 ~5 ~118 minecraft:redstone_wire replace
setblock ~44 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~118 ~55 ~5 ~118 minecraft:redstone_wire replace
setblock ~56 ~5 ~118 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~118 minecraft:redstone_wire replace
setblock ~58 ~5 ~118 minecraft:lever[face=floor,facing=north,powered=false] replace
fill ~3 ~5 ~120 ~7 ~5 ~120 minecraft:redstone_wire replace
setblock ~8 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~9 ~5 ~120 ~19 ~5 ~120 minecraft:redstone_wire replace
setblock ~20 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~21 ~5 ~120 ~31 ~5 ~120 minecraft:redstone_wire replace
setblock ~32 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~33 ~5 ~120 ~43 ~5 ~120 minecraft:redstone_wire replace
setblock ~44 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
fill ~45 ~5 ~120 ~55 ~5 ~120 minecraft:redstone_wire replace
setblock ~56 ~5 ~120 minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~57 ~5 ~120 minecraft:redstone_wire replace
setblock ~58 ~5 ~120 minecraft:lever[face=floor,facing=north,powered=false] replace
setblock ~52 ~6 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~6 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~6 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~6 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~6 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~6 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~6 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~6 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~6 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~38 ~6 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~6 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~6 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~6 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~6 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~6 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~6 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~6 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~6 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~6 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~6 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~6 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~6 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~6 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~6 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~6 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~6 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~6 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~6 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~8 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~8 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~8 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~8 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~8 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~8 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~8 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~8 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~8 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~38 ~8 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~8 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~8 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~8 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~8 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~8 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~8 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~8 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~8 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~8 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~8 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~8 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~8 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~8 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~8 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~8 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~8 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~8 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~8 ~120 minecraft:redstone_torch[lit=true] replace
fill ~38 ~9 ~3 ~38 ~9 ~4 minecraft:redstone_wire replace
setblock ~38 ~9 ~5 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~38 ~9 ~6 ~38 ~9 ~16 minecraft:redstone_wire replace
setblock ~34 ~9 ~7 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~34 ~9 ~8 ~34 ~9 ~18 minecraft:redstone_wire replace
fill ~30 ~9 ~11 ~30 ~9 ~20 minecraft:redstone_wire replace
fill ~26 ~9 ~15 ~26 ~9 ~22 minecraft:redstone_wire replace
setblock ~38 ~9 ~17 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~38 ~9 ~18 ~38 ~9 ~28 minecraft:redstone_wire replace
fill ~22 ~9 ~19 ~22 ~9 ~24 minecraft:redstone_wire replace
setblock ~34 ~9 ~19 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~34 ~9 ~20 ~34 ~9 ~30 minecraft:redstone_wire replace
setblock ~30 ~9 ~21 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~30 ~9 ~22 ~30 ~9 ~32 minecraft:redstone_wire replace
fill ~18 ~9 ~23 ~18 ~9 ~26 minecraft:redstone_wire replace
setblock ~26 ~9 ~23 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~26 ~9 ~24 ~26 ~9 ~34 minecraft:redstone_wire replace
setblock ~22 ~9 ~25 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~22 ~9 ~26 ~22 ~9 ~36 minecraft:redstone_wire replace
fill ~14 ~9 ~27 ~14 ~9 ~28 minecraft:redstone_wire replace
setblock ~18 ~9 ~27 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~18 ~9 ~28 ~18 ~9 ~38 minecraft:redstone_wire replace
setblock ~14 ~9 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~29 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~30 ~14 ~9 ~40 minecraft:redstone_wire replace
fill ~38 ~9 ~30 ~38 ~9 ~40 minecraft:redstone_wire replace
setblock ~10 ~9 ~31 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~31 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~10 ~9 ~32 ~10 ~9 ~42 minecraft:redstone_wire replace
fill ~34 ~9 ~32 ~34 ~9 ~42 minecraft:redstone_wire replace
setblock ~30 ~9 ~33 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~30 ~9 ~34 ~30 ~9 ~44 minecraft:redstone_wire replace
fill ~6 ~9 ~35 ~6 ~9 ~44 minecraft:redstone_wire replace
setblock ~26 ~9 ~35 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~26 ~9 ~36 ~26 ~9 ~46 minecraft:redstone_wire replace
setblock ~22 ~9 ~37 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~22 ~9 ~38 ~22 ~9 ~48 minecraft:redstone_wire replace
fill ~2 ~9 ~39 ~2 ~9 ~46 minecraft:redstone_wire replace
setblock ~18 ~9 ~39 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~18 ~9 ~40 ~18 ~9 ~50 minecraft:redstone_wire replace
setblock ~14 ~9 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~41 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~42 ~14 ~9 ~52 minecraft:redstone_wire replace
fill ~38 ~9 ~42 ~38 ~9 ~52 minecraft:redstone_wire replace
setblock ~10 ~9 ~43 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~43 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~36 ~9 ~43 ~36 ~9 ~52 minecraft:redstone_wire replace
fill ~10 ~9 ~44 ~10 ~9 ~54 minecraft:redstone_wire replace
fill ~34 ~9 ~44 ~34 ~9 ~54 minecraft:redstone_wire replace
setblock ~6 ~9 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~45 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~6 ~9 ~46 ~6 ~9 ~56 minecraft:redstone_wire replace
fill ~30 ~9 ~46 ~30 ~9 ~56 minecraft:redstone_wire replace
setblock ~2 ~9 ~47 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~47 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~32 ~9 ~47 ~32 ~9 ~54 minecraft:redstone_wire replace
fill ~2 ~9 ~48 ~2 ~9 ~58 minecraft:redstone_wire replace
fill ~26 ~9 ~48 ~26 ~9 ~58 minecraft:redstone_wire replace
setblock ~22 ~9 ~49 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~22 ~9 ~50 ~22 ~9 ~60 minecraft:redstone_wire replace
setblock ~18 ~9 ~51 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~28 ~9 ~51 ~28 ~9 ~56 minecraft:redstone_wire replace
fill ~18 ~9 ~52 ~18 ~9 ~62 minecraft:redstone_wire replace
setblock ~14 ~9 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~53 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~54 ~14 ~9 ~64 minecraft:redstone_wire replace
fill ~36 ~9 ~54 ~36 ~9 ~64 minecraft:redstone_wire replace
fill ~38 ~9 ~54 ~38 ~9 ~64 minecraft:redstone_wire replace
setblock ~10 ~9 ~55 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~24 ~9 ~55 ~24 ~9 ~58 minecraft:redstone_wire replace
setblock ~32 ~9 ~55 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~55 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~10 ~9 ~56 ~10 ~9 ~66 minecraft:redstone_wire replace
fill ~32 ~9 ~56 ~32 ~9 ~66 minecraft:redstone_wire replace
fill ~34 ~9 ~56 ~34 ~9 ~66 minecraft:redstone_wire replace
setblock ~6 ~9 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~57 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~6 ~9 ~58 ~6 ~9 ~68 minecraft:redstone_wire replace
fill ~28 ~9 ~58 ~28 ~9 ~68 minecraft:redstone_wire replace
fill ~30 ~9 ~58 ~30 ~9 ~68 minecraft:redstone_wire replace
setblock ~2 ~9 ~59 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~59 ~20 ~9 ~60 minecraft:redstone_wire replace
setblock ~24 ~9 ~59 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~59 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~2 ~9 ~60 ~2 ~9 ~70 minecraft:redstone_wire replace
fill ~24 ~9 ~60 ~24 ~9 ~70 minecraft:redstone_wire replace
fill ~26 ~9 ~60 ~26 ~9 ~70 minecraft:redstone_wire replace
setblock ~20 ~9 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~61 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~62 ~20 ~9 ~72 minecraft:redstone_wire replace
fill ~22 ~9 ~62 ~22 ~9 ~72 minecraft:redstone_wire replace
setblock ~16 ~9 ~63 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~63 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~16 ~9 ~64 ~16 ~9 ~74 minecraft:redstone_wire replace
fill ~18 ~9 ~64 ~18 ~9 ~74 minecraft:redstone_wire replace
setblock ~14 ~9 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~65 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~14 ~9 ~66 ~14 ~9 ~76 minecraft:redstone_wire replace
fill ~36 ~9 ~66 ~36 ~9 ~76 minecraft:redstone_wire replace
fill ~38 ~9 ~66 ~38 ~9 ~76 minecraft:redstone_wire replace
setblock ~10 ~9 ~67 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~12 ~9 ~67 ~12 ~9 ~76 minecraft:redstone_wire replace
setblock ~32 ~9 ~67 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~67 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~10 ~9 ~68 ~10 ~9 ~78 minecraft:redstone_wire replace
fill ~32 ~9 ~68 ~32 ~9 ~78 minecraft:redstone_wire replace
fill ~34 ~9 ~68 ~34 ~9 ~78 minecraft:redstone_wire replace
setblock ~6 ~9 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~69 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~6 ~9 ~70 ~6 ~9 ~80 minecraft:redstone_wire replace
fill ~28 ~9 ~70 ~28 ~9 ~80 minecraft:redstone_wire replace
fill ~30 ~9 ~70 ~30 ~9 ~80 minecraft:redstone_wire replace
setblock ~2 ~9 ~71 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~71 ~8 ~9 ~78 minecraft:redstone_wire replace
setblock ~24 ~9 ~71 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~71 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~2 ~9 ~72 ~2 ~9 ~82 minecraft:redstone_wire replace
fill ~24 ~9 ~72 ~24 ~9 ~82 minecraft:redstone_wire replace
fill ~26 ~9 ~72 ~26 ~9 ~82 minecraft:redstone_wire replace
setblock ~20 ~9 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~73 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~74 ~20 ~9 ~84 minecraft:redstone_wire replace
fill ~22 ~9 ~74 ~22 ~9 ~84 minecraft:redstone_wire replace
fill ~4 ~9 ~75 ~4 ~9 ~80 minecraft:redstone_wire replace
setblock ~16 ~9 ~75 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~75 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~16 ~9 ~76 ~16 ~9 ~86 minecraft:redstone_wire replace
fill ~18 ~9 ~76 ~18 ~9 ~86 minecraft:redstone_wire replace
setblock ~12 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~77 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~12 ~9 ~78 ~12 ~9 ~88 minecraft:redstone_wire replace
fill ~14 ~9 ~78 ~14 ~9 ~88 minecraft:redstone_wire replace
fill ~36 ~9 ~78 ~36 ~9 ~88 minecraft:redstone_wire replace
fill ~38 ~9 ~78 ~38 ~9 ~88 minecraft:redstone_wire replace
fill ~0 ~9 ~79 ~0 ~9 ~82 minecraft:redstone_wire replace
setblock ~8 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~32 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~79 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~80 ~8 ~9 ~90 minecraft:redstone_wire replace
fill ~10 ~9 ~80 ~10 ~9 ~90 minecraft:redstone_wire replace
fill ~32 ~9 ~80 ~32 ~9 ~90 minecraft:redstone_wire replace
fill ~34 ~9 ~80 ~34 ~9 ~90 minecraft:redstone_wire replace
setblock ~4 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~81 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~4 ~9 ~82 ~4 ~9 ~92 minecraft:redstone_wire replace
fill ~6 ~9 ~82 ~6 ~9 ~92 minecraft:redstone_wire replace
fill ~28 ~9 ~82 ~28 ~9 ~92 minecraft:redstone_wire replace
fill ~30 ~9 ~82 ~30 ~9 ~92 minecraft:redstone_wire replace
setblock ~0 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~24 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~83 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~0 ~9 ~84 ~0 ~9 ~94 minecraft:redstone_wire replace
fill ~2 ~9 ~84 ~2 ~9 ~94 minecraft:redstone_wire replace
fill ~24 ~9 ~84 ~24 ~9 ~94 minecraft:redstone_wire replace
fill ~26 ~9 ~84 ~26 ~9 ~94 minecraft:redstone_wire replace
setblock ~20 ~9 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~85 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~20 ~9 ~86 ~20 ~9 ~96 minecraft:redstone_wire replace
fill ~22 ~9 ~86 ~22 ~9 ~96 minecraft:redstone_wire replace
setblock ~16 ~9 ~87 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~87 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~16 ~9 ~88 ~16 ~9 ~98 minecraft:redstone_wire replace
fill ~18 ~9 ~88 ~18 ~9 ~98 minecraft:redstone_wire replace
setblock ~12 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~89 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~12 ~9 ~90 ~12 ~9 ~100 minecraft:redstone_wire replace
fill ~14 ~9 ~90 ~14 ~9 ~100 minecraft:redstone_wire replace
fill ~36 ~9 ~90 ~36 ~9 ~100 minecraft:redstone_wire replace
fill ~38 ~9 ~90 ~38 ~9 ~100 minecraft:redstone_wire replace
setblock ~8 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~32 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~91 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~92 ~8 ~9 ~102 minecraft:redstone_wire replace
fill ~10 ~9 ~92 ~10 ~9 ~102 minecraft:redstone_wire replace
fill ~32 ~9 ~92 ~32 ~9 ~102 minecraft:redstone_wire replace
fill ~34 ~9 ~92 ~34 ~9 ~102 minecraft:redstone_wire replace
setblock ~4 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~93 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~4 ~9 ~94 ~4 ~9 ~104 minecraft:redstone_wire replace
fill ~6 ~9 ~94 ~6 ~9 ~104 minecraft:redstone_wire replace
fill ~28 ~9 ~94 ~28 ~9 ~104 minecraft:redstone_wire replace
fill ~30 ~9 ~94 ~30 ~9 ~104 minecraft:redstone_wire replace
setblock ~0 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~24 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~52 ~9 ~95 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~0 ~9 ~96 ~0 ~9 ~106 minecraft:redstone_wire replace
fill ~2 ~9 ~96 ~2 ~9 ~106 minecraft:redstone_wire replace
fill ~24 ~9 ~96 ~24 ~9 ~106 minecraft:redstone_wire replace
fill ~26 ~9 ~96 ~26 ~9 ~106 minecraft:redstone_wire replace
fill ~52 ~9 ~96 ~52 ~9 ~97 minecraft:redstone_wire replace
setblock ~20 ~9 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~97 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~48 ~9 ~97 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~50 ~9 ~97 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~20 ~9 ~98 ~20 ~9 ~108 minecraft:redstone_wire replace
fill ~22 ~9 ~98 ~22 ~9 ~108 minecraft:redstone_wire replace
fill ~48 ~9 ~98 ~48 ~9 ~105 minecraft:redstone_wire replace
fill ~50 ~9 ~98 ~50 ~9 ~101 minecraft:redstone_wire replace
setblock ~16 ~9 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~44 ~9 ~99 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~46 ~9 ~99 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~16 ~9 ~100 ~16 ~9 ~110 minecraft:redstone_wire replace
fill ~18 ~9 ~100 ~18 ~9 ~110 minecraft:redstone_wire replace
fill ~44 ~9 ~100 ~44 ~9 ~110 minecraft:redstone_wire replace
fill ~46 ~9 ~100 ~46 ~9 ~109 minecraft:redstone_wire replace
setblock ~12 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~36 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~9 ~101 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~40 ~9 ~101 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~42 ~9 ~101 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~12 ~9 ~102 ~12 ~9 ~112 minecraft:redstone_wire replace
fill ~14 ~9 ~102 ~14 ~9 ~112 minecraft:redstone_wire replace
fill ~40 ~9 ~102 ~40 ~9 ~112 minecraft:redstone_wire replace
fill ~42 ~9 ~102 ~42 ~9 ~112 minecraft:redstone_wire replace
setblock ~8 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~32 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~34 ~9 ~103 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~8 ~9 ~104 ~8 ~9 ~114 minecraft:redstone_wire replace
fill ~10 ~9 ~104 ~10 ~9 ~114 minecraft:redstone_wire replace
setblock ~4 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~28 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~30 ~9 ~105 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~4 ~9 ~106 ~4 ~9 ~116 minecraft:redstone_wire replace
fill ~6 ~9 ~106 ~6 ~9 ~116 minecraft:redstone_wire replace
setblock ~0 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~24 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~26 ~9 ~107 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~0 ~9 ~108 ~0 ~9 ~118 minecraft:redstone_wire replace
fill ~2 ~9 ~108 ~2 ~9 ~118 minecraft:redstone_wire replace
setblock ~20 ~9 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~22 ~9 ~109 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~16 ~9 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~18 ~9 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~44 ~9 ~111 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~44 ~9 ~112 ~44 ~9 ~113 minecraft:redstone_wire replace
setblock ~12 ~9 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~14 ~9 ~113 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~40 ~9 ~113 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
setblock ~42 ~9 ~113 minecraft:repeater[delay=1,facing=north,locked=false,powered=false] replace
fill ~40 ~9 ~114 ~40 ~9 ~121 minecraft:redstone_wire replace
fill ~42 ~9 ~114 ~42 ~9 ~117 minecraft:redstone_wire replace
setblock ~8 ~9 ~115 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~10 ~9 ~115 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~4 ~9 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~6 ~9 ~117 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~0 ~9 ~119 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~2 ~9 ~119 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~38 ~10 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~10 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~10 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~10 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~10 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~10 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~10 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~10 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~10 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~10 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~10 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~10 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~10 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~10 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~10 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~10 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~10 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~10 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~10 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~10 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~10 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~10 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~10 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~10 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~10 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~10 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~10 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~10 ~122 minecraft:redstone_torch[lit=true] replace
setblock ~38 ~12 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~34 ~12 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~30 ~12 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~26 ~12 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~22 ~12 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~18 ~12 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~14 ~12 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~10 ~12 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~6 ~12 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~2 ~12 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~36 ~12 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~32 ~12 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~28 ~12 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~24 ~12 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~20 ~12 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~16 ~12 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~12 ~12 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~8 ~12 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~4 ~12 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~0 ~12 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~54 ~12 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~52 ~12 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~50 ~12 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~48 ~12 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~46 ~12 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~44 ~12 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~42 ~12 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~40 ~12 ~122 minecraft:redstone_torch[lit=true] replace
setblock ~39 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~2 ~50 ~13 ~2 minecraft:redstone_wire replace
setblock ~51 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~2 ~62 ~13 ~2 minecraft:redstone_wire replace
setblock ~63 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~2 ~74 ~13 ~2 minecraft:redstone_wire replace
setblock ~75 ~13 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~35 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~36 ~13 ~6 ~46 ~13 ~6 minecraft:redstone_wire replace
setblock ~47 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~6 ~58 ~13 ~6 minecraft:redstone_wire replace
setblock ~59 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~6 ~70 ~13 ~6 minecraft:redstone_wire replace
setblock ~71 ~13 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~72 ~13 ~6 ~75 ~13 ~6 minecraft:redstone_wire replace
setblock ~31 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~32 ~13 ~10 ~42 ~13 ~10 minecraft:redstone_wire replace
setblock ~43 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~10 ~54 ~13 ~10 minecraft:redstone_wire replace
setblock ~55 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~10 ~66 ~13 ~10 minecraft:redstone_wire replace
setblock ~67 ~13 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~68 ~13 ~10 ~75 ~13 ~10 minecraft:redstone_wire replace
setblock ~27 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~28 ~13 ~14 ~38 ~13 ~14 minecraft:redstone_wire replace
setblock ~39 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~14 ~50 ~13 ~14 minecraft:redstone_wire replace
setblock ~51 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~14 ~62 ~13 ~14 minecraft:redstone_wire replace
setblock ~63 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~14 ~74 ~13 ~14 minecraft:redstone_wire replace
setblock ~75 ~13 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~23 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~24 ~13 ~18 ~34 ~13 ~18 minecraft:redstone_wire replace
setblock ~35 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~36 ~13 ~18 ~46 ~13 ~18 minecraft:redstone_wire replace
setblock ~47 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~18 ~58 ~13 ~18 minecraft:redstone_wire replace
setblock ~59 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~18 ~70 ~13 ~18 minecraft:redstone_wire replace
setblock ~71 ~13 ~18 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~72 ~13 ~18 ~75 ~13 ~18 minecraft:redstone_wire replace
setblock ~19 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~20 ~13 ~22 ~30 ~13 ~22 minecraft:redstone_wire replace
setblock ~31 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~32 ~13 ~22 ~42 ~13 ~22 minecraft:redstone_wire replace
setblock ~43 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~22 ~54 ~13 ~22 minecraft:redstone_wire replace
setblock ~55 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~22 ~66 ~13 ~22 minecraft:redstone_wire replace
setblock ~67 ~13 ~22 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~68 ~13 ~22 ~75 ~13 ~22 minecraft:redstone_wire replace
setblock ~15 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~16 ~13 ~26 ~26 ~13 ~26 minecraft:redstone_wire replace
setblock ~27 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~28 ~13 ~26 ~38 ~13 ~26 minecraft:redstone_wire replace
setblock ~39 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~26 ~50 ~13 ~26 minecraft:redstone_wire replace
setblock ~51 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~26 ~62 ~13 ~26 minecraft:redstone_wire replace
setblock ~63 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~26 ~74 ~13 ~26 minecraft:redstone_wire replace
setblock ~75 ~13 ~26 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~11 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~12 ~13 ~30 ~22 ~13 ~30 minecraft:redstone_wire replace
setblock ~23 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~24 ~13 ~30 ~34 ~13 ~30 minecraft:redstone_wire replace
setblock ~35 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~36 ~13 ~30 ~46 ~13 ~30 minecraft:redstone_wire replace
setblock ~47 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~30 ~58 ~13 ~30 minecraft:redstone_wire replace
setblock ~59 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~30 ~70 ~13 ~30 minecraft:redstone_wire replace
setblock ~71 ~13 ~30 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~72 ~13 ~30 ~75 ~13 ~30 minecraft:redstone_wire replace
setblock ~7 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~8 ~13 ~34 ~18 ~13 ~34 minecraft:redstone_wire replace
setblock ~19 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~20 ~13 ~34 ~30 ~13 ~34 minecraft:redstone_wire replace
setblock ~31 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~32 ~13 ~34 ~42 ~13 ~34 minecraft:redstone_wire replace
setblock ~43 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~34 ~54 ~13 ~34 minecraft:redstone_wire replace
setblock ~55 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~34 ~66 ~13 ~34 minecraft:redstone_wire replace
setblock ~67 ~13 ~34 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~68 ~13 ~34 ~75 ~13 ~34 minecraft:redstone_wire replace
setblock ~3 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~4 ~13 ~38 ~14 ~13 ~38 minecraft:redstone_wire replace
setblock ~15 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~16 ~13 ~38 ~26 ~13 ~38 minecraft:redstone_wire replace
setblock ~27 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~28 ~13 ~38 ~38 ~13 ~38 minecraft:redstone_wire replace
setblock ~39 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~40 ~13 ~38 ~50 ~13 ~38 minecraft:redstone_wire replace
setblock ~51 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~38 ~62 ~13 ~38 minecraft:redstone_wire replace
setblock ~63 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~64 ~13 ~38 ~74 ~13 ~38 minecraft:redstone_wire replace
setblock ~75 ~13 ~38 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~37 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~42 ~48 ~13 ~42 minecraft:redstone_wire replace
setblock ~49 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~42 ~60 ~13 ~42 minecraft:redstone_wire replace
setblock ~61 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~42 ~72 ~13 ~42 minecraft:redstone_wire replace
setblock ~73 ~13 ~42 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~42 ~75 ~13 ~42 minecraft:redstone_wire replace
setblock ~33 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~34 ~13 ~46 ~44 ~13 ~46 minecraft:redstone_wire replace
setblock ~45 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~46 ~56 ~13 ~46 minecraft:redstone_wire replace
setblock ~57 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~46 ~68 ~13 ~46 minecraft:redstone_wire replace
setblock ~69 ~13 ~46 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~70 ~13 ~46 ~75 ~13 ~46 minecraft:redstone_wire replace
setblock ~29 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~30 ~13 ~50 ~40 ~13 ~50 minecraft:redstone_wire replace
setblock ~41 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~50 ~52 ~13 ~50 minecraft:redstone_wire replace
setblock ~53 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~50 ~64 ~13 ~50 minecraft:redstone_wire replace
setblock ~65 ~13 ~50 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~66 ~13 ~50 ~75 ~13 ~50 minecraft:redstone_wire replace
setblock ~25 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~26 ~13 ~54 ~36 ~13 ~54 minecraft:redstone_wire replace
setblock ~37 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~54 ~48 ~13 ~54 minecraft:redstone_wire replace
setblock ~49 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~54 ~60 ~13 ~54 minecraft:redstone_wire replace
setblock ~61 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~54 ~72 ~13 ~54 minecraft:redstone_wire replace
setblock ~73 ~13 ~54 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~54 ~75 ~13 ~54 minecraft:redstone_wire replace
setblock ~21 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~22 ~13 ~58 ~32 ~13 ~58 minecraft:redstone_wire replace
setblock ~33 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~34 ~13 ~58 ~44 ~13 ~58 minecraft:redstone_wire replace
setblock ~45 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~58 ~56 ~13 ~58 minecraft:redstone_wire replace
setblock ~57 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~58 ~68 ~13 ~58 minecraft:redstone_wire replace
setblock ~69 ~13 ~58 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~70 ~13 ~58 ~75 ~13 ~58 minecraft:redstone_wire replace
setblock ~17 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~18 ~13 ~62 ~28 ~13 ~62 minecraft:redstone_wire replace
setblock ~29 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~30 ~13 ~62 ~40 ~13 ~62 minecraft:redstone_wire replace
setblock ~41 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~62 ~52 ~13 ~62 minecraft:redstone_wire replace
setblock ~53 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~62 ~64 ~13 ~62 minecraft:redstone_wire replace
setblock ~65 ~13 ~62 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~66 ~13 ~62 ~75 ~13 ~62 minecraft:redstone_wire replace
setblock ~13 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~14 ~13 ~66 ~24 ~13 ~66 minecraft:redstone_wire replace
setblock ~25 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~26 ~13 ~66 ~36 ~13 ~66 minecraft:redstone_wire replace
setblock ~37 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~66 ~48 ~13 ~66 minecraft:redstone_wire replace
setblock ~49 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~66 ~60 ~13 ~66 minecraft:redstone_wire replace
setblock ~61 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~66 ~72 ~13 ~66 minecraft:redstone_wire replace
setblock ~73 ~13 ~66 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~66 ~75 ~13 ~66 minecraft:redstone_wire replace
setblock ~9 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~10 ~13 ~70 ~20 ~13 ~70 minecraft:redstone_wire replace
setblock ~21 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~22 ~13 ~70 ~32 ~13 ~70 minecraft:redstone_wire replace
setblock ~33 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~34 ~13 ~70 ~44 ~13 ~70 minecraft:redstone_wire replace
setblock ~45 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~70 ~56 ~13 ~70 minecraft:redstone_wire replace
setblock ~57 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~70 ~68 ~13 ~70 minecraft:redstone_wire replace
setblock ~69 ~13 ~70 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~70 ~13 ~70 ~75 ~13 ~70 minecraft:redstone_wire replace
setblock ~5 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~6 ~13 ~74 ~16 ~13 ~74 minecraft:redstone_wire replace
setblock ~17 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~18 ~13 ~74 ~28 ~13 ~74 minecraft:redstone_wire replace
setblock ~29 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~30 ~13 ~74 ~40 ~13 ~74 minecraft:redstone_wire replace
setblock ~41 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~74 ~52 ~13 ~74 minecraft:redstone_wire replace
setblock ~53 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~74 ~64 ~13 ~74 minecraft:redstone_wire replace
setblock ~65 ~13 ~74 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~66 ~13 ~74 ~75 ~13 ~74 minecraft:redstone_wire replace
setblock ~1 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~2 ~13 ~78 ~12 ~13 ~78 minecraft:redstone_wire replace
setblock ~13 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~14 ~13 ~78 ~24 ~13 ~78 minecraft:redstone_wire replace
setblock ~25 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~26 ~13 ~78 ~36 ~13 ~78 minecraft:redstone_wire replace
setblock ~37 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~38 ~13 ~78 ~48 ~13 ~78 minecraft:redstone_wire replace
setblock ~49 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~78 ~60 ~13 ~78 minecraft:redstone_wire replace
setblock ~61 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~78 ~72 ~13 ~78 minecraft:redstone_wire replace
setblock ~73 ~13 ~78 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~74 ~13 ~78 ~75 ~13 ~78 minecraft:redstone_wire replace
setblock ~55 ~13 ~94 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~94 ~63 ~13 ~94 minecraft:redstone_wire replace
setblock ~53 ~13 ~98 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~98 ~63 ~13 ~98 minecraft:redstone_wire replace
setblock ~51 ~13 ~102 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~52 ~13 ~102 ~62 ~13 ~102 minecraft:redstone_wire replace
setblock ~63 ~13 ~102 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~49 ~13 ~106 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~50 ~13 ~106 ~60 ~13 ~106 minecraft:redstone_wire replace
setblock ~61 ~13 ~106 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~62 ~13 ~106 ~63 ~13 ~106 minecraft:redstone_wire replace
setblock ~47 ~13 ~110 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~48 ~13 ~110 ~58 ~13 ~110 minecraft:redstone_wire replace
setblock ~59 ~13 ~110 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~60 ~13 ~110 ~63 ~13 ~110 minecraft:redstone_wire replace
setblock ~45 ~13 ~114 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~46 ~13 ~114 ~56 ~13 ~114 minecraft:redstone_wire replace
setblock ~57 ~13 ~114 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~58 ~13 ~114 ~63 ~13 ~114 minecraft:redstone_wire replace
setblock ~43 ~13 ~118 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~44 ~13 ~118 ~54 ~13 ~118 minecraft:redstone_wire replace
setblock ~55 ~13 ~118 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~56 ~13 ~118 ~63 ~13 ~118 minecraft:redstone_wire replace
setblock ~41 ~13 ~122 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~42 ~13 ~122 ~52 ~13 ~122 minecraft:redstone_wire replace
setblock ~53 ~13 ~122 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~54 ~13 ~122 ~63 ~13 ~122 minecraft:redstone_wire replace
setblock ~76 ~14 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~14 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~14 ~122 minecraft:redstone_torch[lit=true] replace
fill ~74 ~15 ~90 ~74 ~15 ~95 minecraft:redstone_wire replace
fill ~74 ~15 ~96 ~75 ~15 ~96 minecraft:redstone_wire replace
fill ~74 ~15 ~97 ~74 ~15 ~98 minecraft:redstone_wire replace
setblock ~74 ~15 ~99 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~74 ~15 ~100 ~75 ~15 ~100 minecraft:redstone_wire replace
fill ~74 ~15 ~101 ~74 ~15 ~103 minecraft:redstone_wire replace
fill ~74 ~15 ~104 ~75 ~15 ~104 minecraft:redstone_wire replace
fill ~74 ~15 ~105 ~74 ~15 ~107 minecraft:redstone_wire replace
fill ~74 ~15 ~108 ~75 ~15 ~108 minecraft:redstone_wire replace
fill ~74 ~15 ~109 ~74 ~15 ~110 minecraft:redstone_wire replace
setblock ~74 ~15 ~111 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~74 ~15 ~112 ~75 ~15 ~112 minecraft:redstone_wire replace
fill ~74 ~15 ~113 ~74 ~15 ~115 minecraft:redstone_wire replace
fill ~74 ~15 ~116 ~75 ~15 ~116 minecraft:redstone_wire replace
fill ~74 ~15 ~117 ~74 ~15 ~119 minecraft:redstone_wire replace
fill ~74 ~15 ~120 ~75 ~15 ~120 minecraft:redstone_wire replace
fill ~74 ~15 ~121 ~74 ~15 ~122 minecraft:redstone_wire replace
setblock ~74 ~15 ~123 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~74 ~15 ~124 ~75 ~15 ~124 minecraft:redstone_wire replace
setblock ~65 ~15 ~125 minecraft:redstone_wire replace
setblock ~66 ~15 ~125 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~67 ~15 ~125 ~74 ~15 ~125 minecraft:redstone_wire replace
setblock ~76 ~16 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~122 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~124 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~125 minecraft:redstone_wire replace
fill ~77 ~17 ~2 ~89 ~17 ~2 minecraft:redstone_wire replace
setblock ~90 ~17 ~2 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~91 ~17 ~2 ~103 ~17 ~2 minecraft:redstone_wire replace
setblock ~105 ~17 ~2 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~107 ~17 ~2 ~110 ~17 ~2 minecraft:redstone_wire replace
setblock ~79 ~17 ~3 minecraft:redstone_wire replace
setblock ~82 ~17 ~3 minecraft:redstone_wire replace
setblock ~85 ~17 ~3 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~17 ~3 minecraft:redstone_wire replace
setblock ~91 ~17 ~3 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~17 ~3 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~6 ~90 ~17 ~6 minecraft:redstone_wire replace
setblock ~92 ~17 ~6 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~6 ~107 ~17 ~6 minecraft:redstone_wire replace
setblock ~109 ~17 ~6 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~6 ~116 ~17 ~6 minecraft:redstone_wire replace
setblock ~94 ~17 ~7 minecraft:redstone_wire replace
setblock ~97 ~17 ~7 minecraft:redstone_wire replace
setblock ~100 ~17 ~7 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~17 ~7 minecraft:redstone_wire replace
setblock ~106 ~17 ~7 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~17 ~7 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~10 ~90 ~17 ~10 minecraft:redstone_wire replace
setblock ~92 ~17 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~10 ~107 ~17 ~10 minecraft:redstone_wire replace
setblock ~109 ~17 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~10 ~124 ~17 ~10 minecraft:redstone_wire replace
setblock ~125 ~17 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~17 ~10 ~134 ~17 ~10 minecraft:redstone_wire replace
setblock ~112 ~17 ~11 minecraft:redstone_wire replace
setblock ~118 ~17 ~11 minecraft:redstone_wire replace
setblock ~121 ~17 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~17 ~11 minecraft:redstone_wire replace
setblock ~127 ~17 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~17 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~14 ~90 ~17 ~14 minecraft:redstone_wire replace
setblock ~92 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~14 ~107 ~17 ~14 minecraft:redstone_wire replace
setblock ~109 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~14 ~124 ~17 ~14 minecraft:redstone_wire replace
setblock ~126 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~14 ~141 ~17 ~14 minecraft:redstone_wire replace
setblock ~143 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~14 ~155 ~17 ~14 minecraft:redstone_wire replace
setblock ~136 ~17 ~15 minecraft:redstone_wire replace
setblock ~139 ~17 ~15 minecraft:redstone_wire replace
setblock ~145 ~17 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~17 ~15 minecraft:redstone_wire replace
setblock ~151 ~17 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~17 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~18 ~90 ~17 ~18 minecraft:redstone_wire replace
setblock ~92 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~18 ~107 ~17 ~18 minecraft:redstone_wire replace
setblock ~109 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~18 ~124 ~17 ~18 minecraft:redstone_wire replace
setblock ~126 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~18 ~141 ~17 ~18 minecraft:redstone_wire replace
setblock ~143 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~18 ~158 ~17 ~18 minecraft:redstone_wire replace
setblock ~159 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~17 ~18 ~173 ~17 ~18 minecraft:redstone_wire replace
setblock ~174 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~17 ~18 ~176 ~17 ~18 minecraft:redstone_wire replace
setblock ~160 ~17 ~19 minecraft:redstone_wire replace
setblock ~163 ~17 ~19 minecraft:redstone_wire replace
setblock ~166 ~17 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~17 ~19 minecraft:redstone_wire replace
setblock ~172 ~17 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~175 ~17 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~22 ~89 ~17 ~22 minecraft:redstone_wire replace
setblock ~91 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~22 ~105 ~17 ~22 minecraft:redstone_wire replace
setblock ~107 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~22 ~121 ~17 ~22 minecraft:redstone_wire replace
setblock ~123 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~22 ~137 ~17 ~22 minecraft:redstone_wire replace
setblock ~139 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~22 ~153 ~17 ~22 minecraft:redstone_wire replace
setblock ~155 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~22 ~169 ~17 ~22 minecraft:redstone_wire replace
setblock ~171 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~22 ~185 ~17 ~22 minecraft:redstone_wire replace
setblock ~187 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~22 ~202 ~17 ~22 minecraft:redstone_wire replace
setblock ~203 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~17 ~22 ~206 ~17 ~22 minecraft:redstone_wire replace
setblock ~184 ~17 ~23 minecraft:redstone_wire replace
setblock ~193 ~17 ~23 minecraft:redstone_wire replace
setblock ~196 ~17 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~17 ~23 minecraft:redstone_wire replace
setblock ~202 ~17 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~205 ~17 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~26 ~90 ~17 ~26 minecraft:redstone_wire replace
setblock ~92 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~26 ~107 ~17 ~26 minecraft:redstone_wire replace
setblock ~109 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~26 ~124 ~17 ~26 minecraft:redstone_wire replace
setblock ~126 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~26 ~141 ~17 ~26 minecraft:redstone_wire replace
setblock ~143 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~26 ~158 ~17 ~26 minecraft:redstone_wire replace
setblock ~160 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~26 ~175 ~17 ~26 minecraft:redstone_wire replace
setblock ~177 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~26 ~192 ~17 ~26 minecraft:redstone_wire replace
setblock ~194 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~26 ~209 ~17 ~26 minecraft:redstone_wire replace
setblock ~210 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~26 ~224 ~17 ~26 minecraft:redstone_wire replace
setblock ~225 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~17 ~26 ~239 ~17 ~26 minecraft:redstone_wire replace
setblock ~211 ~17 ~27 minecraft:redstone_wire replace
setblock ~214 ~17 ~27 minecraft:redstone_wire replace
setblock ~217 ~17 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~17 ~27 minecraft:redstone_wire replace
setblock ~226 ~17 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~238 ~17 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~30 ~90 ~17 ~30 minecraft:redstone_wire replace
setblock ~92 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~30 ~107 ~17 ~30 minecraft:redstone_wire replace
setblock ~109 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~30 ~124 ~17 ~30 minecraft:redstone_wire replace
setblock ~126 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~30 ~141 ~17 ~30 minecraft:redstone_wire replace
setblock ~143 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~30 ~158 ~17 ~30 minecraft:redstone_wire replace
setblock ~160 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~30 ~175 ~17 ~30 minecraft:redstone_wire replace
setblock ~177 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~30 ~192 ~17 ~30 minecraft:redstone_wire replace
setblock ~194 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~30 ~209 ~17 ~30 minecraft:redstone_wire replace
setblock ~211 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~30 ~226 ~17 ~30 minecraft:redstone_wire replace
setblock ~228 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~30 ~243 ~17 ~30 minecraft:redstone_wire replace
setblock ~245 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~30 ~260 ~17 ~30 minecraft:redstone_wire replace
setblock ~262 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~30 ~277 ~17 ~30 minecraft:redstone_wire replace
setblock ~278 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~30 ~284 ~17 ~30 minecraft:redstone_wire replace
setblock ~250 ~17 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~265 ~17 ~31 minecraft:redstone_wire replace
setblock ~268 ~17 ~31 minecraft:redstone_wire replace
setblock ~277 ~17 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~280 ~17 ~31 minecraft:redstone_wire replace
setblock ~283 ~17 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~34 ~89 ~17 ~34 minecraft:redstone_wire replace
setblock ~91 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~34 ~105 ~17 ~34 minecraft:redstone_wire replace
setblock ~107 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~34 ~121 ~17 ~34 minecraft:redstone_wire replace
setblock ~123 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~34 ~137 ~17 ~34 minecraft:redstone_wire replace
setblock ~139 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~34 ~153 ~17 ~34 minecraft:redstone_wire replace
setblock ~155 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~34 ~169 ~17 ~34 minecraft:redstone_wire replace
setblock ~171 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~34 ~185 ~17 ~34 minecraft:redstone_wire replace
setblock ~187 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~34 ~201 ~17 ~34 minecraft:redstone_wire replace
setblock ~203 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~34 ~217 ~17 ~34 minecraft:redstone_wire replace
setblock ~219 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~34 ~233 ~17 ~34 minecraft:redstone_wire replace
setblock ~234 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~17 ~34 ~247 ~17 ~34 minecraft:redstone_wire replace
setblock ~248 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~17 ~34 ~261 ~17 ~34 minecraft:redstone_wire replace
setblock ~263 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~17 ~34 ~272 ~17 ~34 minecraft:redstone_wire replace
setblock ~232 ~17 ~35 minecraft:redstone_wire replace
setblock ~235 ~17 ~35 minecraft:redstone_wire replace
setblock ~241 ~17 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~244 ~17 ~35 minecraft:redstone_wire replace
setblock ~247 ~17 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~271 ~17 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~38 ~89 ~17 ~38 minecraft:redstone_wire replace
setblock ~91 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~38 ~105 ~17 ~38 minecraft:redstone_wire replace
setblock ~107 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~38 ~121 ~17 ~38 minecraft:redstone_wire replace
setblock ~123 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~38 ~137 ~17 ~38 minecraft:redstone_wire replace
setblock ~139 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~38 ~153 ~17 ~38 minecraft:redstone_wire replace
setblock ~155 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~38 ~169 ~17 ~38 minecraft:redstone_wire replace
setblock ~171 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~38 ~185 ~17 ~38 minecraft:redstone_wire replace
setblock ~187 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~38 ~201 ~17 ~38 minecraft:redstone_wire replace
setblock ~203 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~38 ~217 ~17 ~38 minecraft:redstone_wire replace
setblock ~219 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~38 ~233 ~17 ~38 minecraft:redstone_wire replace
setblock ~235 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~17 ~38 ~249 ~17 ~38 minecraft:redstone_wire replace
setblock ~251 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~17 ~38 ~265 ~17 ~38 minecraft:redstone_wire replace
setblock ~267 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~17 ~38 ~281 ~17 ~38 minecraft:redstone_wire replace
setblock ~283 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~17 ~38 ~298 ~17 ~38 minecraft:redstone_wire replace
setblock ~299 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~259 ~17 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~286 ~17 ~39 minecraft:redstone_wire replace
setblock ~289 ~17 ~39 minecraft:redstone_wire replace
setblock ~292 ~17 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~295 ~17 ~39 minecraft:redstone_wire replace
setblock ~298 ~17 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~42 ~89 ~17 ~42 minecraft:redstone_wire replace
setblock ~90 ~17 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~91 ~17 ~42 ~103 ~17 ~42 minecraft:redstone_wire replace
setblock ~105 ~17 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~107 ~17 ~42 ~119 ~17 ~42 minecraft:redstone_wire replace
setblock ~121 ~17 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~17 ~42 ~131 ~17 ~42 minecraft:redstone_wire replace
setblock ~82 ~17 ~43 minecraft:redstone_wire replace
setblock ~85 ~17 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~17 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~17 ~43 minecraft:redstone_wire replace
setblock ~130 ~17 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~46 ~89 ~17 ~46 minecraft:redstone_wire replace
setblock ~91 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~46 ~106 ~17 ~46 minecraft:redstone_wire replace
setblock ~107 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~108 ~17 ~46 ~120 ~17 ~46 minecraft:redstone_wire replace
setblock ~122 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~17 ~46 ~136 ~17 ~46 minecraft:redstone_wire replace
setblock ~138 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~140 ~17 ~46 ~143 ~17 ~46 minecraft:redstone_wire replace
setblock ~97 ~17 ~47 minecraft:redstone_wire replace
setblock ~100 ~17 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~17 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~17 ~47 minecraft:redstone_wire replace
setblock ~142 ~17 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~50 ~89 ~17 ~50 minecraft:redstone_wire replace
setblock ~91 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~50 ~105 ~17 ~50 minecraft:redstone_wire replace
setblock ~107 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~50 ~121 ~17 ~50 minecraft:redstone_wire replace
setblock ~122 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~17 ~50 ~135 ~17 ~50 minecraft:redstone_wire replace
setblock ~137 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~17 ~50 ~151 ~17 ~50 minecraft:redstone_wire replace
setblock ~153 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~155 ~17 ~50 ~158 ~17 ~50 minecraft:redstone_wire replace
setblock ~118 ~17 ~51 minecraft:redstone_wire replace
setblock ~121 ~17 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~17 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~17 ~51 minecraft:redstone_wire replace
setblock ~157 ~17 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~54 ~90 ~17 ~54 minecraft:redstone_wire replace
setblock ~92 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~54 ~107 ~17 ~54 minecraft:redstone_wire replace
setblock ~109 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~54 ~124 ~17 ~54 minecraft:redstone_wire replace
setblock ~126 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~54 ~141 ~17 ~54 minecraft:redstone_wire replace
setblock ~143 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~54 ~158 ~17 ~54 minecraft:redstone_wire replace
setblock ~160 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~54 ~175 ~17 ~54 minecraft:redstone_wire replace
setblock ~177 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~54 ~191 ~17 ~54 minecraft:redstone_wire replace
setblock ~139 ~17 ~55 minecraft:redstone_wire replace
setblock ~145 ~17 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~17 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~17 ~55 minecraft:redstone_wire replace
setblock ~190 ~17 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~58 ~90 ~17 ~58 minecraft:redstone_wire replace
setblock ~92 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~58 ~107 ~17 ~58 minecraft:redstone_wire replace
setblock ~109 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~58 ~124 ~17 ~58 minecraft:redstone_wire replace
setblock ~126 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~58 ~141 ~17 ~58 minecraft:redstone_wire replace
setblock ~143 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~58 ~158 ~17 ~58 minecraft:redstone_wire replace
setblock ~160 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~58 ~175 ~17 ~58 minecraft:redstone_wire replace
setblock ~177 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~58 ~192 ~17 ~58 minecraft:redstone_wire replace
setblock ~194 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~58 ~209 ~17 ~58 minecraft:redstone_wire replace
setblock ~163 ~17 ~59 minecraft:redstone_wire replace
setblock ~166 ~17 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~17 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~17 ~59 minecraft:redstone_wire replace
setblock ~208 ~17 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~62 ~89 ~17 ~62 minecraft:redstone_wire replace
setblock ~91 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~62 ~105 ~17 ~62 minecraft:redstone_wire replace
setblock ~107 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~62 ~121 ~17 ~62 minecraft:redstone_wire replace
setblock ~123 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~62 ~137 ~17 ~62 minecraft:redstone_wire replace
setblock ~139 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~62 ~153 ~17 ~62 minecraft:redstone_wire replace
setblock ~155 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~62 ~169 ~17 ~62 minecraft:redstone_wire replace
setblock ~171 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~62 ~185 ~17 ~62 minecraft:redstone_wire replace
setblock ~187 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~62 ~202 ~17 ~62 minecraft:redstone_wire replace
setblock ~203 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~17 ~62 ~216 ~17 ~62 minecraft:redstone_wire replace
setblock ~218 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~17 ~62 ~221 ~17 ~62 minecraft:redstone_wire replace
setblock ~193 ~17 ~63 minecraft:redstone_wire replace
setblock ~196 ~17 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~17 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~202 ~17 ~63 minecraft:redstone_wire replace
setblock ~220 ~17 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~66 ~90 ~17 ~66 minecraft:redstone_wire replace
setblock ~92 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~66 ~107 ~17 ~66 minecraft:redstone_wire replace
setblock ~109 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~66 ~124 ~17 ~66 minecraft:redstone_wire replace
setblock ~126 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~66 ~141 ~17 ~66 minecraft:redstone_wire replace
setblock ~143 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~66 ~158 ~17 ~66 minecraft:redstone_wire replace
setblock ~160 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~66 ~175 ~17 ~66 minecraft:redstone_wire replace
setblock ~177 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~66 ~192 ~17 ~66 minecraft:redstone_wire replace
setblock ~194 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~66 ~209 ~17 ~66 minecraft:redstone_wire replace
setblock ~211 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~66 ~226 ~17 ~66 minecraft:redstone_wire replace
setblock ~227 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~66 ~241 ~17 ~66 minecraft:redstone_wire replace
setblock ~243 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~66 ~254 ~17 ~66 minecraft:redstone_wire replace
setblock ~214 ~17 ~67 minecraft:redstone_wire replace
setblock ~217 ~17 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~17 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~226 ~17 ~67 minecraft:redstone_wire replace
setblock ~253 ~17 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~70 ~90 ~17 ~70 minecraft:redstone_wire replace
setblock ~92 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~70 ~107 ~17 ~70 minecraft:redstone_wire replace
setblock ~109 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~70 ~124 ~17 ~70 minecraft:redstone_wire replace
setblock ~126 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~70 ~141 ~17 ~70 minecraft:redstone_wire replace
setblock ~143 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~70 ~158 ~17 ~70 minecraft:redstone_wire replace
setblock ~160 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~70 ~175 ~17 ~70 minecraft:redstone_wire replace
setblock ~177 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~70 ~192 ~17 ~70 minecraft:redstone_wire replace
setblock ~194 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~70 ~209 ~17 ~70 minecraft:redstone_wire replace
setblock ~211 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~70 ~226 ~17 ~70 minecraft:redstone_wire replace
setblock ~228 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~70 ~243 ~17 ~70 minecraft:redstone_wire replace
setblock ~245 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~70 ~260 ~17 ~70 minecraft:redstone_wire replace
setblock ~262 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~70 ~277 ~17 ~70 minecraft:redstone_wire replace
setblock ~278 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
