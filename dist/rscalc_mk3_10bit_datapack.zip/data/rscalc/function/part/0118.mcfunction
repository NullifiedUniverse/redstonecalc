setblock ~502 ~169 ~757 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~456 ~169 ~758 ~456 ~169 ~768 minecraft:redstone_wire replace
fill ~462 ~169 ~758 ~462 ~169 ~768 minecraft:redstone_wire replace
fill ~502 ~169 ~758 ~502 ~169 ~768 minecraft:redstone_wire replace
setblock ~452 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~761 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~762 ~452 ~169 ~772 minecraft:redstone_wire replace
fill ~464 ~169 ~762 ~464 ~169 ~772 minecraft:redstone_wire replace
fill ~466 ~169 ~762 ~466 ~169 ~772 minecraft:redstone_wire replace
setblock ~458 ~169 ~765 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~765 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~766 ~458 ~169 ~776 minecraft:redstone_wire replace
fill ~460 ~169 ~766 ~460 ~169 ~776 minecraft:redstone_wire replace
setblock ~456 ~169 ~769 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~769 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~769 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~456 ~169 ~770 ~456 ~169 ~780 minecraft:redstone_wire replace
fill ~462 ~169 ~770 ~462 ~169 ~780 minecraft:redstone_wire replace
fill ~502 ~169 ~770 ~502 ~169 ~780 minecraft:redstone_wire replace
setblock ~452 ~169 ~773 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~773 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~773 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~774 ~452 ~169 ~784 minecraft:redstone_wire replace
fill ~464 ~169 ~774 ~464 ~169 ~784 minecraft:redstone_wire replace
fill ~466 ~169 ~774 ~466 ~169 ~784 minecraft:redstone_wire replace
setblock ~458 ~169 ~777 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~777 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~778 ~458 ~169 ~788 minecraft:redstone_wire replace
fill ~460 ~169 ~778 ~460 ~169 ~788 minecraft:redstone_wire replace
setblock ~456 ~169 ~781 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~781 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~781 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~456 ~169 ~782 ~456 ~169 ~792 minecraft:redstone_wire replace
fill ~462 ~169 ~782 ~462 ~169 ~792 minecraft:redstone_wire replace
fill ~502 ~169 ~782 ~502 ~169 ~792 minecraft:redstone_wire replace
setblock ~452 ~169 ~785 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~785 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~785 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~786 ~452 ~169 ~796 minecraft:redstone_wire replace
fill ~464 ~169 ~786 ~464 ~169 ~796 minecraft:redstone_wire replace
fill ~466 ~169 ~786 ~466 ~169 ~796 minecraft:redstone_wire replace
setblock ~458 ~169 ~789 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~789 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~790 ~458 ~169 ~800 minecraft:redstone_wire replace
fill ~460 ~169 ~790 ~460 ~169 ~800 minecraft:redstone_wire replace
setblock ~456 ~169 ~793 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~793 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~793 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~794 ~462 ~169 ~804 minecraft:redstone_wire replace
fill ~502 ~169 ~794 ~502 ~169 ~804 minecraft:redstone_wire replace
setblock ~452 ~169 ~797 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~797 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~797 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~798 ~452 ~169 ~808 minecraft:redstone_wire replace
fill ~464 ~169 ~798 ~464 ~169 ~808 minecraft:redstone_wire replace
fill ~466 ~169 ~798 ~466 ~169 ~808 minecraft:redstone_wire replace
setblock ~458 ~169 ~801 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~801 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~802 ~458 ~169 ~812 minecraft:redstone_wire replace
fill ~460 ~169 ~802 ~460 ~169 ~812 minecraft:redstone_wire replace
setblock ~462 ~169 ~805 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~805 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~806 ~462 ~169 ~816 minecraft:redstone_wire replace
fill ~502 ~169 ~806 ~502 ~169 ~816 minecraft:redstone_wire replace
setblock ~452 ~169 ~809 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~809 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~809 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~810 ~452 ~169 ~820 minecraft:redstone_wire replace
fill ~464 ~169 ~810 ~464 ~169 ~820 minecraft:redstone_wire replace
fill ~466 ~169 ~810 ~466 ~169 ~820 minecraft:redstone_wire replace
setblock ~458 ~169 ~813 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~813 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~458 ~169 ~814 ~458 ~169 ~824 minecraft:redstone_wire replace
fill ~460 ~169 ~814 ~460 ~169 ~824 minecraft:redstone_wire replace
setblock ~462 ~169 ~817 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~817 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~818 ~462 ~169 ~828 minecraft:redstone_wire replace
fill ~502 ~169 ~818 ~502 ~169 ~828 minecraft:redstone_wire replace
setblock ~452 ~169 ~821 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~821 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~821 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~822 ~452 ~169 ~832 minecraft:redstone_wire replace
fill ~464 ~169 ~822 ~464 ~169 ~832 minecraft:redstone_wire replace
fill ~466 ~169 ~822 ~466 ~169 ~832 minecraft:redstone_wire replace
setblock ~458 ~169 ~825 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~825 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~460 ~169 ~826 ~460 ~169 ~836 minecraft:redstone_wire replace
setblock ~462 ~169 ~829 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~829 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~830 ~462 ~169 ~840 minecraft:redstone_wire replace
fill ~502 ~169 ~830 ~502 ~169 ~840 minecraft:redstone_wire replace
setblock ~452 ~169 ~833 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~833 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~833 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~834 ~452 ~169 ~844 minecraft:redstone_wire replace
fill ~464 ~169 ~834 ~464 ~169 ~844 minecraft:redstone_wire replace
fill ~466 ~169 ~834 ~466 ~169 ~844 minecraft:redstone_wire replace
setblock ~460 ~169 ~837 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~460 ~169 ~838 ~460 ~169 ~848 minecraft:redstone_wire replace
setblock ~462 ~169 ~841 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~841 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~842 ~462 ~169 ~852 minecraft:redstone_wire replace
fill ~502 ~169 ~842 ~502 ~169 ~852 minecraft:redstone_wire replace
setblock ~452 ~169 ~845 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~845 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~845 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~846 ~452 ~169 ~856 minecraft:redstone_wire replace
fill ~464 ~169 ~846 ~464 ~169 ~856 minecraft:redstone_wire replace
fill ~466 ~169 ~846 ~466 ~169 ~856 minecraft:redstone_wire replace
setblock ~460 ~169 ~849 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~460 ~169 ~850 ~460 ~169 ~860 minecraft:redstone_wire replace
setblock ~462 ~169 ~853 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~853 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~854 ~462 ~169 ~864 minecraft:redstone_wire replace
fill ~502 ~169 ~854 ~502 ~169 ~864 minecraft:redstone_wire replace
setblock ~452 ~169 ~857 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~857 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~857 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~858 ~452 ~169 ~868 minecraft:redstone_wire replace
fill ~464 ~169 ~858 ~464 ~169 ~868 minecraft:redstone_wire replace
fill ~466 ~169 ~858 ~466 ~169 ~868 minecraft:redstone_wire replace
setblock ~460 ~169 ~861 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~865 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~865 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~866 ~462 ~169 ~876 minecraft:redstone_wire replace
fill ~502 ~169 ~866 ~502 ~169 ~876 minecraft:redstone_wire replace
setblock ~452 ~169 ~869 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~869 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~869 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~870 ~452 ~169 ~880 minecraft:redstone_wire replace
fill ~464 ~169 ~870 ~464 ~169 ~880 minecraft:redstone_wire replace
fill ~466 ~169 ~870 ~466 ~169 ~880 minecraft:redstone_wire replace
setblock ~462 ~169 ~877 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~877 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~462 ~169 ~878 ~462 ~169 ~888 minecraft:redstone_wire replace
fill ~502 ~169 ~878 ~502 ~169 ~888 minecraft:redstone_wire replace
setblock ~452 ~169 ~881 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~881 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~881 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~882 ~452 ~169 ~892 minecraft:redstone_wire replace
fill ~464 ~169 ~882 ~464 ~169 ~892 minecraft:redstone_wire replace
fill ~466 ~169 ~882 ~466 ~169 ~892 minecraft:redstone_wire replace
setblock ~462 ~169 ~889 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~889 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~890 ~502 ~169 ~900 minecraft:redstone_wire replace
setblock ~452 ~169 ~893 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~893 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~893 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~894 ~452 ~169 ~904 minecraft:redstone_wire replace
fill ~464 ~169 ~894 ~464 ~169 ~904 minecraft:redstone_wire replace
fill ~466 ~169 ~894 ~466 ~169 ~904 minecraft:redstone_wire replace
setblock ~502 ~169 ~901 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~902 ~502 ~169 ~912 minecraft:redstone_wire replace
setblock ~452 ~169 ~905 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~905 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~905 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~906 ~452 ~169 ~916 minecraft:redstone_wire replace
fill ~466 ~169 ~906 ~466 ~169 ~916 minecraft:redstone_wire replace
setblock ~502 ~169 ~913 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~914 ~502 ~169 ~924 minecraft:redstone_wire replace
setblock ~452 ~169 ~917 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~917 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~918 ~452 ~169 ~928 minecraft:redstone_wire replace
fill ~466 ~169 ~918 ~466 ~169 ~928 minecraft:redstone_wire replace
setblock ~502 ~169 ~925 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~926 ~502 ~169 ~936 minecraft:redstone_wire replace
setblock ~452 ~169 ~929 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~929 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~930 ~452 ~169 ~940 minecraft:redstone_wire replace
setblock ~502 ~169 ~937 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~938 ~502 ~169 ~948 minecraft:redstone_wire replace
setblock ~452 ~169 ~941 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~942 ~452 ~169 ~952 minecraft:redstone_wire replace
setblock ~502 ~169 ~949 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~502 ~169 ~950 ~502 ~169 ~960 minecraft:redstone_wire replace
setblock ~452 ~169 ~953 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~452 ~169 ~954 ~452 ~169 ~964 minecraft:redstone_wire replace
setblock ~502 ~169 ~961 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~965 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~440 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~170 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~170 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~170 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~496 ~170 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~170 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~170 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~170 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~498 ~172 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~500 ~172 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~502 ~172 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~496 ~172 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~172 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~172 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~172 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~499 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~173 ~2 ~510 ~173 ~2 minecraft:redstone_wire replace
setblock ~511 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~173 ~2 ~522 ~173 ~2 minecraft:redstone_wire replace
setblock ~523 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~173 ~2 ~534 ~173 ~2 minecraft:redstone_wire replace
setblock ~535 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~536 ~173 ~2 ~546 ~173 ~2 minecraft:redstone_wire replace
setblock ~547 ~173 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~548 ~173 ~2 ~553 ~173 ~2 minecraft:redstone_wire replace
setblock ~501 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~173 ~4 ~512 ~173 ~4 minecraft:redstone_wire replace
setblock ~513 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~173 ~4 ~524 ~173 ~4 minecraft:redstone_wire replace
setblock ~525 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~173 ~4 ~536 ~173 ~4 minecraft:redstone_wire replace
setblock ~537 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~538 ~173 ~4 ~548 ~173 ~4 minecraft:redstone_wire replace
setblock ~549 ~173 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~550 ~173 ~4 ~553 ~173 ~4 minecraft:redstone_wire replace
setblock ~503 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~173 ~6 ~514 ~173 ~6 minecraft:redstone_wire replace
setblock ~515 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~173 ~6 ~526 ~173 ~6 minecraft:redstone_wire replace
setblock ~527 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~173 ~6 ~538 ~173 ~6 minecraft:redstone_wire replace
setblock ~539 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~540 ~173 ~6 ~550 ~173 ~6 minecraft:redstone_wire replace
setblock ~551 ~173 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~552 ~173 ~6 ~553 ~173 ~6 minecraft:redstone_wire replace
setblock ~497 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~173 ~8 ~508 ~173 ~8 minecraft:redstone_wire replace
setblock ~509 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~173 ~8 ~520 ~173 ~8 minecraft:redstone_wire replace
setblock ~521 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~173 ~8 ~532 ~173 ~8 minecraft:redstone_wire replace
setblock ~533 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~534 ~173 ~8 ~544 ~173 ~8 minecraft:redstone_wire replace
setblock ~545 ~173 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~546 ~173 ~8 ~553 ~173 ~8 minecraft:redstone_wire replace
setblock ~440 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~174 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~174 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~174 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~174 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~494 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~484 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~492 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~482 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~176 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~486 ~176 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~490 ~176 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~488 ~176 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~495 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~177 ~2 ~506 ~177 ~2 minecraft:redstone_wire replace
setblock ~507 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~177 ~2 ~518 ~177 ~2 minecraft:redstone_wire replace
setblock ~519 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~177 ~2 ~530 ~177 ~2 minecraft:redstone_wire replace
setblock ~531 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~177 ~2 ~542 ~177 ~2 minecraft:redstone_wire replace
setblock ~543 ~177 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~544 ~177 ~2 ~547 ~177 ~2 minecraft:redstone_wire replace
setblock ~485 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~177 ~4 ~496 ~177 ~4 minecraft:redstone_wire replace
setblock ~497 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~177 ~4 ~508 ~177 ~4 minecraft:redstone_wire replace
setblock ~509 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~177 ~4 ~520 ~177 ~4 minecraft:redstone_wire replace
setblock ~521 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~177 ~4 ~532 ~177 ~4 minecraft:redstone_wire replace
setblock ~533 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~534 ~177 ~4 ~544 ~177 ~4 minecraft:redstone_wire replace
setblock ~545 ~177 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~493 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~177 ~6 ~504 ~177 ~6 minecraft:redstone_wire replace
setblock ~505 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~177 ~6 ~516 ~177 ~6 minecraft:redstone_wire replace
setblock ~517 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~177 ~6 ~528 ~177 ~6 minecraft:redstone_wire replace
setblock ~529 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~177 ~6 ~540 ~177 ~6 minecraft:redstone_wire replace
setblock ~541 ~177 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~542 ~177 ~6 ~549 ~177 ~6 minecraft:redstone_wire replace
setblock ~483 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~177 ~8 ~494 ~177 ~8 minecraft:redstone_wire replace
setblock ~495 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~177 ~8 ~506 ~177 ~8 minecraft:redstone_wire replace
setblock ~507 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~177 ~8 ~518 ~177 ~8 minecraft:redstone_wire replace
setblock ~519 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~177 ~8 ~530 ~177 ~8 minecraft:redstone_wire replace
setblock ~531 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~177 ~8 ~542 ~177 ~8 minecraft:redstone_wire replace
setblock ~543 ~177 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~544 ~177 ~8 ~547 ~177 ~8 minecraft:redstone_wire replace
setblock ~487 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~177 ~10 ~498 ~177 ~10 minecraft:redstone_wire replace
setblock ~499 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~177 ~10 ~510 ~177 ~10 minecraft:redstone_wire replace
setblock ~511 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~177 ~10 ~522 ~177 ~10 minecraft:redstone_wire replace
setblock ~523 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~177 ~10 ~534 ~177 ~10 minecraft:redstone_wire replace
setblock ~535 ~177 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~536 ~177 ~10 ~545 ~177 ~10 minecraft:redstone_wire replace
setblock ~491 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~177 ~12 ~502 ~177 ~12 minecraft:redstone_wire replace
setblock ~503 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~177 ~12 ~514 ~177 ~12 minecraft:redstone_wire replace
setblock ~515 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~177 ~12 ~526 ~177 ~12 minecraft:redstone_wire replace
setblock ~527 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~177 ~12 ~538 ~177 ~12 minecraft:redstone_wire replace
setblock ~539 ~177 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~540 ~177 ~12 ~549 ~177 ~12 minecraft:redstone_wire replace
setblock ~489 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~177 ~14 ~500 ~177 ~14 minecraft:redstone_wire replace
setblock ~501 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~177 ~14 ~512 ~177 ~14 minecraft:redstone_wire replace
setblock ~513 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~177 ~14 ~524 ~177 ~14 minecraft:redstone_wire replace
setblock ~525 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~177 ~14 ~536 ~177 ~14 minecraft:redstone_wire replace
setblock ~537 ~177 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~538 ~177 ~14 ~547 ~177 ~14 minecraft:redstone_wire replace
setblock ~440 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~178 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~178 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~178 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~178 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~468 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~478 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~470 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~480 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~180 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~476 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~180 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~472 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~180 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~474 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~180 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~469 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~181 ~2 ~480 ~181 ~2 minecraft:redstone_wire replace
setblock ~481 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~181 ~2 ~492 ~181 ~2 minecraft:redstone_wire replace
setblock ~493 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~181 ~2 ~504 ~181 ~2 minecraft:redstone_wire replace
setblock ~505 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~181 ~2 ~516 ~181 ~2 minecraft:redstone_wire replace
setblock ~517 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~181 ~2 ~528 ~181 ~2 minecraft:redstone_wire replace
setblock ~529 ~181 ~2 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~181 ~2 ~539 ~181 ~2 minecraft:redstone_wire replace
setblock ~479 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~480 ~181 ~4 ~490 ~181 ~4 minecraft:redstone_wire replace
setblock ~491 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~492 ~181 ~4 ~502 ~181 ~4 minecraft:redstone_wire replace
setblock ~503 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~504 ~181 ~4 ~514 ~181 ~4 minecraft:redstone_wire replace
setblock ~515 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~516 ~181 ~4 ~526 ~181 ~4 minecraft:redstone_wire replace
setblock ~527 ~181 ~4 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~528 ~181 ~4 ~537 ~181 ~4 minecraft:redstone_wire replace
setblock ~471 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~472 ~181 ~6 ~482 ~181 ~6 minecraft:redstone_wire replace
setblock ~483 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~484 ~181 ~6 ~494 ~181 ~6 minecraft:redstone_wire replace
setblock ~495 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~496 ~181 ~6 ~506 ~181 ~6 minecraft:redstone_wire replace
setblock ~507 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~508 ~181 ~6 ~518 ~181 ~6 minecraft:redstone_wire replace
setblock ~519 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~520 ~181 ~6 ~530 ~181 ~6 minecraft:redstone_wire replace
setblock ~531 ~181 ~6 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~532 ~181 ~6 ~541 ~181 ~6 minecraft:redstone_wire replace
setblock ~481 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~181 ~8 ~492 ~181 ~8 minecraft:redstone_wire replace
setblock ~493 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~181 ~8 ~504 ~181 ~8 minecraft:redstone_wire replace
setblock ~505 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~506 ~181 ~8 ~516 ~181 ~8 minecraft:redstone_wire replace
setblock ~517 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~518 ~181 ~8 ~528 ~181 ~8 minecraft:redstone_wire replace
setblock ~529 ~181 ~8 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~530 ~181 ~8 ~539 ~181 ~8 minecraft:redstone_wire replace
setblock ~477 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~478 ~181 ~10 ~488 ~181 ~10 minecraft:redstone_wire replace
setblock ~489 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~490 ~181 ~10 ~500 ~181 ~10 minecraft:redstone_wire replace
setblock ~501 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~502 ~181 ~10 ~512 ~181 ~10 minecraft:redstone_wire replace
setblock ~513 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~514 ~181 ~10 ~524 ~181 ~10 minecraft:redstone_wire replace
setblock ~525 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~526 ~181 ~10 ~536 ~181 ~10 minecraft:redstone_wire replace
setblock ~537 ~181 ~10 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~473 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~474 ~181 ~12 ~484 ~181 ~12 minecraft:redstone_wire replace
setblock ~485 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~486 ~181 ~12 ~496 ~181 ~12 minecraft:redstone_wire replace
setblock ~497 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~498 ~181 ~12 ~508 ~181 ~12 minecraft:redstone_wire replace
setblock ~509 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~510 ~181 ~12 ~520 ~181 ~12 minecraft:redstone_wire replace
setblock ~521 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~522 ~181 ~12 ~532 ~181 ~12 minecraft:redstone_wire replace
setblock ~533 ~181 ~12 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~534 ~181 ~12 ~541 ~181 ~12 minecraft:redstone_wire replace
setblock ~475 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~181 ~14 ~486 ~181 ~14 minecraft:redstone_wire replace
setblock ~487 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~488 ~181 ~14 ~498 ~181 ~14 minecraft:redstone_wire replace
setblock ~499 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~500 ~181 ~14 ~510 ~181 ~14 minecraft:redstone_wire replace
setblock ~511 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~512 ~181 ~14 ~522 ~181 ~14 minecraft:redstone_wire replace
setblock ~523 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~524 ~181 ~14 ~534 ~181 ~14 minecraft:redstone_wire replace
setblock ~535 ~181 ~14 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~536 ~181 ~14 ~539 ~181 ~14 minecraft:redstone_wire replace
setblock ~440 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~450 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~464 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~442 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~456 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~6 minecraft:redstone_torch[lit=true] replace
setblock ~452 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~466 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~554 ~182 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~448 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~462 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~538 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~546 ~182 ~10 minecraft:redstone_torch[lit=true] replace
setblock ~444 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~458 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~542 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~550 ~182 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~446 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~460 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~548 ~182 ~14 minecraft:redstone_torch[lit=true] replace
setblock ~440 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~454 ~184 ~2 minecraft:redstone_torch[lit=true] replace
setblock ~540 ~184 ~2 minecraft:redstone_torch[lit=true] replace
