setblock ~213 ~36 ~293 minecraft:redstone_wire replace
setblock ~144 ~36 ~297 minecraft:redstone_wire replace
setblock ~168 ~36 ~301 minecraft:redstone_wire replace
setblock ~201 ~36 ~305 minecraft:redstone_wire replace
setblock ~255 ~36 ~309 minecraft:redstone_wire replace
setblock ~174 ~36 ~313 minecraft:redstone_wire replace
setblock ~240 ~36 ~317 minecraft:redstone_wire replace
setblock ~258 ~36 ~321 minecraft:redstone_wire replace
setblock ~195 ~36 ~325 minecraft:redstone_wire replace
setblock ~225 ~36 ~329 minecraft:redstone_wire replace
setblock ~246 ~36 ~333 minecraft:redstone_wire replace
setblock ~303 ~36 ~337 minecraft:redstone_wire replace
setblock ~228 ~36 ~341 minecraft:redstone_wire replace
setblock ~261 ~36 ~345 minecraft:redstone_wire replace
setblock ~282 ~36 ~349 minecraft:redstone_wire replace
setblock ~333 ~36 ~353 minecraft:redstone_wire replace
setblock ~264 ~36 ~357 minecraft:redstone_wire replace
setblock ~315 ~36 ~361 minecraft:redstone_wire replace
setblock ~324 ~36 ~365 minecraft:redstone_wire replace
setblock ~339 ~36 ~369 minecraft:redstone_wire replace
setblock ~318 ~36 ~373 minecraft:redstone_wire replace
setblock ~336 ~36 ~377 minecraft:redstone_wire replace
setblock ~342 ~36 ~381 minecraft:redstone_wire replace
setblock ~285 ~36 ~385 minecraft:redstone_wire replace
setblock ~327 ~36 ~389 minecraft:redstone_wire replace
setblock ~348 ~36 ~393 minecraft:redstone_wire replace
setblock ~387 ~36 ~397 minecraft:redstone_wire replace
setblock ~354 ~36 ~401 minecraft:redstone_wire replace
setblock ~360 ~36 ~405 minecraft:redstone_wire replace
setblock ~378 ~36 ~409 minecraft:redstone_wire replace
setblock ~90 ~36 ~413 minecraft:redstone_wire replace
setblock ~114 ~36 ~417 minecraft:redstone_wire replace
setblock ~138 ~36 ~421 minecraft:redstone_wire replace
setblock ~186 ~36 ~425 minecraft:redstone_wire replace
setblock ~216 ~36 ~429 minecraft:redstone_wire replace
setblock ~243 ~36 ~433 minecraft:redstone_wire replace
setblock ~279 ~36 ~437 minecraft:redstone_wire replace
setblock ~309 ~36 ~441 minecraft:redstone_wire replace
setblock ~345 ~36 ~445 minecraft:redstone_wire replace
setblock ~87 ~36 ~449 minecraft:redstone_wire replace
setblock ~111 ~36 ~453 minecraft:redstone_wire replace
setblock ~135 ~36 ~457 minecraft:redstone_wire replace
setblock ~183 ~36 ~461 minecraft:redstone_wire replace
setblock ~207 ~36 ~465 minecraft:redstone_wire replace
setblock ~237 ~36 ~469 minecraft:redstone_wire replace
setblock ~276 ~36 ~473 minecraft:redstone_wire replace
setblock ~306 ~36 ~477 minecraft:redstone_wire replace
setblock ~369 ~36 ~481 minecraft:redstone_wire replace
setblock ~393 ~36 ~485 minecraft:redstone_wire replace
setblock ~84 ~36 ~489 minecraft:redstone_wire replace
setblock ~108 ~36 ~493 minecraft:redstone_wire replace
setblock ~132 ~36 ~497 minecraft:redstone_wire replace
setblock ~165 ~36 ~501 minecraft:redstone_wire replace
setblock ~204 ~36 ~505 minecraft:redstone_wire replace
setblock ~234 ~36 ~509 minecraft:redstone_wire replace
setblock ~273 ~36 ~513 minecraft:redstone_wire replace
setblock ~297 ~36 ~517 minecraft:redstone_wire replace
setblock ~366 ~36 ~521 minecraft:redstone_wire replace
setblock ~390 ~36 ~525 minecraft:redstone_wire replace
setblock ~81 ~36 ~529 minecraft:redstone_wire replace
setblock ~105 ~36 ~533 minecraft:redstone_wire replace
setblock ~129 ~36 ~537 minecraft:redstone_wire replace
setblock ~159 ~36 ~541 minecraft:redstone_wire replace
setblock ~198 ~36 ~545 minecraft:redstone_wire replace
setblock ~231 ~36 ~549 minecraft:redstone_wire replace
setblock ~270 ~36 ~553 minecraft:redstone_wire replace
setblock ~291 ~36 ~557 minecraft:redstone_wire replace
setblock ~363 ~36 ~561 minecraft:redstone_wire replace
setblock ~384 ~36 ~565 minecraft:redstone_wire replace
setblock ~78 ~36 ~569 minecraft:redstone_wire replace
setblock ~102 ~36 ~573 minecraft:redstone_wire replace
setblock ~126 ~36 ~577 minecraft:redstone_wire replace
setblock ~153 ~36 ~581 minecraft:redstone_wire replace
setblock ~192 ~36 ~585 minecraft:redstone_wire replace
setblock ~222 ~36 ~589 minecraft:redstone_wire replace
setblock ~267 ~36 ~593 minecraft:redstone_wire replace
setblock ~288 ~36 ~597 minecraft:redstone_wire replace
setblock ~357 ~36 ~601 minecraft:redstone_wire replace
setblock ~381 ~36 ~605 minecraft:redstone_wire replace
setblock ~99 ~36 ~609 minecraft:redstone_wire replace
setblock ~123 ~36 ~613 minecraft:redstone_wire replace
setblock ~147 ~36 ~617 minecraft:redstone_wire replace
setblock ~189 ~36 ~621 minecraft:redstone_wire replace
setblock ~219 ~36 ~625 minecraft:redstone_wire replace
setblock ~249 ~36 ~629 minecraft:redstone_wire replace
setblock ~294 ~36 ~633 minecraft:redstone_wire replace
setblock ~312 ~36 ~637 minecraft:redstone_wire replace
setblock ~372 ~36 ~641 minecraft:redstone_wire replace
setblock ~162 ~36 ~645 minecraft:redstone_wire replace
setblock ~399 ~36 ~649 minecraft:redstone_wire replace
setblock ~96 ~36 ~653 minecraft:redstone_wire replace
setblock ~375 ~36 ~657 minecraft:redstone_wire replace
setblock ~396 ~36 ~661 minecraft:redstone_wire replace
fill ~147 ~37 ~14 ~150 ~37 ~14 minecraft:redstone_wire replace
setblock ~152 ~37 ~14 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~37 ~14 ~167 ~37 ~14 minecraft:redstone_wire replace
setblock ~169 ~37 ~14 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~37 ~14 ~183 ~37 ~14 minecraft:redstone_wire replace
setblock ~185 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~37 ~14 ~200 ~37 ~14 minecraft:redstone_wire replace
setblock ~202 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~37 ~14 ~217 ~37 ~14 minecraft:redstone_wire replace
setblock ~219 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~37 ~14 ~234 ~37 ~14 minecraft:redstone_wire replace
setblock ~236 ~37 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~37 ~14 ~245 ~37 ~14 minecraft:redstone_wire replace
setblock ~148 ~37 ~15 minecraft:redstone_wire replace
setblock ~175 ~37 ~15 minecraft:redstone_wire replace
setblock ~244 ~37 ~15 minecraft:redstone_wire replace
fill ~177 ~37 ~22 ~183 ~37 ~22 minecraft:redstone_wire replace
setblock ~185 ~37 ~22 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~37 ~22 ~200 ~37 ~22 minecraft:redstone_wire replace
setblock ~202 ~37 ~22 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~37 ~22 ~216 ~37 ~22 minecraft:redstone_wire replace
setblock ~218 ~37 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~37 ~22 ~233 ~37 ~22 minecraft:redstone_wire replace
setblock ~235 ~37 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~37 ~22 ~248 ~37 ~22 minecraft:redstone_wire replace
setblock ~178 ~37 ~23 minecraft:redstone_wire replace
setblock ~247 ~37 ~23 minecraft:redstone_wire replace
fill ~249 ~37 ~30 ~252 ~37 ~30 minecraft:redstone_wire replace
setblock ~250 ~37 ~31 minecraft:redstone_wire replace
fill ~258 ~37 ~46 ~259 ~37 ~46 minecraft:redstone_wire replace
setblock ~261 ~37 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~37 ~46 ~275 ~37 ~46 minecraft:redstone_wire replace
setblock ~277 ~37 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~37 ~46 ~291 ~37 ~46 minecraft:redstone_wire replace
setblock ~293 ~37 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~37 ~46 ~306 ~37 ~46 minecraft:redstone_wire replace
setblock ~308 ~37 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~310 ~37 ~46 ~323 ~37 ~46 minecraft:redstone_wire replace
setblock ~325 ~37 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~327 ~37 ~46 ~332 ~37 ~46 minecraft:redstone_wire replace
setblock ~259 ~37 ~47 minecraft:redstone_wire replace
setblock ~316 ~37 ~47 minecraft:redstone_wire replace
setblock ~331 ~37 ~47 minecraft:redstone_wire replace
fill ~318 ~37 ~54 ~320 ~37 ~54 minecraft:redstone_wire replace
setblock ~322 ~37 ~54 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~37 ~54 ~335 ~37 ~54 minecraft:redstone_wire replace
setblock ~319 ~37 ~55 minecraft:redstone_wire replace
setblock ~334 ~37 ~55 minecraft:redstone_wire replace
fill ~321 ~37 ~62 ~326 ~37 ~62 minecraft:redstone_wire replace
setblock ~325 ~37 ~63 minecraft:redstone_wire replace
fill ~348 ~37 ~78 ~351 ~37 ~78 minecraft:redstone_wire replace
setblock ~349 ~37 ~79 minecraft:redstone_wire replace
fill ~93 ~37 ~262 ~95 ~37 ~262 minecraft:redstone_wire replace
setblock ~94 ~37 ~263 minecraft:redstone_wire replace
fill ~120 ~37 ~266 ~125 ~37 ~266 minecraft:redstone_wire replace
setblock ~124 ~37 ~267 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~37 ~270 ~105 ~37 ~270 minecraft:redstone_wire replace
setblock ~107 ~37 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~37 ~270 ~122 ~37 ~270 minecraft:redstone_wire replace
setblock ~124 ~37 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~37 ~270 ~139 ~37 ~270 minecraft:redstone_wire replace
setblock ~141 ~37 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~37 ~270 ~157 ~37 ~270 minecraft:redstone_wire replace
setblock ~159 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~161 ~37 ~270 ~174 ~37 ~270 minecraft:redstone_wire replace
setblock ~176 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~37 ~270 ~191 ~37 ~270 minecraft:redstone_wire replace
setblock ~193 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~37 ~270 ~208 ~37 ~270 minecraft:redstone_wire replace
setblock ~210 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~37 ~270 ~225 ~37 ~270 minecraft:redstone_wire replace
setblock ~227 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~37 ~270 ~242 ~37 ~270 minecraft:redstone_wire replace
setblock ~244 ~37 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~246 ~37 ~270 ~254 ~37 ~270 minecraft:redstone_wire replace
setblock ~94 ~37 ~271 minecraft:redstone_wire replace
setblock ~127 ~37 ~271 minecraft:redstone_wire replace
setblock ~154 ~37 ~271 minecraft:redstone_wire replace
setblock ~184 ~37 ~271 minecraft:redstone_wire replace
setblock ~253 ~37 ~271 minecraft:redstone_wire replace
fill ~147 ~37 ~274 ~148 ~37 ~274 minecraft:redstone_wire replace
setblock ~150 ~37 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~37 ~274 ~165 ~37 ~274 minecraft:redstone_wire replace
setblock ~167 ~37 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~37 ~274 ~191 ~37 ~274 minecraft:redstone_wire replace
setblock ~193 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~37 ~274 ~208 ~37 ~274 minecraft:redstone_wire replace
setblock ~210 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~37 ~274 ~225 ~37 ~274 minecraft:redstone_wire replace
setblock ~227 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~37 ~274 ~242 ~37 ~274 minecraft:redstone_wire replace
setblock ~243 ~37 ~274 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~37 ~274 ~245 ~37 ~274 minecraft:redstone_wire replace
setblock ~148 ~37 ~275 minecraft:redstone_wire replace
setblock ~175 ~37 ~275 minecraft:redstone_wire replace
setblock ~244 ~37 ~275 minecraft:redstone_wire replace
fill ~96 ~37 ~278 ~108 ~37 ~278 minecraft:redstone_wire replace
setblock ~110 ~37 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~37 ~278 ~125 ~37 ~278 minecraft:redstone_wire replace
setblock ~126 ~37 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~37 ~278 ~140 ~37 ~278 minecraft:redstone_wire replace
setblock ~142 ~37 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~37 ~278 ~168 ~37 ~278 minecraft:redstone_wire replace
setblock ~170 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~37 ~278 ~185 ~37 ~278 minecraft:redstone_wire replace
setblock ~187 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~37 ~278 ~202 ~37 ~278 minecraft:redstone_wire replace
setblock ~204 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~206 ~37 ~278 ~219 ~37 ~278 minecraft:redstone_wire replace
setblock ~221 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~37 ~278 ~236 ~37 ~278 minecraft:redstone_wire replace
setblock ~238 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~37 ~278 ~253 ~37 ~278 minecraft:redstone_wire replace
setblock ~254 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~97 ~37 ~279 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~37 ~279 minecraft:redstone_wire replace
setblock ~154 ~37 ~279 minecraft:redstone_wire replace
setblock ~184 ~37 ~279 minecraft:redstone_wire replace
setblock ~253 ~37 ~279 minecraft:redstone_wire replace
fill ~117 ~37 ~282 ~122 ~37 ~282 minecraft:redstone_wire replace
setblock ~121 ~37 ~283 minecraft:redstone_wire replace
fill ~141 ~37 ~286 ~152 ~37 ~286 minecraft:redstone_wire replace
setblock ~151 ~37 ~287 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~37 ~290 ~124 ~37 ~290 minecraft:redstone_wire replace
setblock ~126 ~37 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~37 ~290 ~141 ~37 ~290 minecraft:redstone_wire replace
setblock ~143 ~37 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~37 ~290 ~158 ~37 ~290 minecraft:redstone_wire replace
setblock ~160 ~37 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~37 ~290 ~180 ~37 ~290 minecraft:redstone_wire replace
setblock ~182 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~184 ~37 ~290 ~197 ~37 ~290 minecraft:redstone_wire replace
setblock ~199 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~201 ~37 ~290 ~214 ~37 ~290 minecraft:redstone_wire replace
setblock ~216 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~218 ~37 ~290 ~231 ~37 ~290 minecraft:redstone_wire replace
setblock ~233 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~37 ~290 ~248 ~37 ~290 minecraft:redstone_wire replace
setblock ~250 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~37 ~290 ~254 ~37 ~290 minecraft:redstone_wire replace
setblock ~121 ~37 ~291 minecraft:redstone_wire replace
setblock ~148 ~37 ~291 minecraft:redstone_wire replace
setblock ~154 ~37 ~291 minecraft:redstone_wire replace
setblock ~175 ~37 ~291 minecraft:redstone_wire replace
setblock ~184 ~37 ~291 minecraft:redstone_wire replace
setblock ~244 ~37 ~291 minecraft:redstone_wire replace
setblock ~253 ~37 ~291 minecraft:redstone_wire replace
fill ~177 ~37 ~294 ~180 ~37 ~294 minecraft:redstone_wire replace
setblock ~182 ~37 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~37 ~294 ~197 ~37 ~294 minecraft:redstone_wire replace
setblock ~199 ~37 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~37 ~294 ~225 ~37 ~294 minecraft:redstone_wire replace
setblock ~227 ~37 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~37 ~294 ~242 ~37 ~294 minecraft:redstone_wire replace
setblock ~244 ~37 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~246 ~37 ~294 ~248 ~37 ~294 minecraft:redstone_wire replace
setblock ~178 ~37 ~295 minecraft:redstone_wire replace
setblock ~247 ~37 ~295 minecraft:redstone_wire replace
fill ~144 ~37 ~298 ~153 ~37 ~298 minecraft:redstone_wire replace
setblock ~155 ~37 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~37 ~298 ~158 ~37 ~298 minecraft:redstone_wire replace
setblock ~157 ~37 ~299 minecraft:redstone_wire replace
fill ~168 ~37 ~302 ~173 ~37 ~302 minecraft:redstone_wire replace
setblock ~175 ~37 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~37 ~302 ~182 ~37 ~302 minecraft:redstone_wire replace
setblock ~181 ~37 ~303 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~37 ~306 ~168 ~37 ~306 minecraft:redstone_wire replace
setblock ~170 ~37 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~37 ~306 ~185 ~37 ~306 minecraft:redstone_wire replace
setblock ~187 ~37 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~37 ~306 ~213 ~37 ~306 minecraft:redstone_wire replace
setblock ~215 ~37 ~306 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~37 ~306 ~230 ~37 ~306 minecraft:redstone_wire replace
setblock ~232 ~37 ~306 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~37 ~306 ~247 ~37 ~306 minecraft:redstone_wire replace
setblock ~248 ~37 ~306 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~37 ~306 ~254 ~37 ~306 minecraft:redstone_wire replace
setblock ~157 ~37 ~307 minecraft:redstone_wire replace
setblock ~175 ~37 ~307 minecraft:redstone_wire replace
setblock ~178 ~37 ~307 minecraft:redstone_wire replace
setblock ~184 ~37 ~307 minecraft:redstone_wire replace
setblock ~244 ~37 ~307 minecraft:redstone_wire replace
setblock ~247 ~37 ~307 minecraft:redstone_wire replace
setblock ~253 ~37 ~307 minecraft:redstone_wire replace
fill ~249 ~37 ~310 ~255 ~37 ~310 minecraft:redstone_wire replace
setblock ~250 ~37 ~311 minecraft:redstone_wire replace
fill ~174 ~37 ~314 ~185 ~37 ~314 minecraft:redstone_wire replace
setblock ~186 ~37 ~314 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~37 ~314 ~188 ~37 ~314 minecraft:redstone_wire replace
setblock ~187 ~37 ~315 minecraft:redstone_wire replace
fill ~186 ~37 ~318 ~191 ~37 ~318 minecraft:redstone_wire replace
setblock ~193 ~37 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~37 ~318 ~208 ~37 ~318 minecraft:redstone_wire replace
setblock ~210 ~37 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~37 ~318 ~225 ~37 ~318 minecraft:redstone_wire replace
setblock ~227 ~37 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~37 ~318 ~251 ~37 ~318 minecraft:redstone_wire replace
setblock ~252 ~37 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~37 ~318 ~254 ~37 ~318 minecraft:redstone_wire replace
setblock ~187 ~37 ~319 minecraft:redstone_wire replace
setblock ~244 ~37 ~319 minecraft:redstone_wire replace
setblock ~247 ~37 ~319 minecraft:redstone_wire replace
setblock ~250 ~37 ~319 minecraft:redstone_wire replace
setblock ~253 ~37 ~319 minecraft:redstone_wire replace
fill ~255 ~37 ~322 ~258 ~37 ~322 minecraft:redstone_wire replace
setblock ~256 ~37 ~323 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~37 ~326 ~203 ~37 ~326 minecraft:redstone_wire replace
setblock ~202 ~37 ~327 minecraft:redstone_wire replace
fill ~222 ~37 ~330 ~225 ~37 ~330 minecraft:redstone_wire replace
setblock ~223 ~37 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~37 ~334 ~203 ~37 ~334 minecraft:redstone_wire replace
setblock ~205 ~37 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~37 ~334 ~220 ~37 ~334 minecraft:redstone_wire replace
setblock ~222 ~37 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~37 ~334 ~237 ~37 ~334 minecraft:redstone_wire replace
setblock ~239 ~37 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~37 ~334 ~251 ~37 ~334 minecraft:redstone_wire replace
setblock ~253 ~37 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~37 ~334 ~268 ~37 ~334 minecraft:redstone_wire replace
setblock ~270 ~37 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~272 ~37 ~334 ~281 ~37 ~334 minecraft:redstone_wire replace
setblock ~202 ~37 ~335 minecraft:redstone_wire replace
setblock ~280 ~37 ~335 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~37 ~338 ~270 ~37 ~338 minecraft:redstone_wire replace
setblock ~272 ~37 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~37 ~338 ~287 ~37 ~338 minecraft:redstone_wire replace
setblock ~289 ~37 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~37 ~338 ~314 ~37 ~338 minecraft:redstone_wire replace
setblock ~315 ~37 ~338 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~316 ~37 ~338 ~328 ~37 ~338 minecraft:redstone_wire replace
setblock ~329 ~37 ~338 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~37 ~338 ~332 ~37 ~338 minecraft:redstone_wire replace
setblock ~259 ~37 ~339 minecraft:redstone_wire replace
setblock ~316 ~37 ~339 minecraft:redstone_wire replace
setblock ~331 ~37 ~339 minecraft:redstone_wire replace
fill ~225 ~37 ~342 ~228 ~37 ~342 minecraft:redstone_wire replace
setblock ~226 ~37 ~343 minecraft:redstone_wire replace
fill ~261 ~37 ~346 ~263 ~37 ~346 minecraft:redstone_wire replace
setblock ~262 ~37 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~37 ~350 ~233 ~37 ~350 minecraft:redstone_wire replace
setblock ~235 ~37 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~37 ~350 ~250 ~37 ~350 minecraft:redstone_wire replace
setblock ~252 ~37 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~37 ~350 ~267 ~37 ~350 minecraft:redstone_wire replace
setblock ~269 ~37 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~37 ~350 ~293 ~37 ~350 minecraft:redstone_wire replace
setblock ~295 ~37 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~37 ~350 ~310 ~37 ~350 minecraft:redstone_wire replace
setblock ~312 ~37 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~37 ~350 ~327 ~37 ~350 minecraft:redstone_wire replace
setblock ~329 ~37 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~37 ~350 ~332 ~37 ~350 minecraft:redstone_wire replace
setblock ~226 ~37 ~351 minecraft:redstone_wire replace
setblock ~259 ~37 ~351 minecraft:redstone_wire replace
setblock ~298 ~37 ~351 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~316 ~37 ~351 minecraft:redstone_wire replace
setblock ~331 ~37 ~351 minecraft:redstone_wire replace
fill ~318 ~37 ~354 ~322 ~37 ~354 minecraft:redstone_wire replace
setblock ~324 ~37 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~326 ~37 ~354 ~335 ~37 ~354 minecraft:redstone_wire replace
setblock ~319 ~37 ~355 minecraft:redstone_wire replace
setblock ~334 ~37 ~355 minecraft:redstone_wire replace
fill ~264 ~37 ~358 ~266 ~37 ~358 minecraft:redstone_wire replace
setblock ~265 ~37 ~359 minecraft:redstone_wire replace
fill ~264 ~37 ~362 ~268 ~37 ~362 minecraft:redstone_wire replace
setblock ~270 ~37 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~37 ~362 ~285 ~37 ~362 minecraft:redstone_wire replace
setblock ~287 ~37 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~37 ~362 ~302 ~37 ~362 minecraft:redstone_wire replace
setblock ~304 ~37 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~37 ~362 ~324 ~37 ~362 minecraft:redstone_wire replace
setblock ~326 ~37 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~328 ~37 ~362 ~335 ~37 ~362 minecraft:redstone_wire replace
setblock ~265 ~37 ~363 minecraft:redstone_wire replace
setblock ~316 ~37 ~363 minecraft:redstone_wire replace
setblock ~319 ~37 ~363 minecraft:redstone_wire replace
setblock ~322 ~37 ~363 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~331 ~37 ~363 minecraft:redstone_wire replace
setblock ~334 ~37 ~363 minecraft:redstone_wire replace
fill ~324 ~37 ~366 ~326 ~37 ~366 minecraft:redstone_wire replace
setblock ~325 ~37 ~367 minecraft:redstone_wire replace
fill ~336 ~37 ~370 ~339 ~37 ~370 minecraft:redstone_wire replace
setblock ~337 ~37 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~37 ~374 ~330 ~37 ~374 minecraft:redstone_wire replace
setblock ~332 ~37 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~37 ~374 ~341 ~37 ~374 minecraft:redstone_wire replace
setblock ~313 ~37 ~375 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~316 ~37 ~375 minecraft:redstone_wire replace
setblock ~319 ~37 ~375 minecraft:redstone_wire replace
setblock ~325 ~37 ~375 minecraft:redstone_wire replace
setblock ~340 ~37 ~375 minecraft:redstone_wire replace
fill ~327 ~37 ~378 ~336 ~37 ~378 minecraft:redstone_wire replace
setblock ~328 ~37 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~37 ~382 ~342 ~37 ~382 minecraft:redstone_wire replace
setblock ~340 ~37 ~383 minecraft:redstone_wire replace
fill ~285 ~37 ~386 ~287 ~37 ~386 minecraft:redstone_wire replace
setblock ~286 ~37 ~387 minecraft:redstone_wire replace
fill ~285 ~37 ~390 ~295 ~37 ~390 minecraft:redstone_wire replace
setblock ~297 ~37 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~299 ~37 ~390 ~312 ~37 ~390 minecraft:redstone_wire replace
setblock ~314 ~37 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~316 ~37 ~390 ~338 ~37 ~390 minecraft:redstone_wire replace
setblock ~340 ~37 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~37 ~390 ~355 ~37 ~390 minecraft:redstone_wire replace
setblock ~357 ~37 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~359 ~37 ~390 ~365 ~37 ~390 minecraft:redstone_wire replace
setblock ~286 ~37 ~391 minecraft:redstone_wire replace
setblock ~364 ~37 ~391 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~37 ~394 ~350 ~37 ~394 minecraft:redstone_wire replace
setblock ~349 ~37 ~395 minecraft:redstone_wire replace
fill ~384 ~37 ~398 ~387 ~37 ~398 minecraft:redstone_wire replace
setblock ~385 ~37 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~351 ~37 ~402 ~354 ~37 ~402 minecraft:redstone_wire replace
setblock ~352 ~37 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~37 ~406 ~346 ~37 ~406 minecraft:redstone_wire replace
setblock ~347 ~37 ~406 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~37 ~406 ~372 ~37 ~406 minecraft:redstone_wire replace
setblock ~374 ~37 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~376 ~37 ~406 ~377 ~37 ~406 minecraft:redstone_wire replace
setblock ~346 ~37 ~407 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~349 ~37 ~407 minecraft:redstone_wire replace
setblock ~376 ~37 ~407 minecraft:redstone_wire replace
fill ~375 ~37 ~410 ~378 ~37 ~410 minecraft:redstone_wire replace
setblock ~376 ~37 ~411 minecraft:redstone_wire replace
fill ~90 ~37 ~414 ~92 ~37 ~414 minecraft:redstone_wire replace
setblock ~91 ~37 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~37 ~418 ~119 ~37 ~418 minecraft:redstone_wire replace
setblock ~118 ~37 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~37 ~422 ~146 ~37 ~422 minecraft:redstone_wire replace
setblock ~145 ~37 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~37 ~426 ~194 ~37 ~426 minecraft:redstone_wire replace
setblock ~193 ~37 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~37 ~430 ~216 ~37 ~430 minecraft:redstone_wire replace
setblock ~214 ~37 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~37 ~434 ~243 ~37 ~434 minecraft:redstone_wire replace
setblock ~238 ~37 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~279 ~37 ~438 ~284 ~37 ~438 minecraft:redstone_wire replace
setblock ~283 ~37 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~37 ~442 ~309 ~37 ~442 minecraft:redstone_wire replace
setblock ~307 ~37 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~37 ~446 ~345 ~37 ~446 minecraft:redstone_wire replace
setblock ~343 ~37 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~37 ~450 ~89 ~37 ~450 minecraft:redstone_wire replace
setblock ~88 ~37 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~37 ~454 ~116 ~37 ~454 minecraft:redstone_wire replace
setblock ~115 ~37 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~37 ~458 ~143 ~37 ~458 minecraft:redstone_wire replace
setblock ~142 ~37 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~37 ~462 ~191 ~37 ~462 minecraft:redstone_wire replace
setblock ~190 ~37 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~37 ~466 ~212 ~37 ~466 minecraft:redstone_wire replace
setblock ~211 ~37 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~37 ~470 ~237 ~37 ~470 minecraft:redstone_wire replace
setblock ~235 ~37 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~37 ~474 ~278 ~37 ~474 minecraft:redstone_wire replace
setblock ~277 ~37 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~37 ~478 ~306 ~37 ~478 minecraft:redstone_wire replace
setblock ~304 ~37 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~366 ~37 ~482 ~369 ~37 ~482 minecraft:redstone_wire replace
setblock ~367 ~37 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~390 ~37 ~486 ~393 ~37 ~486 minecraft:redstone_wire replace
setblock ~391 ~37 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~37 ~490 ~86 ~37 ~490 minecraft:redstone_wire replace
setblock ~85 ~37 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~37 ~494 ~113 ~37 ~494 minecraft:redstone_wire replace
setblock ~112 ~37 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~37 ~498 ~140 ~37 ~498 minecraft:redstone_wire replace
setblock ~139 ~37 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~37 ~502 ~173 ~37 ~502 minecraft:redstone_wire replace
setblock ~172 ~37 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~37 ~506 ~209 ~37 ~506 minecraft:redstone_wire replace
setblock ~208 ~37 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~37 ~510 ~234 ~37 ~510 minecraft:redstone_wire replace
setblock ~232 ~37 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~37 ~514 ~275 ~37 ~514 minecraft:redstone_wire replace
setblock ~274 ~37 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~37 ~518 ~302 ~37 ~518 minecraft:redstone_wire replace
setblock ~301 ~37 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~360 ~37 ~522 ~366 ~37 ~522 minecraft:redstone_wire replace
setblock ~361 ~37 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~387 ~37 ~526 ~390 ~37 ~526 minecraft:redstone_wire replace
setblock ~388 ~37 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~37 ~530 ~83 ~37 ~530 minecraft:redstone_wire replace
setblock ~82 ~37 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~37 ~534 ~110 ~37 ~534 minecraft:redstone_wire replace
setblock ~109 ~37 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~37 ~538 ~137 ~37 ~538 minecraft:redstone_wire replace
setblock ~136 ~37 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~37 ~542 ~167 ~37 ~542 minecraft:redstone_wire replace
setblock ~166 ~37 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~37 ~546 ~206 ~37 ~546 minecraft:redstone_wire replace
setblock ~205 ~37 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~37 ~550 ~231 ~37 ~550 minecraft:redstone_wire replace
setblock ~229 ~37 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~37 ~554 ~272 ~37 ~554 minecraft:redstone_wire replace
setblock ~271 ~37 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~37 ~558 ~293 ~37 ~558 minecraft:redstone_wire replace
setblock ~292 ~37 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~37 ~562 ~363 ~37 ~562 minecraft:redstone_wire replace
setblock ~358 ~37 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~381 ~37 ~566 ~384 ~37 ~566 minecraft:redstone_wire replace
setblock ~382 ~37 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~37 ~570 ~80 ~37 ~570 minecraft:redstone_wire replace
setblock ~79 ~37 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~37 ~574 ~107 ~37 ~574 minecraft:redstone_wire replace
setblock ~106 ~37 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~37 ~578 ~134 ~37 ~578 minecraft:redstone_wire replace
setblock ~133 ~37 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~37 ~582 ~164 ~37 ~582 minecraft:redstone_wire replace
setblock ~163 ~37 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~37 ~586 ~200 ~37 ~586 minecraft:redstone_wire replace
setblock ~199 ~37 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~37 ~590 ~222 ~37 ~590 minecraft:redstone_wire replace
setblock ~220 ~37 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~37 ~594 ~269 ~37 ~594 minecraft:redstone_wire replace
setblock ~268 ~37 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~37 ~598 ~290 ~37 ~598 minecraft:redstone_wire replace
setblock ~289 ~37 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~37 ~602 ~357 ~37 ~602 minecraft:redstone_wire replace
setblock ~355 ~37 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~378 ~37 ~606 ~381 ~37 ~606 minecraft:redstone_wire replace
setblock ~379 ~37 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~37 ~610 ~104 ~37 ~610 minecraft:redstone_wire replace
setblock ~103 ~37 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~37 ~614 ~131 ~37 ~614 minecraft:redstone_wire replace
setblock ~130 ~37 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~37 ~618 ~158 ~37 ~618 minecraft:redstone_wire replace
setblock ~159 ~37 ~618 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~37 ~618 ~161 ~37 ~618 minecraft:redstone_wire replace
setblock ~160 ~37 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~37 ~622 ~197 ~37 ~622 minecraft:redstone_wire replace
setblock ~196 ~37 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~216 ~37 ~626 ~219 ~37 ~626 minecraft:redstone_wire replace
setblock ~217 ~37 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~37 ~630 ~249 ~37 ~630 minecraft:redstone_wire replace
setblock ~241 ~37 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~37 ~634 ~296 ~37 ~634 minecraft:redstone_wire replace
setblock ~295 ~37 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~309 ~37 ~638 ~312 ~37 ~638 minecraft:redstone_wire replace
setblock ~310 ~37 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~369 ~37 ~642 ~372 ~37 ~642 minecraft:redstone_wire replace
setblock ~370 ~37 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~37 ~646 ~170 ~37 ~646 minecraft:redstone_wire replace
setblock ~169 ~37 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~37 ~650 ~399 ~37 ~650 minecraft:redstone_wire replace
setblock ~397 ~37 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~37 ~654 ~101 ~37 ~654 minecraft:redstone_wire replace
setblock ~100 ~37 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~37 ~658 ~375 ~37 ~658 minecraft:redstone_wire replace
setblock ~373 ~37 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~393 ~37 ~662 ~396 ~37 ~662 minecraft:redstone_wire replace
setblock ~394 ~37 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~38 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~38 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~38 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~38 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~38 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~38 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~38 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~38 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~38 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~38 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~38 ~268 minecraft:redstone_wire replace
setblock ~94 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~38 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~38 ~280 minecraft:redstone_wire replace
setblock ~127 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~38 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~38 ~288 minecraft:redstone_wire replace
setblock ~121 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~38 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~38 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~38 ~304 minecraft:redstone_wire replace
setblock ~157 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~38 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~38 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~320 minecraft:redstone_torch[lit=true] replace
