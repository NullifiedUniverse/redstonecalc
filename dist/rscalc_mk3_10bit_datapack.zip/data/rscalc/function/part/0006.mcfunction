setblock ~190 ~25 ~160 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~168 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~183 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~185 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~164 minecraft:light_gray_concrete replace
setblock ~169 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~171 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~186 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~188 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~196 ~25 ~168 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~189 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~191 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~172 minecraft:light_gray_concrete replace
setblock ~232 ~25 ~172 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~174 minecraft:light_gray_concrete replace
setblock ~216 ~25 ~174 minecraft:light_gray_concrete replace
setblock ~217 ~25 ~176 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~178 minecraft:light_gray_concrete replace
setblock ~204 ~25 ~178 minecraft:light_gray_concrete replace
setblock ~220 ~25 ~180 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~182 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~182 minecraft:light_gray_concrete replace
setblock ~223 ~25 ~184 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~186 minecraft:light_gray_concrete replace
setblock ~209 ~25 ~186 minecraft:light_gray_concrete replace
setblock ~253 ~25 ~188 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~188 minecraft:light_gray_concrete replace
setblock ~228 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~230 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~245 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~192 minecraft:light_gray_concrete replace
setblock ~222 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~239 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~196 minecraft:light_gray_concrete replace
setblock ~225 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~242 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~200 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~246 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~286 ~25 ~204 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~204 minecraft:light_gray_concrete replace
setblock ~251 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~253 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~270 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~295 ~25 ~208 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~208 minecraft:light_gray_concrete replace
setblock ~254 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~271 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~273 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~288 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~290 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~212 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~285 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~302 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~216 minecraft:light_gray_concrete replace
setblock ~275 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~334 ~25 ~220 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~284 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~330 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~332 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~224 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~243 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~258 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~260 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~228 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~249 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~264 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~232 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~252 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~267 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~269 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~304 ~25 ~236 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~236 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~267 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~284 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~301 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~322 ~25 ~240 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~240 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~279 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~346 ~25 ~244 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~291 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~306 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~308 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~323 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~340 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~342 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~349 ~25 ~248 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~345 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~352 ~25 ~252 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~330 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~345 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~347 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~136 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~148 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~160 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~184 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~211 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~232 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~253 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~286 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~295 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~304 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~322 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~143 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~192 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~217 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~219 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~234 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~236 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~285 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~302 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~317 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~91 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~112 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~199 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~235 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~262 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~340 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~108 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~110 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~125 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~127 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~142 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~144 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~159 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~161 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~178 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~195 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~209 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~211 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~225 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~243 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~257 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~273 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~275 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~291 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~305 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~321 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~323 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~337 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~339 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~88 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~109 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~169 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~196 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~223 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~334 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~352 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~92 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~122 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~138 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~140 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~170 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~210 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~212 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~246 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~261 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~263 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~293 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~295 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~310 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~312 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~327 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~329 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~344 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~346 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~85 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~106 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~220 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~349 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~96 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~111 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~113 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~128 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~162 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~192 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~209 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~226 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~243 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~258 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~260 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~290 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~324 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~341 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~82 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~103 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~151 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~217 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~346 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~88 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~90 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~105 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~107 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~122 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~141 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~158 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~184 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~186 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~201 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~203 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~233 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~235 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~252 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~284 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~301 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~318 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~333 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~335 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~79 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~100 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~118 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~187 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~87 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~89 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~104 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~106 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~123 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~138 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~140 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~155 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~204 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~218 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~220 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~234 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~236 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~252 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~312 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~330 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~97 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~115 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~142 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~175 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~238 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~271 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~337 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~99 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~101 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~131 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~148 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~150 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~189 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~191 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~206 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~208 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~223 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~225 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~240 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~242 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~257 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~276 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~306 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~308 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~323 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~163 ~25 ~284 minecraft:light_gray_concrete replace
setblock ~148 ~25 ~286 minecraft:light_gray_concrete replace
setblock ~150 ~25 ~286 minecraft:light_gray_concrete replace
setblock ~358 ~25 ~296 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~345 ~25 ~298 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~300 minecraft:light_gray_concrete replace
setblock ~340 ~25 ~300 minecraft:light_gray_concrete replace
setblock ~355 ~25 ~300 minecraft:light_gray_concrete replace
setblock ~111 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~113 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~128 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~162 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~179 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~196 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~198 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~213 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~215 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~231 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~246 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~248 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~263 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~297 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~333 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~348 ~25 ~302 minecraft:light_gray_concrete replace
setblock ~350 ~25 ~302 minecraft:light_gray_concrete replace
fill ~78 ~26 ~4 ~78 ~26 ~500 minecraft:light_gray_concrete replace
fill ~96 ~26 ~8 ~96 ~26 ~540 minecraft:light_gray_concrete replace
fill ~126 ~26 ~8 ~126 ~26 ~12 minecraft:light_gray_concrete replace
fill ~99 ~26 ~12 ~99 ~26 ~504 minecraft:light_gray_concrete replace
fill ~90 ~26 ~16 ~90 ~26 ~344 minecraft:light_gray_concrete replace
fill ~114 ~26 ~16 ~114 ~26 ~544 minecraft:light_gray_concrete replace
fill ~153 ~26 ~16 ~153 ~26 ~20 minecraft:light_gray_concrete replace
fill ~117 ~26 ~20 ~117 ~26 ~508 minecraft:light_gray_concrete replace
fill ~111 ~26 ~24 ~111 ~26 ~348 minecraft:light_gray_concrete replace
fill ~141 ~26 ~24 ~141 ~26 ~548 minecraft:light_gray_concrete replace
fill ~177 ~26 ~24 ~177 ~26 ~28 minecraft:light_gray_concrete replace
fill ~144 ~26 ~28 ~144 ~26 ~512 minecraft:light_gray_concrete replace
fill ~138 ~26 ~32 ~138 ~26 ~352 minecraft:light_gray_concrete replace
fill ~174 ~26 ~32 ~174 ~26 ~552 minecraft:light_gray_concrete replace
fill ~207 ~26 ~32 ~207 ~26 ~36 minecraft:light_gray_concrete replace
fill ~186 ~26 ~36 ~186 ~26 ~516 minecraft:light_gray_concrete replace
fill ~171 ~26 ~40 ~171 ~26 ~356 minecraft:light_gray_concrete replace
fill ~201 ~26 ~40 ~201 ~26 ~556 minecraft:light_gray_concrete replace
fill ~225 ~26 ~40 ~225 ~26 ~44 minecraft:light_gray_concrete replace
fill ~204 ~26 ~44 ~204 ~26 ~520 minecraft:light_gray_concrete replace
fill ~198 ~26 ~48 ~198 ~26 ~360 minecraft:light_gray_concrete replace
fill ~237 ~26 ~48 ~237 ~26 ~560 minecraft:light_gray_concrete replace
fill ~249 ~26 ~48 ~249 ~26 ~52 minecraft:light_gray_concrete replace
fill ~240 ~26 ~52 ~240 ~26 ~524 minecraft:light_gray_concrete replace
fill ~234 ~26 ~56 ~234 ~26 ~364 minecraft:light_gray_concrete replace
fill ~282 ~26 ~56 ~282 ~26 ~60 minecraft:light_gray_concrete replace
fill ~291 ~26 ~56 ~291 ~26 ~568 minecraft:light_gray_concrete replace
fill ~261 ~26 ~60 ~261 ~26 ~368 minecraft:light_gray_concrete replace
fill ~270 ~26 ~60 ~270 ~26 ~564 minecraft:light_gray_concrete replace
fill ~300 ~26 ~60 ~300 ~26 ~64 minecraft:light_gray_concrete replace
fill ~315 ~26 ~64 ~315 ~26 ~532 minecraft:light_gray_concrete replace
fill ~264 ~26 ~68 ~264 ~26 ~528 minecraft:light_gray_concrete replace
fill ~309 ~26 ~72 ~309 ~26 ~76 minecraft:light_gray_concrete replace
fill ~312 ~26 ~72 ~312 ~26 ~376 minecraft:light_gray_concrete replace
fill ~336 ~26 ~72 ~336 ~26 ~572 minecraft:light_gray_concrete replace
fill ~279 ~26 ~76 ~279 ~26 ~372 minecraft:light_gray_concrete replace
fill ~327 ~26 ~76 ~327 ~26 ~80 minecraft:light_gray_concrete replace
fill ~342 ~26 ~80 ~342 ~26 ~536 minecraft:light_gray_concrete replace
fill ~81 ~26 ~84 ~81 ~26 ~460 minecraft:light_gray_concrete replace
fill ~84 ~26 ~88 ~84 ~26 ~420 minecraft:light_gray_concrete replace
fill ~87 ~26 ~92 ~87 ~26 ~380 minecraft:light_gray_concrete replace
fill ~132 ~26 ~100 ~132 ~26 ~260 minecraft:light_gray_concrete replace
fill ~135 ~26 ~100 ~135 ~26 ~264 minecraft:light_gray_concrete replace
fill ~102 ~26 ~104 ~102 ~26 ~464 minecraft:light_gray_concrete replace
fill ~105 ~26 ~108 ~105 ~26 ~424 minecraft:light_gray_concrete replace
fill ~108 ~26 ~112 ~108 ~26 ~384 minecraft:light_gray_concrete replace
fill ~156 ~26 ~120 ~156 ~26 ~272 minecraft:light_gray_concrete replace
fill ~159 ~26 ~120 ~159 ~26 ~276 minecraft:light_gray_concrete replace
fill ~120 ~26 ~124 ~120 ~26 ~468 minecraft:light_gray_concrete replace
fill ~123 ~26 ~128 ~123 ~26 ~428 minecraft:light_gray_concrete replace
fill ~129 ~26 ~132 ~129 ~26 ~388 minecraft:light_gray_concrete replace
fill ~180 ~26 ~140 ~180 ~26 ~280 minecraft:light_gray_concrete replace
fill ~183 ~26 ~140 ~183 ~26 ~284 minecraft:light_gray_concrete replace
fill ~150 ~26 ~144 ~150 ~26 ~472 minecraft:light_gray_concrete replace
fill ~165 ~26 ~148 ~165 ~26 ~432 minecraft:light_gray_concrete replace
fill ~168 ~26 ~152 ~168 ~26 ~392 minecraft:light_gray_concrete replace
fill ~210 ~26 ~156 ~210 ~26 ~288 minecraft:light_gray_concrete replace
fill ~213 ~26 ~156 ~213 ~26 ~292 minecraft:light_gray_concrete replace
fill ~189 ~26 ~160 ~189 ~26 ~476 minecraft:light_gray_concrete replace
fill ~192 ~26 ~164 ~192 ~26 ~436 minecraft:light_gray_concrete replace
fill ~195 ~26 ~168 ~195 ~26 ~396 minecraft:light_gray_concrete replace
fill ~228 ~26 ~172 ~228 ~26 ~296 minecraft:light_gray_concrete replace
fill ~231 ~26 ~172 ~231 ~26 ~300 minecraft:light_gray_concrete replace
fill ~216 ~26 ~176 ~216 ~26 ~480 minecraft:light_gray_concrete replace
fill ~219 ~26 ~180 ~219 ~26 ~440 minecraft:light_gray_concrete replace
fill ~222 ~26 ~184 ~222 ~26 ~400 minecraft:light_gray_concrete replace
fill ~252 ~26 ~188 ~252 ~26 ~304 minecraft:light_gray_concrete replace
fill ~255 ~26 ~188 ~255 ~26 ~308 minecraft:light_gray_concrete replace
fill ~243 ~26 ~192 ~243 ~26 ~484 minecraft:light_gray_concrete replace
fill ~246 ~26 ~196 ~246 ~26 ~444 minecraft:light_gray_concrete replace
fill ~258 ~26 ~200 ~258 ~26 ~404 minecraft:light_gray_concrete replace
fill ~285 ~26 ~204 ~285 ~26 ~312 minecraft:light_gray_concrete replace
fill ~288 ~26 ~204 ~288 ~26 ~316 minecraft:light_gray_concrete replace
fill ~294 ~26 ~208 ~294 ~26 ~320 minecraft:light_gray_concrete replace
fill ~297 ~26 ~208 ~297 ~26 ~324 minecraft:light_gray_concrete replace
fill ~318 ~26 ~212 ~318 ~26 ~492 minecraft:light_gray_concrete replace
fill ~330 ~26 ~216 ~330 ~26 ~452 minecraft:light_gray_concrete replace
fill ~333 ~26 ~220 ~333 ~26 ~412 minecraft:light_gray_concrete replace
fill ~267 ~26 ~224 ~267 ~26 ~488 minecraft:light_gray_concrete replace
fill ~273 ~26 ~228 ~273 ~26 ~448 minecraft:light_gray_concrete replace
fill ~276 ~26 ~232 ~276 ~26 ~408 minecraft:light_gray_concrete replace
fill ~303 ~26 ~236 ~303 ~26 ~328 minecraft:light_gray_concrete replace
fill ~306 ~26 ~236 ~306 ~26 ~332 minecraft:light_gray_concrete replace
fill ~321 ~26 ~240 ~321 ~26 ~336 minecraft:light_gray_concrete replace
fill ~324 ~26 ~240 ~324 ~26 ~340 minecraft:light_gray_concrete replace
fill ~345 ~26 ~244 ~345 ~26 ~496 minecraft:light_gray_concrete replace
fill ~348 ~26 ~248 ~348 ~26 ~456 minecraft:light_gray_concrete replace
fill ~351 ~26 ~252 ~351 ~26 ~416 minecraft:light_gray_concrete replace
fill ~147 ~26 ~256 ~147 ~26 ~268 minecraft:light_gray_concrete replace
fill ~339 ~26 ~260 ~339 ~26 ~588 minecraft:light_gray_concrete replace
fill ~93 ~26 ~280 ~93 ~26 ~584 minecraft:light_gray_concrete replace
fill ~162 ~26 ~284 ~162 ~26 ~576 minecraft:light_gray_concrete replace
fill ~357 ~26 ~296 ~357 ~26 ~580 minecraft:light_gray_concrete replace
fill ~354 ~26 ~300 ~354 ~26 ~592 minecraft:light_gray_concrete replace
setblock ~79 ~27 ~4 minecraft:light_gray_concrete replace
setblock ~97 ~27 ~8 minecraft:light_gray_concrete replace
setblock ~100 ~27 ~12 minecraft:light_gray_concrete replace
setblock ~126 ~27 ~13 minecraft:light_gray_concrete replace
setblock ~91 ~27 ~16 minecraft:light_gray_concrete replace
setblock ~115 ~27 ~16 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~17 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~19 minecraft:light_gray_concrete replace
setblock ~118 ~27 ~20 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~21 minecraft:light_gray_concrete replace
setblock ~153 ~27 ~21 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~23 minecraft:light_gray_concrete replace
setblock ~112 ~27 ~24 minecraft:light_gray_concrete replace
setblock ~142 ~27 ~24 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~25 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~27 minecraft:light_gray_concrete replace
setblock ~145 ~27 ~28 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~29 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~29 minecraft:light_gray_concrete replace
setblock ~177 ~27 ~29 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~31 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~31 minecraft:light_gray_concrete replace
setblock ~139 ~27 ~32 minecraft:light_gray_concrete replace
setblock ~175 ~27 ~32 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~33 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~33 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~35 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~35 minecraft:light_gray_concrete replace
setblock ~187 ~27 ~36 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~37 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~37 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~37 minecraft:light_gray_concrete replace
setblock ~207 ~27 ~37 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~39 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~39 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~39 minecraft:light_gray_concrete replace
setblock ~172 ~27 ~40 minecraft:light_gray_concrete replace
setblock ~202 ~27 ~40 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~41 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~41 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~43 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~43 minecraft:light_gray_concrete replace
setblock ~205 ~27 ~44 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~45 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~45 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~45 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~45 minecraft:light_gray_concrete replace
setblock ~225 ~27 ~45 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~47 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~47 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~47 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~47 minecraft:light_gray_concrete replace
setblock ~199 ~27 ~48 minecraft:light_gray_concrete replace
setblock ~238 ~27 ~48 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~49 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~49 minecraft:light_gray_concrete replace
