fill ~307 ~40 ~360 ~307 ~40 ~361 minecraft:light_gray_concrete replace
fill ~306 ~40 ~362 ~336 ~40 ~362 minecraft:light_gray_concrete replace
fill ~310 ~40 ~364 ~310 ~40 ~365 minecraft:light_gray_concrete replace
fill ~309 ~40 ~366 ~339 ~40 ~366 minecraft:light_gray_concrete replace
fill ~283 ~40 ~368 ~283 ~40 ~369 minecraft:light_gray_concrete replace
fill ~282 ~40 ~370 ~312 ~40 ~370 minecraft:light_gray_concrete replace
fill ~298 ~40 ~372 ~298 ~40 ~373 minecraft:light_gray_concrete replace
fill ~297 ~40 ~374 ~327 ~40 ~374 minecraft:light_gray_concrete replace
fill ~256 ~40 ~380 ~256 ~40 ~381 minecraft:light_gray_concrete replace
fill ~255 ~40 ~382 ~285 ~40 ~382 minecraft:light_gray_concrete replace
fill ~334 ~40 ~384 ~334 ~40 ~385 minecraft:light_gray_concrete replace
fill ~333 ~40 ~386 ~363 ~40 ~386 minecraft:light_gray_concrete replace
fill ~355 ~40 ~388 ~355 ~40 ~389 minecraft:light_gray_concrete replace
fill ~354 ~40 ~390 ~384 ~40 ~390 minecraft:light_gray_concrete replace
fill ~322 ~40 ~392 ~322 ~40 ~393 minecraft:light_gray_concrete replace
fill ~321 ~40 ~394 ~351 ~40 ~394 minecraft:light_gray_concrete replace
fill ~346 ~40 ~396 ~346 ~40 ~397 minecraft:light_gray_concrete replace
fill ~345 ~40 ~398 ~375 ~40 ~398 minecraft:light_gray_concrete replace
fill ~316 ~40 ~400 ~316 ~40 ~401 minecraft:light_gray_concrete replace
fill ~315 ~40 ~402 ~345 ~40 ~402 minecraft:light_gray_concrete replace
fill ~91 ~40 ~408 ~91 ~40 ~409 minecraft:light_gray_concrete replace
fill ~90 ~40 ~410 ~92 ~40 ~410 minecraft:light_gray_concrete replace
fill ~118 ~40 ~412 ~118 ~40 ~413 minecraft:light_gray_concrete replace
fill ~117 ~40 ~414 ~119 ~40 ~414 minecraft:light_gray_concrete replace
fill ~142 ~40 ~416 ~142 ~40 ~417 minecraft:light_gray_concrete replace
fill ~141 ~40 ~418 ~144 ~40 ~418 minecraft:light_gray_concrete replace
fill ~175 ~40 ~420 ~175 ~40 ~421 minecraft:light_gray_concrete replace
fill ~174 ~40 ~422 ~192 ~40 ~422 minecraft:light_gray_concrete replace
fill ~196 ~40 ~424 ~196 ~40 ~425 minecraft:light_gray_concrete replace
fill ~195 ~40 ~426 ~213 ~40 ~426 minecraft:light_gray_concrete replace
fill ~220 ~40 ~428 ~220 ~40 ~429 minecraft:light_gray_concrete replace
fill ~219 ~40 ~430 ~237 ~40 ~430 minecraft:light_gray_concrete replace
fill ~253 ~40 ~432 ~253 ~40 ~433 minecraft:light_gray_concrete replace
fill ~252 ~40 ~434 ~282 ~40 ~434 minecraft:light_gray_concrete replace
fill ~277 ~40 ~436 ~277 ~40 ~437 minecraft:light_gray_concrete replace
fill ~276 ~40 ~438 ~306 ~40 ~438 minecraft:light_gray_concrete replace
fill ~313 ~40 ~440 ~313 ~40 ~441 minecraft:light_gray_concrete replace
fill ~312 ~40 ~442 ~342 ~40 ~442 minecraft:light_gray_concrete replace
fill ~88 ~40 ~444 ~88 ~40 ~445 minecraft:light_gray_concrete replace
fill ~87 ~40 ~446 ~89 ~40 ~446 minecraft:light_gray_concrete replace
fill ~115 ~40 ~448 ~115 ~40 ~449 minecraft:light_gray_concrete replace
fill ~114 ~40 ~450 ~116 ~40 ~450 minecraft:light_gray_concrete replace
fill ~139 ~40 ~452 ~139 ~40 ~453 minecraft:light_gray_concrete replace
fill ~138 ~40 ~454 ~141 ~40 ~454 minecraft:light_gray_concrete replace
fill ~172 ~40 ~456 ~172 ~40 ~457 minecraft:light_gray_concrete replace
fill ~171 ~40 ~458 ~189 ~40 ~458 minecraft:light_gray_concrete replace
fill ~193 ~40 ~460 ~193 ~40 ~461 minecraft:light_gray_concrete replace
fill ~192 ~40 ~462 ~210 ~40 ~462 minecraft:light_gray_concrete replace
fill ~217 ~40 ~464 ~217 ~40 ~465 minecraft:light_gray_concrete replace
fill ~216 ~40 ~466 ~234 ~40 ~466 minecraft:light_gray_concrete replace
fill ~247 ~40 ~468 ~247 ~40 ~469 minecraft:light_gray_concrete replace
fill ~246 ~40 ~470 ~276 ~40 ~470 minecraft:light_gray_concrete replace
fill ~274 ~40 ~472 ~274 ~40 ~473 minecraft:light_gray_concrete replace
fill ~273 ~40 ~474 ~303 ~40 ~474 minecraft:light_gray_concrete replace
fill ~337 ~40 ~476 ~337 ~40 ~477 minecraft:light_gray_concrete replace
fill ~336 ~40 ~478 ~366 ~40 ~478 minecraft:light_gray_concrete replace
fill ~361 ~40 ~480 ~361 ~40 ~481 minecraft:light_gray_concrete replace
fill ~360 ~40 ~482 ~390 ~40 ~482 minecraft:light_gray_concrete replace
fill ~85 ~40 ~484 ~85 ~40 ~485 minecraft:light_gray_concrete replace
fill ~84 ~40 ~486 ~86 ~40 ~486 minecraft:light_gray_concrete replace
fill ~112 ~40 ~488 ~112 ~40 ~489 minecraft:light_gray_concrete replace
fill ~111 ~40 ~490 ~113 ~40 ~490 minecraft:light_gray_concrete replace
fill ~136 ~40 ~492 ~136 ~40 ~493 minecraft:light_gray_concrete replace
fill ~135 ~40 ~494 ~138 ~40 ~494 minecraft:light_gray_concrete replace
fill ~163 ~40 ~496 ~163 ~40 ~497 minecraft:light_gray_concrete replace
fill ~162 ~40 ~498 ~171 ~40 ~498 minecraft:light_gray_concrete replace
fill ~190 ~40 ~500 ~190 ~40 ~501 minecraft:light_gray_concrete replace
fill ~189 ~40 ~502 ~207 ~40 ~502 minecraft:light_gray_concrete replace
fill ~214 ~40 ~504 ~214 ~40 ~505 minecraft:light_gray_concrete replace
fill ~213 ~40 ~506 ~231 ~40 ~506 minecraft:light_gray_concrete replace
fill ~244 ~40 ~508 ~244 ~40 ~509 minecraft:light_gray_concrete replace
fill ~243 ~40 ~510 ~273 ~40 ~510 minecraft:light_gray_concrete replace
fill ~271 ~40 ~512 ~271 ~40 ~513 minecraft:light_gray_concrete replace
fill ~270 ~40 ~514 ~300 ~40 ~514 minecraft:light_gray_concrete replace
fill ~331 ~40 ~516 ~331 ~40 ~517 minecraft:light_gray_concrete replace
fill ~330 ~40 ~518 ~360 ~40 ~518 minecraft:light_gray_concrete replace
fill ~358 ~40 ~520 ~358 ~40 ~521 minecraft:light_gray_concrete replace
fill ~357 ~40 ~522 ~387 ~40 ~522 minecraft:light_gray_concrete replace
fill ~82 ~40 ~524 ~82 ~40 ~525 minecraft:light_gray_concrete replace
fill ~81 ~40 ~526 ~83 ~40 ~526 minecraft:light_gray_concrete replace
fill ~109 ~40 ~528 ~109 ~40 ~529 minecraft:light_gray_concrete replace
fill ~108 ~40 ~530 ~110 ~40 ~530 minecraft:light_gray_concrete replace
fill ~133 ~40 ~532 ~133 ~40 ~533 minecraft:light_gray_concrete replace
fill ~132 ~40 ~534 ~135 ~40 ~534 minecraft:light_gray_concrete replace
fill ~157 ~40 ~536 ~157 ~40 ~537 minecraft:light_gray_concrete replace
fill ~156 ~40 ~538 ~165 ~40 ~538 minecraft:light_gray_concrete replace
fill ~187 ~40 ~540 ~187 ~40 ~541 minecraft:light_gray_concrete replace
fill ~186 ~40 ~542 ~204 ~40 ~542 minecraft:light_gray_concrete replace
fill ~211 ~40 ~544 ~211 ~40 ~545 minecraft:light_gray_concrete replace
fill ~210 ~40 ~546 ~228 ~40 ~546 minecraft:light_gray_concrete replace
fill ~241 ~40 ~548 ~241 ~40 ~549 minecraft:light_gray_concrete replace
fill ~240 ~40 ~550 ~270 ~40 ~550 minecraft:light_gray_concrete replace
fill ~262 ~40 ~552 ~262 ~40 ~553 minecraft:light_gray_concrete replace
fill ~261 ~40 ~554 ~291 ~40 ~554 minecraft:light_gray_concrete replace
fill ~328 ~40 ~556 ~328 ~40 ~557 minecraft:light_gray_concrete replace
fill ~327 ~40 ~558 ~357 ~40 ~558 minecraft:light_gray_concrete replace
fill ~352 ~40 ~560 ~352 ~40 ~561 minecraft:light_gray_concrete replace
fill ~351 ~40 ~562 ~381 ~40 ~562 minecraft:light_gray_concrete replace
fill ~79 ~40 ~564 ~79 ~40 ~565 minecraft:light_gray_concrete replace
fill ~78 ~40 ~566 ~80 ~40 ~566 minecraft:light_gray_concrete replace
fill ~106 ~40 ~568 ~106 ~40 ~569 minecraft:light_gray_concrete replace
fill ~105 ~40 ~570 ~107 ~40 ~570 minecraft:light_gray_concrete replace
fill ~130 ~40 ~572 ~130 ~40 ~573 minecraft:light_gray_concrete replace
fill ~129 ~40 ~574 ~132 ~40 ~574 minecraft:light_gray_concrete replace
fill ~154 ~40 ~576 ~154 ~40 ~577 minecraft:light_gray_concrete replace
fill ~153 ~40 ~578 ~162 ~40 ~578 minecraft:light_gray_concrete replace
fill ~181 ~40 ~580 ~181 ~40 ~581 minecraft:light_gray_concrete replace
fill ~180 ~40 ~582 ~198 ~40 ~582 minecraft:light_gray_concrete replace
fill ~202 ~40 ~584 ~202 ~40 ~585 minecraft:light_gray_concrete replace
fill ~201 ~40 ~586 ~219 ~40 ~586 minecraft:light_gray_concrete replace
fill ~238 ~40 ~588 ~238 ~40 ~589 minecraft:light_gray_concrete replace
fill ~237 ~40 ~590 ~267 ~40 ~590 minecraft:light_gray_concrete replace
fill ~259 ~40 ~592 ~259 ~40 ~593 minecraft:light_gray_concrete replace
fill ~258 ~40 ~594 ~288 ~40 ~594 minecraft:light_gray_concrete replace
fill ~325 ~40 ~596 ~325 ~40 ~597 minecraft:light_gray_concrete replace
fill ~324 ~40 ~598 ~354 ~40 ~598 minecraft:light_gray_concrete replace
fill ~349 ~40 ~600 ~349 ~40 ~601 minecraft:light_gray_concrete replace
fill ~348 ~40 ~602 ~378 ~40 ~602 minecraft:light_gray_concrete replace
fill ~103 ~40 ~604 ~103 ~40 ~605 minecraft:light_gray_concrete replace
fill ~102 ~40 ~606 ~104 ~40 ~606 minecraft:light_gray_concrete replace
fill ~127 ~40 ~608 ~127 ~40 ~609 minecraft:light_gray_concrete replace
fill ~126 ~40 ~610 ~129 ~40 ~610 minecraft:light_gray_concrete replace
fill ~151 ~40 ~612 ~151 ~40 ~613 minecraft:light_gray_concrete replace
fill ~150 ~40 ~614 ~159 ~40 ~614 minecraft:light_gray_concrete replace
fill ~178 ~40 ~616 ~178 ~40 ~617 minecraft:light_gray_concrete replace
fill ~177 ~40 ~618 ~195 ~40 ~618 minecraft:light_gray_concrete replace
fill ~199 ~40 ~620 ~199 ~40 ~621 minecraft:light_gray_concrete replace
fill ~198 ~40 ~622 ~216 ~40 ~622 minecraft:light_gray_concrete replace
fill ~223 ~40 ~624 ~223 ~40 ~625 minecraft:light_gray_concrete replace
fill ~222 ~40 ~626 ~240 ~40 ~626 minecraft:light_gray_concrete replace
fill ~265 ~40 ~628 ~265 ~40 ~629 minecraft:light_gray_concrete replace
fill ~264 ~40 ~630 ~294 ~40 ~630 minecraft:light_gray_concrete replace
fill ~280 ~40 ~632 ~280 ~40 ~633 minecraft:light_gray_concrete replace
fill ~279 ~40 ~634 ~309 ~40 ~634 minecraft:light_gray_concrete replace
fill ~340 ~40 ~636 ~340 ~40 ~637 minecraft:light_gray_concrete replace
fill ~339 ~40 ~638 ~369 ~40 ~638 minecraft:light_gray_concrete replace
fill ~160 ~40 ~640 ~160 ~40 ~641 minecraft:light_gray_concrete replace
fill ~159 ~40 ~642 ~168 ~40 ~642 minecraft:light_gray_concrete replace
fill ~367 ~40 ~644 ~367 ~40 ~645 minecraft:light_gray_concrete replace
fill ~366 ~40 ~646 ~396 ~40 ~646 minecraft:light_gray_concrete replace
fill ~100 ~40 ~648 ~100 ~40 ~649 minecraft:light_gray_concrete replace
fill ~99 ~40 ~650 ~101 ~40 ~650 minecraft:light_gray_concrete replace
fill ~343 ~40 ~652 ~343 ~40 ~653 minecraft:light_gray_concrete replace
fill ~342 ~40 ~654 ~372 ~40 ~654 minecraft:light_gray_concrete replace
fill ~364 ~40 ~656 ~364 ~40 ~657 minecraft:light_gray_concrete replace
fill ~363 ~40 ~658 ~393 ~40 ~658 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~0 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~2 minecraft:light_gray_concrete replace
setblock ~231 ~41 ~2 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~4 minecraft:light_gray_concrete replace
setblock ~145 ~41 ~8 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~12 minecraft:light_gray_concrete replace
setblock ~234 ~41 ~14 minecraft:light_gray_concrete replace
setblock ~236 ~41 ~14 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~16 minecraft:light_gray_concrete replace
setblock ~168 ~41 ~18 minecraft:light_gray_concrete replace
setblock ~170 ~41 ~18 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~24 minecraft:light_gray_concrete replace
setblock ~240 ~41 ~26 minecraft:light_gray_concrete replace
setblock ~242 ~41 ~26 minecraft:light_gray_concrete replace
setblock ~301 ~41 ~32 minecraft:light_gray_concrete replace
setblock ~315 ~41 ~34 minecraft:light_gray_concrete replace
setblock ~317 ~41 ~34 minecraft:light_gray_concrete replace
setblock ~286 ~41 ~36 minecraft:light_gray_concrete replace
setblock ~303 ~41 ~38 minecraft:light_gray_concrete replace
setblock ~305 ~41 ~38 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~40 minecraft:light_gray_concrete replace
setblock ~233 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~235 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~250 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~252 ~41 ~42 minecraft:light_gray_concrete replace
setblock ~304 ~41 ~44 minecraft:light_gray_concrete replace
setblock ~318 ~41 ~46 minecraft:light_gray_concrete replace
setblock ~320 ~41 ~46 minecraft:light_gray_concrete replace
setblock ~289 ~41 ~48 minecraft:light_gray_concrete replace
setblock ~293 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~295 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~310 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~312 ~41 ~50 minecraft:light_gray_concrete replace
setblock ~295 ~41 ~56 minecraft:light_gray_concrete replace
setblock ~309 ~41 ~58 minecraft:light_gray_concrete replace
setblock ~311 ~41 ~58 minecraft:light_gray_concrete replace
setblock ~319 ~41 ~72 minecraft:light_gray_concrete replace
setblock ~335 ~41 ~74 minecraft:light_gray_concrete replace
setblock ~337 ~41 ~74 minecraft:light_gray_concrete replace
setblock ~94 ~41 ~244 minecraft:light_gray_concrete replace
setblock ~124 ~41 ~248 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~252 minecraft:light_gray_concrete replace
setblock ~227 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~244 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~246 ~41 ~254 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~256 minecraft:light_gray_concrete replace
setblock ~171 ~41 ~258 minecraft:light_gray_concrete replace
setblock ~173 ~41 ~258 minecraft:light_gray_concrete replace
setblock ~145 ~41 ~260 minecraft:light_gray_concrete replace
setblock ~124 ~41 ~264 minecraft:light_gray_concrete replace
setblock ~97 ~41 ~272 minecraft:light_gray_concrete replace
setblock ~121 ~41 ~276 minecraft:light_gray_concrete replace
setblock ~145 ~41 ~280 minecraft:light_gray_concrete replace
setblock ~148 ~41 ~292 minecraft:light_gray_concrete replace
setblock ~166 ~41 ~296 minecraft:light_gray_concrete replace
setblock ~171 ~41 ~298 minecraft:light_gray_concrete replace
setblock ~173 ~41 ~298 minecraft:light_gray_concrete replace
setblock ~169 ~41 ~308 minecraft:light_gray_concrete replace
setblock ~171 ~41 ~310 minecraft:light_gray_concrete replace
setblock ~173 ~41 ~310 minecraft:light_gray_concrete replace
setblock ~226 ~41 ~316 minecraft:light_gray_concrete replace
setblock ~229 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~231 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~246 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~248 ~41 ~318 minecraft:light_gray_concrete replace
setblock ~184 ~41 ~320 minecraft:light_gray_concrete replace
setblock ~186 ~41 ~322 minecraft:light_gray_concrete replace
setblock ~188 ~41 ~322 minecraft:light_gray_concrete replace
setblock ~205 ~41 ~324 minecraft:light_gray_concrete replace
setblock ~213 ~41 ~326 minecraft:light_gray_concrete replace
setblock ~215 ~41 ~326 minecraft:light_gray_concrete replace
setblock ~250 ~41 ~328 minecraft:light_gray_concrete replace
setblock ~253 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~255 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~270 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~272 ~41 ~330 minecraft:light_gray_concrete replace
setblock ~208 ~41 ~336 minecraft:light_gray_concrete replace
setblock ~210 ~41 ~338 minecraft:light_gray_concrete replace
setblock ~212 ~41 ~338 minecraft:light_gray_concrete replace
setblock ~232 ~41 ~340 minecraft:light_gray_concrete replace
setblock ~235 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~237 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~252 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~254 ~41 ~342 minecraft:light_gray_concrete replace
setblock ~268 ~41 ~344 minecraft:light_gray_concrete replace
setblock ~271 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~273 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~288 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~290 ~41 ~346 minecraft:light_gray_concrete replace
setblock ~235 ~41 ~352 minecraft:light_gray_concrete replace
setblock ~249 ~41 ~354 minecraft:light_gray_concrete replace
setblock ~251 ~41 ~354 minecraft:light_gray_concrete replace
setblock ~292 ~41 ~356 minecraft:light_gray_concrete replace
setblock ~295 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~297 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~312 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~314 ~41 ~358 minecraft:light_gray_concrete replace
setblock ~307 ~41 ~360 minecraft:light_gray_concrete replace
setblock ~321 ~41 ~362 minecraft:light_gray_concrete replace
setblock ~323 ~41 ~362 minecraft:light_gray_concrete replace
setblock ~310 ~41 ~364 minecraft:light_gray_concrete replace
setblock ~326 ~41 ~366 minecraft:light_gray_concrete replace
setblock ~328 ~41 ~366 minecraft:light_gray_concrete replace
setblock ~283 ~41 ~368 minecraft:light_gray_concrete replace
setblock ~286 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~288 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~303 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~305 ~41 ~370 minecraft:light_gray_concrete replace
setblock ~298 ~41 ~372 minecraft:light_gray_concrete replace
setblock ~301 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~303 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~318 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~320 ~41 ~374 minecraft:light_gray_concrete replace
setblock ~256 ~41 ~380 minecraft:light_gray_concrete replace
setblock ~270 ~41 ~382 minecraft:light_gray_concrete replace
setblock ~272 ~41 ~382 minecraft:light_gray_concrete replace
setblock ~334 ~41 ~384 minecraft:light_gray_concrete replace
setblock ~337 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~339 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~354 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~356 ~41 ~386 minecraft:light_gray_concrete replace
setblock ~355 ~41 ~388 minecraft:light_gray_concrete replace
setblock ~369 ~41 ~390 minecraft:light_gray_concrete replace
setblock ~371 ~41 ~390 minecraft:light_gray_concrete replace
setblock ~322 ~41 ~392 minecraft:light_gray_concrete replace
setblock ~336 ~41 ~394 minecraft:light_gray_concrete replace
setblock ~338 ~41 ~394 minecraft:light_gray_concrete replace
setblock ~346 ~41 ~396 minecraft:light_gray_concrete replace
setblock ~360 ~41 ~398 minecraft:light_gray_concrete replace
setblock ~362 ~41 ~398 minecraft:light_gray_concrete replace
setblock ~316 ~41 ~400 minecraft:light_gray_concrete replace
setblock ~319 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~321 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~336 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~338 ~41 ~402 minecraft:light_gray_concrete replace
setblock ~91 ~41 ~408 minecraft:light_gray_concrete replace
setblock ~118 ~41 ~412 minecraft:light_gray_concrete replace
setblock ~142 ~41 ~416 minecraft:light_gray_concrete replace
setblock ~175 ~41 ~420 minecraft:light_gray_concrete replace
setblock ~183 ~41 ~422 minecraft:light_gray_concrete replace
setblock ~185 ~41 ~422 minecraft:light_gray_concrete replace
setblock ~196 ~41 ~424 minecraft:light_gray_concrete replace
setblock ~204 ~41 ~426 minecraft:light_gray_concrete replace
setblock ~206 ~41 ~426 minecraft:light_gray_concrete replace
setblock ~220 ~41 ~428 minecraft:light_gray_concrete replace
setblock ~228 ~41 ~430 minecraft:light_gray_concrete replace
setblock ~230 ~41 ~430 minecraft:light_gray_concrete replace
setblock ~253 ~41 ~432 minecraft:light_gray_concrete replace
setblock ~256 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~258 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~273 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~275 ~41 ~434 minecraft:light_gray_concrete replace
setblock ~277 ~41 ~436 minecraft:light_gray_concrete replace
setblock ~280 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~282 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~297 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~299 ~41 ~438 minecraft:light_gray_concrete replace
setblock ~313 ~41 ~440 minecraft:light_gray_concrete replace
setblock ~316 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~318 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~333 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~335 ~41 ~442 minecraft:light_gray_concrete replace
setblock ~88 ~41 ~444 minecraft:light_gray_concrete replace
setblock ~115 ~41 ~448 minecraft:light_gray_concrete replace
setblock ~139 ~41 ~452 minecraft:light_gray_concrete replace
setblock ~172 ~41 ~456 minecraft:light_gray_concrete replace
setblock ~180 ~41 ~458 minecraft:light_gray_concrete replace
setblock ~182 ~41 ~458 minecraft:light_gray_concrete replace
setblock ~193 ~41 ~460 minecraft:light_gray_concrete replace
setblock ~201 ~41 ~462 minecraft:light_gray_concrete replace
setblock ~203 ~41 ~462 minecraft:light_gray_concrete replace
setblock ~217 ~41 ~464 minecraft:light_gray_concrete replace
setblock ~225 ~41 ~466 minecraft:light_gray_concrete replace
setblock ~227 ~41 ~466 minecraft:light_gray_concrete replace
setblock ~247 ~41 ~468 minecraft:light_gray_concrete replace
setblock ~250 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~252 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~267 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~269 ~41 ~470 minecraft:light_gray_concrete replace
setblock ~274 ~41 ~472 minecraft:light_gray_concrete replace
setblock ~277 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~279 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~294 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~296 ~41 ~474 minecraft:light_gray_concrete replace
setblock ~337 ~41 ~476 minecraft:light_gray_concrete replace
setblock ~340 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~342 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~357 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~359 ~41 ~478 minecraft:light_gray_concrete replace
setblock ~361 ~41 ~480 minecraft:light_gray_concrete replace
setblock ~364 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~366 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~381 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~383 ~41 ~482 minecraft:light_gray_concrete replace
setblock ~85 ~41 ~484 minecraft:light_gray_concrete replace
setblock ~112 ~41 ~488 minecraft:light_gray_concrete replace
setblock ~136 ~41 ~492 minecraft:light_gray_concrete replace
setblock ~163 ~41 ~496 minecraft:light_gray_concrete replace
setblock ~190 ~41 ~500 minecraft:light_gray_concrete replace
setblock ~198 ~41 ~502 minecraft:light_gray_concrete replace
setblock ~200 ~41 ~502 minecraft:light_gray_concrete replace
setblock ~214 ~41 ~504 minecraft:light_gray_concrete replace
setblock ~222 ~41 ~506 minecraft:light_gray_concrete replace
setblock ~224 ~41 ~506 minecraft:light_gray_concrete replace
setblock ~244 ~41 ~508 minecraft:light_gray_concrete replace
setblock ~247 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~249 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~264 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~266 ~41 ~510 minecraft:light_gray_concrete replace
setblock ~271 ~41 ~512 minecraft:light_gray_concrete replace
setblock ~274 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~276 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~291 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~293 ~41 ~514 minecraft:light_gray_concrete replace
setblock ~331 ~41 ~516 minecraft:light_gray_concrete replace
setblock ~334 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~336 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~351 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~353 ~41 ~518 minecraft:light_gray_concrete replace
setblock ~358 ~41 ~520 minecraft:light_gray_concrete replace
setblock ~361 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~363 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~378 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~380 ~41 ~522 minecraft:light_gray_concrete replace
setblock ~82 ~41 ~524 minecraft:light_gray_concrete replace
setblock ~109 ~41 ~528 minecraft:light_gray_concrete replace
setblock ~133 ~41 ~532 minecraft:light_gray_concrete replace
setblock ~157 ~41 ~536 minecraft:light_gray_concrete replace
setblock ~187 ~41 ~540 minecraft:light_gray_concrete replace
setblock ~195 ~41 ~542 minecraft:light_gray_concrete replace
setblock ~197 ~41 ~542 minecraft:light_gray_concrete replace
setblock ~211 ~41 ~544 minecraft:light_gray_concrete replace
setblock ~219 ~41 ~546 minecraft:light_gray_concrete replace
setblock ~221 ~41 ~546 minecraft:light_gray_concrete replace
setblock ~241 ~41 ~548 minecraft:light_gray_concrete replace
setblock ~244 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~246 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~261 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~263 ~41 ~550 minecraft:light_gray_concrete replace
setblock ~262 ~41 ~552 minecraft:light_gray_concrete replace
setblock ~265 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~267 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~282 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~284 ~41 ~554 minecraft:light_gray_concrete replace
setblock ~328 ~41 ~556 minecraft:light_gray_concrete replace
setblock ~331 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~333 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~348 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~350 ~41 ~558 minecraft:light_gray_concrete replace
setblock ~352 ~41 ~560 minecraft:light_gray_concrete replace
setblock ~355 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~357 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~372 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~374 ~41 ~562 minecraft:light_gray_concrete replace
setblock ~79 ~41 ~564 minecraft:light_gray_concrete replace
setblock ~106 ~41 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~41 ~572 minecraft:light_gray_concrete replace
setblock ~154 ~41 ~576 minecraft:light_gray_concrete replace
setblock ~181 ~41 ~580 minecraft:light_gray_concrete replace
setblock ~189 ~41 ~582 minecraft:light_gray_concrete replace
setblock ~191 ~41 ~582 minecraft:light_gray_concrete replace
setblock ~202 ~41 ~584 minecraft:light_gray_concrete replace
setblock ~210 ~41 ~586 minecraft:light_gray_concrete replace
setblock ~212 ~41 ~586 minecraft:light_gray_concrete replace
setblock ~238 ~41 ~588 minecraft:light_gray_concrete replace
setblock ~241 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~243 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~258 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~260 ~41 ~590 minecraft:light_gray_concrete replace
setblock ~259 ~41 ~592 minecraft:light_gray_concrete replace
setblock ~262 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~264 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~279 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~281 ~41 ~594 minecraft:light_gray_concrete replace
setblock ~325 ~41 ~596 minecraft:light_gray_concrete replace
setblock ~328 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~330 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~345 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~347 ~41 ~598 minecraft:light_gray_concrete replace
setblock ~349 ~41 ~600 minecraft:light_gray_concrete replace
setblock ~352 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~354 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~369 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~371 ~41 ~602 minecraft:light_gray_concrete replace
setblock ~103 ~41 ~604 minecraft:light_gray_concrete replace
setblock ~127 ~41 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~41 ~612 minecraft:light_gray_concrete replace
setblock ~178 ~41 ~616 minecraft:light_gray_concrete replace
setblock ~186 ~41 ~618 minecraft:light_gray_concrete replace
setblock ~188 ~41 ~618 minecraft:light_gray_concrete replace
setblock ~199 ~41 ~620 minecraft:light_gray_concrete replace
setblock ~207 ~41 ~622 minecraft:light_gray_concrete replace
setblock ~209 ~41 ~622 minecraft:light_gray_concrete replace
setblock ~223 ~41 ~624 minecraft:light_gray_concrete replace
setblock ~231 ~41 ~626 minecraft:light_gray_concrete replace
setblock ~233 ~41 ~626 minecraft:light_gray_concrete replace
setblock ~265 ~41 ~628 minecraft:light_gray_concrete replace
setblock ~268 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~270 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~285 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~287 ~41 ~630 minecraft:light_gray_concrete replace
setblock ~280 ~41 ~632 minecraft:light_gray_concrete replace
setblock ~283 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~285 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~300 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~302 ~41 ~634 minecraft:light_gray_concrete replace
setblock ~340 ~41 ~636 minecraft:light_gray_concrete replace
setblock ~343 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~345 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~360 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~362 ~41 ~638 minecraft:light_gray_concrete replace
setblock ~160 ~41 ~640 minecraft:light_gray_concrete replace
setblock ~367 ~41 ~644 minecraft:light_gray_concrete replace
setblock ~370 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~372 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~387 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~389 ~41 ~646 minecraft:light_gray_concrete replace
setblock ~100 ~41 ~648 minecraft:light_gray_concrete replace
setblock ~343 ~41 ~652 minecraft:light_gray_concrete replace
setblock ~346 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~348 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~363 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~365 ~41 ~654 minecraft:light_gray_concrete replace
setblock ~364 ~41 ~656 minecraft:light_gray_concrete replace
setblock ~367 ~41 ~658 minecraft:light_gray_concrete replace
setblock ~369 ~41 ~658 minecraft:light_gray_concrete replace
setblock ~384 ~41 ~658 minecraft:light_gray_concrete replace
setblock ~386 ~41 ~658 minecraft:light_gray_concrete replace
fill ~225 ~42 ~0 ~225 ~42 ~320 minecraft:light_gray_concrete replace
fill ~165 ~42 ~4 ~165 ~42 ~300 minecraft:light_gray_concrete replace
fill ~144 ~42 ~8 ~144 ~42 ~284 minecraft:light_gray_concrete replace
fill ~300 ~42 ~32 ~300 ~42 ~36 minecraft:light_gray_concrete replace
fill ~285 ~42 ~36 ~285 ~42 ~40 minecraft:light_gray_concrete replace
fill ~228 ~42 ~40 ~228 ~42 ~44 minecraft:light_gray_concrete replace
fill ~303 ~42 ~44 ~303 ~42 ~48 minecraft:light_gray_concrete replace
fill ~288 ~42 ~48 ~288 ~42 ~52 minecraft:light_gray_concrete replace
fill ~294 ~42 ~56 ~294 ~42 ~60 minecraft:light_gray_concrete replace
fill ~318 ~42 ~72 ~318 ~42 ~76 minecraft:light_gray_concrete replace
fill ~93 ~42 ~244 ~93 ~42 ~248 minecraft:light_gray_concrete replace
fill ~123 ~42 ~248 ~123 ~42 ~268 minecraft:light_gray_concrete replace
fill ~96 ~42 ~272 ~96 ~42 ~276 minecraft:light_gray_concrete replace
fill ~120 ~42 ~276 ~120 ~42 ~280 minecraft:light_gray_concrete replace
fill ~147 ~42 ~292 ~147 ~42 ~296 minecraft:light_gray_concrete replace
fill ~168 ~42 ~308 ~168 ~42 ~312 minecraft:light_gray_concrete replace
fill ~183 ~42 ~320 ~183 ~42 ~324 minecraft:light_gray_concrete replace
fill ~204 ~42 ~324 ~204 ~42 ~328 minecraft:light_gray_concrete replace
fill ~249 ~42 ~328 ~249 ~42 ~332 minecraft:light_gray_concrete replace
fill ~207 ~42 ~336 ~207 ~42 ~340 minecraft:light_gray_concrete replace
fill ~231 ~42 ~340 ~231 ~42 ~344 minecraft:light_gray_concrete replace
fill ~267 ~42 ~344 ~267 ~42 ~348 minecraft:light_gray_concrete replace
fill ~234 ~42 ~352 ~234 ~42 ~356 minecraft:light_gray_concrete replace
fill ~291 ~42 ~356 ~291 ~42 ~360 minecraft:light_gray_concrete replace
fill ~306 ~42 ~360 ~306 ~42 ~364 minecraft:light_gray_concrete replace
fill ~309 ~42 ~364 ~309 ~42 ~368 minecraft:light_gray_concrete replace
fill ~282 ~42 ~368 ~282 ~42 ~372 minecraft:light_gray_concrete replace
fill ~297 ~42 ~372 ~297 ~42 ~376 minecraft:light_gray_concrete replace
fill ~255 ~42 ~380 ~255 ~42 ~384 minecraft:light_gray_concrete replace
fill ~333 ~42 ~384 ~333 ~42 ~388 minecraft:light_gray_concrete replace
fill ~354 ~42 ~388 ~354 ~42 ~392 minecraft:light_gray_concrete replace
fill ~321 ~42 ~392 ~321 ~42 ~396 minecraft:light_gray_concrete replace
fill ~345 ~42 ~396 ~345 ~42 ~400 minecraft:light_gray_concrete replace
fill ~315 ~42 ~400 ~315 ~42 ~404 minecraft:light_gray_concrete replace
fill ~90 ~42 ~408 ~90 ~42 ~412 minecraft:light_gray_concrete replace
fill ~117 ~42 ~412 ~117 ~42 ~416 minecraft:light_gray_concrete replace
fill ~141 ~42 ~416 ~141 ~42 ~420 minecraft:light_gray_concrete replace
fill ~174 ~42 ~420 ~174 ~42 ~424 minecraft:light_gray_concrete replace
fill ~195 ~42 ~424 ~195 ~42 ~428 minecraft:light_gray_concrete replace
fill ~219 ~42 ~428 ~219 ~42 ~432 minecraft:light_gray_concrete replace
fill ~252 ~42 ~432 ~252 ~42 ~436 minecraft:light_gray_concrete replace
fill ~276 ~42 ~436 ~276 ~42 ~440 minecraft:light_gray_concrete replace
fill ~312 ~42 ~440 ~312 ~42 ~444 minecraft:light_gray_concrete replace
fill ~87 ~42 ~444 ~87 ~42 ~448 minecraft:light_gray_concrete replace
fill ~114 ~42 ~448 ~114 ~42 ~452 minecraft:light_gray_concrete replace
fill ~138 ~42 ~452 ~138 ~42 ~456 minecraft:light_gray_concrete replace
fill ~171 ~42 ~456 ~171 ~42 ~460 minecraft:light_gray_concrete replace
fill ~192 ~42 ~460 ~192 ~42 ~464 minecraft:light_gray_concrete replace
fill ~216 ~42 ~464 ~216 ~42 ~468 minecraft:light_gray_concrete replace
fill ~246 ~42 ~468 ~246 ~42 ~472 minecraft:light_gray_concrete replace
fill ~273 ~42 ~472 ~273 ~42 ~476 minecraft:light_gray_concrete replace
fill ~336 ~42 ~476 ~336 ~42 ~480 minecraft:light_gray_concrete replace
fill ~360 ~42 ~480 ~360 ~42 ~484 minecraft:light_gray_concrete replace
fill ~84 ~42 ~484 ~84 ~42 ~488 minecraft:light_gray_concrete replace
fill ~111 ~42 ~488 ~111 ~42 ~492 minecraft:light_gray_concrete replace
fill ~135 ~42 ~492 ~135 ~42 ~496 minecraft:light_gray_concrete replace
fill ~162 ~42 ~496 ~162 ~42 ~500 minecraft:light_gray_concrete replace
fill ~189 ~42 ~500 ~189 ~42 ~504 minecraft:light_gray_concrete replace
fill ~213 ~42 ~504 ~213 ~42 ~508 minecraft:light_gray_concrete replace
fill ~243 ~42 ~508 ~243 ~42 ~512 minecraft:light_gray_concrete replace
fill ~270 ~42 ~512 ~270 ~42 ~516 minecraft:light_gray_concrete replace
fill ~330 ~42 ~516 ~330 ~42 ~520 minecraft:light_gray_concrete replace
fill ~357 ~42 ~520 ~357 ~42 ~524 minecraft:light_gray_concrete replace
fill ~81 ~42 ~524 ~81 ~42 ~528 minecraft:light_gray_concrete replace
fill ~108 ~42 ~528 ~108 ~42 ~532 minecraft:light_gray_concrete replace
fill ~132 ~42 ~532 ~132 ~42 ~536 minecraft:light_gray_concrete replace
fill ~156 ~42 ~536 ~156 ~42 ~540 minecraft:light_gray_concrete replace
fill ~186 ~42 ~540 ~186 ~42 ~544 minecraft:light_gray_concrete replace
fill ~210 ~42 ~544 ~210 ~42 ~548 minecraft:light_gray_concrete replace
fill ~240 ~42 ~548 ~240 ~42 ~552 minecraft:light_gray_concrete replace
fill ~261 ~42 ~552 ~261 ~42 ~556 minecraft:light_gray_concrete replace
fill ~327 ~42 ~556 ~327 ~42 ~560 minecraft:light_gray_concrete replace
fill ~351 ~42 ~560 ~351 ~42 ~564 minecraft:light_gray_concrete replace
fill ~78 ~42 ~564 ~78 ~42 ~568 minecraft:light_gray_concrete replace
fill ~105 ~42 ~568 ~105 ~42 ~572 minecraft:light_gray_concrete replace
fill ~129 ~42 ~572 ~129 ~42 ~576 minecraft:light_gray_concrete replace
fill ~153 ~42 ~576 ~153 ~42 ~580 minecraft:light_gray_concrete replace
fill ~180 ~42 ~580 ~180 ~42 ~584 minecraft:light_gray_concrete replace
fill ~201 ~42 ~584 ~201 ~42 ~588 minecraft:light_gray_concrete replace
fill ~237 ~42 ~588 ~237 ~42 ~592 minecraft:light_gray_concrete replace
fill ~258 ~42 ~592 ~258 ~42 ~596 minecraft:light_gray_concrete replace
fill ~324 ~42 ~596 ~324 ~42 ~600 minecraft:light_gray_concrete replace
fill ~348 ~42 ~600 ~348 ~42 ~604 minecraft:light_gray_concrete replace
fill ~102 ~42 ~604 ~102 ~42 ~608 minecraft:light_gray_concrete replace
fill ~126 ~42 ~608 ~126 ~42 ~612 minecraft:light_gray_concrete replace
fill ~150 ~42 ~612 ~150 ~42 ~616 minecraft:light_gray_concrete replace
fill ~177 ~42 ~616 ~177 ~42 ~620 minecraft:light_gray_concrete replace
fill ~198 ~42 ~620 ~198 ~42 ~624 minecraft:light_gray_concrete replace
fill ~222 ~42 ~624 ~222 ~42 ~628 minecraft:light_gray_concrete replace
fill ~264 ~42 ~628 ~264 ~42 ~632 minecraft:light_gray_concrete replace
fill ~279 ~42 ~632 ~279 ~42 ~636 minecraft:light_gray_concrete replace
fill ~339 ~42 ~636 ~339 ~42 ~640 minecraft:light_gray_concrete replace
fill ~159 ~42 ~640 ~159 ~42 ~644 minecraft:light_gray_concrete replace
fill ~366 ~42 ~644 ~366 ~42 ~648 minecraft:light_gray_concrete replace
fill ~99 ~42 ~648 ~99 ~42 ~652 minecraft:light_gray_concrete replace
fill ~342 ~42 ~652 ~342 ~42 ~656 minecraft:light_gray_concrete replace
fill ~363 ~42 ~656 ~363 ~42 ~660 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~0 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~4 minecraft:light_gray_concrete replace
setblock ~145 ~43 ~8 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~12 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~16 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~21 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~23 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~24 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~27 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~29 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~31 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~33 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~37 minecraft:light_gray_concrete replace
setblock ~300 ~43 ~37 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~39 minecraft:light_gray_concrete replace
setblock ~285 ~43 ~41 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~43 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~45 minecraft:light_gray_concrete replace
setblock ~228 ~43 ~45 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~47 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~49 minecraft:light_gray_concrete replace
setblock ~303 ~43 ~49 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~53 minecraft:light_gray_concrete replace
setblock ~288 ~43 ~53 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~55 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~59 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~61 minecraft:light_gray_concrete replace
setblock ~294 ~43 ~61 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~63 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~65 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~69 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~71 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~75 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~77 minecraft:light_gray_concrete replace
setblock ~318 ~43 ~77 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~79 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~81 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~85 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~87 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~91 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~93 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~95 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~97 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~101 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~103 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~107 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~109 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~111 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~113 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~117 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~119 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~123 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~125 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~127 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~129 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~133 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~135 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~139 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~141 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~143 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~145 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~149 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~151 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~155 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~157 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~159 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~161 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~165 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~167 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~171 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~173 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~175 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~177 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~181 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~183 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~187 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~189 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~191 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~193 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~197 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~199 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~203 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~205 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~207 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~209 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~213 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~215 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~219 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~221 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~223 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~225 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~229 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~231 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~235 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~237 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~239 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~241 minecraft:light_gray_concrete replace
setblock ~94 ~43 ~244 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~245 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~247 minecraft:light_gray_concrete replace
setblock ~124 ~43 ~248 minecraft:light_gray_concrete replace
setblock ~93 ~43 ~249 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~252 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~256 minecraft:light_gray_concrete replace
setblock ~145 ~43 ~260 minecraft:light_gray_concrete replace
setblock ~123 ~43 ~261 minecraft:light_gray_concrete replace
setblock ~123 ~43 ~263 minecraft:light_gray_concrete replace
setblock ~124 ~43 ~264 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~265 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~267 minecraft:light_gray_concrete replace
setblock ~123 ~43 ~269 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~269 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~271 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~275 minecraft:light_gray_concrete replace
setblock ~121 ~43 ~276 minecraft:light_gray_concrete replace
setblock ~96 ~43 ~277 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~277 minecraft:light_gray_concrete replace
setblock ~145 ~43 ~280 minecraft:light_gray_concrete replace
setblock ~120 ~43 ~281 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~281 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~283 minecraft:light_gray_concrete replace
setblock ~144 ~43 ~285 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~285 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~287 minecraft:light_gray_concrete replace
setblock ~148 ~43 ~292 minecraft:light_gray_concrete replace
setblock ~166 ~43 ~296 minecraft:light_gray_concrete replace
setblock ~147 ~43 ~297 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~297 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~299 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~299 minecraft:light_gray_concrete replace
setblock ~165 ~43 ~301 minecraft:light_gray_concrete replace
setblock ~169 ~43 ~308 minecraft:light_gray_concrete replace
setblock ~168 ~43 ~313 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~313 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~315 minecraft:light_gray_concrete replace
setblock ~226 ~43 ~316 minecraft:light_gray_concrete replace
setblock ~184 ~43 ~320 minecraft:light_gray_concrete replace
setblock ~225 ~43 ~321 minecraft:light_gray_concrete replace
setblock ~183 ~43 ~325 minecraft:light_gray_concrete replace
setblock ~204 ~43 ~329 minecraft:light_gray_concrete replace
setblock ~249 ~43 ~333 minecraft:light_gray_concrete replace
setblock ~208 ~43 ~336 minecraft:light_gray_concrete replace
setblock ~207 ~43 ~341 minecraft:light_gray_concrete replace
setblock ~231 ~43 ~345 minecraft:light_gray_concrete replace
setblock ~267 ~43 ~349 minecraft:light_gray_concrete replace
setblock ~235 ~43 ~352 minecraft:light_gray_concrete replace
setblock ~234 ~43 ~357 minecraft:light_gray_concrete replace
setblock ~291 ~43 ~361 minecraft:light_gray_concrete replace
setblock ~310 ~43 ~364 minecraft:light_gray_concrete replace
setblock ~306 ~43 ~365 minecraft:light_gray_concrete replace
setblock ~309 ~43 ~369 minecraft:light_gray_concrete replace
setblock ~282 ~43 ~373 minecraft:light_gray_concrete replace
setblock ~297 ~43 ~377 minecraft:light_gray_concrete replace
setblock ~256 ~43 ~380 minecraft:light_gray_concrete replace
setblock ~255 ~43 ~385 minecraft:light_gray_concrete replace
setblock ~333 ~43 ~389 minecraft:light_gray_concrete replace
setblock ~354 ~43 ~393 minecraft:light_gray_concrete replace
setblock ~346 ~43 ~396 minecraft:light_gray_concrete replace
setblock ~321 ~43 ~397 minecraft:light_gray_concrete replace
setblock ~345 ~43 ~401 minecraft:light_gray_concrete replace
setblock ~315 ~43 ~405 minecraft:light_gray_concrete replace
setblock ~90 ~43 ~413 minecraft:light_gray_concrete replace
setblock ~117 ~43 ~417 minecraft:light_gray_concrete replace
setblock ~141 ~43 ~421 minecraft:light_gray_concrete replace
setblock ~174 ~43 ~425 minecraft:light_gray_concrete replace
setblock ~195 ~43 ~429 minecraft:light_gray_concrete replace
setblock ~219 ~43 ~433 minecraft:light_gray_concrete replace
setblock ~252 ~43 ~437 minecraft:light_gray_concrete replace
setblock ~276 ~43 ~441 minecraft:light_gray_concrete replace
setblock ~312 ~43 ~445 minecraft:light_gray_concrete replace
setblock ~87 ~43 ~449 minecraft:light_gray_concrete replace
setblock ~114 ~43 ~453 minecraft:light_gray_concrete replace
setblock ~138 ~43 ~457 minecraft:light_gray_concrete replace
setblock ~171 ~43 ~461 minecraft:light_gray_concrete replace
setblock ~192 ~43 ~465 minecraft:light_gray_concrete replace
setblock ~216 ~43 ~469 minecraft:light_gray_concrete replace
setblock ~246 ~43 ~473 minecraft:light_gray_concrete replace
setblock ~273 ~43 ~477 minecraft:light_gray_concrete replace
setblock ~336 ~43 ~481 minecraft:light_gray_concrete replace
setblock ~360 ~43 ~485 minecraft:light_gray_concrete replace
setblock ~84 ~43 ~489 minecraft:light_gray_concrete replace
setblock ~111 ~43 ~493 minecraft:light_gray_concrete replace
setblock ~135 ~43 ~497 minecraft:light_gray_concrete replace
setblock ~162 ~43 ~501 minecraft:light_gray_concrete replace
setblock ~189 ~43 ~505 minecraft:light_gray_concrete replace
setblock ~213 ~43 ~509 minecraft:light_gray_concrete replace
setblock ~243 ~43 ~513 minecraft:light_gray_concrete replace
setblock ~270 ~43 ~517 minecraft:light_gray_concrete replace
setblock ~330 ~43 ~521 minecraft:light_gray_concrete replace
setblock ~357 ~43 ~525 minecraft:light_gray_concrete replace
setblock ~81 ~43 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~43 ~533 minecraft:light_gray_concrete replace
setblock ~132 ~43 ~537 minecraft:light_gray_concrete replace
setblock ~156 ~43 ~541 minecraft:light_gray_concrete replace
setblock ~186 ~43 ~545 minecraft:light_gray_concrete replace
setblock ~210 ~43 ~549 minecraft:light_gray_concrete replace
setblock ~240 ~43 ~553 minecraft:light_gray_concrete replace
setblock ~261 ~43 ~557 minecraft:light_gray_concrete replace
setblock ~327 ~43 ~561 minecraft:light_gray_concrete replace
setblock ~351 ~43 ~565 minecraft:light_gray_concrete replace
setblock ~78 ~43 ~569 minecraft:light_gray_concrete replace
setblock ~105 ~43 ~573 minecraft:light_gray_concrete replace
setblock ~129 ~43 ~577 minecraft:light_gray_concrete replace
setblock ~153 ~43 ~581 minecraft:light_gray_concrete replace
setblock ~180 ~43 ~585 minecraft:light_gray_concrete replace
setblock ~201 ~43 ~589 minecraft:light_gray_concrete replace
setblock ~237 ~43 ~593 minecraft:light_gray_concrete replace
setblock ~258 ~43 ~597 minecraft:light_gray_concrete replace
setblock ~324 ~43 ~601 minecraft:light_gray_concrete replace
setblock ~348 ~43 ~605 minecraft:light_gray_concrete replace
setblock ~102 ~43 ~609 minecraft:light_gray_concrete replace
setblock ~126 ~43 ~613 minecraft:light_gray_concrete replace
setblock ~150 ~43 ~617 minecraft:light_gray_concrete replace
setblock ~177 ~43 ~621 minecraft:light_gray_concrete replace
setblock ~198 ~43 ~625 minecraft:light_gray_concrete replace
setblock ~222 ~43 ~629 minecraft:light_gray_concrete replace
setblock ~264 ~43 ~633 minecraft:light_gray_concrete replace
setblock ~279 ~43 ~637 minecraft:light_gray_concrete replace
setblock ~339 ~43 ~641 minecraft:light_gray_concrete replace
setblock ~159 ~43 ~645 minecraft:light_gray_concrete replace
setblock ~366 ~43 ~649 minecraft:light_gray_concrete replace
setblock ~99 ~43 ~653 minecraft:light_gray_concrete replace
setblock ~342 ~43 ~657 minecraft:light_gray_concrete replace
setblock ~363 ~43 ~661 minecraft:light_gray_concrete replace
fill ~300 ~44 ~38 ~302 ~44 ~38 minecraft:light_gray_concrete replace
fill ~301 ~44 ~39 ~301 ~44 ~40 minecraft:light_gray_concrete replace
fill ~285 ~44 ~42 ~287 ~44 ~42 minecraft:light_gray_concrete replace
fill ~286 ~44 ~43 ~286 ~44 ~44 minecraft:light_gray_concrete replace
fill ~228 ~44 ~46 ~236 ~44 ~46 minecraft:light_gray_concrete replace
fill ~235 ~44 ~47 ~235 ~44 ~48 minecraft:light_gray_concrete replace
fill ~303 ~44 ~50 ~305 ~44 ~50 minecraft:light_gray_concrete replace
fill ~304 ~44 ~51 ~304 ~44 ~52 minecraft:light_gray_concrete replace
fill ~288 ~44 ~54 ~290 ~44 ~54 minecraft:light_gray_concrete replace
fill ~289 ~44 ~55 ~289 ~44 ~56 minecraft:light_gray_concrete replace
fill ~291 ~44 ~62 ~294 ~44 ~62 minecraft:light_gray_concrete replace
fill ~292 ~44 ~63 ~292 ~44 ~64 minecraft:light_gray_concrete replace
fill ~318 ~44 ~78 ~320 ~44 ~78 minecraft:light_gray_concrete replace
fill ~319 ~44 ~79 ~319 ~44 ~80 minecraft:light_gray_concrete replace
fill ~93 ~44 ~250 ~98 ~44 ~250 minecraft:light_gray_concrete replace
fill ~94 ~44 ~251 ~94 ~44 ~252 minecraft:light_gray_concrete replace
fill ~97 ~44 ~251 ~97 ~44 ~252 minecraft:light_gray_concrete replace
fill ~120 ~44 ~270 ~125 ~44 ~270 minecraft:light_gray_concrete replace
fill ~121 ~44 ~271 ~121 ~44 ~272 minecraft:light_gray_concrete replace
fill ~124 ~44 ~271 ~124 ~44 ~272 minecraft:light_gray_concrete replace
fill ~93 ~44 ~278 ~98 ~44 ~278 minecraft:light_gray_concrete replace
fill ~94 ~44 ~279 ~94 ~44 ~280 minecraft:light_gray_concrete replace
fill ~97 ~44 ~279 ~97 ~44 ~280 minecraft:light_gray_concrete replace
fill ~120 ~44 ~282 ~125 ~44 ~282 minecraft:light_gray_concrete replace
fill ~121 ~44 ~283 ~121 ~44 ~284 minecraft:light_gray_concrete replace
fill ~124 ~44 ~283 ~124 ~44 ~284 minecraft:light_gray_concrete replace
fill ~144 ~44 ~286 ~149 ~44 ~286 minecraft:light_gray_concrete replace
fill ~145 ~44 ~287 ~145 ~44 ~288 minecraft:light_gray_concrete replace
fill ~148 ~44 ~287 ~148 ~44 ~288 minecraft:light_gray_concrete replace
fill ~144 ~44 ~298 ~149 ~44 ~298 minecraft:light_gray_concrete replace
fill ~145 ~44 ~299 ~145 ~44 ~300 minecraft:light_gray_concrete replace
fill ~148 ~44 ~299 ~148 ~44 ~300 minecraft:light_gray_concrete replace
fill ~165 ~44 ~302 ~170 ~44 ~302 minecraft:light_gray_concrete replace
fill ~166 ~44 ~303 ~166 ~44 ~304 minecraft:light_gray_concrete replace
fill ~169 ~44 ~303 ~169 ~44 ~304 minecraft:light_gray_concrete replace
fill ~165 ~44 ~314 ~170 ~44 ~314 minecraft:light_gray_concrete replace
fill ~166 ~44 ~315 ~166 ~44 ~316 minecraft:light_gray_concrete replace
fill ~169 ~44 ~315 ~169 ~44 ~316 minecraft:light_gray_concrete replace
fill ~183 ~44 ~322 ~299 ~44 ~322 minecraft:light_gray_concrete replace
fill ~184 ~44 ~323 ~184 ~44 ~324 minecraft:light_gray_concrete replace
fill ~187 ~44 ~323 ~187 ~44 ~324 minecraft:light_gray_concrete replace
fill ~208 ~44 ~323 ~208 ~44 ~324 minecraft:light_gray_concrete replace
fill ~232 ~44 ~323 ~232 ~44 ~324 minecraft:light_gray_concrete replace
fill ~283 ~44 ~323 ~283 ~44 ~324 minecraft:light_gray_concrete replace
fill ~298 ~44 ~323 ~298 ~44 ~324 minecraft:light_gray_concrete replace
fill ~183 ~44 ~326 ~188 ~44 ~326 minecraft:light_gray_concrete replace
fill ~184 ~44 ~327 ~184 ~44 ~328 minecraft:light_gray_concrete replace
fill ~187 ~44 ~327 ~187 ~44 ~328 minecraft:light_gray_concrete replace
fill ~204 ~44 ~330 ~212 ~44 ~330 minecraft:light_gray_concrete replace
fill ~211 ~44 ~331 ~211 ~44 ~332 minecraft:light_gray_concrete replace
fill ~207 ~44 ~334 ~299 ~44 ~334 minecraft:light_gray_concrete replace
fill ~208 ~44 ~335 ~208 ~44 ~336 minecraft:light_gray_concrete replace
fill ~232 ~44 ~335 ~232 ~44 ~336 minecraft:light_gray_concrete replace
fill ~283 ~44 ~335 ~283 ~44 ~336 minecraft:light_gray_concrete replace
fill ~298 ~44 ~335 ~298 ~44 ~336 minecraft:light_gray_concrete replace
fill ~207 ~44 ~342 ~215 ~44 ~342 minecraft:light_gray_concrete replace
fill ~214 ~44 ~343 ~214 ~44 ~344 minecraft:light_gray_concrete replace
fill ~231 ~44 ~346 ~239 ~44 ~346 minecraft:light_gray_concrete replace
fill ~238 ~44 ~347 ~238 ~44 ~348 minecraft:light_gray_concrete replace
fill ~231 ~44 ~350 ~299 ~44 ~350 minecraft:light_gray_concrete replace
fill ~232 ~44 ~351 ~232 ~44 ~352 minecraft:light_gray_concrete replace
fill ~283 ~44 ~351 ~283 ~44 ~352 minecraft:light_gray_concrete replace
fill ~298 ~44 ~351 ~298 ~44 ~352 minecraft:light_gray_concrete replace
fill ~234 ~44 ~358 ~242 ~44 ~358 minecraft:light_gray_concrete replace
fill ~241 ~44 ~359 ~241 ~44 ~360 minecraft:light_gray_concrete replace
fill ~282 ~44 ~362 ~299 ~44 ~362 minecraft:light_gray_concrete replace
fill ~283 ~44 ~363 ~283 ~44 ~364 minecraft:light_gray_concrete replace
fill ~298 ~44 ~363 ~298 ~44 ~364 minecraft:light_gray_concrete replace
fill ~306 ~44 ~366 ~308 ~44 ~366 minecraft:light_gray_concrete replace
fill ~307 ~44 ~367 ~307 ~44 ~368 minecraft:light_gray_concrete replace
fill ~309 ~44 ~370 ~311 ~44 ~370 minecraft:light_gray_concrete replace
fill ~310 ~44 ~371 ~310 ~44 ~372 minecraft:light_gray_concrete replace
fill ~282 ~44 ~374 ~284 ~44 ~374 minecraft:light_gray_concrete replace
fill ~283 ~44 ~375 ~283 ~44 ~376 minecraft:light_gray_concrete replace
fill ~294 ~44 ~378 ~297 ~44 ~378 minecraft:light_gray_concrete replace
fill ~295 ~44 ~379 ~295 ~44 ~380 minecraft:light_gray_concrete replace
fill ~255 ~44 ~386 ~260 ~44 ~386 minecraft:light_gray_concrete replace
fill ~259 ~44 ~387 ~259 ~44 ~388 minecraft:light_gray_concrete replace
fill ~333 ~44 ~390 ~335 ~44 ~390 minecraft:light_gray_concrete replace
fill ~334 ~44 ~391 ~334 ~44 ~392 minecraft:light_gray_concrete replace
fill ~354 ~44 ~394 ~356 ~44 ~394 minecraft:light_gray_concrete replace
fill ~355 ~44 ~395 ~355 ~44 ~396 minecraft:light_gray_concrete replace
fill ~321 ~44 ~398 ~323 ~44 ~398 minecraft:light_gray_concrete replace
fill ~322 ~44 ~399 ~322 ~44 ~400 minecraft:light_gray_concrete replace
fill ~345 ~44 ~402 ~347 ~44 ~402 minecraft:light_gray_concrete replace
fill ~346 ~44 ~403 ~346 ~44 ~404 minecraft:light_gray_concrete replace
fill ~315 ~44 ~406 ~317 ~44 ~406 minecraft:light_gray_concrete replace
fill ~316 ~44 ~407 ~316 ~44 ~408 minecraft:light_gray_concrete replace
fill ~90 ~44 ~414 ~92 ~44 ~414 minecraft:light_gray_concrete replace
fill ~91 ~44 ~415 ~91 ~44 ~416 minecraft:light_gray_concrete replace
fill ~117 ~44 ~418 ~119 ~44 ~418 minecraft:light_gray_concrete replace
fill ~118 ~44 ~419 ~118 ~44 ~420 minecraft:light_gray_concrete replace
fill ~141 ~44 ~422 ~143 ~44 ~422 minecraft:light_gray_concrete replace
fill ~142 ~44 ~423 ~142 ~44 ~424 minecraft:light_gray_concrete replace
fill ~174 ~44 ~426 ~176 ~44 ~426 minecraft:light_gray_concrete replace
fill ~175 ~44 ~427 ~175 ~44 ~428 minecraft:light_gray_concrete replace
fill ~195 ~44 ~430 ~200 ~44 ~430 minecraft:light_gray_concrete replace
fill ~199 ~44 ~431 ~199 ~44 ~432 minecraft:light_gray_concrete replace
fill ~219 ~44 ~434 ~227 ~44 ~434 minecraft:light_gray_concrete replace
fill ~226 ~44 ~435 ~226 ~44 ~436 minecraft:light_gray_concrete replace
fill ~252 ~44 ~438 ~257 ~44 ~438 minecraft:light_gray_concrete replace
fill ~256 ~44 ~439 ~256 ~44 ~440 minecraft:light_gray_concrete replace
fill ~276 ~44 ~442 ~278 ~44 ~442 minecraft:light_gray_concrete replace
fill ~277 ~44 ~443 ~277 ~44 ~444 minecraft:light_gray_concrete replace
fill ~312 ~44 ~446 ~314 ~44 ~446 minecraft:light_gray_concrete replace
fill ~313 ~44 ~447 ~313 ~44 ~448 minecraft:light_gray_concrete replace
fill ~87 ~44 ~450 ~89 ~44 ~450 minecraft:light_gray_concrete replace
fill ~88 ~44 ~451 ~88 ~44 ~452 minecraft:light_gray_concrete replace
fill ~114 ~44 ~454 ~116 ~44 ~454 minecraft:light_gray_concrete replace
fill ~115 ~44 ~455 ~115 ~44 ~456 minecraft:light_gray_concrete replace
fill ~138 ~44 ~458 ~140 ~44 ~458 minecraft:light_gray_concrete replace
fill ~139 ~44 ~459 ~139 ~44 ~460 minecraft:light_gray_concrete replace
fill ~171 ~44 ~462 ~173 ~44 ~462 minecraft:light_gray_concrete replace
fill ~172 ~44 ~463 ~172 ~44 ~464 minecraft:light_gray_concrete replace
fill ~192 ~44 ~466 ~197 ~44 ~466 minecraft:light_gray_concrete replace
fill ~196 ~44 ~467 ~196 ~44 ~468 minecraft:light_gray_concrete replace
fill ~216 ~44 ~470 ~224 ~44 ~470 minecraft:light_gray_concrete replace
fill ~223 ~44 ~471 ~223 ~44 ~472 minecraft:light_gray_concrete replace
fill ~246 ~44 ~474 ~254 ~44 ~474 minecraft:light_gray_concrete replace
fill ~253 ~44 ~475 ~253 ~44 ~476 minecraft:light_gray_concrete replace
fill ~273 ~44 ~478 ~275 ~44 ~478 minecraft:light_gray_concrete replace
fill ~274 ~44 ~479 ~274 ~44 ~480 minecraft:light_gray_concrete replace
fill ~336 ~44 ~482 ~338 ~44 ~482 minecraft:light_gray_concrete replace
fill ~337 ~44 ~483 ~337 ~44 ~484 minecraft:light_gray_concrete replace
fill ~360 ~44 ~486 ~362 ~44 ~486 minecraft:light_gray_concrete replace
fill ~361 ~44 ~487 ~361 ~44 ~488 minecraft:light_gray_concrete replace
fill ~84 ~44 ~490 ~86 ~44 ~490 minecraft:light_gray_concrete replace
fill ~85 ~44 ~491 ~85 ~44 ~492 minecraft:light_gray_concrete replace
fill ~111 ~44 ~494 ~113 ~44 ~494 minecraft:light_gray_concrete replace
fill ~112 ~44 ~495 ~112 ~44 ~496 minecraft:light_gray_concrete replace
fill ~135 ~44 ~498 ~137 ~44 ~498 minecraft:light_gray_concrete replace
fill ~136 ~44 ~499 ~136 ~44 ~500 minecraft:light_gray_concrete replace
fill ~162 ~44 ~502 ~164 ~44 ~502 minecraft:light_gray_concrete replace
fill ~163 ~44 ~503 ~163 ~44 ~504 minecraft:light_gray_concrete replace
fill ~189 ~44 ~506 ~194 ~44 ~506 minecraft:light_gray_concrete replace
fill ~193 ~44 ~507 ~193 ~44 ~508 minecraft:light_gray_concrete replace
fill ~213 ~44 ~510 ~221 ~44 ~510 minecraft:light_gray_concrete replace
fill ~220 ~44 ~511 ~220 ~44 ~512 minecraft:light_gray_concrete replace
fill ~243 ~44 ~514 ~251 ~44 ~514 minecraft:light_gray_concrete replace
fill ~250 ~44 ~515 ~250 ~44 ~516 minecraft:light_gray_concrete replace
fill ~270 ~44 ~518 ~272 ~44 ~518 minecraft:light_gray_concrete replace
fill ~271 ~44 ~519 ~271 ~44 ~520 minecraft:light_gray_concrete replace
fill ~330 ~44 ~522 ~332 ~44 ~522 minecraft:light_gray_concrete replace
fill ~331 ~44 ~523 ~331 ~44 ~524 minecraft:light_gray_concrete replace
fill ~357 ~44 ~526 ~359 ~44 ~526 minecraft:light_gray_concrete replace
fill ~358 ~44 ~527 ~358 ~44 ~528 minecraft:light_gray_concrete replace
fill ~81 ~44 ~530 ~83 ~44 ~530 minecraft:light_gray_concrete replace
fill ~82 ~44 ~531 ~82 ~44 ~532 minecraft:light_gray_concrete replace
fill ~108 ~44 ~534 ~110 ~44 ~534 minecraft:light_gray_concrete replace
fill ~109 ~44 ~535 ~109 ~44 ~536 minecraft:light_gray_concrete replace
fill ~132 ~44 ~538 ~134 ~44 ~538 minecraft:light_gray_concrete replace
fill ~133 ~44 ~539 ~133 ~44 ~540 minecraft:light_gray_concrete replace
fill ~156 ~44 ~542 ~158 ~44 ~542 minecraft:light_gray_concrete replace
fill ~157 ~44 ~543 ~157 ~44 ~544 minecraft:light_gray_concrete replace
fill ~186 ~44 ~546 ~191 ~44 ~546 minecraft:light_gray_concrete replace
fill ~190 ~44 ~547 ~190 ~44 ~548 minecraft:light_gray_concrete replace
fill ~210 ~44 ~550 ~218 ~44 ~550 minecraft:light_gray_concrete replace
fill ~217 ~44 ~551 ~217 ~44 ~552 minecraft:light_gray_concrete replace
fill ~240 ~44 ~554 ~248 ~44 ~554 minecraft:light_gray_concrete replace
fill ~247 ~44 ~555 ~247 ~44 ~556 minecraft:light_gray_concrete replace
fill ~261 ~44 ~558 ~266 ~44 ~558 minecraft:light_gray_concrete replace
fill ~265 ~44 ~559 ~265 ~44 ~560 minecraft:light_gray_concrete replace
fill ~327 ~44 ~562 ~329 ~44 ~562 minecraft:light_gray_concrete replace
fill ~328 ~44 ~563 ~328 ~44 ~564 minecraft:light_gray_concrete replace
fill ~351 ~44 ~566 ~353 ~44 ~566 minecraft:light_gray_concrete replace
fill ~352 ~44 ~567 ~352 ~44 ~568 minecraft:light_gray_concrete replace
fill ~78 ~44 ~570 ~80 ~44 ~570 minecraft:light_gray_concrete replace
fill ~79 ~44 ~571 ~79 ~44 ~572 minecraft:light_gray_concrete replace
fill ~105 ~44 ~574 ~107 ~44 ~574 minecraft:light_gray_concrete replace
fill ~106 ~44 ~575 ~106 ~44 ~576 minecraft:light_gray_concrete replace
fill ~129 ~44 ~578 ~131 ~44 ~578 minecraft:light_gray_concrete replace
fill ~130 ~44 ~579 ~130 ~44 ~580 minecraft:light_gray_concrete replace
fill ~153 ~44 ~582 ~155 ~44 ~582 minecraft:light_gray_concrete replace
fill ~154 ~44 ~583 ~154 ~44 ~584 minecraft:light_gray_concrete replace
fill ~180 ~44 ~586 ~182 ~44 ~586 minecraft:light_gray_concrete replace
fill ~181 ~44 ~587 ~181 ~44 ~588 minecraft:light_gray_concrete replace
fill ~201 ~44 ~590 ~206 ~44 ~590 minecraft:light_gray_concrete replace
fill ~205 ~44 ~591 ~205 ~44 ~592 minecraft:light_gray_concrete replace
fill ~237 ~44 ~594 ~245 ~44 ~594 minecraft:light_gray_concrete replace
fill ~244 ~44 ~595 ~244 ~44 ~596 minecraft:light_gray_concrete replace
fill ~258 ~44 ~598 ~263 ~44 ~598 minecraft:light_gray_concrete replace
fill ~262 ~44 ~599 ~262 ~44 ~600 minecraft:light_gray_concrete replace
fill ~324 ~44 ~602 ~326 ~44 ~602 minecraft:light_gray_concrete replace
fill ~325 ~44 ~603 ~325 ~44 ~604 minecraft:light_gray_concrete replace
fill ~348 ~44 ~606 ~350 ~44 ~606 minecraft:light_gray_concrete replace
fill ~349 ~44 ~607 ~349 ~44 ~608 minecraft:light_gray_concrete replace
fill ~102 ~44 ~610 ~104 ~44 ~610 minecraft:light_gray_concrete replace
fill ~103 ~44 ~611 ~103 ~44 ~612 minecraft:light_gray_concrete replace
fill ~126 ~44 ~614 ~128 ~44 ~614 minecraft:light_gray_concrete replace
fill ~127 ~44 ~615 ~127 ~44 ~616 minecraft:light_gray_concrete replace
fill ~150 ~44 ~618 ~152 ~44 ~618 minecraft:light_gray_concrete replace
fill ~151 ~44 ~619 ~151 ~44 ~620 minecraft:light_gray_concrete replace
fill ~177 ~44 ~622 ~179 ~44 ~622 minecraft:light_gray_concrete replace
fill ~178 ~44 ~623 ~178 ~44 ~624 minecraft:light_gray_concrete replace
fill ~198 ~44 ~626 ~203 ~44 ~626 minecraft:light_gray_concrete replace
fill ~202 ~44 ~627 ~202 ~44 ~628 minecraft:light_gray_concrete replace
fill ~222 ~44 ~630 ~230 ~44 ~630 minecraft:light_gray_concrete replace
fill ~229 ~44 ~631 ~229 ~44 ~632 minecraft:light_gray_concrete replace
fill ~264 ~44 ~634 ~269 ~44 ~634 minecraft:light_gray_concrete replace
fill ~268 ~44 ~635 ~268 ~44 ~636 minecraft:light_gray_concrete replace
fill ~279 ~44 ~638 ~281 ~44 ~638 minecraft:light_gray_concrete replace
fill ~280 ~44 ~639 ~280 ~44 ~640 minecraft:light_gray_concrete replace
fill ~339 ~44 ~642 ~341 ~44 ~642 minecraft:light_gray_concrete replace
fill ~340 ~44 ~643 ~340 ~44 ~644 minecraft:light_gray_concrete replace
fill ~159 ~44 ~646 ~161 ~44 ~646 minecraft:light_gray_concrete replace
fill ~160 ~44 ~647 ~160 ~44 ~648 minecraft:light_gray_concrete replace
fill ~366 ~44 ~650 ~368 ~44 ~650 minecraft:light_gray_concrete replace
fill ~367 ~44 ~651 ~367 ~44 ~652 minecraft:light_gray_concrete replace
fill ~99 ~44 ~654 ~101 ~44 ~654 minecraft:light_gray_concrete replace
fill ~100 ~44 ~655 ~100 ~44 ~656 minecraft:light_gray_concrete replace
fill ~342 ~44 ~658 ~344 ~44 ~658 minecraft:light_gray_concrete replace
fill ~343 ~44 ~659 ~343 ~44 ~660 minecraft:light_gray_concrete replace
fill ~363 ~44 ~662 ~365 ~44 ~662 minecraft:light_gray_concrete replace
fill ~364 ~44 ~663 ~364 ~44 ~664 minecraft:light_gray_concrete replace
setblock ~301 ~45 ~40 minecraft:light_gray_concrete replace
setblock ~286 ~45 ~44 minecraft:light_gray_concrete replace
setblock ~235 ~45 ~48 minecraft:light_gray_concrete replace
setblock ~304 ~45 ~52 minecraft:light_gray_concrete replace
setblock ~289 ~45 ~56 minecraft:light_gray_concrete replace
setblock ~292 ~45 ~64 minecraft:light_gray_concrete replace
setblock ~319 ~45 ~80 minecraft:light_gray_concrete replace
setblock ~94 ~45 ~252 minecraft:light_gray_concrete replace
setblock ~97 ~45 ~252 minecraft:light_gray_concrete replace
setblock ~121 ~45 ~272 minecraft:light_gray_concrete replace
setblock ~124 ~45 ~272 minecraft:light_gray_concrete replace
setblock ~94 ~45 ~280 minecraft:light_gray_concrete replace
setblock ~97 ~45 ~280 minecraft:light_gray_concrete replace
setblock ~121 ~45 ~284 minecraft:light_gray_concrete replace
setblock ~124 ~45 ~284 minecraft:light_gray_concrete replace
setblock ~145 ~45 ~288 minecraft:light_gray_concrete replace
setblock ~148 ~45 ~288 minecraft:light_gray_concrete replace
setblock ~145 ~45 ~300 minecraft:light_gray_concrete replace
setblock ~148 ~45 ~300 minecraft:light_gray_concrete replace
setblock ~166 ~45 ~304 minecraft:light_gray_concrete replace
setblock ~169 ~45 ~304 minecraft:light_gray_concrete replace
setblock ~166 ~45 ~316 minecraft:light_gray_concrete replace
setblock ~169 ~45 ~316 minecraft:light_gray_concrete replace
setblock ~201 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~203 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~217 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~219 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~245 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~247 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~261 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~263 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~277 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~279 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~293 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~295 ~45 ~322 minecraft:light_gray_concrete replace
setblock ~184 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~187 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~208 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~232 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~324 minecraft:light_gray_concrete replace
setblock ~184 ~45 ~328 minecraft:light_gray_concrete replace
setblock ~187 ~45 ~328 minecraft:light_gray_concrete replace
setblock ~211 ~45 ~332 minecraft:light_gray_concrete replace
setblock ~209 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~211 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~225 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~227 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~241 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~243 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~256 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~258 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~273 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~275 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~290 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~292 ~45 ~334 minecraft:light_gray_concrete replace
setblock ~208 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~232 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~336 minecraft:light_gray_concrete replace
setblock ~214 ~45 ~344 minecraft:light_gray_concrete replace
setblock ~238 ~45 ~348 minecraft:light_gray_concrete replace
setblock ~241 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~243 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~258 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~260 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~274 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~276 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~291 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~293 ~45 ~350 minecraft:light_gray_concrete replace
setblock ~232 ~45 ~352 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~352 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~352 minecraft:light_gray_concrete replace
setblock ~241 ~45 ~360 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~364 minecraft:light_gray_concrete replace
setblock ~298 ~45 ~364 minecraft:light_gray_concrete replace
setblock ~307 ~45 ~368 minecraft:light_gray_concrete replace
setblock ~310 ~45 ~372 minecraft:light_gray_concrete replace
setblock ~283 ~45 ~376 minecraft:light_gray_concrete replace
setblock ~295 ~45 ~380 minecraft:light_gray_concrete replace
setblock ~259 ~45 ~388 minecraft:light_gray_concrete replace
setblock ~334 ~45 ~392 minecraft:light_gray_concrete replace
setblock ~355 ~45 ~396 minecraft:light_gray_concrete replace
setblock ~322 ~45 ~400 minecraft:light_gray_concrete replace
setblock ~346 ~45 ~404 minecraft:light_gray_concrete replace
setblock ~316 ~45 ~408 minecraft:light_gray_concrete replace
setblock ~91 ~45 ~416 minecraft:light_gray_concrete replace
setblock ~118 ~45 ~420 minecraft:light_gray_concrete replace
setblock ~142 ~45 ~424 minecraft:light_gray_concrete replace
setblock ~175 ~45 ~428 minecraft:light_gray_concrete replace
setblock ~199 ~45 ~432 minecraft:light_gray_concrete replace
setblock ~226 ~45 ~436 minecraft:light_gray_concrete replace
setblock ~256 ~45 ~440 minecraft:light_gray_concrete replace
setblock ~277 ~45 ~444 minecraft:light_gray_concrete replace
setblock ~313 ~45 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~45 ~452 minecraft:light_gray_concrete replace
setblock ~115 ~45 ~456 minecraft:light_gray_concrete replace
setblock ~139 ~45 ~460 minecraft:light_gray_concrete replace
setblock ~172 ~45 ~464 minecraft:light_gray_concrete replace
setblock ~196 ~45 ~468 minecraft:light_gray_concrete replace
setblock ~223 ~45 ~472 minecraft:light_gray_concrete replace
setblock ~253 ~45 ~476 minecraft:light_gray_concrete replace
setblock ~274 ~45 ~480 minecraft:light_gray_concrete replace
setblock ~337 ~45 ~484 minecraft:light_gray_concrete replace
setblock ~361 ~45 ~488 minecraft:light_gray_concrete replace
setblock ~85 ~45 ~492 minecraft:light_gray_concrete replace
setblock ~112 ~45 ~496 minecraft:light_gray_concrete replace
setblock ~136 ~45 ~500 minecraft:light_gray_concrete replace
setblock ~163 ~45 ~504 minecraft:light_gray_concrete replace
setblock ~193 ~45 ~508 minecraft:light_gray_concrete replace
setblock ~220 ~45 ~512 minecraft:light_gray_concrete replace
setblock ~250 ~45 ~516 minecraft:light_gray_concrete replace
setblock ~271 ~45 ~520 minecraft:light_gray_concrete replace
setblock ~331 ~45 ~524 minecraft:light_gray_concrete replace
setblock ~358 ~45 ~528 minecraft:light_gray_concrete replace
setblock ~82 ~45 ~532 minecraft:light_gray_concrete replace
setblock ~109 ~45 ~536 minecraft:light_gray_concrete replace
setblock ~133 ~45 ~540 minecraft:light_gray_concrete replace
setblock ~157 ~45 ~544 minecraft:light_gray_concrete replace
setblock ~190 ~45 ~548 minecraft:light_gray_concrete replace
setblock ~217 ~45 ~552 minecraft:light_gray_concrete replace
setblock ~247 ~45 ~556 minecraft:light_gray_concrete replace
setblock ~265 ~45 ~560 minecraft:light_gray_concrete replace
setblock ~328 ~45 ~564 minecraft:light_gray_concrete replace
setblock ~352 ~45 ~568 minecraft:light_gray_concrete replace
setblock ~79 ~45 ~572 minecraft:light_gray_concrete replace
setblock ~106 ~45 ~576 minecraft:light_gray_concrete replace
setblock ~130 ~45 ~580 minecraft:light_gray_concrete replace
setblock ~154 ~45 ~584 minecraft:light_gray_concrete replace
setblock ~181 ~45 ~588 minecraft:light_gray_concrete replace
setblock ~205 ~45 ~592 minecraft:light_gray_concrete replace
setblock ~244 ~45 ~596 minecraft:light_gray_concrete replace
setblock ~262 ~45 ~600 minecraft:light_gray_concrete replace
setblock ~325 ~45 ~604 minecraft:light_gray_concrete replace
setblock ~349 ~45 ~608 minecraft:light_gray_concrete replace
setblock ~103 ~45 ~612 minecraft:light_gray_concrete replace
setblock ~127 ~45 ~616 minecraft:light_gray_concrete replace
setblock ~151 ~45 ~620 minecraft:light_gray_concrete replace
setblock ~178 ~45 ~624 minecraft:light_gray_concrete replace
setblock ~202 ~45 ~628 minecraft:light_gray_concrete replace
setblock ~229 ~45 ~632 minecraft:light_gray_concrete replace
setblock ~268 ~45 ~636 minecraft:light_gray_concrete replace
setblock ~280 ~45 ~640 minecraft:light_gray_concrete replace
setblock ~340 ~45 ~644 minecraft:light_gray_concrete replace
setblock ~160 ~45 ~648 minecraft:light_gray_concrete replace
setblock ~367 ~45 ~652 minecraft:light_gray_concrete replace
setblock ~100 ~45 ~656 minecraft:light_gray_concrete replace
setblock ~343 ~45 ~660 minecraft:light_gray_concrete replace
setblock ~364 ~45 ~664 minecraft:light_gray_concrete replace
fill ~300 ~46 ~36 ~300 ~46 ~40 minecraft:light_gray_concrete replace
fill ~285 ~46 ~40 ~285 ~46 ~44 minecraft:light_gray_concrete replace
fill ~234 ~46 ~44 ~234 ~46 ~48 minecraft:light_gray_concrete replace
fill ~303 ~46 ~48 ~303 ~46 ~52 minecraft:light_gray_concrete replace
fill ~288 ~46 ~52 ~288 ~46 ~56 minecraft:light_gray_concrete replace
fill ~291 ~46 ~60 ~291 ~46 ~64 minecraft:light_gray_concrete replace
fill ~318 ~46 ~76 ~318 ~46 ~80 minecraft:light_gray_concrete replace
fill ~96 ~46 ~244 ~96 ~46 ~280 minecraft:light_gray_concrete replace
fill ~93 ~46 ~248 ~93 ~46 ~280 minecraft:light_gray_concrete replace
fill ~123 ~46 ~264 ~123 ~46 ~284 minecraft:light_gray_concrete replace
fill ~120 ~46 ~268 ~120 ~46 ~284 minecraft:light_gray_concrete replace
fill ~147 ~46 ~280 ~147 ~46 ~300 minecraft:light_gray_concrete replace
fill ~144 ~46 ~284 ~144 ~46 ~300 minecraft:light_gray_concrete replace
fill ~168 ~46 ~292 ~168 ~46 ~316 minecraft:light_gray_concrete replace
fill ~165 ~46 ~296 ~165 ~46 ~316 minecraft:light_gray_concrete replace
fill ~297 ~46 ~300 ~297 ~46 ~364 minecraft:light_gray_concrete replace
fill ~282 ~46 ~304 ~282 ~46 ~376 minecraft:light_gray_concrete replace
fill ~231 ~46 ~308 ~231 ~46 ~352 minecraft:light_gray_concrete replace
fill ~207 ~46 ~312 ~207 ~46 ~336 minecraft:light_gray_concrete replace
fill ~186 ~46 ~316 ~186 ~46 ~328 minecraft:light_gray_concrete replace
fill ~183 ~46 ~320 ~183 ~46 ~328 minecraft:light_gray_concrete replace
fill ~210 ~46 ~328 ~210 ~46 ~332 minecraft:light_gray_concrete replace
fill ~213 ~46 ~340 ~213 ~46 ~344 minecraft:light_gray_concrete replace
fill ~237 ~46 ~344 ~237 ~46 ~348 minecraft:light_gray_concrete replace
fill ~240 ~46 ~356 ~240 ~46 ~360 minecraft:light_gray_concrete replace
fill ~306 ~46 ~364 ~306 ~46 ~368 minecraft:light_gray_concrete replace
fill ~309 ~46 ~368 ~309 ~46 ~372 minecraft:light_gray_concrete replace
fill ~294 ~46 ~376 ~294 ~46 ~380 minecraft:light_gray_concrete replace
fill ~258 ~46 ~384 ~258 ~46 ~388 minecraft:light_gray_concrete replace
fill ~333 ~46 ~388 ~333 ~46 ~392 minecraft:light_gray_concrete replace
fill ~354 ~46 ~392 ~354 ~46 ~396 minecraft:light_gray_concrete replace
fill ~321 ~46 ~396 ~321 ~46 ~400 minecraft:light_gray_concrete replace
fill ~345 ~46 ~400 ~345 ~46 ~404 minecraft:light_gray_concrete replace
fill ~315 ~46 ~404 ~315 ~46 ~408 minecraft:light_gray_concrete replace
fill ~90 ~46 ~412 ~90 ~46 ~416 minecraft:light_gray_concrete replace
fill ~117 ~46 ~416 ~117 ~46 ~420 minecraft:light_gray_concrete replace
fill ~141 ~46 ~420 ~141 ~46 ~424 minecraft:light_gray_concrete replace
fill ~174 ~46 ~424 ~174 ~46 ~428 minecraft:light_gray_concrete replace
fill ~198 ~46 ~428 ~198 ~46 ~432 minecraft:light_gray_concrete replace
fill ~225 ~46 ~432 ~225 ~46 ~436 minecraft:light_gray_concrete replace
fill ~255 ~46 ~436 ~255 ~46 ~440 minecraft:light_gray_concrete replace
fill ~276 ~46 ~440 ~276 ~46 ~444 minecraft:light_gray_concrete replace
fill ~312 ~46 ~444 ~312 ~46 ~448 minecraft:light_gray_concrete replace
fill ~87 ~46 ~448 ~87 ~46 ~452 minecraft:light_gray_concrete replace
fill ~114 ~46 ~452 ~114 ~46 ~456 minecraft:light_gray_concrete replace
fill ~138 ~46 ~456 ~138 ~46 ~460 minecraft:light_gray_concrete replace
fill ~171 ~46 ~460 ~171 ~46 ~464 minecraft:light_gray_concrete replace
fill ~195 ~46 ~464 ~195 ~46 ~468 minecraft:light_gray_concrete replace
fill ~222 ~46 ~468 ~222 ~46 ~472 minecraft:light_gray_concrete replace
fill ~252 ~46 ~472 ~252 ~46 ~476 minecraft:light_gray_concrete replace
fill ~273 ~46 ~476 ~273 ~46 ~480 minecraft:light_gray_concrete replace
fill ~336 ~46 ~480 ~336 ~46 ~484 minecraft:light_gray_concrete replace
fill ~360 ~46 ~484 ~360 ~46 ~488 minecraft:light_gray_concrete replace
fill ~84 ~46 ~488 ~84 ~46 ~492 minecraft:light_gray_concrete replace
fill ~111 ~46 ~492 ~111 ~46 ~496 minecraft:light_gray_concrete replace
fill ~135 ~46 ~496 ~135 ~46 ~500 minecraft:light_gray_concrete replace
fill ~162 ~46 ~500 ~162 ~46 ~504 minecraft:light_gray_concrete replace
fill ~192 ~46 ~504 ~192 ~46 ~508 minecraft:light_gray_concrete replace
fill ~219 ~46 ~508 ~219 ~46 ~512 minecraft:light_gray_concrete replace
fill ~249 ~46 ~512 ~249 ~46 ~516 minecraft:light_gray_concrete replace
fill ~270 ~46 ~516 ~270 ~46 ~520 minecraft:light_gray_concrete replace
fill ~330 ~46 ~520 ~330 ~46 ~524 minecraft:light_gray_concrete replace
fill ~357 ~46 ~524 ~357 ~46 ~528 minecraft:light_gray_concrete replace
fill ~81 ~46 ~528 ~81 ~46 ~532 minecraft:light_gray_concrete replace
fill ~108 ~46 ~532 ~108 ~46 ~536 minecraft:light_gray_concrete replace
fill ~132 ~46 ~536 ~132 ~46 ~540 minecraft:light_gray_concrete replace
fill ~156 ~46 ~540 ~156 ~46 ~544 minecraft:light_gray_concrete replace
fill ~189 ~46 ~544 ~189 ~46 ~548 minecraft:light_gray_concrete replace
fill ~216 ~46 ~548 ~216 ~46 ~552 minecraft:light_gray_concrete replace
fill ~246 ~46 ~552 ~246 ~46 ~556 minecraft:light_gray_concrete replace
fill ~264 ~46 ~556 ~264 ~46 ~560 minecraft:light_gray_concrete replace
fill ~327 ~46 ~560 ~327 ~46 ~564 minecraft:light_gray_concrete replace
fill ~351 ~46 ~564 ~351 ~46 ~568 minecraft:light_gray_concrete replace
fill ~78 ~46 ~568 ~78 ~46 ~572 minecraft:light_gray_concrete replace
fill ~105 ~46 ~572 ~105 ~46 ~576 minecraft:light_gray_concrete replace
fill ~129 ~46 ~576 ~129 ~46 ~580 minecraft:light_gray_concrete replace
fill ~153 ~46 ~580 ~153 ~46 ~584 minecraft:light_gray_concrete replace
fill ~180 ~46 ~584 ~180 ~46 ~588 minecraft:light_gray_concrete replace
fill ~204 ~46 ~588 ~204 ~46 ~592 minecraft:light_gray_concrete replace
fill ~243 ~46 ~592 ~243 ~46 ~596 minecraft:light_gray_concrete replace
fill ~261 ~46 ~596 ~261 ~46 ~600 minecraft:light_gray_concrete replace
fill ~324 ~46 ~600 ~324 ~46 ~604 minecraft:light_gray_concrete replace
fill ~348 ~46 ~604 ~348 ~46 ~608 minecraft:light_gray_concrete replace
fill ~102 ~46 ~608 ~102 ~46 ~612 minecraft:light_gray_concrete replace
fill ~126 ~46 ~612 ~126 ~46 ~616 minecraft:light_gray_concrete replace
fill ~150 ~46 ~616 ~150 ~46 ~620 minecraft:light_gray_concrete replace
fill ~177 ~46 ~620 ~177 ~46 ~624 minecraft:light_gray_concrete replace
fill ~201 ~46 ~624 ~201 ~46 ~628 minecraft:light_gray_concrete replace
fill ~228 ~46 ~628 ~228 ~46 ~632 minecraft:light_gray_concrete replace
fill ~267 ~46 ~632 ~267 ~46 ~636 minecraft:light_gray_concrete replace
fill ~279 ~46 ~636 ~279 ~46 ~640 minecraft:light_gray_concrete replace
fill ~339 ~46 ~640 ~339 ~46 ~644 minecraft:light_gray_concrete replace
fill ~159 ~46 ~644 ~159 ~46 ~648 minecraft:light_gray_concrete replace
fill ~366 ~46 ~648 ~366 ~46 ~652 minecraft:light_gray_concrete replace
fill ~99 ~46 ~652 ~99 ~46 ~656 minecraft:light_gray_concrete replace
fill ~342 ~46 ~656 ~342 ~46 ~660 minecraft:light_gray_concrete replace
fill ~363 ~46 ~660 ~363 ~46 ~664 minecraft:light_gray_concrete replace
setblock ~300 ~47 ~35 minecraft:light_gray_concrete replace
setblock ~285 ~47 ~39 minecraft:light_gray_concrete replace
setblock ~234 ~47 ~43 minecraft:light_gray_concrete replace
setblock ~303 ~47 ~47 minecraft:light_gray_concrete replace
setblock ~288 ~47 ~51 minecraft:light_gray_concrete replace
setblock ~291 ~47 ~59 minecraft:light_gray_concrete replace
setblock ~318 ~47 ~75 minecraft:light_gray_concrete replace
setblock ~96 ~47 ~243 minecraft:light_gray_concrete replace
setblock ~93 ~47 ~247 minecraft:light_gray_concrete replace
setblock ~94 ~47 ~252 minecraft:light_gray_concrete replace
setblock ~123 ~47 ~263 minecraft:light_gray_concrete replace
setblock ~93 ~47 ~265 minecraft:light_gray_concrete replace
setblock ~96 ~47 ~265 minecraft:light_gray_concrete replace
setblock ~93 ~47 ~267 minecraft:light_gray_concrete replace
setblock ~96 ~47 ~267 minecraft:light_gray_concrete replace
setblock ~120 ~47 ~267 minecraft:light_gray_concrete replace
setblock ~124 ~47 ~272 minecraft:light_gray_concrete replace
setblock ~147 ~47 ~279 minecraft:light_gray_concrete replace
setblock ~97 ~47 ~280 minecraft:light_gray_concrete replace
setblock ~144 ~47 ~283 minecraft:light_gray_concrete replace
setblock ~121 ~47 ~284 minecraft:light_gray_concrete replace
setblock ~148 ~47 ~288 minecraft:light_gray_concrete replace
setblock ~168 ~47 ~291 minecraft:light_gray_concrete replace
setblock ~168 ~47 ~293 minecraft:light_gray_concrete replace
setblock ~165 ~47 ~295 minecraft:light_gray_concrete replace
setblock ~297 ~47 ~299 minecraft:light_gray_concrete replace
setblock ~145 ~47 ~300 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~303 minecraft:light_gray_concrete replace
setblock ~169 ~47 ~304 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~305 minecraft:light_gray_concrete replace
setblock ~231 ~47 ~307 minecraft:light_gray_concrete replace
setblock ~297 ~47 ~307 minecraft:light_gray_concrete replace
setblock ~297 ~47 ~309 minecraft:light_gray_concrete replace
setblock ~207 ~47 ~311 minecraft:light_gray_concrete replace
setblock ~207 ~47 ~313 minecraft:light_gray_concrete replace
setblock ~186 ~47 ~315 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~315 minecraft:light_gray_concrete replace
setblock ~166 ~47 ~316 minecraft:light_gray_concrete replace
setblock ~186 ~47 ~317 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~317 minecraft:light_gray_concrete replace
setblock ~183 ~47 ~319 minecraft:light_gray_concrete replace
setblock ~183 ~47 ~321 minecraft:light_gray_concrete replace
setblock ~187 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~208 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~232 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~210 ~47 ~327 minecraft:light_gray_concrete replace
setblock ~184 ~47 ~328 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~331 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~333 minecraft:light_gray_concrete replace
setblock ~208 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~232 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~231 ~47 ~337 minecraft:light_gray_concrete replace
setblock ~213 ~47 ~339 minecraft:light_gray_concrete replace
setblock ~231 ~47 ~339 minecraft:light_gray_concrete replace
setblock ~237 ~47 ~343 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~347 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~349 minecraft:light_gray_concrete replace
setblock ~232 ~47 ~352 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~352 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~352 minecraft:light_gray_concrete replace
setblock ~240 ~47 ~355 minecraft:light_gray_concrete replace
setblock ~306 ~47 ~363 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~364 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~364 minecraft:light_gray_concrete replace
setblock ~309 ~47 ~367 minecraft:light_gray_concrete replace
setblock ~294 ~47 ~375 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~376 minecraft:light_gray_concrete replace
setblock ~258 ~47 ~383 minecraft:light_gray_concrete replace
setblock ~333 ~47 ~387 minecraft:light_gray_concrete replace
setblock ~354 ~47 ~391 minecraft:light_gray_concrete replace
setblock ~321 ~47 ~395 minecraft:light_gray_concrete replace
setblock ~345 ~47 ~399 minecraft:light_gray_concrete replace
setblock ~315 ~47 ~403 minecraft:light_gray_concrete replace
setblock ~90 ~47 ~411 minecraft:light_gray_concrete replace
setblock ~117 ~47 ~415 minecraft:light_gray_concrete replace
setblock ~141 ~47 ~419 minecraft:light_gray_concrete replace
setblock ~174 ~47 ~423 minecraft:light_gray_concrete replace
setblock ~198 ~47 ~427 minecraft:light_gray_concrete replace
setblock ~225 ~47 ~431 minecraft:light_gray_concrete replace
setblock ~255 ~47 ~435 minecraft:light_gray_concrete replace
setblock ~276 ~47 ~439 minecraft:light_gray_concrete replace
setblock ~312 ~47 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~47 ~447 minecraft:light_gray_concrete replace
setblock ~114 ~47 ~451 minecraft:light_gray_concrete replace
setblock ~138 ~47 ~455 minecraft:light_gray_concrete replace
setblock ~171 ~47 ~459 minecraft:light_gray_concrete replace
setblock ~195 ~47 ~463 minecraft:light_gray_concrete replace
setblock ~222 ~47 ~467 minecraft:light_gray_concrete replace
setblock ~252 ~47 ~471 minecraft:light_gray_concrete replace
setblock ~273 ~47 ~475 minecraft:light_gray_concrete replace
setblock ~336 ~47 ~479 minecraft:light_gray_concrete replace
setblock ~360 ~47 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~47 ~487 minecraft:light_gray_concrete replace
setblock ~111 ~47 ~491 minecraft:light_gray_concrete replace
setblock ~135 ~47 ~495 minecraft:light_gray_concrete replace
setblock ~162 ~47 ~499 minecraft:light_gray_concrete replace
setblock ~192 ~47 ~503 minecraft:light_gray_concrete replace
setblock ~219 ~47 ~507 minecraft:light_gray_concrete replace
setblock ~249 ~47 ~511 minecraft:light_gray_concrete replace
setblock ~270 ~47 ~515 minecraft:light_gray_concrete replace
setblock ~330 ~47 ~519 minecraft:light_gray_concrete replace
setblock ~357 ~47 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~47 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~47 ~531 minecraft:light_gray_concrete replace
setblock ~132 ~47 ~535 minecraft:light_gray_concrete replace
setblock ~156 ~47 ~539 minecraft:light_gray_concrete replace
setblock ~189 ~47 ~543 minecraft:light_gray_concrete replace
setblock ~216 ~47 ~547 minecraft:light_gray_concrete replace
setblock ~246 ~47 ~551 minecraft:light_gray_concrete replace
setblock ~264 ~47 ~555 minecraft:light_gray_concrete replace
setblock ~327 ~47 ~559 minecraft:light_gray_concrete replace
setblock ~351 ~47 ~563 minecraft:light_gray_concrete replace
setblock ~78 ~47 ~567 minecraft:light_gray_concrete replace
setblock ~105 ~47 ~571 minecraft:light_gray_concrete replace
setblock ~129 ~47 ~575 minecraft:light_gray_concrete replace
setblock ~153 ~47 ~579 minecraft:light_gray_concrete replace
setblock ~180 ~47 ~583 minecraft:light_gray_concrete replace
setblock ~204 ~47 ~587 minecraft:light_gray_concrete replace
setblock ~243 ~47 ~591 minecraft:light_gray_concrete replace
setblock ~261 ~47 ~595 minecraft:light_gray_concrete replace
setblock ~324 ~47 ~599 minecraft:light_gray_concrete replace
setblock ~348 ~47 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~47 ~607 minecraft:light_gray_concrete replace
setblock ~126 ~47 ~611 minecraft:light_gray_concrete replace
setblock ~150 ~47 ~615 minecraft:light_gray_concrete replace
setblock ~177 ~47 ~619 minecraft:light_gray_concrete replace
setblock ~201 ~47 ~623 minecraft:light_gray_concrete replace
setblock ~228 ~47 ~627 minecraft:light_gray_concrete replace
setblock ~267 ~47 ~631 minecraft:light_gray_concrete replace
setblock ~279 ~47 ~635 minecraft:light_gray_concrete replace
setblock ~339 ~47 ~639 minecraft:light_gray_concrete replace
setblock ~159 ~47 ~643 minecraft:light_gray_concrete replace
setblock ~366 ~47 ~647 minecraft:light_gray_concrete replace
setblock ~99 ~47 ~651 minecraft:light_gray_concrete replace
setblock ~342 ~47 ~655 minecraft:light_gray_concrete replace
setblock ~363 ~47 ~659 minecraft:light_gray_concrete replace
fill ~262 ~48 ~32 ~262 ~48 ~33 minecraft:light_gray_concrete replace
fill ~261 ~48 ~34 ~300 ~48 ~34 minecraft:light_gray_concrete replace
fill ~259 ~48 ~36 ~259 ~48 ~37 minecraft:light_gray_concrete replace
fill ~258 ~48 ~38 ~285 ~48 ~38 minecraft:light_gray_concrete replace
fill ~214 ~48 ~40 ~214 ~48 ~41 minecraft:light_gray_concrete replace
fill ~213 ~48 ~42 ~234 ~48 ~42 minecraft:light_gray_concrete replace
fill ~262 ~48 ~44 ~262 ~48 ~45 minecraft:light_gray_concrete replace
fill ~261 ~48 ~46 ~303 ~48 ~46 minecraft:light_gray_concrete replace
fill ~259 ~48 ~48 ~259 ~48 ~49 minecraft:light_gray_concrete replace
fill ~258 ~48 ~50 ~288 ~48 ~50 minecraft:light_gray_concrete replace
fill ~259 ~48 ~56 ~259 ~48 ~57 minecraft:light_gray_concrete replace
fill ~258 ~48 ~58 ~291 ~48 ~58 minecraft:light_gray_concrete replace
fill ~274 ~48 ~72 ~274 ~48 ~73 minecraft:light_gray_concrete replace
fill ~273 ~48 ~74 ~318 ~48 ~74 minecraft:light_gray_concrete replace
fill ~94 ~48 ~240 ~94 ~48 ~241 minecraft:light_gray_concrete replace
fill ~93 ~48 ~242 ~96 ~48 ~242 minecraft:light_gray_concrete replace
fill ~94 ~48 ~244 ~94 ~48 ~245 minecraft:light_gray_concrete replace
fill ~93 ~48 ~246 ~95 ~48 ~246 minecraft:light_gray_concrete replace
fill ~118 ~48 ~260 ~118 ~48 ~261 minecraft:light_gray_concrete replace
fill ~117 ~48 ~262 ~123 ~48 ~262 minecraft:light_gray_concrete replace
fill ~118 ~48 ~264 ~118 ~48 ~265 minecraft:light_gray_concrete replace
fill ~117 ~48 ~266 ~120 ~48 ~266 minecraft:light_gray_concrete replace
fill ~139 ~48 ~276 ~139 ~48 ~277 minecraft:light_gray_concrete replace
fill ~138 ~48 ~278 ~147 ~48 ~278 minecraft:light_gray_concrete replace
fill ~139 ~48 ~280 ~139 ~48 ~281 minecraft:light_gray_concrete replace
fill ~138 ~48 ~282 ~144 ~48 ~282 minecraft:light_gray_concrete replace
fill ~157 ~48 ~288 ~157 ~48 ~289 minecraft:light_gray_concrete replace
fill ~156 ~48 ~290 ~168 ~48 ~290 minecraft:light_gray_concrete replace
fill ~157 ~48 ~292 ~157 ~48 ~293 minecraft:light_gray_concrete replace
fill ~156 ~48 ~294 ~165 ~48 ~294 minecraft:light_gray_concrete replace
fill ~262 ~48 ~296 ~262 ~48 ~297 minecraft:light_gray_concrete replace
fill ~261 ~48 ~298 ~297 ~48 ~298 minecraft:light_gray_concrete replace
fill ~259 ~48 ~300 ~259 ~48 ~301 minecraft:light_gray_concrete replace
fill ~258 ~48 ~302 ~282 ~48 ~302 minecraft:light_gray_concrete replace
fill ~214 ~48 ~304 ~214 ~48 ~305 minecraft:light_gray_concrete replace
fill ~213 ~48 ~306 ~231 ~48 ~306 minecraft:light_gray_concrete replace
fill ~193 ~48 ~308 ~193 ~48 ~309 minecraft:light_gray_concrete replace
fill ~192 ~48 ~310 ~207 ~48 ~310 minecraft:light_gray_concrete replace
fill ~172 ~48 ~312 ~172 ~48 ~313 minecraft:light_gray_concrete replace
fill ~171 ~48 ~314 ~186 ~48 ~314 minecraft:light_gray_concrete replace
fill ~172 ~48 ~316 ~172 ~48 ~317 minecraft:light_gray_concrete replace
fill ~171 ~48 ~318 ~183 ~48 ~318 minecraft:light_gray_concrete replace
fill ~193 ~48 ~324 ~193 ~48 ~325 minecraft:light_gray_concrete replace
fill ~192 ~48 ~326 ~210 ~48 ~326 minecraft:light_gray_concrete replace
fill ~196 ~48 ~336 ~196 ~48 ~337 minecraft:light_gray_concrete replace
fill ~195 ~48 ~338 ~213 ~48 ~338 minecraft:light_gray_concrete replace
fill ~214 ~48 ~340 ~214 ~48 ~341 minecraft:light_gray_concrete replace
fill ~213 ~48 ~342 ~237 ~48 ~342 minecraft:light_gray_concrete replace
fill ~217 ~48 ~352 ~217 ~48 ~353 minecraft:light_gray_concrete replace
fill ~216 ~48 ~354 ~240 ~48 ~354 minecraft:light_gray_concrete replace
fill ~262 ~48 ~360 ~262 ~48 ~361 minecraft:light_gray_concrete replace
fill ~261 ~48 ~362 ~306 ~48 ~362 minecraft:light_gray_concrete replace
fill ~265 ~48 ~364 ~265 ~48 ~365 minecraft:light_gray_concrete replace
fill ~264 ~48 ~366 ~309 ~48 ~366 minecraft:light_gray_concrete replace
fill ~259 ~48 ~372 ~259 ~48 ~373 minecraft:light_gray_concrete replace
fill ~258 ~48 ~374 ~294 ~48 ~374 minecraft:light_gray_concrete replace
fill ~235 ~48 ~380 ~235 ~48 ~381 minecraft:light_gray_concrete replace
fill ~234 ~48 ~382 ~258 ~48 ~382 minecraft:light_gray_concrete replace
fill ~289 ~48 ~384 ~289 ~48 ~385 minecraft:light_gray_concrete replace
fill ~288 ~48 ~386 ~333 ~48 ~386 minecraft:light_gray_concrete replace
fill ~310 ~48 ~388 ~310 ~48 ~389 minecraft:light_gray_concrete replace
fill ~309 ~48 ~390 ~354 ~48 ~390 minecraft:light_gray_concrete replace
fill ~277 ~48 ~392 ~277 ~48 ~393 minecraft:light_gray_concrete replace
fill ~276 ~48 ~394 ~321 ~48 ~394 minecraft:light_gray_concrete replace
fill ~301 ~48 ~396 ~301 ~48 ~397 minecraft:light_gray_concrete replace
fill ~300 ~48 ~398 ~345 ~48 ~398 minecraft:light_gray_concrete replace
fill ~271 ~48 ~400 ~271 ~48 ~401 minecraft:light_gray_concrete replace
fill ~270 ~48 ~402 ~315 ~48 ~402 minecraft:light_gray_concrete replace
fill ~91 ~48 ~408 ~91 ~48 ~409 minecraft:light_gray_concrete replace
fill ~90 ~48 ~410 ~92 ~48 ~410 minecraft:light_gray_concrete replace
fill ~115 ~48 ~412 ~115 ~48 ~413 minecraft:light_gray_concrete replace
fill ~114 ~48 ~414 ~117 ~48 ~414 minecraft:light_gray_concrete replace
fill ~136 ~48 ~416 ~136 ~48 ~417 minecraft:light_gray_concrete replace
fill ~135 ~48 ~418 ~141 ~48 ~418 minecraft:light_gray_concrete replace
fill ~163 ~48 ~420 ~163 ~48 ~421 minecraft:light_gray_concrete replace
fill ~162 ~48 ~422 ~174 ~48 ~422 minecraft:light_gray_concrete replace
fill ~184 ~48 ~424 ~184 ~48 ~425 minecraft:light_gray_concrete replace
fill ~183 ~48 ~426 ~198 ~48 ~426 minecraft:light_gray_concrete replace
fill ~208 ~48 ~428 ~208 ~48 ~429 minecraft:light_gray_concrete replace
fill ~207 ~48 ~430 ~225 ~48 ~430 minecraft:light_gray_concrete replace
fill ~232 ~48 ~432 ~232 ~48 ~433 minecraft:light_gray_concrete replace
fill ~231 ~48 ~434 ~255 ~48 ~434 minecraft:light_gray_concrete replace
fill ~253 ~48 ~436 ~253 ~48 ~437 minecraft:light_gray_concrete replace
fill ~252 ~48 ~438 ~276 ~48 ~438 minecraft:light_gray_concrete replace
fill ~268 ~48 ~440 ~268 ~48 ~441 minecraft:light_gray_concrete replace
fill ~267 ~48 ~442 ~312 ~48 ~442 minecraft:light_gray_concrete replace
fill ~88 ~48 ~444 ~88 ~48 ~445 minecraft:light_gray_concrete replace
fill ~87 ~48 ~446 ~89 ~48 ~446 minecraft:light_gray_concrete replace
fill ~112 ~48 ~448 ~112 ~48 ~449 minecraft:light_gray_concrete replace
fill ~111 ~48 ~450 ~114 ~48 ~450 minecraft:light_gray_concrete replace
fill ~133 ~48 ~452 ~133 ~48 ~453 minecraft:light_gray_concrete replace
fill ~132 ~48 ~454 ~138 ~48 ~454 minecraft:light_gray_concrete replace
fill ~160 ~48 ~456 ~160 ~48 ~457 minecraft:light_gray_concrete replace
fill ~159 ~48 ~458 ~171 ~48 ~458 minecraft:light_gray_concrete replace
fill ~181 ~48 ~460 ~181 ~48 ~461 minecraft:light_gray_concrete replace
fill ~180 ~48 ~462 ~195 ~48 ~462 minecraft:light_gray_concrete replace
fill ~205 ~48 ~464 ~205 ~48 ~465 minecraft:light_gray_concrete replace
fill ~204 ~48 ~466 ~222 ~48 ~466 minecraft:light_gray_concrete replace
fill ~229 ~48 ~468 ~229 ~48 ~469 minecraft:light_gray_concrete replace
fill ~228 ~48 ~470 ~252 ~48 ~470 minecraft:light_gray_concrete replace
fill ~250 ~48 ~472 ~250 ~48 ~473 minecraft:light_gray_concrete replace
fill ~249 ~48 ~474 ~273 ~48 ~474 minecraft:light_gray_concrete replace
fill ~292 ~48 ~476 ~292 ~48 ~477 minecraft:light_gray_concrete replace
fill ~291 ~48 ~478 ~336 ~48 ~478 minecraft:light_gray_concrete replace
fill ~316 ~48 ~480 ~316 ~48 ~481 minecraft:light_gray_concrete replace
fill ~315 ~48 ~482 ~360 ~48 ~482 minecraft:light_gray_concrete replace
fill ~85 ~48 ~484 ~85 ~48 ~485 minecraft:light_gray_concrete replace
fill ~84 ~48 ~486 ~86 ~48 ~486 minecraft:light_gray_concrete replace
fill ~109 ~48 ~488 ~109 ~48 ~489 minecraft:light_gray_concrete replace
fill ~108 ~48 ~490 ~111 ~48 ~490 minecraft:light_gray_concrete replace
fill ~130 ~48 ~492 ~130 ~48 ~493 minecraft:light_gray_concrete replace
fill ~129 ~48 ~494 ~135 ~48 ~494 minecraft:light_gray_concrete replace
fill ~154 ~48 ~496 ~154 ~48 ~497 minecraft:light_gray_concrete replace
fill ~153 ~48 ~498 ~162 ~48 ~498 minecraft:light_gray_concrete replace
fill ~178 ~48 ~500 ~178 ~48 ~501 minecraft:light_gray_concrete replace
fill ~177 ~48 ~502 ~192 ~48 ~502 minecraft:light_gray_concrete replace
fill ~202 ~48 ~504 ~202 ~48 ~505 minecraft:light_gray_concrete replace
fill ~201 ~48 ~506 ~219 ~48 ~506 minecraft:light_gray_concrete replace
fill ~226 ~48 ~508 ~226 ~48 ~509 minecraft:light_gray_concrete replace
fill ~225 ~48 ~510 ~249 ~48 ~510 minecraft:light_gray_concrete replace
fill ~247 ~48 ~512 ~247 ~48 ~513 minecraft:light_gray_concrete replace
fill ~246 ~48 ~514 ~270 ~48 ~514 minecraft:light_gray_concrete replace
fill ~286 ~48 ~516 ~286 ~48 ~517 minecraft:light_gray_concrete replace
fill ~285 ~48 ~518 ~330 ~48 ~518 minecraft:light_gray_concrete replace
fill ~313 ~48 ~520 ~313 ~48 ~521 minecraft:light_gray_concrete replace
fill ~312 ~48 ~522 ~357 ~48 ~522 minecraft:light_gray_concrete replace
fill ~82 ~48 ~524 ~82 ~48 ~525 minecraft:light_gray_concrete replace
fill ~81 ~48 ~526 ~83 ~48 ~526 minecraft:light_gray_concrete replace
fill ~106 ~48 ~528 ~106 ~48 ~529 minecraft:light_gray_concrete replace
fill ~105 ~48 ~530 ~108 ~48 ~530 minecraft:light_gray_concrete replace
fill ~127 ~48 ~532 ~127 ~48 ~533 minecraft:light_gray_concrete replace
fill ~126 ~48 ~534 ~132 ~48 ~534 minecraft:light_gray_concrete replace
fill ~148 ~48 ~536 ~148 ~48 ~537 minecraft:light_gray_concrete replace
fill ~147 ~48 ~538 ~156 ~48 ~538 minecraft:light_gray_concrete replace
fill ~175 ~48 ~540 ~175 ~48 ~541 minecraft:light_gray_concrete replace
fill ~174 ~48 ~542 ~189 ~48 ~542 minecraft:light_gray_concrete replace
fill ~199 ~48 ~544 ~199 ~48 ~545 minecraft:light_gray_concrete replace
fill ~198 ~48 ~546 ~216 ~48 ~546 minecraft:light_gray_concrete replace
fill ~223 ~48 ~548 ~223 ~48 ~549 minecraft:light_gray_concrete replace
fill ~222 ~48 ~550 ~246 ~48 ~550 minecraft:light_gray_concrete replace
fill ~241 ~48 ~552 ~241 ~48 ~553 minecraft:light_gray_concrete replace
fill ~240 ~48 ~554 ~264 ~48 ~554 minecraft:light_gray_concrete replace
fill ~283 ~48 ~556 ~283 ~48 ~557 minecraft:light_gray_concrete replace
fill ~282 ~48 ~558 ~327 ~48 ~558 minecraft:light_gray_concrete replace
fill ~307 ~48 ~560 ~307 ~48 ~561 minecraft:light_gray_concrete replace
fill ~306 ~48 ~562 ~351 ~48 ~562 minecraft:light_gray_concrete replace
fill ~79 ~48 ~564 ~79 ~48 ~565 minecraft:light_gray_concrete replace
fill ~78 ~48 ~566 ~80 ~48 ~566 minecraft:light_gray_concrete replace
fill ~103 ~48 ~568 ~103 ~48 ~569 minecraft:light_gray_concrete replace
fill ~102 ~48 ~570 ~105 ~48 ~570 minecraft:light_gray_concrete replace
fill ~124 ~48 ~572 ~124 ~48 ~573 minecraft:light_gray_concrete replace
fill ~123 ~48 ~574 ~129 ~48 ~574 minecraft:light_gray_concrete replace
fill ~145 ~48 ~576 ~145 ~48 ~577 minecraft:light_gray_concrete replace
fill ~144 ~48 ~578 ~153 ~48 ~578 minecraft:light_gray_concrete replace
fill ~169 ~48 ~580 ~169 ~48 ~581 minecraft:light_gray_concrete replace
fill ~168 ~48 ~582 ~180 ~48 ~582 minecraft:light_gray_concrete replace
fill ~190 ~48 ~584 ~190 ~48 ~585 minecraft:light_gray_concrete replace
fill ~189 ~48 ~586 ~204 ~48 ~586 minecraft:light_gray_concrete replace
fill ~220 ~48 ~588 ~220 ~48 ~589 minecraft:light_gray_concrete replace
fill ~219 ~48 ~590 ~243 ~48 ~590 minecraft:light_gray_concrete replace
fill ~238 ~48 ~592 ~238 ~48 ~593 minecraft:light_gray_concrete replace
fill ~237 ~48 ~594 ~261 ~48 ~594 minecraft:light_gray_concrete replace
fill ~280 ~48 ~596 ~280 ~48 ~597 minecraft:light_gray_concrete replace
fill ~279 ~48 ~598 ~324 ~48 ~598 minecraft:light_gray_concrete replace
fill ~304 ~48 ~600 ~304 ~48 ~601 minecraft:light_gray_concrete replace
fill ~303 ~48 ~602 ~348 ~48 ~602 minecraft:light_gray_concrete replace
fill ~100 ~48 ~604 ~100 ~48 ~605 minecraft:light_gray_concrete replace
fill ~99 ~48 ~606 ~102 ~48 ~606 minecraft:light_gray_concrete replace
fill ~121 ~48 ~608 ~121 ~48 ~609 minecraft:light_gray_concrete replace
fill ~120 ~48 ~610 ~126 ~48 ~610 minecraft:light_gray_concrete replace
fill ~142 ~48 ~612 ~142 ~48 ~613 minecraft:light_gray_concrete replace
fill ~141 ~48 ~614 ~150 ~48 ~614 minecraft:light_gray_concrete replace
fill ~166 ~48 ~616 ~166 ~48 ~617 minecraft:light_gray_concrete replace
fill ~165 ~48 ~618 ~177 ~48 ~618 minecraft:light_gray_concrete replace
fill ~187 ~48 ~620 ~187 ~48 ~621 minecraft:light_gray_concrete replace
fill ~186 ~48 ~622 ~201 ~48 ~622 minecraft:light_gray_concrete replace
fill ~211 ~48 ~624 ~211 ~48 ~625 minecraft:light_gray_concrete replace
fill ~210 ~48 ~626 ~228 ~48 ~626 minecraft:light_gray_concrete replace
fill ~244 ~48 ~628 ~244 ~48 ~629 minecraft:light_gray_concrete replace
fill ~243 ~48 ~630 ~267 ~48 ~630 minecraft:light_gray_concrete replace
fill ~256 ~48 ~632 ~256 ~48 ~633 minecraft:light_gray_concrete replace
fill ~255 ~48 ~634 ~279 ~48 ~634 minecraft:light_gray_concrete replace
fill ~295 ~48 ~636 ~295 ~48 ~637 minecraft:light_gray_concrete replace
fill ~294 ~48 ~638 ~339 ~48 ~638 minecraft:light_gray_concrete replace
fill ~151 ~48 ~640 ~151 ~48 ~641 minecraft:light_gray_concrete replace
fill ~150 ~48 ~642 ~159 ~48 ~642 minecraft:light_gray_concrete replace
fill ~322 ~48 ~644 ~322 ~48 ~645 minecraft:light_gray_concrete replace
fill ~321 ~48 ~646 ~366 ~48 ~646 minecraft:light_gray_concrete replace
fill ~97 ~48 ~648 ~97 ~48 ~649 minecraft:light_gray_concrete replace
fill ~96 ~48 ~650 ~99 ~48 ~650 minecraft:light_gray_concrete replace
fill ~298 ~48 ~652 ~298 ~48 ~653 minecraft:light_gray_concrete replace
fill ~297 ~48 ~654 ~342 ~48 ~654 minecraft:light_gray_concrete replace
fill ~319 ~48 ~656 ~319 ~48 ~657 minecraft:light_gray_concrete replace
fill ~318 ~48 ~658 ~363 ~48 ~658 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~32 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~276 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~291 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~293 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~36 minecraft:light_gray_concrete replace
setblock ~276 ~49 ~38 minecraft:light_gray_concrete replace
setblock ~278 ~49 ~38 minecraft:light_gray_concrete replace
setblock ~214 ~49 ~40 minecraft:light_gray_concrete replace
setblock ~225 ~49 ~42 minecraft:light_gray_concrete replace
setblock ~227 ~49 ~42 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~44 minecraft:light_gray_concrete replace
setblock ~263 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~279 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~281 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~297 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~48 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~264 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~279 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~281 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~56 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~267 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~282 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~284 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~72 minecraft:light_gray_concrete replace
setblock ~275 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~277 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~292 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~294 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~309 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~311 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~94 ~49 ~240 minecraft:light_gray_concrete replace
setblock ~94 ~49 ~244 minecraft:light_gray_concrete replace
setblock ~118 ~49 ~260 minecraft:light_gray_concrete replace
setblock ~118 ~49 ~264 minecraft:light_gray_concrete replace
setblock ~139 ~49 ~276 minecraft:light_gray_concrete replace
setblock ~139 ~49 ~280 minecraft:light_gray_concrete replace
setblock ~157 ~49 ~288 minecraft:light_gray_concrete replace
setblock ~157 ~49 ~292 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~296 minecraft:light_gray_concrete replace
setblock ~272 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~291 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~300 minecraft:light_gray_concrete replace
setblock ~267 ~49 ~302 minecraft:light_gray_concrete replace
setblock ~269 ~49 ~302 minecraft:light_gray_concrete replace
setblock ~214 ~49 ~304 minecraft:light_gray_concrete replace
setblock ~217 ~49 ~306 minecraft:light_gray_concrete replace
setblock ~219 ~49 ~306 minecraft:light_gray_concrete replace
setblock ~193 ~49 ~308 minecraft:light_gray_concrete replace
setblock ~172 ~49 ~312 minecraft:light_gray_concrete replace
setblock ~172 ~49 ~316 minecraft:light_gray_concrete replace
setblock ~193 ~49 ~324 minecraft:light_gray_concrete replace
setblock ~201 ~49 ~326 minecraft:light_gray_concrete replace
setblock ~203 ~49 ~326 minecraft:light_gray_concrete replace
setblock ~196 ~49 ~336 minecraft:light_gray_concrete replace
setblock ~204 ~49 ~338 minecraft:light_gray_concrete replace
setblock ~206 ~49 ~338 minecraft:light_gray_concrete replace
setblock ~214 ~49 ~340 minecraft:light_gray_concrete replace
setblock ~228 ~49 ~342 minecraft:light_gray_concrete replace
setblock ~230 ~49 ~342 minecraft:light_gray_concrete replace
setblock ~217 ~49 ~352 minecraft:light_gray_concrete replace
setblock ~231 ~49 ~354 minecraft:light_gray_concrete replace
setblock ~233 ~49 ~354 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~360 minecraft:light_gray_concrete replace
setblock ~263 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~280 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~282 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~297 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~299 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~364 minecraft:light_gray_concrete replace
setblock ~266 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~268 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~283 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~285 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~300 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~302 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~372 minecraft:light_gray_concrete replace
setblock ~268 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~270 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~285 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~287 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~235 ~49 ~380 minecraft:light_gray_concrete replace
setblock ~249 ~49 ~382 minecraft:light_gray_concrete replace
setblock ~251 ~49 ~382 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~384 minecraft:light_gray_concrete replace
setblock ~290 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~292 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~307 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~309 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~324 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~326 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~310 ~49 ~388 minecraft:light_gray_concrete replace
setblock ~311 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~313 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~328 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~330 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~345 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~347 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~277 ~49 ~392 minecraft:light_gray_concrete replace
setblock ~278 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~280 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~297 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~312 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~314 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~301 ~49 ~396 minecraft:light_gray_concrete replace
setblock ~302 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~304 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~319 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~321 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~336 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~338 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~271 ~49 ~400 minecraft:light_gray_concrete replace
setblock ~272 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~291 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~306 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~308 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~91 ~49 ~408 minecraft:light_gray_concrete replace
setblock ~115 ~49 ~412 minecraft:light_gray_concrete replace
setblock ~136 ~49 ~416 minecraft:light_gray_concrete replace
setblock ~163 ~49 ~420 minecraft:light_gray_concrete replace
setblock ~165 ~49 ~422 minecraft:light_gray_concrete replace
setblock ~167 ~49 ~422 minecraft:light_gray_concrete replace
setblock ~184 ~49 ~424 minecraft:light_gray_concrete replace
setblock ~189 ~49 ~426 minecraft:light_gray_concrete replace
setblock ~191 ~49 ~426 minecraft:light_gray_concrete replace
setblock ~208 ~49 ~428 minecraft:light_gray_concrete replace
setblock ~216 ~49 ~430 minecraft:light_gray_concrete replace
setblock ~218 ~49 ~430 minecraft:light_gray_concrete replace
setblock ~232 ~49 ~432 minecraft:light_gray_concrete replace
setblock ~246 ~49 ~434 minecraft:light_gray_concrete replace
setblock ~248 ~49 ~434 minecraft:light_gray_concrete replace
setblock ~253 ~49 ~436 minecraft:light_gray_concrete replace
setblock ~267 ~49 ~438 minecraft:light_gray_concrete replace
setblock ~269 ~49 ~438 minecraft:light_gray_concrete replace
setblock ~268 ~49 ~440 minecraft:light_gray_concrete replace
setblock ~269 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~271 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~286 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~288 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~303 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~305 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~88 ~49 ~444 minecraft:light_gray_concrete replace
setblock ~112 ~49 ~448 minecraft:light_gray_concrete replace
setblock ~133 ~49 ~452 minecraft:light_gray_concrete replace
setblock ~160 ~49 ~456 minecraft:light_gray_concrete replace
setblock ~162 ~49 ~458 minecraft:light_gray_concrete replace
setblock ~164 ~49 ~458 minecraft:light_gray_concrete replace
setblock ~181 ~49 ~460 minecraft:light_gray_concrete replace
setblock ~186 ~49 ~462 minecraft:light_gray_concrete replace
setblock ~188 ~49 ~462 minecraft:light_gray_concrete replace
setblock ~205 ~49 ~464 minecraft:light_gray_concrete replace
setblock ~213 ~49 ~466 minecraft:light_gray_concrete replace
setblock ~215 ~49 ~466 minecraft:light_gray_concrete replace
setblock ~229 ~49 ~468 minecraft:light_gray_concrete replace
setblock ~243 ~49 ~470 minecraft:light_gray_concrete replace
setblock ~245 ~49 ~470 minecraft:light_gray_concrete replace
setblock ~250 ~49 ~472 minecraft:light_gray_concrete replace
setblock ~264 ~49 ~474 minecraft:light_gray_concrete replace
setblock ~266 ~49 ~474 minecraft:light_gray_concrete replace
setblock ~292 ~49 ~476 minecraft:light_gray_concrete replace
setblock ~293 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~310 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~312 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~327 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~329 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~316 ~49 ~480 minecraft:light_gray_concrete replace
setblock ~317 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~319 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~334 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~336 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~351 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~353 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~85 ~49 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~49 ~488 minecraft:light_gray_concrete replace
setblock ~130 ~49 ~492 minecraft:light_gray_concrete replace
setblock ~154 ~49 ~496 minecraft:light_gray_concrete replace
setblock ~178 ~49 ~500 minecraft:light_gray_concrete replace
setblock ~183 ~49 ~502 minecraft:light_gray_concrete replace
setblock ~185 ~49 ~502 minecraft:light_gray_concrete replace
setblock ~202 ~49 ~504 minecraft:light_gray_concrete replace
setblock ~210 ~49 ~506 minecraft:light_gray_concrete replace
setblock ~212 ~49 ~506 minecraft:light_gray_concrete replace
setblock ~226 ~49 ~508 minecraft:light_gray_concrete replace
setblock ~240 ~49 ~510 minecraft:light_gray_concrete replace
setblock ~242 ~49 ~510 minecraft:light_gray_concrete replace
setblock ~247 ~49 ~512 minecraft:light_gray_concrete replace
setblock ~261 ~49 ~514 minecraft:light_gray_concrete replace
setblock ~263 ~49 ~514 minecraft:light_gray_concrete replace
setblock ~286 ~49 ~516 minecraft:light_gray_concrete replace
setblock ~287 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~304 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~306 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~321 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~323 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~313 ~49 ~520 minecraft:light_gray_concrete replace
setblock ~314 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~316 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~331 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~333 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~348 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~350 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~82 ~49 ~524 minecraft:light_gray_concrete replace
setblock ~106 ~49 ~528 minecraft:light_gray_concrete replace
setblock ~127 ~49 ~532 minecraft:light_gray_concrete replace
setblock ~148 ~49 ~536 minecraft:light_gray_concrete replace
setblock ~175 ~49 ~540 minecraft:light_gray_concrete replace
setblock ~180 ~49 ~542 minecraft:light_gray_concrete replace
setblock ~182 ~49 ~542 minecraft:light_gray_concrete replace
setblock ~199 ~49 ~544 minecraft:light_gray_concrete replace
setblock ~207 ~49 ~546 minecraft:light_gray_concrete replace
setblock ~209 ~49 ~546 minecraft:light_gray_concrete replace
setblock ~223 ~49 ~548 minecraft:light_gray_concrete replace
setblock ~237 ~49 ~550 minecraft:light_gray_concrete replace
setblock ~239 ~49 ~550 minecraft:light_gray_concrete replace
setblock ~241 ~49 ~552 minecraft:light_gray_concrete replace
setblock ~255 ~49 ~554 minecraft:light_gray_concrete replace
setblock ~257 ~49 ~554 minecraft:light_gray_concrete replace
setblock ~283 ~49 ~556 minecraft:light_gray_concrete replace
setblock ~284 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~286 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~301 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~303 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~318 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~320 ~49 ~558 minecraft:light_gray_concrete replace
setblock ~307 ~49 ~560 minecraft:light_gray_concrete replace
setblock ~308 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~310 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~325 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~327 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~342 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~344 ~49 ~562 minecraft:light_gray_concrete replace
setblock ~79 ~49 ~564 minecraft:light_gray_concrete replace
setblock ~103 ~49 ~568 minecraft:light_gray_concrete replace
setblock ~124 ~49 ~572 minecraft:light_gray_concrete replace
setblock ~145 ~49 ~576 minecraft:light_gray_concrete replace
setblock ~169 ~49 ~580 minecraft:light_gray_concrete replace
setblock ~171 ~49 ~582 minecraft:light_gray_concrete replace
setblock ~173 ~49 ~582 minecraft:light_gray_concrete replace
setblock ~190 ~49 ~584 minecraft:light_gray_concrete replace
setblock ~195 ~49 ~586 minecraft:light_gray_concrete replace
setblock ~197 ~49 ~586 minecraft:light_gray_concrete replace
setblock ~220 ~49 ~588 minecraft:light_gray_concrete replace
setblock ~234 ~49 ~590 minecraft:light_gray_concrete replace
setblock ~236 ~49 ~590 minecraft:light_gray_concrete replace
setblock ~238 ~49 ~592 minecraft:light_gray_concrete replace
setblock ~252 ~49 ~594 minecraft:light_gray_concrete replace
setblock ~254 ~49 ~594 minecraft:light_gray_concrete replace
setblock ~280 ~49 ~596 minecraft:light_gray_concrete replace
setblock ~281 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~283 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~298 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~300 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~315 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~317 ~49 ~598 minecraft:light_gray_concrete replace
setblock ~304 ~49 ~600 minecraft:light_gray_concrete replace
setblock ~305 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~307 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~322 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~324 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~339 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~341 ~49 ~602 minecraft:light_gray_concrete replace
setblock ~100 ~49 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~49 ~608 minecraft:light_gray_concrete replace
setblock ~142 ~49 ~612 minecraft:light_gray_concrete replace
setblock ~166 ~49 ~616 minecraft:light_gray_concrete replace
setblock ~168 ~49 ~618 minecraft:light_gray_concrete replace
setblock ~170 ~49 ~618 minecraft:light_gray_concrete replace
setblock ~187 ~49 ~620 minecraft:light_gray_concrete replace
setblock ~192 ~49 ~622 minecraft:light_gray_concrete replace
setblock ~194 ~49 ~622 minecraft:light_gray_concrete replace
setblock ~211 ~49 ~624 minecraft:light_gray_concrete replace
setblock ~219 ~49 ~626 minecraft:light_gray_concrete replace
setblock ~221 ~49 ~626 minecraft:light_gray_concrete replace
setblock ~244 ~49 ~628 minecraft:light_gray_concrete replace
setblock ~258 ~49 ~630 minecraft:light_gray_concrete replace
setblock ~260 ~49 ~630 minecraft:light_gray_concrete replace
setblock ~256 ~49 ~632 minecraft:light_gray_concrete replace
setblock ~270 ~49 ~634 minecraft:light_gray_concrete replace
setblock ~272 ~49 ~634 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~636 minecraft:light_gray_concrete replace
setblock ~296 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~298 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~313 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~315 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~330 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~332 ~49 ~638 minecraft:light_gray_concrete replace
setblock ~151 ~49 ~640 minecraft:light_gray_concrete replace
setblock ~322 ~49 ~644 minecraft:light_gray_concrete replace
setblock ~323 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~325 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~340 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~342 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~357 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~359 ~49 ~646 minecraft:light_gray_concrete replace
setblock ~97 ~49 ~648 minecraft:light_gray_concrete replace
setblock ~298 ~49 ~652 minecraft:light_gray_concrete replace
setblock ~299 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~301 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~316 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~318 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~333 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~335 ~49 ~654 minecraft:light_gray_concrete replace
setblock ~319 ~49 ~656 minecraft:light_gray_concrete replace
setblock ~320 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~322 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~337 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~339 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~354 ~49 ~658 minecraft:light_gray_concrete replace
setblock ~356 ~49 ~658 minecraft:light_gray_concrete replace
fill ~261 ~50 ~32 ~261 ~50 ~364 minecraft:light_gray_concrete replace
fill ~258 ~50 ~36 ~258 ~50 ~376 minecraft:light_gray_concrete replace
fill ~213 ~50 ~40 ~213 ~50 ~344 minecraft:light_gray_concrete replace
fill ~273 ~50 ~72 ~273 ~50 ~76 minecraft:light_gray_concrete replace
fill ~93 ~50 ~240 ~93 ~50 ~248 minecraft:light_gray_concrete replace
fill ~117 ~50 ~260 ~117 ~50 ~268 minecraft:light_gray_concrete replace
fill ~138 ~50 ~276 ~138 ~50 ~284 minecraft:light_gray_concrete replace
fill ~156 ~50 ~288 ~156 ~50 ~296 minecraft:light_gray_concrete replace
fill ~192 ~50 ~308 ~192 ~50 ~328 minecraft:light_gray_concrete replace
fill ~171 ~50 ~312 ~171 ~50 ~320 minecraft:light_gray_concrete replace
fill ~195 ~50 ~336 ~195 ~50 ~340 minecraft:light_gray_concrete replace
fill ~216 ~50 ~352 ~216 ~50 ~356 minecraft:light_gray_concrete replace
fill ~264 ~50 ~364 ~264 ~50 ~368 minecraft:light_gray_concrete replace
fill ~234 ~50 ~380 ~234 ~50 ~384 minecraft:light_gray_concrete replace
fill ~288 ~50 ~384 ~288 ~50 ~388 minecraft:light_gray_concrete replace
fill ~309 ~50 ~388 ~309 ~50 ~392 minecraft:light_gray_concrete replace
fill ~276 ~50 ~392 ~276 ~50 ~396 minecraft:light_gray_concrete replace
fill ~300 ~50 ~396 ~300 ~50 ~400 minecraft:light_gray_concrete replace
fill ~270 ~50 ~400 ~270 ~50 ~404 minecraft:light_gray_concrete replace
fill ~90 ~50 ~408 ~90 ~50 ~412 minecraft:light_gray_concrete replace
fill ~114 ~50 ~412 ~114 ~50 ~416 minecraft:light_gray_concrete replace
fill ~135 ~50 ~416 ~135 ~50 ~420 minecraft:light_gray_concrete replace
fill ~162 ~50 ~420 ~162 ~50 ~424 minecraft:light_gray_concrete replace
fill ~183 ~50 ~424 ~183 ~50 ~428 minecraft:light_gray_concrete replace
fill ~207 ~50 ~428 ~207 ~50 ~432 minecraft:light_gray_concrete replace
fill ~231 ~50 ~432 ~231 ~50 ~436 minecraft:light_gray_concrete replace
fill ~252 ~50 ~436 ~252 ~50 ~440 minecraft:light_gray_concrete replace
fill ~267 ~50 ~440 ~267 ~50 ~444 minecraft:light_gray_concrete replace
fill ~87 ~50 ~444 ~87 ~50 ~448 minecraft:light_gray_concrete replace
fill ~111 ~50 ~448 ~111 ~50 ~452 minecraft:light_gray_concrete replace
fill ~132 ~50 ~452 ~132 ~50 ~456 minecraft:light_gray_concrete replace
fill ~159 ~50 ~456 ~159 ~50 ~460 minecraft:light_gray_concrete replace
fill ~180 ~50 ~460 ~180 ~50 ~464 minecraft:light_gray_concrete replace
fill ~204 ~50 ~464 ~204 ~50 ~468 minecraft:light_gray_concrete replace
fill ~228 ~50 ~468 ~228 ~50 ~472 minecraft:light_gray_concrete replace
fill ~249 ~50 ~472 ~249 ~50 ~476 minecraft:light_gray_concrete replace
fill ~291 ~50 ~476 ~291 ~50 ~480 minecraft:light_gray_concrete replace
fill ~315 ~50 ~480 ~315 ~50 ~484 minecraft:light_gray_concrete replace
fill ~84 ~50 ~484 ~84 ~50 ~488 minecraft:light_gray_concrete replace
fill ~108 ~50 ~488 ~108 ~50 ~492 minecraft:light_gray_concrete replace
fill ~129 ~50 ~492 ~129 ~50 ~496 minecraft:light_gray_concrete replace
fill ~153 ~50 ~496 ~153 ~50 ~500 minecraft:light_gray_concrete replace
fill ~177 ~50 ~500 ~177 ~50 ~504 minecraft:light_gray_concrete replace
fill ~201 ~50 ~504 ~201 ~50 ~508 minecraft:light_gray_concrete replace
fill ~225 ~50 ~508 ~225 ~50 ~512 minecraft:light_gray_concrete replace
fill ~246 ~50 ~512 ~246 ~50 ~516 minecraft:light_gray_concrete replace
fill ~285 ~50 ~516 ~285 ~50 ~520 minecraft:light_gray_concrete replace
fill ~312 ~50 ~520 ~312 ~50 ~524 minecraft:light_gray_concrete replace
fill ~81 ~50 ~524 ~81 ~50 ~528 minecraft:light_gray_concrete replace
fill ~105 ~50 ~528 ~105 ~50 ~532 minecraft:light_gray_concrete replace
fill ~126 ~50 ~532 ~126 ~50 ~536 minecraft:light_gray_concrete replace
fill ~147 ~50 ~536 ~147 ~50 ~540 minecraft:light_gray_concrete replace
fill ~174 ~50 ~540 ~174 ~50 ~544 minecraft:light_gray_concrete replace
fill ~198 ~50 ~544 ~198 ~50 ~548 minecraft:light_gray_concrete replace
fill ~222 ~50 ~548 ~222 ~50 ~552 minecraft:light_gray_concrete replace
fill ~240 ~50 ~552 ~240 ~50 ~556 minecraft:light_gray_concrete replace
fill ~282 ~50 ~556 ~282 ~50 ~560 minecraft:light_gray_concrete replace
fill ~306 ~50 ~560 ~306 ~50 ~564 minecraft:light_gray_concrete replace
fill ~78 ~50 ~564 ~78 ~50 ~568 minecraft:light_gray_concrete replace
fill ~102 ~50 ~568 ~102 ~50 ~572 minecraft:light_gray_concrete replace
fill ~123 ~50 ~572 ~123 ~50 ~576 minecraft:light_gray_concrete replace
fill ~144 ~50 ~576 ~144 ~50 ~580 minecraft:light_gray_concrete replace
fill ~168 ~50 ~580 ~168 ~50 ~584 minecraft:light_gray_concrete replace
fill ~189 ~50 ~584 ~189 ~50 ~588 minecraft:light_gray_concrete replace
fill ~219 ~50 ~588 ~219 ~50 ~592 minecraft:light_gray_concrete replace
fill ~237 ~50 ~592 ~237 ~50 ~596 minecraft:light_gray_concrete replace
fill ~279 ~50 ~596 ~279 ~50 ~600 minecraft:light_gray_concrete replace
fill ~303 ~50 ~600 ~303 ~50 ~604 minecraft:light_gray_concrete replace
fill ~99 ~50 ~604 ~99 ~50 ~608 minecraft:light_gray_concrete replace
fill ~120 ~50 ~608 ~120 ~50 ~612 minecraft:light_gray_concrete replace
fill ~141 ~50 ~612 ~141 ~50 ~616 minecraft:light_gray_concrete replace
fill ~165 ~50 ~616 ~165 ~50 ~620 minecraft:light_gray_concrete replace
fill ~186 ~50 ~620 ~186 ~50 ~624 minecraft:light_gray_concrete replace
fill ~210 ~50 ~624 ~210 ~50 ~628 minecraft:light_gray_concrete replace
fill ~243 ~50 ~628 ~243 ~50 ~632 minecraft:light_gray_concrete replace
fill ~255 ~50 ~632 ~255 ~50 ~636 minecraft:light_gray_concrete replace
fill ~294 ~50 ~636 ~294 ~50 ~640 minecraft:light_gray_concrete replace
fill ~150 ~50 ~640 ~150 ~50 ~644 minecraft:light_gray_concrete replace
fill ~321 ~50 ~644 ~321 ~50 ~648 minecraft:light_gray_concrete replace
fill ~96 ~50 ~648 ~96 ~50 ~652 minecraft:light_gray_concrete replace
fill ~297 ~50 ~652 ~297 ~50 ~656 minecraft:light_gray_concrete replace
fill ~318 ~50 ~656 ~318 ~50 ~660 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~32 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~36 minecraft:light_gray_concrete replace
setblock ~214 ~51 ~40 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~44 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~48 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~53 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~55 minecraft:light_gray_concrete replace
