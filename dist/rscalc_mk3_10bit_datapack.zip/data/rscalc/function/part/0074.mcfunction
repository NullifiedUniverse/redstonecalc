setblock ~256 ~38 ~324 minecraft:redstone_wire replace
setblock ~202 ~38 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~38 ~332 minecraft:redstone_wire replace
setblock ~202 ~38 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~38 ~336 minecraft:redstone_wire replace
setblock ~259 ~38 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~38 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~38 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~38 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~38 ~348 minecraft:redstone_wire replace
setblock ~226 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~38 ~352 minecraft:redstone_wire replace
setblock ~316 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~38 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~38 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~38 ~364 minecraft:redstone_wire replace
setblock ~331 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~38 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~38 ~372 minecraft:redstone_wire replace
setblock ~313 ~38 ~376 minecraft:redstone_wire replace
setblock ~316 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~38 ~380 minecraft:redstone_wire replace
setblock ~340 ~38 ~384 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~38 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~38 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~364 ~38 ~392 minecraft:redstone_wire replace
setblock ~349 ~38 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~385 ~38 ~400 minecraft:redstone_wire replace
setblock ~352 ~38 ~404 minecraft:redstone_wire replace
setblock ~346 ~38 ~408 minecraft:redstone_wire replace
setblock ~349 ~38 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~38 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~38 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~38 ~416 minecraft:redstone_wire replace
setblock ~118 ~38 ~420 minecraft:redstone_wire replace
setblock ~145 ~38 ~424 minecraft:redstone_wire replace
setblock ~193 ~38 ~428 minecraft:redstone_wire replace
setblock ~214 ~38 ~432 minecraft:redstone_wire replace
setblock ~238 ~38 ~436 minecraft:redstone_wire replace
setblock ~283 ~38 ~440 minecraft:redstone_wire replace
setblock ~307 ~38 ~444 minecraft:redstone_wire replace
setblock ~343 ~38 ~448 minecraft:redstone_wire replace
setblock ~88 ~38 ~452 minecraft:redstone_wire replace
setblock ~115 ~38 ~456 minecraft:redstone_wire replace
setblock ~142 ~38 ~460 minecraft:redstone_wire replace
setblock ~190 ~38 ~464 minecraft:redstone_wire replace
setblock ~211 ~38 ~468 minecraft:redstone_wire replace
setblock ~235 ~38 ~472 minecraft:redstone_wire replace
setblock ~277 ~38 ~476 minecraft:redstone_wire replace
setblock ~304 ~38 ~480 minecraft:redstone_wire replace
setblock ~367 ~38 ~484 minecraft:redstone_wire replace
setblock ~391 ~38 ~488 minecraft:redstone_wire replace
setblock ~85 ~38 ~492 minecraft:redstone_wire replace
setblock ~112 ~38 ~496 minecraft:redstone_wire replace
setblock ~139 ~38 ~500 minecraft:redstone_wire replace
setblock ~172 ~38 ~504 minecraft:redstone_wire replace
setblock ~208 ~38 ~508 minecraft:redstone_wire replace
setblock ~232 ~38 ~512 minecraft:redstone_wire replace
setblock ~274 ~38 ~516 minecraft:redstone_wire replace
setblock ~301 ~38 ~520 minecraft:redstone_wire replace
setblock ~361 ~38 ~524 minecraft:redstone_wire replace
setblock ~388 ~38 ~528 minecraft:redstone_wire replace
setblock ~82 ~38 ~532 minecraft:redstone_wire replace
setblock ~109 ~38 ~536 minecraft:redstone_wire replace
setblock ~136 ~38 ~540 minecraft:redstone_wire replace
setblock ~166 ~38 ~544 minecraft:redstone_wire replace
setblock ~205 ~38 ~548 minecraft:redstone_wire replace
setblock ~229 ~38 ~552 minecraft:redstone_wire replace
setblock ~271 ~38 ~556 minecraft:redstone_wire replace
setblock ~292 ~38 ~560 minecraft:redstone_wire replace
setblock ~358 ~38 ~564 minecraft:redstone_wire replace
setblock ~382 ~38 ~568 minecraft:redstone_wire replace
setblock ~79 ~38 ~572 minecraft:redstone_wire replace
setblock ~106 ~38 ~576 minecraft:redstone_wire replace
setblock ~133 ~38 ~580 minecraft:redstone_wire replace
setblock ~163 ~38 ~584 minecraft:redstone_wire replace
setblock ~199 ~38 ~588 minecraft:redstone_wire replace
setblock ~220 ~38 ~592 minecraft:redstone_wire replace
setblock ~268 ~38 ~596 minecraft:redstone_wire replace
setblock ~289 ~38 ~600 minecraft:redstone_wire replace
setblock ~355 ~38 ~604 minecraft:redstone_wire replace
setblock ~379 ~38 ~608 minecraft:redstone_wire replace
setblock ~103 ~38 ~612 minecraft:redstone_wire replace
setblock ~130 ~38 ~616 minecraft:redstone_wire replace
setblock ~160 ~38 ~620 minecraft:redstone_wire replace
setblock ~196 ~38 ~624 minecraft:redstone_wire replace
setblock ~217 ~38 ~628 minecraft:redstone_wire replace
setblock ~241 ~38 ~632 minecraft:redstone_wire replace
setblock ~295 ~38 ~636 minecraft:redstone_wire replace
setblock ~310 ~38 ~640 minecraft:redstone_wire replace
setblock ~370 ~38 ~644 minecraft:redstone_wire replace
setblock ~169 ~38 ~648 minecraft:redstone_wire replace
setblock ~397 ~38 ~652 minecraft:redstone_wire replace
setblock ~100 ~38 ~656 minecraft:redstone_wire replace
setblock ~373 ~38 ~660 minecraft:redstone_wire replace
setblock ~394 ~38 ~664 minecraft:redstone_wire replace
setblock ~243 ~39 ~4 minecraft:redstone_wire replace
setblock ~243 ~39 ~6 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~8 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~8 ~243 ~39 ~20 minecraft:redstone_wire replace
fill ~174 ~39 ~10 ~174 ~39 ~20 minecraft:redstone_wire replace
setblock ~147 ~39 ~12 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~39 ~14 ~147 ~39 ~20 minecraft:redstone_wire replace
fill ~246 ~39 ~16 ~246 ~39 ~18 minecraft:redstone_wire replace
fill ~177 ~39 ~20 ~177 ~39 ~24 minecraft:redstone_wire replace
setblock ~246 ~39 ~20 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~22 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~22 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~22 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~22 ~246 ~39 ~34 minecraft:redstone_wire replace
fill ~147 ~39 ~24 ~147 ~39 ~36 minecraft:redstone_wire replace
fill ~174 ~39 ~24 ~174 ~39 ~36 minecraft:redstone_wire replace
fill ~243 ~39 ~24 ~243 ~39 ~36 minecraft:redstone_wire replace
setblock ~177 ~39 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~39 ~26 ~177 ~39 ~38 minecraft:redstone_wire replace
fill ~249 ~39 ~28 ~249 ~39 ~32 minecraft:redstone_wire replace
setblock ~249 ~39 ~34 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~246 ~39 ~36 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~36 ~249 ~39 ~48 minecraft:redstone_wire replace
setblock ~330 ~39 ~36 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~38 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~38 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~38 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~38 ~246 ~39 ~50 minecraft:redstone_wire replace
fill ~330 ~39 ~38 ~330 ~39 ~48 minecraft:redstone_wire replace
fill ~147 ~39 ~40 ~147 ~39 ~52 minecraft:redstone_wire replace
fill ~174 ~39 ~40 ~174 ~39 ~52 minecraft:redstone_wire replace
setblock ~177 ~39 ~40 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~40 ~243 ~39 ~52 minecraft:redstone_wire replace
fill ~315 ~39 ~40 ~315 ~39 ~42 minecraft:redstone_wire replace
fill ~177 ~39 ~42 ~177 ~39 ~54 minecraft:redstone_wire replace
fill ~258 ~39 ~44 ~258 ~39 ~50 minecraft:redstone_wire replace
setblock ~315 ~39 ~44 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~46 ~315 ~39 ~58 minecraft:redstone_wire replace
setblock ~333 ~39 ~48 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~330 ~39 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~249 ~39 ~50 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~50 ~330 ~39 ~62 minecraft:redstone_wire replace
fill ~333 ~39 ~50 ~333 ~39 ~60 minecraft:redstone_wire replace
setblock ~246 ~39 ~52 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~52 ~249 ~39 ~64 minecraft:redstone_wire replace
setblock ~258 ~39 ~52 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~39 ~52 ~318 ~39 ~58 minecraft:redstone_wire replace
setblock ~147 ~39 ~54 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~54 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~54 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~54 ~246 ~39 ~66 minecraft:redstone_wire replace
fill ~258 ~39 ~54 ~258 ~39 ~66 minecraft:redstone_wire replace
fill ~147 ~39 ~56 ~147 ~39 ~68 minecraft:redstone_wire replace
fill ~174 ~39 ~56 ~174 ~39 ~68 minecraft:redstone_wire replace
setblock ~177 ~39 ~56 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~56 ~243 ~39 ~68 minecraft:redstone_wire replace
fill ~177 ~39 ~58 ~177 ~39 ~70 minecraft:redstone_wire replace
setblock ~315 ~39 ~60 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~60 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~324 ~39 ~60 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~62 ~315 ~39 ~74 minecraft:redstone_wire replace
fill ~318 ~39 ~62 ~318 ~39 ~74 minecraft:redstone_wire replace
fill ~324 ~39 ~62 ~324 ~39 ~72 minecraft:redstone_wire replace
setblock ~333 ~39 ~62 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~330 ~39 ~64 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~64 ~333 ~39 ~76 minecraft:redstone_wire replace
setblock ~249 ~39 ~66 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~66 ~330 ~39 ~78 minecraft:redstone_wire replace
setblock ~246 ~39 ~68 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~68 ~249 ~39 ~80 minecraft:redstone_wire replace
setblock ~258 ~39 ~68 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~70 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~70 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~70 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~70 ~246 ~39 ~82 minecraft:redstone_wire replace
fill ~258 ~39 ~70 ~258 ~39 ~82 minecraft:redstone_wire replace
fill ~147 ~39 ~72 ~147 ~39 ~84 minecraft:redstone_wire replace
fill ~174 ~39 ~72 ~174 ~39 ~84 minecraft:redstone_wire replace
setblock ~177 ~39 ~72 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~72 ~243 ~39 ~84 minecraft:redstone_wire replace
fill ~177 ~39 ~74 ~177 ~39 ~86 minecraft:redstone_wire replace
setblock ~324 ~39 ~74 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~76 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~76 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~76 ~324 ~39 ~88 minecraft:redstone_wire replace
setblock ~348 ~39 ~76 minecraft:redstone_wire replace
setblock ~348 ~39 ~77 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~78 ~315 ~39 ~90 minecraft:redstone_wire replace
fill ~318 ~39 ~78 ~318 ~39 ~90 minecraft:redstone_wire replace
setblock ~333 ~39 ~78 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~78 ~348 ~39 ~90 minecraft:redstone_wire replace
setblock ~330 ~39 ~80 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~80 ~333 ~39 ~92 minecraft:redstone_wire replace
setblock ~249 ~39 ~82 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~82 ~330 ~39 ~94 minecraft:redstone_wire replace
setblock ~246 ~39 ~84 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~84 ~249 ~39 ~96 minecraft:redstone_wire replace
setblock ~258 ~39 ~84 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~86 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~86 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~86 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~86 ~246 ~39 ~98 minecraft:redstone_wire replace
fill ~258 ~39 ~86 ~258 ~39 ~98 minecraft:redstone_wire replace
fill ~147 ~39 ~88 ~147 ~39 ~100 minecraft:redstone_wire replace
fill ~174 ~39 ~88 ~174 ~39 ~100 minecraft:redstone_wire replace
setblock ~177 ~39 ~88 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~88 ~243 ~39 ~100 minecraft:redstone_wire replace
fill ~177 ~39 ~90 ~177 ~39 ~102 minecraft:redstone_wire replace
setblock ~324 ~39 ~90 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~92 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~92 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~92 ~324 ~39 ~104 minecraft:redstone_wire replace
setblock ~348 ~39 ~92 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~94 ~315 ~39 ~106 minecraft:redstone_wire replace
fill ~318 ~39 ~94 ~318 ~39 ~106 minecraft:redstone_wire replace
setblock ~333 ~39 ~94 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~94 ~348 ~39 ~106 minecraft:redstone_wire replace
setblock ~330 ~39 ~96 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~96 ~333 ~39 ~108 minecraft:redstone_wire replace
setblock ~249 ~39 ~98 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~98 ~330 ~39 ~110 minecraft:redstone_wire replace
setblock ~246 ~39 ~100 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~100 ~249 ~39 ~112 minecraft:redstone_wire replace
setblock ~258 ~39 ~100 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~102 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~102 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~102 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~102 ~246 ~39 ~114 minecraft:redstone_wire replace
fill ~258 ~39 ~102 ~258 ~39 ~114 minecraft:redstone_wire replace
fill ~147 ~39 ~104 ~147 ~39 ~116 minecraft:redstone_wire replace
fill ~174 ~39 ~104 ~174 ~39 ~116 minecraft:redstone_wire replace
setblock ~177 ~39 ~104 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~104 ~243 ~39 ~116 minecraft:redstone_wire replace
fill ~177 ~39 ~106 ~177 ~39 ~118 minecraft:redstone_wire replace
setblock ~324 ~39 ~106 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~108 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~108 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~108 ~324 ~39 ~120 minecraft:redstone_wire replace
setblock ~348 ~39 ~108 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~110 ~315 ~39 ~122 minecraft:redstone_wire replace
fill ~318 ~39 ~110 ~318 ~39 ~122 minecraft:redstone_wire replace
setblock ~333 ~39 ~110 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~110 ~348 ~39 ~122 minecraft:redstone_wire replace
setblock ~330 ~39 ~112 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~112 ~333 ~39 ~124 minecraft:redstone_wire replace
setblock ~249 ~39 ~114 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~114 ~330 ~39 ~126 minecraft:redstone_wire replace
setblock ~246 ~39 ~116 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~116 ~249 ~39 ~128 minecraft:redstone_wire replace
setblock ~258 ~39 ~116 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~118 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~118 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~118 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~118 ~246 ~39 ~130 minecraft:redstone_wire replace
fill ~258 ~39 ~118 ~258 ~39 ~130 minecraft:redstone_wire replace
fill ~147 ~39 ~120 ~147 ~39 ~132 minecraft:redstone_wire replace
fill ~174 ~39 ~120 ~174 ~39 ~132 minecraft:redstone_wire replace
setblock ~177 ~39 ~120 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~120 ~243 ~39 ~132 minecraft:redstone_wire replace
fill ~177 ~39 ~122 ~177 ~39 ~134 minecraft:redstone_wire replace
setblock ~324 ~39 ~122 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~124 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~124 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~124 ~324 ~39 ~136 minecraft:redstone_wire replace
setblock ~348 ~39 ~124 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~126 ~315 ~39 ~138 minecraft:redstone_wire replace
fill ~318 ~39 ~126 ~318 ~39 ~138 minecraft:redstone_wire replace
setblock ~333 ~39 ~126 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~126 ~348 ~39 ~138 minecraft:redstone_wire replace
setblock ~330 ~39 ~128 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~128 ~333 ~39 ~140 minecraft:redstone_wire replace
setblock ~249 ~39 ~130 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~130 ~330 ~39 ~142 minecraft:redstone_wire replace
setblock ~246 ~39 ~132 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~132 ~249 ~39 ~144 minecraft:redstone_wire replace
setblock ~258 ~39 ~132 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~134 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~134 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~134 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~134 ~246 ~39 ~146 minecraft:redstone_wire replace
fill ~258 ~39 ~134 ~258 ~39 ~146 minecraft:redstone_wire replace
fill ~147 ~39 ~136 ~147 ~39 ~148 minecraft:redstone_wire replace
fill ~174 ~39 ~136 ~174 ~39 ~148 minecraft:redstone_wire replace
setblock ~177 ~39 ~136 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~136 ~243 ~39 ~148 minecraft:redstone_wire replace
fill ~177 ~39 ~138 ~177 ~39 ~150 minecraft:redstone_wire replace
setblock ~324 ~39 ~138 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~140 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~140 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~140 ~324 ~39 ~152 minecraft:redstone_wire replace
setblock ~348 ~39 ~140 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~142 ~315 ~39 ~154 minecraft:redstone_wire replace
fill ~318 ~39 ~142 ~318 ~39 ~154 minecraft:redstone_wire replace
setblock ~333 ~39 ~142 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~142 ~348 ~39 ~154 minecraft:redstone_wire replace
setblock ~330 ~39 ~144 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~144 ~333 ~39 ~156 minecraft:redstone_wire replace
setblock ~249 ~39 ~146 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~146 ~330 ~39 ~158 minecraft:redstone_wire replace
setblock ~246 ~39 ~148 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~148 ~249 ~39 ~160 minecraft:redstone_wire replace
setblock ~258 ~39 ~148 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~150 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~150 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~150 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~150 ~246 ~39 ~162 minecraft:redstone_wire replace
fill ~258 ~39 ~150 ~258 ~39 ~162 minecraft:redstone_wire replace
fill ~147 ~39 ~152 ~147 ~39 ~164 minecraft:redstone_wire replace
fill ~174 ~39 ~152 ~174 ~39 ~164 minecraft:redstone_wire replace
setblock ~177 ~39 ~152 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~152 ~243 ~39 ~164 minecraft:redstone_wire replace
fill ~177 ~39 ~154 ~177 ~39 ~166 minecraft:redstone_wire replace
setblock ~324 ~39 ~154 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~156 ~324 ~39 ~168 minecraft:redstone_wire replace
setblock ~348 ~39 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~158 ~315 ~39 ~170 minecraft:redstone_wire replace
fill ~318 ~39 ~158 ~318 ~39 ~170 minecraft:redstone_wire replace
setblock ~333 ~39 ~158 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~158 ~348 ~39 ~170 minecraft:redstone_wire replace
setblock ~330 ~39 ~160 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~160 ~333 ~39 ~172 minecraft:redstone_wire replace
setblock ~249 ~39 ~162 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~162 ~330 ~39 ~174 minecraft:redstone_wire replace
setblock ~246 ~39 ~164 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~164 ~249 ~39 ~176 minecraft:redstone_wire replace
setblock ~258 ~39 ~164 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~166 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~166 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~166 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~166 ~246 ~39 ~178 minecraft:redstone_wire replace
fill ~258 ~39 ~166 ~258 ~39 ~178 minecraft:redstone_wire replace
fill ~147 ~39 ~168 ~147 ~39 ~180 minecraft:redstone_wire replace
fill ~174 ~39 ~168 ~174 ~39 ~180 minecraft:redstone_wire replace
setblock ~177 ~39 ~168 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~168 ~243 ~39 ~180 minecraft:redstone_wire replace
fill ~177 ~39 ~170 ~177 ~39 ~182 minecraft:redstone_wire replace
setblock ~324 ~39 ~170 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~172 ~324 ~39 ~184 minecraft:redstone_wire replace
setblock ~348 ~39 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~174 ~315 ~39 ~186 minecraft:redstone_wire replace
fill ~318 ~39 ~174 ~318 ~39 ~186 minecraft:redstone_wire replace
setblock ~333 ~39 ~174 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~174 ~348 ~39 ~186 minecraft:redstone_wire replace
setblock ~330 ~39 ~176 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~176 ~333 ~39 ~188 minecraft:redstone_wire replace
setblock ~249 ~39 ~178 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~178 ~330 ~39 ~190 minecraft:redstone_wire replace
setblock ~246 ~39 ~180 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~180 ~249 ~39 ~192 minecraft:redstone_wire replace
setblock ~258 ~39 ~180 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~182 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~182 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~182 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~182 ~246 ~39 ~194 minecraft:redstone_wire replace
fill ~258 ~39 ~182 ~258 ~39 ~194 minecraft:redstone_wire replace
fill ~147 ~39 ~184 ~147 ~39 ~196 minecraft:redstone_wire replace
fill ~174 ~39 ~184 ~174 ~39 ~196 minecraft:redstone_wire replace
setblock ~177 ~39 ~184 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~184 ~243 ~39 ~196 minecraft:redstone_wire replace
fill ~177 ~39 ~186 ~177 ~39 ~198 minecraft:redstone_wire replace
setblock ~324 ~39 ~186 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~188 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~188 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~188 ~324 ~39 ~200 minecraft:redstone_wire replace
setblock ~348 ~39 ~188 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~190 ~315 ~39 ~202 minecraft:redstone_wire replace
fill ~318 ~39 ~190 ~318 ~39 ~202 minecraft:redstone_wire replace
setblock ~333 ~39 ~190 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~190 ~348 ~39 ~202 minecraft:redstone_wire replace
setblock ~330 ~39 ~192 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~192 ~333 ~39 ~204 minecraft:redstone_wire replace
setblock ~249 ~39 ~194 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~194 ~330 ~39 ~206 minecraft:redstone_wire replace
setblock ~246 ~39 ~196 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~196 ~249 ~39 ~208 minecraft:redstone_wire replace
setblock ~258 ~39 ~196 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~198 ~246 ~39 ~210 minecraft:redstone_wire replace
fill ~258 ~39 ~198 ~258 ~39 ~210 minecraft:redstone_wire replace
fill ~147 ~39 ~200 ~147 ~39 ~212 minecraft:redstone_wire replace
fill ~174 ~39 ~200 ~174 ~39 ~212 minecraft:redstone_wire replace
setblock ~177 ~39 ~200 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~200 ~243 ~39 ~212 minecraft:redstone_wire replace
fill ~177 ~39 ~202 ~177 ~39 ~214 minecraft:redstone_wire replace
setblock ~324 ~39 ~202 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~204 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~204 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~204 ~324 ~39 ~216 minecraft:redstone_wire replace
setblock ~348 ~39 ~204 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~206 ~315 ~39 ~218 minecraft:redstone_wire replace
fill ~318 ~39 ~206 ~318 ~39 ~218 minecraft:redstone_wire replace
setblock ~333 ~39 ~206 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~206 ~348 ~39 ~218 minecraft:redstone_wire replace
setblock ~330 ~39 ~208 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~208 ~333 ~39 ~220 minecraft:redstone_wire replace
setblock ~249 ~39 ~210 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~210 ~330 ~39 ~222 minecraft:redstone_wire replace
setblock ~246 ~39 ~212 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~212 ~249 ~39 ~224 minecraft:redstone_wire replace
setblock ~258 ~39 ~212 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~214 ~246 ~39 ~226 minecraft:redstone_wire replace
fill ~258 ~39 ~214 ~258 ~39 ~226 minecraft:redstone_wire replace
fill ~147 ~39 ~216 ~147 ~39 ~228 minecraft:redstone_wire replace
fill ~174 ~39 ~216 ~174 ~39 ~228 minecraft:redstone_wire replace
setblock ~177 ~39 ~216 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~216 ~243 ~39 ~228 minecraft:redstone_wire replace
fill ~177 ~39 ~218 ~177 ~39 ~230 minecraft:redstone_wire replace
setblock ~324 ~39 ~218 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~220 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~220 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~220 ~324 ~39 ~232 minecraft:redstone_wire replace
setblock ~348 ~39 ~220 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~222 ~315 ~39 ~234 minecraft:redstone_wire replace
fill ~318 ~39 ~222 ~318 ~39 ~234 minecraft:redstone_wire replace
setblock ~333 ~39 ~222 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~222 ~348 ~39 ~234 minecraft:redstone_wire replace
setblock ~330 ~39 ~224 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~224 ~333 ~39 ~236 minecraft:redstone_wire replace
setblock ~249 ~39 ~226 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~226 ~330 ~39 ~238 minecraft:redstone_wire replace
setblock ~246 ~39 ~228 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~228 ~249 ~39 ~240 minecraft:redstone_wire replace
setblock ~258 ~39 ~228 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~230 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~230 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~230 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~230 ~246 ~39 ~242 minecraft:redstone_wire replace
fill ~258 ~39 ~230 ~258 ~39 ~242 minecraft:redstone_wire replace
fill ~147 ~39 ~232 ~147 ~39 ~244 minecraft:redstone_wire replace
fill ~174 ~39 ~232 ~174 ~39 ~244 minecraft:redstone_wire replace
setblock ~177 ~39 ~232 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~232 ~243 ~39 ~244 minecraft:redstone_wire replace
fill ~177 ~39 ~234 ~177 ~39 ~246 minecraft:redstone_wire replace
setblock ~324 ~39 ~234 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~236 ~324 ~39 ~248 minecraft:redstone_wire replace
setblock ~348 ~39 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~238 ~315 ~39 ~250 minecraft:redstone_wire replace
fill ~318 ~39 ~238 ~318 ~39 ~250 minecraft:redstone_wire replace
setblock ~333 ~39 ~238 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~238 ~348 ~39 ~250 minecraft:redstone_wire replace
setblock ~330 ~39 ~240 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~240 ~333 ~39 ~252 minecraft:redstone_wire replace
setblock ~249 ~39 ~242 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~242 ~330 ~39 ~254 minecraft:redstone_wire replace
setblock ~246 ~39 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~244 ~249 ~39 ~256 minecraft:redstone_wire replace
setblock ~258 ~39 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~246 ~246 ~39 ~258 minecraft:redstone_wire replace
fill ~258 ~39 ~246 ~258 ~39 ~258 minecraft:redstone_wire replace
setblock ~93 ~39 ~248 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~39 ~248 ~147 ~39 ~260 minecraft:redstone_wire replace
fill ~174 ~39 ~248 ~174 ~39 ~260 minecraft:redstone_wire replace
setblock ~177 ~39 ~248 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~248 ~243 ~39 ~260 minecraft:redstone_wire replace
fill ~93 ~39 ~250 ~93 ~39 ~256 minecraft:redstone_wire replace
fill ~177 ~39 ~250 ~177 ~39 ~262 minecraft:redstone_wire replace
setblock ~324 ~39 ~250 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~39 ~252 minecraft:redstone_wire replace
setblock ~315 ~39 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~252 ~324 ~39 ~264 minecraft:redstone_wire replace
setblock ~348 ~39 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~39 ~254 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~254 ~315 ~39 ~266 minecraft:redstone_wire replace
fill ~318 ~39 ~254 ~318 ~39 ~266 minecraft:redstone_wire replace
setblock ~333 ~39 ~254 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~254 ~348 ~39 ~266 minecraft:redstone_wire replace
fill ~123 ~39 ~256 ~123 ~39 ~268 minecraft:redstone_wire replace
fill ~252 ~39 ~256 ~252 ~39 ~262 minecraft:redstone_wire replace
setblock ~330 ~39 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~256 ~333 ~39 ~268 minecraft:redstone_wire replace
setblock ~93 ~39 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~249 ~39 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~258 ~330 ~39 ~270 minecraft:redstone_wire replace
fill ~93 ~39 ~260 ~93 ~39 ~272 minecraft:redstone_wire replace
fill ~183 ~39 ~260 ~183 ~39 ~262 minecraft:redstone_wire replace
setblock ~246 ~39 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~260 ~249 ~39 ~272 minecraft:redstone_wire replace
setblock ~258 ~39 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~262 ~246 ~39 ~274 minecraft:redstone_wire replace
fill ~258 ~39 ~262 ~258 ~39 ~274 minecraft:redstone_wire replace
fill ~147 ~39 ~264 ~147 ~39 ~276 minecraft:redstone_wire replace
setblock ~153 ~39 ~264 minecraft:redstone_wire replace
fill ~174 ~39 ~264 ~174 ~39 ~276 minecraft:redstone_wire replace
setblock ~177 ~39 ~264 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~39 ~264 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~264 ~243 ~39 ~276 minecraft:redstone_wire replace
setblock ~252 ~39 ~264 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~39 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~39 ~266 ~153 ~39 ~278 minecraft:redstone_wire replace
fill ~177 ~39 ~266 ~177 ~39 ~278 minecraft:redstone_wire replace
fill ~183 ~39 ~266 ~183 ~39 ~278 minecraft:redstone_wire replace
fill ~252 ~39 ~266 ~252 ~39 ~278 minecraft:redstone_wire replace
setblock ~324 ~39 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~268 ~324 ~39 ~280 minecraft:redstone_wire replace
setblock ~348 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~39 ~270 ~126 ~39 ~280 minecraft:redstone_wire replace
fill ~315 ~39 ~270 ~315 ~39 ~282 minecraft:redstone_wire replace
fill ~318 ~39 ~270 ~318 ~39 ~282 minecraft:redstone_wire replace
setblock ~333 ~39 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~270 ~348 ~39 ~282 minecraft:redstone_wire replace
setblock ~330 ~39 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~272 ~333 ~39 ~284 minecraft:redstone_wire replace
setblock ~249 ~39 ~274 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~274 ~330 ~39 ~286 minecraft:redstone_wire replace
fill ~96 ~39 ~276 ~96 ~39 ~280 minecraft:redstone_wire replace
setblock ~246 ~39 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~276 ~249 ~39 ~288 minecraft:redstone_wire replace
setblock ~258 ~39 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~278 ~246 ~39 ~290 minecraft:redstone_wire replace
fill ~258 ~39 ~278 ~258 ~39 ~290 minecraft:redstone_wire replace
setblock ~153 ~39 ~279 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~39 ~279 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~39 ~279 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~39 ~280 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~39 ~280 ~147 ~39 ~292 minecraft:redstone_wire replace
fill ~153 ~39 ~280 ~153 ~39 ~292 minecraft:redstone_wire replace
fill ~174 ~39 ~280 ~174 ~39 ~292 minecraft:redstone_wire replace
setblock ~177 ~39 ~280 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~39 ~280 ~183 ~39 ~292 minecraft:redstone_wire replace
fill ~243 ~39 ~280 ~243 ~39 ~292 minecraft:redstone_wire replace
fill ~252 ~39 ~280 ~252 ~39 ~292 minecraft:redstone_wire replace
fill ~120 ~39 ~282 ~120 ~39 ~292 minecraft:redstone_wire replace
fill ~177 ~39 ~282 ~177 ~39 ~294 minecraft:redstone_wire replace
setblock ~324 ~39 ~282 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~39 ~284 ~150 ~39 ~288 minecraft:redstone_wire replace
setblock ~315 ~39 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~284 ~324 ~39 ~296 minecraft:redstone_wire replace
setblock ~348 ~39 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~286 ~315 ~39 ~298 minecraft:redstone_wire replace
fill ~318 ~39 ~286 ~318 ~39 ~298 minecraft:redstone_wire replace
setblock ~333 ~39 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~286 ~348 ~39 ~298 minecraft:redstone_wire replace
setblock ~330 ~39 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~288 ~333 ~39 ~300 minecraft:redstone_wire replace
setblock ~249 ~39 ~290 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~290 ~330 ~39 ~302 minecraft:redstone_wire replace
setblock ~246 ~39 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~292 ~249 ~39 ~304 minecraft:redstone_wire replace
setblock ~258 ~39 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~39 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~294 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~39 ~294 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~294 ~243 ~39 ~306 minecraft:redstone_wire replace
fill ~246 ~39 ~294 ~246 ~39 ~306 minecraft:redstone_wire replace
fill ~252 ~39 ~294 ~252 ~39 ~306 minecraft:redstone_wire replace
fill ~258 ~39 ~294 ~258 ~39 ~306 minecraft:redstone_wire replace
setblock ~177 ~39 ~295 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~39 ~296 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~39 ~296 ~174 ~39 ~308 minecraft:redstone_wire replace
fill ~177 ~39 ~296 ~177 ~39 ~308 minecraft:redstone_wire replace
fill ~183 ~39 ~296 ~183 ~39 ~308 minecraft:redstone_wire replace
fill ~156 ~39 ~298 ~156 ~39 ~308 minecraft:redstone_wire replace
setblock ~324 ~39 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~39 ~300 ~180 ~39 ~304 minecraft:redstone_wire replace
setblock ~315 ~39 ~300 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~300 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~300 ~324 ~39 ~312 minecraft:redstone_wire replace
setblock ~348 ~39 ~300 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~302 ~315 ~39 ~314 minecraft:redstone_wire replace
fill ~318 ~39 ~302 ~318 ~39 ~314 minecraft:redstone_wire replace
setblock ~333 ~39 ~302 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~302 ~348 ~39 ~314 minecraft:redstone_wire replace
setblock ~330 ~39 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~304 ~333 ~39 ~316 minecraft:redstone_wire replace
setblock ~249 ~39 ~306 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~306 ~330 ~39 ~318 minecraft:redstone_wire replace
setblock ~243 ~39 ~307 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~246 ~39 ~307 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
