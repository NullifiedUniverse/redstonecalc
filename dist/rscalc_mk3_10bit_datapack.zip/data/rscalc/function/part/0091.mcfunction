setblock ~114 ~143 ~416 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~418 ~114 ~143 ~424 minecraft:redstone_wire replace
fill ~105 ~143 ~420 ~105 ~143 ~426 minecraft:redstone_wire replace
setblock ~102 ~143 ~424 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~143 ~426 ~102 ~143 ~436 minecraft:redstone_wire replace
setblock ~114 ~143 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~428 minecraft:redstone_wire replace
setblock ~105 ~143 ~428 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~428 ~114 ~143 ~440 minecraft:redstone_wire replace
setblock ~99 ~143 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~143 ~430 ~99 ~143 ~442 minecraft:redstone_wire replace
fill ~105 ~143 ~430 ~105 ~143 ~442 minecraft:redstone_wire replace
fill ~96 ~143 ~432 ~96 ~143 ~436 minecraft:redstone_wire replace
fill ~93 ~143 ~436 ~93 ~143 ~442 minecraft:redstone_wire replace
setblock ~96 ~143 ~438 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~143 ~438 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~143 ~440 minecraft:redstone_wire replace
fill ~96 ~143 ~440 ~96 ~143 ~452 minecraft:redstone_wire replace
fill ~102 ~143 ~440 ~102 ~143 ~452 minecraft:redstone_wire replace
setblock ~90 ~143 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~444 ~90 ~143 ~456 minecraft:redstone_wire replace
setblock ~93 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~444 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~444 ~114 ~143 ~456 minecraft:redstone_wire replace
fill ~87 ~143 ~446 ~87 ~143 ~452 minecraft:redstone_wire replace
fill ~93 ~143 ~446 ~93 ~143 ~458 minecraft:redstone_wire replace
fill ~99 ~143 ~446 ~99 ~143 ~458 minecraft:redstone_wire replace
fill ~105 ~143 ~446 ~105 ~143 ~458 minecraft:redstone_wire replace
fill ~78 ~143 ~448 ~78 ~143 ~452 minecraft:redstone_wire replace
setblock ~87 ~143 ~454 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~143 ~454 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~143 ~454 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~143 ~456 ~87 ~143 ~468 minecraft:redstone_wire replace
fill ~96 ~143 ~456 ~96 ~143 ~468 minecraft:redstone_wire replace
fill ~102 ~143 ~456 ~102 ~143 ~468 minecraft:redstone_wire replace
setblock ~90 ~143 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~460 ~90 ~143 ~472 minecraft:redstone_wire replace
setblock ~93 ~143 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~143 ~460 ~114 ~143 ~472 minecraft:redstone_wire replace
fill ~93 ~143 ~462 ~93 ~143 ~474 minecraft:redstone_wire replace
fill ~99 ~143 ~462 ~99 ~143 ~474 minecraft:redstone_wire replace
fill ~105 ~143 ~462 ~105 ~143 ~474 minecraft:redstone_wire replace
fill ~120 ~143 ~468 ~120 ~143 ~474 minecraft:redstone_wire replace
setblock ~87 ~143 ~470 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~143 ~470 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~143 ~470 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~143 ~472 ~87 ~143 ~484 minecraft:redstone_wire replace
fill ~96 ~143 ~472 ~96 ~143 ~484 minecraft:redstone_wire replace
fill ~102 ~143 ~472 ~102 ~143 ~484 minecraft:redstone_wire replace
fill ~108 ~143 ~472 ~108 ~143 ~474 minecraft:redstone_wire replace
setblock ~90 ~143 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~143 ~475 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~476 ~90 ~143 ~488 minecraft:redstone_wire replace
fill ~93 ~143 ~476 ~93 ~143 ~488 minecraft:redstone_wire replace
fill ~99 ~143 ~476 ~99 ~143 ~488 minecraft:redstone_wire replace
fill ~105 ~143 ~476 ~105 ~143 ~488 minecraft:redstone_wire replace
fill ~108 ~143 ~476 ~108 ~143 ~488 minecraft:redstone_wire replace
fill ~114 ~143 ~476 ~114 ~143 ~488 minecraft:redstone_wire replace
fill ~120 ~143 ~476 ~120 ~143 ~488 minecraft:redstone_wire replace
fill ~117 ~143 ~480 ~117 ~143 ~484 minecraft:redstone_wire replace
fill ~147 ~143 ~484 ~147 ~143 ~488 minecraft:redstone_wire replace
fill ~141 ~143 ~488 ~141 ~143 ~490 minecraft:redstone_wire replace
setblock ~90 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~143 ~492 ~90 ~143 ~504 minecraft:redstone_wire replace
fill ~93 ~143 ~492 ~93 ~143 ~504 minecraft:redstone_wire replace
fill ~99 ~143 ~492 ~99 ~143 ~504 minecraft:redstone_wire replace
fill ~105 ~143 ~492 ~105 ~143 ~504 minecraft:redstone_wire replace
fill ~108 ~143 ~492 ~108 ~143 ~504 minecraft:redstone_wire replace
fill ~114 ~143 ~492 ~114 ~143 ~504 minecraft:redstone_wire replace
fill ~120 ~143 ~492 ~120 ~143 ~504 minecraft:redstone_wire replace
setblock ~138 ~143 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~143 ~492 ~147 ~143 ~504 minecraft:redstone_wire replace
fill ~138 ~143 ~494 ~138 ~143 ~500 minecraft:redstone_wire replace
fill ~141 ~143 ~494 ~141 ~143 ~506 minecraft:redstone_wire replace
setblock ~135 ~143 ~496 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~143 ~498 ~135 ~143 ~506 minecraft:redstone_wire replace
setblock ~132 ~143 ~500 minecraft:redstone_wire replace
setblock ~132 ~143 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~143 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~143 ~504 ~129 ~143 ~506 minecraft:redstone_wire replace
fill ~132 ~143 ~504 ~132 ~143 ~516 minecraft:redstone_wire replace
fill ~138 ~143 ~504 ~138 ~143 ~516 minecraft:redstone_wire replace
setblock ~147 ~143 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~143 ~508 ~147 ~143 ~520 minecraft:redstone_wire replace
fill ~126 ~143 ~510 ~126 ~143 ~520 minecraft:redstone_wire replace
fill ~129 ~143 ~510 ~129 ~143 ~522 minecraft:redstone_wire replace
fill ~135 ~143 ~510 ~135 ~143 ~522 minecraft:redstone_wire replace
fill ~141 ~143 ~510 ~141 ~143 ~522 minecraft:redstone_wire replace
fill ~123 ~143 ~512 ~123 ~143 ~516 minecraft:redstone_wire replace
setblock ~123 ~143 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~143 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~143 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~143 ~520 ~123 ~143 ~532 minecraft:redstone_wire replace
fill ~132 ~143 ~520 ~132 ~143 ~532 minecraft:redstone_wire replace
fill ~138 ~143 ~520 ~138 ~143 ~532 minecraft:redstone_wire replace
setblock ~126 ~143 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~143 ~524 ~126 ~143 ~536 minecraft:redstone_wire replace
setblock ~129 ~143 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~143 ~524 ~147 ~143 ~536 minecraft:redstone_wire replace
fill ~129 ~143 ~526 ~129 ~143 ~538 minecraft:redstone_wire replace
fill ~135 ~143 ~526 ~135 ~143 ~538 minecraft:redstone_wire replace
fill ~141 ~143 ~526 ~141 ~143 ~538 minecraft:redstone_wire replace
fill ~153 ~143 ~532 ~153 ~143 ~538 minecraft:redstone_wire replace
setblock ~123 ~143 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~143 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~143 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~143 ~536 ~123 ~143 ~548 minecraft:redstone_wire replace
fill ~132 ~143 ~536 ~132 ~143 ~548 minecraft:redstone_wire replace
fill ~138 ~143 ~536 ~138 ~143 ~548 minecraft:redstone_wire replace
fill ~144 ~143 ~536 ~144 ~143 ~538 minecraft:redstone_wire replace
setblock ~126 ~143 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~143 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~143 ~540 ~126 ~143 ~552 minecraft:redstone_wire replace
fill ~129 ~143 ~540 ~129 ~143 ~552 minecraft:redstone_wire replace
fill ~135 ~143 ~540 ~135 ~143 ~552 minecraft:redstone_wire replace
fill ~141 ~143 ~540 ~141 ~143 ~552 minecraft:redstone_wire replace
fill ~144 ~143 ~540 ~144 ~143 ~552 minecraft:redstone_wire replace
fill ~147 ~143 ~540 ~147 ~143 ~552 minecraft:redstone_wire replace
fill ~153 ~143 ~540 ~153 ~143 ~552 minecraft:redstone_wire replace
fill ~150 ~143 ~544 ~150 ~143 ~548 minecraft:redstone_wire replace
setblock ~126 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~143 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~143 ~556 ~126 ~143 ~568 minecraft:redstone_wire replace
fill ~129 ~143 ~556 ~129 ~143 ~568 minecraft:redstone_wire replace
fill ~135 ~143 ~556 ~135 ~143 ~568 minecraft:redstone_wire replace
fill ~141 ~143 ~556 ~141 ~143 ~568 minecraft:redstone_wire replace
fill ~144 ~143 ~556 ~144 ~143 ~568 minecraft:redstone_wire replace
fill ~147 ~143 ~556 ~147 ~143 ~568 minecraft:redstone_wire replace
fill ~153 ~143 ~556 ~153 ~143 ~568 minecraft:redstone_wire replace
fill ~171 ~143 ~560 ~171 ~143 ~562 minecraft:redstone_wire replace
setblock ~165 ~143 ~564 minecraft:redstone_wire replace
setblock ~171 ~143 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~143 ~566 ~171 ~143 ~578 minecraft:redstone_wire replace
setblock ~162 ~143 ~568 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~143 ~568 ~165 ~143 ~580 minecraft:redstone_wire replace
fill ~162 ~143 ~570 ~162 ~143 ~580 minecraft:redstone_wire replace
setblock ~159 ~143 ~572 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~143 ~574 ~159 ~143 ~580 minecraft:redstone_wire replace
fill ~156 ~143 ~576 ~156 ~143 ~578 minecraft:redstone_wire replace
setblock ~156 ~143 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~143 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~143 ~580 ~156 ~143 ~592 minecraft:redstone_wire replace
fill ~171 ~143 ~580 ~171 ~143 ~592 minecraft:redstone_wire replace
setblock ~159 ~143 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~143 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~143 ~582 ~159 ~143 ~594 minecraft:redstone_wire replace
fill ~162 ~143 ~582 ~162 ~143 ~594 minecraft:redstone_wire replace
fill ~165 ~143 ~582 ~165 ~143 ~594 minecraft:redstone_wire replace
setblock ~156 ~143 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~143 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~143 ~596 ~156 ~143 ~608 minecraft:redstone_wire replace
setblock ~159 ~143 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~143 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~143 ~596 ~171 ~143 ~608 minecraft:redstone_wire replace
fill ~159 ~143 ~598 ~159 ~143 ~610 minecraft:redstone_wire replace
fill ~162 ~143 ~598 ~162 ~143 ~610 minecraft:redstone_wire replace
fill ~165 ~143 ~598 ~165 ~143 ~610 minecraft:redstone_wire replace
fill ~174 ~143 ~604 ~174 ~143 ~610 minecraft:redstone_wire replace
fill ~168 ~143 ~608 ~168 ~143 ~610 minecraft:redstone_wire replace
setblock ~156 ~143 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~143 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~143 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~143 ~612 ~156 ~143 ~624 minecraft:redstone_wire replace
fill ~159 ~143 ~612 ~159 ~143 ~624 minecraft:redstone_wire replace
fill ~162 ~143 ~612 ~162 ~143 ~624 minecraft:redstone_wire replace
fill ~165 ~143 ~612 ~165 ~143 ~624 minecraft:redstone_wire replace
fill ~168 ~143 ~612 ~168 ~143 ~624 minecraft:redstone_wire replace
fill ~171 ~143 ~612 ~171 ~143 ~624 minecraft:redstone_wire replace
fill ~174 ~143 ~612 ~174 ~143 ~624 minecraft:redstone_wire replace
fill ~183 ~143 ~644 ~183 ~143 ~648 minecraft:redstone_wire replace
fill ~84 ~143 ~648 ~84 ~143 ~652 minecraft:redstone_wire replace
fill ~177 ~143 ~652 ~177 ~143 ~656 minecraft:redstone_wire replace
fill ~180 ~143 ~660 ~180 ~143 ~664 minecraft:redstone_wire replace
setblock ~111 ~144 ~383 minecraft:redstone_wire replace
setblock ~81 ~144 ~395 minecraft:redstone_wire replace
setblock ~114 ~144 ~415 minecraft:redstone_wire replace
setblock ~105 ~144 ~419 minecraft:redstone_wire replace
setblock ~102 ~144 ~423 minecraft:redstone_wire replace
setblock ~99 ~144 ~427 minecraft:redstone_wire replace
setblock ~96 ~144 ~431 minecraft:redstone_wire replace
setblock ~93 ~144 ~435 minecraft:redstone_wire replace
setblock ~90 ~144 ~439 minecraft:redstone_wire replace
setblock ~87 ~144 ~443 minecraft:redstone_wire replace
setblock ~78 ~144 ~447 minecraft:redstone_wire replace
setblock ~120 ~144 ~467 minecraft:redstone_wire replace
setblock ~108 ~144 ~471 minecraft:redstone_wire replace
setblock ~117 ~144 ~479 minecraft:redstone_wire replace
setblock ~147 ~144 ~483 minecraft:redstone_wire replace
setblock ~141 ~144 ~487 minecraft:redstone_wire replace
setblock ~138 ~144 ~491 minecraft:redstone_wire replace
setblock ~135 ~144 ~495 minecraft:redstone_wire replace
setblock ~132 ~144 ~499 minecraft:redstone_wire replace
setblock ~129 ~144 ~503 minecraft:redstone_wire replace
setblock ~126 ~144 ~507 minecraft:redstone_wire replace
setblock ~123 ~144 ~511 minecraft:redstone_wire replace
setblock ~153 ~144 ~531 minecraft:redstone_wire replace
setblock ~144 ~144 ~535 minecraft:redstone_wire replace
setblock ~150 ~144 ~543 minecraft:redstone_wire replace
setblock ~171 ~144 ~559 minecraft:redstone_wire replace
setblock ~165 ~144 ~563 minecraft:redstone_wire replace
setblock ~162 ~144 ~567 minecraft:redstone_wire replace
setblock ~159 ~144 ~571 minecraft:redstone_wire replace
setblock ~156 ~144 ~575 minecraft:redstone_wire replace
setblock ~174 ~144 ~603 minecraft:redstone_wire replace
setblock ~168 ~144 ~607 minecraft:redstone_wire replace
setblock ~183 ~144 ~643 minecraft:redstone_wire replace
setblock ~84 ~144 ~647 minecraft:redstone_wire replace
setblock ~177 ~144 ~651 minecraft:redstone_wire replace
setblock ~180 ~144 ~659 minecraft:redstone_wire replace
setblock ~97 ~145 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~145 ~382 ~101 ~145 ~382 minecraft:redstone_wire replace
setblock ~103 ~145 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~145 ~382 ~111 ~145 ~382 minecraft:redstone_wire replace
setblock ~82 ~145 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~145 ~394 ~83 ~145 ~394 minecraft:redstone_wire replace
setblock ~100 ~145 ~413 minecraft:redstone_wire replace
fill ~99 ~145 ~414 ~100 ~145 ~414 minecraft:redstone_wire replace
setblock ~101 ~145 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~145 ~414 ~114 ~145 ~414 minecraft:redstone_wire replace
setblock ~94 ~145 ~417 minecraft:redstone_wire replace
fill ~93 ~145 ~418 ~96 ~145 ~418 minecraft:redstone_wire replace
setblock ~98 ~145 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~145 ~418 ~105 ~145 ~418 minecraft:redstone_wire replace
setblock ~94 ~145 ~421 minecraft:redstone_wire replace
fill ~93 ~145 ~422 ~102 ~145 ~422 minecraft:redstone_wire replace
setblock ~91 ~145 ~425 minecraft:redstone_wire replace
fill ~90 ~145 ~426 ~99 ~145 ~426 minecraft:redstone_wire replace
setblock ~91 ~145 ~429 minecraft:redstone_wire replace
fill ~90 ~145 ~430 ~96 ~145 ~430 minecraft:redstone_wire replace
setblock ~88 ~145 ~433 minecraft:redstone_wire replace
setblock ~87 ~145 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~145 ~434 ~93 ~145 ~434 minecraft:redstone_wire replace
setblock ~88 ~145 ~437 minecraft:redstone_wire replace
fill ~87 ~145 ~438 ~90 ~145 ~438 minecraft:redstone_wire replace
setblock ~88 ~145 ~441 minecraft:redstone_wire replace
fill ~87 ~145 ~442 ~89 ~145 ~442 minecraft:redstone_wire replace
setblock ~79 ~145 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~145 ~446 ~80 ~145 ~446 minecraft:redstone_wire replace
setblock ~100 ~145 ~465 minecraft:redstone_wire replace
fill ~99 ~145 ~466 ~111 ~145 ~466 minecraft:redstone_wire replace
setblock ~113 ~145 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~145 ~466 ~120 ~145 ~466 minecraft:redstone_wire replace
setblock ~94 ~145 ~469 minecraft:redstone_wire replace
fill ~93 ~145 ~470 ~95 ~145 ~470 minecraft:redstone_wire replace
setblock ~97 ~145 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~145 ~470 ~108 ~145 ~470 minecraft:redstone_wire replace
setblock ~100 ~145 ~477 minecraft:redstone_wire replace
fill ~99 ~145 ~478 ~107 ~145 ~478 minecraft:redstone_wire replace
setblock ~109 ~145 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~145 ~478 ~117 ~145 ~478 minecraft:redstone_wire replace
setblock ~112 ~145 ~481 minecraft:redstone_wire replace
fill ~111 ~145 ~482 ~119 ~145 ~482 minecraft:redstone_wire replace
setblock ~121 ~145 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~145 ~482 ~136 ~145 ~482 minecraft:redstone_wire replace
setblock ~138 ~145 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~145 ~482 ~147 ~145 ~482 minecraft:redstone_wire replace
setblock ~109 ~145 ~485 minecraft:redstone_wire replace
fill ~108 ~145 ~486 ~111 ~145 ~486 minecraft:redstone_wire replace
setblock ~113 ~145 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~145 ~486 ~128 ~145 ~486 minecraft:redstone_wire replace
setblock ~130 ~145 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~145 ~486 ~141 ~145 ~486 minecraft:redstone_wire replace
setblock ~109 ~145 ~489 minecraft:redstone_wire replace
setblock ~108 ~145 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~145 ~490 ~122 ~145 ~490 minecraft:redstone_wire replace
setblock ~124 ~145 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~145 ~490 ~138 ~145 ~490 minecraft:redstone_wire replace
setblock ~106 ~145 ~493 minecraft:redstone_wire replace
setblock ~105 ~145 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~145 ~494 ~119 ~145 ~494 minecraft:redstone_wire replace
setblock ~121 ~145 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~145 ~494 ~135 ~145 ~494 minecraft:redstone_wire replace
setblock ~106 ~145 ~497 minecraft:redstone_wire replace
fill ~105 ~145 ~498 ~117 ~145 ~498 minecraft:redstone_wire replace
setblock ~119 ~145 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~145 ~498 ~132 ~145 ~498 minecraft:redstone_wire replace
setblock ~103 ~145 ~501 minecraft:redstone_wire replace
setblock ~102 ~145 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~145 ~502 ~116 ~145 ~502 minecraft:redstone_wire replace
setblock ~118 ~145 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~145 ~502 ~129 ~145 ~502 minecraft:redstone_wire replace
setblock ~103 ~145 ~505 minecraft:redstone_wire replace
fill ~102 ~145 ~506 ~110 ~145 ~506 minecraft:redstone_wire replace
setblock ~112 ~145 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~145 ~506 ~126 ~145 ~506 minecraft:redstone_wire replace
setblock ~103 ~145 ~509 minecraft:redstone_wire replace
fill ~102 ~145 ~510 ~113 ~145 ~510 minecraft:redstone_wire replace
setblock ~115 ~145 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~145 ~510 ~123 ~145 ~510 minecraft:redstone_wire replace
setblock ~112 ~145 ~529 minecraft:redstone_wire replace
fill ~111 ~145 ~530 ~112 ~145 ~530 minecraft:redstone_wire replace
setblock ~113 ~145 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~145 ~530 ~127 ~145 ~530 minecraft:redstone_wire replace
setblock ~129 ~145 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~145 ~530 ~144 ~145 ~530 minecraft:redstone_wire replace
setblock ~146 ~145 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~145 ~530 ~153 ~145 ~530 minecraft:redstone_wire replace
setblock ~109 ~145 ~533 minecraft:redstone_wire replace
fill ~108 ~145 ~534 ~114 ~145 ~534 minecraft:redstone_wire replace
setblock ~116 ~145 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~145 ~534 ~131 ~145 ~534 minecraft:redstone_wire replace
setblock ~133 ~145 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~145 ~534 ~144 ~145 ~534 minecraft:redstone_wire replace
setblock ~112 ~145 ~541 minecraft:redstone_wire replace
fill ~111 ~145 ~542 ~123 ~145 ~542 minecraft:redstone_wire replace
setblock ~125 ~145 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~145 ~542 ~140 ~145 ~542 minecraft:redstone_wire replace
setblock ~142 ~145 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~145 ~542 ~150 ~145 ~542 minecraft:redstone_wire replace
setblock ~124 ~145 ~557 minecraft:redstone_wire replace
fill ~123 ~145 ~558 ~124 ~145 ~558 minecraft:redstone_wire replace
setblock ~126 ~145 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~145 ~558 ~141 ~145 ~558 minecraft:redstone_wire replace
setblock ~143 ~145 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~145 ~558 ~158 ~145 ~558 minecraft:redstone_wire replace
setblock ~160 ~145 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~145 ~558 ~171 ~145 ~558 minecraft:redstone_wire replace
setblock ~121 ~145 ~561 minecraft:redstone_wire replace
fill ~120 ~145 ~562 ~133 ~145 ~562 minecraft:redstone_wire replace
setblock ~135 ~145 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~145 ~562 ~150 ~145 ~562 minecraft:redstone_wire replace
setblock ~152 ~145 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~145 ~562 ~165 ~145 ~562 minecraft:redstone_wire replace
setblock ~118 ~145 ~565 minecraft:redstone_wire replace
fill ~117 ~145 ~566 ~129 ~145 ~566 minecraft:redstone_wire replace
setblock ~131 ~145 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~145 ~566 ~146 ~145 ~566 minecraft:redstone_wire replace
setblock ~148 ~145 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~145 ~566 ~162 ~145 ~566 minecraft:redstone_wire replace
setblock ~115 ~145 ~569 minecraft:redstone_wire replace
fill ~114 ~145 ~570 ~126 ~145 ~570 minecraft:redstone_wire replace
setblock ~128 ~145 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~145 ~570 ~143 ~145 ~570 minecraft:redstone_wire replace
setblock ~145 ~145 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~145 ~570 ~159 ~145 ~570 minecraft:redstone_wire replace
setblock ~115 ~145 ~573 minecraft:redstone_wire replace
fill ~114 ~145 ~574 ~126 ~145 ~574 minecraft:redstone_wire replace
setblock ~128 ~145 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~145 ~574 ~143 ~145 ~574 minecraft:redstone_wire replace
setblock ~145 ~145 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~145 ~574 ~156 ~145 ~574 minecraft:redstone_wire replace
setblock ~124 ~145 ~601 minecraft:redstone_wire replace
fill ~123 ~145 ~602 ~131 ~145 ~602 minecraft:redstone_wire replace
setblock ~133 ~145 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~145 ~602 ~148 ~145 ~602 minecraft:redstone_wire replace
setblock ~150 ~145 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~145 ~602 ~165 ~145 ~602 minecraft:redstone_wire replace
setblock ~167 ~145 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~145 ~602 ~174 ~145 ~602 minecraft:redstone_wire replace
setblock ~121 ~145 ~605 minecraft:redstone_wire replace
fill ~120 ~145 ~606 ~121 ~145 ~606 minecraft:redstone_wire replace
setblock ~123 ~145 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~145 ~606 ~138 ~145 ~606 minecraft:redstone_wire replace
setblock ~140 ~145 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~145 ~606 ~155 ~145 ~606 minecraft:redstone_wire replace
setblock ~157 ~145 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~145 ~606 ~168 ~145 ~606 minecraft:redstone_wire replace
setblock ~133 ~145 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~145 ~642 ~139 ~145 ~642 minecraft:redstone_wire replace
setblock ~141 ~145 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~145 ~642 ~156 ~145 ~642 minecraft:redstone_wire replace
setblock ~158 ~145 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~145 ~642 ~173 ~145 ~642 minecraft:redstone_wire replace
setblock ~175 ~145 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~145 ~642 ~183 ~145 ~642 minecraft:redstone_wire replace
setblock ~85 ~145 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~145 ~646 ~86 ~145 ~646 minecraft:redstone_wire replace
setblock ~127 ~145 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~145 ~650 ~133 ~145 ~650 minecraft:redstone_wire replace
setblock ~135 ~145 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~145 ~650 ~150 ~145 ~650 minecraft:redstone_wire replace
setblock ~152 ~145 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~145 ~650 ~167 ~145 ~650 minecraft:redstone_wire replace
setblock ~169 ~145 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~145 ~650 ~177 ~145 ~650 minecraft:redstone_wire replace
setblock ~130 ~145 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~145 ~658 ~136 ~145 ~658 minecraft:redstone_wire replace
setblock ~138 ~145 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~145 ~658 ~153 ~145 ~658 minecraft:redstone_wire replace
setblock ~155 ~145 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~145 ~658 ~170 ~145 ~658 minecraft:redstone_wire replace
setblock ~172 ~145 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~145 ~658 ~180 ~145 ~658 minecraft:redstone_wire replace
setblock ~97 ~146 ~380 minecraft:redstone_wire replace
setblock ~82 ~146 ~392 minecraft:redstone_wire replace
setblock ~100 ~146 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~146 ~416 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~146 ~420 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~146 ~424 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~146 ~428 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~146 ~432 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~146 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~146 ~440 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~146 ~444 minecraft:redstone_wire replace
setblock ~100 ~146 ~464 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~146 ~468 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~146 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~146 ~480 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~146 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~146 ~488 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~146 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~146 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~146 ~500 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~146 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~146 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~146 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~146 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~146 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~146 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~146 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~146 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~146 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~146 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~146 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~146 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~146 ~640 minecraft:redstone_wire replace
setblock ~85 ~146 ~644 minecraft:redstone_wire replace
setblock ~127 ~146 ~648 minecraft:redstone_wire replace
setblock ~130 ~146 ~656 minecraft:redstone_wire replace
fill ~96 ~147 ~380 ~96 ~147 ~384 minecraft:redstone_wire replace
fill ~81 ~147 ~392 ~81 ~147 ~396 minecraft:redstone_wire replace
fill ~99 ~147 ~412 ~99 ~147 ~424 minecraft:redstone_wire replace
fill ~93 ~147 ~416 ~93 ~147 ~428 minecraft:redstone_wire replace
fill ~90 ~147 ~424 ~90 ~147 ~430 minecraft:redstone_wire replace
setblock ~99 ~147 ~426 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~428 ~99 ~147 ~440 minecraft:redstone_wire replace
setblock ~93 ~147 ~430 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~147 ~432 ~87 ~147 ~442 minecraft:redstone_wire replace
setblock ~90 ~147 ~432 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~147 ~432 ~93 ~147 ~444 minecraft:redstone_wire replace
setblock ~99 ~147 ~442 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~147 ~444 ~78 ~147 ~448 minecraft:redstone_wire replace
setblock ~87 ~147 ~444 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~444 ~99 ~147 ~456 minecraft:redstone_wire replace
setblock ~93 ~147 ~446 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~147 ~448 ~93 ~147 ~460 minecraft:redstone_wire replace
setblock ~99 ~147 ~458 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~460 ~99 ~147 ~472 minecraft:redstone_wire replace
setblock ~93 ~147 ~462 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~147 ~464 ~93 ~147 ~470 minecraft:redstone_wire replace
setblock ~93 ~147 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~147 ~474 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~147 ~476 ~99 ~147 ~480 minecraft:redstone_wire replace
fill ~111 ~147 ~480 ~111 ~147 ~492 minecraft:redstone_wire replace
fill ~108 ~147 ~484 ~108 ~147 ~496 minecraft:redstone_wire replace
fill ~105 ~147 ~492 ~105 ~147 ~498 minecraft:redstone_wire replace
setblock ~111 ~147 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~496 ~111 ~147 ~508 minecraft:redstone_wire replace
setblock ~108 ~147 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~147 ~500 ~102 ~147 ~510 minecraft:redstone_wire replace
setblock ~105 ~147 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~147 ~500 ~108 ~147 ~512 minecraft:redstone_wire replace
setblock ~111 ~147 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~147 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~512 ~111 ~147 ~524 minecraft:redstone_wire replace
setblock ~108 ~147 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~147 ~516 ~108 ~147 ~528 minecraft:redstone_wire replace
setblock ~111 ~147 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~528 ~111 ~147 ~540 minecraft:redstone_wire replace
setblock ~108 ~147 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~147 ~532 ~108 ~147 ~536 minecraft:redstone_wire replace
setblock ~111 ~147 ~541 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~147 ~542 ~111 ~147 ~544 minecraft:redstone_wire replace
fill ~123 ~147 ~556 ~123 ~147 ~568 minecraft:redstone_wire replace
fill ~120 ~147 ~560 ~120 ~147 ~572 minecraft:redstone_wire replace
fill ~117 ~147 ~564 ~117 ~147 ~568 minecraft:redstone_wire replace
fill ~114 ~147 ~568 ~114 ~147 ~574 minecraft:redstone_wire replace
setblock ~123 ~147 ~570 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~147 ~572 ~123 ~147 ~584 minecraft:redstone_wire replace
setblock ~120 ~147 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~147 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~147 ~576 ~120 ~147 ~588 minecraft:redstone_wire replace
setblock ~123 ~147 ~586 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~147 ~588 ~123 ~147 ~600 minecraft:redstone_wire replace
setblock ~120 ~147 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~147 ~592 ~120 ~147 ~604 minecraft:redstone_wire replace
setblock ~123 ~147 ~601 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~147 ~602 ~123 ~147 ~604 minecraft:redstone_wire replace
setblock ~120 ~147 ~605 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~147 ~606 ~120 ~147 ~608 minecraft:redstone_wire replace
fill ~132 ~147 ~640 ~132 ~147 ~644 minecraft:redstone_wire replace
fill ~84 ~147 ~644 ~84 ~147 ~648 minecraft:redstone_wire replace
fill ~126 ~147 ~648 ~126 ~147 ~652 minecraft:redstone_wire replace
fill ~129 ~147 ~656 ~129 ~147 ~660 minecraft:redstone_wire replace
setblock ~96 ~148 ~385 minecraft:redstone_wire replace
setblock ~81 ~148 ~397 minecraft:redstone_wire replace
setblock ~90 ~148 ~433 minecraft:redstone_wire replace
setblock ~87 ~148 ~445 minecraft:redstone_wire replace
setblock ~78 ~148 ~449 minecraft:redstone_wire replace
setblock ~93 ~148 ~473 minecraft:redstone_wire replace
setblock ~99 ~148 ~481 minecraft:redstone_wire replace
setblock ~105 ~148 ~501 minecraft:redstone_wire replace
setblock ~102 ~148 ~513 minecraft:redstone_wire replace
setblock ~108 ~148 ~537 minecraft:redstone_wire replace
setblock ~111 ~148 ~545 minecraft:redstone_wire replace
setblock ~117 ~148 ~569 minecraft:redstone_wire replace
setblock ~114 ~148 ~577 minecraft:redstone_wire replace
setblock ~123 ~148 ~605 minecraft:redstone_wire replace
setblock ~120 ~148 ~609 minecraft:redstone_wire replace
setblock ~132 ~148 ~645 minecraft:redstone_wire replace
setblock ~84 ~148 ~649 minecraft:redstone_wire replace
setblock ~126 ~148 ~653 minecraft:redstone_wire replace
setblock ~129 ~148 ~661 minecraft:redstone_wire replace
fill ~96 ~149 ~386 ~102 ~149 ~386 minecraft:redstone_wire replace
setblock ~104 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~149 ~386 ~119 ~149 ~386 minecraft:redstone_wire replace
setblock ~121 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~149 ~386 ~136 ~149 ~386 minecraft:redstone_wire replace
setblock ~138 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~140 ~149 ~386 ~153 ~149 ~386 minecraft:redstone_wire replace
setblock ~155 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~149 ~386 ~170 ~149 ~386 minecraft:redstone_wire replace
setblock ~172 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~149 ~386 ~187 ~149 ~386 minecraft:redstone_wire replace
setblock ~189 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~191 ~149 ~386 ~204 ~149 ~386 minecraft:redstone_wire replace
setblock ~206 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~149 ~386 ~221 ~149 ~386 minecraft:redstone_wire replace
setblock ~223 ~149 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~149 ~386 ~233 ~149 ~386 minecraft:redstone_wire replace
setblock ~232 ~149 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~149 ~398 ~83 ~149 ~398 minecraft:redstone_wire replace
setblock ~82 ~149 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~149 ~434 ~101 ~149 ~434 minecraft:redstone_wire replace
setblock ~102 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~149 ~434 ~115 ~149 ~434 minecraft:redstone_wire replace
setblock ~116 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~117 ~149 ~434 ~130 ~149 ~434 minecraft:redstone_wire replace
setblock ~131 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~132 ~149 ~434 ~145 ~149 ~434 minecraft:redstone_wire replace
setblock ~146 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~149 ~434 ~160 ~149 ~434 minecraft:redstone_wire replace
setblock ~161 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~149 ~434 ~175 ~149 ~434 minecraft:redstone_wire replace
setblock ~176 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~149 ~434 ~190 ~149 ~434 minecraft:redstone_wire replace
setblock ~191 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~149 ~434 ~205 ~149 ~434 minecraft:redstone_wire replace
setblock ~206 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~207 ~149 ~434 ~220 ~149 ~434 minecraft:redstone_wire replace
setblock ~221 ~149 ~434 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~222 ~149 ~434 ~230 ~149 ~434 minecraft:redstone_wire replace
setblock ~85 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~149 ~435 minecraft:redstone_wire replace
setblock ~106 ~149 ~435 minecraft:redstone_wire replace
setblock ~109 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~149 ~435 minecraft:redstone_wire replace
