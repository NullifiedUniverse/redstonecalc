setblock ~259 ~51 ~56 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~59 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~61 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~63 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~65 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~69 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~71 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~75 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~77 minecraft:light_gray_concrete replace
setblock ~273 ~51 ~77 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~79 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~81 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~85 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~87 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~91 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~93 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~95 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~97 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~101 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~103 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~107 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~109 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~111 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~113 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~117 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~119 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~123 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~125 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~127 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~129 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~133 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~135 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~139 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~141 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~143 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~145 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~149 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~151 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~155 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~157 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~159 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~161 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~165 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~167 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~171 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~173 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~175 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~177 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~181 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~183 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~187 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~189 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~191 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~193 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~197 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~199 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~203 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~205 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~207 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~209 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~213 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~215 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~219 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~221 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~223 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~225 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~229 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~231 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~235 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~237 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~239 minecraft:light_gray_concrete replace
setblock ~94 ~51 ~240 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~241 minecraft:light_gray_concrete replace
setblock ~94 ~51 ~244 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~245 minecraft:light_gray_concrete replace
setblock ~93 ~51 ~247 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~247 minecraft:light_gray_concrete replace
setblock ~93 ~51 ~249 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~251 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~253 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~255 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~257 minecraft:light_gray_concrete replace
setblock ~118 ~51 ~260 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~261 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~263 minecraft:light_gray_concrete replace
setblock ~118 ~51 ~264 minecraft:light_gray_concrete replace
setblock ~117 ~51 ~267 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~267 minecraft:light_gray_concrete replace
setblock ~117 ~51 ~269 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~269 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~271 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~273 minecraft:light_gray_concrete replace
setblock ~139 ~51 ~276 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~277 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~279 minecraft:light_gray_concrete replace
setblock ~139 ~51 ~280 minecraft:light_gray_concrete replace
setblock ~138 ~51 ~283 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~283 minecraft:light_gray_concrete replace
setblock ~138 ~51 ~285 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~285 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~287 minecraft:light_gray_concrete replace
setblock ~157 ~51 ~288 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~289 minecraft:light_gray_concrete replace
setblock ~157 ~51 ~292 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~293 minecraft:light_gray_concrete replace
setblock ~156 ~51 ~295 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~295 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~296 minecraft:light_gray_concrete replace
setblock ~156 ~51 ~297 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~299 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~300 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~301 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~303 minecraft:light_gray_concrete replace
setblock ~214 ~51 ~304 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~305 minecraft:light_gray_concrete replace
setblock ~193 ~51 ~308 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~309 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~311 minecraft:light_gray_concrete replace
setblock ~172 ~51 ~312 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~315 minecraft:light_gray_concrete replace
setblock ~172 ~51 ~316 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~317 minecraft:light_gray_concrete replace
setblock ~171 ~51 ~319 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~319 minecraft:light_gray_concrete replace
setblock ~171 ~51 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~51 ~321 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~51 ~323 minecraft:light_gray_concrete replace
setblock ~193 ~51 ~324 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~325 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~327 minecraft:light_gray_concrete replace
setblock ~192 ~51 ~329 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~331 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~333 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~335 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~337 minecraft:light_gray_concrete replace
setblock ~214 ~51 ~340 minecraft:light_gray_concrete replace
setblock ~195 ~51 ~341 minecraft:light_gray_concrete replace
setblock ~213 ~51 ~345 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~347 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~349 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~351 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~353 minecraft:light_gray_concrete replace
setblock ~216 ~51 ~357 minecraft:light_gray_concrete replace
setblock ~262 ~51 ~360 minecraft:light_gray_concrete replace
setblock ~261 ~51 ~365 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~367 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~369 minecraft:light_gray_concrete replace
setblock ~264 ~51 ~369 minecraft:light_gray_concrete replace
setblock ~259 ~51 ~372 minecraft:light_gray_concrete replace
setblock ~258 ~51 ~377 minecraft:light_gray_concrete replace
setblock ~234 ~51 ~385 minecraft:light_gray_concrete replace
setblock ~288 ~51 ~389 minecraft:light_gray_concrete replace
setblock ~309 ~51 ~393 minecraft:light_gray_concrete replace
setblock ~276 ~51 ~397 minecraft:light_gray_concrete replace
setblock ~300 ~51 ~401 minecraft:light_gray_concrete replace
setblock ~270 ~51 ~405 minecraft:light_gray_concrete replace
setblock ~90 ~51 ~413 minecraft:light_gray_concrete replace
setblock ~114 ~51 ~417 minecraft:light_gray_concrete replace
setblock ~135 ~51 ~421 minecraft:light_gray_concrete replace
setblock ~162 ~51 ~425 minecraft:light_gray_concrete replace
setblock ~183 ~51 ~429 minecraft:light_gray_concrete replace
setblock ~207 ~51 ~433 minecraft:light_gray_concrete replace
setblock ~231 ~51 ~437 minecraft:light_gray_concrete replace
setblock ~252 ~51 ~441 minecraft:light_gray_concrete replace
setblock ~267 ~51 ~445 minecraft:light_gray_concrete replace
setblock ~87 ~51 ~449 minecraft:light_gray_concrete replace
setblock ~111 ~51 ~453 minecraft:light_gray_concrete replace
setblock ~132 ~51 ~457 minecraft:light_gray_concrete replace
setblock ~159 ~51 ~461 minecraft:light_gray_concrete replace
setblock ~180 ~51 ~465 minecraft:light_gray_concrete replace
setblock ~204 ~51 ~469 minecraft:light_gray_concrete replace
setblock ~228 ~51 ~473 minecraft:light_gray_concrete replace
setblock ~249 ~51 ~477 minecraft:light_gray_concrete replace
setblock ~291 ~51 ~481 minecraft:light_gray_concrete replace
setblock ~315 ~51 ~485 minecraft:light_gray_concrete replace
setblock ~84 ~51 ~489 minecraft:light_gray_concrete replace
setblock ~108 ~51 ~493 minecraft:light_gray_concrete replace
setblock ~129 ~51 ~497 minecraft:light_gray_concrete replace
setblock ~153 ~51 ~501 minecraft:light_gray_concrete replace
setblock ~177 ~51 ~505 minecraft:light_gray_concrete replace
setblock ~201 ~51 ~509 minecraft:light_gray_concrete replace
setblock ~225 ~51 ~513 minecraft:light_gray_concrete replace
setblock ~246 ~51 ~517 minecraft:light_gray_concrete replace
setblock ~285 ~51 ~521 minecraft:light_gray_concrete replace
setblock ~312 ~51 ~525 minecraft:light_gray_concrete replace
setblock ~81 ~51 ~529 minecraft:light_gray_concrete replace
setblock ~105 ~51 ~533 minecraft:light_gray_concrete replace
setblock ~126 ~51 ~537 minecraft:light_gray_concrete replace
setblock ~147 ~51 ~541 minecraft:light_gray_concrete replace
setblock ~174 ~51 ~545 minecraft:light_gray_concrete replace
setblock ~198 ~51 ~549 minecraft:light_gray_concrete replace
setblock ~222 ~51 ~553 minecraft:light_gray_concrete replace
setblock ~240 ~51 ~557 minecraft:light_gray_concrete replace
setblock ~282 ~51 ~561 minecraft:light_gray_concrete replace
setblock ~306 ~51 ~565 minecraft:light_gray_concrete replace
setblock ~78 ~51 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~51 ~573 minecraft:light_gray_concrete replace
setblock ~123 ~51 ~577 minecraft:light_gray_concrete replace
setblock ~144 ~51 ~581 minecraft:light_gray_concrete replace
setblock ~168 ~51 ~585 minecraft:light_gray_concrete replace
setblock ~189 ~51 ~589 minecraft:light_gray_concrete replace
setblock ~219 ~51 ~593 minecraft:light_gray_concrete replace
setblock ~237 ~51 ~597 minecraft:light_gray_concrete replace
setblock ~279 ~51 ~601 minecraft:light_gray_concrete replace
setblock ~303 ~51 ~605 minecraft:light_gray_concrete replace
setblock ~99 ~51 ~609 minecraft:light_gray_concrete replace
setblock ~120 ~51 ~613 minecraft:light_gray_concrete replace
setblock ~141 ~51 ~617 minecraft:light_gray_concrete replace
setblock ~165 ~51 ~621 minecraft:light_gray_concrete replace
setblock ~186 ~51 ~625 minecraft:light_gray_concrete replace
setblock ~210 ~51 ~629 minecraft:light_gray_concrete replace
setblock ~243 ~51 ~633 minecraft:light_gray_concrete replace
setblock ~255 ~51 ~637 minecraft:light_gray_concrete replace
setblock ~294 ~51 ~641 minecraft:light_gray_concrete replace
setblock ~150 ~51 ~645 minecraft:light_gray_concrete replace
setblock ~321 ~51 ~649 minecraft:light_gray_concrete replace
setblock ~96 ~51 ~653 minecraft:light_gray_concrete replace
setblock ~297 ~51 ~657 minecraft:light_gray_concrete replace
setblock ~318 ~51 ~661 minecraft:light_gray_concrete replace
fill ~273 ~52 ~78 ~275 ~52 ~78 minecraft:light_gray_concrete replace
fill ~274 ~52 ~79 ~274 ~52 ~80 minecraft:light_gray_concrete replace
fill ~93 ~52 ~250 ~95 ~52 ~250 minecraft:light_gray_concrete replace
fill ~94 ~52 ~251 ~94 ~52 ~252 minecraft:light_gray_concrete replace
fill ~117 ~52 ~270 ~119 ~52 ~270 minecraft:light_gray_concrete replace
fill ~118 ~52 ~271 ~118 ~52 ~272 minecraft:light_gray_concrete replace
fill ~138 ~52 ~286 ~140 ~52 ~286 minecraft:light_gray_concrete replace
fill ~139 ~52 ~287 ~139 ~52 ~288 minecraft:light_gray_concrete replace
fill ~153 ~52 ~298 ~156 ~52 ~298 minecraft:light_gray_concrete replace
fill ~154 ~52 ~299 ~154 ~52 ~300 minecraft:light_gray_concrete replace
fill ~168 ~52 ~322 ~171 ~52 ~322 minecraft:light_gray_concrete replace
fill ~169 ~52 ~323 ~169 ~52 ~324 minecraft:light_gray_concrete replace
fill ~189 ~52 ~330 ~194 ~52 ~330 minecraft:light_gray_concrete replace
fill ~190 ~52 ~331 ~190 ~52 ~332 minecraft:light_gray_concrete replace
fill ~193 ~52 ~331 ~193 ~52 ~332 minecraft:light_gray_concrete replace
fill ~189 ~52 ~342 ~195 ~52 ~342 minecraft:light_gray_concrete replace
fill ~190 ~52 ~343 ~190 ~52 ~344 minecraft:light_gray_concrete replace
fill ~193 ~52 ~343 ~193 ~52 ~344 minecraft:light_gray_concrete replace
fill ~210 ~52 ~346 ~215 ~52 ~346 minecraft:light_gray_concrete replace
fill ~211 ~52 ~347 ~211 ~52 ~348 minecraft:light_gray_concrete replace
fill ~214 ~52 ~347 ~214 ~52 ~348 minecraft:light_gray_concrete replace
fill ~210 ~52 ~358 ~216 ~52 ~358 minecraft:light_gray_concrete replace
fill ~211 ~52 ~359 ~211 ~52 ~360 minecraft:light_gray_concrete replace
fill ~214 ~52 ~359 ~214 ~52 ~360 minecraft:light_gray_concrete replace
fill ~261 ~52 ~366 ~266 ~52 ~366 minecraft:light_gray_concrete replace
fill ~262 ~52 ~367 ~262 ~52 ~368 minecraft:light_gray_concrete replace
fill ~265 ~52 ~367 ~265 ~52 ~368 minecraft:light_gray_concrete replace
fill ~261 ~52 ~370 ~266 ~52 ~370 minecraft:light_gray_concrete replace
fill ~262 ~52 ~371 ~262 ~52 ~372 minecraft:light_gray_concrete replace
fill ~265 ~52 ~371 ~265 ~52 ~372 minecraft:light_gray_concrete replace
fill ~234 ~52 ~378 ~308 ~52 ~378 minecraft:light_gray_concrete replace
fill ~235 ~52 ~379 ~235 ~52 ~380 minecraft:light_gray_concrete replace
fill ~238 ~52 ~379 ~238 ~52 ~380 minecraft:light_gray_concrete replace
fill ~271 ~52 ~379 ~271 ~52 ~380 minecraft:light_gray_concrete replace
fill ~307 ~52 ~379 ~307 ~52 ~380 minecraft:light_gray_concrete replace
fill ~234 ~52 ~386 ~239 ~52 ~386 minecraft:light_gray_concrete replace
fill ~235 ~52 ~387 ~235 ~52 ~388 minecraft:light_gray_concrete replace
fill ~238 ~52 ~387 ~238 ~52 ~388 minecraft:light_gray_concrete replace
fill ~270 ~52 ~390 ~308 ~52 ~390 minecraft:light_gray_concrete replace
fill ~271 ~52 ~391 ~271 ~52 ~392 minecraft:light_gray_concrete replace
fill ~307 ~52 ~391 ~307 ~52 ~392 minecraft:light_gray_concrete replace
fill ~309 ~52 ~394 ~311 ~52 ~394 minecraft:light_gray_concrete replace
fill ~310 ~52 ~395 ~310 ~52 ~396 minecraft:light_gray_concrete replace
fill ~276 ~52 ~398 ~278 ~52 ~398 minecraft:light_gray_concrete replace
fill ~277 ~52 ~399 ~277 ~52 ~400 minecraft:light_gray_concrete replace
fill ~297 ~52 ~402 ~300 ~52 ~402 minecraft:light_gray_concrete replace
fill ~298 ~52 ~403 ~298 ~52 ~404 minecraft:light_gray_concrete replace
fill ~270 ~52 ~406 ~272 ~52 ~406 minecraft:light_gray_concrete replace
fill ~271 ~52 ~407 ~271 ~52 ~408 minecraft:light_gray_concrete replace
fill ~90 ~52 ~414 ~92 ~52 ~414 minecraft:light_gray_concrete replace
fill ~91 ~52 ~415 ~91 ~52 ~416 minecraft:light_gray_concrete replace
fill ~114 ~52 ~418 ~116 ~52 ~418 minecraft:light_gray_concrete replace
fill ~115 ~52 ~419 ~115 ~52 ~420 minecraft:light_gray_concrete replace
fill ~135 ~52 ~422 ~137 ~52 ~422 minecraft:light_gray_concrete replace
fill ~136 ~52 ~423 ~136 ~52 ~424 minecraft:light_gray_concrete replace
fill ~159 ~52 ~426 ~162 ~52 ~426 minecraft:light_gray_concrete replace
fill ~160 ~52 ~427 ~160 ~52 ~428 minecraft:light_gray_concrete replace
fill ~180 ~52 ~430 ~183 ~52 ~430 minecraft:light_gray_concrete replace
fill ~181 ~52 ~431 ~181 ~52 ~432 minecraft:light_gray_concrete replace
fill ~204 ~52 ~434 ~207 ~52 ~434 minecraft:light_gray_concrete replace
fill ~205 ~52 ~435 ~205 ~52 ~436 minecraft:light_gray_concrete replace
fill ~231 ~52 ~438 ~233 ~52 ~438 minecraft:light_gray_concrete replace
fill ~232 ~52 ~439 ~232 ~52 ~440 minecraft:light_gray_concrete replace
fill ~252 ~52 ~442 ~257 ~52 ~442 minecraft:light_gray_concrete replace
fill ~256 ~52 ~443 ~256 ~52 ~444 minecraft:light_gray_concrete replace
fill ~267 ~52 ~446 ~269 ~52 ~446 minecraft:light_gray_concrete replace
fill ~268 ~52 ~447 ~268 ~52 ~448 minecraft:light_gray_concrete replace
fill ~87 ~52 ~450 ~89 ~52 ~450 minecraft:light_gray_concrete replace
fill ~88 ~52 ~451 ~88 ~52 ~452 minecraft:light_gray_concrete replace
fill ~111 ~52 ~454 ~113 ~52 ~454 minecraft:light_gray_concrete replace
fill ~112 ~52 ~455 ~112 ~52 ~456 minecraft:light_gray_concrete replace
fill ~132 ~52 ~458 ~134 ~52 ~458 minecraft:light_gray_concrete replace
fill ~133 ~52 ~459 ~133 ~52 ~460 minecraft:light_gray_concrete replace
fill ~156 ~52 ~462 ~159 ~52 ~462 minecraft:light_gray_concrete replace
fill ~157 ~52 ~463 ~157 ~52 ~464 minecraft:light_gray_concrete replace
fill ~177 ~52 ~466 ~180 ~52 ~466 minecraft:light_gray_concrete replace
fill ~178 ~52 ~467 ~178 ~52 ~468 minecraft:light_gray_concrete replace
fill ~201 ~52 ~470 ~204 ~52 ~470 minecraft:light_gray_concrete replace
fill ~202 ~52 ~471 ~202 ~52 ~472 minecraft:light_gray_concrete replace
fill ~225 ~52 ~474 ~228 ~52 ~474 minecraft:light_gray_concrete replace
fill ~226 ~52 ~475 ~226 ~52 ~476 minecraft:light_gray_concrete replace
fill ~249 ~52 ~478 ~254 ~52 ~478 minecraft:light_gray_concrete replace
fill ~253 ~52 ~479 ~253 ~52 ~480 minecraft:light_gray_concrete replace
fill ~288 ~52 ~482 ~291 ~52 ~482 minecraft:light_gray_concrete replace
fill ~289 ~52 ~483 ~289 ~52 ~484 minecraft:light_gray_concrete replace
fill ~315 ~52 ~486 ~317 ~52 ~486 minecraft:light_gray_concrete replace
fill ~316 ~52 ~487 ~316 ~52 ~488 minecraft:light_gray_concrete replace
fill ~84 ~52 ~490 ~86 ~52 ~490 minecraft:light_gray_concrete replace
fill ~85 ~52 ~491 ~85 ~52 ~492 minecraft:light_gray_concrete replace
fill ~108 ~52 ~494 ~110 ~52 ~494 minecraft:light_gray_concrete replace
fill ~109 ~52 ~495 ~109 ~52 ~496 minecraft:light_gray_concrete replace
fill ~129 ~52 ~498 ~131 ~52 ~498 minecraft:light_gray_concrete replace
fill ~130 ~52 ~499 ~130 ~52 ~500 minecraft:light_gray_concrete replace
fill ~150 ~52 ~502 ~153 ~52 ~502 minecraft:light_gray_concrete replace
fill ~151 ~52 ~503 ~151 ~52 ~504 minecraft:light_gray_concrete replace
fill ~174 ~52 ~506 ~177 ~52 ~506 minecraft:light_gray_concrete replace
fill ~175 ~52 ~507 ~175 ~52 ~508 minecraft:light_gray_concrete replace
fill ~198 ~52 ~510 ~201 ~52 ~510 minecraft:light_gray_concrete replace
fill ~199 ~52 ~511 ~199 ~52 ~512 minecraft:light_gray_concrete replace
fill ~222 ~52 ~514 ~225 ~52 ~514 minecraft:light_gray_concrete replace
fill ~223 ~52 ~515 ~223 ~52 ~516 minecraft:light_gray_concrete replace
fill ~246 ~52 ~518 ~251 ~52 ~518 minecraft:light_gray_concrete replace
fill ~250 ~52 ~519 ~250 ~52 ~520 minecraft:light_gray_concrete replace
fill ~285 ~52 ~522 ~287 ~52 ~522 minecraft:light_gray_concrete replace
fill ~286 ~52 ~523 ~286 ~52 ~524 minecraft:light_gray_concrete replace
fill ~312 ~52 ~526 ~314 ~52 ~526 minecraft:light_gray_concrete replace
fill ~313 ~52 ~527 ~313 ~52 ~528 minecraft:light_gray_concrete replace
fill ~81 ~52 ~530 ~83 ~52 ~530 minecraft:light_gray_concrete replace
fill ~82 ~52 ~531 ~82 ~52 ~532 minecraft:light_gray_concrete replace
fill ~105 ~52 ~534 ~107 ~52 ~534 minecraft:light_gray_concrete replace
fill ~106 ~52 ~535 ~106 ~52 ~536 minecraft:light_gray_concrete replace
fill ~126 ~52 ~538 ~128 ~52 ~538 minecraft:light_gray_concrete replace
fill ~127 ~52 ~539 ~127 ~52 ~540 minecraft:light_gray_concrete replace
fill ~147 ~52 ~542 ~149 ~52 ~542 minecraft:light_gray_concrete replace
fill ~148 ~52 ~543 ~148 ~52 ~544 minecraft:light_gray_concrete replace
fill ~171 ~52 ~546 ~174 ~52 ~546 minecraft:light_gray_concrete replace
fill ~172 ~52 ~547 ~172 ~52 ~548 minecraft:light_gray_concrete replace
fill ~195 ~52 ~550 ~198 ~52 ~550 minecraft:light_gray_concrete replace
fill ~196 ~52 ~551 ~196 ~52 ~552 minecraft:light_gray_concrete replace
fill ~219 ~52 ~554 ~222 ~52 ~554 minecraft:light_gray_concrete replace
fill ~220 ~52 ~555 ~220 ~52 ~556 minecraft:light_gray_concrete replace
fill ~240 ~52 ~558 ~245 ~52 ~558 minecraft:light_gray_concrete replace
fill ~244 ~52 ~559 ~244 ~52 ~560 minecraft:light_gray_concrete replace
fill ~282 ~52 ~562 ~284 ~52 ~562 minecraft:light_gray_concrete replace
fill ~283 ~52 ~563 ~283 ~52 ~564 minecraft:light_gray_concrete replace
fill ~303 ~52 ~566 ~306 ~52 ~566 minecraft:light_gray_concrete replace
fill ~304 ~52 ~567 ~304 ~52 ~568 minecraft:light_gray_concrete replace
fill ~78 ~52 ~570 ~80 ~52 ~570 minecraft:light_gray_concrete replace
fill ~79 ~52 ~571 ~79 ~52 ~572 minecraft:light_gray_concrete replace
fill ~102 ~52 ~574 ~104 ~52 ~574 minecraft:light_gray_concrete replace
fill ~103 ~52 ~575 ~103 ~52 ~576 minecraft:light_gray_concrete replace
fill ~123 ~52 ~578 ~125 ~52 ~578 minecraft:light_gray_concrete replace
fill ~124 ~52 ~579 ~124 ~52 ~580 minecraft:light_gray_concrete replace
fill ~144 ~52 ~582 ~146 ~52 ~582 minecraft:light_gray_concrete replace
fill ~145 ~52 ~583 ~145 ~52 ~584 minecraft:light_gray_concrete replace
fill ~165 ~52 ~586 ~168 ~52 ~586 minecraft:light_gray_concrete replace
fill ~166 ~52 ~587 ~166 ~52 ~588 minecraft:light_gray_concrete replace
fill ~186 ~52 ~590 ~189 ~52 ~590 minecraft:light_gray_concrete replace
fill ~187 ~52 ~591 ~187 ~52 ~592 minecraft:light_gray_concrete replace
fill ~216 ~52 ~594 ~219 ~52 ~594 minecraft:light_gray_concrete replace
fill ~217 ~52 ~595 ~217 ~52 ~596 minecraft:light_gray_concrete replace
fill ~237 ~52 ~598 ~242 ~52 ~598 minecraft:light_gray_concrete replace
fill ~241 ~52 ~599 ~241 ~52 ~600 minecraft:light_gray_concrete replace
fill ~279 ~52 ~602 ~281 ~52 ~602 minecraft:light_gray_concrete replace
fill ~280 ~52 ~603 ~280 ~52 ~604 minecraft:light_gray_concrete replace
fill ~300 ~52 ~606 ~303 ~52 ~606 minecraft:light_gray_concrete replace
fill ~301 ~52 ~607 ~301 ~52 ~608 minecraft:light_gray_concrete replace
fill ~99 ~52 ~610 ~101 ~52 ~610 minecraft:light_gray_concrete replace
fill ~100 ~52 ~611 ~100 ~52 ~612 minecraft:light_gray_concrete replace
fill ~120 ~52 ~614 ~122 ~52 ~614 minecraft:light_gray_concrete replace
fill ~121 ~52 ~615 ~121 ~52 ~616 minecraft:light_gray_concrete replace
fill ~141 ~52 ~618 ~143 ~52 ~618 minecraft:light_gray_concrete replace
fill ~142 ~52 ~619 ~142 ~52 ~620 minecraft:light_gray_concrete replace
fill ~162 ~52 ~622 ~165 ~52 ~622 minecraft:light_gray_concrete replace
fill ~163 ~52 ~623 ~163 ~52 ~624 minecraft:light_gray_concrete replace
fill ~183 ~52 ~626 ~186 ~52 ~626 minecraft:light_gray_concrete replace
fill ~184 ~52 ~627 ~184 ~52 ~628 minecraft:light_gray_concrete replace
fill ~207 ~52 ~630 ~210 ~52 ~630 minecraft:light_gray_concrete replace
fill ~208 ~52 ~631 ~208 ~52 ~632 minecraft:light_gray_concrete replace
fill ~243 ~52 ~634 ~248 ~52 ~634 minecraft:light_gray_concrete replace
fill ~247 ~52 ~635 ~247 ~52 ~636 minecraft:light_gray_concrete replace
fill ~255 ~52 ~638 ~260 ~52 ~638 minecraft:light_gray_concrete replace
fill ~259 ~52 ~639 ~259 ~52 ~640 minecraft:light_gray_concrete replace
fill ~291 ~52 ~642 ~294 ~52 ~642 minecraft:light_gray_concrete replace
fill ~292 ~52 ~643 ~292 ~52 ~644 minecraft:light_gray_concrete replace
fill ~93 ~52 ~646 ~230 ~52 ~646 minecraft:light_gray_concrete replace
fill ~94 ~52 ~647 ~94 ~52 ~648 minecraft:light_gray_concrete replace
fill ~118 ~52 ~647 ~118 ~52 ~648 minecraft:light_gray_concrete replace
fill ~139 ~52 ~647 ~139 ~52 ~648 minecraft:light_gray_concrete replace
fill ~154 ~52 ~647 ~154 ~52 ~648 minecraft:light_gray_concrete replace
fill ~169 ~52 ~647 ~169 ~52 ~648 minecraft:light_gray_concrete replace
fill ~229 ~52 ~647 ~229 ~52 ~648 minecraft:light_gray_concrete replace
fill ~321 ~52 ~650 ~323 ~52 ~650 minecraft:light_gray_concrete replace
fill ~322 ~52 ~651 ~322 ~52 ~652 minecraft:light_gray_concrete replace
fill ~96 ~52 ~654 ~98 ~52 ~654 minecraft:light_gray_concrete replace
fill ~97 ~52 ~655 ~97 ~52 ~656 minecraft:light_gray_concrete replace
fill ~294 ~52 ~658 ~297 ~52 ~658 minecraft:light_gray_concrete replace
fill ~295 ~52 ~659 ~295 ~52 ~660 minecraft:light_gray_concrete replace
fill ~318 ~52 ~662 ~320 ~52 ~662 minecraft:light_gray_concrete replace
fill ~319 ~52 ~663 ~319 ~52 ~664 minecraft:light_gray_concrete replace
setblock ~274 ~53 ~80 minecraft:light_gray_concrete replace
setblock ~94 ~53 ~252 minecraft:light_gray_concrete replace
setblock ~118 ~53 ~272 minecraft:light_gray_concrete replace
setblock ~139 ~53 ~288 minecraft:light_gray_concrete replace
setblock ~154 ~53 ~300 minecraft:light_gray_concrete replace
setblock ~169 ~53 ~324 minecraft:light_gray_concrete replace
setblock ~190 ~53 ~332 minecraft:light_gray_concrete replace
setblock ~193 ~53 ~332 minecraft:light_gray_concrete replace
setblock ~190 ~53 ~344 minecraft:light_gray_concrete replace
setblock ~193 ~53 ~344 minecraft:light_gray_concrete replace
setblock ~211 ~53 ~348 minecraft:light_gray_concrete replace
setblock ~214 ~53 ~348 minecraft:light_gray_concrete replace
setblock ~211 ~53 ~360 minecraft:light_gray_concrete replace
setblock ~214 ~53 ~360 minecraft:light_gray_concrete replace
setblock ~262 ~53 ~368 minecraft:light_gray_concrete replace
setblock ~265 ~53 ~368 minecraft:light_gray_concrete replace
setblock ~262 ~53 ~372 minecraft:light_gray_concrete replace
setblock ~265 ~53 ~372 minecraft:light_gray_concrete replace
setblock ~251 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~253 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~264 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~266 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~281 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~283 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~298 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~300 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~235 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~238 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~271 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~307 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~235 ~53 ~388 minecraft:light_gray_concrete replace
setblock ~238 ~53 ~388 minecraft:light_gray_concrete replace
setblock ~279 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~281 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~295 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~297 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~271 ~53 ~392 minecraft:light_gray_concrete replace
setblock ~307 ~53 ~392 minecraft:light_gray_concrete replace
setblock ~310 ~53 ~396 minecraft:light_gray_concrete replace
setblock ~277 ~53 ~400 minecraft:light_gray_concrete replace
setblock ~298 ~53 ~404 minecraft:light_gray_concrete replace
setblock ~271 ~53 ~408 minecraft:light_gray_concrete replace
setblock ~91 ~53 ~416 minecraft:light_gray_concrete replace
setblock ~115 ~53 ~420 minecraft:light_gray_concrete replace
setblock ~136 ~53 ~424 minecraft:light_gray_concrete replace
setblock ~160 ~53 ~428 minecraft:light_gray_concrete replace
setblock ~181 ~53 ~432 minecraft:light_gray_concrete replace
setblock ~205 ~53 ~436 minecraft:light_gray_concrete replace
setblock ~232 ~53 ~440 minecraft:light_gray_concrete replace
setblock ~256 ~53 ~444 minecraft:light_gray_concrete replace
setblock ~268 ~53 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~53 ~452 minecraft:light_gray_concrete replace
setblock ~112 ~53 ~456 minecraft:light_gray_concrete replace
setblock ~133 ~53 ~460 minecraft:light_gray_concrete replace
setblock ~157 ~53 ~464 minecraft:light_gray_concrete replace
setblock ~178 ~53 ~468 minecraft:light_gray_concrete replace
setblock ~202 ~53 ~472 minecraft:light_gray_concrete replace
setblock ~226 ~53 ~476 minecraft:light_gray_concrete replace
setblock ~253 ~53 ~480 minecraft:light_gray_concrete replace
setblock ~289 ~53 ~484 minecraft:light_gray_concrete replace
setblock ~316 ~53 ~488 minecraft:light_gray_concrete replace
setblock ~85 ~53 ~492 minecraft:light_gray_concrete replace
setblock ~109 ~53 ~496 minecraft:light_gray_concrete replace
setblock ~130 ~53 ~500 minecraft:light_gray_concrete replace
setblock ~151 ~53 ~504 minecraft:light_gray_concrete replace
setblock ~175 ~53 ~508 minecraft:light_gray_concrete replace
setblock ~199 ~53 ~512 minecraft:light_gray_concrete replace
setblock ~223 ~53 ~516 minecraft:light_gray_concrete replace
setblock ~250 ~53 ~520 minecraft:light_gray_concrete replace
setblock ~286 ~53 ~524 minecraft:light_gray_concrete replace
setblock ~313 ~53 ~528 minecraft:light_gray_concrete replace
setblock ~82 ~53 ~532 minecraft:light_gray_concrete replace
setblock ~106 ~53 ~536 minecraft:light_gray_concrete replace
setblock ~127 ~53 ~540 minecraft:light_gray_concrete replace
setblock ~148 ~53 ~544 minecraft:light_gray_concrete replace
setblock ~172 ~53 ~548 minecraft:light_gray_concrete replace
setblock ~196 ~53 ~552 minecraft:light_gray_concrete replace
setblock ~220 ~53 ~556 minecraft:light_gray_concrete replace
setblock ~244 ~53 ~560 minecraft:light_gray_concrete replace
setblock ~283 ~53 ~564 minecraft:light_gray_concrete replace
setblock ~304 ~53 ~568 minecraft:light_gray_concrete replace
setblock ~79 ~53 ~572 minecraft:light_gray_concrete replace
setblock ~103 ~53 ~576 minecraft:light_gray_concrete replace
setblock ~124 ~53 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~53 ~584 minecraft:light_gray_concrete replace
setblock ~166 ~53 ~588 minecraft:light_gray_concrete replace
setblock ~187 ~53 ~592 minecraft:light_gray_concrete replace
setblock ~217 ~53 ~596 minecraft:light_gray_concrete replace
setblock ~241 ~53 ~600 minecraft:light_gray_concrete replace
setblock ~280 ~53 ~604 minecraft:light_gray_concrete replace
setblock ~301 ~53 ~608 minecraft:light_gray_concrete replace
setblock ~100 ~53 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~53 ~616 minecraft:light_gray_concrete replace
setblock ~142 ~53 ~620 minecraft:light_gray_concrete replace
setblock ~163 ~53 ~624 minecraft:light_gray_concrete replace
setblock ~184 ~53 ~628 minecraft:light_gray_concrete replace
setblock ~208 ~53 ~632 minecraft:light_gray_concrete replace
setblock ~247 ~53 ~636 minecraft:light_gray_concrete replace
setblock ~259 ~53 ~640 minecraft:light_gray_concrete replace
setblock ~292 ~53 ~644 minecraft:light_gray_concrete replace
setblock ~107 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~109 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~124 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~126 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~141 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~143 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~157 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~159 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~174 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~176 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~191 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~193 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~208 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~210 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~225 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~227 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~94 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~118 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~139 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~154 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~169 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~229 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~322 ~53 ~652 minecraft:light_gray_concrete replace
setblock ~97 ~53 ~656 minecraft:light_gray_concrete replace
setblock ~295 ~53 ~660 minecraft:light_gray_concrete replace
setblock ~319 ~53 ~664 minecraft:light_gray_concrete replace
fill ~273 ~54 ~76 ~273 ~54 ~80 minecraft:light_gray_concrete replace
fill ~93 ~54 ~248 ~93 ~54 ~648 minecraft:light_gray_concrete replace
fill ~117 ~54 ~268 ~117 ~54 ~648 minecraft:light_gray_concrete replace
fill ~138 ~54 ~284 ~138 ~54 ~648 minecraft:light_gray_concrete replace
fill ~153 ~54 ~296 ~153 ~54 ~648 minecraft:light_gray_concrete replace
fill ~168 ~54 ~320 ~168 ~54 ~648 minecraft:light_gray_concrete replace
fill ~192 ~54 ~324 ~192 ~54 ~344 minecraft:light_gray_concrete replace
fill ~189 ~54 ~328 ~189 ~54 ~344 minecraft:light_gray_concrete replace
fill ~213 ~54 ~340 ~213 ~54 ~360 minecraft:light_gray_concrete replace
fill ~210 ~54 ~344 ~210 ~54 ~360 minecraft:light_gray_concrete replace
fill ~264 ~54 ~356 ~264 ~54 ~372 minecraft:light_gray_concrete replace
fill ~261 ~54 ~360 ~261 ~54 ~372 minecraft:light_gray_concrete replace
fill ~306 ~54 ~364 ~306 ~54 ~392 minecraft:light_gray_concrete replace
fill ~270 ~54 ~368 ~270 ~54 ~408 minecraft:light_gray_concrete replace
fill ~237 ~54 ~372 ~237 ~54 ~388 minecraft:light_gray_concrete replace
fill ~234 ~54 ~376 ~234 ~54 ~388 minecraft:light_gray_concrete replace
fill ~309 ~54 ~392 ~309 ~54 ~396 minecraft:light_gray_concrete replace
fill ~276 ~54 ~396 ~276 ~54 ~400 minecraft:light_gray_concrete replace
fill ~297 ~54 ~400 ~297 ~54 ~404 minecraft:light_gray_concrete replace
fill ~90 ~54 ~412 ~90 ~54 ~416 minecraft:light_gray_concrete replace
fill ~114 ~54 ~416 ~114 ~54 ~420 minecraft:light_gray_concrete replace
fill ~135 ~54 ~420 ~135 ~54 ~424 minecraft:light_gray_concrete replace
fill ~159 ~54 ~424 ~159 ~54 ~428 minecraft:light_gray_concrete replace
fill ~180 ~54 ~428 ~180 ~54 ~432 minecraft:light_gray_concrete replace
fill ~204 ~54 ~432 ~204 ~54 ~436 minecraft:light_gray_concrete replace
fill ~231 ~54 ~436 ~231 ~54 ~440 minecraft:light_gray_concrete replace
fill ~255 ~54 ~440 ~255 ~54 ~444 minecraft:light_gray_concrete replace
fill ~267 ~54 ~444 ~267 ~54 ~448 minecraft:light_gray_concrete replace
fill ~87 ~54 ~448 ~87 ~54 ~452 minecraft:light_gray_concrete replace
fill ~111 ~54 ~452 ~111 ~54 ~456 minecraft:light_gray_concrete replace
fill ~132 ~54 ~456 ~132 ~54 ~460 minecraft:light_gray_concrete replace
fill ~156 ~54 ~460 ~156 ~54 ~464 minecraft:light_gray_concrete replace
fill ~177 ~54 ~464 ~177 ~54 ~468 minecraft:light_gray_concrete replace
fill ~201 ~54 ~468 ~201 ~54 ~472 minecraft:light_gray_concrete replace
fill ~225 ~54 ~472 ~225 ~54 ~476 minecraft:light_gray_concrete replace
fill ~252 ~54 ~476 ~252 ~54 ~480 minecraft:light_gray_concrete replace
fill ~288 ~54 ~480 ~288 ~54 ~484 minecraft:light_gray_concrete replace
fill ~315 ~54 ~484 ~315 ~54 ~488 minecraft:light_gray_concrete replace
fill ~84 ~54 ~488 ~84 ~54 ~492 minecraft:light_gray_concrete replace
fill ~108 ~54 ~492 ~108 ~54 ~496 minecraft:light_gray_concrete replace
fill ~129 ~54 ~496 ~129 ~54 ~500 minecraft:light_gray_concrete replace
fill ~150 ~54 ~500 ~150 ~54 ~504 minecraft:light_gray_concrete replace
fill ~174 ~54 ~504 ~174 ~54 ~508 minecraft:light_gray_concrete replace
fill ~198 ~54 ~508 ~198 ~54 ~512 minecraft:light_gray_concrete replace
fill ~222 ~54 ~512 ~222 ~54 ~516 minecraft:light_gray_concrete replace
fill ~249 ~54 ~516 ~249 ~54 ~520 minecraft:light_gray_concrete replace
fill ~285 ~54 ~520 ~285 ~54 ~524 minecraft:light_gray_concrete replace
fill ~312 ~54 ~524 ~312 ~54 ~528 minecraft:light_gray_concrete replace
fill ~81 ~54 ~528 ~81 ~54 ~532 minecraft:light_gray_concrete replace
fill ~105 ~54 ~532 ~105 ~54 ~536 minecraft:light_gray_concrete replace
fill ~126 ~54 ~536 ~126 ~54 ~540 minecraft:light_gray_concrete replace
fill ~147 ~54 ~540 ~147 ~54 ~544 minecraft:light_gray_concrete replace
fill ~171 ~54 ~544 ~171 ~54 ~548 minecraft:light_gray_concrete replace
fill ~195 ~54 ~548 ~195 ~54 ~552 minecraft:light_gray_concrete replace
fill ~219 ~54 ~552 ~219 ~54 ~556 minecraft:light_gray_concrete replace
fill ~243 ~54 ~556 ~243 ~54 ~560 minecraft:light_gray_concrete replace
fill ~282 ~54 ~560 ~282 ~54 ~564 minecraft:light_gray_concrete replace
fill ~303 ~54 ~564 ~303 ~54 ~568 minecraft:light_gray_concrete replace
fill ~78 ~54 ~568 ~78 ~54 ~572 minecraft:light_gray_concrete replace
fill ~102 ~54 ~572 ~102 ~54 ~576 minecraft:light_gray_concrete replace
fill ~123 ~54 ~576 ~123 ~54 ~580 minecraft:light_gray_concrete replace
fill ~144 ~54 ~580 ~144 ~54 ~584 minecraft:light_gray_concrete replace
fill ~165 ~54 ~584 ~165 ~54 ~588 minecraft:light_gray_concrete replace
fill ~186 ~54 ~588 ~186 ~54 ~592 minecraft:light_gray_concrete replace
fill ~216 ~54 ~592 ~216 ~54 ~596 minecraft:light_gray_concrete replace
fill ~240 ~54 ~596 ~240 ~54 ~600 minecraft:light_gray_concrete replace
fill ~279 ~54 ~600 ~279 ~54 ~604 minecraft:light_gray_concrete replace
fill ~300 ~54 ~604 ~300 ~54 ~608 minecraft:light_gray_concrete replace
fill ~99 ~54 ~608 ~99 ~54 ~612 minecraft:light_gray_concrete replace
fill ~120 ~54 ~612 ~120 ~54 ~616 minecraft:light_gray_concrete replace
fill ~141 ~54 ~616 ~141 ~54 ~620 minecraft:light_gray_concrete replace
fill ~162 ~54 ~620 ~162 ~54 ~624 minecraft:light_gray_concrete replace
fill ~183 ~54 ~624 ~183 ~54 ~628 minecraft:light_gray_concrete replace
fill ~207 ~54 ~628 ~207 ~54 ~632 minecraft:light_gray_concrete replace
fill ~246 ~54 ~632 ~246 ~54 ~636 minecraft:light_gray_concrete replace
fill ~258 ~54 ~636 ~258 ~54 ~640 minecraft:light_gray_concrete replace
fill ~291 ~54 ~640 ~291 ~54 ~644 minecraft:light_gray_concrete replace
fill ~228 ~54 ~644 ~228 ~54 ~648 minecraft:light_gray_concrete replace
fill ~321 ~54 ~648 ~321 ~54 ~652 minecraft:light_gray_concrete replace
fill ~96 ~54 ~652 ~96 ~54 ~656 minecraft:light_gray_concrete replace
fill ~294 ~54 ~656 ~294 ~54 ~660 minecraft:light_gray_concrete replace
fill ~318 ~54 ~660 ~318 ~54 ~664 minecraft:light_gray_concrete replace
setblock ~273 ~55 ~75 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~247 minecraft:light_gray_concrete replace
setblock ~94 ~55 ~252 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~265 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~267 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~267 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~269 minecraft:light_gray_concrete replace
setblock ~118 ~55 ~272 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~281 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~281 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~283 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~283 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~283 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~285 minecraft:light_gray_concrete replace
setblock ~139 ~55 ~288 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~295 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~297 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~297 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~297 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~299 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~299 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~299 minecraft:light_gray_concrete replace
setblock ~154 ~55 ~300 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~319 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~55 ~323 minecraft:light_gray_concrete replace
setblock ~169 ~55 ~324 minecraft:light_gray_concrete replace
setblock ~189 ~55 ~327 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~193 ~55 ~332 minecraft:light_gray_concrete replace
setblock ~213 ~55 ~339 minecraft:light_gray_concrete replace
setblock ~210 ~55 ~343 minecraft:light_gray_concrete replace
setblock ~190 ~55 ~344 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~214 ~55 ~348 minecraft:light_gray_concrete replace
setblock ~264 ~55 ~355 minecraft:light_gray_concrete replace
setblock ~264 ~55 ~357 minecraft:light_gray_concrete replace
setblock ~261 ~55 ~359 minecraft:light_gray_concrete replace
setblock ~264 ~55 ~359 minecraft:light_gray_concrete replace
setblock ~211 ~55 ~360 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~261 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~306 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~367 minecraft:light_gray_concrete replace
setblock ~265 ~55 ~368 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~369 minecraft:light_gray_concrete replace
setblock ~237 ~55 ~371 minecraft:light_gray_concrete replace
setblock ~262 ~55 ~372 minecraft:light_gray_concrete replace
setblock ~237 ~55 ~373 minecraft:light_gray_concrete replace
setblock ~234 ~55 ~375 minecraft:light_gray_concrete replace
setblock ~237 ~55 ~375 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~234 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~238 ~55 ~380 minecraft:light_gray_concrete replace
setblock ~271 ~55 ~380 minecraft:light_gray_concrete replace
setblock ~307 ~55 ~380 minecraft:light_gray_concrete replace
setblock ~235 ~55 ~388 minecraft:light_gray_concrete replace
setblock ~309 ~55 ~391 minecraft:light_gray_concrete replace
setblock ~271 ~55 ~392 minecraft:light_gray_concrete replace
setblock ~307 ~55 ~392 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~276 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~297 ~55 ~399 minecraft:light_gray_concrete replace
setblock ~271 ~55 ~408 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~90 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~114 ~55 ~415 minecraft:light_gray_concrete replace
setblock ~135 ~55 ~419 minecraft:light_gray_concrete replace
setblock ~159 ~55 ~423 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~180 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~204 ~55 ~431 minecraft:light_gray_concrete replace
setblock ~231 ~55 ~435 minecraft:light_gray_concrete replace
setblock ~255 ~55 ~439 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~267 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~55 ~447 minecraft:light_gray_concrete replace
setblock ~111 ~55 ~451 minecraft:light_gray_concrete replace
setblock ~132 ~55 ~455 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~156 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~177 ~55 ~463 minecraft:light_gray_concrete replace
setblock ~201 ~55 ~467 minecraft:light_gray_concrete replace
setblock ~225 ~55 ~471 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~252 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~288 ~55 ~479 minecraft:light_gray_concrete replace
setblock ~315 ~55 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~55 ~487 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~129 ~55 ~495 minecraft:light_gray_concrete replace
setblock ~150 ~55 ~499 minecraft:light_gray_concrete replace
setblock ~174 ~55 ~503 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~198 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~222 ~55 ~511 minecraft:light_gray_concrete replace
setblock ~249 ~55 ~515 minecraft:light_gray_concrete replace
setblock ~285 ~55 ~519 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~312 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~55 ~527 minecraft:light_gray_concrete replace
setblock ~105 ~55 ~531 minecraft:light_gray_concrete replace
setblock ~126 ~55 ~535 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~147 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~171 ~55 ~543 minecraft:light_gray_concrete replace
setblock ~195 ~55 ~547 minecraft:light_gray_concrete replace
setblock ~219 ~55 ~551 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~243 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~282 ~55 ~559 minecraft:light_gray_concrete replace
setblock ~303 ~55 ~563 minecraft:light_gray_concrete replace
setblock ~78 ~55 ~567 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~123 ~55 ~575 minecraft:light_gray_concrete replace
setblock ~144 ~55 ~579 minecraft:light_gray_concrete replace
setblock ~165 ~55 ~583 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~186 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~216 ~55 ~591 minecraft:light_gray_concrete replace
setblock ~240 ~55 ~595 minecraft:light_gray_concrete replace
setblock ~279 ~55 ~599 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~300 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~99 ~55 ~607 minecraft:light_gray_concrete replace
setblock ~120 ~55 ~611 minecraft:light_gray_concrete replace
setblock ~141 ~55 ~615 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~162 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~183 ~55 ~623 minecraft:light_gray_concrete replace
setblock ~207 ~55 ~627 minecraft:light_gray_concrete replace
setblock ~246 ~55 ~631 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~258 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~291 ~55 ~639 minecraft:light_gray_concrete replace
setblock ~228 ~55 ~643 minecraft:light_gray_concrete replace
setblock ~321 ~55 ~647 minecraft:light_gray_concrete replace
setblock ~96 ~55 ~651 minecraft:light_gray_concrete replace
setblock ~294 ~55 ~655 minecraft:light_gray_concrete replace
setblock ~318 ~55 ~659 minecraft:light_gray_concrete replace
fill ~169 ~56 ~72 ~169 ~56 ~73 minecraft:light_gray_concrete replace
fill ~168 ~56 ~74 ~273 ~56 ~74 minecraft:light_gray_concrete replace
fill ~79 ~56 ~244 ~79 ~56 ~245 minecraft:light_gray_concrete replace
fill ~78 ~56 ~246 ~93 ~56 ~246 minecraft:light_gray_concrete replace
fill ~82 ~56 ~264 ~82 ~56 ~265 minecraft:light_gray_concrete replace
fill ~81 ~56 ~266 ~117 ~56 ~266 minecraft:light_gray_concrete replace
fill ~85 ~56 ~280 ~85 ~56 ~281 minecraft:light_gray_concrete replace
fill ~84 ~56 ~282 ~138 ~56 ~282 minecraft:light_gray_concrete replace
fill ~88 ~56 ~292 ~88 ~56 ~293 minecraft:light_gray_concrete replace
fill ~87 ~56 ~294 ~153 ~56 ~294 minecraft:light_gray_concrete replace
fill ~91 ~56 ~316 ~91 ~56 ~317 minecraft:light_gray_concrete replace
fill ~90 ~56 ~318 ~168 ~56 ~318 minecraft:light_gray_concrete replace
fill ~100 ~56 ~320 ~100 ~56 ~321 minecraft:light_gray_concrete replace
fill ~99 ~56 ~322 ~192 ~56 ~322 minecraft:light_gray_concrete replace
fill ~100 ~56 ~324 ~100 ~56 ~325 minecraft:light_gray_concrete replace
fill ~99 ~56 ~326 ~189 ~56 ~326 minecraft:light_gray_concrete replace
fill ~118 ~56 ~336 ~118 ~56 ~337 minecraft:light_gray_concrete replace
fill ~117 ~56 ~338 ~213 ~56 ~338 minecraft:light_gray_concrete replace
fill ~118 ~56 ~340 ~118 ~56 ~341 minecraft:light_gray_concrete replace
fill ~117 ~56 ~342 ~210 ~56 ~342 minecraft:light_gray_concrete replace
fill ~163 ~56 ~352 ~163 ~56 ~353 minecraft:light_gray_concrete replace
fill ~162 ~56 ~354 ~264 ~56 ~354 minecraft:light_gray_concrete replace
fill ~163 ~56 ~356 ~163 ~56 ~357 minecraft:light_gray_concrete replace
fill ~162 ~56 ~358 ~261 ~56 ~358 minecraft:light_gray_concrete replace
fill ~199 ~56 ~360 ~199 ~56 ~361 minecraft:light_gray_concrete replace
fill ~198 ~56 ~362 ~306 ~56 ~362 minecraft:light_gray_concrete replace
fill ~169 ~56 ~364 ~169 ~56 ~365 minecraft:light_gray_concrete replace
fill ~168 ~56 ~366 ~270 ~56 ~366 minecraft:light_gray_concrete replace
fill ~139 ~56 ~368 ~139 ~56 ~369 minecraft:light_gray_concrete replace
fill ~138 ~56 ~370 ~237 ~56 ~370 minecraft:light_gray_concrete replace
fill ~139 ~56 ~372 ~139 ~56 ~373 minecraft:light_gray_concrete replace
fill ~138 ~56 ~374 ~234 ~56 ~374 minecraft:light_gray_concrete replace
fill ~199 ~56 ~388 ~199 ~56 ~389 minecraft:light_gray_concrete replace
fill ~198 ~56 ~390 ~309 ~56 ~390 minecraft:light_gray_concrete replace
fill ~169 ~56 ~392 ~169 ~56 ~393 minecraft:light_gray_concrete replace
fill ~168 ~56 ~394 ~276 ~56 ~394 minecraft:light_gray_concrete replace
fill ~190 ~56 ~396 ~190 ~56 ~397 minecraft:light_gray_concrete replace
fill ~189 ~56 ~398 ~297 ~56 ~398 minecraft:light_gray_concrete replace
fill ~79 ~56 ~408 ~79 ~56 ~409 minecraft:light_gray_concrete replace
fill ~78 ~56 ~410 ~90 ~56 ~410 minecraft:light_gray_concrete replace
fill ~82 ~56 ~412 ~82 ~56 ~413 minecraft:light_gray_concrete replace
fill ~81 ~56 ~414 ~114 ~56 ~414 minecraft:light_gray_concrete replace
fill ~85 ~56 ~416 ~85 ~56 ~417 minecraft:light_gray_concrete replace
fill ~84 ~56 ~418 ~135 ~56 ~418 minecraft:light_gray_concrete replace
fill ~88 ~56 ~420 ~88 ~56 ~421 minecraft:light_gray_concrete replace
fill ~87 ~56 ~422 ~159 ~56 ~422 minecraft:light_gray_concrete replace
fill ~91 ~56 ~424 ~91 ~56 ~425 minecraft:light_gray_concrete replace
fill ~90 ~56 ~426 ~180 ~56 ~426 minecraft:light_gray_concrete replace
fill ~112 ~56 ~428 ~112 ~56 ~429 minecraft:light_gray_concrete replace
fill ~111 ~56 ~430 ~204 ~56 ~430 minecraft:light_gray_concrete replace
fill ~136 ~56 ~432 ~136 ~56 ~433 minecraft:light_gray_concrete replace
fill ~135 ~56 ~434 ~231 ~56 ~434 minecraft:light_gray_concrete replace
fill ~157 ~56 ~436 ~157 ~56 ~437 minecraft:light_gray_concrete replace
fill ~156 ~56 ~438 ~255 ~56 ~438 minecraft:light_gray_concrete replace
fill ~166 ~56 ~440 ~166 ~56 ~441 minecraft:light_gray_concrete replace
fill ~165 ~56 ~442 ~267 ~56 ~442 minecraft:light_gray_concrete replace
fill ~79 ~56 ~444 ~79 ~56 ~445 minecraft:light_gray_concrete replace
fill ~78 ~56 ~446 ~87 ~56 ~446 minecraft:light_gray_concrete replace
fill ~82 ~56 ~448 ~82 ~56 ~449 minecraft:light_gray_concrete replace
fill ~81 ~56 ~450 ~111 ~56 ~450 minecraft:light_gray_concrete replace
fill ~85 ~56 ~452 ~85 ~56 ~453 minecraft:light_gray_concrete replace
fill ~84 ~56 ~454 ~132 ~56 ~454 minecraft:light_gray_concrete replace
fill ~88 ~56 ~456 ~88 ~56 ~457 minecraft:light_gray_concrete replace
fill ~87 ~56 ~458 ~156 ~56 ~458 minecraft:light_gray_concrete replace
fill ~91 ~56 ~460 ~91 ~56 ~461 minecraft:light_gray_concrete replace
fill ~90 ~56 ~462 ~177 ~56 ~462 minecraft:light_gray_concrete replace
fill ~109 ~56 ~464 ~109 ~56 ~465 minecraft:light_gray_concrete replace
fill ~108 ~56 ~466 ~201 ~56 ~466 minecraft:light_gray_concrete replace
fill ~130 ~56 ~468 ~130 ~56 ~469 minecraft:light_gray_concrete replace
fill ~129 ~56 ~470 ~225 ~56 ~470 minecraft:light_gray_concrete replace
fill ~154 ~56 ~472 ~154 ~56 ~473 minecraft:light_gray_concrete replace
fill ~153 ~56 ~474 ~252 ~56 ~474 minecraft:light_gray_concrete replace
fill ~181 ~56 ~476 ~181 ~56 ~477 minecraft:light_gray_concrete replace
fill ~180 ~56 ~478 ~288 ~56 ~478 minecraft:light_gray_concrete replace
fill ~205 ~56 ~480 ~205 ~56 ~481 minecraft:light_gray_concrete replace
fill ~204 ~56 ~482 ~315 ~56 ~482 minecraft:light_gray_concrete replace
fill ~79 ~56 ~484 ~79 ~56 ~485 minecraft:light_gray_concrete replace
fill ~78 ~56 ~486 ~84 ~56 ~486 minecraft:light_gray_concrete replace
fill ~82 ~56 ~488 ~82 ~56 ~489 minecraft:light_gray_concrete replace
fill ~81 ~56 ~490 ~108 ~56 ~490 minecraft:light_gray_concrete replace
fill ~85 ~56 ~492 ~85 ~56 ~493 minecraft:light_gray_concrete replace
fill ~84 ~56 ~494 ~129 ~56 ~494 minecraft:light_gray_concrete replace
fill ~88 ~56 ~496 ~88 ~56 ~497 minecraft:light_gray_concrete replace
fill ~87 ~56 ~498 ~150 ~56 ~498 minecraft:light_gray_concrete replace
fill ~91 ~56 ~500 ~91 ~56 ~501 minecraft:light_gray_concrete replace
fill ~90 ~56 ~502 ~174 ~56 ~502 minecraft:light_gray_concrete replace
fill ~106 ~56 ~504 ~106 ~56 ~505 minecraft:light_gray_concrete replace
fill ~105 ~56 ~506 ~198 ~56 ~506 minecraft:light_gray_concrete replace
fill ~127 ~56 ~508 ~127 ~56 ~509 minecraft:light_gray_concrete replace
fill ~126 ~56 ~510 ~222 ~56 ~510 minecraft:light_gray_concrete replace
fill ~151 ~56 ~512 ~151 ~56 ~513 minecraft:light_gray_concrete replace
fill ~150 ~56 ~514 ~249 ~56 ~514 minecraft:light_gray_concrete replace
fill ~178 ~56 ~516 ~178 ~56 ~517 minecraft:light_gray_concrete replace
fill ~177 ~56 ~518 ~285 ~56 ~518 minecraft:light_gray_concrete replace
fill ~202 ~56 ~520 ~202 ~56 ~521 minecraft:light_gray_concrete replace
fill ~201 ~56 ~522 ~312 ~56 ~522 minecraft:light_gray_concrete replace
fill ~79 ~56 ~524 ~79 ~56 ~525 minecraft:light_gray_concrete replace
fill ~78 ~56 ~526 ~81 ~56 ~526 minecraft:light_gray_concrete replace
fill ~82 ~56 ~528 ~82 ~56 ~529 minecraft:light_gray_concrete replace
fill ~81 ~56 ~530 ~105 ~56 ~530 minecraft:light_gray_concrete replace
fill ~85 ~56 ~532 ~85 ~56 ~533 minecraft:light_gray_concrete replace
fill ~84 ~56 ~534 ~126 ~56 ~534 minecraft:light_gray_concrete replace
fill ~88 ~56 ~536 ~88 ~56 ~537 minecraft:light_gray_concrete replace
fill ~87 ~56 ~538 ~147 ~56 ~538 minecraft:light_gray_concrete replace
fill ~91 ~56 ~540 ~91 ~56 ~541 minecraft:light_gray_concrete replace
fill ~90 ~56 ~542 ~171 ~56 ~542 minecraft:light_gray_concrete replace
fill ~103 ~56 ~544 ~103 ~56 ~545 minecraft:light_gray_concrete replace
fill ~102 ~56 ~546 ~195 ~56 ~546 minecraft:light_gray_concrete replace
fill ~124 ~56 ~548 ~124 ~56 ~549 minecraft:light_gray_concrete replace
fill ~123 ~56 ~550 ~219 ~56 ~550 minecraft:light_gray_concrete replace
fill ~145 ~56 ~552 ~145 ~56 ~553 minecraft:light_gray_concrete replace
fill ~144 ~56 ~554 ~243 ~56 ~554 minecraft:light_gray_concrete replace
fill ~175 ~56 ~556 ~175 ~56 ~557 minecraft:light_gray_concrete replace
fill ~174 ~56 ~558 ~282 ~56 ~558 minecraft:light_gray_concrete replace
fill ~196 ~56 ~560 ~196 ~56 ~561 minecraft:light_gray_concrete replace
fill ~195 ~56 ~562 ~303 ~56 ~562 minecraft:light_gray_concrete replace
fill ~79 ~56 ~564 ~79 ~56 ~565 minecraft:light_gray_concrete replace
fill ~78 ~56 ~566 ~80 ~56 ~566 minecraft:light_gray_concrete replace
fill ~82 ~56 ~568 ~82 ~56 ~569 minecraft:light_gray_concrete replace
fill ~81 ~56 ~570 ~102 ~56 ~570 minecraft:light_gray_concrete replace
fill ~85 ~56 ~572 ~85 ~56 ~573 minecraft:light_gray_concrete replace
fill ~84 ~56 ~574 ~123 ~56 ~574 minecraft:light_gray_concrete replace
fill ~88 ~56 ~576 ~88 ~56 ~577 minecraft:light_gray_concrete replace
fill ~87 ~56 ~578 ~144 ~56 ~578 minecraft:light_gray_concrete replace
fill ~91 ~56 ~580 ~91 ~56 ~581 minecraft:light_gray_concrete replace
fill ~90 ~56 ~582 ~165 ~56 ~582 minecraft:light_gray_concrete replace
fill ~97 ~56 ~584 ~97 ~56 ~585 minecraft:light_gray_concrete replace
fill ~96 ~56 ~586 ~186 ~56 ~586 minecraft:light_gray_concrete replace
fill ~121 ~56 ~588 ~121 ~56 ~589 minecraft:light_gray_concrete replace
fill ~120 ~56 ~590 ~216 ~56 ~590 minecraft:light_gray_concrete replace
fill ~142 ~56 ~592 ~142 ~56 ~593 minecraft:light_gray_concrete replace
fill ~141 ~56 ~594 ~240 ~56 ~594 minecraft:light_gray_concrete replace
fill ~172 ~56 ~596 ~172 ~56 ~597 minecraft:light_gray_concrete replace
fill ~171 ~56 ~598 ~279 ~56 ~598 minecraft:light_gray_concrete replace
fill ~193 ~56 ~600 ~193 ~56 ~601 minecraft:light_gray_concrete replace
fill ~192 ~56 ~602 ~300 ~56 ~602 minecraft:light_gray_concrete replace
fill ~82 ~56 ~604 ~82 ~56 ~605 minecraft:light_gray_concrete replace
fill ~81 ~56 ~606 ~99 ~56 ~606 minecraft:light_gray_concrete replace
fill ~85 ~56 ~608 ~85 ~56 ~609 minecraft:light_gray_concrete replace
fill ~84 ~56 ~610 ~120 ~56 ~610 minecraft:light_gray_concrete replace
fill ~88 ~56 ~612 ~88 ~56 ~613 minecraft:light_gray_concrete replace
fill ~87 ~56 ~614 ~141 ~56 ~614 minecraft:light_gray_concrete replace
fill ~91 ~56 ~616 ~91 ~56 ~617 minecraft:light_gray_concrete replace
fill ~90 ~56 ~618 ~162 ~56 ~618 minecraft:light_gray_concrete replace
fill ~94 ~56 ~620 ~94 ~56 ~621 minecraft:light_gray_concrete replace
fill ~93 ~56 ~622 ~183 ~56 ~622 minecraft:light_gray_concrete replace
fill ~115 ~56 ~624 ~115 ~56 ~625 minecraft:light_gray_concrete replace
fill ~114 ~56 ~626 ~207 ~56 ~626 minecraft:light_gray_concrete replace
fill ~148 ~56 ~628 ~148 ~56 ~629 minecraft:light_gray_concrete replace
fill ~147 ~56 ~630 ~246 ~56 ~630 minecraft:light_gray_concrete replace
fill ~160 ~56 ~632 ~160 ~56 ~633 minecraft:light_gray_concrete replace
fill ~159 ~56 ~634 ~258 ~56 ~634 minecraft:light_gray_concrete replace
fill ~184 ~56 ~636 ~184 ~56 ~637 minecraft:light_gray_concrete replace
fill ~183 ~56 ~638 ~291 ~56 ~638 minecraft:light_gray_concrete replace
fill ~133 ~56 ~640 ~133 ~56 ~641 minecraft:light_gray_concrete replace
fill ~132 ~56 ~642 ~228 ~56 ~642 minecraft:light_gray_concrete replace
fill ~211 ~56 ~644 ~211 ~56 ~645 minecraft:light_gray_concrete replace
fill ~210 ~56 ~646 ~321 ~56 ~646 minecraft:light_gray_concrete replace
fill ~79 ~56 ~648 ~79 ~56 ~649 minecraft:light_gray_concrete replace
fill ~78 ~56 ~650 ~96 ~56 ~650 minecraft:light_gray_concrete replace
fill ~187 ~56 ~652 ~187 ~56 ~653 minecraft:light_gray_concrete replace
fill ~186 ~56 ~654 ~294 ~56 ~654 minecraft:light_gray_concrete replace
fill ~208 ~56 ~656 ~208 ~56 ~657 minecraft:light_gray_concrete replace
fill ~207 ~56 ~658 ~318 ~56 ~658 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~72 minecraft:light_gray_concrete replace
setblock ~179 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~181 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~196 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~198 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~213 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~215 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~230 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~232 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~247 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~249 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~264 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~266 ~57 ~74 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~244 minecraft:light_gray_concrete replace
setblock ~81 ~57 ~246 minecraft:light_gray_concrete replace
setblock ~83 ~57 ~246 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~264 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~266 minecraft:light_gray_concrete replace
setblock ~87 ~57 ~266 minecraft:light_gray_concrete replace
setblock ~102 ~57 ~266 minecraft:light_gray_concrete replace
setblock ~104 ~57 ~266 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~280 minecraft:light_gray_concrete replace
setblock ~89 ~57 ~282 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~282 minecraft:light_gray_concrete replace
setblock ~106 ~57 ~282 minecraft:light_gray_concrete replace
setblock ~108 ~57 ~282 minecraft:light_gray_concrete replace
setblock ~123 ~57 ~282 minecraft:light_gray_concrete replace
setblock ~125 ~57 ~282 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~292 minecraft:light_gray_concrete replace
setblock ~90 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~92 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~107 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~124 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~126 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~141 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~143 ~57 ~294 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~316 minecraft:light_gray_concrete replace
setblock ~102 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~104 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~119 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~121 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~136 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~138 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~153 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~155 ~57 ~318 minecraft:light_gray_concrete replace
setblock ~100 ~57 ~320 minecraft:light_gray_concrete replace
setblock ~116 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~133 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~135 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~150 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~152 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~167 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~184 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~186 ~57 ~322 minecraft:light_gray_concrete replace
setblock ~100 ~57 ~324 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~111 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~126 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~128 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~143 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~145 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~160 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~162 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~177 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~179 ~57 ~326 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~336 minecraft:light_gray_concrete replace
setblock ~120 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~122 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~137 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~154 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~156 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~171 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~173 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~188 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~205 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~207 ~57 ~338 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~340 minecraft:light_gray_concrete replace
setblock ~130 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~132 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~147 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~149 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~164 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~166 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~181 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~183 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~198 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~200 ~57 ~342 minecraft:light_gray_concrete replace
setblock ~163 ~57 ~352 minecraft:light_gray_concrete replace
setblock ~165 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~167 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~182 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~184 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~201 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~216 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~218 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~233 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~235 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~250 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~252 ~57 ~354 minecraft:light_gray_concrete replace
setblock ~163 ~57 ~356 minecraft:light_gray_concrete replace
setblock ~167 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~183 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~185 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~201 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~215 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~217 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~231 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~233 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~247 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~249 ~57 ~358 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~360 minecraft:light_gray_concrete replace
setblock ~207 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~209 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~224 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~226 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~241 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~243 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~258 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~260 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~275 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~277 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~292 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~294 ~57 ~362 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~364 minecraft:light_gray_concrete replace
setblock ~170 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~172 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~187 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~189 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~204 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~206 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~221 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~223 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~238 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~240 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~255 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~257 ~57 ~366 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~368 minecraft:light_gray_concrete replace
setblock ~155 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~157 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~172 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~174 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~189 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~191 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~206 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~208 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~223 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~225 ~57 ~370 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~372 minecraft:light_gray_concrete replace
setblock ~151 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~153 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~168 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~170 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~185 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~187 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~202 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~204 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~219 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~221 ~57 ~374 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~388 minecraft:light_gray_concrete replace
setblock ~215 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~217 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~232 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~234 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~249 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~251 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~266 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~268 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~283 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~285 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~300 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~302 ~57 ~390 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~392 minecraft:light_gray_concrete replace
setblock ~182 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~184 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~201 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~216 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~218 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~233 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~235 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~250 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~252 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~267 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~269 ~57 ~394 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~396 minecraft:light_gray_concrete replace
setblock ~203 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~205 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~220 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~222 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~237 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~239 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~254 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~256 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~271 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~273 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~288 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~290 ~57 ~398 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~408 minecraft:light_gray_concrete replace
setblock ~81 ~57 ~410 minecraft:light_gray_concrete replace
setblock ~83 ~57 ~410 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~412 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~414 minecraft:light_gray_concrete replace
setblock ~90 ~57 ~414 minecraft:light_gray_concrete replace
setblock ~105 ~57 ~414 minecraft:light_gray_concrete replace
setblock ~107 ~57 ~414 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~416 minecraft:light_gray_concrete replace
setblock ~92 ~57 ~418 minecraft:light_gray_concrete replace
setblock ~94 ~57 ~418 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~418 minecraft:light_gray_concrete replace
setblock ~111 ~57 ~418 minecraft:light_gray_concrete replace
setblock ~126 ~57 ~418 minecraft:light_gray_concrete replace
setblock ~128 ~57 ~418 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~420 minecraft:light_gray_concrete replace
setblock ~99 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~101 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~116 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~133 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~135 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~150 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~152 ~57 ~422 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~424 minecraft:light_gray_concrete replace
setblock ~103 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~105 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~120 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~122 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~137 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~154 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~156 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~171 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~173 ~57 ~426 minecraft:light_gray_concrete replace
setblock ~112 ~57 ~428 minecraft:light_gray_concrete replace
setblock ~116 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~132 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~134 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~148 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~150 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~164 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~166 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~180 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~182 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~196 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~198 ~57 ~430 minecraft:light_gray_concrete replace
setblock ~136 ~57 ~432 minecraft:light_gray_concrete replace
setblock ~137 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~154 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~156 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~171 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~173 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~188 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~205 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~207 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~222 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~224 ~57 ~434 minecraft:light_gray_concrete replace
setblock ~157 ~57 ~436 minecraft:light_gray_concrete replace
setblock ~161 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~163 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~178 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~180 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~195 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~197 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~212 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~214 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~229 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~231 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~246 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~248 ~57 ~438 minecraft:light_gray_concrete replace
setblock ~166 ~57 ~440 minecraft:light_gray_concrete replace
setblock ~173 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~175 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~192 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~207 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~209 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~224 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~226 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~241 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~243 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~258 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~260 ~57 ~442 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~444 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~448 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~450 minecraft:light_gray_concrete replace
setblock ~87 ~57 ~450 minecraft:light_gray_concrete replace
setblock ~102 ~57 ~450 minecraft:light_gray_concrete replace
setblock ~104 ~57 ~450 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~452 minecraft:light_gray_concrete replace
setblock ~89 ~57 ~454 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~454 minecraft:light_gray_concrete replace
setblock ~106 ~57 ~454 minecraft:light_gray_concrete replace
setblock ~108 ~57 ~454 minecraft:light_gray_concrete replace
setblock ~123 ~57 ~454 minecraft:light_gray_concrete replace
setblock ~125 ~57 ~454 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~456 minecraft:light_gray_concrete replace
setblock ~96 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~98 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~113 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~115 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~130 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~132 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~147 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~149 ~57 ~458 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~460 minecraft:light_gray_concrete replace
setblock ~100 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~102 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~117 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~119 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~134 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~136 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~151 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~153 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~168 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~170 ~57 ~462 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~464 minecraft:light_gray_concrete replace
setblock ~113 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~115 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~129 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~131 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~145 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~147 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~161 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~163 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~177 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~179 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~193 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~195 ~57 ~466 minecraft:light_gray_concrete replace
setblock ~130 ~57 ~468 minecraft:light_gray_concrete replace
setblock ~131 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~133 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~148 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~150 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~165 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~167 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~182 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~184 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~201 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~216 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~218 ~57 ~470 minecraft:light_gray_concrete replace
setblock ~154 ~57 ~472 minecraft:light_gray_concrete replace
setblock ~158 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~160 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~175 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~177 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~192 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~194 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~209 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~211 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~226 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~228 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~243 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~245 ~57 ~474 minecraft:light_gray_concrete replace
setblock ~181 ~57 ~476 minecraft:light_gray_concrete replace
setblock ~194 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~196 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~211 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~213 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~228 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~230 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~245 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~247 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~262 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~264 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~279 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~281 ~57 ~478 minecraft:light_gray_concrete replace
setblock ~205 ~57 ~480 minecraft:light_gray_concrete replace
setblock ~221 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~223 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~238 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~240 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~255 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~257 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~272 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~274 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~289 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~291 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~306 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~308 ~57 ~482 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~484 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~488 minecraft:light_gray_concrete replace
setblock ~99 ~57 ~490 minecraft:light_gray_concrete replace
setblock ~101 ~57 ~490 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~492 minecraft:light_gray_concrete replace
setblock ~86 ~57 ~494 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~494 minecraft:light_gray_concrete replace
setblock ~103 ~57 ~494 minecraft:light_gray_concrete replace
setblock ~105 ~57 ~494 minecraft:light_gray_concrete replace
setblock ~120 ~57 ~494 minecraft:light_gray_concrete replace
setblock ~122 ~57 ~494 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~496 minecraft:light_gray_concrete replace
setblock ~90 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~92 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~107 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~124 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~126 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~141 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~143 ~57 ~498 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~500 minecraft:light_gray_concrete replace
setblock ~97 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~99 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~114 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~116 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~131 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~133 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~148 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~150 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~165 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~167 ~57 ~502 minecraft:light_gray_concrete replace
setblock ~106 ~57 ~504 minecraft:light_gray_concrete replace
setblock ~110 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~112 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~126 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~128 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~142 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~144 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~158 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~160 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~174 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~176 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~192 ~57 ~506 minecraft:light_gray_concrete replace
setblock ~127 ~57 ~508 minecraft:light_gray_concrete replace
setblock ~128 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~130 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~145 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~147 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~162 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~164 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~179 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~181 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~196 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~198 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~213 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~215 ~57 ~510 minecraft:light_gray_concrete replace
setblock ~151 ~57 ~512 minecraft:light_gray_concrete replace
setblock ~155 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~157 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~172 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~174 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~189 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~191 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~206 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~208 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~223 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~225 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~240 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~242 ~57 ~514 minecraft:light_gray_concrete replace
setblock ~178 ~57 ~516 minecraft:light_gray_concrete replace
setblock ~191 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~193 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~208 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~210 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~225 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~227 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~242 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~244 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~259 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~261 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~276 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~278 ~57 ~518 minecraft:light_gray_concrete replace
setblock ~202 ~57 ~520 minecraft:light_gray_concrete replace
setblock ~218 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~220 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~235 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~237 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~252 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~254 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~269 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~271 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~286 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~288 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~303 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~305 ~57 ~522 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~524 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~528 minecraft:light_gray_concrete replace
setblock ~96 ~57 ~530 minecraft:light_gray_concrete replace
setblock ~98 ~57 ~530 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~532 minecraft:light_gray_concrete replace
setblock ~86 ~57 ~534 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~534 minecraft:light_gray_concrete replace
setblock ~102 ~57 ~534 minecraft:light_gray_concrete replace
setblock ~104 ~57 ~534 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~534 minecraft:light_gray_concrete replace
setblock ~120 ~57 ~534 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~536 minecraft:light_gray_concrete replace
setblock ~104 ~57 ~538 minecraft:light_gray_concrete replace
setblock ~106 ~57 ~538 minecraft:light_gray_concrete replace
setblock ~121 ~57 ~538 minecraft:light_gray_concrete replace
setblock ~123 ~57 ~538 minecraft:light_gray_concrete replace
setblock ~138 ~57 ~538 minecraft:light_gray_concrete replace
setblock ~140 ~57 ~538 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~540 minecraft:light_gray_concrete replace
setblock ~94 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~96 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~111 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~113 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~128 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~130 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~145 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~147 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~162 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~164 ~57 ~542 minecraft:light_gray_concrete replace
setblock ~103 ~57 ~544 minecraft:light_gray_concrete replace
setblock ~107 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~123 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~125 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~141 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~155 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~157 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~171 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~173 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~187 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~189 ~57 ~546 minecraft:light_gray_concrete replace
setblock ~124 ~57 ~548 minecraft:light_gray_concrete replace
setblock ~125 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~127 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~142 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~144 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~159 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~161 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~176 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~178 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~193 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~195 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~210 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~212 ~57 ~550 minecraft:light_gray_concrete replace
setblock ~145 ~57 ~552 minecraft:light_gray_concrete replace
setblock ~149 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~151 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~166 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~168 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~183 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~185 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~200 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~202 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~217 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~219 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~234 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~236 ~57 ~554 minecraft:light_gray_concrete replace
setblock ~175 ~57 ~556 minecraft:light_gray_concrete replace
setblock ~188 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~205 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~207 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~222 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~224 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~239 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~241 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~256 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~258 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~273 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~275 ~57 ~558 minecraft:light_gray_concrete replace
setblock ~196 ~57 ~560 minecraft:light_gray_concrete replace
setblock ~209 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~211 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~226 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~228 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~243 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~245 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~260 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~262 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~277 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~279 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~294 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~296 ~57 ~562 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~564 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~568 minecraft:light_gray_concrete replace
setblock ~93 ~57 ~570 minecraft:light_gray_concrete replace
setblock ~95 ~57 ~570 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~572 minecraft:light_gray_concrete replace
setblock ~97 ~57 ~574 minecraft:light_gray_concrete replace
setblock ~99 ~57 ~574 minecraft:light_gray_concrete replace
setblock ~114 ~57 ~574 minecraft:light_gray_concrete replace
setblock ~116 ~57 ~574 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~576 minecraft:light_gray_concrete replace
setblock ~101 ~57 ~578 minecraft:light_gray_concrete replace
setblock ~103 ~57 ~578 minecraft:light_gray_concrete replace
setblock ~118 ~57 ~578 minecraft:light_gray_concrete replace
setblock ~120 ~57 ~578 minecraft:light_gray_concrete replace
setblock ~135 ~57 ~578 minecraft:light_gray_concrete replace
setblock ~137 ~57 ~578 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~580 minecraft:light_gray_concrete replace
setblock ~105 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~107 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~122 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~124 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~141 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~156 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~158 ~57 ~582 minecraft:light_gray_concrete replace
setblock ~97 ~57 ~584 minecraft:light_gray_concrete replace
setblock ~109 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~111 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~126 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~128 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~143 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~145 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~160 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~162 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~177 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~179 ~57 ~586 minecraft:light_gray_concrete replace
setblock ~121 ~57 ~588 minecraft:light_gray_concrete replace
setblock ~122 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~124 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~139 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~141 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~156 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~158 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~173 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~175 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~190 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~192 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~207 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~209 ~57 ~590 minecraft:light_gray_concrete replace
setblock ~142 ~57 ~592 minecraft:light_gray_concrete replace
setblock ~146 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~148 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~163 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~165 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~180 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~182 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~197 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~214 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~216 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~231 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~233 ~57 ~594 minecraft:light_gray_concrete replace
setblock ~172 ~57 ~596 minecraft:light_gray_concrete replace
setblock ~185 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~187 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~202 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~204 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~219 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~221 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~236 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~238 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~253 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~255 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~270 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~272 ~57 ~598 minecraft:light_gray_concrete replace
setblock ~193 ~57 ~600 minecraft:light_gray_concrete replace
setblock ~206 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~208 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~223 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~225 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~240 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~242 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~257 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~259 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~274 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~276 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~291 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~293 ~57 ~602 minecraft:light_gray_concrete replace
setblock ~82 ~57 ~604 minecraft:light_gray_concrete replace
setblock ~90 ~57 ~606 minecraft:light_gray_concrete replace
setblock ~92 ~57 ~606 minecraft:light_gray_concrete replace
setblock ~85 ~57 ~608 minecraft:light_gray_concrete replace
setblock ~94 ~57 ~610 minecraft:light_gray_concrete replace
setblock ~96 ~57 ~610 minecraft:light_gray_concrete replace
setblock ~111 ~57 ~610 minecraft:light_gray_concrete replace
setblock ~113 ~57 ~610 minecraft:light_gray_concrete replace
setblock ~88 ~57 ~612 minecraft:light_gray_concrete replace
setblock ~98 ~57 ~614 minecraft:light_gray_concrete replace
setblock ~100 ~57 ~614 minecraft:light_gray_concrete replace
setblock ~115 ~57 ~614 minecraft:light_gray_concrete replace
setblock ~117 ~57 ~614 minecraft:light_gray_concrete replace
setblock ~132 ~57 ~614 minecraft:light_gray_concrete replace
setblock ~134 ~57 ~614 minecraft:light_gray_concrete replace
setblock ~91 ~57 ~616 minecraft:light_gray_concrete replace
setblock ~102 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~104 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~119 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~121 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~136 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~138 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~153 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~155 ~57 ~618 minecraft:light_gray_concrete replace
setblock ~94 ~57 ~620 minecraft:light_gray_concrete replace
setblock ~106 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~108 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~123 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~125 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~140 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~142 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~157 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~159 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~174 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~176 ~57 ~622 minecraft:light_gray_concrete replace
setblock ~115 ~57 ~624 minecraft:light_gray_concrete replace
setblock ~119 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~121 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~135 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~137 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~151 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~153 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~167 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~183 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~185 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~201 ~57 ~626 minecraft:light_gray_concrete replace
setblock ~148 ~57 ~628 minecraft:light_gray_concrete replace
setblock ~152 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~154 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~169 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~171 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~186 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~188 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~203 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~205 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~220 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~222 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~237 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~239 ~57 ~630 minecraft:light_gray_concrete replace
setblock ~160 ~57 ~632 minecraft:light_gray_concrete replace
setblock ~164 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~166 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~181 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~183 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~198 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~200 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~215 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~217 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~232 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~234 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~249 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~251 ~57 ~634 minecraft:light_gray_concrete replace
setblock ~184 ~57 ~636 minecraft:light_gray_concrete replace
setblock ~197 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~199 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~214 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~216 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~231 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~233 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~248 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~250 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~265 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~267 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~282 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~284 ~57 ~638 minecraft:light_gray_concrete replace
setblock ~133 ~57 ~640 minecraft:light_gray_concrete replace
setblock ~134 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~136 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~151 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~153 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~168 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~170 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~185 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~187 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~202 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~204 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~219 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~221 ~57 ~642 minecraft:light_gray_concrete replace
setblock ~211 ~57 ~644 minecraft:light_gray_concrete replace
setblock ~227 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~229 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~244 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~246 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~261 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~263 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~278 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~280 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~295 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~297 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~312 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~314 ~57 ~646 minecraft:light_gray_concrete replace
setblock ~79 ~57 ~648 minecraft:light_gray_concrete replace
setblock ~87 ~57 ~650 minecraft:light_gray_concrete replace
setblock ~89 ~57 ~650 minecraft:light_gray_concrete replace
setblock ~187 ~57 ~652 minecraft:light_gray_concrete replace
setblock ~200 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~202 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~217 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~219 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~234 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~236 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~251 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~253 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~268 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~270 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~285 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~287 ~57 ~654 minecraft:light_gray_concrete replace
setblock ~208 ~57 ~656 minecraft:light_gray_concrete replace
setblock ~224 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~226 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~241 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~243 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~258 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~260 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~275 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~277 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~292 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~294 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~309 ~57 ~658 minecraft:light_gray_concrete replace
setblock ~311 ~57 ~658 minecraft:light_gray_concrete replace
fill ~168 ~58 ~72 ~168 ~58 ~396 minecraft:light_gray_concrete replace
fill ~78 ~58 ~244 ~78 ~58 ~652 minecraft:light_gray_concrete replace
fill ~81 ~58 ~264 ~81 ~58 ~608 minecraft:light_gray_concrete replace
fill ~84 ~58 ~280 ~84 ~58 ~612 minecraft:light_gray_concrete replace
fill ~87 ~58 ~292 ~87 ~58 ~616 minecraft:light_gray_concrete replace
fill ~90 ~58 ~316 ~90 ~58 ~620 minecraft:light_gray_concrete replace
fill ~99 ~58 ~320 ~99 ~58 ~328 minecraft:light_gray_concrete replace
fill ~117 ~58 ~336 ~117 ~58 ~344 minecraft:light_gray_concrete replace
fill ~162 ~58 ~352 ~162 ~58 ~360 minecraft:light_gray_concrete replace
fill ~198 ~58 ~360 ~198 ~58 ~392 minecraft:light_gray_concrete replace
fill ~138 ~58 ~368 ~138 ~58 ~376 minecraft:light_gray_concrete replace
fill ~189 ~58 ~396 ~189 ~58 ~400 minecraft:light_gray_concrete replace
fill ~111 ~58 ~428 ~111 ~58 ~432 minecraft:light_gray_concrete replace
fill ~135 ~58 ~432 ~135 ~58 ~436 minecraft:light_gray_concrete replace
fill ~156 ~58 ~436 ~156 ~58 ~440 minecraft:light_gray_concrete replace
fill ~165 ~58 ~440 ~165 ~58 ~444 minecraft:light_gray_concrete replace
fill ~108 ~58 ~464 ~108 ~58 ~468 minecraft:light_gray_concrete replace
fill ~129 ~58 ~468 ~129 ~58 ~472 minecraft:light_gray_concrete replace
fill ~153 ~58 ~472 ~153 ~58 ~476 minecraft:light_gray_concrete replace
fill ~180 ~58 ~476 ~180 ~58 ~480 minecraft:light_gray_concrete replace
fill ~204 ~58 ~480 ~204 ~58 ~484 minecraft:light_gray_concrete replace
fill ~105 ~58 ~504 ~105 ~58 ~508 minecraft:light_gray_concrete replace
fill ~126 ~58 ~508 ~126 ~58 ~512 minecraft:light_gray_concrete replace
fill ~150 ~58 ~512 ~150 ~58 ~516 minecraft:light_gray_concrete replace
fill ~177 ~58 ~516 ~177 ~58 ~520 minecraft:light_gray_concrete replace
fill ~201 ~58 ~520 ~201 ~58 ~524 minecraft:light_gray_concrete replace
fill ~102 ~58 ~544 ~102 ~58 ~548 minecraft:light_gray_concrete replace
fill ~123 ~58 ~548 ~123 ~58 ~552 minecraft:light_gray_concrete replace
fill ~144 ~58 ~552 ~144 ~58 ~556 minecraft:light_gray_concrete replace
fill ~174 ~58 ~556 ~174 ~58 ~560 minecraft:light_gray_concrete replace
fill ~195 ~58 ~560 ~195 ~58 ~564 minecraft:light_gray_concrete replace
fill ~96 ~58 ~584 ~96 ~58 ~588 minecraft:light_gray_concrete replace
fill ~120 ~58 ~588 ~120 ~58 ~592 minecraft:light_gray_concrete replace
fill ~141 ~58 ~592 ~141 ~58 ~596 minecraft:light_gray_concrete replace
fill ~171 ~58 ~596 ~171 ~58 ~600 minecraft:light_gray_concrete replace
fill ~192 ~58 ~600 ~192 ~58 ~604 minecraft:light_gray_concrete replace
fill ~93 ~58 ~620 ~93 ~58 ~624 minecraft:light_gray_concrete replace
fill ~114 ~58 ~624 ~114 ~58 ~628 minecraft:light_gray_concrete replace
fill ~147 ~58 ~628 ~147 ~58 ~632 minecraft:light_gray_concrete replace
fill ~159 ~58 ~632 ~159 ~58 ~636 minecraft:light_gray_concrete replace
fill ~183 ~58 ~636 ~183 ~58 ~640 minecraft:light_gray_concrete replace
fill ~132 ~58 ~640 ~132 ~58 ~644 minecraft:light_gray_concrete replace
fill ~210 ~58 ~644 ~210 ~58 ~648 minecraft:light_gray_concrete replace
fill ~186 ~58 ~652 ~186 ~58 ~656 minecraft:light_gray_concrete replace
fill ~207 ~58 ~656 ~207 ~58 ~660 minecraft:light_gray_concrete replace
setblock ~169 ~59 ~72 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~85 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~87 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~101 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~103 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~117 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~119 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~133 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~135 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~149 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~151 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~165 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~167 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~181 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~183 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~197 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~199 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~213 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~215 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~229 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~231 minecraft:light_gray_concrete replace
setblock ~79 ~59 ~244 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~245 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~247 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~257 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~259 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~261 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~263 minecraft:light_gray_concrete replace
setblock ~82 ~59 ~264 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~273 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~275 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~277 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~277 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~279 minecraft:light_gray_concrete replace
setblock ~168 ~59 ~279 minecraft:light_gray_concrete replace
setblock ~85 ~59 ~280 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~289 minecraft:light_gray_concrete replace
setblock ~78 ~59 ~291 minecraft:light_gray_concrete replace
setblock ~88 ~59 ~292 minecraft:light_gray_concrete replace
setblock ~81 ~59 ~293 minecraft:light_gray_concrete replace
setblock ~84 ~59 ~293 minecraft:light_gray_concrete replace
