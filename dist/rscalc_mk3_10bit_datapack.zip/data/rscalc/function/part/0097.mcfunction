setblock ~100 ~153 ~273 minecraft:redstone_wire replace
fill ~99 ~153 ~274 ~100 ~153 ~274 minecraft:redstone_wire replace
setblock ~102 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~274 ~117 ~153 ~274 minecraft:redstone_wire replace
setblock ~119 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~274 ~134 ~153 ~274 minecraft:redstone_wire replace
setblock ~136 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~153 ~274 ~151 ~153 ~274 minecraft:redstone_wire replace
setblock ~153 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~153 ~274 ~168 ~153 ~274 minecraft:redstone_wire replace
setblock ~170 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~153 ~274 ~185 ~153 ~274 minecraft:redstone_wire replace
setblock ~187 ~153 ~274 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~153 ~274 ~201 ~153 ~274 minecraft:redstone_wire replace
setblock ~100 ~153 ~277 minecraft:redstone_wire replace
fill ~99 ~153 ~278 ~104 ~153 ~278 minecraft:redstone_wire replace
setblock ~106 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~153 ~278 ~121 ~153 ~278 minecraft:redstone_wire replace
setblock ~123 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~153 ~278 ~138 ~153 ~278 minecraft:redstone_wire replace
setblock ~140 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~153 ~278 ~155 ~153 ~278 minecraft:redstone_wire replace
setblock ~157 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~278 ~172 ~153 ~278 minecraft:redstone_wire replace
setblock ~174 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~153 ~278 ~189 ~153 ~278 minecraft:redstone_wire replace
setblock ~191 ~153 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~153 ~278 ~198 ~153 ~278 minecraft:redstone_wire replace
setblock ~100 ~153 ~281 minecraft:redstone_wire replace
fill ~99 ~153 ~282 ~103 ~153 ~282 minecraft:redstone_wire replace
setblock ~105 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~153 ~282 ~119 ~153 ~282 minecraft:redstone_wire replace
setblock ~121 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~282 ~135 ~153 ~282 minecraft:redstone_wire replace
setblock ~137 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~153 ~282 ~151 ~153 ~282 minecraft:redstone_wire replace
setblock ~153 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~153 ~282 ~167 ~153 ~282 minecraft:redstone_wire replace
setblock ~169 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~282 ~183 ~153 ~282 minecraft:redstone_wire replace
setblock ~185 ~153 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~153 ~282 ~195 ~153 ~282 minecraft:redstone_wire replace
setblock ~100 ~153 ~285 minecraft:redstone_wire replace
fill ~99 ~153 ~286 ~109 ~153 ~286 minecraft:redstone_wire replace
setblock ~111 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~153 ~286 ~126 ~153 ~286 minecraft:redstone_wire replace
setblock ~128 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~153 ~286 ~143 ~153 ~286 minecraft:redstone_wire replace
setblock ~145 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~286 ~160 ~153 ~286 minecraft:redstone_wire replace
setblock ~162 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~153 ~286 ~177 ~153 ~286 minecraft:redstone_wire replace
setblock ~179 ~153 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~153 ~286 ~192 ~153 ~286 minecraft:redstone_wire replace
setblock ~97 ~153 ~289 minecraft:redstone_wire replace
fill ~96 ~153 ~290 ~105 ~153 ~290 minecraft:redstone_wire replace
setblock ~107 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~153 ~290 ~122 ~153 ~290 minecraft:redstone_wire replace
setblock ~124 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~153 ~290 ~139 ~153 ~290 minecraft:redstone_wire replace
setblock ~141 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~153 ~290 ~156 ~153 ~290 minecraft:redstone_wire replace
setblock ~158 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~153 ~290 ~173 ~153 ~290 minecraft:redstone_wire replace
setblock ~175 ~153 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~153 ~290 ~189 ~153 ~290 minecraft:redstone_wire replace
setblock ~97 ~153 ~293 minecraft:redstone_wire replace
fill ~96 ~153 ~294 ~109 ~153 ~294 minecraft:redstone_wire replace
setblock ~111 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~153 ~294 ~126 ~153 ~294 minecraft:redstone_wire replace
setblock ~128 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~153 ~294 ~143 ~153 ~294 minecraft:redstone_wire replace
setblock ~145 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~294 ~160 ~153 ~294 minecraft:redstone_wire replace
setblock ~162 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~153 ~294 ~177 ~153 ~294 minecraft:redstone_wire replace
setblock ~179 ~153 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~153 ~294 ~186 ~153 ~294 minecraft:redstone_wire replace
setblock ~97 ~153 ~297 minecraft:redstone_wire replace
fill ~96 ~153 ~298 ~102 ~153 ~298 minecraft:redstone_wire replace
setblock ~104 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~153 ~298 ~119 ~153 ~298 minecraft:redstone_wire replace
setblock ~121 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~298 ~136 ~153 ~298 minecraft:redstone_wire replace
setblock ~138 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~153 ~298 ~153 ~153 ~298 minecraft:redstone_wire replace
setblock ~155 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~153 ~298 ~170 ~153 ~298 minecraft:redstone_wire replace
setblock ~172 ~153 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~153 ~298 ~183 ~153 ~298 minecraft:redstone_wire replace
setblock ~97 ~153 ~301 minecraft:redstone_wire replace
fill ~96 ~153 ~302 ~97 ~153 ~302 minecraft:redstone_wire replace
setblock ~99 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~153 ~302 ~114 ~153 ~302 minecraft:redstone_wire replace
setblock ~116 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~153 ~302 ~131 ~153 ~302 minecraft:redstone_wire replace
setblock ~133 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~153 ~302 ~148 ~153 ~302 minecraft:redstone_wire replace
setblock ~150 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~153 ~302 ~165 ~153 ~302 minecraft:redstone_wire replace
setblock ~167 ~153 ~302 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~153 ~302 ~180 ~153 ~302 minecraft:redstone_wire replace
setblock ~94 ~153 ~305 minecraft:redstone_wire replace
fill ~93 ~153 ~306 ~95 ~153 ~306 minecraft:redstone_wire replace
setblock ~96 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~306 ~110 ~153 ~306 minecraft:redstone_wire replace
setblock ~112 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~306 ~127 ~153 ~306 minecraft:redstone_wire replace
setblock ~129 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~153 ~306 ~144 ~153 ~306 minecraft:redstone_wire replace
setblock ~146 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~153 ~306 ~161 ~153 ~306 minecraft:redstone_wire replace
setblock ~163 ~153 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~153 ~306 ~177 ~153 ~306 minecraft:redstone_wire replace
setblock ~94 ~153 ~309 minecraft:redstone_wire replace
fill ~93 ~153 ~310 ~97 ~153 ~310 minecraft:redstone_wire replace
setblock ~99 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~153 ~310 ~114 ~153 ~310 minecraft:redstone_wire replace
setblock ~116 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~153 ~310 ~131 ~153 ~310 minecraft:redstone_wire replace
setblock ~133 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~153 ~310 ~148 ~153 ~310 minecraft:redstone_wire replace
setblock ~150 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~153 ~310 ~165 ~153 ~310 minecraft:redstone_wire replace
setblock ~167 ~153 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~153 ~310 ~174 ~153 ~310 minecraft:redstone_wire replace
setblock ~94 ~153 ~313 minecraft:redstone_wire replace
setblock ~93 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~153 ~314 ~107 ~153 ~314 minecraft:redstone_wire replace
setblock ~109 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~314 ~124 ~153 ~314 minecraft:redstone_wire replace
setblock ~126 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~314 ~141 ~153 ~314 minecraft:redstone_wire replace
setblock ~143 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~314 ~158 ~153 ~314 minecraft:redstone_wire replace
setblock ~160 ~153 ~314 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~153 ~314 ~171 ~153 ~314 minecraft:redstone_wire replace
setblock ~94 ~153 ~317 minecraft:redstone_wire replace
fill ~93 ~153 ~318 ~102 ~153 ~318 minecraft:redstone_wire replace
setblock ~104 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~153 ~318 ~119 ~153 ~318 minecraft:redstone_wire replace
setblock ~121 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~318 ~136 ~153 ~318 minecraft:redstone_wire replace
setblock ~138 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~153 ~318 ~153 ~153 ~318 minecraft:redstone_wire replace
setblock ~155 ~153 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~153 ~318 ~168 ~153 ~318 minecraft:redstone_wire replace
setblock ~94 ~153 ~321 minecraft:redstone_wire replace
fill ~93 ~153 ~322 ~98 ~153 ~322 minecraft:redstone_wire replace
setblock ~100 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~153 ~322 ~115 ~153 ~322 minecraft:redstone_wire replace
setblock ~117 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~153 ~322 ~132 ~153 ~322 minecraft:redstone_wire replace
setblock ~134 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~153 ~322 ~149 ~153 ~322 minecraft:redstone_wire replace
setblock ~151 ~153 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~153 ~322 ~165 ~153 ~322 minecraft:redstone_wire replace
setblock ~94 ~153 ~325 minecraft:redstone_wire replace
fill ~93 ~153 ~326 ~102 ~153 ~326 minecraft:redstone_wire replace
setblock ~104 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~153 ~326 ~119 ~153 ~326 minecraft:redstone_wire replace
setblock ~121 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~326 ~136 ~153 ~326 minecraft:redstone_wire replace
setblock ~138 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~153 ~326 ~153 ~153 ~326 minecraft:redstone_wire replace
setblock ~155 ~153 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~153 ~326 ~162 ~153 ~326 minecraft:redstone_wire replace
setblock ~94 ~153 ~329 minecraft:redstone_wire replace
fill ~93 ~153 ~330 ~95 ~153 ~330 minecraft:redstone_wire replace
setblock ~97 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~153 ~330 ~112 ~153 ~330 minecraft:redstone_wire replace
setblock ~114 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~330 ~129 ~153 ~330 minecraft:redstone_wire replace
setblock ~131 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~330 ~146 ~153 ~330 minecraft:redstone_wire replace
setblock ~148 ~153 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~153 ~330 ~159 ~153 ~330 minecraft:redstone_wire replace
setblock ~91 ~153 ~333 minecraft:redstone_wire replace
fill ~90 ~153 ~334 ~92 ~153 ~334 minecraft:redstone_wire replace
setblock ~93 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~153 ~334 ~107 ~153 ~334 minecraft:redstone_wire replace
setblock ~109 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~334 ~124 ~153 ~334 minecraft:redstone_wire replace
setblock ~126 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~334 ~141 ~153 ~334 minecraft:redstone_wire replace
setblock ~143 ~153 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~334 ~156 ~153 ~334 minecraft:redstone_wire replace
setblock ~91 ~153 ~337 minecraft:redstone_wire replace
fill ~90 ~153 ~338 ~103 ~153 ~338 minecraft:redstone_wire replace
setblock ~105 ~153 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~153 ~338 ~120 ~153 ~338 minecraft:redstone_wire replace
setblock ~122 ~153 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~153 ~338 ~137 ~153 ~338 minecraft:redstone_wire replace
setblock ~139 ~153 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~153 ~338 ~153 ~153 ~338 minecraft:redstone_wire replace
setblock ~91 ~153 ~341 minecraft:redstone_wire replace
fill ~90 ~153 ~342 ~92 ~153 ~342 minecraft:redstone_wire replace
setblock ~93 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~153 ~342 ~107 ~153 ~342 minecraft:redstone_wire replace
setblock ~109 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~342 ~124 ~153 ~342 minecraft:redstone_wire replace
setblock ~126 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~342 ~141 ~153 ~342 minecraft:redstone_wire replace
setblock ~143 ~153 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~342 ~150 ~153 ~342 minecraft:redstone_wire replace
setblock ~91 ~153 ~345 minecraft:redstone_wire replace
fill ~90 ~153 ~346 ~100 ~153 ~346 minecraft:redstone_wire replace
setblock ~102 ~153 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~346 ~117 ~153 ~346 minecraft:redstone_wire replace
setblock ~119 ~153 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~346 ~134 ~153 ~346 minecraft:redstone_wire replace
setblock ~136 ~153 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~153 ~346 ~147 ~153 ~346 minecraft:redstone_wire replace
setblock ~91 ~153 ~349 minecraft:redstone_wire replace
fill ~90 ~153 ~350 ~95 ~153 ~350 minecraft:redstone_wire replace
setblock ~97 ~153 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~153 ~350 ~112 ~153 ~350 minecraft:redstone_wire replace
setblock ~114 ~153 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~350 ~129 ~153 ~350 minecraft:redstone_wire replace
setblock ~131 ~153 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~350 ~144 ~153 ~350 minecraft:redstone_wire replace
setblock ~91 ~153 ~353 minecraft:redstone_wire replace
fill ~90 ~153 ~354 ~91 ~153 ~354 minecraft:redstone_wire replace
setblock ~93 ~153 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~153 ~354 ~108 ~153 ~354 minecraft:redstone_wire replace
setblock ~110 ~153 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~153 ~354 ~125 ~153 ~354 minecraft:redstone_wire replace
setblock ~127 ~153 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~153 ~354 ~141 ~153 ~354 minecraft:redstone_wire replace
setblock ~91 ~153 ~357 minecraft:redstone_wire replace
fill ~90 ~153 ~358 ~95 ~153 ~358 minecraft:redstone_wire replace
setblock ~97 ~153 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~153 ~358 ~112 ~153 ~358 minecraft:redstone_wire replace
setblock ~114 ~153 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~358 ~129 ~153 ~358 minecraft:redstone_wire replace
setblock ~131 ~153 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~358 ~138 ~153 ~358 minecraft:redstone_wire replace
setblock ~91 ~153 ~361 minecraft:redstone_wire replace
fill ~90 ~153 ~362 ~91 ~153 ~362 minecraft:redstone_wire replace
setblock ~93 ~153 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~153 ~362 ~107 ~153 ~362 minecraft:redstone_wire replace
setblock ~109 ~153 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~362 ~123 ~153 ~362 minecraft:redstone_wire replace
setblock ~125 ~153 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~153 ~362 ~135 ~153 ~362 minecraft:redstone_wire replace
setblock ~91 ~153 ~365 minecraft:redstone_wire replace
fill ~90 ~153 ~366 ~100 ~153 ~366 minecraft:redstone_wire replace
setblock ~102 ~153 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~366 ~117 ~153 ~366 minecraft:redstone_wire replace
setblock ~119 ~153 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~366 ~132 ~153 ~366 minecraft:redstone_wire replace
setblock ~88 ~153 ~369 minecraft:redstone_wire replace
fill ~87 ~153 ~370 ~96 ~153 ~370 minecraft:redstone_wire replace
setblock ~98 ~153 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~153 ~370 ~113 ~153 ~370 minecraft:redstone_wire replace
setblock ~115 ~153 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~153 ~370 ~129 ~153 ~370 minecraft:redstone_wire replace
setblock ~88 ~153 ~373 minecraft:redstone_wire replace
fill ~87 ~153 ~374 ~100 ~153 ~374 minecraft:redstone_wire replace
setblock ~102 ~153 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~153 ~374 ~117 ~153 ~374 minecraft:redstone_wire replace
setblock ~119 ~153 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~153 ~374 ~126 ~153 ~374 minecraft:redstone_wire replace
setblock ~88 ~153 ~377 minecraft:redstone_wire replace
fill ~87 ~153 ~378 ~93 ~153 ~378 minecraft:redstone_wire replace
setblock ~95 ~153 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~378 ~110 ~153 ~378 minecraft:redstone_wire replace
setblock ~112 ~153 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~378 ~123 ~153 ~378 minecraft:redstone_wire replace
setblock ~88 ~153 ~381 minecraft:redstone_wire replace
fill ~87 ~153 ~382 ~88 ~153 ~382 minecraft:redstone_wire replace
setblock ~90 ~153 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~153 ~382 ~105 ~153 ~382 minecraft:redstone_wire replace
setblock ~107 ~153 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~153 ~382 ~120 ~153 ~382 minecraft:redstone_wire replace
setblock ~88 ~153 ~385 minecraft:redstone_wire replace
setblock ~87 ~153 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~153 ~386 ~101 ~153 ~386 minecraft:redstone_wire replace
setblock ~103 ~153 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~153 ~386 ~117 ~153 ~386 minecraft:redstone_wire replace
setblock ~88 ~153 ~389 minecraft:redstone_wire replace
fill ~87 ~153 ~390 ~88 ~153 ~390 minecraft:redstone_wire replace
setblock ~90 ~153 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~153 ~390 ~105 ~153 ~390 minecraft:redstone_wire replace
setblock ~107 ~153 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~153 ~390 ~114 ~153 ~390 minecraft:redstone_wire replace
setblock ~88 ~153 ~393 minecraft:redstone_wire replace
fill ~87 ~153 ~394 ~98 ~153 ~394 minecraft:redstone_wire replace
setblock ~100 ~153 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~153 ~394 ~111 ~153 ~394 minecraft:redstone_wire replace
setblock ~88 ~153 ~397 minecraft:redstone_wire replace
fill ~87 ~153 ~398 ~93 ~153 ~398 minecraft:redstone_wire replace
setblock ~95 ~153 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~398 ~108 ~153 ~398 minecraft:redstone_wire replace
setblock ~85 ~153 ~401 minecraft:redstone_wire replace
fill ~84 ~153 ~402 ~89 ~153 ~402 minecraft:redstone_wire replace
setblock ~91 ~153 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~153 ~402 ~105 ~153 ~402 minecraft:redstone_wire replace
setblock ~85 ~153 ~405 minecraft:redstone_wire replace
fill ~84 ~153 ~406 ~93 ~153 ~406 minecraft:redstone_wire replace
setblock ~95 ~153 ~406 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~153 ~406 ~102 ~153 ~406 minecraft:redstone_wire replace
setblock ~85 ~153 ~409 minecraft:redstone_wire replace
fill ~84 ~153 ~410 ~86 ~153 ~410 minecraft:redstone_wire replace
setblock ~88 ~153 ~410 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~153 ~410 ~99 ~153 ~410 minecraft:redstone_wire replace
setblock ~85 ~153 ~413 minecraft:redstone_wire replace
setblock ~84 ~153 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~153 ~414 ~96 ~153 ~414 minecraft:redstone_wire replace
setblock ~85 ~153 ~417 minecraft:redstone_wire replace
fill ~84 ~153 ~418 ~93 ~153 ~418 minecraft:redstone_wire replace
setblock ~85 ~153 ~421 minecraft:redstone_wire replace
setblock ~84 ~153 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~153 ~422 ~90 ~153 ~422 minecraft:redstone_wire replace
setblock ~85 ~153 ~425 minecraft:redstone_wire replace
fill ~84 ~153 ~426 ~87 ~153 ~426 minecraft:redstone_wire replace
setblock ~85 ~153 ~429 minecraft:redstone_wire replace
fill ~84 ~153 ~430 ~86 ~153 ~430 minecraft:redstone_wire replace
setblock ~79 ~153 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~153 ~446 ~80 ~153 ~446 minecraft:redstone_wire replace
setblock ~109 ~153 ~473 minecraft:redstone_wire replace
setblock ~112 ~153 ~473 minecraft:redstone_wire replace
setblock ~115 ~153 ~473 minecraft:redstone_wire replace
setblock ~118 ~153 ~473 minecraft:redstone_wire replace
setblock ~121 ~153 ~473 minecraft:redstone_wire replace
setblock ~124 ~153 ~473 minecraft:redstone_wire replace
setblock ~127 ~153 ~473 minecraft:redstone_wire replace
setblock ~130 ~153 ~473 minecraft:redstone_wire replace
setblock ~133 ~153 ~473 minecraft:redstone_wire replace
setblock ~136 ~153 ~473 minecraft:redstone_wire replace
setblock ~139 ~153 ~473 minecraft:redstone_wire replace
setblock ~142 ~153 ~473 minecraft:redstone_wire replace
setblock ~145 ~153 ~473 minecraft:redstone_wire replace
setblock ~148 ~153 ~473 minecraft:redstone_wire replace
setblock ~151 ~153 ~473 minecraft:redstone_wire replace
setblock ~154 ~153 ~473 minecraft:redstone_wire replace
setblock ~157 ~153 ~473 minecraft:redstone_wire replace
setblock ~160 ~153 ~473 minecraft:redstone_wire replace
setblock ~163 ~153 ~473 minecraft:redstone_wire replace
setblock ~166 ~153 ~473 minecraft:redstone_wire replace
setblock ~169 ~153 ~473 minecraft:redstone_wire replace
setblock ~172 ~153 ~473 minecraft:redstone_wire replace
setblock ~175 ~153 ~473 minecraft:redstone_wire replace
setblock ~178 ~153 ~473 minecraft:redstone_wire replace
setblock ~181 ~153 ~473 minecraft:redstone_wire replace
setblock ~184 ~153 ~473 minecraft:redstone_wire replace
setblock ~187 ~153 ~473 minecraft:redstone_wire replace
setblock ~190 ~153 ~473 minecraft:redstone_wire replace
setblock ~193 ~153 ~473 minecraft:redstone_wire replace
setblock ~196 ~153 ~473 minecraft:redstone_wire replace
setblock ~199 ~153 ~473 minecraft:redstone_wire replace
setblock ~202 ~153 ~473 minecraft:redstone_wire replace
setblock ~205 ~153 ~473 minecraft:redstone_wire replace
setblock ~208 ~153 ~473 minecraft:redstone_wire replace
setblock ~211 ~153 ~473 minecraft:redstone_wire replace
setblock ~214 ~153 ~473 minecraft:redstone_wire replace
setblock ~217 ~153 ~473 minecraft:redstone_wire replace
setblock ~220 ~153 ~473 minecraft:redstone_wire replace
setblock ~223 ~153 ~473 minecraft:redstone_wire replace
setblock ~226 ~153 ~473 minecraft:redstone_wire replace
setblock ~229 ~153 ~473 minecraft:redstone_wire replace
setblock ~232 ~153 ~473 minecraft:redstone_wire replace
setblock ~235 ~153 ~473 minecraft:redstone_wire replace
setblock ~238 ~153 ~473 minecraft:redstone_wire replace
setblock ~241 ~153 ~473 minecraft:redstone_wire replace
setblock ~244 ~153 ~473 minecraft:redstone_wire replace
setblock ~247 ~153 ~473 minecraft:redstone_wire replace
setblock ~250 ~153 ~473 minecraft:redstone_wire replace
setblock ~253 ~153 ~473 minecraft:redstone_wire replace
fill ~108 ~153 ~474 ~112 ~153 ~474 minecraft:redstone_wire replace
setblock ~113 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~474 ~127 ~153 ~474 minecraft:redstone_wire replace
setblock ~128 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~153 ~474 ~142 ~153 ~474 minecraft:redstone_wire replace
setblock ~143 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~153 ~474 ~157 ~153 ~474 minecraft:redstone_wire replace
setblock ~158 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~474 ~172 ~153 ~474 minecraft:redstone_wire replace
setblock ~173 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~153 ~474 ~187 ~153 ~474 minecraft:redstone_wire replace
setblock ~188 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~153 ~474 ~202 ~153 ~474 minecraft:redstone_wire replace
setblock ~203 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~153 ~474 ~217 ~153 ~474 minecraft:redstone_wire replace
setblock ~218 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~153 ~474 ~232 ~153 ~474 minecraft:redstone_wire replace
setblock ~233 ~153 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~153 ~474 ~254 ~153 ~474 minecraft:redstone_wire replace
setblock ~109 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~153 ~477 minecraft:redstone_wire replace
setblock ~118 ~153 ~477 minecraft:redstone_wire replace
setblock ~121 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~124 ~153 ~477 minecraft:redstone_wire replace
setblock ~127 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~153 ~477 minecraft:redstone_wire replace
setblock ~133 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~477 minecraft:redstone_wire replace
setblock ~139 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~153 ~477 minecraft:redstone_wire replace
setblock ~145 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~153 ~477 minecraft:redstone_wire replace
setblock ~151 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~154 ~153 ~477 minecraft:redstone_wire replace
setblock ~157 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~477 minecraft:redstone_wire replace
setblock ~163 ~153 ~477 minecraft:redstone_wire replace
setblock ~166 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~153 ~477 minecraft:redstone_wire replace
setblock ~172 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~175 ~153 ~477 minecraft:redstone_wire replace
setblock ~178 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~153 ~477 minecraft:redstone_wire replace
setblock ~184 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~153 ~477 minecraft:redstone_wire replace
setblock ~193 ~153 ~477 minecraft:redstone_wire replace
setblock ~196 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~199 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~153 ~477 minecraft:redstone_wire replace
setblock ~205 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~214 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~153 ~477 minecraft:redstone_wire replace
setblock ~226 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~229 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~232 ~153 ~477 minecraft:redstone_wire replace
setblock ~235 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~153 ~477 minecraft:redstone_wire replace
setblock ~241 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~153 ~477 minecraft:redstone_wire replace
setblock ~247 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~250 ~153 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~153 ~477 minecraft:redstone_wire replace
fill ~108 ~153 ~478 ~121 ~153 ~478 minecraft:redstone_wire replace
setblock ~122 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~153 ~478 ~136 ~153 ~478 minecraft:redstone_wire replace
setblock ~137 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~153 ~478 ~151 ~153 ~478 minecraft:redstone_wire replace
setblock ~152 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~153 ~478 ~166 ~153 ~478 minecraft:redstone_wire replace
setblock ~167 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~153 ~478 ~181 ~153 ~478 minecraft:redstone_wire replace
setblock ~182 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~153 ~478 ~196 ~153 ~478 minecraft:redstone_wire replace
setblock ~197 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~153 ~478 ~211 ~153 ~478 minecraft:redstone_wire replace
setblock ~212 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~153 ~478 ~226 ~153 ~478 minecraft:redstone_wire replace
setblock ~227 ~153 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~153 ~478 ~239 ~153 ~478 minecraft:redstone_wire replace
setblock ~240 ~153 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~153 ~478 ~253 ~153 ~478 minecraft:redstone_wire replace
setblock ~254 ~153 ~478 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~109 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~118 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~121 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~124 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~127 ~153 ~497 minecraft:redstone_wire replace
setblock ~130 ~153 ~497 minecraft:redstone_wire replace
setblock ~133 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~142 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~145 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~151 ~153 ~497 minecraft:redstone_wire replace
setblock ~154 ~153 ~497 minecraft:redstone_wire replace
setblock ~157 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~163 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~166 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~172 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~175 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~178 ~153 ~497 minecraft:redstone_wire replace
setblock ~181 ~153 ~497 minecraft:redstone_wire replace
setblock ~184 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~190 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~193 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~196 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~199 ~153 ~497 minecraft:redstone_wire replace
setblock ~202 ~153 ~497 minecraft:redstone_wire replace
setblock ~205 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~214 ~153 ~497 minecraft:redstone_wire replace
setblock ~217 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~226 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~229 ~153 ~497 minecraft:redstone_wire replace
setblock ~232 ~153 ~497 minecraft:redstone_wire replace
setblock ~235 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~238 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~241 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~247 ~153 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~250 ~153 ~497 minecraft:redstone_wire replace
setblock ~253 ~153 ~497 minecraft:redstone_wire replace
fill ~108 ~153 ~498 ~112 ~153 ~498 minecraft:redstone_wire replace
setblock ~113 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~153 ~498 ~127 ~153 ~498 minecraft:redstone_wire replace
setblock ~128 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~153 ~498 ~142 ~153 ~498 minecraft:redstone_wire replace
setblock ~143 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~153 ~498 ~157 ~153 ~498 minecraft:redstone_wire replace
setblock ~158 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~498 ~172 ~153 ~498 minecraft:redstone_wire replace
setblock ~173 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~153 ~498 ~187 ~153 ~498 minecraft:redstone_wire replace
setblock ~188 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~153 ~498 ~202 ~153 ~498 minecraft:redstone_wire replace
setblock ~203 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~153 ~498 ~217 ~153 ~498 minecraft:redstone_wire replace
setblock ~218 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~153 ~498 ~232 ~153 ~498 minecraft:redstone_wire replace
setblock ~233 ~153 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~153 ~498 ~245 ~153 ~498 minecraft:redstone_wire replace
setblock ~246 ~153 ~498 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~153 ~498 ~254 ~153 ~498 minecraft:redstone_wire replace
setblock ~109 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~509 minecraft:redstone_wire replace
setblock ~115 ~153 ~509 minecraft:redstone_wire replace
setblock ~118 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~121 ~153 ~509 minecraft:redstone_wire replace
setblock ~124 ~153 ~509 minecraft:redstone_wire replace
setblock ~127 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~130 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~133 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~136 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~139 ~153 ~509 minecraft:redstone_wire replace
setblock ~142 ~153 ~509 minecraft:redstone_wire replace
setblock ~145 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~148 ~153 ~509 minecraft:redstone_wire replace
setblock ~151 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~154 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~157 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~160 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~163 ~153 ~509 minecraft:redstone_wire replace
setblock ~166 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~169 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~172 ~153 ~509 minecraft:redstone_wire replace
setblock ~175 ~153 ~509 minecraft:redstone_wire replace
setblock ~178 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~184 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~187 ~153 ~509 minecraft:redstone_wire replace
setblock ~190 ~153 ~509 minecraft:redstone_wire replace
setblock ~193 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~196 ~153 ~509 minecraft:redstone_wire replace
setblock ~199 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~202 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~205 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~208 ~153 ~509 minecraft:redstone_wire replace
setblock ~211 ~153 ~509 minecraft:redstone_wire replace
setblock ~214 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~217 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~220 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~223 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~226 ~153 ~509 minecraft:redstone_wire replace
setblock ~229 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~232 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~235 ~153 ~509 minecraft:redstone_wire replace
setblock ~238 ~153 ~509 minecraft:redstone_wire replace
setblock ~241 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~244 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~247 ~153 ~509 minecraft:redstone_wire replace
setblock ~250 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~153 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~153 ~510 ~109 ~153 ~510 minecraft:redstone_wire replace
setblock ~110 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~510 ~124 ~153 ~510 minecraft:redstone_wire replace
setblock ~125 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~153 ~510 ~139 ~153 ~510 minecraft:redstone_wire replace
setblock ~140 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~153 ~510 ~154 ~153 ~510 minecraft:redstone_wire replace
setblock ~155 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~153 ~510 ~169 ~153 ~510 minecraft:redstone_wire replace
setblock ~170 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~510 ~184 ~153 ~510 minecraft:redstone_wire replace
setblock ~185 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~153 ~510 ~199 ~153 ~510 minecraft:redstone_wire replace
setblock ~200 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~153 ~510 ~214 ~153 ~510 minecraft:redstone_wire replace
setblock ~215 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~153 ~510 ~229 ~153 ~510 minecraft:redstone_wire replace
setblock ~230 ~153 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~153 ~510 ~242 ~153 ~510 minecraft:redstone_wire replace
setblock ~243 ~153 ~510 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~153 ~510 ~254 ~153 ~510 minecraft:redstone_wire replace
setblock ~109 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~112 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~115 ~153 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
