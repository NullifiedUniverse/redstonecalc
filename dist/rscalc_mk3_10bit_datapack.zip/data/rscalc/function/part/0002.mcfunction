setblock ~176 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~178 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~193 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~195 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~210 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~212 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~227 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~229 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~244 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~246 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~261 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~263 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~278 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~280 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~295 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~297 ~17 ~114 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~116 minecraft:light_gray_concrete replace
setblock ~181 ~17 ~116 minecraft:light_gray_concrete replace
setblock ~187 ~17 ~116 minecraft:light_gray_concrete replace
setblock ~301 ~17 ~116 minecraft:light_gray_concrete replace
setblock ~64 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~93 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~108 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~110 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~125 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~127 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~142 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~144 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~159 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~161 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~191 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~193 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~208 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~210 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~225 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~227 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~242 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~244 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~259 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~261 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~276 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~278 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~293 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~295 ~17 ~118 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~120 minecraft:light_gray_concrete replace
setblock ~178 ~17 ~120 minecraft:light_gray_concrete replace
setblock ~181 ~17 ~120 minecraft:light_gray_concrete replace
setblock ~301 ~17 ~120 minecraft:light_gray_concrete replace
setblock ~64 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~93 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~108 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~110 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~125 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~127 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~142 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~144 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~159 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~161 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~191 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~193 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~208 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~210 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~225 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~227 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~242 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~244 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~259 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~261 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~276 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~278 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~293 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~295 ~17 ~122 minecraft:light_gray_concrete replace
setblock ~76 ~17 ~124 minecraft:light_gray_concrete replace
setblock ~178 ~17 ~124 minecraft:light_gray_concrete replace
setblock ~181 ~17 ~124 minecraft:light_gray_concrete replace
setblock ~187 ~17 ~124 minecraft:light_gray_concrete replace
setblock ~301 ~17 ~124 minecraft:light_gray_concrete replace
setblock ~91 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~93 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~108 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~110 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~125 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~127 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~142 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~144 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~159 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~161 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~176 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~178 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~193 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~195 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~210 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~212 ~17 ~126 minecraft:light_gray_concrete replace
setblock ~229 ~17 ~128 minecraft:light_gray_concrete replace
fill ~78 ~18 ~4 ~78 ~18 ~8 minecraft:light_gray_concrete replace
fill ~81 ~18 ~4 ~81 ~18 ~88 minecraft:light_gray_concrete replace
fill ~84 ~18 ~4 ~84 ~18 ~92 minecraft:light_gray_concrete replace
fill ~87 ~18 ~4 ~87 ~18 ~96 minecraft:light_gray_concrete replace
fill ~90 ~18 ~4 ~90 ~18 ~100 minecraft:light_gray_concrete replace
fill ~108 ~18 ~4 ~108 ~18 ~12 minecraft:light_gray_concrete replace
fill ~93 ~18 ~8 ~93 ~18 ~16 minecraft:light_gray_concrete replace
fill ~96 ~18 ~8 ~96 ~18 ~108 minecraft:light_gray_concrete replace
fill ~99 ~18 ~8 ~99 ~18 ~112 minecraft:light_gray_concrete replace
fill ~102 ~18 ~8 ~102 ~18 ~116 minecraft:light_gray_concrete replace
fill ~105 ~18 ~8 ~105 ~18 ~120 minecraft:light_gray_concrete replace
fill ~114 ~18 ~8 ~114 ~18 ~20 minecraft:light_gray_concrete replace
fill ~111 ~18 ~12 ~111 ~18 ~24 minecraft:light_gray_concrete replace
fill ~117 ~18 ~12 ~117 ~18 ~128 minecraft:light_gray_concrete replace
fill ~120 ~18 ~12 ~120 ~18 ~132 minecraft:light_gray_concrete replace
fill ~123 ~18 ~12 ~123 ~18 ~136 minecraft:light_gray_concrete replace
fill ~126 ~18 ~12 ~126 ~18 ~140 minecraft:light_gray_concrete replace
fill ~132 ~18 ~12 ~132 ~18 ~28 minecraft:light_gray_concrete replace
fill ~135 ~18 ~16 ~135 ~18 ~32 minecraft:light_gray_concrete replace
fill ~138 ~18 ~16 ~138 ~18 ~148 minecraft:light_gray_concrete replace
fill ~144 ~18 ~16 ~144 ~18 ~152 minecraft:light_gray_concrete replace
fill ~147 ~18 ~16 ~147 ~18 ~156 minecraft:light_gray_concrete replace
fill ~150 ~18 ~16 ~150 ~18 ~160 minecraft:light_gray_concrete replace
fill ~153 ~18 ~16 ~153 ~18 ~36 minecraft:light_gray_concrete replace
fill ~159 ~18 ~20 ~159 ~18 ~40 minecraft:light_gray_concrete replace
fill ~162 ~18 ~20 ~162 ~18 ~168 minecraft:light_gray_concrete replace
fill ~165 ~18 ~20 ~165 ~18 ~172 minecraft:light_gray_concrete replace
fill ~168 ~18 ~20 ~168 ~18 ~176 minecraft:light_gray_concrete replace
fill ~171 ~18 ~20 ~171 ~18 ~180 minecraft:light_gray_concrete replace
fill ~174 ~18 ~20 ~174 ~18 ~44 minecraft:light_gray_concrete replace
fill ~183 ~18 ~24 ~183 ~18 ~48 minecraft:light_gray_concrete replace
fill ~192 ~18 ~24 ~192 ~18 ~188 minecraft:light_gray_concrete replace
fill ~195 ~18 ~24 ~195 ~18 ~192 minecraft:light_gray_concrete replace
fill ~198 ~18 ~24 ~198 ~18 ~196 minecraft:light_gray_concrete replace
fill ~201 ~18 ~24 ~201 ~18 ~200 minecraft:light_gray_concrete replace
fill ~204 ~18 ~24 ~204 ~18 ~52 minecraft:light_gray_concrete replace
fill ~210 ~18 ~28 ~210 ~18 ~56 minecraft:light_gray_concrete replace
fill ~213 ~18 ~28 ~213 ~18 ~208 minecraft:light_gray_concrete replace
fill ~216 ~18 ~28 ~216 ~18 ~212 minecraft:light_gray_concrete replace
fill ~222 ~18 ~28 ~222 ~18 ~216 minecraft:light_gray_concrete replace
fill ~225 ~18 ~28 ~225 ~18 ~220 minecraft:light_gray_concrete replace
fill ~237 ~18 ~28 ~237 ~18 ~60 minecraft:light_gray_concrete replace
fill ~249 ~18 ~32 ~249 ~18 ~64 minecraft:light_gray_concrete replace
fill ~264 ~18 ~32 ~264 ~18 ~68 minecraft:light_gray_concrete replace
fill ~267 ~18 ~32 ~267 ~18 ~232 minecraft:light_gray_concrete replace
fill ~276 ~18 ~32 ~276 ~18 ~236 minecraft:light_gray_concrete replace
fill ~279 ~18 ~32 ~279 ~18 ~240 minecraft:light_gray_concrete replace
fill ~282 ~18 ~32 ~282 ~18 ~244 minecraft:light_gray_concrete replace
fill ~231 ~18 ~36 ~231 ~18 ~72 minecraft:light_gray_concrete replace
fill ~234 ~18 ~36 ~234 ~18 ~248 minecraft:light_gray_concrete replace
fill ~240 ~18 ~36 ~240 ~18 ~252 minecraft:light_gray_concrete replace
fill ~243 ~18 ~36 ~243 ~18 ~256 minecraft:light_gray_concrete replace
fill ~246 ~18 ~36 ~246 ~18 ~260 minecraft:light_gray_concrete replace
fill ~270 ~18 ~36 ~270 ~18 ~76 minecraft:light_gray_concrete replace
fill ~258 ~18 ~40 ~258 ~18 ~80 minecraft:light_gray_concrete replace
fill ~285 ~18 ~40 ~285 ~18 ~84 minecraft:light_gray_concrete replace
fill ~288 ~18 ~40 ~288 ~18 ~272 minecraft:light_gray_concrete replace
fill ~291 ~18 ~40 ~291 ~18 ~276 minecraft:light_gray_concrete replace
fill ~294 ~18 ~40 ~294 ~18 ~280 minecraft:light_gray_concrete replace
fill ~297 ~18 ~40 ~297 ~18 ~284 minecraft:light_gray_concrete replace
fill ~129 ~18 ~44 ~129 ~18 ~104 minecraft:light_gray_concrete replace
fill ~141 ~18 ~48 ~141 ~18 ~124 minecraft:light_gray_concrete replace
fill ~156 ~18 ~52 ~156 ~18 ~144 minecraft:light_gray_concrete replace
fill ~189 ~18 ~56 ~189 ~18 ~164 minecraft:light_gray_concrete replace
fill ~207 ~18 ~60 ~207 ~18 ~184 minecraft:light_gray_concrete replace
fill ~219 ~18 ~64 ~219 ~18 ~204 minecraft:light_gray_concrete replace
fill ~252 ~18 ~68 ~252 ~18 ~224 minecraft:light_gray_concrete replace
fill ~255 ~18 ~72 ~255 ~18 ~228 minecraft:light_gray_concrete replace
fill ~261 ~18 ~76 ~261 ~18 ~264 minecraft:light_gray_concrete replace
fill ~273 ~18 ~80 ~273 ~18 ~268 minecraft:light_gray_concrete replace
fill ~300 ~18 ~84 ~300 ~18 ~300 minecraft:light_gray_concrete replace
fill ~186 ~18 ~100 ~186 ~18 ~296 minecraft:light_gray_concrete replace
fill ~177 ~18 ~104 ~177 ~18 ~288 minecraft:light_gray_concrete replace
fill ~180 ~18 ~112 ~180 ~18 ~292 minecraft:light_gray_concrete replace
fill ~228 ~18 ~128 ~228 ~18 ~304 minecraft:light_gray_concrete replace
setblock ~79 ~19 ~4 minecraft:light_gray_concrete replace
setblock ~82 ~19 ~4 minecraft:light_gray_concrete replace
setblock ~88 ~19 ~4 minecraft:light_gray_concrete replace
setblock ~94 ~19 ~8 minecraft:light_gray_concrete replace
setblock ~97 ~19 ~8 minecraft:light_gray_concrete replace
setblock ~103 ~19 ~8 minecraft:light_gray_concrete replace
setblock ~78 ~19 ~9 minecraft:light_gray_concrete replace
setblock ~108 ~19 ~11 minecraft:light_gray_concrete replace
setblock ~112 ~19 ~12 minecraft:light_gray_concrete replace
setblock ~118 ~19 ~12 minecraft:light_gray_concrete replace
setblock ~124 ~19 ~12 minecraft:light_gray_concrete replace
setblock ~108 ~19 ~13 minecraft:light_gray_concrete replace
setblock ~93 ~19 ~15 minecraft:light_gray_concrete replace
setblock ~136 ~19 ~16 minecraft:light_gray_concrete replace
setblock ~139 ~19 ~16 minecraft:light_gray_concrete replace
setblock ~148 ~19 ~16 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~17 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~17 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~17 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~17 minecraft:light_gray_concrete replace
setblock ~93 ~19 ~17 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~19 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~19 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~19 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~19 minecraft:light_gray_concrete replace
setblock ~114 ~19 ~19 minecraft:light_gray_concrete replace
setblock ~160 ~19 ~20 minecraft:light_gray_concrete replace
setblock ~163 ~19 ~20 minecraft:light_gray_concrete replace
setblock ~169 ~19 ~20 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~21 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~21 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~21 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~21 minecraft:light_gray_concrete replace
setblock ~114 ~19 ~21 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~23 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~23 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~23 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~23 minecraft:light_gray_concrete replace
setblock ~111 ~19 ~23 minecraft:light_gray_concrete replace
setblock ~184 ~19 ~24 minecraft:light_gray_concrete replace
setblock ~193 ~19 ~24 minecraft:light_gray_concrete replace
setblock ~199 ~19 ~24 minecraft:light_gray_concrete replace
setblock ~111 ~19 ~25 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~25 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~25 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~25 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~25 minecraft:light_gray_concrete replace
setblock ~132 ~19 ~25 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~27 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~27 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~27 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~27 minecraft:light_gray_concrete replace
setblock ~132 ~19 ~27 minecraft:light_gray_concrete replace
setblock ~211 ~19 ~28 minecraft:light_gray_concrete replace
setblock ~214 ~19 ~28 minecraft:light_gray_concrete replace
setblock ~223 ~19 ~28 minecraft:light_gray_concrete replace
setblock ~132 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~135 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~153 ~19 ~29 minecraft:light_gray_concrete replace
setblock ~135 ~19 ~31 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~31 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~31 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~31 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~31 minecraft:light_gray_concrete replace
setblock ~153 ~19 ~31 minecraft:light_gray_concrete replace
setblock ~265 ~19 ~32 minecraft:light_gray_concrete replace
setblock ~268 ~19 ~32 minecraft:light_gray_concrete replace
setblock ~280 ~19 ~32 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~135 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~159 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~174 ~19 ~33 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~159 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~174 ~19 ~35 minecraft:light_gray_concrete replace
setblock ~232 ~19 ~36 minecraft:light_gray_concrete replace
setblock ~235 ~19 ~36 minecraft:light_gray_concrete replace
setblock ~244 ~19 ~36 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~153 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~183 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~204 ~19 ~37 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~183 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~204 ~19 ~39 minecraft:light_gray_concrete replace
setblock ~286 ~19 ~40 minecraft:light_gray_concrete replace
setblock ~289 ~19 ~40 minecraft:light_gray_concrete replace
setblock ~295 ~19 ~40 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~159 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~210 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~237 ~19 ~41 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~174 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~210 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~237 ~19 ~43 minecraft:light_gray_concrete replace
setblock ~82 ~19 ~44 minecraft:light_gray_concrete replace
setblock ~91 ~19 ~44 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~174 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~249 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~264 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~45 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~183 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~249 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~264 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~47 minecraft:light_gray_concrete replace
setblock ~97 ~19 ~48 minecraft:light_gray_concrete replace
setblock ~106 ~19 ~48 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~183 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~231 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~270 ~19 ~49 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~204 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~231 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~270 ~19 ~51 minecraft:light_gray_concrete replace
setblock ~118 ~19 ~52 minecraft:light_gray_concrete replace
setblock ~127 ~19 ~52 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~204 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~258 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~285 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~53 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~210 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~258 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~285 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~55 minecraft:light_gray_concrete replace
setblock ~139 ~19 ~56 minecraft:light_gray_concrete replace
setblock ~151 ~19 ~56 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~129 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~210 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~237 ~19 ~57 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~129 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~237 ~19 ~59 minecraft:light_gray_concrete replace
setblock ~163 ~19 ~60 minecraft:light_gray_concrete replace
setblock ~172 ~19 ~60 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~141 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~237 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~249 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~264 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~61 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~141 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~249 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~264 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~63 minecraft:light_gray_concrete replace
setblock ~193 ~19 ~64 minecraft:light_gray_concrete replace
setblock ~202 ~19 ~64 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~231 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~249 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~270 ~19 ~65 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~231 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~270 ~19 ~67 minecraft:light_gray_concrete replace
setblock ~214 ~19 ~68 minecraft:light_gray_concrete replace
setblock ~226 ~19 ~68 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~258 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~264 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~285 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~69 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~258 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~285 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~71 minecraft:light_gray_concrete replace
setblock ~268 ~19 ~72 minecraft:light_gray_concrete replace
setblock ~283 ~19 ~72 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~129 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~231 ~19 ~73 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~129 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~270 ~19 ~75 minecraft:light_gray_concrete replace
setblock ~235 ~19 ~76 minecraft:light_gray_concrete replace
setblock ~247 ~19 ~76 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~141 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~270 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~77 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~141 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~258 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~79 minecraft:light_gray_concrete replace
setblock ~289 ~19 ~80 minecraft:light_gray_concrete replace
setblock ~298 ~19 ~80 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~258 ~19 ~81 minecraft:light_gray_concrete replace
setblock ~81 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~84 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~87 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~90 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~285 ~19 ~83 minecraft:light_gray_concrete replace
setblock ~96 ~19 ~85 minecraft:light_gray_concrete replace
setblock ~99 ~19 ~85 minecraft:light_gray_concrete replace
setblock ~102 ~19 ~85 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~85 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~85 minecraft:light_gray_concrete replace
