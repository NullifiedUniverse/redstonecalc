fill ~306 ~29 ~494 ~318 ~29 ~494 minecraft:redstone_wire replace
setblock ~292 ~29 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~315 ~29 ~498 ~317 ~29 ~498 minecraft:redstone_wire replace
setblock ~318 ~29 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~29 ~498 ~331 ~29 ~498 minecraft:redstone_wire replace
setblock ~333 ~29 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~335 ~29 ~498 ~345 ~29 ~498 minecraft:redstone_wire replace
setblock ~316 ~29 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~29 ~502 ~80 ~29 ~502 minecraft:redstone_wire replace
setblock ~79 ~29 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~29 ~506 ~101 ~29 ~506 minecraft:redstone_wire replace
setblock ~100 ~29 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~29 ~510 ~119 ~29 ~510 minecraft:redstone_wire replace
setblock ~118 ~29 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~29 ~514 ~144 ~29 ~514 minecraft:redstone_wire replace
setblock ~142 ~29 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~29 ~518 ~186 ~29 ~518 minecraft:redstone_wire replace
setblock ~178 ~29 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~29 ~522 ~204 ~29 ~522 minecraft:redstone_wire replace
setblock ~196 ~29 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~29 ~526 ~226 ~29 ~526 minecraft:redstone_wire replace
setblock ~227 ~29 ~526 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~29 ~526 ~240 ~29 ~526 minecraft:redstone_wire replace
setblock ~226 ~29 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~246 ~29 ~530 ~248 ~29 ~530 minecraft:redstone_wire replace
setblock ~250 ~29 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~29 ~530 ~264 ~29 ~530 minecraft:redstone_wire replace
setblock ~247 ~29 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~29 ~534 ~289 ~29 ~534 minecraft:redstone_wire replace
setblock ~290 ~29 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~29 ~534 ~304 ~29 ~534 minecraft:redstone_wire replace
setblock ~306 ~29 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~29 ~534 ~315 ~29 ~534 minecraft:redstone_wire replace
setblock ~289 ~29 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~29 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~29 ~538 ~326 ~29 ~538 minecraft:redstone_wire replace
setblock ~328 ~29 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~29 ~538 ~342 ~29 ~538 minecraft:redstone_wire replace
setblock ~313 ~29 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~29 ~542 ~98 ~29 ~542 minecraft:redstone_wire replace
setblock ~97 ~29 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~29 ~546 ~116 ~29 ~546 minecraft:redstone_wire replace
setblock ~115 ~29 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~29 ~550 ~141 ~29 ~550 minecraft:redstone_wire replace
setblock ~139 ~29 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~29 ~554 ~174 ~29 ~554 minecraft:redstone_wire replace
setblock ~169 ~29 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~29 ~558 ~193 ~29 ~558 minecraft:redstone_wire replace
setblock ~194 ~29 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~29 ~558 ~201 ~29 ~558 minecraft:redstone_wire replace
setblock ~193 ~29 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~222 ~29 ~562 ~224 ~29 ~562 minecraft:redstone_wire replace
setblock ~225 ~29 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~29 ~562 ~237 ~29 ~562 minecraft:redstone_wire replace
setblock ~223 ~29 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~252 ~29 ~566 ~254 ~29 ~566 minecraft:redstone_wire replace
setblock ~256 ~29 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~29 ~566 ~270 ~29 ~566 minecraft:redstone_wire replace
setblock ~253 ~29 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~29 ~570 ~276 ~29 ~570 minecraft:redstone_wire replace
setblock ~278 ~29 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~29 ~570 ~291 ~29 ~570 minecraft:redstone_wire replace
setblock ~271 ~29 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~29 ~574 ~308 ~29 ~574 minecraft:redstone_wire replace
setblock ~310 ~29 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~29 ~574 ~325 ~29 ~574 minecraft:redstone_wire replace
setblock ~327 ~29 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~29 ~574 ~336 ~29 ~574 minecraft:redstone_wire replace
setblock ~307 ~29 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~29 ~578 ~162 ~29 ~578 minecraft:redstone_wire replace
setblock ~157 ~29 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~29 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~328 ~29 ~582 ~341 ~29 ~582 minecraft:redstone_wire replace
setblock ~343 ~29 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~345 ~29 ~582 ~357 ~29 ~582 minecraft:redstone_wire replace
setblock ~328 ~29 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~29 ~586 ~95 ~29 ~586 minecraft:redstone_wire replace
setblock ~94 ~29 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~29 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~29 ~590 ~323 ~29 ~590 minecraft:redstone_wire replace
setblock ~325 ~29 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~29 ~590 ~339 ~29 ~590 minecraft:redstone_wire replace
setblock ~310 ~29 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~29 ~594 ~326 ~29 ~594 minecraft:redstone_wire replace
setblock ~328 ~29 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~29 ~594 ~343 ~29 ~594 minecraft:redstone_wire replace
setblock ~345 ~29 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~347 ~29 ~594 ~354 ~29 ~594 minecraft:redstone_wire replace
setblock ~325 ~29 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~30 ~16 minecraft:redstone_wire replace
setblock ~151 ~30 ~24 minecraft:redstone_wire replace
setblock ~172 ~30 ~32 minecraft:redstone_wire replace
setblock ~199 ~30 ~40 minecraft:redstone_wire replace
setblock ~214 ~30 ~48 minecraft:redstone_wire replace
setblock ~235 ~30 ~56 minecraft:redstone_wire replace
setblock ~265 ~30 ~64 minecraft:redstone_wire replace
setblock ~277 ~30 ~68 minecraft:redstone_wire replace
setblock ~283 ~30 ~80 minecraft:redstone_wire replace
setblock ~298 ~30 ~84 minecraft:redstone_wire replace
setblock ~133 ~30 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~30 ~268 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~30 ~272 minecraft:redstone_wire replace
setblock ~154 ~30 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~30 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~30 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~30 ~288 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~30 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~30 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~30 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~30 ~304 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~30 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~30 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~30 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~30 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~30 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~30 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~30 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~30 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~30 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~30 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~30 ~348 minecraft:redstone_wire replace
setblock ~112 ~30 ~352 minecraft:redstone_wire replace
setblock ~136 ~30 ~356 minecraft:redstone_wire replace
setblock ~166 ~30 ~360 minecraft:redstone_wire replace
setblock ~190 ~30 ~364 minecraft:redstone_wire replace
setblock ~220 ~30 ~368 minecraft:redstone_wire replace
setblock ~244 ~30 ~372 minecraft:redstone_wire replace
setblock ~262 ~30 ~376 minecraft:redstone_wire replace
setblock ~286 ~30 ~380 minecraft:redstone_wire replace
setblock ~88 ~30 ~384 minecraft:redstone_wire replace
setblock ~109 ~30 ~388 minecraft:redstone_wire replace
setblock ~130 ~30 ~392 minecraft:redstone_wire replace
setblock ~163 ~30 ~396 minecraft:redstone_wire replace
setblock ~187 ~30 ~400 minecraft:redstone_wire replace
setblock ~211 ~30 ~404 minecraft:redstone_wire replace
setblock ~241 ~30 ~408 minecraft:redstone_wire replace
setblock ~259 ~30 ~412 minecraft:redstone_wire replace
setblock ~304 ~30 ~416 minecraft:redstone_wire replace
setblock ~322 ~30 ~420 minecraft:redstone_wire replace
setblock ~85 ~30 ~424 minecraft:redstone_wire replace
setblock ~106 ~30 ~428 minecraft:redstone_wire replace
setblock ~124 ~30 ~432 minecraft:redstone_wire replace
setblock ~160 ~30 ~436 minecraft:redstone_wire replace
setblock ~184 ~30 ~440 minecraft:redstone_wire replace
setblock ~208 ~30 ~444 minecraft:redstone_wire replace
setblock ~232 ~30 ~448 minecraft:redstone_wire replace
setblock ~256 ~30 ~452 minecraft:redstone_wire replace
setblock ~301 ~30 ~456 minecraft:redstone_wire replace
setblock ~319 ~30 ~460 minecraft:redstone_wire replace
setblock ~82 ~30 ~464 minecraft:redstone_wire replace
setblock ~103 ~30 ~468 minecraft:redstone_wire replace
setblock ~121 ~30 ~472 minecraft:redstone_wire replace
setblock ~148 ~30 ~476 minecraft:redstone_wire replace
setblock ~181 ~30 ~480 minecraft:redstone_wire replace
setblock ~205 ~30 ~484 minecraft:redstone_wire replace
setblock ~229 ~30 ~488 minecraft:redstone_wire replace
setblock ~250 ~30 ~492 minecraft:redstone_wire replace
setblock ~292 ~30 ~496 minecraft:redstone_wire replace
setblock ~316 ~30 ~500 minecraft:redstone_wire replace
setblock ~79 ~30 ~504 minecraft:redstone_wire replace
setblock ~100 ~30 ~508 minecraft:redstone_wire replace
setblock ~118 ~30 ~512 minecraft:redstone_wire replace
setblock ~142 ~30 ~516 minecraft:redstone_wire replace
setblock ~178 ~30 ~520 minecraft:redstone_wire replace
setblock ~196 ~30 ~524 minecraft:redstone_wire replace
setblock ~226 ~30 ~528 minecraft:redstone_wire replace
setblock ~247 ~30 ~532 minecraft:redstone_wire replace
setblock ~289 ~30 ~536 minecraft:redstone_wire replace
setblock ~313 ~30 ~540 minecraft:redstone_wire replace
setblock ~97 ~30 ~544 minecraft:redstone_wire replace
setblock ~115 ~30 ~548 minecraft:redstone_wire replace
setblock ~139 ~30 ~552 minecraft:redstone_wire replace
setblock ~169 ~30 ~556 minecraft:redstone_wire replace
setblock ~193 ~30 ~560 minecraft:redstone_wire replace
setblock ~223 ~30 ~564 minecraft:redstone_wire replace
setblock ~253 ~30 ~568 minecraft:redstone_wire replace
setblock ~271 ~30 ~572 minecraft:redstone_wire replace
setblock ~307 ~30 ~576 minecraft:redstone_wire replace
setblock ~157 ~30 ~580 minecraft:redstone_wire replace
setblock ~328 ~30 ~584 minecraft:redstone_wire replace
setblock ~94 ~30 ~588 minecraft:redstone_wire replace
setblock ~310 ~30 ~592 minecraft:redstone_wire replace
setblock ~325 ~30 ~596 minecraft:redstone_wire replace
fill ~126 ~31 ~12 ~126 ~31 ~16 minecraft:redstone_wire replace
fill ~150 ~31 ~20 ~150 ~31 ~24 minecraft:redstone_wire replace
fill ~171 ~31 ~28 ~171 ~31 ~32 minecraft:redstone_wire replace
fill ~198 ~31 ~36 ~198 ~31 ~40 minecraft:redstone_wire replace
fill ~213 ~31 ~44 ~213 ~31 ~48 minecraft:redstone_wire replace
fill ~234 ~31 ~52 ~234 ~31 ~56 minecraft:redstone_wire replace
fill ~264 ~31 ~60 ~264 ~31 ~64 minecraft:redstone_wire replace
fill ~276 ~31 ~64 ~276 ~31 ~68 minecraft:redstone_wire replace
fill ~282 ~31 ~76 ~282 ~31 ~80 minecraft:redstone_wire replace
fill ~297 ~31 ~80 ~297 ~31 ~84 minecraft:redstone_wire replace
setblock ~132 ~31 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~31 ~262 ~132 ~31 ~268 minecraft:redstone_wire replace
fill ~144 ~31 ~268 ~144 ~31 ~272 minecraft:redstone_wire replace
setblock ~153 ~31 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~31 ~274 ~153 ~31 ~280 minecraft:redstone_wire replace
setblock ~174 ~31 ~280 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~31 ~282 ~174 ~31 ~288 minecraft:redstone_wire replace
setblock ~201 ~31 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~31 ~290 ~201 ~31 ~296 minecraft:redstone_wire replace
setblock ~216 ~31 ~296 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~31 ~298 ~216 ~31 ~304 minecraft:redstone_wire replace
setblock ~237 ~31 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~31 ~306 ~237 ~31 ~312 minecraft:redstone_wire replace
setblock ~267 ~31 ~312 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~31 ~314 ~267 ~31 ~320 minecraft:redstone_wire replace
setblock ~273 ~31 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~31 ~322 ~273 ~31 ~328 minecraft:redstone_wire replace
setblock ~279 ~31 ~328 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~31 ~330 ~279 ~31 ~336 minecraft:redstone_wire replace
setblock ~294 ~31 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~294 ~31 ~338 ~294 ~31 ~344 minecraft:redstone_wire replace
fill ~90 ~31 ~344 ~90 ~31 ~348 minecraft:redstone_wire replace
fill ~111 ~31 ~348 ~111 ~31 ~352 minecraft:redstone_wire replace
fill ~135 ~31 ~352 ~135 ~31 ~356 minecraft:redstone_wire replace
fill ~165 ~31 ~356 ~165 ~31 ~360 minecraft:redstone_wire replace
fill ~189 ~31 ~360 ~189 ~31 ~364 minecraft:redstone_wire replace
fill ~219 ~31 ~364 ~219 ~31 ~368 minecraft:redstone_wire replace
fill ~243 ~31 ~368 ~243 ~31 ~372 minecraft:redstone_wire replace
fill ~261 ~31 ~372 ~261 ~31 ~376 minecraft:redstone_wire replace
fill ~285 ~31 ~376 ~285 ~31 ~380 minecraft:redstone_wire replace
fill ~87 ~31 ~380 ~87 ~31 ~384 minecraft:redstone_wire replace
fill ~108 ~31 ~384 ~108 ~31 ~388 minecraft:redstone_wire replace
fill ~129 ~31 ~388 ~129 ~31 ~392 minecraft:redstone_wire replace
fill ~162 ~31 ~392 ~162 ~31 ~396 minecraft:redstone_wire replace
fill ~186 ~31 ~396 ~186 ~31 ~400 minecraft:redstone_wire replace
fill ~210 ~31 ~400 ~210 ~31 ~404 minecraft:redstone_wire replace
fill ~240 ~31 ~404 ~240 ~31 ~408 minecraft:redstone_wire replace
fill ~258 ~31 ~408 ~258 ~31 ~412 minecraft:redstone_wire replace
fill ~303 ~31 ~412 ~303 ~31 ~416 minecraft:redstone_wire replace
fill ~321 ~31 ~416 ~321 ~31 ~420 minecraft:redstone_wire replace
fill ~84 ~31 ~420 ~84 ~31 ~424 minecraft:redstone_wire replace
fill ~105 ~31 ~424 ~105 ~31 ~428 minecraft:redstone_wire replace
fill ~123 ~31 ~428 ~123 ~31 ~432 minecraft:redstone_wire replace
fill ~159 ~31 ~432 ~159 ~31 ~436 minecraft:redstone_wire replace
fill ~183 ~31 ~436 ~183 ~31 ~440 minecraft:redstone_wire replace
fill ~207 ~31 ~440 ~207 ~31 ~444 minecraft:redstone_wire replace
fill ~231 ~31 ~444 ~231 ~31 ~448 minecraft:redstone_wire replace
fill ~255 ~31 ~448 ~255 ~31 ~452 minecraft:redstone_wire replace
fill ~300 ~31 ~452 ~300 ~31 ~456 minecraft:redstone_wire replace
fill ~318 ~31 ~456 ~318 ~31 ~460 minecraft:redstone_wire replace
fill ~81 ~31 ~460 ~81 ~31 ~464 minecraft:redstone_wire replace
fill ~102 ~31 ~464 ~102 ~31 ~468 minecraft:redstone_wire replace
fill ~120 ~31 ~468 ~120 ~31 ~472 minecraft:redstone_wire replace
fill ~147 ~31 ~472 ~147 ~31 ~476 minecraft:redstone_wire replace
fill ~180 ~31 ~476 ~180 ~31 ~480 minecraft:redstone_wire replace
fill ~204 ~31 ~480 ~204 ~31 ~484 minecraft:redstone_wire replace
fill ~228 ~31 ~484 ~228 ~31 ~488 minecraft:redstone_wire replace
fill ~249 ~31 ~488 ~249 ~31 ~492 minecraft:redstone_wire replace
fill ~291 ~31 ~492 ~291 ~31 ~496 minecraft:redstone_wire replace
fill ~315 ~31 ~496 ~315 ~31 ~500 minecraft:redstone_wire replace
fill ~78 ~31 ~500 ~78 ~31 ~504 minecraft:redstone_wire replace
fill ~99 ~31 ~504 ~99 ~31 ~508 minecraft:redstone_wire replace
fill ~117 ~31 ~508 ~117 ~31 ~512 minecraft:redstone_wire replace
fill ~141 ~31 ~512 ~141 ~31 ~516 minecraft:redstone_wire replace
fill ~177 ~31 ~516 ~177 ~31 ~520 minecraft:redstone_wire replace
fill ~195 ~31 ~520 ~195 ~31 ~524 minecraft:redstone_wire replace
fill ~225 ~31 ~524 ~225 ~31 ~528 minecraft:redstone_wire replace
fill ~246 ~31 ~528 ~246 ~31 ~532 minecraft:redstone_wire replace
fill ~288 ~31 ~532 ~288 ~31 ~536 minecraft:redstone_wire replace
fill ~312 ~31 ~536 ~312 ~31 ~540 minecraft:redstone_wire replace
fill ~96 ~31 ~540 ~96 ~31 ~544 minecraft:redstone_wire replace
fill ~114 ~31 ~544 ~114 ~31 ~548 minecraft:redstone_wire replace
fill ~138 ~31 ~548 ~138 ~31 ~552 minecraft:redstone_wire replace
fill ~168 ~31 ~552 ~168 ~31 ~556 minecraft:redstone_wire replace
fill ~192 ~31 ~556 ~192 ~31 ~560 minecraft:redstone_wire replace
fill ~222 ~31 ~560 ~222 ~31 ~564 minecraft:redstone_wire replace
fill ~252 ~31 ~564 ~252 ~31 ~568 minecraft:redstone_wire replace
fill ~270 ~31 ~568 ~270 ~31 ~572 minecraft:redstone_wire replace
fill ~306 ~31 ~572 ~306 ~31 ~576 minecraft:redstone_wire replace
fill ~156 ~31 ~576 ~156 ~31 ~580 minecraft:redstone_wire replace
fill ~327 ~31 ~580 ~327 ~31 ~584 minecraft:redstone_wire replace
fill ~93 ~31 ~584 ~93 ~31 ~588 minecraft:redstone_wire replace
fill ~309 ~31 ~588 ~309 ~31 ~592 minecraft:redstone_wire replace
fill ~324 ~31 ~592 ~324 ~31 ~596 minecraft:redstone_wire replace
setblock ~126 ~32 ~11 minecraft:redstone_wire replace
setblock ~150 ~32 ~19 minecraft:redstone_wire replace
setblock ~171 ~32 ~27 minecraft:redstone_wire replace
setblock ~198 ~32 ~35 minecraft:redstone_wire replace
setblock ~213 ~32 ~43 minecraft:redstone_wire replace
setblock ~234 ~32 ~51 minecraft:redstone_wire replace
setblock ~264 ~32 ~59 minecraft:redstone_wire replace
setblock ~276 ~32 ~63 minecraft:redstone_wire replace
setblock ~282 ~32 ~75 minecraft:redstone_wire replace
setblock ~297 ~32 ~79 minecraft:redstone_wire replace
setblock ~132 ~32 ~259 minecraft:redstone_wire replace
setblock ~144 ~32 ~267 minecraft:redstone_wire replace
setblock ~153 ~32 ~271 minecraft:redstone_wire replace
setblock ~174 ~32 ~279 minecraft:redstone_wire replace
setblock ~201 ~32 ~287 minecraft:redstone_wire replace
setblock ~216 ~32 ~295 minecraft:redstone_wire replace
setblock ~237 ~32 ~303 minecraft:redstone_wire replace
setblock ~267 ~32 ~311 minecraft:redstone_wire replace
setblock ~273 ~32 ~319 minecraft:redstone_wire replace
setblock ~279 ~32 ~327 minecraft:redstone_wire replace
setblock ~294 ~32 ~335 minecraft:redstone_wire replace
setblock ~90 ~32 ~343 minecraft:redstone_wire replace
setblock ~111 ~32 ~347 minecraft:redstone_wire replace
setblock ~135 ~32 ~351 minecraft:redstone_wire replace
setblock ~165 ~32 ~355 minecraft:redstone_wire replace
setblock ~189 ~32 ~359 minecraft:redstone_wire replace
setblock ~219 ~32 ~363 minecraft:redstone_wire replace
setblock ~243 ~32 ~367 minecraft:redstone_wire replace
setblock ~261 ~32 ~371 minecraft:redstone_wire replace
setblock ~285 ~32 ~375 minecraft:redstone_wire replace
setblock ~87 ~32 ~379 minecraft:redstone_wire replace
setblock ~108 ~32 ~383 minecraft:redstone_wire replace
setblock ~129 ~32 ~387 minecraft:redstone_wire replace
setblock ~162 ~32 ~391 minecraft:redstone_wire replace
setblock ~186 ~32 ~395 minecraft:redstone_wire replace
setblock ~210 ~32 ~399 minecraft:redstone_wire replace
setblock ~240 ~32 ~403 minecraft:redstone_wire replace
setblock ~258 ~32 ~407 minecraft:redstone_wire replace
setblock ~303 ~32 ~411 minecraft:redstone_wire replace
setblock ~321 ~32 ~415 minecraft:redstone_wire replace
setblock ~84 ~32 ~419 minecraft:redstone_wire replace
setblock ~105 ~32 ~423 minecraft:redstone_wire replace
setblock ~123 ~32 ~427 minecraft:redstone_wire replace
setblock ~159 ~32 ~431 minecraft:redstone_wire replace
setblock ~183 ~32 ~435 minecraft:redstone_wire replace
setblock ~207 ~32 ~439 minecraft:redstone_wire replace
setblock ~231 ~32 ~443 minecraft:redstone_wire replace
setblock ~255 ~32 ~447 minecraft:redstone_wire replace
setblock ~300 ~32 ~451 minecraft:redstone_wire replace
setblock ~318 ~32 ~455 minecraft:redstone_wire replace
setblock ~81 ~32 ~459 minecraft:redstone_wire replace
setblock ~102 ~32 ~463 minecraft:redstone_wire replace
setblock ~120 ~32 ~467 minecraft:redstone_wire replace
setblock ~147 ~32 ~471 minecraft:redstone_wire replace
setblock ~180 ~32 ~475 minecraft:redstone_wire replace
setblock ~204 ~32 ~479 minecraft:redstone_wire replace
setblock ~228 ~32 ~483 minecraft:redstone_wire replace
setblock ~249 ~32 ~487 minecraft:redstone_wire replace
setblock ~291 ~32 ~491 minecraft:redstone_wire replace
setblock ~315 ~32 ~495 minecraft:redstone_wire replace
setblock ~78 ~32 ~499 minecraft:redstone_wire replace
setblock ~99 ~32 ~503 minecraft:redstone_wire replace
setblock ~117 ~32 ~507 minecraft:redstone_wire replace
setblock ~141 ~32 ~511 minecraft:redstone_wire replace
setblock ~177 ~32 ~515 minecraft:redstone_wire replace
setblock ~195 ~32 ~519 minecraft:redstone_wire replace
setblock ~225 ~32 ~523 minecraft:redstone_wire replace
setblock ~246 ~32 ~527 minecraft:redstone_wire replace
setblock ~288 ~32 ~531 minecraft:redstone_wire replace
setblock ~312 ~32 ~535 minecraft:redstone_wire replace
setblock ~96 ~32 ~539 minecraft:redstone_wire replace
setblock ~114 ~32 ~543 minecraft:redstone_wire replace
setblock ~138 ~32 ~547 minecraft:redstone_wire replace
setblock ~168 ~32 ~551 minecraft:redstone_wire replace
setblock ~192 ~32 ~555 minecraft:redstone_wire replace
setblock ~222 ~32 ~559 minecraft:redstone_wire replace
setblock ~252 ~32 ~563 minecraft:redstone_wire replace
setblock ~270 ~32 ~567 minecraft:redstone_wire replace
setblock ~306 ~32 ~571 minecraft:redstone_wire replace
setblock ~156 ~32 ~575 minecraft:redstone_wire replace
setblock ~327 ~32 ~579 minecraft:redstone_wire replace
setblock ~93 ~32 ~583 minecraft:redstone_wire replace
setblock ~309 ~32 ~587 minecraft:redstone_wire replace
setblock ~324 ~32 ~591 minecraft:redstone_wire replace
setblock ~94 ~33 ~9 minecraft:redstone_wire replace
setblock ~121 ~33 ~9 minecraft:redstone_wire replace
setblock ~151 ~33 ~9 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~178 ~33 ~9 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~33 ~10 ~99 ~33 ~10 minecraft:redstone_wire replace
setblock ~101 ~33 ~10 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~33 ~10 ~116 ~33 ~10 minecraft:redstone_wire replace
setblock ~118 ~33 ~10 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~33 ~10 ~132 ~33 ~10 minecraft:redstone_wire replace
setblock ~134 ~33 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~33 ~10 ~149 ~33 ~10 minecraft:redstone_wire replace
setblock ~150 ~33 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~151 ~33 ~10 ~164 ~33 ~10 minecraft:redstone_wire replace
setblock ~166 ~33 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~168 ~33 ~10 ~179 ~33 ~10 minecraft:redstone_wire replace
setblock ~118 ~33 ~17 minecraft:redstone_wire replace
setblock ~142 ~33 ~17 minecraft:redstone_wire replace
setblock ~172 ~33 ~17 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~211 ~33 ~17 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~33 ~18 ~125 ~33 ~18 minecraft:redstone_wire replace
setblock ~127 ~33 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~33 ~18 ~142 ~33 ~18 minecraft:redstone_wire replace
setblock ~143 ~33 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~33 ~18 ~156 ~33 ~18 minecraft:redstone_wire replace
setblock ~158 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~33 ~18 ~173 ~33 ~18 minecraft:redstone_wire replace
setblock ~175 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~33 ~18 ~190 ~33 ~18 minecraft:redstone_wire replace
setblock ~192 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~33 ~18 ~207 ~33 ~18 minecraft:redstone_wire replace
setblock ~209 ~33 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~33 ~18 ~212 ~33 ~18 minecraft:redstone_wire replace
setblock ~145 ~33 ~25 minecraft:redstone_wire replace
setblock ~169 ~33 ~25 minecraft:redstone_wire replace
setblock ~202 ~33 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~253 ~33 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~33 ~26 ~146 ~33 ~26 minecraft:redstone_wire replace
setblock ~147 ~33 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~33 ~26 ~161 ~33 ~26 minecraft:redstone_wire replace
setblock ~163 ~33 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~33 ~26 ~177 ~33 ~26 minecraft:redstone_wire replace
setblock ~179 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~181 ~33 ~26 ~194 ~33 ~26 minecraft:redstone_wire replace
setblock ~196 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~198 ~33 ~26 ~211 ~33 ~26 minecraft:redstone_wire replace
setblock ~213 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~215 ~33 ~26 ~228 ~33 ~26 minecraft:redstone_wire replace
setblock ~230 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~33 ~26 ~245 ~33 ~26 minecraft:redstone_wire replace
setblock ~247 ~33 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~33 ~26 ~254 ~33 ~26 minecraft:redstone_wire replace
setblock ~175 ~33 ~33 minecraft:redstone_wire replace
setblock ~241 ~33 ~33 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~33 ~33 minecraft:redstone_wire replace
setblock ~174 ~33 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~33 ~34 ~188 ~33 ~34 minecraft:redstone_wire replace
setblock ~190 ~33 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~33 ~34 ~204 ~33 ~34 minecraft:redstone_wire replace
setblock ~206 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~33 ~34 ~221 ~33 ~34 minecraft:redstone_wire replace
setblock ~223 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~33 ~34 ~238 ~33 ~34 minecraft:redstone_wire replace
setblock ~239 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~33 ~34 ~253 ~33 ~34 minecraft:redstone_wire replace
setblock ~255 ~33 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~257 ~33 ~34 ~260 ~33 ~34 minecraft:redstone_wire replace
setblock ~196 ~33 ~41 minecraft:redstone_wire replace
setblock ~226 ~33 ~41 minecraft:redstone_wire replace
setblock ~247 ~33 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~301 ~33 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~33 ~42 ~203 ~33 ~42 minecraft:redstone_wire replace
setblock ~205 ~33 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~33 ~42 ~219 ~33 ~42 minecraft:redstone_wire replace
setblock ~221 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~33 ~42 ~236 ~33 ~42 minecraft:redstone_wire replace
setblock ~238 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~33 ~42 ~253 ~33 ~42 minecraft:redstone_wire replace
setblock ~255 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~257 ~33 ~42 ~270 ~33 ~42 minecraft:redstone_wire replace
setblock ~272 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~274 ~33 ~42 ~287 ~33 ~42 minecraft:redstone_wire replace
setblock ~289 ~33 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~291 ~33 ~42 ~302 ~33 ~42 minecraft:redstone_wire replace
setblock ~229 ~33 ~49 minecraft:redstone_wire replace
setblock ~262 ~33 ~49 minecraft:redstone_wire replace
setblock ~283 ~33 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~331 ~33 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~33 ~50 ~240 ~33 ~50 minecraft:redstone_wire replace
setblock ~242 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~33 ~50 ~257 ~33 ~50 minecraft:redstone_wire replace
setblock ~259 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~33 ~50 ~274 ~33 ~50 minecraft:redstone_wire replace
setblock ~276 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~278 ~33 ~50 ~291 ~33 ~50 minecraft:redstone_wire replace
setblock ~293 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~295 ~33 ~50 ~308 ~33 ~50 minecraft:redstone_wire replace
setblock ~310 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~312 ~33 ~50 ~325 ~33 ~50 minecraft:redstone_wire replace
setblock ~327 ~33 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~329 ~33 ~50 ~332 ~33 ~50 minecraft:redstone_wire replace
setblock ~265 ~33 ~57 minecraft:redstone_wire replace
setblock ~316 ~33 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~322 ~33 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~340 ~33 ~57 minecraft:redstone_wire replace
fill ~264 ~33 ~58 ~269 ~33 ~58 minecraft:redstone_wire replace
setblock ~271 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~33 ~58 ~285 ~33 ~58 minecraft:redstone_wire replace
setblock ~287 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~289 ~33 ~58 ~301 ~33 ~58 minecraft:redstone_wire replace
setblock ~303 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~305 ~33 ~58 ~317 ~33 ~58 minecraft:redstone_wire replace
setblock ~319 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~321 ~33 ~58 ~333 ~33 ~58 minecraft:redstone_wire replace
setblock ~335 ~33 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~337 ~33 ~58 ~341 ~33 ~58 minecraft:redstone_wire replace
setblock ~319 ~33 ~61 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~337 ~33 ~61 minecraft:redstone_wire replace
setblock ~343 ~33 ~61 minecraft:redstone_wire replace
fill ~276 ~33 ~62 ~282 ~33 ~62 minecraft:redstone_wire replace
setblock ~284 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~286 ~33 ~62 ~299 ~33 ~62 minecraft:redstone_wire replace
setblock ~301 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~303 ~33 ~62 ~316 ~33 ~62 minecraft:redstone_wire replace
setblock ~317 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~318 ~33 ~62 ~331 ~33 ~62 minecraft:redstone_wire replace
setblock ~333 ~33 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~335 ~33 ~62 ~344 ~33 ~62 minecraft:redstone_wire replace
setblock ~286 ~33 ~73 minecraft:redstone_wire replace
setblock ~328 ~33 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~352 ~33 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~388 ~33 ~73 minecraft:redstone_wire replace
fill ~282 ~33 ~74 ~288 ~33 ~74 minecraft:redstone_wire replace
setblock ~290 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~292 ~33 ~74 ~305 ~33 ~74 minecraft:redstone_wire replace
setblock ~307 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~309 ~33 ~74 ~322 ~33 ~74 minecraft:redstone_wire replace
setblock ~324 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~326 ~33 ~74 ~339 ~33 ~74 minecraft:redstone_wire replace
setblock ~341 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~343 ~33 ~74 ~356 ~33 ~74 minecraft:redstone_wire replace
setblock ~358 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~360 ~33 ~74 ~373 ~33 ~74 minecraft:redstone_wire replace
setblock ~375 ~33 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~377 ~33 ~74 ~389 ~33 ~74 minecraft:redstone_wire replace
setblock ~355 ~33 ~77 minecraft:redstone_wire replace
setblock ~361 ~33 ~77 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~379 ~33 ~77 minecraft:redstone_wire replace
fill ~297 ~33 ~78 ~302 ~33 ~78 minecraft:redstone_wire replace
setblock ~304 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~306 ~33 ~78 ~318 ~33 ~78 minecraft:redstone_wire replace
setblock ~320 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~322 ~33 ~78 ~334 ~33 ~78 minecraft:redstone_wire replace
setblock ~336 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~338 ~33 ~78 ~350 ~33 ~78 minecraft:redstone_wire replace
setblock ~352 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~354 ~33 ~78 ~366 ~33 ~78 minecraft:redstone_wire replace
setblock ~368 ~33 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~370 ~33 ~78 ~380 ~33 ~78 minecraft:redstone_wire replace
setblock ~94 ~33 ~257 minecraft:redstone_wire replace
setblock ~121 ~33 ~257 minecraft:redstone_wire replace
setblock ~151 ~33 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~181 ~33 ~257 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~33 ~258 ~99 ~33 ~258 minecraft:redstone_wire replace
setblock ~101 ~33 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~33 ~258 ~116 ~33 ~258 minecraft:redstone_wire replace
setblock ~118 ~33 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~33 ~258 ~144 ~33 ~258 minecraft:redstone_wire replace
setblock ~146 ~33 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~33 ~258 ~161 ~33 ~258 minecraft:redstone_wire replace
setblock ~163 ~33 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~33 ~258 ~178 ~33 ~258 minecraft:redstone_wire replace
setblock ~179 ~33 ~258 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~180 ~33 ~258 ~182 ~33 ~258 minecraft:redstone_wire replace
setblock ~157 ~33 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~33 ~266 ~150 ~33 ~266 minecraft:redstone_wire replace
setblock ~152 ~33 ~266 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~154 ~33 ~266 ~158 ~33 ~266 minecraft:redstone_wire replace
setblock ~118 ~33 ~269 minecraft:redstone_wire replace
setblock ~142 ~33 ~269 minecraft:redstone_wire replace
setblock ~172 ~33 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~214 ~33 ~269 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~33 ~270 ~120 ~33 ~270 minecraft:redstone_wire replace
setblock ~122 ~33 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~33 ~270 ~137 ~33 ~270 minecraft:redstone_wire replace
setblock ~139 ~33 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~33 ~270 ~165 ~33 ~270 minecraft:redstone_wire replace
setblock ~167 ~33 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~33 ~270 ~182 ~33 ~270 minecraft:redstone_wire replace
setblock ~184 ~33 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~33 ~270 ~199 ~33 ~270 minecraft:redstone_wire replace
setblock ~201 ~33 ~270 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~203 ~33 ~270 ~215 ~33 ~270 minecraft:redstone_wire replace
setblock ~145 ~33 ~277 minecraft:redstone_wire replace
setblock ~169 ~33 ~277 minecraft:redstone_wire replace
setblock ~202 ~33 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~256 ~33 ~277 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~33 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~33 ~278 ~158 ~33 ~278 minecraft:redstone_wire replace
setblock ~160 ~33 ~278 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~33 ~278 ~186 ~33 ~278 minecraft:redstone_wire replace
setblock ~188 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~190 ~33 ~278 ~203 ~33 ~278 minecraft:redstone_wire replace
setblock ~205 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~207 ~33 ~278 ~220 ~33 ~278 minecraft:redstone_wire replace
setblock ~222 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~224 ~33 ~278 ~237 ~33 ~278 minecraft:redstone_wire replace
setblock ~239 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~33 ~278 ~254 ~33 ~278 minecraft:redstone_wire replace
setblock ~255 ~33 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~256 ~33 ~278 ~257 ~33 ~278 minecraft:redstone_wire replace
setblock ~175 ~33 ~285 minecraft:redstone_wire replace
setblock ~241 ~33 ~285 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~259 ~33 ~285 minecraft:redstone_wire replace
fill ~174 ~33 ~286 ~185 ~33 ~286 minecraft:redstone_wire replace
setblock ~187 ~33 ~286 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~33 ~286 ~213 ~33 ~286 minecraft:redstone_wire replace
setblock ~215 ~33 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~33 ~286 ~230 ~33 ~286 minecraft:redstone_wire replace
setblock ~232 ~33 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~33 ~286 ~247 ~33 ~286 minecraft:redstone_wire replace
setblock ~249 ~33 ~286 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~251 ~33 ~286 ~260 ~33 ~286 minecraft:redstone_wire replace
setblock ~196 ~33 ~293 minecraft:redstone_wire replace
setblock ~226 ~33 ~293 minecraft:redstone_wire replace
setblock ~247 ~33 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~304 ~33 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~33 ~294 ~200 ~33 ~294 minecraft:redstone_wire replace
setblock ~202 ~33 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~33 ~294 ~228 ~33 ~294 minecraft:redstone_wire replace
setblock ~230 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~33 ~294 ~245 ~33 ~294 minecraft:redstone_wire replace
setblock ~246 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~33 ~294 ~260 ~33 ~294 minecraft:redstone_wire replace
setblock ~262 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~33 ~294 ~277 ~33 ~294 minecraft:redstone_wire replace
setblock ~279 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~33 ~294 ~294 ~33 ~294 minecraft:redstone_wire replace
setblock ~296 ~33 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~33 ~294 ~305 ~33 ~294 minecraft:redstone_wire replace
