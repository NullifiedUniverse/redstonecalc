setblock ~172 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~174 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~189 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~191 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~206 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~208 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~223 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~225 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~240 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~242 ~149 ~546 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~548 minecraft:light_gray_concrete replace
setblock ~250 ~149 ~548 minecraft:light_gray_concrete replace
setblock ~256 ~149 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~126 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~141 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~143 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~158 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~160 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~175 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~177 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~192 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~194 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~209 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~211 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~226 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~228 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~243 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~245 ~149 ~570 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~572 minecraft:light_gray_concrete replace
setblock ~256 ~149 ~572 minecraft:light_gray_concrete replace
setblock ~259 ~149 ~572 minecraft:light_gray_concrete replace
setblock ~127 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~129 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~144 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~146 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~161 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~163 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~178 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~180 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~195 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~197 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~212 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~214 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~229 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~231 ~149 ~578 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~580 minecraft:light_gray_concrete replace
setblock ~253 ~149 ~580 minecraft:light_gray_concrete replace
setblock ~256 ~149 ~580 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~135 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~150 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~152 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~167 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~184 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~186 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~201 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~203 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~218 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~235 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~237 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~252 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~254 ~149 ~606 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~608 minecraft:light_gray_concrete replace
setblock ~256 ~149 ~608 minecraft:light_gray_concrete replace
setblock ~265 ~149 ~608 minecraft:light_gray_concrete replace
setblock ~268 ~149 ~608 minecraft:light_gray_concrete replace
setblock ~130 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~132 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~147 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~149 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~164 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~181 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~183 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~198 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~200 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~215 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~232 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~234 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~249 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~251 ~149 ~610 minecraft:light_gray_concrete replace
setblock ~247 ~149 ~612 minecraft:light_gray_concrete replace
setblock ~256 ~149 ~612 minecraft:light_gray_concrete replace
setblock ~262 ~149 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~141 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~156 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~158 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~173 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~175 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~192 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~207 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~209 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~224 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~226 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~241 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~243 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~258 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~260 ~149 ~646 minecraft:light_gray_concrete replace
setblock ~277 ~149 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~88 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~91 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~94 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~97 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~100 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~106 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~109 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~112 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~118 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~121 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~124 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~136 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~142 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~145 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~148 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~160 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~163 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~172 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~175 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~178 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~181 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~184 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~187 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~193 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~196 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~199 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~202 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~208 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~211 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~214 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~217 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~223 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~226 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~229 ~149 ~652 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~135 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~150 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~152 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~167 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~169 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~184 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~186 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~201 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~203 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~218 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~220 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~235 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~237 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~252 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~254 ~149 ~654 minecraft:light_gray_concrete replace
setblock ~271 ~149 ~656 minecraft:light_gray_concrete replace
setblock ~136 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~138 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~153 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~155 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~170 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~172 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~187 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~189 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~204 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~206 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~221 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~223 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~238 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~240 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~255 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~257 ~149 ~662 minecraft:light_gray_concrete replace
setblock ~274 ~149 ~664 minecraft:light_gray_concrete replace
fill ~231 ~150 ~232 ~231 ~150 ~388 minecraft:light_gray_concrete replace
fill ~81 ~150 ~236 ~81 ~150 ~400 minecraft:light_gray_concrete replace
fill ~228 ~150 ~240 ~228 ~150 ~652 minecraft:light_gray_concrete replace
fill ~225 ~150 ~244 ~225 ~150 ~652 minecraft:light_gray_concrete replace
fill ~222 ~150 ~248 ~222 ~150 ~652 minecraft:light_gray_concrete replace
fill ~219 ~150 ~252 ~219 ~150 ~652 minecraft:light_gray_concrete replace
fill ~216 ~150 ~256 ~216 ~150 ~652 minecraft:light_gray_concrete replace
fill ~213 ~150 ~260 ~213 ~150 ~652 minecraft:light_gray_concrete replace
fill ~210 ~150 ~264 ~210 ~150 ~652 minecraft:light_gray_concrete replace
fill ~207 ~150 ~268 ~207 ~150 ~652 minecraft:light_gray_concrete replace
fill ~204 ~150 ~272 ~204 ~150 ~652 minecraft:light_gray_concrete replace
fill ~201 ~150 ~276 ~201 ~150 ~652 minecraft:light_gray_concrete replace
fill ~198 ~150 ~280 ~198 ~150 ~652 minecraft:light_gray_concrete replace
fill ~195 ~150 ~284 ~195 ~150 ~652 minecraft:light_gray_concrete replace
fill ~192 ~150 ~288 ~192 ~150 ~652 minecraft:light_gray_concrete replace
fill ~189 ~150 ~292 ~189 ~150 ~652 minecraft:light_gray_concrete replace
fill ~186 ~150 ~296 ~186 ~150 ~652 minecraft:light_gray_concrete replace
fill ~183 ~150 ~300 ~183 ~150 ~652 minecraft:light_gray_concrete replace
fill ~180 ~150 ~304 ~180 ~150 ~652 minecraft:light_gray_concrete replace
fill ~177 ~150 ~308 ~177 ~150 ~652 minecraft:light_gray_concrete replace
fill ~174 ~150 ~312 ~174 ~150 ~652 minecraft:light_gray_concrete replace
fill ~171 ~150 ~316 ~171 ~150 ~652 minecraft:light_gray_concrete replace
fill ~168 ~150 ~320 ~168 ~150 ~652 minecraft:light_gray_concrete replace
fill ~165 ~150 ~324 ~165 ~150 ~652 minecraft:light_gray_concrete replace
fill ~162 ~150 ~328 ~162 ~150 ~652 minecraft:light_gray_concrete replace
fill ~159 ~150 ~332 ~159 ~150 ~652 minecraft:light_gray_concrete replace
fill ~156 ~150 ~336 ~156 ~150 ~652 minecraft:light_gray_concrete replace
fill ~153 ~150 ~340 ~153 ~150 ~652 minecraft:light_gray_concrete replace
fill ~150 ~150 ~344 ~150 ~150 ~652 minecraft:light_gray_concrete replace
fill ~147 ~150 ~348 ~147 ~150 ~652 minecraft:light_gray_concrete replace
fill ~144 ~150 ~352 ~144 ~150 ~652 minecraft:light_gray_concrete replace
fill ~141 ~150 ~356 ~141 ~150 ~652 minecraft:light_gray_concrete replace
fill ~138 ~150 ~360 ~138 ~150 ~652 minecraft:light_gray_concrete replace
fill ~135 ~150 ~364 ~135 ~150 ~652 minecraft:light_gray_concrete replace
fill ~132 ~150 ~368 ~132 ~150 ~652 minecraft:light_gray_concrete replace
fill ~129 ~150 ~372 ~129 ~150 ~652 minecraft:light_gray_concrete replace
fill ~126 ~150 ~376 ~126 ~150 ~652 minecraft:light_gray_concrete replace
fill ~123 ~150 ~380 ~123 ~150 ~652 minecraft:light_gray_concrete replace
fill ~120 ~150 ~384 ~120 ~150 ~652 minecraft:light_gray_concrete replace
fill ~117 ~150 ~388 ~117 ~150 ~652 minecraft:light_gray_concrete replace
fill ~114 ~150 ~392 ~114 ~150 ~652 minecraft:light_gray_concrete replace
fill ~111 ~150 ~396 ~111 ~150 ~652 minecraft:light_gray_concrete replace
fill ~108 ~150 ~400 ~108 ~150 ~652 minecraft:light_gray_concrete replace
fill ~105 ~150 ~404 ~105 ~150 ~652 minecraft:light_gray_concrete replace
fill ~102 ~150 ~408 ~102 ~150 ~652 minecraft:light_gray_concrete replace
fill ~99 ~150 ~412 ~99 ~150 ~652 minecraft:light_gray_concrete replace
fill ~96 ~150 ~416 ~96 ~150 ~652 minecraft:light_gray_concrete replace
fill ~93 ~150 ~420 ~93 ~150 ~652 minecraft:light_gray_concrete replace
fill ~90 ~150 ~424 ~90 ~150 ~652 minecraft:light_gray_concrete replace
fill ~87 ~150 ~428 ~87 ~150 ~652 minecraft:light_gray_concrete replace
fill ~84 ~150 ~432 ~84 ~150 ~652 minecraft:light_gray_concrete replace
fill ~78 ~150 ~448 ~78 ~150 ~452 minecraft:light_gray_concrete replace
fill ~246 ~150 ~476 ~246 ~150 ~612 minecraft:light_gray_concrete replace
fill ~234 ~150 ~480 ~234 ~150 ~484 minecraft:light_gray_concrete replace
fill ~240 ~150 ~500 ~240 ~150 ~504 minecraft:light_gray_concrete replace
fill ~237 ~150 ~512 ~237 ~150 ~516 minecraft:light_gray_concrete replace
fill ~243 ~150 ~536 ~243 ~150 ~540 minecraft:light_gray_concrete replace
fill ~255 ~150 ~540 ~255 ~150 ~612 minecraft:light_gray_concrete replace
fill ~249 ~150 ~544 ~249 ~150 ~548 minecraft:light_gray_concrete replace
fill ~258 ~150 ~568 ~258 ~150 ~572 minecraft:light_gray_concrete replace
fill ~252 ~150 ~576 ~252 ~150 ~580 minecraft:light_gray_concrete replace
fill ~267 ~150 ~600 ~267 ~150 ~608 minecraft:light_gray_concrete replace
fill ~264 ~150 ~604 ~264 ~150 ~608 minecraft:light_gray_concrete replace
fill ~261 ~150 ~608 ~261 ~150 ~612 minecraft:light_gray_concrete replace
fill ~276 ~150 ~644 ~276 ~150 ~648 minecraft:light_gray_concrete replace
fill ~270 ~150 ~652 ~270 ~150 ~656 minecraft:light_gray_concrete replace
fill ~273 ~150 ~660 ~273 ~150 ~664 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~231 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~233 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~235 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~239 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~241 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~243 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~243 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~245 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~245 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~247 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~247 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~251 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~255 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~255 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~255 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~255 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~255 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~257 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~257 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~257 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~257 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~257 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~259 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~259 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~261 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~261 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~263 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~263 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~267 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~271 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~273 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~275 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~275 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~277 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~277 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~279 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~279 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~283 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~287 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~289 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~291 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~291 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~293 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~293 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~295 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~295 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~299 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~303 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~305 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~307 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~307 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~309 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~309 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~311 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~311 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~315 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~319 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~321 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~323 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~323 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~325 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~325 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~327 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~327 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~331 minecraft:light_gray_concrete replace
setblock ~156 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~335 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~337 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~339 minecraft:light_gray_concrete replace
setblock ~153 ~151 ~339 minecraft:light_gray_concrete replace
setblock ~153 ~151 ~341 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~341 minecraft:light_gray_concrete replace
setblock ~150 ~151 ~343 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~343 minecraft:light_gray_concrete replace
setblock ~147 ~151 ~347 minecraft:light_gray_concrete replace
setblock ~144 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~147 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~150 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~153 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~156 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~351 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~147 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~150 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~153 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~156 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~353 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~355 minecraft:light_gray_concrete replace
setblock ~141 ~151 ~355 minecraft:light_gray_concrete replace
setblock ~141 ~151 ~357 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~357 minecraft:light_gray_concrete replace
setblock ~138 ~151 ~359 minecraft:light_gray_concrete replace
setblock ~231 ~151 ~359 minecraft:light_gray_concrete replace
setblock ~135 ~151 ~363 minecraft:light_gray_concrete replace
setblock ~132 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~135 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~138 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~141 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~144 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~147 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~150 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~153 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~156 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~171 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~174 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~177 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~180 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~183 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~186 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~189 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~192 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~195 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~198 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~201 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~204 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~207 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~210 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~213 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~216 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~219 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~222 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~225 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~228 ~151 ~367 minecraft:light_gray_concrete replace
setblock ~81 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~135 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~138 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~141 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~144 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~147 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~150 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~153 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~156 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~159 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~162 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~165 ~151 ~369 minecraft:light_gray_concrete replace
setblock ~168 ~151 ~369 minecraft:light_gray_concrete replace
