setblock ~76 ~16 ~18 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~22 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~26 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~30 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~34 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~38 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~42 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~46 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~50 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~54 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~58 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~62 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~66 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~70 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~74 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~78 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~94 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~96 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~98 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~102 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~106 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~110 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~114 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~116 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~118 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~122 minecraft:redstone_torch[lit=true] replace
setblock ~76 ~16 ~124 minecraft:redstone_torch[lit=true] replace
setblock ~64 ~16 ~125 minecraft:redstone_wire replace
fill ~77 ~17 ~2 ~89 ~17 ~2 minecraft:redstone_wire replace
setblock ~90 ~17 ~2 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~91 ~17 ~2 ~103 ~17 ~2 minecraft:redstone_wire replace
setblock ~105 ~17 ~2 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~107 ~17 ~2 ~110 ~17 ~2 minecraft:redstone_wire replace
setblock ~79 ~17 ~3 minecraft:redstone_wire replace
setblock ~82 ~17 ~3 minecraft:redstone_wire replace
setblock ~85 ~17 ~3 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~17 ~3 minecraft:redstone_wire replace
setblock ~91 ~17 ~3 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~17 ~3 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~6 ~90 ~17 ~6 minecraft:redstone_wire replace
setblock ~92 ~17 ~6 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~6 ~107 ~17 ~6 minecraft:redstone_wire replace
setblock ~109 ~17 ~6 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~6 ~116 ~17 ~6 minecraft:redstone_wire replace
setblock ~94 ~17 ~7 minecraft:redstone_wire replace
setblock ~97 ~17 ~7 minecraft:redstone_wire replace
setblock ~100 ~17 ~7 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~17 ~7 minecraft:redstone_wire replace
setblock ~106 ~17 ~7 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~17 ~7 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~10 ~90 ~17 ~10 minecraft:redstone_wire replace
setblock ~92 ~17 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~10 ~107 ~17 ~10 minecraft:redstone_wire replace
setblock ~109 ~17 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~10 ~124 ~17 ~10 minecraft:redstone_wire replace
setblock ~125 ~17 ~10 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~17 ~10 ~134 ~17 ~10 minecraft:redstone_wire replace
setblock ~112 ~17 ~11 minecraft:redstone_wire replace
setblock ~118 ~17 ~11 minecraft:redstone_wire replace
setblock ~121 ~17 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~17 ~11 minecraft:redstone_wire replace
setblock ~127 ~17 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~17 ~11 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~14 ~90 ~17 ~14 minecraft:redstone_wire replace
setblock ~92 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~14 ~107 ~17 ~14 minecraft:redstone_wire replace
setblock ~109 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~14 ~124 ~17 ~14 minecraft:redstone_wire replace
setblock ~126 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~14 ~141 ~17 ~14 minecraft:redstone_wire replace
setblock ~143 ~17 ~14 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~14 ~155 ~17 ~14 minecraft:redstone_wire replace
setblock ~136 ~17 ~15 minecraft:redstone_wire replace
setblock ~139 ~17 ~15 minecraft:redstone_wire replace
setblock ~145 ~17 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~17 ~15 minecraft:redstone_wire replace
setblock ~151 ~17 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~17 ~15 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~18 ~90 ~17 ~18 minecraft:redstone_wire replace
setblock ~92 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~18 ~107 ~17 ~18 minecraft:redstone_wire replace
setblock ~109 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~18 ~124 ~17 ~18 minecraft:redstone_wire replace
setblock ~126 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~18 ~141 ~17 ~18 minecraft:redstone_wire replace
setblock ~143 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~18 ~158 ~17 ~18 minecraft:redstone_wire replace
setblock ~159 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~17 ~18 ~173 ~17 ~18 minecraft:redstone_wire replace
setblock ~174 ~17 ~18 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~17 ~18 ~176 ~17 ~18 minecraft:redstone_wire replace
setblock ~160 ~17 ~19 minecraft:redstone_wire replace
setblock ~163 ~17 ~19 minecraft:redstone_wire replace
setblock ~166 ~17 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~17 ~19 minecraft:redstone_wire replace
setblock ~172 ~17 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~175 ~17 ~19 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~22 ~89 ~17 ~22 minecraft:redstone_wire replace
setblock ~91 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~22 ~105 ~17 ~22 minecraft:redstone_wire replace
setblock ~107 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~22 ~121 ~17 ~22 minecraft:redstone_wire replace
setblock ~123 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~22 ~137 ~17 ~22 minecraft:redstone_wire replace
setblock ~139 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~22 ~153 ~17 ~22 minecraft:redstone_wire replace
setblock ~155 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~22 ~169 ~17 ~22 minecraft:redstone_wire replace
setblock ~171 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~22 ~185 ~17 ~22 minecraft:redstone_wire replace
setblock ~187 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~22 ~202 ~17 ~22 minecraft:redstone_wire replace
setblock ~203 ~17 ~22 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~17 ~22 ~206 ~17 ~22 minecraft:redstone_wire replace
setblock ~184 ~17 ~23 minecraft:redstone_wire replace
setblock ~193 ~17 ~23 minecraft:redstone_wire replace
setblock ~196 ~17 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~17 ~23 minecraft:redstone_wire replace
setblock ~202 ~17 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~205 ~17 ~23 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~26 ~90 ~17 ~26 minecraft:redstone_wire replace
setblock ~92 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~26 ~107 ~17 ~26 minecraft:redstone_wire replace
setblock ~109 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~26 ~124 ~17 ~26 minecraft:redstone_wire replace
setblock ~126 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~26 ~141 ~17 ~26 minecraft:redstone_wire replace
setblock ~143 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~26 ~158 ~17 ~26 minecraft:redstone_wire replace
setblock ~160 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~26 ~175 ~17 ~26 minecraft:redstone_wire replace
setblock ~177 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~26 ~192 ~17 ~26 minecraft:redstone_wire replace
setblock ~194 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~26 ~209 ~17 ~26 minecraft:redstone_wire replace
setblock ~210 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~17 ~26 ~224 ~17 ~26 minecraft:redstone_wire replace
setblock ~225 ~17 ~26 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~17 ~26 ~239 ~17 ~26 minecraft:redstone_wire replace
setblock ~211 ~17 ~27 minecraft:redstone_wire replace
setblock ~214 ~17 ~27 minecraft:redstone_wire replace
setblock ~217 ~17 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~17 ~27 minecraft:redstone_wire replace
setblock ~226 ~17 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~238 ~17 ~27 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~30 ~90 ~17 ~30 minecraft:redstone_wire replace
setblock ~92 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~30 ~107 ~17 ~30 minecraft:redstone_wire replace
setblock ~109 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~30 ~124 ~17 ~30 minecraft:redstone_wire replace
setblock ~126 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~30 ~141 ~17 ~30 minecraft:redstone_wire replace
setblock ~143 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~30 ~158 ~17 ~30 minecraft:redstone_wire replace
setblock ~160 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~30 ~175 ~17 ~30 minecraft:redstone_wire replace
setblock ~177 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~30 ~192 ~17 ~30 minecraft:redstone_wire replace
setblock ~194 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~30 ~209 ~17 ~30 minecraft:redstone_wire replace
setblock ~211 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~30 ~226 ~17 ~30 minecraft:redstone_wire replace
setblock ~228 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~30 ~243 ~17 ~30 minecraft:redstone_wire replace
setblock ~245 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~30 ~260 ~17 ~30 minecraft:redstone_wire replace
setblock ~262 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~30 ~277 ~17 ~30 minecraft:redstone_wire replace
setblock ~278 ~17 ~30 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~30 ~284 ~17 ~30 minecraft:redstone_wire replace
setblock ~250 ~17 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~265 ~17 ~31 minecraft:redstone_wire replace
setblock ~268 ~17 ~31 minecraft:redstone_wire replace
setblock ~277 ~17 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~280 ~17 ~31 minecraft:redstone_wire replace
setblock ~283 ~17 ~31 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~34 ~89 ~17 ~34 minecraft:redstone_wire replace
setblock ~91 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~34 ~105 ~17 ~34 minecraft:redstone_wire replace
setblock ~107 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~34 ~121 ~17 ~34 minecraft:redstone_wire replace
setblock ~123 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~34 ~137 ~17 ~34 minecraft:redstone_wire replace
setblock ~139 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~34 ~153 ~17 ~34 minecraft:redstone_wire replace
setblock ~155 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~34 ~169 ~17 ~34 minecraft:redstone_wire replace
setblock ~171 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~34 ~185 ~17 ~34 minecraft:redstone_wire replace
setblock ~187 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~34 ~201 ~17 ~34 minecraft:redstone_wire replace
setblock ~203 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~34 ~217 ~17 ~34 minecraft:redstone_wire replace
setblock ~219 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~34 ~233 ~17 ~34 minecraft:redstone_wire replace
setblock ~234 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~17 ~34 ~247 ~17 ~34 minecraft:redstone_wire replace
setblock ~248 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~17 ~34 ~261 ~17 ~34 minecraft:redstone_wire replace
setblock ~263 ~17 ~34 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~265 ~17 ~34 ~272 ~17 ~34 minecraft:redstone_wire replace
setblock ~232 ~17 ~35 minecraft:redstone_wire replace
setblock ~235 ~17 ~35 minecraft:redstone_wire replace
setblock ~241 ~17 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~244 ~17 ~35 minecraft:redstone_wire replace
setblock ~247 ~17 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~271 ~17 ~35 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~38 ~89 ~17 ~38 minecraft:redstone_wire replace
setblock ~91 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~38 ~105 ~17 ~38 minecraft:redstone_wire replace
setblock ~107 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~38 ~121 ~17 ~38 minecraft:redstone_wire replace
setblock ~123 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~38 ~137 ~17 ~38 minecraft:redstone_wire replace
setblock ~139 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~38 ~153 ~17 ~38 minecraft:redstone_wire replace
setblock ~155 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~38 ~169 ~17 ~38 minecraft:redstone_wire replace
setblock ~171 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~38 ~185 ~17 ~38 minecraft:redstone_wire replace
setblock ~187 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~38 ~201 ~17 ~38 minecraft:redstone_wire replace
setblock ~203 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~38 ~217 ~17 ~38 minecraft:redstone_wire replace
setblock ~219 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~38 ~233 ~17 ~38 minecraft:redstone_wire replace
setblock ~235 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~17 ~38 ~249 ~17 ~38 minecraft:redstone_wire replace
setblock ~251 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~17 ~38 ~265 ~17 ~38 minecraft:redstone_wire replace
setblock ~267 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~17 ~38 ~281 ~17 ~38 minecraft:redstone_wire replace
setblock ~283 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~17 ~38 ~298 ~17 ~38 minecraft:redstone_wire replace
setblock ~299 ~17 ~38 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~259 ~17 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~286 ~17 ~39 minecraft:redstone_wire replace
setblock ~289 ~17 ~39 minecraft:redstone_wire replace
setblock ~292 ~17 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~295 ~17 ~39 minecraft:redstone_wire replace
setblock ~298 ~17 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~42 ~89 ~17 ~42 minecraft:redstone_wire replace
setblock ~90 ~17 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~91 ~17 ~42 ~103 ~17 ~42 minecraft:redstone_wire replace
setblock ~105 ~17 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~107 ~17 ~42 ~119 ~17 ~42 minecraft:redstone_wire replace
setblock ~121 ~17 ~42 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~17 ~42 ~131 ~17 ~42 minecraft:redstone_wire replace
setblock ~82 ~17 ~43 minecraft:redstone_wire replace
setblock ~85 ~17 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~17 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~17 ~43 minecraft:redstone_wire replace
setblock ~130 ~17 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~46 ~89 ~17 ~46 minecraft:redstone_wire replace
setblock ~91 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~46 ~106 ~17 ~46 minecraft:redstone_wire replace
setblock ~107 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~108 ~17 ~46 ~120 ~17 ~46 minecraft:redstone_wire replace
setblock ~122 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~17 ~46 ~136 ~17 ~46 minecraft:redstone_wire replace
setblock ~138 ~17 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~140 ~17 ~46 ~143 ~17 ~46 minecraft:redstone_wire replace
setblock ~97 ~17 ~47 minecraft:redstone_wire replace
setblock ~100 ~17 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~17 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~17 ~47 minecraft:redstone_wire replace
setblock ~142 ~17 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~50 ~89 ~17 ~50 minecraft:redstone_wire replace
setblock ~91 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~50 ~105 ~17 ~50 minecraft:redstone_wire replace
setblock ~107 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~50 ~121 ~17 ~50 minecraft:redstone_wire replace
setblock ~122 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~17 ~50 ~135 ~17 ~50 minecraft:redstone_wire replace
setblock ~137 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~17 ~50 ~151 ~17 ~50 minecraft:redstone_wire replace
setblock ~153 ~17 ~50 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~155 ~17 ~50 ~158 ~17 ~50 minecraft:redstone_wire replace
setblock ~118 ~17 ~51 minecraft:redstone_wire replace
setblock ~121 ~17 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~17 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~17 ~51 minecraft:redstone_wire replace
setblock ~157 ~17 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~54 ~90 ~17 ~54 minecraft:redstone_wire replace
setblock ~92 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~54 ~107 ~17 ~54 minecraft:redstone_wire replace
setblock ~109 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~54 ~124 ~17 ~54 minecraft:redstone_wire replace
setblock ~126 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~54 ~141 ~17 ~54 minecraft:redstone_wire replace
setblock ~143 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~54 ~158 ~17 ~54 minecraft:redstone_wire replace
setblock ~160 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~54 ~175 ~17 ~54 minecraft:redstone_wire replace
setblock ~177 ~17 ~54 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~54 ~191 ~17 ~54 minecraft:redstone_wire replace
setblock ~139 ~17 ~55 minecraft:redstone_wire replace
setblock ~145 ~17 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~17 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~17 ~55 minecraft:redstone_wire replace
setblock ~190 ~17 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~58 ~90 ~17 ~58 minecraft:redstone_wire replace
setblock ~92 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~58 ~107 ~17 ~58 minecraft:redstone_wire replace
setblock ~109 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~58 ~124 ~17 ~58 minecraft:redstone_wire replace
setblock ~126 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~58 ~141 ~17 ~58 minecraft:redstone_wire replace
setblock ~143 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~58 ~158 ~17 ~58 minecraft:redstone_wire replace
setblock ~160 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~58 ~175 ~17 ~58 minecraft:redstone_wire replace
setblock ~177 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~58 ~192 ~17 ~58 minecraft:redstone_wire replace
setblock ~194 ~17 ~58 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~58 ~209 ~17 ~58 minecraft:redstone_wire replace
setblock ~163 ~17 ~59 minecraft:redstone_wire replace
setblock ~166 ~17 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~17 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~17 ~59 minecraft:redstone_wire replace
setblock ~208 ~17 ~59 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~62 ~89 ~17 ~62 minecraft:redstone_wire replace
setblock ~91 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~62 ~105 ~17 ~62 minecraft:redstone_wire replace
setblock ~107 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~62 ~121 ~17 ~62 minecraft:redstone_wire replace
setblock ~123 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~62 ~137 ~17 ~62 minecraft:redstone_wire replace
setblock ~139 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~62 ~153 ~17 ~62 minecraft:redstone_wire replace
setblock ~155 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~62 ~169 ~17 ~62 minecraft:redstone_wire replace
setblock ~171 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~62 ~185 ~17 ~62 minecraft:redstone_wire replace
setblock ~187 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~62 ~202 ~17 ~62 minecraft:redstone_wire replace
setblock ~203 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~17 ~62 ~216 ~17 ~62 minecraft:redstone_wire replace
setblock ~218 ~17 ~62 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~17 ~62 ~221 ~17 ~62 minecraft:redstone_wire replace
setblock ~193 ~17 ~63 minecraft:redstone_wire replace
setblock ~196 ~17 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~17 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~202 ~17 ~63 minecraft:redstone_wire replace
setblock ~220 ~17 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~66 ~90 ~17 ~66 minecraft:redstone_wire replace
setblock ~92 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~66 ~107 ~17 ~66 minecraft:redstone_wire replace
setblock ~109 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~66 ~124 ~17 ~66 minecraft:redstone_wire replace
setblock ~126 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~66 ~141 ~17 ~66 minecraft:redstone_wire replace
setblock ~143 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~66 ~158 ~17 ~66 minecraft:redstone_wire replace
setblock ~160 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~66 ~175 ~17 ~66 minecraft:redstone_wire replace
setblock ~177 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~66 ~192 ~17 ~66 minecraft:redstone_wire replace
setblock ~194 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~66 ~209 ~17 ~66 minecraft:redstone_wire replace
setblock ~211 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~66 ~226 ~17 ~66 minecraft:redstone_wire replace
setblock ~227 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~17 ~66 ~241 ~17 ~66 minecraft:redstone_wire replace
setblock ~243 ~17 ~66 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~17 ~66 ~254 ~17 ~66 minecraft:redstone_wire replace
setblock ~214 ~17 ~67 minecraft:redstone_wire replace
setblock ~217 ~17 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~17 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~226 ~17 ~67 minecraft:redstone_wire replace
setblock ~253 ~17 ~67 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~70 ~90 ~17 ~70 minecraft:redstone_wire replace
setblock ~92 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~70 ~107 ~17 ~70 minecraft:redstone_wire replace
setblock ~109 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~70 ~124 ~17 ~70 minecraft:redstone_wire replace
setblock ~126 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~70 ~141 ~17 ~70 minecraft:redstone_wire replace
setblock ~143 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~70 ~158 ~17 ~70 minecraft:redstone_wire replace
setblock ~160 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~70 ~175 ~17 ~70 minecraft:redstone_wire replace
setblock ~177 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~70 ~192 ~17 ~70 minecraft:redstone_wire replace
setblock ~194 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~70 ~209 ~17 ~70 minecraft:redstone_wire replace
setblock ~211 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~70 ~226 ~17 ~70 minecraft:redstone_wire replace
setblock ~228 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~70 ~243 ~17 ~70 minecraft:redstone_wire replace
setblock ~245 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~70 ~260 ~17 ~70 minecraft:redstone_wire replace
setblock ~262 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~70 ~277 ~17 ~70 minecraft:redstone_wire replace
setblock ~278 ~17 ~70 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~279 ~17 ~70 ~284 ~17 ~70 minecraft:redstone_wire replace
setblock ~256 ~17 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~268 ~17 ~71 minecraft:redstone_wire replace
setblock ~277 ~17 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~280 ~17 ~71 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~283 ~17 ~71 minecraft:redstone_wire replace
fill ~77 ~17 ~74 ~89 ~17 ~74 minecraft:redstone_wire replace
setblock ~91 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~74 ~105 ~17 ~74 minecraft:redstone_wire replace
setblock ~107 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~74 ~121 ~17 ~74 minecraft:redstone_wire replace
setblock ~123 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~74 ~137 ~17 ~74 minecraft:redstone_wire replace
setblock ~139 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~74 ~153 ~17 ~74 minecraft:redstone_wire replace
setblock ~155 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~74 ~169 ~17 ~74 minecraft:redstone_wire replace
setblock ~171 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~74 ~185 ~17 ~74 minecraft:redstone_wire replace
setblock ~187 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~74 ~201 ~17 ~74 minecraft:redstone_wire replace
setblock ~203 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~74 ~217 ~17 ~74 minecraft:redstone_wire replace
setblock ~219 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~74 ~233 ~17 ~74 minecraft:redstone_wire replace
setblock ~234 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~17 ~74 ~247 ~17 ~74 minecraft:redstone_wire replace
setblock ~248 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~17 ~74 ~262 ~17 ~74 minecraft:redstone_wire replace
setblock ~263 ~17 ~74 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~235 ~17 ~75 minecraft:redstone_wire replace
setblock ~241 ~17 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~244 ~17 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~17 ~75 minecraft:redstone_wire replace
setblock ~262 ~17 ~75 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~77 ~17 ~78 ~89 ~17 ~78 minecraft:redstone_wire replace
setblock ~91 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~93 ~17 ~78 ~105 ~17 ~78 minecraft:redstone_wire replace
setblock ~107 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~17 ~78 ~121 ~17 ~78 minecraft:redstone_wire replace
setblock ~123 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~125 ~17 ~78 ~137 ~17 ~78 minecraft:redstone_wire replace
setblock ~139 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~17 ~78 ~153 ~17 ~78 minecraft:redstone_wire replace
setblock ~155 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~17 ~78 ~169 ~17 ~78 minecraft:redstone_wire replace
setblock ~171 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~17 ~78 ~185 ~17 ~78 minecraft:redstone_wire replace
setblock ~187 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~17 ~78 ~201 ~17 ~78 minecraft:redstone_wire replace
setblock ~203 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~205 ~17 ~78 ~217 ~17 ~78 minecraft:redstone_wire replace
setblock ~219 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~17 ~78 ~233 ~17 ~78 minecraft:redstone_wire replace
setblock ~235 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~17 ~78 ~249 ~17 ~78 minecraft:redstone_wire replace
setblock ~251 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~17 ~78 ~265 ~17 ~78 minecraft:redstone_wire replace
setblock ~267 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~269 ~17 ~78 ~281 ~17 ~78 minecraft:redstone_wire replace
setblock ~283 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~285 ~17 ~78 ~298 ~17 ~78 minecraft:redstone_wire replace
setblock ~299 ~17 ~78 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~274 ~17 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~289 ~17 ~79 minecraft:redstone_wire replace
setblock ~292 ~17 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~295 ~17 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~298 ~17 ~79 minecraft:redstone_wire replace
fill ~78 ~17 ~82 ~90 ~17 ~82 minecraft:redstone_wire replace
setblock ~92 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~82 ~107 ~17 ~82 minecraft:redstone_wire replace
setblock ~109 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~82 ~124 ~17 ~82 minecraft:redstone_wire replace
setblock ~126 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~82 ~141 ~17 ~82 minecraft:redstone_wire replace
setblock ~143 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~82 ~158 ~17 ~82 minecraft:redstone_wire replace
setblock ~160 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~82 ~175 ~17 ~82 minecraft:redstone_wire replace
setblock ~177 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~82 ~192 ~17 ~82 minecraft:redstone_wire replace
setblock ~194 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~82 ~209 ~17 ~82 minecraft:redstone_wire replace
setblock ~211 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~82 ~226 ~17 ~82 minecraft:redstone_wire replace
setblock ~228 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~82 ~243 ~17 ~82 minecraft:redstone_wire replace
setblock ~245 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~82 ~260 ~17 ~82 minecraft:redstone_wire replace
setblock ~262 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~82 ~277 ~17 ~82 minecraft:redstone_wire replace
setblock ~279 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~82 ~294 ~17 ~82 minecraft:redstone_wire replace
setblock ~296 ~17 ~82 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~82 ~302 ~17 ~82 minecraft:redstone_wire replace
setblock ~301 ~17 ~83 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~17 ~86 ~90 ~17 ~86 minecraft:redstone_wire replace
setblock ~92 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~86 ~107 ~17 ~86 minecraft:redstone_wire replace
setblock ~109 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~86 ~124 ~17 ~86 minecraft:redstone_wire replace
setblock ~126 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~86 ~141 ~17 ~86 minecraft:redstone_wire replace
setblock ~143 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~86 ~158 ~17 ~86 minecraft:redstone_wire replace
setblock ~160 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~86 ~175 ~17 ~86 minecraft:redstone_wire replace
setblock ~177 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~86 ~192 ~17 ~86 minecraft:redstone_wire replace
setblock ~194 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~86 ~209 ~17 ~86 minecraft:redstone_wire replace
setblock ~211 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~86 ~226 ~17 ~86 minecraft:redstone_wire replace
setblock ~228 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~86 ~243 ~17 ~86 minecraft:redstone_wire replace
setblock ~245 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~86 ~260 ~17 ~86 minecraft:redstone_wire replace
setblock ~262 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~86 ~277 ~17 ~86 minecraft:redstone_wire replace
setblock ~279 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~86 ~294 ~17 ~86 minecraft:redstone_wire replace
setblock ~296 ~17 ~86 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~86 ~302 ~17 ~86 minecraft:redstone_wire replace
setblock ~301 ~17 ~87 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~63 ~17 ~90 ~63 ~17 ~100 minecraft:redstone_wire replace
fill ~78 ~17 ~90 ~90 ~17 ~90 minecraft:redstone_wire replace
setblock ~92 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~90 ~107 ~17 ~90 minecraft:redstone_wire replace
setblock ~109 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~90 ~124 ~17 ~90 minecraft:redstone_wire replace
setblock ~126 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~90 ~141 ~17 ~90 minecraft:redstone_wire replace
setblock ~143 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~90 ~158 ~17 ~90 minecraft:redstone_wire replace
setblock ~160 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~90 ~175 ~17 ~90 minecraft:redstone_wire replace
setblock ~177 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~90 ~192 ~17 ~90 minecraft:redstone_wire replace
setblock ~194 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~90 ~209 ~17 ~90 minecraft:redstone_wire replace
setblock ~211 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~90 ~226 ~17 ~90 minecraft:redstone_wire replace
setblock ~228 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~90 ~243 ~17 ~90 minecraft:redstone_wire replace
setblock ~245 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~90 ~260 ~17 ~90 minecraft:redstone_wire replace
setblock ~262 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~90 ~277 ~17 ~90 minecraft:redstone_wire replace
setblock ~279 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~90 ~294 ~17 ~90 minecraft:redstone_wire replace
setblock ~296 ~17 ~90 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~90 ~302 ~17 ~90 minecraft:redstone_wire replace
setblock ~301 ~17 ~91 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~94 minecraft:redstone_wire replace
setblock ~66 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~94 minecraft:redstone_wire replace
setblock ~68 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~94 minecraft:redstone_wire replace
setblock ~70 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~94 ~75 ~17 ~94 minecraft:redstone_wire replace
setblock ~76 ~17 ~94 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~94 ~90 ~17 ~94 minecraft:redstone_wire replace
setblock ~92 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~94 ~17 ~94 ~107 ~17 ~94 minecraft:redstone_wire replace
setblock ~109 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~17 ~94 ~124 ~17 ~94 minecraft:redstone_wire replace
setblock ~126 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~128 ~17 ~94 ~141 ~17 ~94 minecraft:redstone_wire replace
setblock ~143 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~17 ~94 ~158 ~17 ~94 minecraft:redstone_wire replace
setblock ~160 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~17 ~94 ~175 ~17 ~94 minecraft:redstone_wire replace
setblock ~177 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~179 ~17 ~94 ~192 ~17 ~94 minecraft:redstone_wire replace
setblock ~194 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~196 ~17 ~94 ~209 ~17 ~94 minecraft:redstone_wire replace
setblock ~211 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~213 ~17 ~94 ~226 ~17 ~94 minecraft:redstone_wire replace
setblock ~228 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~230 ~17 ~94 ~243 ~17 ~94 minecraft:redstone_wire replace
setblock ~245 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~17 ~94 ~260 ~17 ~94 minecraft:redstone_wire replace
setblock ~262 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~17 ~94 ~277 ~17 ~94 minecraft:redstone_wire replace
setblock ~279 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~281 ~17 ~94 ~294 ~17 ~94 minecraft:redstone_wire replace
setblock ~296 ~17 ~94 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~298 ~17 ~94 ~302 ~17 ~94 minecraft:redstone_wire replace
setblock ~76 ~17 ~95 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~301 ~17 ~95 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~65 ~17 ~98 minecraft:redstone_wire replace
setblock ~66 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~67 ~17 ~98 minecraft:redstone_wire replace
setblock ~68 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~69 ~17 ~98 minecraft:redstone_wire replace
setblock ~70 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~71 ~17 ~98 ~75 ~17 ~98 minecraft:redstone_wire replace
setblock ~76 ~17 ~98 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~77 ~17 ~98 ~90 ~17 ~98 minecraft:redstone_wire replace
setblock ~92 ~17 ~98 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
