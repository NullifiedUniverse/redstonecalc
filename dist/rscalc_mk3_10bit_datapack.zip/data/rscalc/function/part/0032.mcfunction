setblock ~136 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~139 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~142 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~145 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~148 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~151 ~117 ~636 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~135 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~150 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~152 ~117 ~646 minecraft:light_gray_concrete replace
setblock ~160 ~117 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~117 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~129 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~144 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~146 ~117 ~654 minecraft:light_gray_concrete replace
setblock ~154 ~117 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~132 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~147 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~149 ~117 ~662 minecraft:light_gray_concrete replace
setblock ~157 ~117 ~664 minecraft:light_gray_concrete replace
fill ~120 ~118 ~384 ~120 ~118 ~388 minecraft:light_gray_concrete replace
fill ~81 ~118 ~396 ~81 ~118 ~400 minecraft:light_gray_concrete replace
fill ~87 ~118 ~500 ~87 ~118 ~532 minecraft:light_gray_concrete replace
fill ~78 ~118 ~504 ~78 ~118 ~536 minecraft:light_gray_concrete replace
fill ~90 ~118 ~508 ~90 ~118 ~540 minecraft:light_gray_concrete replace
fill ~93 ~118 ~512 ~93 ~118 ~544 minecraft:light_gray_concrete replace
fill ~123 ~118 ~516 ~123 ~118 ~604 minecraft:light_gray_concrete replace
fill ~114 ~118 ~520 ~114 ~118 ~604 minecraft:light_gray_concrete replace
fill ~111 ~118 ~524 ~111 ~118 ~568 minecraft:light_gray_concrete replace
fill ~108 ~118 ~528 ~108 ~118 ~604 minecraft:light_gray_concrete replace
fill ~105 ~118 ~532 ~105 ~118 ~604 minecraft:light_gray_concrete replace
fill ~102 ~118 ~536 ~102 ~118 ~580 minecraft:light_gray_concrete replace
fill ~99 ~118 ~540 ~99 ~118 ~604 minecraft:light_gray_concrete replace
fill ~96 ~118 ~544 ~96 ~118 ~580 minecraft:light_gray_concrete replace
fill ~129 ~118 ~560 ~129 ~118 ~568 minecraft:light_gray_concrete replace
fill ~117 ~118 ~564 ~117 ~118 ~604 minecraft:light_gray_concrete replace
fill ~126 ~118 ~576 ~126 ~118 ~604 minecraft:light_gray_concrete replace
fill ~147 ~118 ~592 ~147 ~118 ~636 minecraft:light_gray_concrete replace
fill ~141 ~118 ~596 ~141 ~118 ~636 minecraft:light_gray_concrete replace
fill ~138 ~118 ~600 ~138 ~118 ~636 minecraft:light_gray_concrete replace
fill ~135 ~118 ~604 ~135 ~118 ~636 minecraft:light_gray_concrete replace
fill ~132 ~118 ~608 ~132 ~118 ~636 minecraft:light_gray_concrete replace
fill ~150 ~118 ~620 ~150 ~118 ~636 minecraft:light_gray_concrete replace
fill ~144 ~118 ~624 ~144 ~118 ~636 minecraft:light_gray_concrete replace
fill ~159 ~118 ~644 ~159 ~118 ~648 minecraft:light_gray_concrete replace
fill ~84 ~118 ~648 ~84 ~118 ~652 minecraft:light_gray_concrete replace
fill ~153 ~118 ~652 ~153 ~118 ~656 minecraft:light_gray_concrete replace
fill ~156 ~118 ~660 ~156 ~118 ~664 minecraft:light_gray_concrete replace
setblock ~120 ~119 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~119 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~499 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~501 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~503 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~503 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~505 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~507 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~507 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~509 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~511 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~511 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~513 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~515 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~515 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~517 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~517 minecraft:light_gray_concrete replace
setblock ~87 ~119 ~519 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~519 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~521 minecraft:light_gray_concrete replace
setblock ~78 ~119 ~523 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~523 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~525 minecraft:light_gray_concrete replace
setblock ~90 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~527 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~529 minecraft:light_gray_concrete replace
setblock ~93 ~119 ~531 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~531 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~533 minecraft:light_gray_concrete replace
setblock ~102 ~119 ~535 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~537 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~539 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~539 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~541 minecraft:light_gray_concrete replace
setblock ~96 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~543 minecraft:light_gray_concrete replace
setblock ~97 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~119 ~548 minecraft:light_gray_concrete replace
setblock ~96 ~119 ~551 minecraft:light_gray_concrete replace
setblock ~102 ~119 ~551 minecraft:light_gray_concrete replace
setblock ~96 ~119 ~553 minecraft:light_gray_concrete replace
setblock ~102 ~119 ~553 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~553 minecraft:light_gray_concrete replace
setblock ~111 ~119 ~555 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~557 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~129 ~119 ~559 minecraft:light_gray_concrete replace
setblock ~129 ~119 ~561 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~563 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~565 minecraft:light_gray_concrete replace
setblock ~97 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~103 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~119 ~568 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~573 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~575 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~577 minecraft:light_gray_concrete replace
setblock ~106 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~115 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~119 ~580 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~589 minecraft:light_gray_concrete replace
setblock ~99 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~105 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~108 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~114 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~117 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~123 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~126 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~591 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~593 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~595 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~597 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~599 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~603 minecraft:light_gray_concrete replace
setblock ~100 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~106 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~124 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~127 ~119 ~604 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~605 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~607 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~609 minecraft:light_gray_concrete replace
setblock ~136 ~119 ~612 minecraft:light_gray_concrete replace
setblock ~142 ~119 ~612 minecraft:light_gray_concrete replace
setblock ~148 ~119 ~612 minecraft:light_gray_concrete replace
setblock ~150 ~119 ~619 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~150 ~119 ~621 minecraft:light_gray_concrete replace
setblock ~132 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~135 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~138 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~141 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~144 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~147 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~150 ~119 ~623 minecraft:light_gray_concrete replace
setblock ~144 ~119 ~625 minecraft:light_gray_concrete replace
setblock ~139 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~145 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~151 ~119 ~628 minecraft:light_gray_concrete replace
setblock ~133 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~139 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~142 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~148 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~151 ~119 ~636 minecraft:light_gray_concrete replace
setblock ~159 ~119 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~119 ~647 minecraft:light_gray_concrete replace
setblock ~153 ~119 ~651 minecraft:light_gray_concrete replace
setblock ~156 ~119 ~659 minecraft:light_gray_concrete replace
fill ~106 ~120 ~380 ~106 ~120 ~381 minecraft:light_gray_concrete replace
fill ~105 ~120 ~382 ~120 ~120 ~382 minecraft:light_gray_concrete replace
fill ~82 ~120 ~392 ~82 ~120 ~393 minecraft:light_gray_concrete replace
fill ~81 ~120 ~394 ~83 ~120 ~394 minecraft:light_gray_concrete replace
fill ~88 ~120 ~496 ~88 ~120 ~497 minecraft:light_gray_concrete replace
fill ~87 ~120 ~498 ~89 ~120 ~498 minecraft:light_gray_concrete replace
fill ~79 ~120 ~500 ~79 ~120 ~501 minecraft:light_gray_concrete replace
fill ~78 ~120 ~502 ~80 ~120 ~502 minecraft:light_gray_concrete replace
fill ~91 ~120 ~504 ~91 ~120 ~505 minecraft:light_gray_concrete replace
fill ~90 ~120 ~506 ~92 ~120 ~506 minecraft:light_gray_concrete replace
fill ~94 ~120 ~508 ~94 ~120 ~509 minecraft:light_gray_concrete replace
fill ~93 ~120 ~510 ~95 ~120 ~510 minecraft:light_gray_concrete replace
fill ~109 ~120 ~512 ~109 ~120 ~513 minecraft:light_gray_concrete replace
fill ~108 ~120 ~514 ~123 ~120 ~514 minecraft:light_gray_concrete replace
fill ~103 ~120 ~516 ~103 ~120 ~517 minecraft:light_gray_concrete replace
fill ~102 ~120 ~518 ~114 ~120 ~518 minecraft:light_gray_concrete replace
fill ~103 ~120 ~520 ~103 ~120 ~521 minecraft:light_gray_concrete replace
fill ~102 ~120 ~522 ~111 ~120 ~522 minecraft:light_gray_concrete replace
fill ~100 ~120 ~524 ~100 ~120 ~525 minecraft:light_gray_concrete replace
fill ~99 ~120 ~526 ~108 ~120 ~526 minecraft:light_gray_concrete replace
fill ~100 ~120 ~528 ~100 ~120 ~529 minecraft:light_gray_concrete replace
fill ~99 ~120 ~530 ~105 ~120 ~530 minecraft:light_gray_concrete replace
fill ~100 ~120 ~532 ~100 ~120 ~533 minecraft:light_gray_concrete replace
fill ~99 ~120 ~534 ~102 ~120 ~534 minecraft:light_gray_concrete replace
fill ~97 ~120 ~536 ~97 ~120 ~537 minecraft:light_gray_concrete replace
fill ~96 ~120 ~538 ~99 ~120 ~538 minecraft:light_gray_concrete replace
fill ~97 ~120 ~540 ~97 ~120 ~541 minecraft:light_gray_concrete replace
fill ~96 ~120 ~542 ~98 ~120 ~542 minecraft:light_gray_concrete replace
fill ~109 ~120 ~556 ~109 ~120 ~557 minecraft:light_gray_concrete replace
fill ~108 ~120 ~558 ~129 ~120 ~558 minecraft:light_gray_concrete replace
fill ~103 ~120 ~560 ~103 ~120 ~561 minecraft:light_gray_concrete replace
fill ~102 ~120 ~562 ~117 ~120 ~562 minecraft:light_gray_concrete replace
fill ~109 ~120 ~572 ~109 ~120 ~573 minecraft:light_gray_concrete replace
fill ~108 ~120 ~574 ~126 ~120 ~574 minecraft:light_gray_concrete replace
fill ~121 ~120 ~588 ~121 ~120 ~589 minecraft:light_gray_concrete replace
fill ~120 ~120 ~590 ~147 ~120 ~590 minecraft:light_gray_concrete replace
fill ~118 ~120 ~592 ~118 ~120 ~593 minecraft:light_gray_concrete replace
fill ~117 ~120 ~594 ~141 ~120 ~594 minecraft:light_gray_concrete replace
fill ~115 ~120 ~596 ~115 ~120 ~597 minecraft:light_gray_concrete replace
fill ~114 ~120 ~598 ~138 ~120 ~598 minecraft:light_gray_concrete replace
fill ~115 ~120 ~600 ~115 ~120 ~601 minecraft:light_gray_concrete replace
fill ~114 ~120 ~602 ~135 ~120 ~602 minecraft:light_gray_concrete replace
fill ~112 ~120 ~604 ~112 ~120 ~605 minecraft:light_gray_concrete replace
fill ~111 ~120 ~606 ~132 ~120 ~606 minecraft:light_gray_concrete replace
fill ~121 ~120 ~616 ~121 ~120 ~617 minecraft:light_gray_concrete replace
fill ~120 ~120 ~618 ~150 ~120 ~618 minecraft:light_gray_concrete replace
fill ~118 ~120 ~620 ~118 ~120 ~621 minecraft:light_gray_concrete replace
fill ~117 ~120 ~622 ~144 ~120 ~622 minecraft:light_gray_concrete replace
fill ~130 ~120 ~640 ~130 ~120 ~641 minecraft:light_gray_concrete replace
fill ~129 ~120 ~642 ~159 ~120 ~642 minecraft:light_gray_concrete replace
fill ~85 ~120 ~644 ~85 ~120 ~645 minecraft:light_gray_concrete replace
fill ~84 ~120 ~646 ~86 ~120 ~646 minecraft:light_gray_concrete replace
fill ~124 ~120 ~648 ~124 ~120 ~649 minecraft:light_gray_concrete replace
fill ~123 ~120 ~650 ~153 ~120 ~650 minecraft:light_gray_concrete replace
fill ~127 ~120 ~656 ~127 ~120 ~657 minecraft:light_gray_concrete replace
fill ~126 ~120 ~658 ~156 ~120 ~658 minecraft:light_gray_concrete replace
setblock ~106 ~121 ~380 minecraft:light_gray_concrete replace
setblock ~111 ~121 ~382 minecraft:light_gray_concrete replace
setblock ~113 ~121 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~121 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~121 ~496 minecraft:light_gray_concrete replace
setblock ~79 ~121 ~500 minecraft:light_gray_concrete replace
setblock ~91 ~121 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~121 ~508 minecraft:light_gray_concrete replace
setblock ~109 ~121 ~512 minecraft:light_gray_concrete replace
setblock ~103 ~121 ~516 minecraft:light_gray_concrete replace
setblock ~104 ~121 ~518 minecraft:light_gray_concrete replace
setblock ~106 ~121 ~518 minecraft:light_gray_concrete replace
setblock ~103 ~121 ~520 minecraft:light_gray_concrete replace
setblock ~100 ~121 ~524 minecraft:light_gray_concrete replace
setblock ~100 ~121 ~528 minecraft:light_gray_concrete replace
setblock ~100 ~121 ~532 minecraft:light_gray_concrete replace
setblock ~97 ~121 ~536 minecraft:light_gray_concrete replace
setblock ~97 ~121 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~121 ~556 minecraft:light_gray_concrete replace
setblock ~114 ~121 ~558 minecraft:light_gray_concrete replace
setblock ~116 ~121 ~558 minecraft:light_gray_concrete replace
setblock ~103 ~121 ~560 minecraft:light_gray_concrete replace
setblock ~109 ~121 ~572 minecraft:light_gray_concrete replace
setblock ~111 ~121 ~574 minecraft:light_gray_concrete replace
setblock ~113 ~121 ~574 minecraft:light_gray_concrete replace
setblock ~121 ~121 ~588 minecraft:light_gray_concrete replace
setblock ~132 ~121 ~590 minecraft:light_gray_concrete replace
setblock ~134 ~121 ~590 minecraft:light_gray_concrete replace
setblock ~118 ~121 ~592 minecraft:light_gray_concrete replace
setblock ~126 ~121 ~594 minecraft:light_gray_concrete replace
setblock ~128 ~121 ~594 minecraft:light_gray_concrete replace
setblock ~115 ~121 ~596 minecraft:light_gray_concrete replace
setblock ~128 ~121 ~598 minecraft:light_gray_concrete replace
setblock ~130 ~121 ~598 minecraft:light_gray_concrete replace
setblock ~115 ~121 ~600 minecraft:light_gray_concrete replace
setblock ~121 ~121 ~602 minecraft:light_gray_concrete replace
setblock ~123 ~121 ~602 minecraft:light_gray_concrete replace
setblock ~112 ~121 ~604 minecraft:light_gray_concrete replace
setblock ~117 ~121 ~606 minecraft:light_gray_concrete replace
setblock ~119 ~121 ~606 minecraft:light_gray_concrete replace
setblock ~121 ~121 ~616 minecraft:light_gray_concrete replace
setblock ~137 ~121 ~618 minecraft:light_gray_concrete replace
setblock ~139 ~121 ~618 minecraft:light_gray_concrete replace
setblock ~118 ~121 ~620 minecraft:light_gray_concrete replace
setblock ~129 ~121 ~622 minecraft:light_gray_concrete replace
setblock ~131 ~121 ~622 minecraft:light_gray_concrete replace
setblock ~130 ~121 ~640 minecraft:light_gray_concrete replace
setblock ~133 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~135 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~150 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~152 ~121 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~121 ~644 minecraft:light_gray_concrete replace
setblock ~124 ~121 ~648 minecraft:light_gray_concrete replace
setblock ~127 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~129 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~144 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~146 ~121 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~121 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~121 ~658 minecraft:light_gray_concrete replace
setblock ~132 ~121 ~658 minecraft:light_gray_concrete replace
setblock ~147 ~121 ~658 minecraft:light_gray_concrete replace
setblock ~149 ~121 ~658 minecraft:light_gray_concrete replace
fill ~105 ~122 ~380 ~105 ~122 ~384 minecraft:light_gray_concrete replace
fill ~81 ~122 ~392 ~81 ~122 ~396 minecraft:light_gray_concrete replace
fill ~87 ~122 ~496 ~87 ~122 ~500 minecraft:light_gray_concrete replace
fill ~78 ~122 ~500 ~78 ~122 ~504 minecraft:light_gray_concrete replace
fill ~90 ~122 ~504 ~90 ~122 ~508 minecraft:light_gray_concrete replace
fill ~93 ~122 ~508 ~93 ~122 ~512 minecraft:light_gray_concrete replace
fill ~108 ~122 ~512 ~108 ~122 ~576 minecraft:light_gray_concrete replace
fill ~102 ~122 ~516 ~102 ~122 ~564 minecraft:light_gray_concrete replace
fill ~99 ~122 ~524 ~99 ~122 ~536 minecraft:light_gray_concrete replace
fill ~96 ~122 ~536 ~96 ~122 ~544 minecraft:light_gray_concrete replace
fill ~120 ~122 ~588 ~120 ~122 ~620 minecraft:light_gray_concrete replace
fill ~117 ~122 ~592 ~117 ~122 ~624 minecraft:light_gray_concrete replace
fill ~114 ~122 ~596 ~114 ~122 ~604 minecraft:light_gray_concrete replace
fill ~111 ~122 ~604 ~111 ~122 ~608 minecraft:light_gray_concrete replace
fill ~129 ~122 ~640 ~129 ~122 ~644 minecraft:light_gray_concrete replace
fill ~84 ~122 ~644 ~84 ~122 ~648 minecraft:light_gray_concrete replace
fill ~123 ~122 ~648 ~123 ~122 ~652 minecraft:light_gray_concrete replace
fill ~126 ~122 ~656 ~126 ~122 ~660 minecraft:light_gray_concrete replace
setblock ~105 ~123 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~123 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~123 ~501 minecraft:light_gray_concrete replace
setblock ~78 ~123 ~505 minecraft:light_gray_concrete replace
setblock ~90 ~123 ~509 minecraft:light_gray_concrete replace
setblock ~109 ~123 ~512 minecraft:light_gray_concrete replace
setblock ~93 ~123 ~513 minecraft:light_gray_concrete replace
setblock ~103 ~123 ~516 minecraft:light_gray_concrete replace
setblock ~103 ~123 ~520 minecraft:light_gray_concrete replace
setblock ~100 ~123 ~524 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~525 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~527 minecraft:light_gray_concrete replace
setblock ~100 ~123 ~528 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~529 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~531 minecraft:light_gray_concrete replace
setblock ~100 ~123 ~532 minecraft:light_gray_concrete replace
setblock ~99 ~123 ~535 minecraft:light_gray_concrete replace
setblock ~97 ~123 ~536 minecraft:light_gray_concrete replace
setblock ~99 ~123 ~537 minecraft:light_gray_concrete replace
setblock ~97 ~123 ~540 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~541 minecraft:light_gray_concrete replace
setblock ~96 ~123 ~543 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~543 minecraft:light_gray_concrete replace
setblock ~96 ~123 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~545 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~547 minecraft:light_gray_concrete replace
setblock ~109 ~123 ~556 minecraft:light_gray_concrete replace
setblock ~103 ~123 ~560 minecraft:light_gray_concrete replace
setblock ~102 ~123 ~565 minecraft:light_gray_concrete replace
setblock ~109 ~123 ~572 minecraft:light_gray_concrete replace
setblock ~108 ~123 ~577 minecraft:light_gray_concrete replace
setblock ~121 ~123 ~588 minecraft:light_gray_concrete replace
setblock ~118 ~123 ~592 minecraft:light_gray_concrete replace
setblock ~115 ~123 ~596 minecraft:light_gray_concrete replace
setblock ~115 ~123 ~600 minecraft:light_gray_concrete replace
setblock ~120 ~123 ~601 minecraft:light_gray_concrete replace
setblock ~114 ~123 ~603 minecraft:light_gray_concrete replace
setblock ~120 ~123 ~603 minecraft:light_gray_concrete replace
setblock ~112 ~123 ~604 minecraft:light_gray_concrete replace
setblock ~114 ~123 ~605 minecraft:light_gray_concrete replace
setblock ~117 ~123 ~605 minecraft:light_gray_concrete replace
setblock ~117 ~123 ~607 minecraft:light_gray_concrete replace
setblock ~111 ~123 ~609 minecraft:light_gray_concrete replace
setblock ~121 ~123 ~616 minecraft:light_gray_concrete replace
setblock ~118 ~123 ~620 minecraft:light_gray_concrete replace
setblock ~120 ~123 ~621 minecraft:light_gray_concrete replace
setblock ~117 ~123 ~625 minecraft:light_gray_concrete replace
setblock ~129 ~123 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~123 ~649 minecraft:light_gray_concrete replace
setblock ~123 ~123 ~653 minecraft:light_gray_concrete replace
setblock ~126 ~123 ~661 minecraft:light_gray_concrete replace
fill ~105 ~124 ~386 ~119 ~124 ~386 minecraft:light_gray_concrete replace
fill ~118 ~124 ~387 ~118 ~124 ~388 minecraft:light_gray_concrete replace
fill ~81 ~124 ~398 ~83 ~124 ~398 minecraft:light_gray_concrete replace
fill ~82 ~124 ~399 ~82 ~124 ~400 minecraft:light_gray_concrete replace
fill ~87 ~124 ~502 ~89 ~124 ~502 minecraft:light_gray_concrete replace
fill ~88 ~124 ~503 ~88 ~124 ~504 minecraft:light_gray_concrete replace
fill ~78 ~124 ~506 ~80 ~124 ~506 minecraft:light_gray_concrete replace
fill ~79 ~124 ~507 ~79 ~124 ~508 minecraft:light_gray_concrete replace
fill ~90 ~124 ~510 ~92 ~124 ~510 minecraft:light_gray_concrete replace
fill ~91 ~124 ~511 ~91 ~124 ~512 minecraft:light_gray_concrete replace
fill ~93 ~124 ~514 ~122 ~124 ~514 minecraft:light_gray_concrete replace
fill ~94 ~124 ~515 ~94 ~124 ~516 minecraft:light_gray_concrete replace
fill ~97 ~124 ~515 ~97 ~124 ~516 minecraft:light_gray_concrete replace
fill ~100 ~124 ~515 ~100 ~124 ~516 minecraft:light_gray_concrete replace
fill ~103 ~124 ~515 ~103 ~124 ~516 minecraft:light_gray_concrete replace
fill ~106 ~124 ~515 ~106 ~124 ~516 minecraft:light_gray_concrete replace
fill ~109 ~124 ~515 ~109 ~124 ~516 minecraft:light_gray_concrete replace
fill ~112 ~124 ~515 ~112 ~124 ~516 minecraft:light_gray_concrete replace
fill ~121 ~124 ~515 ~121 ~124 ~516 minecraft:light_gray_concrete replace
fill ~93 ~124 ~538 ~128 ~124 ~538 minecraft:light_gray_concrete replace
fill ~94 ~124 ~539 ~94 ~124 ~540 minecraft:light_gray_concrete replace
fill ~100 ~124 ~539 ~100 ~124 ~540 minecraft:light_gray_concrete replace
fill ~103 ~124 ~539 ~103 ~124 ~540 minecraft:light_gray_concrete replace
fill ~106 ~124 ~539 ~106 ~124 ~540 minecraft:light_gray_concrete replace
fill ~112 ~124 ~539 ~112 ~124 ~540 minecraft:light_gray_concrete replace
fill ~115 ~124 ~539 ~115 ~124 ~540 minecraft:light_gray_concrete replace
fill ~127 ~124 ~539 ~127 ~124 ~540 minecraft:light_gray_concrete replace
fill ~93 ~124 ~546 ~125 ~124 ~546 minecraft:light_gray_concrete replace
fill ~94 ~124 ~547 ~94 ~124 ~548 minecraft:light_gray_concrete replace
fill ~97 ~124 ~547 ~97 ~124 ~548 minecraft:light_gray_concrete replace
fill ~103 ~124 ~547 ~103 ~124 ~548 minecraft:light_gray_concrete replace
fill ~109 ~124 ~547 ~109 ~124 ~548 minecraft:light_gray_concrete replace
fill ~115 ~124 ~547 ~115 ~124 ~548 minecraft:light_gray_concrete replace
fill ~124 ~124 ~547 ~124 ~124 ~548 minecraft:light_gray_concrete replace
fill ~96 ~124 ~566 ~128 ~124 ~566 minecraft:light_gray_concrete replace
fill ~97 ~124 ~567 ~97 ~124 ~568 minecraft:light_gray_concrete replace
fill ~100 ~124 ~567 ~100 ~124 ~568 minecraft:light_gray_concrete replace
fill ~106 ~124 ~567 ~106 ~124 ~568 minecraft:light_gray_concrete replace
fill ~112 ~124 ~567 ~112 ~124 ~568 minecraft:light_gray_concrete replace
fill ~115 ~124 ~567 ~115 ~124 ~568 minecraft:light_gray_concrete replace
fill ~121 ~124 ~567 ~121 ~124 ~568 minecraft:light_gray_concrete replace
fill ~127 ~124 ~567 ~127 ~124 ~568 minecraft:light_gray_concrete replace
fill ~108 ~124 ~578 ~161 ~124 ~578 minecraft:light_gray_concrete replace
fill ~130 ~124 ~579 ~130 ~124 ~580 minecraft:light_gray_concrete replace
fill ~133 ~124 ~579 ~133 ~124 ~580 minecraft:light_gray_concrete replace
fill ~136 ~124 ~579 ~136 ~124 ~580 minecraft:light_gray_concrete replace
fill ~139 ~124 ~579 ~139 ~124 ~580 minecraft:light_gray_concrete replace
fill ~142 ~124 ~579 ~142 ~124 ~580 minecraft:light_gray_concrete replace
fill ~145 ~124 ~579 ~145 ~124 ~580 minecraft:light_gray_concrete replace
fill ~148 ~124 ~579 ~148 ~124 ~580 minecraft:light_gray_concrete replace
fill ~160 ~124 ~579 ~160 ~124 ~580 minecraft:light_gray_concrete replace
fill ~114 ~124 ~606 ~164 ~124 ~606 minecraft:light_gray_concrete replace
fill ~130 ~124 ~607 ~130 ~124 ~608 minecraft:light_gray_concrete replace
fill ~136 ~124 ~607 ~136 ~124 ~608 minecraft:light_gray_concrete replace
fill ~139 ~124 ~607 ~139 ~124 ~608 minecraft:light_gray_concrete replace
fill ~142 ~124 ~607 ~142 ~124 ~608 minecraft:light_gray_concrete replace
fill ~148 ~124 ~607 ~148 ~124 ~608 minecraft:light_gray_concrete replace
fill ~151 ~124 ~607 ~151 ~124 ~608 minecraft:light_gray_concrete replace
fill ~163 ~124 ~607 ~163 ~124 ~608 minecraft:light_gray_concrete replace
fill ~111 ~124 ~610 ~158 ~124 ~610 minecraft:light_gray_concrete replace
fill ~130 ~124 ~611 ~130 ~124 ~612 minecraft:light_gray_concrete replace
fill ~133 ~124 ~611 ~133 ~124 ~612 minecraft:light_gray_concrete replace
fill ~139 ~124 ~611 ~139 ~124 ~612 minecraft:light_gray_concrete replace
fill ~145 ~124 ~611 ~145 ~124 ~612 minecraft:light_gray_concrete replace
fill ~151 ~124 ~611 ~151 ~124 ~612 minecraft:light_gray_concrete replace
fill ~157 ~124 ~611 ~157 ~124 ~612 minecraft:light_gray_concrete replace
fill ~120 ~124 ~622 ~155 ~124 ~622 minecraft:light_gray_concrete replace
fill ~154 ~124 ~623 ~154 ~124 ~624 minecraft:light_gray_concrete replace
fill ~117 ~124 ~626 ~164 ~124 ~626 minecraft:light_gray_concrete replace
fill ~133 ~124 ~627 ~133 ~124 ~628 minecraft:light_gray_concrete replace
fill ~136 ~124 ~627 ~136 ~124 ~628 minecraft:light_gray_concrete replace
fill ~142 ~124 ~627 ~142 ~124 ~628 minecraft:light_gray_concrete replace
fill ~148 ~124 ~627 ~148 ~124 ~628 minecraft:light_gray_concrete replace
fill ~151 ~124 ~627 ~151 ~124 ~628 minecraft:light_gray_concrete replace
fill ~160 ~124 ~627 ~160 ~124 ~628 minecraft:light_gray_concrete replace
fill ~163 ~124 ~627 ~163 ~124 ~628 minecraft:light_gray_concrete replace
fill ~129 ~124 ~646 ~173 ~124 ~646 minecraft:light_gray_concrete replace
fill ~172 ~124 ~647 ~172 ~124 ~648 minecraft:light_gray_concrete replace
fill ~84 ~124 ~650 ~86 ~124 ~650 minecraft:light_gray_concrete replace
fill ~85 ~124 ~651 ~85 ~124 ~652 minecraft:light_gray_concrete replace
fill ~123 ~124 ~654 ~167 ~124 ~654 minecraft:light_gray_concrete replace
fill ~166 ~124 ~655 ~166 ~124 ~656 minecraft:light_gray_concrete replace
fill ~126 ~124 ~662 ~170 ~124 ~662 minecraft:light_gray_concrete replace
fill ~169 ~124 ~663 ~169 ~124 ~664 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~386 minecraft:light_gray_concrete replace
setblock ~114 ~125 ~386 minecraft:light_gray_concrete replace
setblock ~118 ~125 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~125 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~125 ~504 minecraft:light_gray_concrete replace
setblock ~79 ~125 ~508 minecraft:light_gray_concrete replace
setblock ~91 ~125 ~512 minecraft:light_gray_concrete replace
setblock ~94 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~97 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~100 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~103 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~106 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~109 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~125 ~516 minecraft:light_gray_concrete replace
setblock ~94 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~100 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~103 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~106 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~540 minecraft:light_gray_concrete replace
setblock ~94 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~97 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~125 ~548 minecraft:light_gray_concrete replace
setblock ~97 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~106 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~568 minecraft:light_gray_concrete replace
setblock ~115 ~125 ~578 minecraft:light_gray_concrete replace
setblock ~117 ~125 ~578 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~139 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~142 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~160 ~125 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~129 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~144 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~146 ~125 ~606 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~139 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~142 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~148 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~163 ~125 ~608 minecraft:light_gray_concrete replace
setblock ~118 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~120 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~135 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~137 ~125 ~610 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~145 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~151 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~157 ~125 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~132 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~147 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~149 ~125 ~622 minecraft:light_gray_concrete replace
setblock ~154 ~125 ~624 minecraft:light_gray_concrete replace
setblock ~127 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~129 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~144 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~146 ~125 ~626 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~148 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~151 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~160 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~163 ~125 ~628 minecraft:light_gray_concrete replace
setblock ~136 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~138 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~153 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~155 ~125 ~646 minecraft:light_gray_concrete replace
setblock ~172 ~125 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~125 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~132 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~147 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~149 ~125 ~654 minecraft:light_gray_concrete replace
setblock ~166 ~125 ~656 minecraft:light_gray_concrete replace
setblock ~133 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~135 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~150 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~152 ~125 ~662 minecraft:light_gray_concrete replace
setblock ~169 ~125 ~664 minecraft:light_gray_concrete replace
fill ~117 ~126 ~384 ~117 ~126 ~388 minecraft:light_gray_concrete replace
fill ~81 ~126 ~396 ~81 ~126 ~400 minecraft:light_gray_concrete replace
fill ~87 ~126 ~472 ~87 ~126 ~504 minecraft:light_gray_concrete replace
fill ~78 ~126 ~476 ~78 ~126 ~508 minecraft:light_gray_concrete replace
fill ~90 ~126 ~480 ~90 ~126 ~512 minecraft:light_gray_concrete replace
fill ~120 ~126 ~484 ~120 ~126 ~568 minecraft:light_gray_concrete replace
fill ~111 ~126 ~488 ~111 ~126 ~568 minecraft:light_gray_concrete replace
fill ~108 ~126 ~492 ~108 ~126 ~548 minecraft:light_gray_concrete replace
fill ~105 ~126 ~496 ~105 ~126 ~568 minecraft:light_gray_concrete replace
fill ~102 ~126 ~500 ~102 ~126 ~548 minecraft:light_gray_concrete replace
fill ~99 ~126 ~504 ~99 ~126 ~568 minecraft:light_gray_concrete replace
fill ~96 ~126 ~508 ~96 ~126 ~568 minecraft:light_gray_concrete replace
fill ~93 ~126 ~512 ~93 ~126 ~548 minecraft:light_gray_concrete replace
fill ~126 ~126 ~532 ~126 ~126 ~568 minecraft:light_gray_concrete replace
fill ~114 ~126 ~536 ~114 ~126 ~568 minecraft:light_gray_concrete replace
fill ~123 ~126 ~544 ~123 ~126 ~548 minecraft:light_gray_concrete replace
fill ~159 ~126 ~548 ~159 ~126 ~628 minecraft:light_gray_concrete replace
fill ~147 ~126 ~552 ~147 ~126 ~628 minecraft:light_gray_concrete replace
fill ~144 ~126 ~556 ~144 ~126 ~612 minecraft:light_gray_concrete replace
