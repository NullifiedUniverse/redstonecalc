fill ~215 ~157 ~750 ~228 ~157 ~750 minecraft:redstone_wire replace
setblock ~230 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~750 ~245 ~157 ~750 minecraft:redstone_wire replace
setblock ~247 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~750 ~262 ~157 ~750 minecraft:redstone_wire replace
setblock ~264 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~750 ~279 ~157 ~750 minecraft:redstone_wire replace
setblock ~281 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~750 ~296 ~157 ~750 minecraft:redstone_wire replace
setblock ~298 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~750 ~313 ~157 ~750 minecraft:redstone_wire replace
setblock ~315 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~750 ~330 ~157 ~750 minecraft:redstone_wire replace
setblock ~332 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~750 ~347 ~157 ~750 minecraft:redstone_wire replace
setblock ~349 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~157 ~750 ~364 ~157 ~750 minecraft:redstone_wire replace
setblock ~366 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~368 ~157 ~750 ~381 ~157 ~750 minecraft:redstone_wire replace
setblock ~383 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~385 ~157 ~750 ~398 ~157 ~750 minecraft:redstone_wire replace
setblock ~400 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~402 ~157 ~750 ~414 ~157 ~750 minecraft:redstone_wire replace
setblock ~157 ~157 ~751 minecraft:redstone_wire replace
fill ~159 ~157 ~754 ~163 ~157 ~754 minecraft:redstone_wire replace
setblock ~165 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~754 ~180 ~157 ~754 minecraft:redstone_wire replace
setblock ~182 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~754 ~197 ~157 ~754 minecraft:redstone_wire replace
setblock ~199 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~754 ~214 ~157 ~754 minecraft:redstone_wire replace
setblock ~216 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~754 ~231 ~157 ~754 minecraft:redstone_wire replace
setblock ~233 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~754 ~248 ~157 ~754 minecraft:redstone_wire replace
setblock ~250 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~754 ~265 ~157 ~754 minecraft:redstone_wire replace
setblock ~267 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~754 ~282 ~157 ~754 minecraft:redstone_wire replace
setblock ~284 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~754 ~299 ~157 ~754 minecraft:redstone_wire replace
setblock ~301 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~157 ~754 ~316 ~157 ~754 minecraft:redstone_wire replace
setblock ~318 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~320 ~157 ~754 ~333 ~157 ~754 minecraft:redstone_wire replace
setblock ~335 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~157 ~754 ~350 ~157 ~754 minecraft:redstone_wire replace
setblock ~352 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~157 ~754 ~367 ~157 ~754 minecraft:redstone_wire replace
setblock ~369 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~371 ~157 ~754 ~384 ~157 ~754 minecraft:redstone_wire replace
setblock ~386 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~388 ~157 ~754 ~401 ~157 ~754 minecraft:redstone_wire replace
setblock ~403 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~405 ~157 ~754 ~417 ~157 ~754 minecraft:redstone_wire replace
setblock ~160 ~157 ~755 minecraft:redstone_wire replace
fill ~162 ~157 ~758 ~167 ~157 ~758 minecraft:redstone_wire replace
setblock ~169 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~758 ~184 ~157 ~758 minecraft:redstone_wire replace
setblock ~186 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~758 ~201 ~157 ~758 minecraft:redstone_wire replace
setblock ~203 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~758 ~218 ~157 ~758 minecraft:redstone_wire replace
setblock ~220 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~758 ~235 ~157 ~758 minecraft:redstone_wire replace
setblock ~237 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~758 ~252 ~157 ~758 minecraft:redstone_wire replace
setblock ~254 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~758 ~269 ~157 ~758 minecraft:redstone_wire replace
setblock ~271 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~758 ~286 ~157 ~758 minecraft:redstone_wire replace
setblock ~288 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~758 ~303 ~157 ~758 minecraft:redstone_wire replace
setblock ~305 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~758 ~320 ~157 ~758 minecraft:redstone_wire replace
setblock ~322 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~758 ~337 ~157 ~758 minecraft:redstone_wire replace
setblock ~339 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~758 ~354 ~157 ~758 minecraft:redstone_wire replace
setblock ~356 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~758 ~371 ~157 ~758 minecraft:redstone_wire replace
setblock ~373 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~157 ~758 ~388 ~157 ~758 minecraft:redstone_wire replace
setblock ~390 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~392 ~157 ~758 ~405 ~157 ~758 minecraft:redstone_wire replace
setblock ~407 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~409 ~157 ~758 ~420 ~157 ~758 minecraft:redstone_wire replace
setblock ~163 ~157 ~759 minecraft:redstone_wire replace
fill ~165 ~157 ~762 ~174 ~157 ~762 minecraft:redstone_wire replace
setblock ~176 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~762 ~191 ~157 ~762 minecraft:redstone_wire replace
setblock ~193 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~762 ~208 ~157 ~762 minecraft:redstone_wire replace
setblock ~210 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~762 ~225 ~157 ~762 minecraft:redstone_wire replace
setblock ~227 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~762 ~242 ~157 ~762 minecraft:redstone_wire replace
setblock ~244 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~762 ~259 ~157 ~762 minecraft:redstone_wire replace
setblock ~261 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~762 ~276 ~157 ~762 minecraft:redstone_wire replace
setblock ~278 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~762 ~293 ~157 ~762 minecraft:redstone_wire replace
setblock ~295 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~157 ~762 ~310 ~157 ~762 minecraft:redstone_wire replace
setblock ~312 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~762 ~327 ~157 ~762 minecraft:redstone_wire replace
setblock ~329 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~157 ~762 ~344 ~157 ~762 minecraft:redstone_wire replace
setblock ~346 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~157 ~762 ~361 ~157 ~762 minecraft:redstone_wire replace
setblock ~363 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~365 ~157 ~762 ~378 ~157 ~762 minecraft:redstone_wire replace
setblock ~380 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~382 ~157 ~762 ~395 ~157 ~762 minecraft:redstone_wire replace
setblock ~397 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~399 ~157 ~762 ~412 ~157 ~762 minecraft:redstone_wire replace
setblock ~414 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~416 ~157 ~762 ~423 ~157 ~762 minecraft:redstone_wire replace
setblock ~166 ~157 ~763 minecraft:redstone_wire replace
fill ~129 ~157 ~766 ~135 ~157 ~766 minecraft:redstone_wire replace
setblock ~137 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~766 ~151 ~157 ~766 minecraft:redstone_wire replace
setblock ~153 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~766 ~167 ~157 ~766 minecraft:redstone_wire replace
setblock ~169 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~766 ~183 ~157 ~766 minecraft:redstone_wire replace
setblock ~185 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~766 ~199 ~157 ~766 minecraft:redstone_wire replace
setblock ~201 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~766 ~215 ~157 ~766 minecraft:redstone_wire replace
setblock ~217 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~157 ~766 ~231 ~157 ~766 minecraft:redstone_wire replace
setblock ~233 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~766 ~247 ~157 ~766 minecraft:redstone_wire replace
setblock ~249 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~766 ~255 ~157 ~766 minecraft:redstone_wire replace
setblock ~130 ~157 ~767 minecraft:redstone_wire replace
fill ~129 ~157 ~770 ~140 ~157 ~770 minecraft:redstone_wire replace
setblock ~142 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~770 ~157 ~157 ~770 minecraft:redstone_wire replace
setblock ~159 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~770 ~174 ~157 ~770 minecraft:redstone_wire replace
setblock ~176 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~770 ~191 ~157 ~770 minecraft:redstone_wire replace
setblock ~193 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~770 ~208 ~157 ~770 minecraft:redstone_wire replace
setblock ~210 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~770 ~225 ~157 ~770 minecraft:redstone_wire replace
setblock ~227 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~770 ~242 ~157 ~770 minecraft:redstone_wire replace
setblock ~244 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~770 ~258 ~157 ~770 minecraft:redstone_wire replace
setblock ~130 ~157 ~771 minecraft:redstone_wire replace
fill ~129 ~157 ~774 ~135 ~157 ~774 minecraft:redstone_wire replace
setblock ~137 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~774 ~151 ~157 ~774 minecraft:redstone_wire replace
setblock ~153 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~774 ~167 ~157 ~774 minecraft:redstone_wire replace
setblock ~169 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~774 ~183 ~157 ~774 minecraft:redstone_wire replace
setblock ~185 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~774 ~199 ~157 ~774 minecraft:redstone_wire replace
setblock ~201 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~774 ~215 ~157 ~774 minecraft:redstone_wire replace
setblock ~217 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~157 ~774 ~231 ~157 ~774 minecraft:redstone_wire replace
setblock ~233 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~774 ~247 ~157 ~774 minecraft:redstone_wire replace
setblock ~249 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~774 ~261 ~157 ~774 minecraft:redstone_wire replace
setblock ~130 ~157 ~775 minecraft:redstone_wire replace
fill ~129 ~157 ~778 ~132 ~157 ~778 minecraft:redstone_wire replace
setblock ~134 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~778 ~149 ~157 ~778 minecraft:redstone_wire replace
setblock ~151 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~778 ~166 ~157 ~778 minecraft:redstone_wire replace
setblock ~168 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~778 ~183 ~157 ~778 minecraft:redstone_wire replace
setblock ~185 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~778 ~200 ~157 ~778 minecraft:redstone_wire replace
setblock ~202 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~778 ~217 ~157 ~778 minecraft:redstone_wire replace
setblock ~219 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~778 ~234 ~157 ~778 minecraft:redstone_wire replace
setblock ~236 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~778 ~251 ~157 ~778 minecraft:redstone_wire replace
setblock ~253 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~157 ~778 ~264 ~157 ~778 minecraft:redstone_wire replace
setblock ~130 ~157 ~779 minecraft:redstone_wire replace
fill ~129 ~157 ~782 ~139 ~157 ~782 minecraft:redstone_wire replace
setblock ~141 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~782 ~156 ~157 ~782 minecraft:redstone_wire replace
setblock ~158 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~782 ~173 ~157 ~782 minecraft:redstone_wire replace
setblock ~175 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~782 ~190 ~157 ~782 minecraft:redstone_wire replace
setblock ~192 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~782 ~207 ~157 ~782 minecraft:redstone_wire replace
setblock ~209 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~782 ~224 ~157 ~782 minecraft:redstone_wire replace
setblock ~226 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~782 ~241 ~157 ~782 minecraft:redstone_wire replace
setblock ~243 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~782 ~258 ~157 ~782 minecraft:redstone_wire replace
setblock ~260 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~782 ~267 ~157 ~782 minecraft:redstone_wire replace
setblock ~130 ~157 ~783 minecraft:redstone_wire replace
fill ~129 ~157 ~786 ~135 ~157 ~786 minecraft:redstone_wire replace
setblock ~137 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~786 ~152 ~157 ~786 minecraft:redstone_wire replace
setblock ~154 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~786 ~169 ~157 ~786 minecraft:redstone_wire replace
setblock ~171 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~786 ~186 ~157 ~786 minecraft:redstone_wire replace
setblock ~188 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~786 ~203 ~157 ~786 minecraft:redstone_wire replace
setblock ~205 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~786 ~220 ~157 ~786 minecraft:redstone_wire replace
setblock ~222 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~157 ~786 ~237 ~157 ~786 minecraft:redstone_wire replace
setblock ~239 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~157 ~786 ~254 ~157 ~786 minecraft:redstone_wire replace
setblock ~256 ~157 ~786 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~157 ~786 ~270 ~157 ~786 minecraft:redstone_wire replace
setblock ~130 ~157 ~787 minecraft:redstone_wire replace
fill ~129 ~157 ~790 ~139 ~157 ~790 minecraft:redstone_wire replace
setblock ~141 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~790 ~156 ~157 ~790 minecraft:redstone_wire replace
setblock ~158 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~790 ~173 ~157 ~790 minecraft:redstone_wire replace
setblock ~175 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~790 ~190 ~157 ~790 minecraft:redstone_wire replace
setblock ~192 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~790 ~207 ~157 ~790 minecraft:redstone_wire replace
setblock ~209 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~790 ~224 ~157 ~790 minecraft:redstone_wire replace
setblock ~226 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~790 ~241 ~157 ~790 minecraft:redstone_wire replace
setblock ~243 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~790 ~258 ~157 ~790 minecraft:redstone_wire replace
setblock ~260 ~157 ~790 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~790 ~273 ~157 ~790 minecraft:redstone_wire replace
setblock ~130 ~157 ~791 minecraft:redstone_wire replace
fill ~129 ~157 ~794 ~136 ~157 ~794 minecraft:redstone_wire replace
setblock ~138 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~794 ~152 ~157 ~794 minecraft:redstone_wire replace
setblock ~154 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~794 ~168 ~157 ~794 minecraft:redstone_wire replace
setblock ~170 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~794 ~184 ~157 ~794 minecraft:redstone_wire replace
setblock ~186 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~794 ~200 ~157 ~794 minecraft:redstone_wire replace
setblock ~202 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~794 ~216 ~157 ~794 minecraft:redstone_wire replace
setblock ~218 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~794 ~232 ~157 ~794 minecraft:redstone_wire replace
setblock ~234 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~157 ~794 ~248 ~157 ~794 minecraft:redstone_wire replace
setblock ~250 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~794 ~264 ~157 ~794 minecraft:redstone_wire replace
setblock ~266 ~157 ~794 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~794 ~276 ~157 ~794 minecraft:redstone_wire replace
setblock ~130 ~157 ~795 minecraft:redstone_wire replace
fill ~132 ~157 ~798 ~134 ~157 ~798 minecraft:redstone_wire replace
setblock ~136 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~798 ~151 ~157 ~798 minecraft:redstone_wire replace
setblock ~153 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~798 ~168 ~157 ~798 minecraft:redstone_wire replace
setblock ~170 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~798 ~185 ~157 ~798 minecraft:redstone_wire replace
setblock ~187 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~798 ~202 ~157 ~798 minecraft:redstone_wire replace
setblock ~204 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~798 ~219 ~157 ~798 minecraft:redstone_wire replace
setblock ~221 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~798 ~236 ~157 ~798 minecraft:redstone_wire replace
setblock ~238 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~798 ~253 ~157 ~798 minecraft:redstone_wire replace
setblock ~255 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~798 ~270 ~157 ~798 minecraft:redstone_wire replace
setblock ~272 ~157 ~798 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~798 ~279 ~157 ~798 minecraft:redstone_wire replace
setblock ~133 ~157 ~799 minecraft:redstone_wire replace
fill ~132 ~157 ~802 ~139 ~157 ~802 minecraft:redstone_wire replace
setblock ~141 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~802 ~155 ~157 ~802 minecraft:redstone_wire replace
setblock ~157 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~802 ~171 ~157 ~802 minecraft:redstone_wire replace
setblock ~173 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~802 ~187 ~157 ~802 minecraft:redstone_wire replace
setblock ~189 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~802 ~203 ~157 ~802 minecraft:redstone_wire replace
setblock ~205 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~802 ~219 ~157 ~802 minecraft:redstone_wire replace
setblock ~221 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~802 ~235 ~157 ~802 minecraft:redstone_wire replace
setblock ~237 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~802 ~251 ~157 ~802 minecraft:redstone_wire replace
setblock ~253 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~157 ~802 ~267 ~157 ~802 minecraft:redstone_wire replace
setblock ~269 ~157 ~802 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~802 ~282 ~157 ~802 minecraft:redstone_wire replace
setblock ~133 ~157 ~803 minecraft:redstone_wire replace
fill ~132 ~157 ~806 ~134 ~157 ~806 minecraft:redstone_wire replace
setblock ~136 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~806 ~151 ~157 ~806 minecraft:redstone_wire replace
setblock ~153 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~806 ~168 ~157 ~806 minecraft:redstone_wire replace
setblock ~170 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~806 ~185 ~157 ~806 minecraft:redstone_wire replace
setblock ~187 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~806 ~202 ~157 ~806 minecraft:redstone_wire replace
setblock ~204 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~806 ~219 ~157 ~806 minecraft:redstone_wire replace
setblock ~221 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~806 ~236 ~157 ~806 minecraft:redstone_wire replace
setblock ~238 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~806 ~253 ~157 ~806 minecraft:redstone_wire replace
setblock ~255 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~806 ~270 ~157 ~806 minecraft:redstone_wire replace
setblock ~272 ~157 ~806 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~806 ~285 ~157 ~806 minecraft:redstone_wire replace
setblock ~133 ~157 ~807 minecraft:redstone_wire replace
fill ~132 ~157 ~810 ~139 ~157 ~810 minecraft:redstone_wire replace
setblock ~141 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~810 ~156 ~157 ~810 minecraft:redstone_wire replace
setblock ~158 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~810 ~173 ~157 ~810 minecraft:redstone_wire replace
setblock ~175 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~810 ~190 ~157 ~810 minecraft:redstone_wire replace
setblock ~192 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~810 ~207 ~157 ~810 minecraft:redstone_wire replace
setblock ~209 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~810 ~224 ~157 ~810 minecraft:redstone_wire replace
setblock ~226 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~810 ~241 ~157 ~810 minecraft:redstone_wire replace
setblock ~243 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~810 ~258 ~157 ~810 minecraft:redstone_wire replace
setblock ~260 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~810 ~275 ~157 ~810 minecraft:redstone_wire replace
setblock ~277 ~157 ~810 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~157 ~810 ~288 ~157 ~810 minecraft:redstone_wire replace
setblock ~133 ~157 ~811 minecraft:redstone_wire replace
setblock ~132 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~157 ~814 ~146 ~157 ~814 minecraft:redstone_wire replace
setblock ~148 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~814 ~163 ~157 ~814 minecraft:redstone_wire replace
setblock ~165 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~814 ~180 ~157 ~814 minecraft:redstone_wire replace
setblock ~182 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~814 ~197 ~157 ~814 minecraft:redstone_wire replace
setblock ~199 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~814 ~214 ~157 ~814 minecraft:redstone_wire replace
setblock ~216 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~814 ~231 ~157 ~814 minecraft:redstone_wire replace
setblock ~233 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~814 ~248 ~157 ~814 minecraft:redstone_wire replace
setblock ~250 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~814 ~265 ~157 ~814 minecraft:redstone_wire replace
setblock ~267 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~814 ~282 ~157 ~814 minecraft:redstone_wire replace
setblock ~284 ~157 ~814 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~814 ~291 ~157 ~814 minecraft:redstone_wire replace
setblock ~133 ~157 ~815 minecraft:redstone_wire replace
fill ~132 ~157 ~818 ~142 ~157 ~818 minecraft:redstone_wire replace
setblock ~144 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~818 ~159 ~157 ~818 minecraft:redstone_wire replace
setblock ~161 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~818 ~176 ~157 ~818 minecraft:redstone_wire replace
setblock ~178 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~818 ~193 ~157 ~818 minecraft:redstone_wire replace
setblock ~195 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~818 ~210 ~157 ~818 minecraft:redstone_wire replace
setblock ~212 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~818 ~227 ~157 ~818 minecraft:redstone_wire replace
setblock ~229 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~157 ~818 ~244 ~157 ~818 minecraft:redstone_wire replace
setblock ~246 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~248 ~157 ~818 ~261 ~157 ~818 minecraft:redstone_wire replace
setblock ~263 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~157 ~818 ~278 ~157 ~818 minecraft:redstone_wire replace
setblock ~280 ~157 ~818 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~157 ~818 ~294 ~157 ~818 minecraft:redstone_wire replace
setblock ~133 ~157 ~819 minecraft:redstone_wire replace
setblock ~132 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~157 ~822 ~146 ~157 ~822 minecraft:redstone_wire replace
setblock ~148 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~822 ~163 ~157 ~822 minecraft:redstone_wire replace
setblock ~165 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~822 ~180 ~157 ~822 minecraft:redstone_wire replace
setblock ~182 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~822 ~197 ~157 ~822 minecraft:redstone_wire replace
setblock ~199 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~822 ~214 ~157 ~822 minecraft:redstone_wire replace
setblock ~216 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~822 ~231 ~157 ~822 minecraft:redstone_wire replace
setblock ~233 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~822 ~248 ~157 ~822 minecraft:redstone_wire replace
setblock ~250 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~822 ~265 ~157 ~822 minecraft:redstone_wire replace
setblock ~267 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~822 ~282 ~157 ~822 minecraft:redstone_wire replace
setblock ~284 ~157 ~822 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~822 ~297 ~157 ~822 minecraft:redstone_wire replace
setblock ~133 ~157 ~823 minecraft:redstone_wire replace
fill ~132 ~157 ~826 ~134 ~157 ~826 minecraft:redstone_wire replace
setblock ~136 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~826 ~151 ~157 ~826 minecraft:redstone_wire replace
setblock ~153 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~826 ~168 ~157 ~826 minecraft:redstone_wire replace
setblock ~170 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~826 ~185 ~157 ~826 minecraft:redstone_wire replace
setblock ~187 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~826 ~202 ~157 ~826 minecraft:redstone_wire replace
setblock ~204 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~826 ~219 ~157 ~826 minecraft:redstone_wire replace
setblock ~221 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~826 ~236 ~157 ~826 minecraft:redstone_wire replace
setblock ~238 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~826 ~253 ~157 ~826 minecraft:redstone_wire replace
setblock ~255 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~826 ~270 ~157 ~826 minecraft:redstone_wire replace
setblock ~272 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~826 ~287 ~157 ~826 minecraft:redstone_wire replace
setblock ~289 ~157 ~826 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~157 ~826 ~300 ~157 ~826 minecraft:redstone_wire replace
setblock ~133 ~157 ~827 minecraft:redstone_wire replace
fill ~135 ~157 ~830 ~141 ~157 ~830 minecraft:redstone_wire replace
setblock ~143 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~830 ~158 ~157 ~830 minecraft:redstone_wire replace
setblock ~160 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~830 ~175 ~157 ~830 minecraft:redstone_wire replace
setblock ~177 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~830 ~192 ~157 ~830 minecraft:redstone_wire replace
setblock ~194 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~830 ~209 ~157 ~830 minecraft:redstone_wire replace
setblock ~211 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~830 ~226 ~157 ~830 minecraft:redstone_wire replace
setblock ~228 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~830 ~243 ~157 ~830 minecraft:redstone_wire replace
setblock ~245 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~830 ~260 ~157 ~830 minecraft:redstone_wire replace
setblock ~262 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~830 ~277 ~157 ~830 minecraft:redstone_wire replace
setblock ~279 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~830 ~294 ~157 ~830 minecraft:redstone_wire replace
setblock ~296 ~157 ~830 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~830 ~303 ~157 ~830 minecraft:redstone_wire replace
setblock ~136 ~157 ~831 minecraft:redstone_wire replace
fill ~135 ~157 ~834 ~137 ~157 ~834 minecraft:redstone_wire replace
setblock ~139 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~834 ~154 ~157 ~834 minecraft:redstone_wire replace
setblock ~156 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~834 ~171 ~157 ~834 minecraft:redstone_wire replace
setblock ~173 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~834 ~188 ~157 ~834 minecraft:redstone_wire replace
setblock ~190 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~834 ~205 ~157 ~834 minecraft:redstone_wire replace
setblock ~207 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~834 ~222 ~157 ~834 minecraft:redstone_wire replace
setblock ~224 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~834 ~239 ~157 ~834 minecraft:redstone_wire replace
setblock ~241 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~157 ~834 ~256 ~157 ~834 minecraft:redstone_wire replace
setblock ~258 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~260 ~157 ~834 ~273 ~157 ~834 minecraft:redstone_wire replace
setblock ~275 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~157 ~834 ~290 ~157 ~834 minecraft:redstone_wire replace
setblock ~292 ~157 ~834 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~157 ~834 ~306 ~157 ~834 minecraft:redstone_wire replace
setblock ~136 ~157 ~835 minecraft:redstone_wire replace
fill ~135 ~157 ~838 ~141 ~157 ~838 minecraft:redstone_wire replace
setblock ~143 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~838 ~158 ~157 ~838 minecraft:redstone_wire replace
setblock ~160 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~838 ~175 ~157 ~838 minecraft:redstone_wire replace
setblock ~177 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~838 ~192 ~157 ~838 minecraft:redstone_wire replace
setblock ~194 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~838 ~209 ~157 ~838 minecraft:redstone_wire replace
setblock ~211 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~838 ~226 ~157 ~838 minecraft:redstone_wire replace
setblock ~228 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~838 ~243 ~157 ~838 minecraft:redstone_wire replace
setblock ~245 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~838 ~260 ~157 ~838 minecraft:redstone_wire replace
setblock ~262 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~838 ~277 ~157 ~838 minecraft:redstone_wire replace
setblock ~279 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~838 ~294 ~157 ~838 minecraft:redstone_wire replace
setblock ~296 ~157 ~838 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~838 ~309 ~157 ~838 minecraft:redstone_wire replace
setblock ~136 ~157 ~839 minecraft:redstone_wire replace
fill ~135 ~157 ~842 ~146 ~157 ~842 minecraft:redstone_wire replace
setblock ~148 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~842 ~163 ~157 ~842 minecraft:redstone_wire replace
setblock ~165 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~842 ~180 ~157 ~842 minecraft:redstone_wire replace
setblock ~182 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~842 ~197 ~157 ~842 minecraft:redstone_wire replace
setblock ~199 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~842 ~214 ~157 ~842 minecraft:redstone_wire replace
setblock ~216 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~842 ~231 ~157 ~842 minecraft:redstone_wire replace
setblock ~233 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~842 ~248 ~157 ~842 minecraft:redstone_wire replace
setblock ~250 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~842 ~265 ~157 ~842 minecraft:redstone_wire replace
setblock ~267 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~842 ~282 ~157 ~842 minecraft:redstone_wire replace
setblock ~284 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~842 ~299 ~157 ~842 minecraft:redstone_wire replace
setblock ~301 ~157 ~842 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~157 ~842 ~312 ~157 ~842 minecraft:redstone_wire replace
setblock ~136 ~157 ~843 minecraft:redstone_wire replace
fill ~135 ~157 ~846 ~136 ~157 ~846 minecraft:redstone_wire replace
setblock ~138 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~846 ~153 ~157 ~846 minecraft:redstone_wire replace
setblock ~155 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~846 ~170 ~157 ~846 minecraft:redstone_wire replace
setblock ~172 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~846 ~187 ~157 ~846 minecraft:redstone_wire replace
setblock ~189 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~846 ~204 ~157 ~846 minecraft:redstone_wire replace
setblock ~206 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~157 ~846 ~221 ~157 ~846 minecraft:redstone_wire replace
setblock ~223 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~157 ~846 ~238 ~157 ~846 minecraft:redstone_wire replace
setblock ~240 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~157 ~846 ~255 ~157 ~846 minecraft:redstone_wire replace
setblock ~257 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~846 ~272 ~157 ~846 minecraft:redstone_wire replace
setblock ~274 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~846 ~289 ~157 ~846 minecraft:redstone_wire replace
setblock ~291 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~157 ~846 ~306 ~157 ~846 minecraft:redstone_wire replace
setblock ~308 ~157 ~846 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~157 ~846 ~315 ~157 ~846 minecraft:redstone_wire replace
setblock ~136 ~157 ~847 minecraft:redstone_wire replace
setblock ~135 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~850 ~149 ~157 ~850 minecraft:redstone_wire replace
setblock ~151 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~850 ~166 ~157 ~850 minecraft:redstone_wire replace
setblock ~168 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~850 ~183 ~157 ~850 minecraft:redstone_wire replace
setblock ~185 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~850 ~200 ~157 ~850 minecraft:redstone_wire replace
setblock ~202 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~850 ~217 ~157 ~850 minecraft:redstone_wire replace
setblock ~219 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~850 ~234 ~157 ~850 minecraft:redstone_wire replace
setblock ~236 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~850 ~251 ~157 ~850 minecraft:redstone_wire replace
setblock ~253 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~157 ~850 ~268 ~157 ~850 minecraft:redstone_wire replace
setblock ~270 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~157 ~850 ~285 ~157 ~850 minecraft:redstone_wire replace
setblock ~287 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~157 ~850 ~302 ~157 ~850 minecraft:redstone_wire replace
setblock ~304 ~157 ~850 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~157 ~850 ~318 ~157 ~850 minecraft:redstone_wire replace
setblock ~136 ~157 ~851 minecraft:redstone_wire replace
fill ~135 ~157 ~854 ~136 ~157 ~854 minecraft:redstone_wire replace
setblock ~138 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~854 ~153 ~157 ~854 minecraft:redstone_wire replace
setblock ~155 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~854 ~170 ~157 ~854 minecraft:redstone_wire replace
setblock ~172 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~854 ~187 ~157 ~854 minecraft:redstone_wire replace
setblock ~189 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~854 ~204 ~157 ~854 minecraft:redstone_wire replace
setblock ~206 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~157 ~854 ~221 ~157 ~854 minecraft:redstone_wire replace
setblock ~223 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~157 ~854 ~238 ~157 ~854 minecraft:redstone_wire replace
setblock ~240 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~157 ~854 ~255 ~157 ~854 minecraft:redstone_wire replace
setblock ~257 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~854 ~272 ~157 ~854 minecraft:redstone_wire replace
setblock ~274 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~854 ~289 ~157 ~854 minecraft:redstone_wire replace
setblock ~291 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~157 ~854 ~306 ~157 ~854 minecraft:redstone_wire replace
setblock ~308 ~157 ~854 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~157 ~854 ~321 ~157 ~854 minecraft:redstone_wire replace
setblock ~136 ~157 ~855 minecraft:redstone_wire replace
fill ~135 ~157 ~858 ~141 ~157 ~858 minecraft:redstone_wire replace
setblock ~143 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~858 ~158 ~157 ~858 minecraft:redstone_wire replace
setblock ~160 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~858 ~175 ~157 ~858 minecraft:redstone_wire replace
setblock ~177 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~858 ~192 ~157 ~858 minecraft:redstone_wire replace
setblock ~194 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~858 ~209 ~157 ~858 minecraft:redstone_wire replace
setblock ~211 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~858 ~226 ~157 ~858 minecraft:redstone_wire replace
setblock ~228 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~858 ~243 ~157 ~858 minecraft:redstone_wire replace
setblock ~245 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~858 ~260 ~157 ~858 minecraft:redstone_wire replace
setblock ~262 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~858 ~277 ~157 ~858 minecraft:redstone_wire replace
setblock ~279 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~858 ~294 ~157 ~858 minecraft:redstone_wire replace
setblock ~296 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~858 ~311 ~157 ~858 minecraft:redstone_wire replace
setblock ~313 ~157 ~858 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~157 ~858 ~324 ~157 ~858 minecraft:redstone_wire replace
setblock ~136 ~157 ~859 minecraft:redstone_wire replace
fill ~135 ~157 ~862 ~148 ~157 ~862 minecraft:redstone_wire replace
setblock ~150 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~862 ~165 ~157 ~862 minecraft:redstone_wire replace
setblock ~167 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~862 ~182 ~157 ~862 minecraft:redstone_wire replace
setblock ~184 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~862 ~199 ~157 ~862 minecraft:redstone_wire replace
setblock ~201 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~862 ~216 ~157 ~862 minecraft:redstone_wire replace
setblock ~218 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~862 ~233 ~157 ~862 minecraft:redstone_wire replace
setblock ~235 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~157 ~862 ~250 ~157 ~862 minecraft:redstone_wire replace
setblock ~252 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~157 ~862 ~267 ~157 ~862 minecraft:redstone_wire replace
setblock ~269 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~862 ~284 ~157 ~862 minecraft:redstone_wire replace
setblock ~286 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~157 ~862 ~301 ~157 ~862 minecraft:redstone_wire replace
setblock ~303 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~157 ~862 ~318 ~157 ~862 minecraft:redstone_wire replace
setblock ~320 ~157 ~862 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~157 ~862 ~327 ~157 ~862 minecraft:redstone_wire replace
setblock ~136 ~157 ~863 minecraft:redstone_wire replace
fill ~138 ~157 ~866 ~144 ~157 ~866 minecraft:redstone_wire replace
setblock ~146 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~157 ~866 ~161 ~157 ~866 minecraft:redstone_wire replace
setblock ~163 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~157 ~866 ~178 ~157 ~866 minecraft:redstone_wire replace
setblock ~180 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~157 ~866 ~195 ~157 ~866 minecraft:redstone_wire replace
setblock ~197 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~157 ~866 ~212 ~157 ~866 minecraft:redstone_wire replace
setblock ~214 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~157 ~866 ~229 ~157 ~866 minecraft:redstone_wire replace
setblock ~231 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~233 ~157 ~866 ~246 ~157 ~866 minecraft:redstone_wire replace
setblock ~248 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~157 ~866 ~263 ~157 ~866 minecraft:redstone_wire replace
setblock ~265 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~157 ~866 ~280 ~157 ~866 minecraft:redstone_wire replace
setblock ~282 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~284 ~157 ~866 ~297 ~157 ~866 minecraft:redstone_wire replace
setblock ~299 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~157 ~866 ~314 ~157 ~866 minecraft:redstone_wire replace
setblock ~316 ~157 ~866 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~157 ~866 ~330 ~157 ~866 minecraft:redstone_wire replace
setblock ~139 ~157 ~867 minecraft:redstone_wire replace
fill ~138 ~157 ~870 ~148 ~157 ~870 minecraft:redstone_wire replace
setblock ~150 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~870 ~165 ~157 ~870 minecraft:redstone_wire replace
setblock ~167 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~870 ~182 ~157 ~870 minecraft:redstone_wire replace
setblock ~184 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~870 ~199 ~157 ~870 minecraft:redstone_wire replace
setblock ~201 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~870 ~216 ~157 ~870 minecraft:redstone_wire replace
setblock ~218 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~870 ~233 ~157 ~870 minecraft:redstone_wire replace
setblock ~235 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~157 ~870 ~250 ~157 ~870 minecraft:redstone_wire replace
setblock ~252 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~157 ~870 ~267 ~157 ~870 minecraft:redstone_wire replace
setblock ~269 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~870 ~284 ~157 ~870 minecraft:redstone_wire replace
setblock ~286 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~157 ~870 ~301 ~157 ~870 minecraft:redstone_wire replace
setblock ~303 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~157 ~870 ~318 ~157 ~870 minecraft:redstone_wire replace
setblock ~320 ~157 ~870 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~157 ~870 ~333 ~157 ~870 minecraft:redstone_wire replace
setblock ~139 ~157 ~871 minecraft:redstone_wire replace
fill ~138 ~157 ~874 ~148 ~157 ~874 minecraft:redstone_wire replace
setblock ~150 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~874 ~164 ~157 ~874 minecraft:redstone_wire replace
setblock ~166 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~874 ~180 ~157 ~874 minecraft:redstone_wire replace
setblock ~182 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~874 ~196 ~157 ~874 minecraft:redstone_wire replace
setblock ~198 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~874 ~212 ~157 ~874 minecraft:redstone_wire replace
setblock ~214 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~157 ~874 ~228 ~157 ~874 minecraft:redstone_wire replace
setblock ~230 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~874 ~244 ~157 ~874 minecraft:redstone_wire replace
setblock ~246 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~248 ~157 ~874 ~260 ~157 ~874 minecraft:redstone_wire replace
setblock ~262 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~874 ~276 ~157 ~874 minecraft:redstone_wire replace
setblock ~278 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~874 ~292 ~157 ~874 minecraft:redstone_wire replace
setblock ~294 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~157 ~874 ~308 ~157 ~874 minecraft:redstone_wire replace
setblock ~310 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~874 ~324 ~157 ~874 minecraft:redstone_wire replace
setblock ~326 ~157 ~874 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~328 ~157 ~874 ~336 ~157 ~874 minecraft:redstone_wire replace
setblock ~139 ~157 ~875 minecraft:redstone_wire replace
fill ~138 ~157 ~878 ~143 ~157 ~878 minecraft:redstone_wire replace
setblock ~145 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~878 ~160 ~157 ~878 minecraft:redstone_wire replace
setblock ~162 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~878 ~177 ~157 ~878 minecraft:redstone_wire replace
setblock ~179 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~878 ~194 ~157 ~878 minecraft:redstone_wire replace
setblock ~196 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~878 ~211 ~157 ~878 minecraft:redstone_wire replace
setblock ~213 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~878 ~228 ~157 ~878 minecraft:redstone_wire replace
setblock ~230 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~878 ~245 ~157 ~878 minecraft:redstone_wire replace
setblock ~247 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~878 ~262 ~157 ~878 minecraft:redstone_wire replace
setblock ~264 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~878 ~279 ~157 ~878 minecraft:redstone_wire replace
setblock ~281 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~878 ~296 ~157 ~878 minecraft:redstone_wire replace
setblock ~298 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~878 ~313 ~157 ~878 minecraft:redstone_wire replace
setblock ~315 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~878 ~330 ~157 ~878 minecraft:redstone_wire replace
setblock ~332 ~157 ~878 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~878 ~339 ~157 ~878 minecraft:redstone_wire replace
setblock ~139 ~157 ~879 minecraft:redstone_wire replace
fill ~138 ~157 ~882 ~139 ~157 ~882 minecraft:redstone_wire replace
setblock ~141 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~882 ~156 ~157 ~882 minecraft:redstone_wire replace
setblock ~158 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~882 ~173 ~157 ~882 minecraft:redstone_wire replace
setblock ~175 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~882 ~190 ~157 ~882 minecraft:redstone_wire replace
setblock ~192 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~882 ~207 ~157 ~882 minecraft:redstone_wire replace
setblock ~209 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~882 ~224 ~157 ~882 minecraft:redstone_wire replace
setblock ~226 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~882 ~241 ~157 ~882 minecraft:redstone_wire replace
setblock ~243 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~157 ~882 ~258 ~157 ~882 minecraft:redstone_wire replace
setblock ~260 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~157 ~882 ~275 ~157 ~882 minecraft:redstone_wire replace
setblock ~277 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~157 ~882 ~292 ~157 ~882 minecraft:redstone_wire replace
setblock ~294 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~157 ~882 ~309 ~157 ~882 minecraft:redstone_wire replace
setblock ~311 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~157 ~882 ~326 ~157 ~882 minecraft:redstone_wire replace
setblock ~328 ~157 ~882 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~157 ~882 ~342 ~157 ~882 minecraft:redstone_wire replace
setblock ~139 ~157 ~883 minecraft:redstone_wire replace
fill ~138 ~157 ~886 ~143 ~157 ~886 minecraft:redstone_wire replace
setblock ~145 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~886 ~160 ~157 ~886 minecraft:redstone_wire replace
setblock ~162 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~886 ~177 ~157 ~886 minecraft:redstone_wire replace
setblock ~179 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~886 ~194 ~157 ~886 minecraft:redstone_wire replace
setblock ~196 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~886 ~211 ~157 ~886 minecraft:redstone_wire replace
setblock ~213 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~886 ~228 ~157 ~886 minecraft:redstone_wire replace
setblock ~230 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~886 ~245 ~157 ~886 minecraft:redstone_wire replace
setblock ~247 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~886 ~262 ~157 ~886 minecraft:redstone_wire replace
setblock ~264 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~886 ~279 ~157 ~886 minecraft:redstone_wire replace
setblock ~281 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~886 ~296 ~157 ~886 minecraft:redstone_wire replace
setblock ~298 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~886 ~313 ~157 ~886 minecraft:redstone_wire replace
setblock ~315 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~886 ~330 ~157 ~886 minecraft:redstone_wire replace
setblock ~332 ~157 ~886 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~886 ~345 ~157 ~886 minecraft:redstone_wire replace
setblock ~139 ~157 ~887 minecraft:redstone_wire replace
fill ~138 ~157 ~890 ~148 ~157 ~890 minecraft:redstone_wire replace
setblock ~150 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~890 ~165 ~157 ~890 minecraft:redstone_wire replace
setblock ~167 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~890 ~182 ~157 ~890 minecraft:redstone_wire replace
setblock ~184 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~890 ~199 ~157 ~890 minecraft:redstone_wire replace
setblock ~201 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~890 ~216 ~157 ~890 minecraft:redstone_wire replace
setblock ~218 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~157 ~890 ~233 ~157 ~890 minecraft:redstone_wire replace
setblock ~235 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~157 ~890 ~250 ~157 ~890 minecraft:redstone_wire replace
setblock ~252 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~157 ~890 ~267 ~157 ~890 minecraft:redstone_wire replace
setblock ~269 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~157 ~890 ~284 ~157 ~890 minecraft:redstone_wire replace
setblock ~286 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~157 ~890 ~301 ~157 ~890 minecraft:redstone_wire replace
setblock ~303 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~305 ~157 ~890 ~318 ~157 ~890 minecraft:redstone_wire replace
setblock ~320 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~157 ~890 ~335 ~157 ~890 minecraft:redstone_wire replace
setblock ~337 ~157 ~890 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~157 ~890 ~348 ~157 ~890 minecraft:redstone_wire replace
setblock ~139 ~157 ~891 minecraft:redstone_wire replace
setblock ~141 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~894 ~155 ~157 ~894 minecraft:redstone_wire replace
setblock ~157 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~894 ~172 ~157 ~894 minecraft:redstone_wire replace
setblock ~174 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~894 ~189 ~157 ~894 minecraft:redstone_wire replace
setblock ~191 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~894 ~206 ~157 ~894 minecraft:redstone_wire replace
setblock ~208 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~894 ~223 ~157 ~894 minecraft:redstone_wire replace
setblock ~225 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~894 ~240 ~157 ~894 minecraft:redstone_wire replace
setblock ~242 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~894 ~257 ~157 ~894 minecraft:redstone_wire replace
setblock ~259 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~894 ~274 ~157 ~894 minecraft:redstone_wire replace
setblock ~276 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~894 ~291 ~157 ~894 minecraft:redstone_wire replace
setblock ~293 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~894 ~308 ~157 ~894 minecraft:redstone_wire replace
setblock ~310 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~894 ~325 ~157 ~894 minecraft:redstone_wire replace
setblock ~327 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~894 ~342 ~157 ~894 minecraft:redstone_wire replace
setblock ~344 ~157 ~894 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~894 ~351 ~157 ~894 minecraft:redstone_wire replace
setblock ~142 ~157 ~895 minecraft:redstone_wire replace
fill ~141 ~157 ~898 ~151 ~157 ~898 minecraft:redstone_wire replace
setblock ~153 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~898 ~168 ~157 ~898 minecraft:redstone_wire replace
setblock ~170 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~157 ~898 ~185 ~157 ~898 minecraft:redstone_wire replace
setblock ~187 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~157 ~898 ~202 ~157 ~898 minecraft:redstone_wire replace
setblock ~204 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~157 ~898 ~219 ~157 ~898 minecraft:redstone_wire replace
setblock ~221 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~157 ~898 ~236 ~157 ~898 minecraft:redstone_wire replace
setblock ~238 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~157 ~898 ~253 ~157 ~898 minecraft:redstone_wire replace
setblock ~255 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~157 ~898 ~270 ~157 ~898 minecraft:redstone_wire replace
setblock ~272 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~157 ~898 ~287 ~157 ~898 minecraft:redstone_wire replace
setblock ~289 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~157 ~898 ~304 ~157 ~898 minecraft:redstone_wire replace
setblock ~306 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~157 ~898 ~321 ~157 ~898 minecraft:redstone_wire replace
setblock ~323 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~325 ~157 ~898 ~338 ~157 ~898 minecraft:redstone_wire replace
setblock ~340 ~157 ~898 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~342 ~157 ~898 ~354 ~157 ~898 minecraft:redstone_wire replace
setblock ~142 ~157 ~899 minecraft:redstone_wire replace
setblock ~141 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~902 ~155 ~157 ~902 minecraft:redstone_wire replace
setblock ~157 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~902 ~172 ~157 ~902 minecraft:redstone_wire replace
setblock ~174 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~902 ~189 ~157 ~902 minecraft:redstone_wire replace
setblock ~191 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~902 ~206 ~157 ~902 minecraft:redstone_wire replace
setblock ~208 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~902 ~223 ~157 ~902 minecraft:redstone_wire replace
setblock ~225 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~902 ~240 ~157 ~902 minecraft:redstone_wire replace
setblock ~242 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~902 ~257 ~157 ~902 minecraft:redstone_wire replace
setblock ~259 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~902 ~274 ~157 ~902 minecraft:redstone_wire replace
setblock ~276 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~902 ~291 ~157 ~902 minecraft:redstone_wire replace
setblock ~293 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~902 ~308 ~157 ~902 minecraft:redstone_wire replace
setblock ~310 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~902 ~325 ~157 ~902 minecraft:redstone_wire replace
setblock ~327 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~902 ~342 ~157 ~902 minecraft:redstone_wire replace
setblock ~344 ~157 ~902 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~902 ~357 ~157 ~902 minecraft:redstone_wire replace
setblock ~142 ~157 ~903 minecraft:redstone_wire replace
fill ~141 ~157 ~906 ~143 ~157 ~906 minecraft:redstone_wire replace
setblock ~145 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~906 ~160 ~157 ~906 minecraft:redstone_wire replace
setblock ~162 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~906 ~177 ~157 ~906 minecraft:redstone_wire replace
setblock ~179 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~906 ~194 ~157 ~906 minecraft:redstone_wire replace
setblock ~196 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~906 ~211 ~157 ~906 minecraft:redstone_wire replace
setblock ~213 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~906 ~228 ~157 ~906 minecraft:redstone_wire replace
setblock ~230 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~906 ~245 ~157 ~906 minecraft:redstone_wire replace
setblock ~247 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~906 ~262 ~157 ~906 minecraft:redstone_wire replace
setblock ~264 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~906 ~279 ~157 ~906 minecraft:redstone_wire replace
setblock ~281 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~906 ~296 ~157 ~906 minecraft:redstone_wire replace
setblock ~298 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~906 ~313 ~157 ~906 minecraft:redstone_wire replace
setblock ~315 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~906 ~330 ~157 ~906 minecraft:redstone_wire replace
setblock ~332 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~906 ~347 ~157 ~906 minecraft:redstone_wire replace
setblock ~349 ~157 ~906 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~157 ~906 ~360 ~157 ~906 minecraft:redstone_wire replace
setblock ~142 ~157 ~907 minecraft:redstone_wire replace
fill ~144 ~157 ~910 ~150 ~157 ~910 minecraft:redstone_wire replace
setblock ~152 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~910 ~167 ~157 ~910 minecraft:redstone_wire replace
setblock ~169 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~910 ~184 ~157 ~910 minecraft:redstone_wire replace
setblock ~186 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~910 ~201 ~157 ~910 minecraft:redstone_wire replace
setblock ~203 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~910 ~218 ~157 ~910 minecraft:redstone_wire replace
setblock ~220 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~910 ~235 ~157 ~910 minecraft:redstone_wire replace
setblock ~237 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~910 ~252 ~157 ~910 minecraft:redstone_wire replace
setblock ~254 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~910 ~269 ~157 ~910 minecraft:redstone_wire replace
setblock ~271 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~910 ~286 ~157 ~910 minecraft:redstone_wire replace
setblock ~288 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~910 ~303 ~157 ~910 minecraft:redstone_wire replace
setblock ~305 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~910 ~320 ~157 ~910 minecraft:redstone_wire replace
setblock ~322 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~910 ~337 ~157 ~910 minecraft:redstone_wire replace
setblock ~339 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~910 ~354 ~157 ~910 minecraft:redstone_wire replace
setblock ~356 ~157 ~910 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~910 ~363 ~157 ~910 minecraft:redstone_wire replace
setblock ~145 ~157 ~911 minecraft:redstone_wire replace
fill ~144 ~157 ~914 ~146 ~157 ~914 minecraft:redstone_wire replace
setblock ~148 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~157 ~914 ~163 ~157 ~914 minecraft:redstone_wire replace
setblock ~165 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~914 ~180 ~157 ~914 minecraft:redstone_wire replace
setblock ~182 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~914 ~197 ~157 ~914 minecraft:redstone_wire replace
setblock ~199 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~914 ~214 ~157 ~914 minecraft:redstone_wire replace
setblock ~216 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~914 ~231 ~157 ~914 minecraft:redstone_wire replace
setblock ~233 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~914 ~248 ~157 ~914 minecraft:redstone_wire replace
setblock ~250 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~914 ~265 ~157 ~914 minecraft:redstone_wire replace
setblock ~267 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~914 ~282 ~157 ~914 minecraft:redstone_wire replace
setblock ~284 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~914 ~299 ~157 ~914 minecraft:redstone_wire replace
setblock ~301 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~157 ~914 ~316 ~157 ~914 minecraft:redstone_wire replace
setblock ~318 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~320 ~157 ~914 ~333 ~157 ~914 minecraft:redstone_wire replace
setblock ~335 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~157 ~914 ~350 ~157 ~914 minecraft:redstone_wire replace
setblock ~352 ~157 ~914 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~157 ~914 ~366 ~157 ~914 minecraft:redstone_wire replace
setblock ~145 ~157 ~915 minecraft:redstone_wire replace
fill ~144 ~157 ~918 ~150 ~157 ~918 minecraft:redstone_wire replace
setblock ~152 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~918 ~167 ~157 ~918 minecraft:redstone_wire replace
setblock ~169 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~918 ~184 ~157 ~918 minecraft:redstone_wire replace
setblock ~186 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~918 ~201 ~157 ~918 minecraft:redstone_wire replace
setblock ~203 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~918 ~218 ~157 ~918 minecraft:redstone_wire replace
setblock ~220 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~918 ~235 ~157 ~918 minecraft:redstone_wire replace
setblock ~237 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~918 ~252 ~157 ~918 minecraft:redstone_wire replace
setblock ~254 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~918 ~269 ~157 ~918 minecraft:redstone_wire replace
setblock ~271 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~918 ~286 ~157 ~918 minecraft:redstone_wire replace
setblock ~288 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~918 ~303 ~157 ~918 minecraft:redstone_wire replace
setblock ~305 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~918 ~320 ~157 ~918 minecraft:redstone_wire replace
setblock ~322 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~918 ~337 ~157 ~918 minecraft:redstone_wire replace
setblock ~339 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~918 ~354 ~157 ~918 minecraft:redstone_wire replace
setblock ~356 ~157 ~918 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~918 ~369 ~157 ~918 minecraft:redstone_wire replace
setblock ~145 ~157 ~919 minecraft:redstone_wire replace
fill ~144 ~157 ~922 ~155 ~157 ~922 minecraft:redstone_wire replace
setblock ~157 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~922 ~172 ~157 ~922 minecraft:redstone_wire replace
setblock ~174 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~922 ~189 ~157 ~922 minecraft:redstone_wire replace
setblock ~191 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~922 ~206 ~157 ~922 minecraft:redstone_wire replace
setblock ~208 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~922 ~223 ~157 ~922 minecraft:redstone_wire replace
setblock ~225 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~922 ~240 ~157 ~922 minecraft:redstone_wire replace
setblock ~242 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~922 ~257 ~157 ~922 minecraft:redstone_wire replace
setblock ~259 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~922 ~274 ~157 ~922 minecraft:redstone_wire replace
setblock ~276 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~922 ~291 ~157 ~922 minecraft:redstone_wire replace
setblock ~293 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~922 ~308 ~157 ~922 minecraft:redstone_wire replace
setblock ~310 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~922 ~325 ~157 ~922 minecraft:redstone_wire replace
setblock ~327 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~922 ~342 ~157 ~922 minecraft:redstone_wire replace
setblock ~344 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~922 ~359 ~157 ~922 minecraft:redstone_wire replace
setblock ~361 ~157 ~922 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~157 ~922 ~372 ~157 ~922 minecraft:redstone_wire replace
setblock ~145 ~157 ~923 minecraft:redstone_wire replace
fill ~144 ~157 ~926 ~145 ~157 ~926 minecraft:redstone_wire replace
setblock ~147 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~926 ~162 ~157 ~926 minecraft:redstone_wire replace
setblock ~164 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~926 ~179 ~157 ~926 minecraft:redstone_wire replace
setblock ~181 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~926 ~196 ~157 ~926 minecraft:redstone_wire replace
setblock ~198 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~926 ~213 ~157 ~926 minecraft:redstone_wire replace
setblock ~215 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~926 ~230 ~157 ~926 minecraft:redstone_wire replace
setblock ~232 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~926 ~247 ~157 ~926 minecraft:redstone_wire replace
setblock ~249 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~926 ~264 ~157 ~926 minecraft:redstone_wire replace
setblock ~266 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~926 ~281 ~157 ~926 minecraft:redstone_wire replace
setblock ~283 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~157 ~926 ~298 ~157 ~926 minecraft:redstone_wire replace
setblock ~300 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~157 ~926 ~315 ~157 ~926 minecraft:redstone_wire replace
setblock ~317 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~157 ~926 ~332 ~157 ~926 minecraft:redstone_wire replace
setblock ~334 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~157 ~926 ~349 ~157 ~926 minecraft:redstone_wire replace
setblock ~351 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~353 ~157 ~926 ~366 ~157 ~926 minecraft:redstone_wire replace
setblock ~368 ~157 ~926 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~157 ~926 ~375 ~157 ~926 minecraft:redstone_wire replace
setblock ~145 ~157 ~927 minecraft:redstone_wire replace
setblock ~144 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~930 ~158 ~157 ~930 minecraft:redstone_wire replace
setblock ~160 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~930 ~175 ~157 ~930 minecraft:redstone_wire replace
setblock ~177 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~930 ~192 ~157 ~930 minecraft:redstone_wire replace
setblock ~194 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~930 ~209 ~157 ~930 minecraft:redstone_wire replace
setblock ~211 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~930 ~226 ~157 ~930 minecraft:redstone_wire replace
setblock ~228 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~930 ~243 ~157 ~930 minecraft:redstone_wire replace
setblock ~245 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~930 ~260 ~157 ~930 minecraft:redstone_wire replace
setblock ~262 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~930 ~277 ~157 ~930 minecraft:redstone_wire replace
setblock ~279 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~930 ~294 ~157 ~930 minecraft:redstone_wire replace
setblock ~296 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~930 ~311 ~157 ~930 minecraft:redstone_wire replace
setblock ~313 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~157 ~930 ~328 ~157 ~930 minecraft:redstone_wire replace
setblock ~330 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~332 ~157 ~930 ~345 ~157 ~930 minecraft:redstone_wire replace
setblock ~347 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~349 ~157 ~930 ~362 ~157 ~930 minecraft:redstone_wire replace
setblock ~364 ~157 ~930 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~366 ~157 ~930 ~378 ~157 ~930 minecraft:redstone_wire replace
setblock ~145 ~157 ~931 minecraft:redstone_wire replace
fill ~147 ~157 ~934 ~159 ~157 ~934 minecraft:redstone_wire replace
setblock ~161 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~934 ~175 ~157 ~934 minecraft:redstone_wire replace
setblock ~177 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~934 ~191 ~157 ~934 minecraft:redstone_wire replace
setblock ~193 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~934 ~207 ~157 ~934 minecraft:redstone_wire replace
setblock ~209 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~934 ~223 ~157 ~934 minecraft:redstone_wire replace
setblock ~225 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~934 ~239 ~157 ~934 minecraft:redstone_wire replace
setblock ~241 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~157 ~934 ~255 ~157 ~934 minecraft:redstone_wire replace
setblock ~257 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~934 ~271 ~157 ~934 minecraft:redstone_wire replace
setblock ~273 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~157 ~934 ~287 ~157 ~934 minecraft:redstone_wire replace
setblock ~289 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~157 ~934 ~303 ~157 ~934 minecraft:redstone_wire replace
setblock ~305 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~934 ~319 ~157 ~934 minecraft:redstone_wire replace
setblock ~321 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~323 ~157 ~934 ~335 ~157 ~934 minecraft:redstone_wire replace
setblock ~337 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~157 ~934 ~351 ~157 ~934 minecraft:redstone_wire replace
setblock ~353 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~355 ~157 ~934 ~367 ~157 ~934 minecraft:redstone_wire replace
setblock ~369 ~157 ~934 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~371 ~157 ~934 ~381 ~157 ~934 minecraft:redstone_wire replace
setblock ~148 ~157 ~935 minecraft:redstone_wire replace
fill ~147 ~157 ~938 ~150 ~157 ~938 minecraft:redstone_wire replace
setblock ~152 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~938 ~167 ~157 ~938 minecraft:redstone_wire replace
setblock ~169 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~938 ~184 ~157 ~938 minecraft:redstone_wire replace
setblock ~186 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~938 ~201 ~157 ~938 minecraft:redstone_wire replace
setblock ~203 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~938 ~218 ~157 ~938 minecraft:redstone_wire replace
setblock ~220 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~938 ~235 ~157 ~938 minecraft:redstone_wire replace
setblock ~237 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~938 ~252 ~157 ~938 minecraft:redstone_wire replace
setblock ~254 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~938 ~269 ~157 ~938 minecraft:redstone_wire replace
setblock ~271 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~938 ~286 ~157 ~938 minecraft:redstone_wire replace
setblock ~288 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~938 ~303 ~157 ~938 minecraft:redstone_wire replace
setblock ~305 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~938 ~320 ~157 ~938 minecraft:redstone_wire replace
setblock ~322 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~938 ~337 ~157 ~938 minecraft:redstone_wire replace
setblock ~339 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~938 ~354 ~157 ~938 minecraft:redstone_wire replace
setblock ~356 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~938 ~371 ~157 ~938 minecraft:redstone_wire replace
setblock ~373 ~157 ~938 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~157 ~938 ~384 ~157 ~938 minecraft:redstone_wire replace
setblock ~148 ~157 ~939 minecraft:redstone_wire replace
fill ~147 ~157 ~942 ~157 ~157 ~942 minecraft:redstone_wire replace
setblock ~159 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~942 ~174 ~157 ~942 minecraft:redstone_wire replace
setblock ~176 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~942 ~191 ~157 ~942 minecraft:redstone_wire replace
setblock ~193 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~942 ~208 ~157 ~942 minecraft:redstone_wire replace
setblock ~210 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~942 ~225 ~157 ~942 minecraft:redstone_wire replace
setblock ~227 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~942 ~242 ~157 ~942 minecraft:redstone_wire replace
setblock ~244 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~942 ~259 ~157 ~942 minecraft:redstone_wire replace
setblock ~261 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~942 ~276 ~157 ~942 minecraft:redstone_wire replace
setblock ~278 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~942 ~293 ~157 ~942 minecraft:redstone_wire replace
setblock ~295 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~157 ~942 ~310 ~157 ~942 minecraft:redstone_wire replace
setblock ~312 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~942 ~327 ~157 ~942 minecraft:redstone_wire replace
setblock ~329 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~157 ~942 ~344 ~157 ~942 minecraft:redstone_wire replace
setblock ~346 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~157 ~942 ~361 ~157 ~942 minecraft:redstone_wire replace
setblock ~363 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~365 ~157 ~942 ~378 ~157 ~942 minecraft:redstone_wire replace
setblock ~380 ~157 ~942 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~382 ~157 ~942 ~387 ~157 ~942 minecraft:redstone_wire replace
setblock ~148 ~157 ~943 minecraft:redstone_wire replace
fill ~147 ~157 ~946 ~153 ~157 ~946 minecraft:redstone_wire replace
setblock ~155 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~946 ~170 ~157 ~946 minecraft:redstone_wire replace
setblock ~172 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~946 ~187 ~157 ~946 minecraft:redstone_wire replace
setblock ~189 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~157 ~946 ~204 ~157 ~946 minecraft:redstone_wire replace
setblock ~206 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~157 ~946 ~221 ~157 ~946 minecraft:redstone_wire replace
setblock ~223 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~157 ~946 ~238 ~157 ~946 minecraft:redstone_wire replace
setblock ~240 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~157 ~946 ~255 ~157 ~946 minecraft:redstone_wire replace
setblock ~257 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~157 ~946 ~272 ~157 ~946 minecraft:redstone_wire replace
setblock ~274 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~946 ~289 ~157 ~946 minecraft:redstone_wire replace
setblock ~291 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~293 ~157 ~946 ~306 ~157 ~946 minecraft:redstone_wire replace
setblock ~308 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~310 ~157 ~946 ~323 ~157 ~946 minecraft:redstone_wire replace
setblock ~325 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~157 ~946 ~340 ~157 ~946 minecraft:redstone_wire replace
setblock ~342 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~344 ~157 ~946 ~357 ~157 ~946 minecraft:redstone_wire replace
setblock ~359 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~361 ~157 ~946 ~374 ~157 ~946 minecraft:redstone_wire replace
setblock ~376 ~157 ~946 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~378 ~157 ~946 ~390 ~157 ~946 minecraft:redstone_wire replace
setblock ~148 ~157 ~947 minecraft:redstone_wire replace
fill ~147 ~157 ~950 ~157 ~157 ~950 minecraft:redstone_wire replace
setblock ~159 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~950 ~174 ~157 ~950 minecraft:redstone_wire replace
setblock ~176 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~950 ~191 ~157 ~950 minecraft:redstone_wire replace
setblock ~193 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~950 ~208 ~157 ~950 minecraft:redstone_wire replace
setblock ~210 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~950 ~225 ~157 ~950 minecraft:redstone_wire replace
setblock ~227 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~950 ~242 ~157 ~950 minecraft:redstone_wire replace
setblock ~244 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~950 ~259 ~157 ~950 minecraft:redstone_wire replace
setblock ~261 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~950 ~276 ~157 ~950 minecraft:redstone_wire replace
setblock ~278 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~950 ~293 ~157 ~950 minecraft:redstone_wire replace
setblock ~295 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~157 ~950 ~310 ~157 ~950 minecraft:redstone_wire replace
setblock ~312 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~950 ~327 ~157 ~950 minecraft:redstone_wire replace
setblock ~329 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~157 ~950 ~344 ~157 ~950 minecraft:redstone_wire replace
setblock ~346 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~157 ~950 ~361 ~157 ~950 minecraft:redstone_wire replace
setblock ~363 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~365 ~157 ~950 ~378 ~157 ~950 minecraft:redstone_wire replace
setblock ~380 ~157 ~950 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~382 ~157 ~950 ~393 ~157 ~950 minecraft:redstone_wire replace
setblock ~148 ~157 ~951 minecraft:redstone_wire replace
setblock ~147 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~157 ~954 ~160 ~157 ~954 minecraft:redstone_wire replace
setblock ~162 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~954 ~176 ~157 ~954 minecraft:redstone_wire replace
setblock ~178 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~954 ~192 ~157 ~954 minecraft:redstone_wire replace
setblock ~194 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~954 ~208 ~157 ~954 minecraft:redstone_wire replace
setblock ~210 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~954 ~224 ~157 ~954 minecraft:redstone_wire replace
setblock ~226 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~157 ~954 ~240 ~157 ~954 minecraft:redstone_wire replace
setblock ~242 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~954 ~256 ~157 ~954 minecraft:redstone_wire replace
setblock ~258 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~260 ~157 ~954 ~272 ~157 ~954 minecraft:redstone_wire replace
setblock ~274 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~157 ~954 ~288 ~157 ~954 minecraft:redstone_wire replace
setblock ~290 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~157 ~954 ~304 ~157 ~954 minecraft:redstone_wire replace
setblock ~306 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~308 ~157 ~954 ~320 ~157 ~954 minecraft:redstone_wire replace
setblock ~322 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~954 ~336 ~157 ~954 minecraft:redstone_wire replace
setblock ~338 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~340 ~157 ~954 ~352 ~157 ~954 minecraft:redstone_wire replace
setblock ~354 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~356 ~157 ~954 ~368 ~157 ~954 minecraft:redstone_wire replace
setblock ~370 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~372 ~157 ~954 ~384 ~157 ~954 minecraft:redstone_wire replace
setblock ~386 ~157 ~954 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~388 ~157 ~954 ~396 ~157 ~954 minecraft:redstone_wire replace
setblock ~148 ~157 ~955 minecraft:redstone_wire replace
fill ~147 ~157 ~958 ~152 ~157 ~958 minecraft:redstone_wire replace
setblock ~154 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~958 ~169 ~157 ~958 minecraft:redstone_wire replace
setblock ~171 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~958 ~186 ~157 ~958 minecraft:redstone_wire replace
setblock ~188 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~958 ~203 ~157 ~958 minecraft:redstone_wire replace
setblock ~205 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~958 ~220 ~157 ~958 minecraft:redstone_wire replace
setblock ~222 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~157 ~958 ~237 ~157 ~958 minecraft:redstone_wire replace
setblock ~239 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~157 ~958 ~254 ~157 ~958 minecraft:redstone_wire replace
setblock ~256 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~157 ~958 ~271 ~157 ~958 minecraft:redstone_wire replace
setblock ~273 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~157 ~958 ~288 ~157 ~958 minecraft:redstone_wire replace
setblock ~290 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~157 ~958 ~305 ~157 ~958 minecraft:redstone_wire replace
setblock ~307 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~309 ~157 ~958 ~322 ~157 ~958 minecraft:redstone_wire replace
setblock ~324 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~326 ~157 ~958 ~339 ~157 ~958 minecraft:redstone_wire replace
setblock ~341 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~157 ~958 ~356 ~157 ~958 minecraft:redstone_wire replace
setblock ~358 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~360 ~157 ~958 ~373 ~157 ~958 minecraft:redstone_wire replace
setblock ~375 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~377 ~157 ~958 ~390 ~157 ~958 minecraft:redstone_wire replace
setblock ~392 ~157 ~958 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~394 ~157 ~958 ~399 ~157 ~958 minecraft:redstone_wire replace
setblock ~148 ~157 ~959 minecraft:redstone_wire replace
fill ~174 ~157 ~962 ~179 ~157 ~962 minecraft:redstone_wire replace
setblock ~181 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~962 ~196 ~157 ~962 minecraft:redstone_wire replace
setblock ~198 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~962 ~213 ~157 ~962 minecraft:redstone_wire replace
setblock ~215 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~962 ~230 ~157 ~962 minecraft:redstone_wire replace
setblock ~232 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~962 ~247 ~157 ~962 minecraft:redstone_wire replace
setblock ~249 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~962 ~264 ~157 ~962 minecraft:redstone_wire replace
setblock ~266 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~962 ~281 ~157 ~962 minecraft:redstone_wire replace
setblock ~283 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~157 ~962 ~298 ~157 ~962 minecraft:redstone_wire replace
setblock ~300 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~157 ~962 ~315 ~157 ~962 minecraft:redstone_wire replace
setblock ~317 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~157 ~962 ~332 ~157 ~962 minecraft:redstone_wire replace
setblock ~334 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~157 ~962 ~349 ~157 ~962 minecraft:redstone_wire replace
setblock ~351 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~353 ~157 ~962 ~366 ~157 ~962 minecraft:redstone_wire replace
setblock ~368 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~157 ~962 ~383 ~157 ~962 minecraft:redstone_wire replace
setblock ~385 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~387 ~157 ~962 ~400 ~157 ~962 minecraft:redstone_wire replace
setblock ~402 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~404 ~157 ~962 ~417 ~157 ~962 minecraft:redstone_wire replace
setblock ~419 ~157 ~962 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~421 ~157 ~962 ~432 ~157 ~962 minecraft:redstone_wire replace
setblock ~175 ~157 ~963 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~157 ~966 ~172 ~157 ~966 minecraft:redstone_wire replace
setblock ~174 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~966 ~189 ~157 ~966 minecraft:redstone_wire replace
setblock ~191 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~966 ~206 ~157 ~966 minecraft:redstone_wire replace
setblock ~208 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~966 ~223 ~157 ~966 minecraft:redstone_wire replace
setblock ~225 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~966 ~240 ~157 ~966 minecraft:redstone_wire replace
setblock ~242 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~966 ~257 ~157 ~966 minecraft:redstone_wire replace
setblock ~259 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~966 ~274 ~157 ~966 minecraft:redstone_wire replace
setblock ~276 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~966 ~291 ~157 ~966 minecraft:redstone_wire replace
setblock ~293 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~966 ~308 ~157 ~966 minecraft:redstone_wire replace
setblock ~310 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~966 ~325 ~157 ~966 minecraft:redstone_wire replace
setblock ~327 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~966 ~342 ~157 ~966 minecraft:redstone_wire replace
setblock ~344 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~966 ~359 ~157 ~966 minecraft:redstone_wire replace
setblock ~361 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~157 ~966 ~376 ~157 ~966 minecraft:redstone_wire replace
setblock ~378 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~380 ~157 ~966 ~393 ~157 ~966 minecraft:redstone_wire replace
setblock ~395 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~397 ~157 ~966 ~410 ~157 ~966 minecraft:redstone_wire replace
setblock ~412 ~157 ~966 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~414 ~157 ~966 ~426 ~157 ~966 minecraft:redstone_wire replace
setblock ~169 ~157 ~967 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~157 ~970 ~175 ~157 ~970 minecraft:redstone_wire replace
setblock ~177 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~970 ~192 ~157 ~970 minecraft:redstone_wire replace
setblock ~194 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~157 ~970 ~209 ~157 ~970 minecraft:redstone_wire replace
setblock ~211 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~157 ~970 ~226 ~157 ~970 minecraft:redstone_wire replace
setblock ~228 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~157 ~970 ~243 ~157 ~970 minecraft:redstone_wire replace
setblock ~245 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~970 ~260 ~157 ~970 minecraft:redstone_wire replace
setblock ~262 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~157 ~970 ~277 ~157 ~970 minecraft:redstone_wire replace
setblock ~279 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~157 ~970 ~294 ~157 ~970 minecraft:redstone_wire replace
setblock ~296 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~970 ~311 ~157 ~970 minecraft:redstone_wire replace
setblock ~313 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~157 ~970 ~328 ~157 ~970 minecraft:redstone_wire replace
setblock ~330 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~332 ~157 ~970 ~345 ~157 ~970 minecraft:redstone_wire replace
setblock ~347 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~349 ~157 ~970 ~362 ~157 ~970 minecraft:redstone_wire replace
setblock ~364 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~366 ~157 ~970 ~379 ~157 ~970 minecraft:redstone_wire replace
setblock ~381 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~383 ~157 ~970 ~396 ~157 ~970 minecraft:redstone_wire replace
setblock ~398 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~400 ~157 ~970 ~413 ~157 ~970 minecraft:redstone_wire replace
setblock ~415 ~157 ~970 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~417 ~157 ~970 ~429 ~157 ~970 minecraft:redstone_wire replace
setblock ~172 ~157 ~971 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~158 ~236 minecraft:redstone_wire replace
setblock ~82 ~158 ~240 minecraft:redstone_wire replace
setblock ~103 ~158 ~268 minecraft:redstone_wire replace
setblock ~100 ~158 ~292 minecraft:redstone_wire replace
setblock ~97 ~158 ~308 minecraft:redstone_wire replace
setblock ~94 ~158 ~336 minecraft:redstone_wire replace
setblock ~91 ~158 ~372 minecraft:redstone_wire replace
setblock ~88 ~158 ~404 minecraft:redstone_wire replace
setblock ~85 ~158 ~436 minecraft:redstone_wire replace
setblock ~79 ~158 ~452 minecraft:redstone_wire replace
setblock ~109 ~158 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~158 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~576 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~584 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~158 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~158 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~644 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~648 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~656 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~158 ~664 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~668 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~672 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~676 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~158 ~680 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~684 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~688 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~692 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~696 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~700 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~158 ~704 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~708 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~712 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~716 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~720 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~724 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~728 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~158 ~732 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~158 ~736 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~158 ~740 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~158 ~744 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~158 ~748 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~158 ~752 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~158 ~756 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~158 ~760 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~158 ~764 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~768 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~772 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~776 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~780 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~784 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~788 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~792 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~158 ~796 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~800 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~804 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~808 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~812 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~816 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~820 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~824 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~158 ~828 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~832 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~836 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~840 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~844 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~848 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~852 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~856 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~860 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~158 ~864 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~868 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~872 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~876 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~880 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~884 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~888 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~158 ~892 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~896 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~900 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~904 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~158 ~908 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~912 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~916 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~920 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~924 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~928 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~158 ~932 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~936 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~940 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~944 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~948 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~952 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~956 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~158 ~960 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~158 ~964 minecraft:redstone_wire replace
setblock ~169 ~158 ~968 minecraft:redstone_wire replace
setblock ~172 ~158 ~972 minecraft:redstone_wire replace
fill ~105 ~159 ~232 ~105 ~159 ~236 minecraft:redstone_wire replace
fill ~81 ~159 ~236 ~81 ~159 ~240 minecraft:redstone_wire replace
fill ~102 ~159 ~264 ~102 ~159 ~268 minecraft:redstone_wire replace
fill ~99 ~159 ~288 ~99 ~159 ~292 minecraft:redstone_wire replace
fill ~96 ~159 ~304 ~96 ~159 ~308 minecraft:redstone_wire replace
fill ~93 ~159 ~332 ~93 ~159 ~336 minecraft:redstone_wire replace
fill ~90 ~159 ~368 ~90 ~159 ~372 minecraft:redstone_wire replace
fill ~87 ~159 ~400 ~87 ~159 ~404 minecraft:redstone_wire replace
fill ~84 ~159 ~432 ~84 ~159 ~436 minecraft:redstone_wire replace
fill ~78 ~159 ~448 ~78 ~159 ~452 minecraft:redstone_wire replace
fill ~108 ~159 ~536 ~108 ~159 ~540 minecraft:redstone_wire replace
setblock ~108 ~159 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~159 ~542 ~108 ~159 ~554 minecraft:redstone_wire replace
setblock ~108 ~159 ~555 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~159 ~556 ~108 ~159 ~568 minecraft:redstone_wire replace
fill ~111 ~159 ~568 ~111 ~159 ~572 minecraft:redstone_wire replace
setblock ~111 ~159 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~159 ~574 ~111 ~159 ~586 minecraft:redstone_wire replace
setblock ~111 ~159 ~587 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~159 ~588 ~111 ~159 ~600 minecraft:redstone_wire replace
setblock ~114 ~159 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~159 ~602 ~114 ~159 ~608 minecraft:redstone_wire replace
setblock ~114 ~159 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~159 ~610 ~114 ~159 ~622 minecraft:redstone_wire replace
setblock ~114 ~159 ~623 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~159 ~624 ~114 ~159 ~636 minecraft:redstone_wire replace
setblock ~117 ~159 ~636 minecraft:redstone_wire replace
setblock ~117 ~159 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~159 ~638 ~117 ~159 ~650 minecraft:redstone_wire replace
setblock ~117 ~159 ~651 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~159 ~652 ~117 ~159 ~664 minecraft:redstone_wire replace
fill ~120 ~159 ~664 ~120 ~159 ~666 minecraft:redstone_wire replace
setblock ~120 ~159 ~667 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~159 ~668 ~120 ~159 ~680 minecraft:redstone_wire replace
setblock ~123 ~159 ~680 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~159 ~682 ~123 ~159 ~690 minecraft:redstone_wire replace
setblock ~123 ~159 ~691 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~159 ~692 ~123 ~159 ~704 minecraft:redstone_wire replace
setblock ~126 ~159 ~704 minecraft:redstone_wire replace
setblock ~126 ~159 ~705 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~159 ~706 ~126 ~159 ~718 minecraft:redstone_wire replace
setblock ~126 ~159 ~719 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~159 ~720 ~126 ~159 ~732 minecraft:redstone_wire replace
fill ~150 ~159 ~732 ~150 ~159 ~736 minecraft:redstone_wire replace
setblock ~153 ~159 ~736 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~159 ~738 ~153 ~159 ~744 minecraft:redstone_wire replace
setblock ~156 ~159 ~744 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~159 ~746 ~156 ~159 ~752 minecraft:redstone_wire replace
fill ~159 ~159 ~752 ~159 ~159 ~756 minecraft:redstone_wire replace
fill ~162 ~159 ~756 ~162 ~159 ~760 minecraft:redstone_wire replace
fill ~165 ~159 ~760 ~165 ~159 ~764 minecraft:redstone_wire replace
fill ~129 ~159 ~764 ~129 ~159 ~768 minecraft:redstone_wire replace
setblock ~129 ~159 ~769 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~159 ~770 ~129 ~159 ~782 minecraft:redstone_wire replace
setblock ~129 ~159 ~783 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~159 ~784 ~129 ~159 ~796 minecraft:redstone_wire replace
fill ~132 ~159 ~796 ~132 ~159 ~800 minecraft:redstone_wire replace
setblock ~132 ~159 ~801 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~159 ~802 ~132 ~159 ~814 minecraft:redstone_wire replace
setblock ~132 ~159 ~815 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~159 ~816 ~132 ~159 ~828 minecraft:redstone_wire replace
setblock ~135 ~159 ~828 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~159 ~830 ~135 ~159 ~836 minecraft:redstone_wire replace
setblock ~135 ~159 ~837 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~159 ~838 ~135 ~159 ~850 minecraft:redstone_wire replace
setblock ~135 ~159 ~851 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~159 ~852 ~135 ~159 ~864 minecraft:redstone_wire replace
setblock ~138 ~159 ~864 minecraft:redstone_wire replace
setblock ~138 ~159 ~865 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~159 ~866 ~138 ~159 ~878 minecraft:redstone_wire replace
setblock ~138 ~159 ~879 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~159 ~880 ~138 ~159 ~892 minecraft:redstone_wire replace
fill ~141 ~159 ~892 ~141 ~159 ~894 minecraft:redstone_wire replace
setblock ~141 ~159 ~895 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~159 ~896 ~141 ~159 ~908 minecraft:redstone_wire replace
setblock ~144 ~159 ~908 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~159 ~910 ~144 ~159 ~918 minecraft:redstone_wire replace
setblock ~144 ~159 ~919 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~159 ~920 ~144 ~159 ~932 minecraft:redstone_wire replace
setblock ~147 ~159 ~932 minecraft:redstone_wire replace
setblock ~147 ~159 ~933 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~159 ~934 ~147 ~159 ~946 minecraft:redstone_wire replace
setblock ~147 ~159 ~947 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~159 ~948 ~147 ~159 ~960 minecraft:redstone_wire replace
fill ~174 ~159 ~960 ~174 ~159 ~964 minecraft:redstone_wire replace
fill ~168 ~159 ~964 ~168 ~159 ~968 minecraft:redstone_wire replace
fill ~171 ~159 ~968 ~171 ~159 ~972 minecraft:redstone_wire replace
setblock ~105 ~160 ~231 minecraft:redstone_wire replace
setblock ~81 ~160 ~235 minecraft:redstone_wire replace
setblock ~102 ~160 ~263 minecraft:redstone_wire replace
setblock ~99 ~160 ~287 minecraft:redstone_wire replace
setblock ~96 ~160 ~303 minecraft:redstone_wire replace
setblock ~93 ~160 ~331 minecraft:redstone_wire replace
setblock ~90 ~160 ~367 minecraft:redstone_wire replace
setblock ~87 ~160 ~399 minecraft:redstone_wire replace
setblock ~84 ~160 ~431 minecraft:redstone_wire replace
setblock ~78 ~160 ~447 minecraft:redstone_wire replace
setblock ~108 ~160 ~535 minecraft:redstone_wire replace
setblock ~111 ~160 ~567 minecraft:redstone_wire replace
setblock ~114 ~160 ~599 minecraft:redstone_wire replace
setblock ~117 ~160 ~635 minecraft:redstone_wire replace
setblock ~120 ~160 ~663 minecraft:redstone_wire replace
setblock ~123 ~160 ~679 minecraft:redstone_wire replace
setblock ~126 ~160 ~703 minecraft:redstone_wire replace
setblock ~150 ~160 ~731 minecraft:redstone_wire replace
setblock ~153 ~160 ~735 minecraft:redstone_wire replace
setblock ~156 ~160 ~743 minecraft:redstone_wire replace
setblock ~159 ~160 ~751 minecraft:redstone_wire replace
setblock ~162 ~160 ~755 minecraft:redstone_wire replace
setblock ~165 ~160 ~759 minecraft:redstone_wire replace
setblock ~129 ~160 ~763 minecraft:redstone_wire replace
setblock ~132 ~160 ~795 minecraft:redstone_wire replace
setblock ~135 ~160 ~827 minecraft:redstone_wire replace
setblock ~138 ~160 ~863 minecraft:redstone_wire replace
setblock ~141 ~160 ~891 minecraft:redstone_wire replace
setblock ~144 ~160 ~907 minecraft:redstone_wire replace
setblock ~147 ~160 ~931 minecraft:redstone_wire replace
setblock ~174 ~160 ~959 minecraft:redstone_wire replace
setblock ~168 ~160 ~963 minecraft:redstone_wire replace
setblock ~171 ~160 ~967 minecraft:redstone_wire replace
fill ~105 ~161 ~230 ~107 ~161 ~230 minecraft:redstone_wire replace
fill ~81 ~161 ~234 ~83 ~161 ~234 minecraft:redstone_wire replace
fill ~102 ~161 ~262 ~104 ~161 ~262 minecraft:redstone_wire replace
fill ~99 ~161 ~286 ~101 ~161 ~286 minecraft:redstone_wire replace
fill ~96 ~161 ~302 ~98 ~161 ~302 minecraft:redstone_wire replace
fill ~93 ~161 ~330 ~95 ~161 ~330 minecraft:redstone_wire replace
fill ~90 ~161 ~366 ~92 ~161 ~366 minecraft:redstone_wire replace
fill ~87 ~161 ~398 ~89 ~161 ~398 minecraft:redstone_wire replace
fill ~84 ~161 ~430 ~86 ~161 ~430 minecraft:redstone_wire replace
fill ~78 ~161 ~446 ~80 ~161 ~446 minecraft:redstone_wire replace
fill ~108 ~161 ~534 ~110 ~161 ~534 minecraft:redstone_wire replace
fill ~111 ~161 ~566 ~113 ~161 ~566 minecraft:redstone_wire replace
fill ~114 ~161 ~598 ~116 ~161 ~598 minecraft:redstone_wire replace
fill ~117 ~161 ~634 ~119 ~161 ~634 minecraft:redstone_wire replace
fill ~120 ~161 ~662 ~122 ~161 ~662 minecraft:redstone_wire replace
fill ~123 ~161 ~678 ~125 ~161 ~678 minecraft:redstone_wire replace
fill ~126 ~161 ~702 ~128 ~161 ~702 minecraft:redstone_wire replace
fill ~150 ~161 ~730 ~152 ~161 ~730 minecraft:redstone_wire replace
fill ~153 ~161 ~734 ~155 ~161 ~734 minecraft:redstone_wire replace
fill ~156 ~161 ~742 ~158 ~161 ~742 minecraft:redstone_wire replace
fill ~159 ~161 ~750 ~161 ~161 ~750 minecraft:redstone_wire replace
fill ~162 ~161 ~754 ~164 ~161 ~754 minecraft:redstone_wire replace
fill ~165 ~161 ~758 ~167 ~161 ~758 minecraft:redstone_wire replace
fill ~129 ~161 ~762 ~131 ~161 ~762 minecraft:redstone_wire replace
fill ~132 ~161 ~794 ~134 ~161 ~794 minecraft:redstone_wire replace
fill ~135 ~161 ~826 ~137 ~161 ~826 minecraft:redstone_wire replace
fill ~138 ~161 ~862 ~140 ~161 ~862 minecraft:redstone_wire replace
fill ~141 ~161 ~890 ~143 ~161 ~890 minecraft:redstone_wire replace
fill ~144 ~161 ~906 ~146 ~161 ~906 minecraft:redstone_wire replace
fill ~147 ~161 ~930 ~149 ~161 ~930 minecraft:redstone_wire replace
fill ~174 ~161 ~958 ~176 ~161 ~958 minecraft:redstone_wire replace
fill ~168 ~161 ~962 ~170 ~161 ~962 minecraft:redstone_wire replace
fill ~171 ~161 ~966 ~173 ~161 ~966 minecraft:redstone_wire replace
setblock ~108 ~162 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~84 ~162 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~105 ~162 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~102 ~162 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~99 ~162 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~96 ~162 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~93 ~162 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~90 ~162 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~87 ~162 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~81 ~162 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~111 ~162 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~114 ~162 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~117 ~162 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~120 ~162 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~123 ~162 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~126 ~162 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~129 ~162 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~153 ~162 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~156 ~162 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~159 ~162 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~162 ~162 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~165 ~162 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~168 ~162 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~132 ~162 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~135 ~162 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~138 ~162 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~141 ~162 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~144 ~162 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~147 ~162 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~150 ~162 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~171 ~162 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~174 ~162 ~966 minecraft:redstone_torch[lit=true] replace
setblock ~108 ~164 ~230 minecraft:redstone_torch[lit=true] replace
setblock ~84 ~164 ~234 minecraft:redstone_torch[lit=true] replace
setblock ~105 ~164 ~262 minecraft:redstone_torch[lit=true] replace
setblock ~102 ~164 ~286 minecraft:redstone_torch[lit=true] replace
setblock ~99 ~164 ~302 minecraft:redstone_torch[lit=true] replace
setblock ~96 ~164 ~330 minecraft:redstone_torch[lit=true] replace
setblock ~93 ~164 ~366 minecraft:redstone_torch[lit=true] replace
setblock ~90 ~164 ~398 minecraft:redstone_torch[lit=true] replace
setblock ~87 ~164 ~430 minecraft:redstone_torch[lit=true] replace
setblock ~81 ~164 ~446 minecraft:redstone_torch[lit=true] replace
setblock ~111 ~164 ~534 minecraft:redstone_torch[lit=true] replace
setblock ~114 ~164 ~566 minecraft:redstone_torch[lit=true] replace
setblock ~117 ~164 ~598 minecraft:redstone_torch[lit=true] replace
setblock ~120 ~164 ~634 minecraft:redstone_torch[lit=true] replace
setblock ~123 ~164 ~662 minecraft:redstone_torch[lit=true] replace
setblock ~126 ~164 ~678 minecraft:redstone_torch[lit=true] replace
setblock ~129 ~164 ~702 minecraft:redstone_torch[lit=true] replace
setblock ~153 ~164 ~730 minecraft:redstone_torch[lit=true] replace
setblock ~156 ~164 ~734 minecraft:redstone_torch[lit=true] replace
setblock ~159 ~164 ~742 minecraft:redstone_torch[lit=true] replace
setblock ~162 ~164 ~750 minecraft:redstone_torch[lit=true] replace
setblock ~165 ~164 ~754 minecraft:redstone_torch[lit=true] replace
setblock ~168 ~164 ~758 minecraft:redstone_torch[lit=true] replace
setblock ~132 ~164 ~762 minecraft:redstone_torch[lit=true] replace
setblock ~135 ~164 ~794 minecraft:redstone_torch[lit=true] replace
setblock ~138 ~164 ~826 minecraft:redstone_torch[lit=true] replace
setblock ~141 ~164 ~862 minecraft:redstone_torch[lit=true] replace
setblock ~144 ~164 ~890 minecraft:redstone_torch[lit=true] replace
setblock ~147 ~164 ~906 minecraft:redstone_torch[lit=true] replace
setblock ~150 ~164 ~930 minecraft:redstone_torch[lit=true] replace
setblock ~171 ~164 ~962 minecraft:redstone_torch[lit=true] replace
setblock ~174 ~164 ~966 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~110 ~165 ~230 ~120 ~165 ~230 minecraft:redstone_wire replace
setblock ~121 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~230 ~132 ~165 ~230 minecraft:redstone_wire replace
setblock ~133 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~230 ~144 ~165 ~230 minecraft:redstone_wire replace
setblock ~145 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~230 ~156 ~165 ~230 minecraft:redstone_wire replace
setblock ~157 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~230 ~168 ~165 ~230 minecraft:redstone_wire replace
setblock ~169 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~230 ~180 ~165 ~230 minecraft:redstone_wire replace
setblock ~181 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~230 ~192 ~165 ~230 minecraft:redstone_wire replace
setblock ~193 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~230 ~204 ~165 ~230 minecraft:redstone_wire replace
setblock ~205 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~230 ~216 ~165 ~230 minecraft:redstone_wire replace
setblock ~217 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~230 ~228 ~165 ~230 minecraft:redstone_wire replace
setblock ~229 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~230 ~240 ~165 ~230 minecraft:redstone_wire replace
setblock ~241 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~230 ~252 ~165 ~230 minecraft:redstone_wire replace
setblock ~253 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~230 ~264 ~165 ~230 minecraft:redstone_wire replace
setblock ~265 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~230 ~276 ~165 ~230 minecraft:redstone_wire replace
setblock ~277 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~230 ~288 ~165 ~230 minecraft:redstone_wire replace
setblock ~289 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~230 ~300 ~165 ~230 minecraft:redstone_wire replace
setblock ~301 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~230 ~312 ~165 ~230 minecraft:redstone_wire replace
setblock ~313 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~230 ~324 ~165 ~230 minecraft:redstone_wire replace
setblock ~325 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~230 ~336 ~165 ~230 minecraft:redstone_wire replace
setblock ~337 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~230 ~348 ~165 ~230 minecraft:redstone_wire replace
setblock ~349 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~230 ~360 ~165 ~230 minecraft:redstone_wire replace
setblock ~361 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~230 ~372 ~165 ~230 minecraft:redstone_wire replace
setblock ~373 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~230 ~384 ~165 ~230 minecraft:redstone_wire replace
setblock ~385 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~230 ~396 ~165 ~230 minecraft:redstone_wire replace
setblock ~397 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~230 ~408 ~165 ~230 minecraft:redstone_wire replace
setblock ~409 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~230 ~420 ~165 ~230 minecraft:redstone_wire replace
setblock ~421 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~230 ~432 ~165 ~230 minecraft:redstone_wire replace
setblock ~433 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~230 ~444 ~165 ~230 minecraft:redstone_wire replace
setblock ~445 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~230 ~456 ~165 ~230 minecraft:redstone_wire replace
setblock ~457 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~230 ~468 ~165 ~230 minecraft:redstone_wire replace
setblock ~469 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~230 ~480 ~165 ~230 minecraft:redstone_wire replace
setblock ~481 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~165 ~230 ~492 ~165 ~230 minecraft:redstone_wire replace
setblock ~493 ~165 ~230 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~165 ~230 ~495 ~165 ~230 minecraft:redstone_wire replace
setblock ~85 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~86 ~165 ~234 ~96 ~165 ~234 minecraft:redstone_wire replace
setblock ~97 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~98 ~165 ~234 ~108 ~165 ~234 minecraft:redstone_wire replace
setblock ~109 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~110 ~165 ~234 ~120 ~165 ~234 minecraft:redstone_wire replace
setblock ~121 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~122 ~165 ~234 ~132 ~165 ~234 minecraft:redstone_wire replace
setblock ~133 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~234 ~144 ~165 ~234 minecraft:redstone_wire replace
setblock ~145 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~234 ~156 ~165 ~234 minecraft:redstone_wire replace
setblock ~157 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~234 ~168 ~165 ~234 minecraft:redstone_wire replace
setblock ~169 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~234 ~180 ~165 ~234 minecraft:redstone_wire replace
setblock ~181 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~234 ~192 ~165 ~234 minecraft:redstone_wire replace
setblock ~193 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~234 ~204 ~165 ~234 minecraft:redstone_wire replace
setblock ~205 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~234 ~216 ~165 ~234 minecraft:redstone_wire replace
setblock ~217 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~234 ~228 ~165 ~234 minecraft:redstone_wire replace
setblock ~229 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~234 ~240 ~165 ~234 minecraft:redstone_wire replace
setblock ~241 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~234 ~252 ~165 ~234 minecraft:redstone_wire replace
setblock ~253 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~234 ~264 ~165 ~234 minecraft:redstone_wire replace
setblock ~265 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~234 ~276 ~165 ~234 minecraft:redstone_wire replace
setblock ~277 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~234 ~288 ~165 ~234 minecraft:redstone_wire replace
setblock ~289 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~234 ~300 ~165 ~234 minecraft:redstone_wire replace
setblock ~301 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~234 ~312 ~165 ~234 minecraft:redstone_wire replace
setblock ~313 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~234 ~324 ~165 ~234 minecraft:redstone_wire replace
setblock ~325 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~234 ~336 ~165 ~234 minecraft:redstone_wire replace
setblock ~337 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~234 ~348 ~165 ~234 minecraft:redstone_wire replace
setblock ~349 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~234 ~360 ~165 ~234 minecraft:redstone_wire replace
setblock ~361 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~234 ~372 ~165 ~234 minecraft:redstone_wire replace
setblock ~373 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~234 ~384 ~165 ~234 minecraft:redstone_wire replace
setblock ~385 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~234 ~396 ~165 ~234 minecraft:redstone_wire replace
setblock ~397 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~234 ~408 ~165 ~234 minecraft:redstone_wire replace
setblock ~409 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~234 ~420 ~165 ~234 minecraft:redstone_wire replace
setblock ~421 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~234 ~432 ~165 ~234 minecraft:redstone_wire replace
setblock ~433 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~234 ~444 ~165 ~234 minecraft:redstone_wire replace
setblock ~445 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~234 ~456 ~165 ~234 minecraft:redstone_wire replace
setblock ~457 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~234 ~468 ~165 ~234 minecraft:redstone_wire replace
setblock ~469 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~234 ~480 ~165 ~234 minecraft:redstone_wire replace
setblock ~481 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~482 ~165 ~234 ~492 ~165 ~234 minecraft:redstone_wire replace
setblock ~493 ~165 ~234 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~494 ~165 ~234 ~497 ~165 ~234 minecraft:redstone_wire replace
setblock ~106 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~107 ~165 ~262 ~117 ~165 ~262 minecraft:redstone_wire replace
setblock ~118 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~119 ~165 ~262 ~129 ~165 ~262 minecraft:redstone_wire replace
setblock ~130 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~262 ~141 ~165 ~262 minecraft:redstone_wire replace
setblock ~142 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~262 ~153 ~165 ~262 minecraft:redstone_wire replace
setblock ~154 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~262 ~165 ~165 ~262 minecraft:redstone_wire replace
setblock ~166 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~262 ~177 ~165 ~262 minecraft:redstone_wire replace
setblock ~178 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~262 ~189 ~165 ~262 minecraft:redstone_wire replace
setblock ~190 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~262 ~201 ~165 ~262 minecraft:redstone_wire replace
setblock ~202 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~262 ~213 ~165 ~262 minecraft:redstone_wire replace
setblock ~214 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~262 ~225 ~165 ~262 minecraft:redstone_wire replace
setblock ~226 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~262 ~237 ~165 ~262 minecraft:redstone_wire replace
setblock ~238 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~262 ~249 ~165 ~262 minecraft:redstone_wire replace
setblock ~250 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~262 ~261 ~165 ~262 minecraft:redstone_wire replace
setblock ~262 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~262 ~273 ~165 ~262 minecraft:redstone_wire replace
setblock ~274 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~262 ~285 ~165 ~262 minecraft:redstone_wire replace
setblock ~286 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~262 ~297 ~165 ~262 minecraft:redstone_wire replace
setblock ~298 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~262 ~309 ~165 ~262 minecraft:redstone_wire replace
setblock ~310 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~262 ~321 ~165 ~262 minecraft:redstone_wire replace
setblock ~322 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~262 ~333 ~165 ~262 minecraft:redstone_wire replace
setblock ~334 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~262 ~345 ~165 ~262 minecraft:redstone_wire replace
setblock ~346 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~262 ~357 ~165 ~262 minecraft:redstone_wire replace
setblock ~358 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~262 ~369 ~165 ~262 minecraft:redstone_wire replace
setblock ~370 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~262 ~381 ~165 ~262 minecraft:redstone_wire replace
setblock ~382 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~262 ~393 ~165 ~262 minecraft:redstone_wire replace
setblock ~394 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~262 ~405 ~165 ~262 minecraft:redstone_wire replace
setblock ~406 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~262 ~417 ~165 ~262 minecraft:redstone_wire replace
setblock ~418 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~262 ~429 ~165 ~262 minecraft:redstone_wire replace
setblock ~430 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~262 ~441 ~165 ~262 minecraft:redstone_wire replace
setblock ~442 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~262 ~453 ~165 ~262 minecraft:redstone_wire replace
setblock ~454 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~262 ~465 ~165 ~262 minecraft:redstone_wire replace
setblock ~466 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~262 ~477 ~165 ~262 minecraft:redstone_wire replace
setblock ~478 ~165 ~262 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~479 ~165 ~262 ~481 ~165 ~262 minecraft:redstone_wire replace
setblock ~103 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~104 ~165 ~286 ~114 ~165 ~286 minecraft:redstone_wire replace
setblock ~115 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~116 ~165 ~286 ~126 ~165 ~286 minecraft:redstone_wire replace
setblock ~127 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~286 ~138 ~165 ~286 minecraft:redstone_wire replace
setblock ~139 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~286 ~150 ~165 ~286 minecraft:redstone_wire replace
setblock ~151 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~286 ~162 ~165 ~286 minecraft:redstone_wire replace
setblock ~163 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~286 ~174 ~165 ~286 minecraft:redstone_wire replace
setblock ~175 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~286 ~186 ~165 ~286 minecraft:redstone_wire replace
setblock ~187 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~286 ~198 ~165 ~286 minecraft:redstone_wire replace
setblock ~199 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~286 ~210 ~165 ~286 minecraft:redstone_wire replace
setblock ~211 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~286 ~222 ~165 ~286 minecraft:redstone_wire replace
setblock ~223 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~286 ~234 ~165 ~286 minecraft:redstone_wire replace
setblock ~235 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~286 ~246 ~165 ~286 minecraft:redstone_wire replace
setblock ~247 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~286 ~258 ~165 ~286 minecraft:redstone_wire replace
setblock ~259 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~286 ~270 ~165 ~286 minecraft:redstone_wire replace
setblock ~271 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~286 ~282 ~165 ~286 minecraft:redstone_wire replace
setblock ~283 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~286 ~294 ~165 ~286 minecraft:redstone_wire replace
setblock ~295 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~286 ~306 ~165 ~286 minecraft:redstone_wire replace
setblock ~307 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~286 ~318 ~165 ~286 minecraft:redstone_wire replace
setblock ~319 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~286 ~330 ~165 ~286 minecraft:redstone_wire replace
setblock ~331 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~286 ~342 ~165 ~286 minecraft:redstone_wire replace
setblock ~343 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~286 ~354 ~165 ~286 minecraft:redstone_wire replace
setblock ~355 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~286 ~366 ~165 ~286 minecraft:redstone_wire replace
setblock ~367 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~286 ~378 ~165 ~286 minecraft:redstone_wire replace
setblock ~379 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~286 ~390 ~165 ~286 minecraft:redstone_wire replace
setblock ~391 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~286 ~402 ~165 ~286 minecraft:redstone_wire replace
setblock ~403 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~286 ~414 ~165 ~286 minecraft:redstone_wire replace
setblock ~415 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~286 ~426 ~165 ~286 minecraft:redstone_wire replace
setblock ~427 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~286 ~438 ~165 ~286 minecraft:redstone_wire replace
setblock ~439 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~286 ~450 ~165 ~286 minecraft:redstone_wire replace
setblock ~451 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~286 ~462 ~165 ~286 minecraft:redstone_wire replace
setblock ~463 ~165 ~286 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
