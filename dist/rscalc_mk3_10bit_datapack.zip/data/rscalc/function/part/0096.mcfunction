setblock ~156 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~592 ~84 ~151 ~604 minecraft:redstone_wire replace
fill ~87 ~151 ~592 ~87 ~151 ~604 minecraft:redstone_wire replace
fill ~90 ~151 ~592 ~90 ~151 ~604 minecraft:redstone_wire replace
fill ~93 ~151 ~592 ~93 ~151 ~604 minecraft:redstone_wire replace
fill ~96 ~151 ~592 ~96 ~151 ~604 minecraft:redstone_wire replace
fill ~99 ~151 ~592 ~99 ~151 ~604 minecraft:redstone_wire replace
fill ~102 ~151 ~592 ~102 ~151 ~604 minecraft:redstone_wire replace
fill ~105 ~151 ~592 ~105 ~151 ~604 minecraft:redstone_wire replace
fill ~108 ~151 ~592 ~108 ~151 ~604 minecraft:redstone_wire replace
fill ~111 ~151 ~592 ~111 ~151 ~604 minecraft:redstone_wire replace
fill ~114 ~151 ~592 ~114 ~151 ~604 minecraft:redstone_wire replace
fill ~117 ~151 ~592 ~117 ~151 ~604 minecraft:redstone_wire replace
fill ~120 ~151 ~592 ~120 ~151 ~604 minecraft:redstone_wire replace
fill ~123 ~151 ~592 ~123 ~151 ~604 minecraft:redstone_wire replace
fill ~126 ~151 ~592 ~126 ~151 ~604 minecraft:redstone_wire replace
fill ~129 ~151 ~592 ~129 ~151 ~604 minecraft:redstone_wire replace
fill ~132 ~151 ~592 ~132 ~151 ~604 minecraft:redstone_wire replace
fill ~135 ~151 ~592 ~135 ~151 ~604 minecraft:redstone_wire replace
fill ~138 ~151 ~592 ~138 ~151 ~604 minecraft:redstone_wire replace
fill ~141 ~151 ~592 ~141 ~151 ~604 minecraft:redstone_wire replace
fill ~144 ~151 ~592 ~144 ~151 ~604 minecraft:redstone_wire replace
fill ~147 ~151 ~592 ~147 ~151 ~604 minecraft:redstone_wire replace
fill ~150 ~151 ~592 ~150 ~151 ~604 minecraft:redstone_wire replace
fill ~153 ~151 ~592 ~153 ~151 ~604 minecraft:redstone_wire replace
fill ~156 ~151 ~592 ~156 ~151 ~604 minecraft:redstone_wire replace
fill ~159 ~151 ~592 ~159 ~151 ~604 minecraft:redstone_wire replace
fill ~162 ~151 ~592 ~162 ~151 ~604 minecraft:redstone_wire replace
fill ~165 ~151 ~592 ~165 ~151 ~604 minecraft:redstone_wire replace
fill ~168 ~151 ~592 ~168 ~151 ~604 minecraft:redstone_wire replace
fill ~171 ~151 ~592 ~171 ~151 ~604 minecraft:redstone_wire replace
fill ~174 ~151 ~592 ~174 ~151 ~604 minecraft:redstone_wire replace
fill ~177 ~151 ~592 ~177 ~151 ~604 minecraft:redstone_wire replace
fill ~180 ~151 ~592 ~180 ~151 ~604 minecraft:redstone_wire replace
fill ~183 ~151 ~592 ~183 ~151 ~604 minecraft:redstone_wire replace
fill ~186 ~151 ~592 ~186 ~151 ~604 minecraft:redstone_wire replace
fill ~189 ~151 ~592 ~189 ~151 ~604 minecraft:redstone_wire replace
fill ~192 ~151 ~592 ~192 ~151 ~604 minecraft:redstone_wire replace
fill ~195 ~151 ~592 ~195 ~151 ~604 minecraft:redstone_wire replace
fill ~198 ~151 ~592 ~198 ~151 ~604 minecraft:redstone_wire replace
fill ~201 ~151 ~592 ~201 ~151 ~604 minecraft:redstone_wire replace
fill ~204 ~151 ~592 ~204 ~151 ~604 minecraft:redstone_wire replace
fill ~207 ~151 ~592 ~207 ~151 ~604 minecraft:redstone_wire replace
fill ~210 ~151 ~592 ~210 ~151 ~604 minecraft:redstone_wire replace
fill ~213 ~151 ~592 ~213 ~151 ~604 minecraft:redstone_wire replace
fill ~216 ~151 ~592 ~216 ~151 ~604 minecraft:redstone_wire replace
fill ~219 ~151 ~592 ~219 ~151 ~604 minecraft:redstone_wire replace
fill ~222 ~151 ~592 ~222 ~151 ~604 minecraft:redstone_wire replace
fill ~225 ~151 ~592 ~225 ~151 ~604 minecraft:redstone_wire replace
fill ~228 ~151 ~592 ~228 ~151 ~604 minecraft:redstone_wire replace
setblock ~246 ~151 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~600 ~246 ~151 ~612 minecraft:redstone_wire replace
fill ~255 ~151 ~600 ~255 ~151 ~612 minecraft:redstone_wire replace
setblock ~267 ~151 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~151 ~602 ~267 ~151 ~608 minecraft:redstone_wire replace
fill ~264 ~151 ~604 ~264 ~151 ~608 minecraft:redstone_wire replace
setblock ~84 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~608 ~84 ~151 ~620 minecraft:redstone_wire replace
fill ~87 ~151 ~608 ~87 ~151 ~620 minecraft:redstone_wire replace
fill ~90 ~151 ~608 ~90 ~151 ~620 minecraft:redstone_wire replace
fill ~93 ~151 ~608 ~93 ~151 ~620 minecraft:redstone_wire replace
fill ~96 ~151 ~608 ~96 ~151 ~620 minecraft:redstone_wire replace
fill ~99 ~151 ~608 ~99 ~151 ~620 minecraft:redstone_wire replace
fill ~102 ~151 ~608 ~102 ~151 ~620 minecraft:redstone_wire replace
fill ~105 ~151 ~608 ~105 ~151 ~620 minecraft:redstone_wire replace
fill ~108 ~151 ~608 ~108 ~151 ~620 minecraft:redstone_wire replace
fill ~111 ~151 ~608 ~111 ~151 ~620 minecraft:redstone_wire replace
fill ~114 ~151 ~608 ~114 ~151 ~620 minecraft:redstone_wire replace
fill ~117 ~151 ~608 ~117 ~151 ~620 minecraft:redstone_wire replace
fill ~120 ~151 ~608 ~120 ~151 ~620 minecraft:redstone_wire replace
fill ~123 ~151 ~608 ~123 ~151 ~620 minecraft:redstone_wire replace
fill ~126 ~151 ~608 ~126 ~151 ~620 minecraft:redstone_wire replace
fill ~129 ~151 ~608 ~129 ~151 ~620 minecraft:redstone_wire replace
fill ~132 ~151 ~608 ~132 ~151 ~620 minecraft:redstone_wire replace
fill ~135 ~151 ~608 ~135 ~151 ~620 minecraft:redstone_wire replace
fill ~138 ~151 ~608 ~138 ~151 ~620 minecraft:redstone_wire replace
fill ~141 ~151 ~608 ~141 ~151 ~620 minecraft:redstone_wire replace
fill ~144 ~151 ~608 ~144 ~151 ~620 minecraft:redstone_wire replace
fill ~147 ~151 ~608 ~147 ~151 ~620 minecraft:redstone_wire replace
fill ~150 ~151 ~608 ~150 ~151 ~620 minecraft:redstone_wire replace
fill ~153 ~151 ~608 ~153 ~151 ~620 minecraft:redstone_wire replace
fill ~156 ~151 ~608 ~156 ~151 ~620 minecraft:redstone_wire replace
fill ~159 ~151 ~608 ~159 ~151 ~620 minecraft:redstone_wire replace
fill ~162 ~151 ~608 ~162 ~151 ~620 minecraft:redstone_wire replace
fill ~165 ~151 ~608 ~165 ~151 ~620 minecraft:redstone_wire replace
fill ~168 ~151 ~608 ~168 ~151 ~620 minecraft:redstone_wire replace
fill ~171 ~151 ~608 ~171 ~151 ~620 minecraft:redstone_wire replace
fill ~174 ~151 ~608 ~174 ~151 ~620 minecraft:redstone_wire replace
fill ~177 ~151 ~608 ~177 ~151 ~620 minecraft:redstone_wire replace
fill ~180 ~151 ~608 ~180 ~151 ~620 minecraft:redstone_wire replace
fill ~183 ~151 ~608 ~183 ~151 ~620 minecraft:redstone_wire replace
fill ~186 ~151 ~608 ~186 ~151 ~620 minecraft:redstone_wire replace
fill ~189 ~151 ~608 ~189 ~151 ~620 minecraft:redstone_wire replace
fill ~192 ~151 ~608 ~192 ~151 ~620 minecraft:redstone_wire replace
fill ~195 ~151 ~608 ~195 ~151 ~620 minecraft:redstone_wire replace
fill ~198 ~151 ~608 ~198 ~151 ~620 minecraft:redstone_wire replace
fill ~201 ~151 ~608 ~201 ~151 ~620 minecraft:redstone_wire replace
fill ~204 ~151 ~608 ~204 ~151 ~620 minecraft:redstone_wire replace
fill ~207 ~151 ~608 ~207 ~151 ~620 minecraft:redstone_wire replace
fill ~210 ~151 ~608 ~210 ~151 ~620 minecraft:redstone_wire replace
fill ~213 ~151 ~608 ~213 ~151 ~620 minecraft:redstone_wire replace
fill ~216 ~151 ~608 ~216 ~151 ~620 minecraft:redstone_wire replace
fill ~219 ~151 ~608 ~219 ~151 ~620 minecraft:redstone_wire replace
fill ~222 ~151 ~608 ~222 ~151 ~620 minecraft:redstone_wire replace
fill ~225 ~151 ~608 ~225 ~151 ~620 minecraft:redstone_wire replace
fill ~228 ~151 ~608 ~228 ~151 ~620 minecraft:redstone_wire replace
fill ~261 ~151 ~608 ~261 ~151 ~612 minecraft:redstone_wire replace
setblock ~84 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~624 ~84 ~151 ~636 minecraft:redstone_wire replace
fill ~87 ~151 ~624 ~87 ~151 ~636 minecraft:redstone_wire replace
fill ~90 ~151 ~624 ~90 ~151 ~636 minecraft:redstone_wire replace
fill ~93 ~151 ~624 ~93 ~151 ~636 minecraft:redstone_wire replace
fill ~96 ~151 ~624 ~96 ~151 ~636 minecraft:redstone_wire replace
fill ~99 ~151 ~624 ~99 ~151 ~636 minecraft:redstone_wire replace
fill ~102 ~151 ~624 ~102 ~151 ~636 minecraft:redstone_wire replace
fill ~105 ~151 ~624 ~105 ~151 ~636 minecraft:redstone_wire replace
fill ~108 ~151 ~624 ~108 ~151 ~636 minecraft:redstone_wire replace
fill ~111 ~151 ~624 ~111 ~151 ~636 minecraft:redstone_wire replace
fill ~114 ~151 ~624 ~114 ~151 ~636 minecraft:redstone_wire replace
fill ~117 ~151 ~624 ~117 ~151 ~636 minecraft:redstone_wire replace
fill ~120 ~151 ~624 ~120 ~151 ~636 minecraft:redstone_wire replace
fill ~123 ~151 ~624 ~123 ~151 ~636 minecraft:redstone_wire replace
fill ~126 ~151 ~624 ~126 ~151 ~636 minecraft:redstone_wire replace
fill ~129 ~151 ~624 ~129 ~151 ~636 minecraft:redstone_wire replace
fill ~132 ~151 ~624 ~132 ~151 ~636 minecraft:redstone_wire replace
fill ~135 ~151 ~624 ~135 ~151 ~636 minecraft:redstone_wire replace
fill ~138 ~151 ~624 ~138 ~151 ~636 minecraft:redstone_wire replace
fill ~141 ~151 ~624 ~141 ~151 ~636 minecraft:redstone_wire replace
fill ~144 ~151 ~624 ~144 ~151 ~636 minecraft:redstone_wire replace
fill ~147 ~151 ~624 ~147 ~151 ~636 minecraft:redstone_wire replace
fill ~150 ~151 ~624 ~150 ~151 ~636 minecraft:redstone_wire replace
fill ~153 ~151 ~624 ~153 ~151 ~636 minecraft:redstone_wire replace
fill ~156 ~151 ~624 ~156 ~151 ~636 minecraft:redstone_wire replace
fill ~159 ~151 ~624 ~159 ~151 ~636 minecraft:redstone_wire replace
fill ~162 ~151 ~624 ~162 ~151 ~636 minecraft:redstone_wire replace
fill ~165 ~151 ~624 ~165 ~151 ~636 minecraft:redstone_wire replace
fill ~168 ~151 ~624 ~168 ~151 ~636 minecraft:redstone_wire replace
fill ~171 ~151 ~624 ~171 ~151 ~636 minecraft:redstone_wire replace
fill ~174 ~151 ~624 ~174 ~151 ~636 minecraft:redstone_wire replace
fill ~177 ~151 ~624 ~177 ~151 ~636 minecraft:redstone_wire replace
fill ~180 ~151 ~624 ~180 ~151 ~636 minecraft:redstone_wire replace
fill ~183 ~151 ~624 ~183 ~151 ~636 minecraft:redstone_wire replace
fill ~186 ~151 ~624 ~186 ~151 ~636 minecraft:redstone_wire replace
fill ~189 ~151 ~624 ~189 ~151 ~636 minecraft:redstone_wire replace
fill ~192 ~151 ~624 ~192 ~151 ~636 minecraft:redstone_wire replace
fill ~195 ~151 ~624 ~195 ~151 ~636 minecraft:redstone_wire replace
fill ~198 ~151 ~624 ~198 ~151 ~636 minecraft:redstone_wire replace
fill ~201 ~151 ~624 ~201 ~151 ~636 minecraft:redstone_wire replace
fill ~204 ~151 ~624 ~204 ~151 ~636 minecraft:redstone_wire replace
fill ~207 ~151 ~624 ~207 ~151 ~636 minecraft:redstone_wire replace
fill ~210 ~151 ~624 ~210 ~151 ~636 minecraft:redstone_wire replace
fill ~213 ~151 ~624 ~213 ~151 ~636 minecraft:redstone_wire replace
fill ~216 ~151 ~624 ~216 ~151 ~636 minecraft:redstone_wire replace
fill ~219 ~151 ~624 ~219 ~151 ~636 minecraft:redstone_wire replace
fill ~222 ~151 ~624 ~222 ~151 ~636 minecraft:redstone_wire replace
fill ~225 ~151 ~624 ~225 ~151 ~636 minecraft:redstone_wire replace
fill ~228 ~151 ~624 ~228 ~151 ~636 minecraft:redstone_wire replace
setblock ~84 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~638 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~640 ~84 ~151 ~652 minecraft:redstone_wire replace
fill ~87 ~151 ~640 ~87 ~151 ~652 minecraft:redstone_wire replace
fill ~90 ~151 ~640 ~90 ~151 ~652 minecraft:redstone_wire replace
fill ~93 ~151 ~640 ~93 ~151 ~652 minecraft:redstone_wire replace
fill ~96 ~151 ~640 ~96 ~151 ~652 minecraft:redstone_wire replace
fill ~99 ~151 ~640 ~99 ~151 ~652 minecraft:redstone_wire replace
fill ~102 ~151 ~640 ~102 ~151 ~652 minecraft:redstone_wire replace
fill ~105 ~151 ~640 ~105 ~151 ~652 minecraft:redstone_wire replace
fill ~108 ~151 ~640 ~108 ~151 ~652 minecraft:redstone_wire replace
fill ~111 ~151 ~640 ~111 ~151 ~652 minecraft:redstone_wire replace
fill ~114 ~151 ~640 ~114 ~151 ~652 minecraft:redstone_wire replace
fill ~117 ~151 ~640 ~117 ~151 ~652 minecraft:redstone_wire replace
fill ~120 ~151 ~640 ~120 ~151 ~652 minecraft:redstone_wire replace
fill ~123 ~151 ~640 ~123 ~151 ~652 minecraft:redstone_wire replace
fill ~126 ~151 ~640 ~126 ~151 ~652 minecraft:redstone_wire replace
fill ~129 ~151 ~640 ~129 ~151 ~652 minecraft:redstone_wire replace
fill ~132 ~151 ~640 ~132 ~151 ~652 minecraft:redstone_wire replace
fill ~135 ~151 ~640 ~135 ~151 ~652 minecraft:redstone_wire replace
fill ~138 ~151 ~640 ~138 ~151 ~652 minecraft:redstone_wire replace
fill ~141 ~151 ~640 ~141 ~151 ~652 minecraft:redstone_wire replace
fill ~144 ~151 ~640 ~144 ~151 ~652 minecraft:redstone_wire replace
fill ~147 ~151 ~640 ~147 ~151 ~652 minecraft:redstone_wire replace
fill ~150 ~151 ~640 ~150 ~151 ~652 minecraft:redstone_wire replace
fill ~153 ~151 ~640 ~153 ~151 ~652 minecraft:redstone_wire replace
fill ~156 ~151 ~640 ~156 ~151 ~652 minecraft:redstone_wire replace
fill ~159 ~151 ~640 ~159 ~151 ~652 minecraft:redstone_wire replace
fill ~162 ~151 ~640 ~162 ~151 ~652 minecraft:redstone_wire replace
fill ~165 ~151 ~640 ~165 ~151 ~652 minecraft:redstone_wire replace
fill ~168 ~151 ~640 ~168 ~151 ~652 minecraft:redstone_wire replace
fill ~171 ~151 ~640 ~171 ~151 ~652 minecraft:redstone_wire replace
fill ~174 ~151 ~640 ~174 ~151 ~652 minecraft:redstone_wire replace
fill ~177 ~151 ~640 ~177 ~151 ~652 minecraft:redstone_wire replace
fill ~180 ~151 ~640 ~180 ~151 ~652 minecraft:redstone_wire replace
fill ~183 ~151 ~640 ~183 ~151 ~652 minecraft:redstone_wire replace
fill ~186 ~151 ~640 ~186 ~151 ~652 minecraft:redstone_wire replace
fill ~189 ~151 ~640 ~189 ~151 ~652 minecraft:redstone_wire replace
fill ~192 ~151 ~640 ~192 ~151 ~652 minecraft:redstone_wire replace
fill ~195 ~151 ~640 ~195 ~151 ~652 minecraft:redstone_wire replace
fill ~198 ~151 ~640 ~198 ~151 ~652 minecraft:redstone_wire replace
fill ~201 ~151 ~640 ~201 ~151 ~652 minecraft:redstone_wire replace
fill ~204 ~151 ~640 ~204 ~151 ~652 minecraft:redstone_wire replace
fill ~207 ~151 ~640 ~207 ~151 ~652 minecraft:redstone_wire replace
fill ~210 ~151 ~640 ~210 ~151 ~652 minecraft:redstone_wire replace
fill ~213 ~151 ~640 ~213 ~151 ~652 minecraft:redstone_wire replace
fill ~216 ~151 ~640 ~216 ~151 ~652 minecraft:redstone_wire replace
fill ~219 ~151 ~640 ~219 ~151 ~652 minecraft:redstone_wire replace
fill ~222 ~151 ~640 ~222 ~151 ~652 minecraft:redstone_wire replace
fill ~225 ~151 ~640 ~225 ~151 ~652 minecraft:redstone_wire replace
fill ~228 ~151 ~640 ~228 ~151 ~652 minecraft:redstone_wire replace
fill ~276 ~151 ~644 ~276 ~151 ~648 minecraft:redstone_wire replace
fill ~270 ~151 ~652 ~270 ~151 ~656 minecraft:redstone_wire replace
fill ~273 ~151 ~660 ~273 ~151 ~664 minecraft:redstone_wire replace
setblock ~231 ~152 ~231 minecraft:redstone_wire replace
setblock ~81 ~152 ~235 minecraft:redstone_wire replace
setblock ~228 ~152 ~239 minecraft:redstone_wire replace
setblock ~225 ~152 ~243 minecraft:redstone_wire replace
setblock ~222 ~152 ~247 minecraft:redstone_wire replace
setblock ~219 ~152 ~251 minecraft:redstone_wire replace
setblock ~216 ~152 ~255 minecraft:redstone_wire replace
setblock ~213 ~152 ~259 minecraft:redstone_wire replace
setblock ~210 ~152 ~263 minecraft:redstone_wire replace
setblock ~207 ~152 ~267 minecraft:redstone_wire replace
setblock ~204 ~152 ~271 minecraft:redstone_wire replace
setblock ~201 ~152 ~275 minecraft:redstone_wire replace
setblock ~198 ~152 ~279 minecraft:redstone_wire replace
setblock ~195 ~152 ~283 minecraft:redstone_wire replace
setblock ~192 ~152 ~287 minecraft:redstone_wire replace
setblock ~189 ~152 ~291 minecraft:redstone_wire replace
setblock ~186 ~152 ~295 minecraft:redstone_wire replace
setblock ~183 ~152 ~299 minecraft:redstone_wire replace
setblock ~180 ~152 ~303 minecraft:redstone_wire replace
setblock ~177 ~152 ~307 minecraft:redstone_wire replace
setblock ~174 ~152 ~311 minecraft:redstone_wire replace
setblock ~171 ~152 ~315 minecraft:redstone_wire replace
setblock ~168 ~152 ~319 minecraft:redstone_wire replace
setblock ~165 ~152 ~323 minecraft:redstone_wire replace
setblock ~162 ~152 ~327 minecraft:redstone_wire replace
setblock ~159 ~152 ~331 minecraft:redstone_wire replace
setblock ~156 ~152 ~335 minecraft:redstone_wire replace
setblock ~153 ~152 ~339 minecraft:redstone_wire replace
setblock ~150 ~152 ~343 minecraft:redstone_wire replace
setblock ~147 ~152 ~347 minecraft:redstone_wire replace
setblock ~144 ~152 ~351 minecraft:redstone_wire replace
setblock ~141 ~152 ~355 minecraft:redstone_wire replace
setblock ~138 ~152 ~359 minecraft:redstone_wire replace
setblock ~135 ~152 ~363 minecraft:redstone_wire replace
setblock ~132 ~152 ~367 minecraft:redstone_wire replace
setblock ~129 ~152 ~371 minecraft:redstone_wire replace
setblock ~126 ~152 ~375 minecraft:redstone_wire replace
setblock ~123 ~152 ~379 minecraft:redstone_wire replace
setblock ~120 ~152 ~383 minecraft:redstone_wire replace
setblock ~117 ~152 ~387 minecraft:redstone_wire replace
setblock ~114 ~152 ~391 minecraft:redstone_wire replace
setblock ~111 ~152 ~395 minecraft:redstone_wire replace
setblock ~108 ~152 ~399 minecraft:redstone_wire replace
setblock ~105 ~152 ~403 minecraft:redstone_wire replace
setblock ~102 ~152 ~407 minecraft:redstone_wire replace
setblock ~99 ~152 ~411 minecraft:redstone_wire replace
setblock ~96 ~152 ~415 minecraft:redstone_wire replace
setblock ~93 ~152 ~419 minecraft:redstone_wire replace
setblock ~90 ~152 ~423 minecraft:redstone_wire replace
setblock ~87 ~152 ~427 minecraft:redstone_wire replace
setblock ~84 ~152 ~431 minecraft:redstone_wire replace
setblock ~78 ~152 ~447 minecraft:redstone_wire replace
setblock ~246 ~152 ~475 minecraft:redstone_wire replace
setblock ~234 ~152 ~479 minecraft:redstone_wire replace
setblock ~240 ~152 ~499 minecraft:redstone_wire replace
setblock ~237 ~152 ~511 minecraft:redstone_wire replace
setblock ~243 ~152 ~535 minecraft:redstone_wire replace
setblock ~255 ~152 ~539 minecraft:redstone_wire replace
setblock ~249 ~152 ~543 minecraft:redstone_wire replace
setblock ~258 ~152 ~567 minecraft:redstone_wire replace
setblock ~252 ~152 ~575 minecraft:redstone_wire replace
setblock ~267 ~152 ~599 minecraft:redstone_wire replace
setblock ~264 ~152 ~603 minecraft:redstone_wire replace
setblock ~261 ~152 ~607 minecraft:redstone_wire replace
setblock ~276 ~152 ~643 minecraft:redstone_wire replace
setblock ~270 ~152 ~651 minecraft:redstone_wire replace
setblock ~273 ~152 ~659 minecraft:redstone_wire replace
setblock ~106 ~153 ~229 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~153 ~230 ~113 ~153 ~230 minecraft:redstone_wire replace
setblock ~115 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~153 ~230 ~130 ~153 ~230 minecraft:redstone_wire replace
setblock ~132 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~153 ~230 ~147 ~153 ~230 minecraft:redstone_wire replace
setblock ~149 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~153 ~230 ~164 ~153 ~230 minecraft:redstone_wire replace
setblock ~166 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~153 ~230 ~181 ~153 ~230 minecraft:redstone_wire replace
setblock ~183 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~153 ~230 ~198 ~153 ~230 minecraft:redstone_wire replace
setblock ~200 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~153 ~230 ~215 ~153 ~230 minecraft:redstone_wire replace
setblock ~217 ~153 ~230 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~153 ~230 ~231 ~153 ~230 minecraft:redstone_wire replace
setblock ~82 ~153 ~233 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~153 ~234 ~83 ~153 ~234 minecraft:redstone_wire replace
setblock ~103 ~153 ~237 minecraft:redstone_wire replace
fill ~102 ~153 ~238 ~111 ~153 ~238 minecraft:redstone_wire replace
setblock ~113 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~153 ~238 ~128 ~153 ~238 minecraft:redstone_wire replace
setblock ~130 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~153 ~238 ~145 ~153 ~238 minecraft:redstone_wire replace
setblock ~147 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~153 ~238 ~162 ~153 ~238 minecraft:redstone_wire replace
setblock ~164 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~153 ~238 ~179 ~153 ~238 minecraft:redstone_wire replace
setblock ~181 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~153 ~238 ~196 ~153 ~238 minecraft:redstone_wire replace
setblock ~198 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~153 ~238 ~213 ~153 ~238 minecraft:redstone_wire replace
setblock ~215 ~153 ~238 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~153 ~238 ~228 ~153 ~238 minecraft:redstone_wire replace
setblock ~103 ~153 ~241 minecraft:redstone_wire replace
fill ~102 ~153 ~242 ~107 ~153 ~242 minecraft:redstone_wire replace
setblock ~109 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~153 ~242 ~124 ~153 ~242 minecraft:redstone_wire replace
setblock ~126 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~153 ~242 ~141 ~153 ~242 minecraft:redstone_wire replace
setblock ~143 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~153 ~242 ~158 ~153 ~242 minecraft:redstone_wire replace
setblock ~160 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~153 ~242 ~175 ~153 ~242 minecraft:redstone_wire replace
setblock ~177 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~153 ~242 ~192 ~153 ~242 minecraft:redstone_wire replace
setblock ~194 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~153 ~242 ~209 ~153 ~242 minecraft:redstone_wire replace
setblock ~211 ~153 ~242 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~153 ~242 ~225 ~153 ~242 minecraft:redstone_wire replace
setblock ~103 ~153 ~245 minecraft:redstone_wire replace
fill ~102 ~153 ~246 ~111 ~153 ~246 minecraft:redstone_wire replace
setblock ~113 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~153 ~246 ~128 ~153 ~246 minecraft:redstone_wire replace
setblock ~130 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~153 ~246 ~145 ~153 ~246 minecraft:redstone_wire replace
setblock ~147 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~153 ~246 ~162 ~153 ~246 minecraft:redstone_wire replace
setblock ~164 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~153 ~246 ~179 ~153 ~246 minecraft:redstone_wire replace
setblock ~181 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~153 ~246 ~196 ~153 ~246 minecraft:redstone_wire replace
setblock ~198 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~153 ~246 ~213 ~153 ~246 minecraft:redstone_wire replace
setblock ~215 ~153 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~153 ~246 ~222 ~153 ~246 minecraft:redstone_wire replace
setblock ~103 ~153 ~249 minecraft:redstone_wire replace
fill ~102 ~153 ~250 ~104 ~153 ~250 minecraft:redstone_wire replace
setblock ~106 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~153 ~250 ~121 ~153 ~250 minecraft:redstone_wire replace
setblock ~123 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~153 ~250 ~138 ~153 ~250 minecraft:redstone_wire replace
setblock ~140 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~153 ~250 ~155 ~153 ~250 minecraft:redstone_wire replace
setblock ~157 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~250 ~172 ~153 ~250 minecraft:redstone_wire replace
setblock ~174 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~153 ~250 ~189 ~153 ~250 minecraft:redstone_wire replace
setblock ~191 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~153 ~250 ~206 ~153 ~250 minecraft:redstone_wire replace
setblock ~208 ~153 ~250 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~153 ~250 ~219 ~153 ~250 minecraft:redstone_wire replace
setblock ~103 ~153 ~253 minecraft:redstone_wire replace
setblock ~102 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~153 ~254 ~116 ~153 ~254 minecraft:redstone_wire replace
setblock ~118 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~153 ~254 ~133 ~153 ~254 minecraft:redstone_wire replace
setblock ~135 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~153 ~254 ~150 ~153 ~254 minecraft:redstone_wire replace
setblock ~152 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~153 ~254 ~167 ~153 ~254 minecraft:redstone_wire replace
setblock ~169 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~254 ~184 ~153 ~254 minecraft:redstone_wire replace
setblock ~186 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~153 ~254 ~201 ~153 ~254 minecraft:redstone_wire replace
setblock ~203 ~153 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~153 ~254 ~216 ~153 ~254 minecraft:redstone_wire replace
setblock ~103 ~153 ~257 minecraft:redstone_wire replace
fill ~102 ~153 ~258 ~112 ~153 ~258 minecraft:redstone_wire replace
setblock ~114 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~153 ~258 ~129 ~153 ~258 minecraft:redstone_wire replace
setblock ~131 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~153 ~258 ~146 ~153 ~258 minecraft:redstone_wire replace
setblock ~148 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~153 ~258 ~163 ~153 ~258 minecraft:redstone_wire replace
setblock ~165 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~153 ~258 ~180 ~153 ~258 minecraft:redstone_wire replace
setblock ~182 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~153 ~258 ~197 ~153 ~258 minecraft:redstone_wire replace
setblock ~199 ~153 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~153 ~258 ~213 ~153 ~258 minecraft:redstone_wire replace
setblock ~103 ~153 ~261 minecraft:redstone_wire replace
setblock ~102 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~153 ~262 ~116 ~153 ~262 minecraft:redstone_wire replace
setblock ~118 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~153 ~262 ~133 ~153 ~262 minecraft:redstone_wire replace
setblock ~135 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~153 ~262 ~150 ~153 ~262 minecraft:redstone_wire replace
setblock ~152 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~153 ~262 ~167 ~153 ~262 minecraft:redstone_wire replace
setblock ~169 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~153 ~262 ~184 ~153 ~262 minecraft:redstone_wire replace
setblock ~186 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~153 ~262 ~201 ~153 ~262 minecraft:redstone_wire replace
setblock ~203 ~153 ~262 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~153 ~262 ~210 ~153 ~262 minecraft:redstone_wire replace
setblock ~100 ~153 ~265 minecraft:redstone_wire replace
fill ~99 ~153 ~266 ~109 ~153 ~266 minecraft:redstone_wire replace
setblock ~111 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~153 ~266 ~126 ~153 ~266 minecraft:redstone_wire replace
setblock ~128 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~153 ~266 ~143 ~153 ~266 minecraft:redstone_wire replace
setblock ~145 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~153 ~266 ~160 ~153 ~266 minecraft:redstone_wire replace
setblock ~162 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~153 ~266 ~177 ~153 ~266 minecraft:redstone_wire replace
setblock ~179 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~153 ~266 ~194 ~153 ~266 minecraft:redstone_wire replace
setblock ~196 ~153 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~153 ~266 ~207 ~153 ~266 minecraft:redstone_wire replace
setblock ~100 ~153 ~269 minecraft:redstone_wire replace
fill ~99 ~153 ~270 ~104 ~153 ~270 minecraft:redstone_wire replace
setblock ~106 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~153 ~270 ~121 ~153 ~270 minecraft:redstone_wire replace
setblock ~123 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~153 ~270 ~138 ~153 ~270 minecraft:redstone_wire replace
setblock ~140 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~153 ~270 ~155 ~153 ~270 minecraft:redstone_wire replace
setblock ~157 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~153 ~270 ~172 ~153 ~270 minecraft:redstone_wire replace
setblock ~174 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~153 ~270 ~189 ~153 ~270 minecraft:redstone_wire replace
setblock ~191 ~153 ~270 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~153 ~270 ~204 ~153 ~270 minecraft:redstone_wire replace
