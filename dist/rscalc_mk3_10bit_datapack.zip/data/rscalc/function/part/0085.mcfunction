fill ~108 ~75 ~388 ~108 ~75 ~400 minecraft:redstone_wire replace
fill ~84 ~75 ~392 ~84 ~75 ~396 minecraft:redstone_wire replace
setblock ~108 ~75 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~404 ~108 ~75 ~416 minecraft:redstone_wire replace
setblock ~108 ~75 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~420 ~108 ~75 ~432 minecraft:redstone_wire replace
setblock ~108 ~75 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~436 ~108 ~75 ~448 minecraft:redstone_wire replace
setblock ~108 ~75 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~452 ~108 ~75 ~464 minecraft:redstone_wire replace
setblock ~108 ~75 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~468 ~108 ~75 ~480 minecraft:redstone_wire replace
setblock ~108 ~75 ~481 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~482 ~108 ~75 ~494 minecraft:redstone_wire replace
setblock ~108 ~75 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~498 ~108 ~75 ~510 minecraft:redstone_wire replace
setblock ~108 ~75 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~514 ~108 ~75 ~526 minecraft:redstone_wire replace
setblock ~108 ~75 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~530 ~108 ~75 ~542 minecraft:redstone_wire replace
setblock ~108 ~75 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~546 ~108 ~75 ~558 minecraft:redstone_wire replace
setblock ~108 ~75 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~560 ~108 ~75 ~572 minecraft:redstone_wire replace
setblock ~108 ~75 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~576 ~108 ~75 ~588 minecraft:redstone_wire replace
setblock ~108 ~75 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~592 ~108 ~75 ~604 minecraft:redstone_wire replace
fill ~87 ~75 ~600 ~87 ~75 ~604 minecraft:redstone_wire replace
fill ~90 ~75 ~604 ~90 ~75 ~608 minecraft:redstone_wire replace
setblock ~108 ~75 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~75 ~608 ~93 ~75 ~612 minecraft:redstone_wire replace
fill ~108 ~75 ~608 ~108 ~75 ~620 minecraft:redstone_wire replace
fill ~96 ~75 ~612 ~96 ~75 ~616 minecraft:redstone_wire replace
fill ~99 ~75 ~616 ~99 ~75 ~620 minecraft:redstone_wire replace
fill ~102 ~75 ~620 ~102 ~75 ~624 minecraft:redstone_wire replace
setblock ~108 ~75 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~624 ~108 ~75 ~636 minecraft:redstone_wire replace
fill ~111 ~75 ~624 ~111 ~75 ~628 minecraft:redstone_wire replace
fill ~78 ~75 ~628 ~78 ~75 ~632 minecraft:redstone_wire replace
fill ~105 ~75 ~632 ~105 ~75 ~636 minecraft:redstone_wire replace
setblock ~108 ~75 ~637 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~638 ~108 ~75 ~650 minecraft:redstone_wire replace
fill ~120 ~75 ~644 ~120 ~75 ~648 minecraft:redstone_wire replace
fill ~81 ~75 ~648 ~81 ~75 ~652 minecraft:redstone_wire replace
setblock ~108 ~75 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~652 ~108 ~75 ~656 minecraft:redstone_wire replace
fill ~117 ~75 ~656 ~117 ~75 ~660 minecraft:redstone_wire replace
setblock ~114 ~76 ~385 minecraft:redstone_wire replace
setblock ~84 ~76 ~397 minecraft:redstone_wire replace
setblock ~87 ~76 ~605 minecraft:redstone_wire replace
setblock ~90 ~76 ~609 minecraft:redstone_wire replace
setblock ~93 ~76 ~613 minecraft:redstone_wire replace
setblock ~96 ~76 ~617 minecraft:redstone_wire replace
setblock ~99 ~76 ~621 minecraft:redstone_wire replace
setblock ~102 ~76 ~625 minecraft:redstone_wire replace
setblock ~111 ~76 ~629 minecraft:redstone_wire replace
setblock ~78 ~76 ~633 minecraft:redstone_wire replace
setblock ~105 ~76 ~637 minecraft:redstone_wire replace
setblock ~120 ~76 ~649 minecraft:redstone_wire replace
setblock ~81 ~76 ~653 minecraft:redstone_wire replace
setblock ~108 ~76 ~657 minecraft:redstone_wire replace
setblock ~117 ~76 ~661 minecraft:redstone_wire replace
fill ~114 ~77 ~386 ~116 ~77 ~386 minecraft:redstone_wire replace
setblock ~115 ~77 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~77 ~398 ~84 ~77 ~398 minecraft:redstone_wire replace
setblock ~82 ~77 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~606 ~79 ~77 ~606 minecraft:redstone_wire replace
setblock ~80 ~77 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~81 ~77 ~606 ~89 ~77 ~606 minecraft:redstone_wire replace
setblock ~79 ~77 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~77 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~610 ~80 ~77 ~610 minecraft:redstone_wire replace
setblock ~82 ~77 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~84 ~77 ~610 ~92 ~77 ~610 minecraft:redstone_wire replace
setblock ~79 ~77 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~77 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~614 ~83 ~77 ~614 minecraft:redstone_wire replace
setblock ~85 ~77 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~87 ~77 ~614 ~95 ~77 ~614 minecraft:redstone_wire replace
setblock ~79 ~77 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~77 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~618 ~86 ~77 ~618 minecraft:redstone_wire replace
setblock ~88 ~77 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~77 ~618 ~98 ~77 ~618 minecraft:redstone_wire replace
setblock ~79 ~77 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~77 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~622 ~89 ~77 ~622 minecraft:redstone_wire replace
setblock ~91 ~77 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~77 ~622 ~101 ~77 ~622 minecraft:redstone_wire replace
setblock ~79 ~77 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~77 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~77 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~79 ~77 ~626 ~92 ~77 ~626 minecraft:redstone_wire replace
setblock ~94 ~77 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~96 ~77 ~626 ~104 ~77 ~626 minecraft:redstone_wire replace
setblock ~79 ~77 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~77 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~77 ~630 ~111 ~77 ~630 minecraft:redstone_wire replace
setblock ~109 ~77 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~634 ~80 ~77 ~634 minecraft:redstone_wire replace
setblock ~79 ~77 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~638 ~80 ~77 ~638 minecraft:redstone_wire replace
setblock ~81 ~77 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~82 ~77 ~638 ~95 ~77 ~638 minecraft:redstone_wire replace
setblock ~97 ~77 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~77 ~638 ~107 ~77 ~638 minecraft:redstone_wire replace
setblock ~79 ~77 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~77 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~77 ~650 ~125 ~77 ~650 minecraft:redstone_wire replace
setblock ~124 ~77 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~654 ~86 ~77 ~654 minecraft:redstone_wire replace
setblock ~79 ~77 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~85 ~77 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~658 ~81 ~77 ~658 minecraft:redstone_wire replace
setblock ~83 ~77 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~77 ~658 ~98 ~77 ~658 minecraft:redstone_wire replace
setblock ~100 ~77 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~77 ~658 ~114 ~77 ~658 minecraft:redstone_wire replace
setblock ~116 ~77 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~77 ~658 ~119 ~77 ~658 minecraft:redstone_wire replace
setblock ~79 ~77 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~77 ~659 minecraft:redstone_wire replace
setblock ~118 ~77 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~77 ~662 ~122 ~77 ~662 minecraft:redstone_wire replace
setblock ~121 ~77 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~78 ~388 minecraft:redstone_wire replace
setblock ~82 ~78 ~400 minecraft:redstone_wire replace
setblock ~79 ~78 ~608 minecraft:redstone_wire replace
setblock ~88 ~78 ~608 minecraft:redstone_wire replace
setblock ~79 ~78 ~612 minecraft:redstone_wire replace
setblock ~91 ~78 ~612 minecraft:redstone_wire replace
setblock ~79 ~78 ~616 minecraft:redstone_wire replace
setblock ~94 ~78 ~616 minecraft:redstone_wire replace
setblock ~79 ~78 ~620 minecraft:redstone_wire replace
setblock ~97 ~78 ~620 minecraft:redstone_wire replace
setblock ~79 ~78 ~624 minecraft:redstone_wire replace
setblock ~100 ~78 ~624 minecraft:redstone_wire replace
setblock ~79 ~78 ~628 minecraft:redstone_wire replace
setblock ~103 ~78 ~628 minecraft:redstone_wire replace
setblock ~109 ~78 ~632 minecraft:redstone_wire replace
setblock ~79 ~78 ~636 minecraft:redstone_wire replace
setblock ~79 ~78 ~640 minecraft:redstone_wire replace
setblock ~106 ~78 ~640 minecraft:redstone_wire replace
setblock ~124 ~78 ~652 minecraft:redstone_wire replace
setblock ~79 ~78 ~656 minecraft:redstone_wire replace
setblock ~85 ~78 ~656 minecraft:redstone_wire replace
setblock ~79 ~78 ~660 minecraft:redstone_wire replace
setblock ~112 ~78 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~78 ~660 minecraft:redstone_wire replace
setblock ~121 ~78 ~664 minecraft:redstone_wire replace
fill ~114 ~79 ~384 ~114 ~79 ~388 minecraft:redstone_wire replace
fill ~81 ~79 ~396 ~81 ~79 ~400 minecraft:redstone_wire replace
setblock ~87 ~79 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~79 ~602 ~87 ~79 ~608 minecraft:redstone_wire replace
setblock ~78 ~79 ~604 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~79 ~606 ~78 ~79 ~614 minecraft:redstone_wire replace
fill ~90 ~79 ~608 ~90 ~79 ~612 minecraft:redstone_wire replace
fill ~93 ~79 ~612 ~93 ~79 ~616 minecraft:redstone_wire replace
setblock ~78 ~79 ~615 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~79 ~616 ~78 ~79 ~628 minecraft:redstone_wire replace
fill ~96 ~79 ~616 ~96 ~79 ~620 minecraft:redstone_wire replace
fill ~99 ~79 ~620 ~99 ~79 ~624 minecraft:redstone_wire replace
fill ~102 ~79 ~624 ~102 ~79 ~628 minecraft:redstone_wire replace
fill ~108 ~79 ~628 ~108 ~79 ~632 minecraft:redstone_wire replace
setblock ~78 ~79 ~630 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~79 ~632 ~78 ~79 ~644 minecraft:redstone_wire replace
fill ~105 ~79 ~636 ~105 ~79 ~640 minecraft:redstone_wire replace
setblock ~123 ~79 ~644 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~79 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~79 ~646 ~123 ~79 ~652 minecraft:redstone_wire replace
fill ~78 ~79 ~648 ~78 ~79 ~660 minecraft:redstone_wire replace
setblock ~84 ~79 ~648 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~79 ~650 ~84 ~79 ~656 minecraft:redstone_wire replace
setblock ~117 ~79 ~652 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~79 ~654 ~117 ~79 ~660 minecraft:redstone_wire replace
fill ~111 ~79 ~656 ~111 ~79 ~660 minecraft:redstone_wire replace
fill ~120 ~79 ~660 ~120 ~79 ~664 minecraft:redstone_wire replace
setblock ~114 ~80 ~383 minecraft:redstone_wire replace
setblock ~81 ~80 ~395 minecraft:redstone_wire replace
setblock ~87 ~80 ~599 minecraft:redstone_wire replace
setblock ~78 ~80 ~603 minecraft:redstone_wire replace
setblock ~90 ~80 ~607 minecraft:redstone_wire replace
setblock ~93 ~80 ~611 minecraft:redstone_wire replace
setblock ~96 ~80 ~615 minecraft:redstone_wire replace
setblock ~99 ~80 ~619 minecraft:redstone_wire replace
setblock ~102 ~80 ~623 minecraft:redstone_wire replace
setblock ~108 ~80 ~627 minecraft:redstone_wire replace
setblock ~105 ~80 ~635 minecraft:redstone_wire replace
setblock ~123 ~80 ~643 minecraft:redstone_wire replace
setblock ~84 ~80 ~647 minecraft:redstone_wire replace
setblock ~117 ~80 ~651 minecraft:redstone_wire replace
setblock ~111 ~80 ~655 minecraft:redstone_wire replace
setblock ~120 ~80 ~659 minecraft:redstone_wire replace
setblock ~115 ~81 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~81 ~382 ~116 ~81 ~382 minecraft:redstone_wire replace
setblock ~82 ~81 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~81 ~394 ~83 ~81 ~394 minecraft:redstone_wire replace
setblock ~88 ~81 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~81 ~598 ~89 ~81 ~598 minecraft:redstone_wire replace
setblock ~79 ~81 ~601 minecraft:redstone_wire replace
fill ~78 ~81 ~602 ~80 ~81 ~602 minecraft:redstone_wire replace
setblock ~91 ~81 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~81 ~606 ~92 ~81 ~606 minecraft:redstone_wire replace
setblock ~94 ~81 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~81 ~610 ~95 ~81 ~610 minecraft:redstone_wire replace
setblock ~97 ~81 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~81 ~614 ~98 ~81 ~614 minecraft:redstone_wire replace
setblock ~100 ~81 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~81 ~618 ~101 ~81 ~618 minecraft:redstone_wire replace
setblock ~103 ~81 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~81 ~622 ~104 ~81 ~622 minecraft:redstone_wire replace
setblock ~109 ~81 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~81 ~626 ~110 ~81 ~626 minecraft:redstone_wire replace
setblock ~106 ~81 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~81 ~634 ~107 ~81 ~634 minecraft:redstone_wire replace
setblock ~124 ~81 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~81 ~642 ~125 ~81 ~642 minecraft:redstone_wire replace
setblock ~85 ~81 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~81 ~646 ~86 ~81 ~646 minecraft:redstone_wire replace
setblock ~118 ~81 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~81 ~650 ~119 ~81 ~650 minecraft:redstone_wire replace
setblock ~112 ~81 ~653 minecraft:redstone_wire replace
fill ~111 ~81 ~654 ~113 ~81 ~654 minecraft:redstone_wire replace
setblock ~121 ~81 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~81 ~658 ~122 ~81 ~658 minecraft:redstone_wire replace
setblock ~115 ~82 ~380 minecraft:redstone_wire replace
setblock ~82 ~82 ~392 minecraft:redstone_wire replace
setblock ~88 ~82 ~596 minecraft:redstone_wire replace
setblock ~79 ~82 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~82 ~604 minecraft:redstone_wire replace
setblock ~94 ~82 ~608 minecraft:redstone_wire replace
setblock ~97 ~82 ~612 minecraft:redstone_wire replace
setblock ~100 ~82 ~616 minecraft:redstone_wire replace
setblock ~103 ~82 ~620 minecraft:redstone_wire replace
setblock ~109 ~82 ~624 minecraft:redstone_wire replace
setblock ~106 ~82 ~632 minecraft:redstone_wire replace
setblock ~124 ~82 ~640 minecraft:redstone_wire replace
setblock ~85 ~82 ~644 minecraft:redstone_wire replace
setblock ~118 ~82 ~648 minecraft:redstone_wire replace
setblock ~112 ~82 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~82 ~656 minecraft:redstone_wire replace
fill ~114 ~83 ~380 ~114 ~83 ~384 minecraft:redstone_wire replace
fill ~81 ~83 ~392 ~81 ~83 ~396 minecraft:redstone_wire replace
fill ~87 ~83 ~596 ~87 ~83 ~600 minecraft:redstone_wire replace
fill ~78 ~83 ~600 ~78 ~83 ~604 minecraft:redstone_wire replace
fill ~90 ~83 ~604 ~90 ~83 ~608 minecraft:redstone_wire replace
fill ~93 ~83 ~608 ~93 ~83 ~612 minecraft:redstone_wire replace
fill ~96 ~83 ~612 ~96 ~83 ~616 minecraft:redstone_wire replace
fill ~99 ~83 ~616 ~99 ~83 ~620 minecraft:redstone_wire replace
fill ~102 ~83 ~620 ~102 ~83 ~624 minecraft:redstone_wire replace
fill ~108 ~83 ~624 ~108 ~83 ~628 minecraft:redstone_wire replace
fill ~105 ~83 ~632 ~105 ~83 ~636 minecraft:redstone_wire replace
fill ~123 ~83 ~640 ~123 ~83 ~644 minecraft:redstone_wire replace
fill ~84 ~83 ~644 ~84 ~83 ~648 minecraft:redstone_wire replace
fill ~117 ~83 ~648 ~117 ~83 ~652 minecraft:redstone_wire replace
fill ~111 ~83 ~652 ~111 ~83 ~656 minecraft:redstone_wire replace
fill ~120 ~83 ~656 ~120 ~83 ~660 minecraft:redstone_wire replace
setblock ~114 ~84 ~385 minecraft:redstone_wire replace
setblock ~81 ~84 ~397 minecraft:redstone_wire replace
setblock ~87 ~84 ~601 minecraft:redstone_wire replace
setblock ~78 ~84 ~605 minecraft:redstone_wire replace
setblock ~90 ~84 ~609 minecraft:redstone_wire replace
setblock ~93 ~84 ~613 minecraft:redstone_wire replace
setblock ~96 ~84 ~617 minecraft:redstone_wire replace
setblock ~99 ~84 ~621 minecraft:redstone_wire replace
setblock ~102 ~84 ~625 minecraft:redstone_wire replace
setblock ~108 ~84 ~629 minecraft:redstone_wire replace
setblock ~105 ~84 ~637 minecraft:redstone_wire replace
setblock ~123 ~84 ~645 minecraft:redstone_wire replace
setblock ~84 ~84 ~649 minecraft:redstone_wire replace
setblock ~117 ~84 ~653 minecraft:redstone_wire replace
setblock ~111 ~84 ~657 minecraft:redstone_wire replace
setblock ~120 ~84 ~661 minecraft:redstone_wire replace
fill ~114 ~85 ~386 ~116 ~85 ~386 minecraft:redstone_wire replace
setblock ~115 ~85 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~85 ~398 ~83 ~85 ~398 minecraft:redstone_wire replace
setblock ~82 ~85 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~85 ~602 ~89 ~85 ~602 minecraft:redstone_wire replace
setblock ~88 ~85 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~85 ~606 ~80 ~85 ~606 minecraft:redstone_wire replace
setblock ~79 ~85 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~85 ~610 ~92 ~85 ~610 minecraft:redstone_wire replace
setblock ~91 ~85 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~85 ~614 ~95 ~85 ~614 minecraft:redstone_wire replace
setblock ~94 ~85 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~85 ~618 ~98 ~85 ~618 minecraft:redstone_wire replace
setblock ~97 ~85 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~85 ~622 ~101 ~85 ~622 minecraft:redstone_wire replace
setblock ~100 ~85 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~85 ~626 ~104 ~85 ~626 minecraft:redstone_wire replace
setblock ~103 ~85 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~85 ~630 ~110 ~85 ~630 minecraft:redstone_wire replace
setblock ~109 ~85 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~85 ~638 ~107 ~85 ~638 minecraft:redstone_wire replace
setblock ~106 ~85 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~85 ~646 ~125 ~85 ~646 minecraft:redstone_wire replace
setblock ~124 ~85 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~85 ~650 ~86 ~85 ~650 minecraft:redstone_wire replace
setblock ~85 ~85 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~85 ~654 ~119 ~85 ~654 minecraft:redstone_wire replace
setblock ~118 ~85 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~85 ~658 ~113 ~85 ~658 minecraft:redstone_wire replace
setblock ~112 ~85 ~659 minecraft:redstone_wire replace
fill ~120 ~85 ~662 ~122 ~85 ~662 minecraft:redstone_wire replace
setblock ~121 ~85 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~86 ~388 minecraft:redstone_wire replace
setblock ~82 ~86 ~400 minecraft:redstone_wire replace
setblock ~88 ~86 ~604 minecraft:redstone_wire replace
setblock ~79 ~86 ~608 minecraft:redstone_wire replace
setblock ~91 ~86 ~612 minecraft:redstone_wire replace
setblock ~94 ~86 ~616 minecraft:redstone_wire replace
setblock ~97 ~86 ~620 minecraft:redstone_wire replace
setblock ~100 ~86 ~624 minecraft:redstone_wire replace
setblock ~103 ~86 ~628 minecraft:redstone_wire replace
setblock ~109 ~86 ~632 minecraft:redstone_wire replace
setblock ~106 ~86 ~640 minecraft:redstone_wire replace
setblock ~124 ~86 ~648 minecraft:redstone_wire replace
setblock ~85 ~86 ~652 minecraft:redstone_wire replace
setblock ~118 ~86 ~656 minecraft:redstone_wire replace
setblock ~112 ~86 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~86 ~664 minecraft:redstone_wire replace
fill ~114 ~87 ~384 ~114 ~87 ~388 minecraft:redstone_wire replace
fill ~81 ~87 ~396 ~81 ~87 ~400 minecraft:redstone_wire replace
fill ~87 ~87 ~600 ~87 ~87 ~604 minecraft:redstone_wire replace
fill ~78 ~87 ~604 ~78 ~87 ~608 minecraft:redstone_wire replace
fill ~90 ~87 ~608 ~90 ~87 ~612 minecraft:redstone_wire replace
fill ~93 ~87 ~612 ~93 ~87 ~616 minecraft:redstone_wire replace
fill ~96 ~87 ~616 ~96 ~87 ~620 minecraft:redstone_wire replace
fill ~99 ~87 ~620 ~99 ~87 ~624 minecraft:redstone_wire replace
fill ~102 ~87 ~624 ~102 ~87 ~628 minecraft:redstone_wire replace
fill ~108 ~87 ~628 ~108 ~87 ~632 minecraft:redstone_wire replace
fill ~105 ~87 ~636 ~105 ~87 ~640 minecraft:redstone_wire replace
fill ~123 ~87 ~644 ~123 ~87 ~648 minecraft:redstone_wire replace
fill ~84 ~87 ~648 ~84 ~87 ~652 minecraft:redstone_wire replace
fill ~117 ~87 ~652 ~117 ~87 ~656 minecraft:redstone_wire replace
fill ~111 ~87 ~656 ~111 ~87 ~660 minecraft:redstone_wire replace
fill ~120 ~87 ~660 ~120 ~87 ~664 minecraft:redstone_wire replace
setblock ~114 ~88 ~383 minecraft:redstone_wire replace
setblock ~81 ~88 ~395 minecraft:redstone_wire replace
setblock ~87 ~88 ~599 minecraft:redstone_wire replace
setblock ~78 ~88 ~603 minecraft:redstone_wire replace
setblock ~90 ~88 ~607 minecraft:redstone_wire replace
setblock ~93 ~88 ~611 minecraft:redstone_wire replace
setblock ~96 ~88 ~615 minecraft:redstone_wire replace
setblock ~99 ~88 ~619 minecraft:redstone_wire replace
setblock ~102 ~88 ~623 minecraft:redstone_wire replace
setblock ~108 ~88 ~627 minecraft:redstone_wire replace
setblock ~105 ~88 ~635 minecraft:redstone_wire replace
setblock ~123 ~88 ~643 minecraft:redstone_wire replace
setblock ~84 ~88 ~647 minecraft:redstone_wire replace
setblock ~117 ~88 ~651 minecraft:redstone_wire replace
setblock ~111 ~88 ~655 minecraft:redstone_wire replace
setblock ~120 ~88 ~659 minecraft:redstone_wire replace
setblock ~115 ~89 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~89 ~382 ~116 ~89 ~382 minecraft:redstone_wire replace
setblock ~82 ~89 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~89 ~394 ~83 ~89 ~394 minecraft:redstone_wire replace
setblock ~88 ~89 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~89 ~598 ~89 ~89 ~598 minecraft:redstone_wire replace
setblock ~79 ~89 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~89 ~602 ~80 ~89 ~602 minecraft:redstone_wire replace
setblock ~91 ~89 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~89 ~606 ~92 ~89 ~606 minecraft:redstone_wire replace
setblock ~94 ~89 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~89 ~610 ~95 ~89 ~610 minecraft:redstone_wire replace
setblock ~97 ~89 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~89 ~614 ~98 ~89 ~614 minecraft:redstone_wire replace
setblock ~100 ~89 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~89 ~618 ~101 ~89 ~618 minecraft:redstone_wire replace
setblock ~103 ~89 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~89 ~622 ~104 ~89 ~622 minecraft:redstone_wire replace
setblock ~109 ~89 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~89 ~626 ~110 ~89 ~626 minecraft:redstone_wire replace
setblock ~106 ~89 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~89 ~634 ~107 ~89 ~634 minecraft:redstone_wire replace
setblock ~124 ~89 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~89 ~642 ~125 ~89 ~642 minecraft:redstone_wire replace
setblock ~85 ~89 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~89 ~646 ~86 ~89 ~646 minecraft:redstone_wire replace
setblock ~118 ~89 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~89 ~650 ~119 ~89 ~650 minecraft:redstone_wire replace
setblock ~112 ~89 ~653 minecraft:redstone_wire replace
fill ~111 ~89 ~654 ~113 ~89 ~654 minecraft:redstone_wire replace
setblock ~121 ~89 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~89 ~658 ~122 ~89 ~658 minecraft:redstone_wire replace
setblock ~115 ~90 ~380 minecraft:redstone_wire replace
setblock ~82 ~90 ~392 minecraft:redstone_wire replace
setblock ~88 ~90 ~596 minecraft:redstone_wire replace
setblock ~79 ~90 ~600 minecraft:redstone_wire replace
setblock ~91 ~90 ~604 minecraft:redstone_wire replace
setblock ~94 ~90 ~608 minecraft:redstone_wire replace
setblock ~97 ~90 ~612 minecraft:redstone_wire replace
setblock ~100 ~90 ~616 minecraft:redstone_wire replace
setblock ~103 ~90 ~620 minecraft:redstone_wire replace
setblock ~109 ~90 ~624 minecraft:redstone_wire replace
setblock ~106 ~90 ~632 minecraft:redstone_wire replace
setblock ~124 ~90 ~640 minecraft:redstone_wire replace
setblock ~85 ~90 ~644 minecraft:redstone_wire replace
setblock ~118 ~90 ~648 minecraft:redstone_wire replace
setblock ~112 ~90 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~90 ~656 minecraft:redstone_wire replace
fill ~114 ~91 ~380 ~114 ~91 ~384 minecraft:redstone_wire replace
fill ~81 ~91 ~392 ~81 ~91 ~396 minecraft:redstone_wire replace
fill ~87 ~91 ~596 ~87 ~91 ~600 minecraft:redstone_wire replace
fill ~78 ~91 ~600 ~78 ~91 ~604 minecraft:redstone_wire replace
fill ~90 ~91 ~604 ~90 ~91 ~608 minecraft:redstone_wire replace
fill ~93 ~91 ~608 ~93 ~91 ~612 minecraft:redstone_wire replace
fill ~96 ~91 ~612 ~96 ~91 ~616 minecraft:redstone_wire replace
fill ~99 ~91 ~616 ~99 ~91 ~620 minecraft:redstone_wire replace
fill ~102 ~91 ~620 ~102 ~91 ~624 minecraft:redstone_wire replace
fill ~108 ~91 ~624 ~108 ~91 ~628 minecraft:redstone_wire replace
fill ~105 ~91 ~632 ~105 ~91 ~636 minecraft:redstone_wire replace
fill ~123 ~91 ~640 ~123 ~91 ~644 minecraft:redstone_wire replace
fill ~84 ~91 ~644 ~84 ~91 ~648 minecraft:redstone_wire replace
fill ~117 ~91 ~648 ~117 ~91 ~652 minecraft:redstone_wire replace
fill ~111 ~91 ~652 ~111 ~91 ~656 minecraft:redstone_wire replace
fill ~120 ~91 ~656 ~120 ~91 ~660 minecraft:redstone_wire replace
setblock ~114 ~92 ~385 minecraft:redstone_wire replace
setblock ~81 ~92 ~397 minecraft:redstone_wire replace
setblock ~87 ~92 ~601 minecraft:redstone_wire replace
setblock ~78 ~92 ~605 minecraft:redstone_wire replace
setblock ~90 ~92 ~609 minecraft:redstone_wire replace
setblock ~93 ~92 ~613 minecraft:redstone_wire replace
setblock ~96 ~92 ~617 minecraft:redstone_wire replace
setblock ~99 ~92 ~621 minecraft:redstone_wire replace
setblock ~102 ~92 ~625 minecraft:redstone_wire replace
setblock ~108 ~92 ~629 minecraft:redstone_wire replace
setblock ~105 ~92 ~637 minecraft:redstone_wire replace
setblock ~123 ~92 ~645 minecraft:redstone_wire replace
setblock ~84 ~92 ~649 minecraft:redstone_wire replace
setblock ~117 ~92 ~653 minecraft:redstone_wire replace
setblock ~111 ~92 ~657 minecraft:redstone_wire replace
setblock ~120 ~92 ~661 minecraft:redstone_wire replace
fill ~114 ~93 ~386 ~119 ~93 ~386 minecraft:redstone_wire replace
setblock ~120 ~93 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~93 ~386 ~122 ~93 ~386 minecraft:redstone_wire replace
setblock ~121 ~93 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~93 ~398 ~83 ~93 ~398 minecraft:redstone_wire replace
setblock ~82 ~93 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~93 ~602 ~89 ~93 ~602 minecraft:redstone_wire replace
setblock ~88 ~93 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~93 ~606 ~80 ~93 ~606 minecraft:redstone_wire replace
setblock ~79 ~93 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~93 ~610 ~92 ~93 ~610 minecraft:redstone_wire replace
setblock ~91 ~93 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~93 ~614 ~95 ~93 ~614 minecraft:redstone_wire replace
setblock ~94 ~93 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~93 ~618 ~98 ~93 ~618 minecraft:redstone_wire replace
setblock ~97 ~93 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~93 ~622 ~101 ~93 ~622 minecraft:redstone_wire replace
setblock ~100 ~93 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~93 ~626 ~104 ~93 ~626 minecraft:redstone_wire replace
setblock ~103 ~93 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~93 ~630 ~113 ~93 ~630 minecraft:redstone_wire replace
setblock ~114 ~93 ~630 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~93 ~630 ~125 ~93 ~630 minecraft:redstone_wire replace
setblock ~106 ~93 ~631 minecraft:redstone_wire replace
setblock ~112 ~93 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~93 ~631 minecraft:redstone_wire replace
setblock ~118 ~93 ~631 minecraft:redstone_wire replace
setblock ~124 ~93 ~631 minecraft:redstone_wire replace
fill ~105 ~93 ~638 ~110 ~93 ~638 minecraft:redstone_wire replace
setblock ~111 ~93 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~93 ~638 ~124 ~93 ~638 minecraft:redstone_wire replace
setblock ~125 ~93 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~93 ~638 ~128 ~93 ~638 minecraft:redstone_wire replace
setblock ~106 ~93 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~93 ~639 minecraft:redstone_wire replace
setblock ~112 ~93 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~93 ~639 minecraft:redstone_wire replace
setblock ~127 ~93 ~639 minecraft:redstone_wire replace
fill ~123 ~93 ~646 ~129 ~93 ~646 minecraft:redstone_wire replace
setblock ~131 ~93 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~93 ~646 ~137 ~93 ~646 minecraft:redstone_wire replace
setblock ~136 ~93 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~93 ~650 ~86 ~93 ~650 minecraft:redstone_wire replace
setblock ~85 ~93 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~93 ~654 ~123 ~93 ~654 minecraft:redstone_wire replace
setblock ~125 ~93 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~93 ~654 ~131 ~93 ~654 minecraft:redstone_wire replace
setblock ~130 ~93 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~93 ~658 ~116 ~93 ~658 minecraft:redstone_wire replace
setblock ~117 ~93 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~93 ~658 ~128 ~93 ~658 minecraft:redstone_wire replace
setblock ~106 ~93 ~659 minecraft:redstone_wire replace
setblock ~109 ~93 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~93 ~659 minecraft:redstone_wire replace
setblock ~115 ~93 ~659 minecraft:redstone_wire replace
setblock ~118 ~93 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~93 ~659 minecraft:redstone_wire replace
setblock ~127 ~93 ~659 minecraft:redstone_wire replace
fill ~120 ~93 ~662 ~126 ~93 ~662 minecraft:redstone_wire replace
setblock ~128 ~93 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~93 ~662 ~134 ~93 ~662 minecraft:redstone_wire replace
setblock ~133 ~93 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~94 ~388 minecraft:redstone_wire replace
setblock ~82 ~94 ~400 minecraft:redstone_wire replace
setblock ~88 ~94 ~604 minecraft:redstone_wire replace
setblock ~79 ~94 ~608 minecraft:redstone_wire replace
setblock ~91 ~94 ~612 minecraft:redstone_wire replace
setblock ~94 ~94 ~616 minecraft:redstone_wire replace
setblock ~97 ~94 ~620 minecraft:redstone_wire replace
setblock ~100 ~94 ~624 minecraft:redstone_wire replace
setblock ~103 ~94 ~628 minecraft:redstone_wire replace
setblock ~106 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~94 ~632 minecraft:redstone_wire replace
setblock ~115 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~94 ~640 minecraft:redstone_wire replace
setblock ~109 ~94 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~94 ~640 minecraft:redstone_wire replace
setblock ~115 ~94 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~94 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~94 ~648 minecraft:redstone_wire replace
setblock ~85 ~94 ~652 minecraft:redstone_wire replace
setblock ~130 ~94 ~656 minecraft:redstone_wire replace
setblock ~106 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~94 ~660 minecraft:redstone_wire replace
setblock ~112 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~94 ~660 minecraft:redstone_wire replace
setblock ~124 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~94 ~664 minecraft:redstone_wire replace
fill ~120 ~95 ~384 ~120 ~95 ~388 minecraft:redstone_wire replace
fill ~81 ~95 ~396 ~81 ~95 ~400 minecraft:redstone_wire replace
fill ~87 ~95 ~584 ~87 ~95 ~588 minecraft:redstone_wire replace
fill ~78 ~95 ~588 ~78 ~95 ~592 minecraft:redstone_wire replace
setblock ~87 ~95 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~95 ~592 ~87 ~95 ~604 minecraft:redstone_wire replace
fill ~90 ~95 ~592 ~90 ~95 ~596 minecraft:redstone_wire replace
setblock ~78 ~95 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~95 ~596 ~78 ~95 ~608 minecraft:redstone_wire replace
fill ~93 ~95 ~596 ~93 ~95 ~600 minecraft:redstone_wire replace
setblock ~90 ~95 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~95 ~600 ~90 ~95 ~612 minecraft:redstone_wire replace
fill ~96 ~95 ~600 ~96 ~95 ~604 minecraft:redstone_wire replace
setblock ~93 ~95 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~95 ~604 ~93 ~95 ~616 minecraft:redstone_wire replace
fill ~99 ~95 ~604 ~99 ~95 ~608 minecraft:redstone_wire replace
setblock ~96 ~95 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~95 ~608 ~96 ~95 ~620 minecraft:redstone_wire replace
fill ~102 ~95 ~608 ~102 ~95 ~612 minecraft:redstone_wire replace
setblock ~99 ~95 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~95 ~612 ~99 ~95 ~624 minecraft:redstone_wire replace
fill ~123 ~95 ~612 ~123 ~95 ~614 minecraft:redstone_wire replace
setblock ~102 ~95 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~95 ~616 ~102 ~95 ~628 minecraft:redstone_wire replace
setblock ~117 ~95 ~616 minecraft:redstone_wire replace
setblock ~123 ~95 ~616 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~95 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~95 ~618 ~117 ~95 ~630 minecraft:redstone_wire replace
fill ~123 ~95 ~618 ~123 ~95 ~630 minecraft:redstone_wire replace
setblock ~114 ~95 ~620 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~95 ~622 ~114 ~95 ~630 minecraft:redstone_wire replace
fill ~111 ~95 ~624 ~111 ~95 ~630 minecraft:redstone_wire replace
fill ~105 ~95 ~628 ~105 ~95 ~630 minecraft:redstone_wire replace
setblock ~105 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~95 ~632 ~105 ~95 ~644 minecraft:redstone_wire replace
fill ~111 ~95 ~632 ~111 ~95 ~644 minecraft:redstone_wire replace
fill ~114 ~95 ~632 ~114 ~95 ~644 minecraft:redstone_wire replace
fill ~117 ~95 ~632 ~117 ~95 ~644 minecraft:redstone_wire replace
fill ~123 ~95 ~632 ~123 ~95 ~644 minecraft:redstone_wire replace
setblock ~126 ~95 ~632 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~95 ~634 ~126 ~95 ~644 minecraft:redstone_wire replace
setblock ~108 ~95 ~636 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~95 ~638 ~108 ~95 ~644 minecraft:redstone_wire replace
fill ~135 ~95 ~644 ~135 ~95 ~648 minecraft:redstone_wire replace
setblock ~105 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~95 ~648 ~84 ~95 ~652 minecraft:redstone_wire replace
fill ~105 ~95 ~648 ~105 ~95 ~660 minecraft:redstone_wire replace
fill ~108 ~95 ~648 ~108 ~95 ~660 minecraft:redstone_wire replace
fill ~111 ~95 ~648 ~111 ~95 ~660 minecraft:redstone_wire replace
fill ~114 ~95 ~648 ~114 ~95 ~660 minecraft:redstone_wire replace
fill ~117 ~95 ~648 ~117 ~95 ~660 minecraft:redstone_wire replace
fill ~123 ~95 ~648 ~123 ~95 ~660 minecraft:redstone_wire replace
fill ~126 ~95 ~648 ~126 ~95 ~660 minecraft:redstone_wire replace
fill ~129 ~95 ~652 ~129 ~95 ~656 minecraft:redstone_wire replace
fill ~132 ~95 ~660 ~132 ~95 ~664 minecraft:redstone_wire replace
setblock ~120 ~96 ~383 minecraft:redstone_wire replace
setblock ~81 ~96 ~395 minecraft:redstone_wire replace
setblock ~87 ~96 ~583 minecraft:redstone_wire replace
setblock ~78 ~96 ~587 minecraft:redstone_wire replace
setblock ~90 ~96 ~591 minecraft:redstone_wire replace
setblock ~93 ~96 ~595 minecraft:redstone_wire replace
setblock ~96 ~96 ~599 minecraft:redstone_wire replace
setblock ~99 ~96 ~603 minecraft:redstone_wire replace
setblock ~102 ~96 ~607 minecraft:redstone_wire replace
