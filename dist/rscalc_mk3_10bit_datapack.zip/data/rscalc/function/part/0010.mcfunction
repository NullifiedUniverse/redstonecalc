setblock ~147 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~150 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~159 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~162 ~127 ~615 minecraft:light_gray_concrete replace
setblock ~153 ~127 ~619 minecraft:light_gray_concrete replace
setblock ~154 ~127 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~148 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~160 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~163 ~127 ~628 minecraft:light_gray_concrete replace
setblock ~171 ~127 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~127 ~647 minecraft:light_gray_concrete replace
setblock ~165 ~127 ~651 minecraft:light_gray_concrete replace
setblock ~168 ~127 ~659 minecraft:light_gray_concrete replace
fill ~103 ~128 ~380 ~103 ~128 ~381 minecraft:light_gray_concrete replace
fill ~102 ~128 ~382 ~117 ~128 ~382 minecraft:light_gray_concrete replace
fill ~82 ~128 ~392 ~82 ~128 ~393 minecraft:light_gray_concrete replace
fill ~81 ~128 ~394 ~83 ~128 ~394 minecraft:light_gray_concrete replace
fill ~88 ~128 ~468 ~88 ~128 ~469 minecraft:light_gray_concrete replace
fill ~87 ~128 ~470 ~89 ~128 ~470 minecraft:light_gray_concrete replace
fill ~79 ~128 ~472 ~79 ~128 ~473 minecraft:light_gray_concrete replace
fill ~78 ~128 ~474 ~80 ~128 ~474 minecraft:light_gray_concrete replace
fill ~91 ~128 ~476 ~91 ~128 ~477 minecraft:light_gray_concrete replace
fill ~90 ~128 ~478 ~92 ~128 ~478 minecraft:light_gray_concrete replace
fill ~106 ~128 ~480 ~106 ~128 ~481 minecraft:light_gray_concrete replace
fill ~105 ~128 ~482 ~120 ~128 ~482 minecraft:light_gray_concrete replace
fill ~100 ~128 ~484 ~100 ~128 ~485 minecraft:light_gray_concrete replace
fill ~99 ~128 ~486 ~111 ~128 ~486 minecraft:light_gray_concrete replace
fill ~100 ~128 ~488 ~100 ~128 ~489 minecraft:light_gray_concrete replace
fill ~99 ~128 ~490 ~108 ~128 ~490 minecraft:light_gray_concrete replace
fill ~97 ~128 ~492 ~97 ~128 ~493 minecraft:light_gray_concrete replace
fill ~96 ~128 ~494 ~105 ~128 ~494 minecraft:light_gray_concrete replace
fill ~97 ~128 ~496 ~97 ~128 ~497 minecraft:light_gray_concrete replace
fill ~96 ~128 ~498 ~102 ~128 ~498 minecraft:light_gray_concrete replace
fill ~94 ~128 ~500 ~94 ~128 ~501 minecraft:light_gray_concrete replace
fill ~93 ~128 ~502 ~99 ~128 ~502 minecraft:light_gray_concrete replace
fill ~94 ~128 ~504 ~94 ~128 ~505 minecraft:light_gray_concrete replace
fill ~93 ~128 ~506 ~96 ~128 ~506 minecraft:light_gray_concrete replace
fill ~94 ~128 ~508 ~94 ~128 ~509 minecraft:light_gray_concrete replace
fill ~93 ~128 ~510 ~95 ~128 ~510 minecraft:light_gray_concrete replace
fill ~106 ~128 ~528 ~106 ~128 ~529 minecraft:light_gray_concrete replace
fill ~105 ~128 ~530 ~126 ~128 ~530 minecraft:light_gray_concrete replace
fill ~100 ~128 ~532 ~100 ~128 ~533 minecraft:light_gray_concrete replace
fill ~99 ~128 ~534 ~114 ~128 ~534 minecraft:light_gray_concrete replace
fill ~106 ~128 ~540 ~106 ~128 ~541 minecraft:light_gray_concrete replace
fill ~105 ~128 ~542 ~123 ~128 ~542 minecraft:light_gray_concrete replace
fill ~121 ~128 ~544 ~121 ~128 ~545 minecraft:light_gray_concrete replace
fill ~120 ~128 ~546 ~159 ~128 ~546 minecraft:light_gray_concrete replace
fill ~115 ~128 ~548 ~115 ~128 ~549 minecraft:light_gray_concrete replace
fill ~114 ~128 ~550 ~147 ~128 ~550 minecraft:light_gray_concrete replace
fill ~115 ~128 ~552 ~115 ~128 ~553 minecraft:light_gray_concrete replace
fill ~114 ~128 ~554 ~144 ~128 ~554 minecraft:light_gray_concrete replace
fill ~112 ~128 ~556 ~112 ~128 ~557 minecraft:light_gray_concrete replace
fill ~111 ~128 ~558 ~141 ~128 ~558 minecraft:light_gray_concrete replace
fill ~112 ~128 ~560 ~112 ~128 ~561 minecraft:light_gray_concrete replace
fill ~111 ~128 ~562 ~138 ~128 ~562 minecraft:light_gray_concrete replace
fill ~109 ~128 ~564 ~109 ~128 ~565 minecraft:light_gray_concrete replace
fill ~108 ~128 ~566 ~135 ~128 ~566 minecraft:light_gray_concrete replace
fill ~109 ~128 ~568 ~109 ~128 ~569 minecraft:light_gray_concrete replace
fill ~108 ~128 ~570 ~132 ~128 ~570 minecraft:light_gray_concrete replace
fill ~109 ~128 ~572 ~109 ~128 ~573 minecraft:light_gray_concrete replace
fill ~108 ~128 ~574 ~129 ~128 ~574 minecraft:light_gray_concrete replace
fill ~121 ~128 ~596 ~121 ~128 ~597 minecraft:light_gray_concrete replace
fill ~120 ~128 ~598 ~162 ~128 ~598 minecraft:light_gray_concrete replace
fill ~115 ~128 ~600 ~115 ~128 ~601 minecraft:light_gray_concrete replace
fill ~114 ~128 ~602 ~150 ~128 ~602 minecraft:light_gray_concrete replace
fill ~121 ~128 ~604 ~121 ~128 ~605 minecraft:light_gray_concrete replace
fill ~120 ~128 ~606 ~156 ~128 ~606 minecraft:light_gray_concrete replace
fill ~118 ~128 ~616 ~118 ~128 ~617 minecraft:light_gray_concrete replace
fill ~117 ~128 ~618 ~153 ~128 ~618 minecraft:light_gray_concrete replace
fill ~130 ~128 ~640 ~130 ~128 ~641 minecraft:light_gray_concrete replace
fill ~129 ~128 ~642 ~171 ~128 ~642 minecraft:light_gray_concrete replace
fill ~85 ~128 ~644 ~85 ~128 ~645 minecraft:light_gray_concrete replace
fill ~84 ~128 ~646 ~86 ~128 ~646 minecraft:light_gray_concrete replace
fill ~124 ~128 ~648 ~124 ~128 ~649 minecraft:light_gray_concrete replace
fill ~123 ~128 ~650 ~165 ~128 ~650 minecraft:light_gray_concrete replace
fill ~127 ~128 ~656 ~127 ~128 ~657 minecraft:light_gray_concrete replace
fill ~126 ~128 ~658 ~168 ~128 ~658 minecraft:light_gray_concrete replace
setblock ~103 ~129 ~380 minecraft:light_gray_concrete replace
setblock ~108 ~129 ~382 minecraft:light_gray_concrete replace
setblock ~110 ~129 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~129 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~129 ~468 minecraft:light_gray_concrete replace
setblock ~79 ~129 ~472 minecraft:light_gray_concrete replace
setblock ~91 ~129 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~129 ~480 minecraft:light_gray_concrete replace
setblock ~110 ~129 ~482 minecraft:light_gray_concrete replace
setblock ~112 ~129 ~482 minecraft:light_gray_concrete replace
setblock ~100 ~129 ~484 minecraft:light_gray_concrete replace
setblock ~100 ~129 ~488 minecraft:light_gray_concrete replace
setblock ~97 ~129 ~492 minecraft:light_gray_concrete replace
setblock ~97 ~129 ~496 minecraft:light_gray_concrete replace
setblock ~94 ~129 ~500 minecraft:light_gray_concrete replace
setblock ~94 ~129 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~129 ~508 minecraft:light_gray_concrete replace
setblock ~106 ~129 ~528 minecraft:light_gray_concrete replace
setblock ~118 ~129 ~530 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~530 minecraft:light_gray_concrete replace
setblock ~100 ~129 ~532 minecraft:light_gray_concrete replace
setblock ~102 ~129 ~534 minecraft:light_gray_concrete replace
setblock ~104 ~129 ~534 minecraft:light_gray_concrete replace
setblock ~106 ~129 ~540 minecraft:light_gray_concrete replace
setblock ~114 ~129 ~542 minecraft:light_gray_concrete replace
setblock ~116 ~129 ~542 minecraft:light_gray_concrete replace
setblock ~121 ~129 ~544 minecraft:light_gray_concrete replace
setblock ~128 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~145 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~546 minecraft:light_gray_concrete replace
setblock ~115 ~129 ~548 minecraft:light_gray_concrete replace
setblock ~132 ~129 ~550 minecraft:light_gray_concrete replace
setblock ~134 ~129 ~550 minecraft:light_gray_concrete replace
setblock ~115 ~129 ~552 minecraft:light_gray_concrete replace
setblock ~129 ~129 ~554 minecraft:light_gray_concrete replace
setblock ~131 ~129 ~554 minecraft:light_gray_concrete replace
setblock ~112 ~129 ~556 minecraft:light_gray_concrete replace
setblock ~114 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~116 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~131 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~133 ~129 ~558 minecraft:light_gray_concrete replace
setblock ~112 ~129 ~560 minecraft:light_gray_concrete replace
setblock ~124 ~129 ~562 minecraft:light_gray_concrete replace
setblock ~126 ~129 ~562 minecraft:light_gray_concrete replace
setblock ~109 ~129 ~564 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~566 minecraft:light_gray_concrete replace
setblock ~122 ~129 ~566 minecraft:light_gray_concrete replace
setblock ~109 ~129 ~568 minecraft:light_gray_concrete replace
setblock ~117 ~129 ~570 minecraft:light_gray_concrete replace
setblock ~119 ~129 ~570 minecraft:light_gray_concrete replace
setblock ~109 ~129 ~572 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~574 minecraft:light_gray_concrete replace
setblock ~122 ~129 ~574 minecraft:light_gray_concrete replace
setblock ~121 ~129 ~596 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~132 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~149 ~129 ~598 minecraft:light_gray_concrete replace
setblock ~115 ~129 ~600 minecraft:light_gray_concrete replace
setblock ~118 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~120 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~135 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~137 ~129 ~602 minecraft:light_gray_concrete replace
setblock ~121 ~129 ~604 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~132 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~149 ~129 ~606 minecraft:light_gray_concrete replace
setblock ~118 ~129 ~616 minecraft:light_gray_concrete replace
setblock ~127 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~129 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~144 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~146 ~129 ~618 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~640 minecraft:light_gray_concrete replace
setblock ~131 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~133 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~147 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~149 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~163 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~165 ~129 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~129 ~644 minecraft:light_gray_concrete replace
setblock ~124 ~129 ~648 minecraft:light_gray_concrete replace
setblock ~125 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~141 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~143 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~157 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~159 ~129 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~129 ~656 minecraft:light_gray_concrete replace
setblock ~128 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~130 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~144 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~146 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~160 ~129 ~658 minecraft:light_gray_concrete replace
setblock ~162 ~129 ~658 minecraft:light_gray_concrete replace
fill ~102 ~130 ~380 ~102 ~130 ~384 minecraft:light_gray_concrete replace
fill ~81 ~130 ~392 ~81 ~130 ~396 minecraft:light_gray_concrete replace
fill ~87 ~130 ~468 ~87 ~130 ~472 minecraft:light_gray_concrete replace
fill ~78 ~130 ~472 ~78 ~130 ~476 minecraft:light_gray_concrete replace
fill ~90 ~130 ~476 ~90 ~130 ~480 minecraft:light_gray_concrete replace
fill ~105 ~130 ~480 ~105 ~130 ~544 minecraft:light_gray_concrete replace
fill ~99 ~130 ~484 ~99 ~130 ~536 minecraft:light_gray_concrete replace
fill ~96 ~130 ~492 ~96 ~130 ~500 minecraft:light_gray_concrete replace
fill ~93 ~130 ~500 ~93 ~130 ~512 minecraft:light_gray_concrete replace
fill ~120 ~130 ~544 ~120 ~130 ~608 minecraft:light_gray_concrete replace
fill ~114 ~130 ~548 ~114 ~130 ~604 minecraft:light_gray_concrete replace
fill ~111 ~130 ~556 ~111 ~130 ~564 minecraft:light_gray_concrete replace
fill ~108 ~130 ~564 ~108 ~130 ~576 minecraft:light_gray_concrete replace
fill ~117 ~130 ~616 ~117 ~130 ~620 minecraft:light_gray_concrete replace
fill ~129 ~130 ~640 ~129 ~130 ~644 minecraft:light_gray_concrete replace
fill ~84 ~130 ~644 ~84 ~130 ~648 minecraft:light_gray_concrete replace
fill ~123 ~130 ~648 ~123 ~130 ~652 minecraft:light_gray_concrete replace
fill ~126 ~130 ~656 ~126 ~130 ~660 minecraft:light_gray_concrete replace
setblock ~102 ~131 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~131 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~131 ~473 minecraft:light_gray_concrete replace
setblock ~78 ~131 ~477 minecraft:light_gray_concrete replace
setblock ~106 ~131 ~480 minecraft:light_gray_concrete replace
setblock ~90 ~131 ~481 minecraft:light_gray_concrete replace
setblock ~100 ~131 ~484 minecraft:light_gray_concrete replace
setblock ~100 ~131 ~488 minecraft:light_gray_concrete replace
setblock ~97 ~131 ~492 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~493 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~495 minecraft:light_gray_concrete replace
setblock ~97 ~131 ~496 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~497 minecraft:light_gray_concrete replace
setblock ~96 ~131 ~499 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~499 minecraft:light_gray_concrete replace
setblock ~94 ~131 ~500 minecraft:light_gray_concrete replace
setblock ~96 ~131 ~501 minecraft:light_gray_concrete replace
setblock ~94 ~131 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~131 ~508 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~509 minecraft:light_gray_concrete replace
setblock ~93 ~131 ~511 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~511 minecraft:light_gray_concrete replace
setblock ~93 ~131 ~513 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~513 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~515 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~525 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~527 minecraft:light_gray_concrete replace
setblock ~106 ~131 ~528 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~529 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~531 minecraft:light_gray_concrete replace
setblock ~100 ~131 ~532 minecraft:light_gray_concrete replace
setblock ~99 ~131 ~537 minecraft:light_gray_concrete replace
setblock ~106 ~131 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~131 ~544 minecraft:light_gray_concrete replace
setblock ~105 ~131 ~545 minecraft:light_gray_concrete replace
setblock ~115 ~131 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~131 ~552 minecraft:light_gray_concrete replace
setblock ~112 ~131 ~556 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~557 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~559 minecraft:light_gray_concrete replace
setblock ~112 ~131 ~560 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~561 minecraft:light_gray_concrete replace
setblock ~111 ~131 ~563 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~563 minecraft:light_gray_concrete replace
setblock ~109 ~131 ~564 minecraft:light_gray_concrete replace
setblock ~111 ~131 ~565 minecraft:light_gray_concrete replace
setblock ~109 ~131 ~568 minecraft:light_gray_concrete replace
setblock ~109 ~131 ~572 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~573 minecraft:light_gray_concrete replace
setblock ~108 ~131 ~575 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~575 minecraft:light_gray_concrete replace
setblock ~108 ~131 ~577 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~577 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~579 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~589 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~591 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~593 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~595 minecraft:light_gray_concrete replace
setblock ~121 ~131 ~596 minecraft:light_gray_concrete replace
setblock ~115 ~131 ~600 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~603 minecraft:light_gray_concrete replace
setblock ~121 ~131 ~604 minecraft:light_gray_concrete replace
setblock ~114 ~131 ~605 minecraft:light_gray_concrete replace
setblock ~120 ~131 ~609 minecraft:light_gray_concrete replace
setblock ~118 ~131 ~616 minecraft:light_gray_concrete replace
setblock ~117 ~131 ~621 minecraft:light_gray_concrete replace
setblock ~129 ~131 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~131 ~649 minecraft:light_gray_concrete replace
setblock ~123 ~131 ~653 minecraft:light_gray_concrete replace
setblock ~126 ~131 ~661 minecraft:light_gray_concrete replace
fill ~102 ~132 ~386 ~116 ~132 ~386 minecraft:light_gray_concrete replace
fill ~115 ~132 ~387 ~115 ~132 ~388 minecraft:light_gray_concrete replace
fill ~81 ~132 ~398 ~83 ~132 ~398 minecraft:light_gray_concrete replace
fill ~82 ~132 ~399 ~82 ~132 ~400 minecraft:light_gray_concrete replace
fill ~87 ~132 ~474 ~89 ~132 ~474 minecraft:light_gray_concrete replace
fill ~88 ~132 ~475 ~88 ~132 ~476 minecraft:light_gray_concrete replace
fill ~78 ~132 ~478 ~80 ~132 ~478 minecraft:light_gray_concrete replace
fill ~79 ~132 ~479 ~79 ~132 ~480 minecraft:light_gray_concrete replace
fill ~90 ~132 ~482 ~119 ~132 ~482 minecraft:light_gray_concrete replace
fill ~91 ~132 ~483 ~91 ~132 ~484 minecraft:light_gray_concrete replace
fill ~94 ~132 ~483 ~94 ~132 ~484 minecraft:light_gray_concrete replace
fill ~97 ~132 ~483 ~97 ~132 ~484 minecraft:light_gray_concrete replace
fill ~100 ~132 ~483 ~100 ~132 ~484 minecraft:light_gray_concrete replace
fill ~103 ~132 ~483 ~103 ~132 ~484 minecraft:light_gray_concrete replace
fill ~106 ~132 ~483 ~106 ~132 ~484 minecraft:light_gray_concrete replace
fill ~109 ~132 ~483 ~109 ~132 ~484 minecraft:light_gray_concrete replace
fill ~118 ~132 ~483 ~118 ~132 ~484 minecraft:light_gray_concrete replace
fill ~90 ~132 ~502 ~125 ~132 ~502 minecraft:light_gray_concrete replace
fill ~91 ~132 ~503 ~91 ~132 ~504 minecraft:light_gray_concrete replace
fill ~97 ~132 ~503 ~97 ~132 ~504 minecraft:light_gray_concrete replace
fill ~103 ~132 ~503 ~103 ~132 ~504 minecraft:light_gray_concrete replace
fill ~106 ~132 ~503 ~106 ~132 ~504 minecraft:light_gray_concrete replace
fill ~112 ~132 ~503 ~112 ~132 ~504 minecraft:light_gray_concrete replace
fill ~124 ~132 ~503 ~124 ~132 ~504 minecraft:light_gray_concrete replace
fill ~90 ~132 ~514 ~122 ~132 ~514 minecraft:light_gray_concrete replace
fill ~91 ~132 ~515 ~91 ~132 ~516 minecraft:light_gray_concrete replace
fill ~94 ~132 ~515 ~94 ~132 ~516 minecraft:light_gray_concrete replace
fill ~97 ~132 ~515 ~97 ~132 ~516 minecraft:light_gray_concrete replace
fill ~100 ~132 ~515 ~100 ~132 ~516 minecraft:light_gray_concrete replace
fill ~109 ~132 ~515 ~109 ~132 ~516 minecraft:light_gray_concrete replace
fill ~112 ~132 ~515 ~112 ~132 ~516 minecraft:light_gray_concrete replace
fill ~121 ~132 ~515 ~121 ~132 ~516 minecraft:light_gray_concrete replace
fill ~93 ~132 ~538 ~122 ~132 ~538 minecraft:light_gray_concrete replace
fill ~94 ~132 ~539 ~94 ~132 ~540 minecraft:light_gray_concrete replace
fill ~100 ~132 ~539 ~100 ~132 ~540 minecraft:light_gray_concrete replace
fill ~103 ~132 ~539 ~103 ~132 ~540 minecraft:light_gray_concrete replace
fill ~109 ~132 ~539 ~109 ~132 ~540 minecraft:light_gray_concrete replace
fill ~112 ~132 ~539 ~112 ~132 ~540 minecraft:light_gray_concrete replace
fill ~118 ~132 ~539 ~118 ~132 ~540 minecraft:light_gray_concrete replace
fill ~121 ~132 ~539 ~121 ~132 ~540 minecraft:light_gray_concrete replace
fill ~105 ~132 ~546 ~152 ~132 ~546 minecraft:light_gray_concrete replace
fill ~127 ~132 ~547 ~127 ~132 ~548 minecraft:light_gray_concrete replace
fill ~130 ~132 ~547 ~130 ~132 ~548 minecraft:light_gray_concrete replace
fill ~133 ~132 ~547 ~133 ~132 ~548 minecraft:light_gray_concrete replace
fill ~136 ~132 ~547 ~136 ~132 ~548 minecraft:light_gray_concrete replace
fill ~139 ~132 ~547 ~139 ~132 ~548 minecraft:light_gray_concrete replace
fill ~142 ~132 ~547 ~142 ~132 ~548 minecraft:light_gray_concrete replace
fill ~145 ~132 ~547 ~145 ~132 ~548 minecraft:light_gray_concrete replace
fill ~151 ~132 ~547 ~151 ~132 ~548 minecraft:light_gray_concrete replace
fill ~111 ~132 ~566 ~155 ~132 ~566 minecraft:light_gray_concrete replace
fill ~127 ~132 ~567 ~127 ~132 ~568 minecraft:light_gray_concrete replace
fill ~133 ~132 ~567 ~133 ~132 ~568 minecraft:light_gray_concrete replace
fill ~139 ~132 ~567 ~139 ~132 ~568 minecraft:light_gray_concrete replace
fill ~142 ~132 ~567 ~142 ~132 ~568 minecraft:light_gray_concrete replace
fill ~148 ~132 ~567 ~148 ~132 ~568 minecraft:light_gray_concrete replace
fill ~154 ~132 ~567 ~154 ~132 ~568 minecraft:light_gray_concrete replace
fill ~108 ~132 ~578 ~158 ~132 ~578 minecraft:light_gray_concrete replace
fill ~127 ~132 ~579 ~127 ~132 ~580 minecraft:light_gray_concrete replace
fill ~130 ~132 ~579 ~130 ~132 ~580 minecraft:light_gray_concrete replace
fill ~133 ~132 ~579 ~133 ~132 ~580 minecraft:light_gray_concrete replace
fill ~136 ~132 ~579 ~136 ~132 ~580 minecraft:light_gray_concrete replace
fill ~145 ~132 ~579 ~145 ~132 ~580 minecraft:light_gray_concrete replace
fill ~148 ~132 ~579 ~148 ~132 ~580 minecraft:light_gray_concrete replace
fill ~157 ~132 ~579 ~157 ~132 ~580 minecraft:light_gray_concrete replace
fill ~114 ~132 ~606 ~158 ~132 ~606 minecraft:light_gray_concrete replace
fill ~130 ~132 ~607 ~130 ~132 ~608 minecraft:light_gray_concrete replace
fill ~136 ~132 ~607 ~136 ~132 ~608 minecraft:light_gray_concrete replace
fill ~139 ~132 ~607 ~139 ~132 ~608 minecraft:light_gray_concrete replace
fill ~145 ~132 ~607 ~145 ~132 ~608 minecraft:light_gray_concrete replace
fill ~148 ~132 ~607 ~148 ~132 ~608 minecraft:light_gray_concrete replace
fill ~151 ~132 ~607 ~151 ~132 ~608 minecraft:light_gray_concrete replace
fill ~157 ~132 ~607 ~157 ~132 ~608 minecraft:light_gray_concrete replace
fill ~120 ~132 ~610 ~164 ~132 ~610 minecraft:light_gray_concrete replace
fill ~163 ~132 ~611 ~163 ~132 ~612 minecraft:light_gray_concrete replace
fill ~117 ~132 ~622 ~161 ~132 ~622 minecraft:light_gray_concrete replace
fill ~160 ~132 ~623 ~160 ~132 ~624 minecraft:light_gray_concrete replace
fill ~129 ~132 ~646 ~173 ~132 ~646 minecraft:light_gray_concrete replace
fill ~172 ~132 ~647 ~172 ~132 ~648 minecraft:light_gray_concrete replace
fill ~84 ~132 ~650 ~86 ~132 ~650 minecraft:light_gray_concrete replace
fill ~85 ~132 ~651 ~85 ~132 ~652 minecraft:light_gray_concrete replace
fill ~123 ~132 ~654 ~167 ~132 ~654 minecraft:light_gray_concrete replace
fill ~166 ~132 ~655 ~166 ~132 ~656 minecraft:light_gray_concrete replace
fill ~126 ~132 ~662 ~170 ~132 ~662 minecraft:light_gray_concrete replace
fill ~169 ~132 ~663 ~169 ~132 ~664 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~386 minecraft:light_gray_concrete replace
setblock ~111 ~133 ~386 minecraft:light_gray_concrete replace
setblock ~115 ~133 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~133 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~133 ~476 minecraft:light_gray_concrete replace
setblock ~79 ~133 ~480 minecraft:light_gray_concrete replace
setblock ~91 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~94 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~97 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~100 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~133 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~502 minecraft:light_gray_concrete replace
setblock ~111 ~133 ~502 minecraft:light_gray_concrete replace
setblock ~91 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~97 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~103 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~112 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~124 ~133 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~514 minecraft:light_gray_concrete replace
setblock ~108 ~133 ~514 minecraft:light_gray_concrete replace
setblock ~91 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~94 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~97 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~100 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~133 ~516 minecraft:light_gray_concrete replace
setblock ~106 ~133 ~538 minecraft:light_gray_concrete replace
setblock ~108 ~133 ~538 minecraft:light_gray_concrete replace
setblock ~94 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~100 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~103 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~133 ~540 minecraft:light_gray_concrete replace
setblock ~115 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~117 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~147 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~149 ~133 ~546 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~142 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~145 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~133 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~133 ~566 minecraft:light_gray_concrete replace
setblock ~126 ~133 ~566 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~139 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~148 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~133 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~123 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~138 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~140 ~133 ~578 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~157 ~133 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~133 ~606 minecraft:light_gray_concrete replace
setblock ~129 ~133 ~606 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~139 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~145 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~148 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~157 ~133 ~608 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~132 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~147 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~149 ~133 ~610 minecraft:light_gray_concrete replace
setblock ~163 ~133 ~612 minecraft:light_gray_concrete replace
setblock ~124 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~126 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~141 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~143 ~133 ~622 minecraft:light_gray_concrete replace
setblock ~160 ~133 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~138 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~153 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~155 ~133 ~646 minecraft:light_gray_concrete replace
setblock ~172 ~133 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~133 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~132 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~147 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~149 ~133 ~654 minecraft:light_gray_concrete replace
setblock ~166 ~133 ~656 minecraft:light_gray_concrete replace
setblock ~133 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~135 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~150 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~152 ~133 ~662 minecraft:light_gray_concrete replace
setblock ~169 ~133 ~664 minecraft:light_gray_concrete replace
fill ~114 ~134 ~384 ~114 ~134 ~388 minecraft:light_gray_concrete replace
fill ~81 ~134 ~396 ~81 ~134 ~400 minecraft:light_gray_concrete replace
fill ~87 ~134 ~444 ~87 ~134 ~476 minecraft:light_gray_concrete replace
fill ~78 ~134 ~448 ~78 ~134 ~480 minecraft:light_gray_concrete replace
fill ~117 ~134 ~452 ~117 ~134 ~540 minecraft:light_gray_concrete replace
fill ~108 ~134 ~456 ~108 ~134 ~540 minecraft:light_gray_concrete replace
fill ~105 ~134 ~460 ~105 ~134 ~504 minecraft:light_gray_concrete replace
fill ~102 ~134 ~464 ~102 ~134 ~540 minecraft:light_gray_concrete replace
fill ~99 ~134 ~468 ~99 ~134 ~540 minecraft:light_gray_concrete replace
fill ~96 ~134 ~472 ~96 ~134 ~516 minecraft:light_gray_concrete replace
fill ~93 ~134 ~476 ~93 ~134 ~540 minecraft:light_gray_concrete replace
fill ~90 ~134 ~480 ~90 ~134 ~516 minecraft:light_gray_concrete replace
fill ~123 ~134 ~496 ~123 ~134 ~504 minecraft:light_gray_concrete replace
fill ~111 ~134 ~500 ~111 ~134 ~540 minecraft:light_gray_concrete replace
fill ~120 ~134 ~512 ~120 ~134 ~540 minecraft:light_gray_concrete replace
fill ~150 ~134 ~516 ~150 ~134 ~608 minecraft:light_gray_concrete replace
fill ~144 ~134 ~520 ~144 ~134 ~608 minecraft:light_gray_concrete replace
fill ~141 ~134 ~524 ~141 ~134 ~568 minecraft:light_gray_concrete replace
fill ~138 ~134 ~528 ~138 ~134 ~608 minecraft:light_gray_concrete replace
fill ~135 ~134 ~532 ~135 ~134 ~608 minecraft:light_gray_concrete replace
fill ~132 ~134 ~536 ~132 ~134 ~580 minecraft:light_gray_concrete replace
fill ~129 ~134 ~540 ~129 ~134 ~608 minecraft:light_gray_concrete replace
fill ~126 ~134 ~544 ~126 ~134 ~580 minecraft:light_gray_concrete replace
fill ~153 ~134 ~560 ~153 ~134 ~568 minecraft:light_gray_concrete replace
fill ~147 ~134 ~564 ~147 ~134 ~608 minecraft:light_gray_concrete replace
fill ~156 ~134 ~576 ~156 ~134 ~608 minecraft:light_gray_concrete replace
fill ~162 ~134 ~608 ~162 ~134 ~612 minecraft:light_gray_concrete replace
fill ~159 ~134 ~620 ~159 ~134 ~624 minecraft:light_gray_concrete replace
fill ~171 ~134 ~644 ~171 ~134 ~648 minecraft:light_gray_concrete replace
fill ~84 ~134 ~648 ~84 ~134 ~652 minecraft:light_gray_concrete replace
fill ~165 ~134 ~652 ~165 ~134 ~656 minecraft:light_gray_concrete replace
fill ~168 ~134 ~660 ~168 ~134 ~664 minecraft:light_gray_concrete replace
setblock ~114 ~135 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~135 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~445 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~447 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~447 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~449 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~451 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~451 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~453 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~455 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~459 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~461 minecraft:light_gray_concrete replace
setblock ~87 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~463 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~465 minecraft:light_gray_concrete replace
setblock ~78 ~135 ~467 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~467 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~469 minecraft:light_gray_concrete replace
setblock ~96 ~135 ~471 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~473 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~475 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~475 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~477 minecraft:light_gray_concrete replace
setblock ~90 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~479 minecraft:light_gray_concrete replace
setblock ~91 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~135 ~484 minecraft:light_gray_concrete replace
setblock ~90 ~135 ~487 minecraft:light_gray_concrete replace
setblock ~96 ~135 ~487 minecraft:light_gray_concrete replace
setblock ~90 ~135 ~489 minecraft:light_gray_concrete replace
setblock ~96 ~135 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~135 ~491 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~493 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~123 ~135 ~495 minecraft:light_gray_concrete replace
setblock ~123 ~135 ~497 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~499 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~501 minecraft:light_gray_concrete replace
setblock ~91 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~97 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~124 ~135 ~504 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~509 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~511 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~513 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~515 minecraft:light_gray_concrete replace
setblock ~100 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~109 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~135 ~516 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~519 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~521 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~523 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~525 minecraft:light_gray_concrete replace
setblock ~93 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~99 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~102 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~111 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~117 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~120 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~527 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~531 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~531 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~531 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~533 minecraft:light_gray_concrete replace
setblock ~132 ~135 ~535 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~535 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~535 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~537 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~539 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~539 minecraft:light_gray_concrete replace
setblock ~94 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~100 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~109 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~121 ~135 ~540 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~541 minecraft:light_gray_concrete replace
setblock ~126 ~135 ~543 minecraft:light_gray_concrete replace
setblock ~127 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~145 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~135 ~548 minecraft:light_gray_concrete replace
setblock ~126 ~135 ~551 minecraft:light_gray_concrete replace
setblock ~132 ~135 ~551 minecraft:light_gray_concrete replace
setblock ~126 ~135 ~553 minecraft:light_gray_concrete replace
setblock ~132 ~135 ~553 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~553 minecraft:light_gray_concrete replace
setblock ~141 ~135 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~135 ~559 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~561 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~561 minecraft:light_gray_concrete replace
setblock ~153 ~135 ~561 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~147 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~563 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~565 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~565 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~565 minecraft:light_gray_concrete replace
setblock ~127 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~133 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~135 ~568 minecraft:light_gray_concrete replace
setblock ~156 ~135 ~575 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~577 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~577 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~579 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~579 minecraft:light_gray_concrete replace
setblock ~136 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~148 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~157 ~135 ~580 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~147 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~156 ~135 ~593 minecraft:light_gray_concrete replace
setblock ~129 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~135 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~138 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~144 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~147 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~150 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~156 ~135 ~595 minecraft:light_gray_concrete replace
setblock ~162 ~135 ~607 minecraft:light_gray_concrete replace
setblock ~130 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~136 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~145 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~151 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~157 ~135 ~608 minecraft:light_gray_concrete replace
setblock ~163 ~135 ~612 minecraft:light_gray_concrete replace
setblock ~159 ~135 ~619 minecraft:light_gray_concrete replace
setblock ~160 ~135 ~624 minecraft:light_gray_concrete replace
setblock ~171 ~135 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~135 ~647 minecraft:light_gray_concrete replace
setblock ~165 ~135 ~651 minecraft:light_gray_concrete replace
setblock ~168 ~135 ~659 minecraft:light_gray_concrete replace
fill ~100 ~136 ~380 ~100 ~136 ~381 minecraft:light_gray_concrete replace
fill ~99 ~136 ~382 ~114 ~136 ~382 minecraft:light_gray_concrete replace
fill ~82 ~136 ~392 ~82 ~136 ~393 minecraft:light_gray_concrete replace
fill ~81 ~136 ~394 ~83 ~136 ~394 minecraft:light_gray_concrete replace
fill ~88 ~136 ~440 ~88 ~136 ~441 minecraft:light_gray_concrete replace
fill ~87 ~136 ~442 ~89 ~136 ~442 minecraft:light_gray_concrete replace
fill ~79 ~136 ~444 ~79 ~136 ~445 minecraft:light_gray_concrete replace
fill ~78 ~136 ~446 ~80 ~136 ~446 minecraft:light_gray_concrete replace
fill ~103 ~136 ~448 ~103 ~136 ~449 minecraft:light_gray_concrete replace
fill ~102 ~136 ~450 ~117 ~136 ~450 minecraft:light_gray_concrete replace
fill ~97 ~136 ~452 ~97 ~136 ~453 minecraft:light_gray_concrete replace
fill ~96 ~136 ~454 ~108 ~136 ~454 minecraft:light_gray_concrete replace
fill ~97 ~136 ~456 ~97 ~136 ~457 minecraft:light_gray_concrete replace
fill ~96 ~136 ~458 ~105 ~136 ~458 minecraft:light_gray_concrete replace
fill ~94 ~136 ~460 ~94 ~136 ~461 minecraft:light_gray_concrete replace
fill ~93 ~136 ~462 ~102 ~136 ~462 minecraft:light_gray_concrete replace
fill ~94 ~136 ~464 ~94 ~136 ~465 minecraft:light_gray_concrete replace
fill ~93 ~136 ~466 ~99 ~136 ~466 minecraft:light_gray_concrete replace
fill ~94 ~136 ~468 ~94 ~136 ~469 minecraft:light_gray_concrete replace
fill ~93 ~136 ~470 ~96 ~136 ~470 minecraft:light_gray_concrete replace
fill ~91 ~136 ~472 ~91 ~136 ~473 minecraft:light_gray_concrete replace
fill ~90 ~136 ~474 ~93 ~136 ~474 minecraft:light_gray_concrete replace
fill ~91 ~136 ~476 ~91 ~136 ~477 minecraft:light_gray_concrete replace
fill ~90 ~136 ~478 ~92 ~136 ~478 minecraft:light_gray_concrete replace
fill ~103 ~136 ~492 ~103 ~136 ~493 minecraft:light_gray_concrete replace
fill ~102 ~136 ~494 ~123 ~136 ~494 minecraft:light_gray_concrete replace
fill ~97 ~136 ~496 ~97 ~136 ~497 minecraft:light_gray_concrete replace
fill ~96 ~136 ~498 ~111 ~136 ~498 minecraft:light_gray_concrete replace
fill ~103 ~136 ~508 ~103 ~136 ~509 minecraft:light_gray_concrete replace
fill ~102 ~136 ~510 ~120 ~136 ~510 minecraft:light_gray_concrete replace
fill ~115 ~136 ~512 ~115 ~136 ~513 minecraft:light_gray_concrete replace
fill ~114 ~136 ~514 ~150 ~136 ~514 minecraft:light_gray_concrete replace
fill ~112 ~136 ~516 ~112 ~136 ~517 minecraft:light_gray_concrete replace
fill ~111 ~136 ~518 ~144 ~136 ~518 minecraft:light_gray_concrete replace
fill ~112 ~136 ~520 ~112 ~136 ~521 minecraft:light_gray_concrete replace
fill ~111 ~136 ~522 ~141 ~136 ~522 minecraft:light_gray_concrete replace
fill ~109 ~136 ~524 ~109 ~136 ~525 minecraft:light_gray_concrete replace
fill ~108 ~136 ~526 ~138 ~136 ~526 minecraft:light_gray_concrete replace
fill ~109 ~136 ~528 ~109 ~136 ~529 minecraft:light_gray_concrete replace
fill ~108 ~136 ~530 ~135 ~136 ~530 minecraft:light_gray_concrete replace
fill ~109 ~136 ~532 ~109 ~136 ~533 minecraft:light_gray_concrete replace
fill ~108 ~136 ~534 ~132 ~136 ~534 minecraft:light_gray_concrete replace
fill ~106 ~136 ~536 ~106 ~136 ~537 minecraft:light_gray_concrete replace
fill ~105 ~136 ~538 ~129 ~136 ~538 minecraft:light_gray_concrete replace
fill ~106 ~136 ~540 ~106 ~136 ~541 minecraft:light_gray_concrete replace
fill ~105 ~136 ~542 ~126 ~136 ~542 minecraft:light_gray_concrete replace
fill ~115 ~136 ~556 ~115 ~136 ~557 minecraft:light_gray_concrete replace
fill ~114 ~136 ~558 ~153 ~136 ~558 minecraft:light_gray_concrete replace
fill ~112 ~136 ~560 ~112 ~136 ~561 minecraft:light_gray_concrete replace
fill ~111 ~136 ~562 ~147 ~136 ~562 minecraft:light_gray_concrete replace
fill ~115 ~136 ~572 ~115 ~136 ~573 minecraft:light_gray_concrete replace
fill ~114 ~136 ~574 ~156 ~136 ~574 minecraft:light_gray_concrete replace
fill ~121 ~136 ~604 ~121 ~136 ~605 minecraft:light_gray_concrete replace
fill ~120 ~136 ~606 ~162 ~136 ~606 minecraft:light_gray_concrete replace
fill ~118 ~136 ~616 ~118 ~136 ~617 minecraft:light_gray_concrete replace
fill ~117 ~136 ~618 ~159 ~136 ~618 minecraft:light_gray_concrete replace
fill ~130 ~136 ~640 ~130 ~136 ~641 minecraft:light_gray_concrete replace
fill ~129 ~136 ~642 ~171 ~136 ~642 minecraft:light_gray_concrete replace
fill ~85 ~136 ~644 ~85 ~136 ~645 minecraft:light_gray_concrete replace
fill ~84 ~136 ~646 ~86 ~136 ~646 minecraft:light_gray_concrete replace
fill ~124 ~136 ~648 ~124 ~136 ~649 minecraft:light_gray_concrete replace
fill ~123 ~136 ~650 ~165 ~136 ~650 minecraft:light_gray_concrete replace
fill ~127 ~136 ~656 ~127 ~136 ~657 minecraft:light_gray_concrete replace
fill ~126 ~136 ~658 ~168 ~136 ~658 minecraft:light_gray_concrete replace
setblock ~100 ~137 ~380 minecraft:light_gray_concrete replace
setblock ~105 ~137 ~382 minecraft:light_gray_concrete replace
setblock ~107 ~137 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~137 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~137 ~440 minecraft:light_gray_concrete replace
setblock ~79 ~137 ~444 minecraft:light_gray_concrete replace
setblock ~103 ~137 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~137 ~452 minecraft:light_gray_concrete replace
setblock ~98 ~137 ~454 minecraft:light_gray_concrete replace
setblock ~100 ~137 ~454 minecraft:light_gray_concrete replace
setblock ~97 ~137 ~456 minecraft:light_gray_concrete replace
setblock ~94 ~137 ~460 minecraft:light_gray_concrete replace
setblock ~94 ~137 ~464 minecraft:light_gray_concrete replace
setblock ~94 ~137 ~468 minecraft:light_gray_concrete replace
setblock ~91 ~137 ~472 minecraft:light_gray_concrete replace
setblock ~91 ~137 ~476 minecraft:light_gray_concrete replace
setblock ~103 ~137 ~492 minecraft:light_gray_concrete replace
setblock ~108 ~137 ~494 minecraft:light_gray_concrete replace
setblock ~110 ~137 ~494 minecraft:light_gray_concrete replace
setblock ~97 ~137 ~496 minecraft:light_gray_concrete replace
setblock ~103 ~137 ~508 minecraft:light_gray_concrete replace
setblock ~105 ~137 ~510 minecraft:light_gray_concrete replace
setblock ~107 ~137 ~510 minecraft:light_gray_concrete replace
setblock ~115 ~137 ~512 minecraft:light_gray_concrete replace
setblock ~119 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~136 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~138 ~137 ~514 minecraft:light_gray_concrete replace
setblock ~112 ~137 ~516 minecraft:light_gray_concrete replace
setblock ~129 ~137 ~518 minecraft:light_gray_concrete replace
setblock ~131 ~137 ~518 minecraft:light_gray_concrete replace
setblock ~112 ~137 ~520 minecraft:light_gray_concrete replace
setblock ~126 ~137 ~522 minecraft:light_gray_concrete replace
setblock ~128 ~137 ~522 minecraft:light_gray_concrete replace
setblock ~109 ~137 ~524 minecraft:light_gray_concrete replace
setblock ~126 ~137 ~526 minecraft:light_gray_concrete replace
setblock ~128 ~137 ~526 minecraft:light_gray_concrete replace
setblock ~109 ~137 ~528 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~530 minecraft:light_gray_concrete replace
setblock ~123 ~137 ~530 minecraft:light_gray_concrete replace
setblock ~109 ~137 ~532 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~534 minecraft:light_gray_concrete replace
setblock ~120 ~137 ~534 minecraft:light_gray_concrete replace
setblock ~106 ~137 ~536 minecraft:light_gray_concrete replace
setblock ~114 ~137 ~538 minecraft:light_gray_concrete replace
setblock ~116 ~137 ~538 minecraft:light_gray_concrete replace
setblock ~106 ~137 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~542 minecraft:light_gray_concrete replace
setblock ~120 ~137 ~542 minecraft:light_gray_concrete replace
setblock ~115 ~137 ~556 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~123 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~138 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~140 ~137 ~558 minecraft:light_gray_concrete replace
setblock ~112 ~137 ~560 minecraft:light_gray_concrete replace
setblock ~116 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~133 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~135 ~137 ~562 minecraft:light_gray_concrete replace
setblock ~115 ~137 ~572 minecraft:light_gray_concrete replace
setblock ~127 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~129 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~144 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~146 ~137 ~574 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~604 minecraft:light_gray_concrete replace
setblock ~122 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~124 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~138 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~140 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~154 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~156 ~137 ~606 minecraft:light_gray_concrete replace
setblock ~118 ~137 ~616 minecraft:light_gray_concrete replace
setblock ~119 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~121 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~135 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~137 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~151 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~153 ~137 ~618 minecraft:light_gray_concrete replace
setblock ~130 ~137 ~640 minecraft:light_gray_concrete replace
setblock ~131 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~133 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~147 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~149 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~163 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~165 ~137 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~137 ~644 minecraft:light_gray_concrete replace
setblock ~124 ~137 ~648 minecraft:light_gray_concrete replace
setblock ~125 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~141 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~143 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~157 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~159 ~137 ~650 minecraft:light_gray_concrete replace
setblock ~127 ~137 ~656 minecraft:light_gray_concrete replace
setblock ~128 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~130 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~144 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~146 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~160 ~137 ~658 minecraft:light_gray_concrete replace
setblock ~162 ~137 ~658 minecraft:light_gray_concrete replace
fill ~99 ~138 ~380 ~99 ~138 ~384 minecraft:light_gray_concrete replace
fill ~81 ~138 ~392 ~81 ~138 ~396 minecraft:light_gray_concrete replace
fill ~87 ~138 ~440 ~87 ~138 ~444 minecraft:light_gray_concrete replace
fill ~78 ~138 ~444 ~78 ~138 ~448 minecraft:light_gray_concrete replace
fill ~102 ~138 ~448 ~102 ~138 ~512 minecraft:light_gray_concrete replace
fill ~96 ~138 ~452 ~96 ~138 ~500 minecraft:light_gray_concrete replace
fill ~93 ~138 ~460 ~93 ~138 ~472 minecraft:light_gray_concrete replace
fill ~90 ~138 ~472 ~90 ~138 ~480 minecraft:light_gray_concrete replace
fill ~114 ~138 ~512 ~114 ~138 ~576 minecraft:light_gray_concrete replace
fill ~111 ~138 ~516 ~111 ~138 ~564 minecraft:light_gray_concrete replace
fill ~108 ~138 ~524 ~108 ~138 ~536 minecraft:light_gray_concrete replace
fill ~105 ~138 ~536 ~105 ~138 ~544 minecraft:light_gray_concrete replace
fill ~120 ~138 ~604 ~120 ~138 ~608 minecraft:light_gray_concrete replace
fill ~117 ~138 ~616 ~117 ~138 ~620 minecraft:light_gray_concrete replace
fill ~129 ~138 ~640 ~129 ~138 ~644 minecraft:light_gray_concrete replace
fill ~84 ~138 ~644 ~84 ~138 ~648 minecraft:light_gray_concrete replace
fill ~123 ~138 ~648 ~123 ~138 ~652 minecraft:light_gray_concrete replace
fill ~126 ~138 ~656 ~126 ~138 ~660 minecraft:light_gray_concrete replace
setblock ~99 ~139 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~139 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~139 ~445 minecraft:light_gray_concrete replace
setblock ~103 ~139 ~448 minecraft:light_gray_concrete replace
setblock ~78 ~139 ~449 minecraft:light_gray_concrete replace
setblock ~97 ~139 ~452 minecraft:light_gray_concrete replace
setblock ~97 ~139 ~456 minecraft:light_gray_concrete replace
setblock ~94 ~139 ~460 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~461 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~463 minecraft:light_gray_concrete replace
setblock ~94 ~139 ~464 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~465 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~467 minecraft:light_gray_concrete replace
setblock ~94 ~139 ~468 minecraft:light_gray_concrete replace
setblock ~93 ~139 ~471 minecraft:light_gray_concrete replace
setblock ~91 ~139 ~472 minecraft:light_gray_concrete replace
setblock ~93 ~139 ~473 minecraft:light_gray_concrete replace
setblock ~91 ~139 ~476 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~477 minecraft:light_gray_concrete replace
setblock ~90 ~139 ~479 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~479 minecraft:light_gray_concrete replace
setblock ~90 ~139 ~481 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~481 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~483 minecraft:light_gray_concrete replace
setblock ~103 ~139 ~492 minecraft:light_gray_concrete replace
setblock ~97 ~139 ~496 minecraft:light_gray_concrete replace
setblock ~96 ~139 ~501 minecraft:light_gray_concrete replace
setblock ~103 ~139 ~508 minecraft:light_gray_concrete replace
setblock ~115 ~139 ~512 minecraft:light_gray_concrete replace
setblock ~102 ~139 ~513 minecraft:light_gray_concrete replace
setblock ~112 ~139 ~516 minecraft:light_gray_concrete replace
setblock ~112 ~139 ~520 minecraft:light_gray_concrete replace
setblock ~109 ~139 ~524 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~525 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~527 minecraft:light_gray_concrete replace
setblock ~109 ~139 ~528 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~529 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~531 minecraft:light_gray_concrete replace
setblock ~109 ~139 ~532 minecraft:light_gray_concrete replace
setblock ~108 ~139 ~535 minecraft:light_gray_concrete replace
setblock ~106 ~139 ~536 minecraft:light_gray_concrete replace
setblock ~108 ~139 ~537 minecraft:light_gray_concrete replace
setblock ~106 ~139 ~540 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~541 minecraft:light_gray_concrete replace
setblock ~105 ~139 ~543 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~543 minecraft:light_gray_concrete replace
setblock ~105 ~139 ~545 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~545 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~547 minecraft:light_gray_concrete replace
setblock ~115 ~139 ~556 minecraft:light_gray_concrete replace
setblock ~112 ~139 ~560 minecraft:light_gray_concrete replace
setblock ~111 ~139 ~565 minecraft:light_gray_concrete replace
setblock ~115 ~139 ~572 minecraft:light_gray_concrete replace
setblock ~114 ~139 ~577 minecraft:light_gray_concrete replace
setblock ~121 ~139 ~604 minecraft:light_gray_concrete replace
setblock ~120 ~139 ~609 minecraft:light_gray_concrete replace
setblock ~118 ~139 ~616 minecraft:light_gray_concrete replace
setblock ~117 ~139 ~621 minecraft:light_gray_concrete replace
setblock ~129 ~139 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~139 ~649 minecraft:light_gray_concrete replace
setblock ~123 ~139 ~653 minecraft:light_gray_concrete replace
setblock ~126 ~139 ~661 minecraft:light_gray_concrete replace
fill ~99 ~140 ~386 ~113 ~140 ~386 minecraft:light_gray_concrete replace
fill ~112 ~140 ~387 ~112 ~140 ~388 minecraft:light_gray_concrete replace
fill ~81 ~140 ~398 ~83 ~140 ~398 minecraft:light_gray_concrete replace
fill ~82 ~140 ~399 ~82 ~140 ~400 minecraft:light_gray_concrete replace
fill ~87 ~140 ~446 ~116 ~140 ~446 minecraft:light_gray_concrete replace
fill ~88 ~140 ~447 ~88 ~140 ~448 minecraft:light_gray_concrete replace
fill ~91 ~140 ~447 ~91 ~140 ~448 minecraft:light_gray_concrete replace
fill ~94 ~140 ~447 ~94 ~140 ~448 minecraft:light_gray_concrete replace
fill ~97 ~140 ~447 ~97 ~140 ~448 minecraft:light_gray_concrete replace
fill ~100 ~140 ~447 ~100 ~140 ~448 minecraft:light_gray_concrete replace
fill ~103 ~140 ~447 ~103 ~140 ~448 minecraft:light_gray_concrete replace
fill ~106 ~140 ~447 ~106 ~140 ~448 minecraft:light_gray_concrete replace
fill ~115 ~140 ~447 ~115 ~140 ~448 minecraft:light_gray_concrete replace
fill ~78 ~140 ~450 ~80 ~140 ~450 minecraft:light_gray_concrete replace
fill ~79 ~140 ~451 ~79 ~140 ~452 minecraft:light_gray_concrete replace
fill ~87 ~140 ~474 ~122 ~140 ~474 minecraft:light_gray_concrete replace
fill ~88 ~140 ~475 ~88 ~140 ~476 minecraft:light_gray_concrete replace
fill ~94 ~140 ~475 ~94 ~140 ~476 minecraft:light_gray_concrete replace
fill ~97 ~140 ~475 ~97 ~140 ~476 minecraft:light_gray_concrete replace
fill ~100 ~140 ~475 ~100 ~140 ~476 minecraft:light_gray_concrete replace
fill ~106 ~140 ~475 ~106 ~140 ~476 minecraft:light_gray_concrete replace
fill ~109 ~140 ~475 ~109 ~140 ~476 minecraft:light_gray_concrete replace
fill ~121 ~140 ~475 ~121 ~140 ~476 minecraft:light_gray_concrete replace
fill ~87 ~140 ~482 ~119 ~140 ~482 minecraft:light_gray_concrete replace
fill ~88 ~140 ~483 ~88 ~140 ~484 minecraft:light_gray_concrete replace
fill ~91 ~140 ~483 ~91 ~140 ~484 minecraft:light_gray_concrete replace
fill ~97 ~140 ~483 ~97 ~140 ~484 minecraft:light_gray_concrete replace
fill ~103 ~140 ~483 ~103 ~140 ~484 minecraft:light_gray_concrete replace
fill ~109 ~140 ~483 ~109 ~140 ~484 minecraft:light_gray_concrete replace
fill ~118 ~140 ~483 ~118 ~140 ~484 minecraft:light_gray_concrete replace
fill ~90 ~140 ~502 ~122 ~140 ~502 minecraft:light_gray_concrete replace
fill ~91 ~140 ~503 ~91 ~140 ~504 minecraft:light_gray_concrete replace
fill ~94 ~140 ~503 ~94 ~140 ~504 minecraft:light_gray_concrete replace
fill ~100 ~140 ~503 ~100 ~140 ~504 minecraft:light_gray_concrete replace
fill ~106 ~140 ~503 ~106 ~140 ~504 minecraft:light_gray_concrete replace
fill ~109 ~140 ~503 ~109 ~140 ~504 minecraft:light_gray_concrete replace
fill ~115 ~140 ~503 ~115 ~140 ~504 minecraft:light_gray_concrete replace
fill ~121 ~140 ~503 ~121 ~140 ~504 minecraft:light_gray_concrete replace
fill ~102 ~140 ~514 ~149 ~140 ~514 minecraft:light_gray_concrete replace
fill ~124 ~140 ~515 ~124 ~140 ~516 minecraft:light_gray_concrete replace
fill ~127 ~140 ~515 ~127 ~140 ~516 minecraft:light_gray_concrete replace
fill ~130 ~140 ~515 ~130 ~140 ~516 minecraft:light_gray_concrete replace
fill ~133 ~140 ~515 ~133 ~140 ~516 minecraft:light_gray_concrete replace
fill ~136 ~140 ~515 ~136 ~140 ~516 minecraft:light_gray_concrete replace
fill ~139 ~140 ~515 ~139 ~140 ~516 minecraft:light_gray_concrete replace
fill ~142 ~140 ~515 ~142 ~140 ~516 minecraft:light_gray_concrete replace
fill ~148 ~140 ~515 ~148 ~140 ~516 minecraft:light_gray_concrete replace
fill ~108 ~140 ~538 ~155 ~140 ~538 minecraft:light_gray_concrete replace
fill ~124 ~140 ~539 ~124 ~140 ~540 minecraft:light_gray_concrete replace
fill ~130 ~140 ~539 ~130 ~140 ~540 minecraft:light_gray_concrete replace
fill ~133 ~140 ~539 ~133 ~140 ~540 minecraft:light_gray_concrete replace
fill ~136 ~140 ~539 ~136 ~140 ~540 minecraft:light_gray_concrete replace
fill ~142 ~140 ~539 ~142 ~140 ~540 minecraft:light_gray_concrete replace
fill ~145 ~140 ~539 ~145 ~140 ~540 minecraft:light_gray_concrete replace
fill ~154 ~140 ~539 ~154 ~140 ~540 minecraft:light_gray_concrete replace
fill ~105 ~140 ~546 ~152 ~140 ~546 minecraft:light_gray_concrete replace
fill ~124 ~140 ~547 ~124 ~140 ~548 minecraft:light_gray_concrete replace
fill ~127 ~140 ~547 ~127 ~140 ~548 minecraft:light_gray_concrete replace
fill ~133 ~140 ~547 ~133 ~140 ~548 minecraft:light_gray_concrete replace
fill ~139 ~140 ~547 ~139 ~140 ~548 minecraft:light_gray_concrete replace
fill ~145 ~140 ~547 ~145 ~140 ~548 minecraft:light_gray_concrete replace
fill ~151 ~140 ~547 ~151 ~140 ~548 minecraft:light_gray_concrete replace
fill ~111 ~140 ~566 ~155 ~140 ~566 minecraft:light_gray_concrete replace
fill ~127 ~140 ~567 ~127 ~140 ~568 minecraft:light_gray_concrete replace
fill ~130 ~140 ~567 ~130 ~140 ~568 minecraft:light_gray_concrete replace
fill ~136 ~140 ~567 ~136 ~140 ~568 minecraft:light_gray_concrete replace
fill ~142 ~140 ~567 ~142 ~140 ~568 minecraft:light_gray_concrete replace
fill ~145 ~140 ~567 ~145 ~140 ~568 minecraft:light_gray_concrete replace
fill ~148 ~140 ~567 ~148 ~140 ~568 minecraft:light_gray_concrete replace
fill ~154 ~140 ~567 ~154 ~140 ~568 minecraft:light_gray_concrete replace
fill ~114 ~140 ~578 ~173 ~140 ~578 minecraft:light_gray_concrete replace
fill ~157 ~140 ~579 ~157 ~140 ~580 minecraft:light_gray_concrete replace
fill ~160 ~140 ~579 ~160 ~140 ~580 minecraft:light_gray_concrete replace
fill ~163 ~140 ~579 ~163 ~140 ~580 minecraft:light_gray_concrete replace
fill ~166 ~140 ~579 ~166 ~140 ~580 minecraft:light_gray_concrete replace
fill ~172 ~140 ~579 ~172 ~140 ~580 minecraft:light_gray_concrete replace
fill ~120 ~140 ~610 ~176 ~140 ~610 minecraft:light_gray_concrete replace
fill ~160 ~140 ~611 ~160 ~140 ~612 minecraft:light_gray_concrete replace
fill ~163 ~140 ~611 ~163 ~140 ~612 minecraft:light_gray_concrete replace
fill ~166 ~140 ~611 ~166 ~140 ~612 minecraft:light_gray_concrete replace
fill ~169 ~140 ~611 ~169 ~140 ~612 minecraft:light_gray_concrete replace
fill ~175 ~140 ~611 ~175 ~140 ~612 minecraft:light_gray_concrete replace
fill ~117 ~140 ~622 ~176 ~140 ~622 minecraft:light_gray_concrete replace
fill ~157 ~140 ~623 ~157 ~140 ~624 minecraft:light_gray_concrete replace
fill ~160 ~140 ~623 ~160 ~140 ~624 minecraft:light_gray_concrete replace
fill ~163 ~140 ~623 ~163 ~140 ~624 minecraft:light_gray_concrete replace
fill ~166 ~140 ~623 ~166 ~140 ~624 minecraft:light_gray_concrete replace
fill ~169 ~140 ~623 ~169 ~140 ~624 minecraft:light_gray_concrete replace
fill ~172 ~140 ~623 ~172 ~140 ~624 minecraft:light_gray_concrete replace
fill ~175 ~140 ~623 ~175 ~140 ~624 minecraft:light_gray_concrete replace
fill ~129 ~140 ~646 ~185 ~140 ~646 minecraft:light_gray_concrete replace
fill ~184 ~140 ~647 ~184 ~140 ~648 minecraft:light_gray_concrete replace
fill ~84 ~140 ~650 ~86 ~140 ~650 minecraft:light_gray_concrete replace
fill ~85 ~140 ~651 ~85 ~140 ~652 minecraft:light_gray_concrete replace
fill ~123 ~140 ~654 ~179 ~140 ~654 minecraft:light_gray_concrete replace
fill ~178 ~140 ~655 ~178 ~140 ~656 minecraft:light_gray_concrete replace
fill ~126 ~140 ~662 ~182 ~140 ~662 minecraft:light_gray_concrete replace
fill ~181 ~140 ~663 ~181 ~140 ~664 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~386 minecraft:light_gray_concrete replace
setblock ~108 ~141 ~386 minecraft:light_gray_concrete replace
setblock ~112 ~141 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~141 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~91 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~94 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~100 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~103 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~115 ~141 ~448 minecraft:light_gray_concrete replace
setblock ~79 ~141 ~452 minecraft:light_gray_concrete replace
setblock ~88 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~94 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~97 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~100 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~476 minecraft:light_gray_concrete replace
setblock ~88 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~91 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~97 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~141 ~484 minecraft:light_gray_concrete replace
setblock ~91 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~94 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~115 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~504 minecraft:light_gray_concrete replace
setblock ~109 ~141 ~514 minecraft:light_gray_concrete replace
setblock ~111 ~141 ~514 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~139 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~142 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~148 ~141 ~516 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~123 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~140 ~141 ~538 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~142 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~145 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~154 ~141 ~540 minecraft:light_gray_concrete replace
setblock ~118 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~120 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~135 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~137 ~141 ~546 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~145 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~141 ~548 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~123 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~140 ~141 ~566 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~145 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~148 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~141 ~568 minecraft:light_gray_concrete replace
setblock ~121 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~123 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~140 ~141 ~578 minecraft:light_gray_concrete replace
setblock ~157 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~160 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~163 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~172 ~141 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~129 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~144 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~146 ~141 ~610 minecraft:light_gray_concrete replace
setblock ~160 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~163 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~169 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~175 ~141 ~612 minecraft:light_gray_concrete replace
setblock ~124 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~126 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~141 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~143 ~141 ~622 minecraft:light_gray_concrete replace
setblock ~157 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~160 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~163 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~169 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~172 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~175 ~141 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~138 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~153 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~155 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~170 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~172 ~141 ~646 minecraft:light_gray_concrete replace
setblock ~184 ~141 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~141 ~652 minecraft:light_gray_concrete replace
setblock ~130 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~132 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~147 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~149 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~164 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~166 ~141 ~654 minecraft:light_gray_concrete replace
setblock ~178 ~141 ~656 minecraft:light_gray_concrete replace
setblock ~133 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~135 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~150 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~152 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~167 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~169 ~141 ~662 minecraft:light_gray_concrete replace
setblock ~181 ~141 ~664 minecraft:light_gray_concrete replace
fill ~111 ~142 ~384 ~111 ~142 ~388 minecraft:light_gray_concrete replace
fill ~81 ~142 ~396 ~81 ~142 ~400 minecraft:light_gray_concrete replace
fill ~114 ~142 ~416 ~114 ~142 ~504 minecraft:light_gray_concrete replace
fill ~105 ~142 ~420 ~105 ~142 ~504 minecraft:light_gray_concrete replace
fill ~102 ~142 ~424 ~102 ~142 ~484 minecraft:light_gray_concrete replace
fill ~99 ~142 ~428 ~99 ~142 ~504 minecraft:light_gray_concrete replace
fill ~96 ~142 ~432 ~96 ~142 ~484 minecraft:light_gray_concrete replace
fill ~93 ~142 ~436 ~93 ~142 ~504 minecraft:light_gray_concrete replace
fill ~90 ~142 ~440 ~90 ~142 ~504 minecraft:light_gray_concrete replace
fill ~87 ~142 ~444 ~87 ~142 ~484 minecraft:light_gray_concrete replace
fill ~78 ~142 ~448 ~78 ~142 ~452 minecraft:light_gray_concrete replace
fill ~120 ~142 ~468 ~120 ~142 ~504 minecraft:light_gray_concrete replace
fill ~108 ~142 ~472 ~108 ~142 ~504 minecraft:light_gray_concrete replace
fill ~117 ~142 ~480 ~117 ~142 ~484 minecraft:light_gray_concrete replace
fill ~147 ~142 ~484 ~147 ~142 ~568 minecraft:light_gray_concrete replace
fill ~141 ~142 ~488 ~141 ~142 ~568 minecraft:light_gray_concrete replace
fill ~138 ~142 ~492 ~138 ~142 ~548 minecraft:light_gray_concrete replace
fill ~135 ~142 ~496 ~135 ~142 ~568 minecraft:light_gray_concrete replace
fill ~132 ~142 ~500 ~132 ~142 ~548 minecraft:light_gray_concrete replace
fill ~129 ~142 ~504 ~129 ~142 ~568 minecraft:light_gray_concrete replace
fill ~126 ~142 ~508 ~126 ~142 ~568 minecraft:light_gray_concrete replace
fill ~123 ~142 ~512 ~123 ~142 ~548 minecraft:light_gray_concrete replace
fill ~153 ~142 ~532 ~153 ~142 ~568 minecraft:light_gray_concrete replace
fill ~144 ~142 ~536 ~144 ~142 ~568 minecraft:light_gray_concrete replace
fill ~150 ~142 ~544 ~150 ~142 ~548 minecraft:light_gray_concrete replace
fill ~171 ~142 ~560 ~171 ~142 ~624 minecraft:light_gray_concrete replace
fill ~165 ~142 ~564 ~165 ~142 ~624 minecraft:light_gray_concrete replace
fill ~162 ~142 ~568 ~162 ~142 ~624 minecraft:light_gray_concrete replace
fill ~159 ~142 ~572 ~159 ~142 ~624 minecraft:light_gray_concrete replace
fill ~156 ~142 ~576 ~156 ~142 ~624 minecraft:light_gray_concrete replace
fill ~174 ~142 ~604 ~174 ~142 ~624 minecraft:light_gray_concrete replace
fill ~168 ~142 ~608 ~168 ~142 ~624 minecraft:light_gray_concrete replace
fill ~183 ~142 ~644 ~183 ~142 ~648 minecraft:light_gray_concrete replace
fill ~84 ~142 ~648 ~84 ~142 ~652 minecraft:light_gray_concrete replace
fill ~177 ~142 ~652 ~177 ~142 ~656 minecraft:light_gray_concrete replace
fill ~180 ~142 ~660 ~180 ~142 ~664 minecraft:light_gray_concrete replace
setblock ~111 ~143 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~143 ~395 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~415 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~417 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~419 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~423 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~425 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~425 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~427 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~427 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~429 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~431 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~435 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~437 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~437 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~439 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~439 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~439 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~441 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~441 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~445 minecraft:light_gray_concrete replace
setblock ~78 ~143 ~447 minecraft:light_gray_concrete replace
setblock ~91 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~97 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~106 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~115 ~143 ~448 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~453 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~453 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~453 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~455 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~455 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~455 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~457 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~457 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~459 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~461 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~461 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~461 minecraft:light_gray_concrete replace
setblock ~120 ~143 ~467 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~469 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~469 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~469 minecraft:light_gray_concrete replace
setblock ~87 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~96 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~102 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~108 ~143 ~471 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~473 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~473 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~475 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~475 minecraft:light_gray_concrete replace
setblock ~94 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~106 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~109 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~121 ~143 ~476 minecraft:light_gray_concrete replace
setblock ~117 ~143 ~479 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~483 minecraft:light_gray_concrete replace
setblock ~88 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~97 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~103 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~118 ~143 ~484 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~487 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~108 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~120 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~489 minecraft:light_gray_concrete replace
setblock ~90 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~93 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~99 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~105 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~114 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~120 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~493 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~493 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~495 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~497 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~499 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~501 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~501 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~503 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~503 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~503 minecraft:light_gray_concrete replace
setblock ~94 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~106 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~115 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~121 ~143 ~504 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~505 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~507 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~509 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~511 minecraft:light_gray_concrete replace
setblock ~127 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~133 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~142 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~148 ~143 ~516 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~517 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~517 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~517 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~519 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~519 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~519 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~521 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~521 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~523 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~525 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~525 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~525 minecraft:light_gray_concrete replace
setblock ~153 ~143 ~531 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~533 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~533 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~533 minecraft:light_gray_concrete replace
setblock ~123 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~132 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~138 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~144 ~143 ~535 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~537 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~537 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~539 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~539 minecraft:light_gray_concrete replace
setblock ~130 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~142 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~145 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~154 ~143 ~540 minecraft:light_gray_concrete replace
setblock ~150 ~143 ~543 minecraft:light_gray_concrete replace
setblock ~124 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~133 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~151 ~143 ~548 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~144 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~153 ~143 ~553 minecraft:light_gray_concrete replace
setblock ~126 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~129 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~135 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~141 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~144 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~147 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~143 ~555 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~559 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~563 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~563 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~565 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~565 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~567 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~567 minecraft:light_gray_concrete replace
setblock ~130 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~136 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~142 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~148 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~154 ~143 ~568 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~569 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~571 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~573 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~575 minecraft:light_gray_concrete replace
setblock ~157 ~143 ~580 minecraft:light_gray_concrete replace
setblock ~166 ~143 ~580 minecraft:light_gray_concrete replace
setblock ~172 ~143 ~580 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~593 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~593 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~595 minecraft:light_gray_concrete replace
setblock ~159 ~143 ~597 minecraft:light_gray_concrete replace
setblock ~162 ~143 ~597 minecraft:light_gray_concrete replace
setblock ~165 ~143 ~597 minecraft:light_gray_concrete replace
setblock ~174 ~143 ~603 minecraft:light_gray_concrete replace
setblock ~168 ~143 ~607 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~609 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~609 minecraft:light_gray_concrete replace
setblock ~156 ~143 ~611 minecraft:light_gray_concrete replace
setblock ~171 ~143 ~611 minecraft:light_gray_concrete replace
setblock ~160 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~166 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~169 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~175 ~143 ~612 minecraft:light_gray_concrete replace
setblock ~160 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~163 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~166 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~172 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~175 ~143 ~624 minecraft:light_gray_concrete replace
setblock ~183 ~143 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~143 ~647 minecraft:light_gray_concrete replace
setblock ~177 ~143 ~651 minecraft:light_gray_concrete replace
setblock ~180 ~143 ~659 minecraft:light_gray_concrete replace
fill ~97 ~144 ~380 ~97 ~144 ~381 minecraft:light_gray_concrete replace
fill ~96 ~144 ~382 ~111 ~144 ~382 minecraft:light_gray_concrete replace
fill ~82 ~144 ~392 ~82 ~144 ~393 minecraft:light_gray_concrete replace
fill ~81 ~144 ~394 ~83 ~144 ~394 minecraft:light_gray_concrete replace
fill ~100 ~144 ~412 ~100 ~144 ~413 minecraft:light_gray_concrete replace
fill ~99 ~144 ~414 ~114 ~144 ~414 minecraft:light_gray_concrete replace
fill ~94 ~144 ~416 ~94 ~144 ~417 minecraft:light_gray_concrete replace
fill ~93 ~144 ~418 ~105 ~144 ~418 minecraft:light_gray_concrete replace
fill ~94 ~144 ~420 ~94 ~144 ~421 minecraft:light_gray_concrete replace
fill ~93 ~144 ~422 ~102 ~144 ~422 minecraft:light_gray_concrete replace
fill ~91 ~144 ~424 ~91 ~144 ~425 minecraft:light_gray_concrete replace
fill ~90 ~144 ~426 ~99 ~144 ~426 minecraft:light_gray_concrete replace
fill ~91 ~144 ~428 ~91 ~144 ~429 minecraft:light_gray_concrete replace
fill ~90 ~144 ~430 ~96 ~144 ~430 minecraft:light_gray_concrete replace
fill ~88 ~144 ~432 ~88 ~144 ~433 minecraft:light_gray_concrete replace
fill ~87 ~144 ~434 ~93 ~144 ~434 minecraft:light_gray_concrete replace
fill ~88 ~144 ~436 ~88 ~144 ~437 minecraft:light_gray_concrete replace
fill ~87 ~144 ~438 ~90 ~144 ~438 minecraft:light_gray_concrete replace
fill ~88 ~144 ~440 ~88 ~144 ~441 minecraft:light_gray_concrete replace
fill ~87 ~144 ~442 ~89 ~144 ~442 minecraft:light_gray_concrete replace
fill ~79 ~144 ~444 ~79 ~144 ~445 minecraft:light_gray_concrete replace
fill ~78 ~144 ~446 ~80 ~144 ~446 minecraft:light_gray_concrete replace
fill ~100 ~144 ~464 ~100 ~144 ~465 minecraft:light_gray_concrete replace
fill ~99 ~144 ~466 ~120 ~144 ~466 minecraft:light_gray_concrete replace
fill ~94 ~144 ~468 ~94 ~144 ~469 minecraft:light_gray_concrete replace
fill ~93 ~144 ~470 ~108 ~144 ~470 minecraft:light_gray_concrete replace
fill ~100 ~144 ~476 ~100 ~144 ~477 minecraft:light_gray_concrete replace
fill ~99 ~144 ~478 ~117 ~144 ~478 minecraft:light_gray_concrete replace
fill ~112 ~144 ~480 ~112 ~144 ~481 minecraft:light_gray_concrete replace
fill ~111 ~144 ~482 ~147 ~144 ~482 minecraft:light_gray_concrete replace
fill ~109 ~144 ~484 ~109 ~144 ~485 minecraft:light_gray_concrete replace
fill ~108 ~144 ~486 ~141 ~144 ~486 minecraft:light_gray_concrete replace
fill ~109 ~144 ~488 ~109 ~144 ~489 minecraft:light_gray_concrete replace
fill ~108 ~144 ~490 ~138 ~144 ~490 minecraft:light_gray_concrete replace
fill ~106 ~144 ~492 ~106 ~144 ~493 minecraft:light_gray_concrete replace
fill ~105 ~144 ~494 ~135 ~144 ~494 minecraft:light_gray_concrete replace
fill ~106 ~144 ~496 ~106 ~144 ~497 minecraft:light_gray_concrete replace
fill ~105 ~144 ~498 ~132 ~144 ~498 minecraft:light_gray_concrete replace
fill ~103 ~144 ~500 ~103 ~144 ~501 minecraft:light_gray_concrete replace
fill ~102 ~144 ~502 ~129 ~144 ~502 minecraft:light_gray_concrete replace
fill ~103 ~144 ~504 ~103 ~144 ~505 minecraft:light_gray_concrete replace
fill ~102 ~144 ~506 ~126 ~144 ~506 minecraft:light_gray_concrete replace
fill ~103 ~144 ~508 ~103 ~144 ~509 minecraft:light_gray_concrete replace
fill ~102 ~144 ~510 ~123 ~144 ~510 minecraft:light_gray_concrete replace
fill ~112 ~144 ~528 ~112 ~144 ~529 minecraft:light_gray_concrete replace
fill ~111 ~144 ~530 ~153 ~144 ~530 minecraft:light_gray_concrete replace
fill ~109 ~144 ~532 ~109 ~144 ~533 minecraft:light_gray_concrete replace
fill ~108 ~144 ~534 ~144 ~144 ~534 minecraft:light_gray_concrete replace
fill ~112 ~144 ~540 ~112 ~144 ~541 minecraft:light_gray_concrete replace
fill ~111 ~144 ~542 ~150 ~144 ~542 minecraft:light_gray_concrete replace
fill ~124 ~144 ~556 ~124 ~144 ~557 minecraft:light_gray_concrete replace
fill ~123 ~144 ~558 ~171 ~144 ~558 minecraft:light_gray_concrete replace
fill ~121 ~144 ~560 ~121 ~144 ~561 minecraft:light_gray_concrete replace
fill ~120 ~144 ~562 ~165 ~144 ~562 minecraft:light_gray_concrete replace
fill ~118 ~144 ~564 ~118 ~144 ~565 minecraft:light_gray_concrete replace
fill ~117 ~144 ~566 ~162 ~144 ~566 minecraft:light_gray_concrete replace
fill ~115 ~144 ~568 ~115 ~144 ~569 minecraft:light_gray_concrete replace
fill ~114 ~144 ~570 ~159 ~144 ~570 minecraft:light_gray_concrete replace
fill ~115 ~144 ~572 ~115 ~144 ~573 minecraft:light_gray_concrete replace
fill ~114 ~144 ~574 ~156 ~144 ~574 minecraft:light_gray_concrete replace
fill ~124 ~144 ~600 ~124 ~144 ~601 minecraft:light_gray_concrete replace
fill ~123 ~144 ~602 ~174 ~144 ~602 minecraft:light_gray_concrete replace
fill ~121 ~144 ~604 ~121 ~144 ~605 minecraft:light_gray_concrete replace
fill ~120 ~144 ~606 ~168 ~144 ~606 minecraft:light_gray_concrete replace
fill ~133 ~144 ~640 ~133 ~144 ~641 minecraft:light_gray_concrete replace
fill ~132 ~144 ~642 ~183 ~144 ~642 minecraft:light_gray_concrete replace
fill ~85 ~144 ~644 ~85 ~144 ~645 minecraft:light_gray_concrete replace
fill ~84 ~144 ~646 ~86 ~144 ~646 minecraft:light_gray_concrete replace
fill ~127 ~144 ~648 ~127 ~144 ~649 minecraft:light_gray_concrete replace
fill ~126 ~144 ~650 ~177 ~144 ~650 minecraft:light_gray_concrete replace
fill ~130 ~144 ~656 ~130 ~144 ~657 minecraft:light_gray_concrete replace
fill ~129 ~144 ~658 ~180 ~144 ~658 minecraft:light_gray_concrete replace
setblock ~97 ~145 ~380 minecraft:light_gray_concrete replace
setblock ~102 ~145 ~382 minecraft:light_gray_concrete replace
setblock ~104 ~145 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~145 ~392 minecraft:light_gray_concrete replace
setblock ~100 ~145 ~412 minecraft:light_gray_concrete replace
setblock ~94 ~145 ~416 minecraft:light_gray_concrete replace
setblock ~97 ~145 ~418 minecraft:light_gray_concrete replace
setblock ~99 ~145 ~418 minecraft:light_gray_concrete replace
setblock ~94 ~145 ~420 minecraft:light_gray_concrete replace
setblock ~91 ~145 ~424 minecraft:light_gray_concrete replace
setblock ~91 ~145 ~428 minecraft:light_gray_concrete replace
setblock ~88 ~145 ~432 minecraft:light_gray_concrete replace
setblock ~88 ~145 ~436 minecraft:light_gray_concrete replace
setblock ~88 ~145 ~440 minecraft:light_gray_concrete replace
setblock ~79 ~145 ~444 minecraft:light_gray_concrete replace
setblock ~100 ~145 ~464 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~466 minecraft:light_gray_concrete replace
setblock ~114 ~145 ~466 minecraft:light_gray_concrete replace
setblock ~94 ~145 ~468 minecraft:light_gray_concrete replace
setblock ~96 ~145 ~470 minecraft:light_gray_concrete replace
setblock ~98 ~145 ~470 minecraft:light_gray_concrete replace
setblock ~100 ~145 ~476 minecraft:light_gray_concrete replace
setblock ~108 ~145 ~478 minecraft:light_gray_concrete replace
setblock ~110 ~145 ~478 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~480 minecraft:light_gray_concrete replace
setblock ~120 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~122 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~137 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~139 ~145 ~482 minecraft:light_gray_concrete replace
setblock ~109 ~145 ~484 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~114 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~129 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~131 ~145 ~486 minecraft:light_gray_concrete replace
setblock ~109 ~145 ~488 minecraft:light_gray_concrete replace
setblock ~123 ~145 ~490 minecraft:light_gray_concrete replace
setblock ~125 ~145 ~490 minecraft:light_gray_concrete replace
setblock ~106 ~145 ~492 minecraft:light_gray_concrete replace
setblock ~120 ~145 ~494 minecraft:light_gray_concrete replace
setblock ~122 ~145 ~494 minecraft:light_gray_concrete replace
setblock ~106 ~145 ~496 minecraft:light_gray_concrete replace
setblock ~118 ~145 ~498 minecraft:light_gray_concrete replace
setblock ~120 ~145 ~498 minecraft:light_gray_concrete replace
setblock ~103 ~145 ~500 minecraft:light_gray_concrete replace
setblock ~117 ~145 ~502 minecraft:light_gray_concrete replace
setblock ~119 ~145 ~502 minecraft:light_gray_concrete replace
setblock ~103 ~145 ~504 minecraft:light_gray_concrete replace
setblock ~111 ~145 ~506 minecraft:light_gray_concrete replace
setblock ~113 ~145 ~506 minecraft:light_gray_concrete replace
setblock ~103 ~145 ~508 minecraft:light_gray_concrete replace
setblock ~114 ~145 ~510 minecraft:light_gray_concrete replace
setblock ~116 ~145 ~510 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~528 minecraft:light_gray_concrete replace
setblock ~128 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~130 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~145 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~147 ~145 ~530 minecraft:light_gray_concrete replace
setblock ~109 ~145 ~532 minecraft:light_gray_concrete replace
setblock ~115 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~117 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~132 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~534 minecraft:light_gray_concrete replace
setblock ~112 ~145 ~540 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~126 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~141 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~143 ~145 ~542 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~556 minecraft:light_gray_concrete replace
setblock ~125 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~142 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~144 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~159 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~161 ~145 ~558 minecraft:light_gray_concrete replace
setblock ~121 ~145 ~560 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~136 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~151 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~153 ~145 ~562 minecraft:light_gray_concrete replace
setblock ~118 ~145 ~564 minecraft:light_gray_concrete replace
setblock ~130 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~132 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~147 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~149 ~145 ~566 minecraft:light_gray_concrete replace
setblock ~115 ~145 ~568 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~129 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~144 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~146 ~145 ~570 minecraft:light_gray_concrete replace
setblock ~115 ~145 ~572 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~129 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~144 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~146 ~145 ~574 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~600 minecraft:light_gray_concrete replace
setblock ~132 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~149 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~151 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~166 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~168 ~145 ~602 minecraft:light_gray_concrete replace
setblock ~121 ~145 ~604 minecraft:light_gray_concrete replace
setblock ~122 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~124 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~139 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~141 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~156 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~158 ~145 ~606 minecraft:light_gray_concrete replace
setblock ~133 ~145 ~640 minecraft:light_gray_concrete replace
setblock ~140 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~142 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~157 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~159 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~174 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~176 ~145 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~145 ~644 minecraft:light_gray_concrete replace
setblock ~127 ~145 ~648 minecraft:light_gray_concrete replace
setblock ~134 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~136 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~151 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~153 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~168 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~170 ~145 ~650 minecraft:light_gray_concrete replace
setblock ~130 ~145 ~656 minecraft:light_gray_concrete replace
setblock ~137 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~139 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~154 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~156 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~171 ~145 ~658 minecraft:light_gray_concrete replace
setblock ~173 ~145 ~658 minecraft:light_gray_concrete replace
fill ~96 ~146 ~380 ~96 ~146 ~384 minecraft:light_gray_concrete replace
fill ~81 ~146 ~392 ~81 ~146 ~396 minecraft:light_gray_concrete replace
fill ~99 ~146 ~412 ~99 ~146 ~480 minecraft:light_gray_concrete replace
fill ~93 ~146 ~416 ~93 ~146 ~472 minecraft:light_gray_concrete replace
fill ~90 ~146 ~424 ~90 ~146 ~432 minecraft:light_gray_concrete replace
fill ~87 ~146 ~432 ~87 ~146 ~444 minecraft:light_gray_concrete replace
fill ~78 ~146 ~444 ~78 ~146 ~448 minecraft:light_gray_concrete replace
fill ~111 ~146 ~480 ~111 ~146 ~544 minecraft:light_gray_concrete replace
fill ~108 ~146 ~484 ~108 ~146 ~536 minecraft:light_gray_concrete replace
fill ~105 ~146 ~492 ~105 ~146 ~500 minecraft:light_gray_concrete replace
fill ~102 ~146 ~500 ~102 ~146 ~512 minecraft:light_gray_concrete replace
fill ~123 ~146 ~556 ~123 ~146 ~604 minecraft:light_gray_concrete replace
fill ~120 ~146 ~560 ~120 ~146 ~608 minecraft:light_gray_concrete replace
fill ~117 ~146 ~564 ~117 ~146 ~568 minecraft:light_gray_concrete replace
fill ~114 ~146 ~568 ~114 ~146 ~576 minecraft:light_gray_concrete replace
fill ~132 ~146 ~640 ~132 ~146 ~644 minecraft:light_gray_concrete replace
fill ~84 ~146 ~644 ~84 ~146 ~648 minecraft:light_gray_concrete replace
fill ~126 ~146 ~648 ~126 ~146 ~652 minecraft:light_gray_concrete replace
fill ~129 ~146 ~656 ~129 ~146 ~660 minecraft:light_gray_concrete replace
setblock ~96 ~147 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~147 ~397 minecraft:light_gray_concrete replace
setblock ~100 ~147 ~412 minecraft:light_gray_concrete replace
setblock ~94 ~147 ~416 minecraft:light_gray_concrete replace
setblock ~94 ~147 ~420 minecraft:light_gray_concrete replace
setblock ~91 ~147 ~424 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~425 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~427 minecraft:light_gray_concrete replace
setblock ~91 ~147 ~428 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~429 minecraft:light_gray_concrete replace
setblock ~90 ~147 ~431 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~431 minecraft:light_gray_concrete replace
setblock ~88 ~147 ~432 minecraft:light_gray_concrete replace
setblock ~90 ~147 ~433 minecraft:light_gray_concrete replace
setblock ~88 ~147 ~436 minecraft:light_gray_concrete replace
setblock ~88 ~147 ~440 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~441 minecraft:light_gray_concrete replace
setblock ~87 ~147 ~443 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~147 ~445 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~445 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~447 minecraft:light_gray_concrete replace
setblock ~78 ~147 ~449 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~457 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~459 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~461 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~463 minecraft:light_gray_concrete replace
setblock ~100 ~147 ~464 minecraft:light_gray_concrete replace
setblock ~94 ~147 ~468 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~471 minecraft:light_gray_concrete replace
setblock ~93 ~147 ~473 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~473 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~475 minecraft:light_gray_concrete replace
setblock ~100 ~147 ~476 minecraft:light_gray_concrete replace
setblock ~112 ~147 ~480 minecraft:light_gray_concrete replace
setblock ~99 ~147 ~481 minecraft:light_gray_concrete replace
setblock ~109 ~147 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~147 ~488 minecraft:light_gray_concrete replace
setblock ~106 ~147 ~492 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~493 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~495 minecraft:light_gray_concrete replace
setblock ~106 ~147 ~496 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~497 minecraft:light_gray_concrete replace
setblock ~105 ~147 ~499 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~499 minecraft:light_gray_concrete replace
setblock ~103 ~147 ~500 minecraft:light_gray_concrete replace
setblock ~105 ~147 ~501 minecraft:light_gray_concrete replace
setblock ~103 ~147 ~504 minecraft:light_gray_concrete replace
setblock ~103 ~147 ~508 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~509 minecraft:light_gray_concrete replace
setblock ~102 ~147 ~511 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~511 minecraft:light_gray_concrete replace
setblock ~102 ~147 ~513 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~513 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~515 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~525 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~527 minecraft:light_gray_concrete replace
setblock ~112 ~147 ~528 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~529 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~531 minecraft:light_gray_concrete replace
setblock ~109 ~147 ~532 minecraft:light_gray_concrete replace
setblock ~108 ~147 ~537 minecraft:light_gray_concrete replace
setblock ~112 ~147 ~540 minecraft:light_gray_concrete replace
setblock ~111 ~147 ~545 minecraft:light_gray_concrete replace
setblock ~124 ~147 ~556 minecraft:light_gray_concrete replace
setblock ~121 ~147 ~560 minecraft:light_gray_concrete replace
setblock ~118 ~147 ~564 minecraft:light_gray_concrete replace
setblock ~115 ~147 ~568 minecraft:light_gray_concrete replace
setblock ~117 ~147 ~569 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~569 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~571 minecraft:light_gray_concrete replace
setblock ~115 ~147 ~572 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~573 minecraft:light_gray_concrete replace
setblock ~114 ~147 ~575 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~575 minecraft:light_gray_concrete replace
setblock ~114 ~147 ~577 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~585 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~587 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~589 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~591 minecraft:light_gray_concrete replace
setblock ~124 ~147 ~600 minecraft:light_gray_concrete replace
setblock ~121 ~147 ~604 minecraft:light_gray_concrete replace
setblock ~123 ~147 ~605 minecraft:light_gray_concrete replace
setblock ~120 ~147 ~609 minecraft:light_gray_concrete replace
setblock ~132 ~147 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~147 ~649 minecraft:light_gray_concrete replace
setblock ~126 ~147 ~653 minecraft:light_gray_concrete replace
setblock ~129 ~147 ~661 minecraft:light_gray_concrete replace
fill ~96 ~148 ~386 ~233 ~148 ~386 minecraft:light_gray_concrete replace
fill ~232 ~148 ~387 ~232 ~148 ~388 minecraft:light_gray_concrete replace
fill ~81 ~148 ~398 ~83 ~148 ~398 minecraft:light_gray_concrete replace
fill ~82 ~148 ~399 ~82 ~148 ~400 minecraft:light_gray_concrete replace
fill ~84 ~148 ~434 ~230 ~148 ~434 minecraft:light_gray_concrete replace
fill ~85 ~148 ~435 ~85 ~148 ~436 minecraft:light_gray_concrete replace
fill ~88 ~148 ~435 ~88 ~148 ~436 minecraft:light_gray_concrete replace
fill ~91 ~148 ~435 ~91 ~148 ~436 minecraft:light_gray_concrete replace
fill ~94 ~148 ~435 ~94 ~148 ~436 minecraft:light_gray_concrete replace
fill ~97 ~148 ~435 ~97 ~148 ~436 minecraft:light_gray_concrete replace
fill ~100 ~148 ~435 ~100 ~148 ~436 minecraft:light_gray_concrete replace
fill ~103 ~148 ~435 ~103 ~148 ~436 minecraft:light_gray_concrete replace
fill ~106 ~148 ~435 ~106 ~148 ~436 minecraft:light_gray_concrete replace
fill ~109 ~148 ~435 ~109 ~148 ~436 minecraft:light_gray_concrete replace
fill ~112 ~148 ~435 ~112 ~148 ~436 minecraft:light_gray_concrete replace
fill ~115 ~148 ~435 ~115 ~148 ~436 minecraft:light_gray_concrete replace
fill ~118 ~148 ~435 ~118 ~148 ~436 minecraft:light_gray_concrete replace
fill ~121 ~148 ~435 ~121 ~148 ~436 minecraft:light_gray_concrete replace
fill ~124 ~148 ~435 ~124 ~148 ~436 minecraft:light_gray_concrete replace
fill ~127 ~148 ~435 ~127 ~148 ~436 minecraft:light_gray_concrete replace
fill ~130 ~148 ~435 ~130 ~148 ~436 minecraft:light_gray_concrete replace
fill ~133 ~148 ~435 ~133 ~148 ~436 minecraft:light_gray_concrete replace
fill ~136 ~148 ~435 ~136 ~148 ~436 minecraft:light_gray_concrete replace
fill ~139 ~148 ~435 ~139 ~148 ~436 minecraft:light_gray_concrete replace
fill ~142 ~148 ~435 ~142 ~148 ~436 minecraft:light_gray_concrete replace
fill ~145 ~148 ~435 ~145 ~148 ~436 minecraft:light_gray_concrete replace
fill ~148 ~148 ~435 ~148 ~148 ~436 minecraft:light_gray_concrete replace
fill ~151 ~148 ~435 ~151 ~148 ~436 minecraft:light_gray_concrete replace
fill ~154 ~148 ~435 ~154 ~148 ~436 minecraft:light_gray_concrete replace
fill ~157 ~148 ~435 ~157 ~148 ~436 minecraft:light_gray_concrete replace
fill ~160 ~148 ~435 ~160 ~148 ~436 minecraft:light_gray_concrete replace
fill ~163 ~148 ~435 ~163 ~148 ~436 minecraft:light_gray_concrete replace
fill ~166 ~148 ~435 ~166 ~148 ~436 minecraft:light_gray_concrete replace
fill ~169 ~148 ~435 ~169 ~148 ~436 minecraft:light_gray_concrete replace
fill ~172 ~148 ~435 ~172 ~148 ~436 minecraft:light_gray_concrete replace
fill ~175 ~148 ~435 ~175 ~148 ~436 minecraft:light_gray_concrete replace
fill ~178 ~148 ~435 ~178 ~148 ~436 minecraft:light_gray_concrete replace
fill ~181 ~148 ~435 ~181 ~148 ~436 minecraft:light_gray_concrete replace
fill ~184 ~148 ~435 ~184 ~148 ~436 minecraft:light_gray_concrete replace
fill ~187 ~148 ~435 ~187 ~148 ~436 minecraft:light_gray_concrete replace
fill ~190 ~148 ~435 ~190 ~148 ~436 minecraft:light_gray_concrete replace
fill ~193 ~148 ~435 ~193 ~148 ~436 minecraft:light_gray_concrete replace
fill ~196 ~148 ~435 ~196 ~148 ~436 minecraft:light_gray_concrete replace
fill ~199 ~148 ~435 ~199 ~148 ~436 minecraft:light_gray_concrete replace
fill ~202 ~148 ~435 ~202 ~148 ~436 minecraft:light_gray_concrete replace
fill ~205 ~148 ~435 ~205 ~148 ~436 minecraft:light_gray_concrete replace
fill ~208 ~148 ~435 ~208 ~148 ~436 minecraft:light_gray_concrete replace
fill ~211 ~148 ~435 ~211 ~148 ~436 minecraft:light_gray_concrete replace
fill ~214 ~148 ~435 ~214 ~148 ~436 minecraft:light_gray_concrete replace
fill ~217 ~148 ~435 ~217 ~148 ~436 minecraft:light_gray_concrete replace
fill ~220 ~148 ~435 ~220 ~148 ~436 minecraft:light_gray_concrete replace
fill ~223 ~148 ~435 ~223 ~148 ~436 minecraft:light_gray_concrete replace
fill ~226 ~148 ~435 ~226 ~148 ~436 minecraft:light_gray_concrete replace
fill ~229 ~148 ~435 ~229 ~148 ~436 minecraft:light_gray_concrete replace
fill ~84 ~148 ~446 ~230 ~148 ~446 minecraft:light_gray_concrete replace
fill ~85 ~148 ~447 ~85 ~148 ~448 minecraft:light_gray_concrete replace
fill ~88 ~148 ~447 ~88 ~148 ~448 minecraft:light_gray_concrete replace
fill ~91 ~148 ~447 ~91 ~148 ~448 minecraft:light_gray_concrete replace
fill ~94 ~148 ~447 ~94 ~148 ~448 minecraft:light_gray_concrete replace
fill ~97 ~148 ~447 ~97 ~148 ~448 minecraft:light_gray_concrete replace
fill ~100 ~148 ~447 ~100 ~148 ~448 minecraft:light_gray_concrete replace
fill ~103 ~148 ~447 ~103 ~148 ~448 minecraft:light_gray_concrete replace
fill ~106 ~148 ~447 ~106 ~148 ~448 minecraft:light_gray_concrete replace
fill ~109 ~148 ~447 ~109 ~148 ~448 minecraft:light_gray_concrete replace
fill ~112 ~148 ~447 ~112 ~148 ~448 minecraft:light_gray_concrete replace
fill ~115 ~148 ~447 ~115 ~148 ~448 minecraft:light_gray_concrete replace
fill ~118 ~148 ~447 ~118 ~148 ~448 minecraft:light_gray_concrete replace
fill ~121 ~148 ~447 ~121 ~148 ~448 minecraft:light_gray_concrete replace
fill ~124 ~148 ~447 ~124 ~148 ~448 minecraft:light_gray_concrete replace
fill ~127 ~148 ~447 ~127 ~148 ~448 minecraft:light_gray_concrete replace
fill ~130 ~148 ~447 ~130 ~148 ~448 minecraft:light_gray_concrete replace
fill ~133 ~148 ~447 ~133 ~148 ~448 minecraft:light_gray_concrete replace
fill ~136 ~148 ~447 ~136 ~148 ~448 minecraft:light_gray_concrete replace
fill ~139 ~148 ~447 ~139 ~148 ~448 minecraft:light_gray_concrete replace
fill ~142 ~148 ~447 ~142 ~148 ~448 minecraft:light_gray_concrete replace
fill ~145 ~148 ~447 ~145 ~148 ~448 minecraft:light_gray_concrete replace
fill ~148 ~148 ~447 ~148 ~148 ~448 minecraft:light_gray_concrete replace
fill ~151 ~148 ~447 ~151 ~148 ~448 minecraft:light_gray_concrete replace
fill ~154 ~148 ~447 ~154 ~148 ~448 minecraft:light_gray_concrete replace
fill ~157 ~148 ~447 ~157 ~148 ~448 minecraft:light_gray_concrete replace
fill ~160 ~148 ~447 ~160 ~148 ~448 minecraft:light_gray_concrete replace
fill ~163 ~148 ~447 ~163 ~148 ~448 minecraft:light_gray_concrete replace
fill ~166 ~148 ~447 ~166 ~148 ~448 minecraft:light_gray_concrete replace
fill ~169 ~148 ~447 ~169 ~148 ~448 minecraft:light_gray_concrete replace
fill ~172 ~148 ~447 ~172 ~148 ~448 minecraft:light_gray_concrete replace
fill ~175 ~148 ~447 ~175 ~148 ~448 minecraft:light_gray_concrete replace
fill ~178 ~148 ~447 ~178 ~148 ~448 minecraft:light_gray_concrete replace
fill ~181 ~148 ~447 ~181 ~148 ~448 minecraft:light_gray_concrete replace
fill ~184 ~148 ~447 ~184 ~148 ~448 minecraft:light_gray_concrete replace
fill ~187 ~148 ~447 ~187 ~148 ~448 minecraft:light_gray_concrete replace
fill ~190 ~148 ~447 ~190 ~148 ~448 minecraft:light_gray_concrete replace
fill ~193 ~148 ~447 ~193 ~148 ~448 minecraft:light_gray_concrete replace
fill ~196 ~148 ~447 ~196 ~148 ~448 minecraft:light_gray_concrete replace
fill ~199 ~148 ~447 ~199 ~148 ~448 minecraft:light_gray_concrete replace
fill ~202 ~148 ~447 ~202 ~148 ~448 minecraft:light_gray_concrete replace
fill ~205 ~148 ~447 ~205 ~148 ~448 minecraft:light_gray_concrete replace
fill ~208 ~148 ~447 ~208 ~148 ~448 minecraft:light_gray_concrete replace
fill ~211 ~148 ~447 ~211 ~148 ~448 minecraft:light_gray_concrete replace
fill ~214 ~148 ~447 ~214 ~148 ~448 minecraft:light_gray_concrete replace
fill ~217 ~148 ~447 ~217 ~148 ~448 minecraft:light_gray_concrete replace
fill ~220 ~148 ~447 ~220 ~148 ~448 minecraft:light_gray_concrete replace
fill ~223 ~148 ~447 ~223 ~148 ~448 minecraft:light_gray_concrete replace
fill ~226 ~148 ~447 ~226 ~148 ~448 minecraft:light_gray_concrete replace
fill ~229 ~148 ~447 ~229 ~148 ~448 minecraft:light_gray_concrete replace
fill ~78 ~148 ~450 ~80 ~148 ~450 minecraft:light_gray_concrete replace
fill ~79 ~148 ~451 ~79 ~148 ~452 minecraft:light_gray_concrete replace
fill ~84 ~148 ~474 ~230 ~148 ~474 minecraft:light_gray_concrete replace
fill ~85 ~148 ~475 ~85 ~148 ~476 minecraft:light_gray_concrete replace
fill ~88 ~148 ~475 ~88 ~148 ~476 minecraft:light_gray_concrete replace
fill ~91 ~148 ~475 ~91 ~148 ~476 minecraft:light_gray_concrete replace
fill ~94 ~148 ~475 ~94 ~148 ~476 minecraft:light_gray_concrete replace
fill ~97 ~148 ~475 ~97 ~148 ~476 minecraft:light_gray_concrete replace
fill ~100 ~148 ~475 ~100 ~148 ~476 minecraft:light_gray_concrete replace
fill ~103 ~148 ~475 ~103 ~148 ~476 minecraft:light_gray_concrete replace
fill ~106 ~148 ~475 ~106 ~148 ~476 minecraft:light_gray_concrete replace
fill ~109 ~148 ~475 ~109 ~148 ~476 minecraft:light_gray_concrete replace
fill ~112 ~148 ~475 ~112 ~148 ~476 minecraft:light_gray_concrete replace
fill ~115 ~148 ~475 ~115 ~148 ~476 minecraft:light_gray_concrete replace
fill ~118 ~148 ~475 ~118 ~148 ~476 minecraft:light_gray_concrete replace
fill ~121 ~148 ~475 ~121 ~148 ~476 minecraft:light_gray_concrete replace
fill ~124 ~148 ~475 ~124 ~148 ~476 minecraft:light_gray_concrete replace
fill ~127 ~148 ~475 ~127 ~148 ~476 minecraft:light_gray_concrete replace
fill ~130 ~148 ~475 ~130 ~148 ~476 minecraft:light_gray_concrete replace
fill ~133 ~148 ~475 ~133 ~148 ~476 minecraft:light_gray_concrete replace
fill ~136 ~148 ~475 ~136 ~148 ~476 minecraft:light_gray_concrete replace
fill ~139 ~148 ~475 ~139 ~148 ~476 minecraft:light_gray_concrete replace
fill ~142 ~148 ~475 ~142 ~148 ~476 minecraft:light_gray_concrete replace
fill ~145 ~148 ~475 ~145 ~148 ~476 minecraft:light_gray_concrete replace
fill ~148 ~148 ~475 ~148 ~148 ~476 minecraft:light_gray_concrete replace
fill ~151 ~148 ~475 ~151 ~148 ~476 minecraft:light_gray_concrete replace
fill ~154 ~148 ~475 ~154 ~148 ~476 minecraft:light_gray_concrete replace
fill ~157 ~148 ~475 ~157 ~148 ~476 minecraft:light_gray_concrete replace
fill ~160 ~148 ~475 ~160 ~148 ~476 minecraft:light_gray_concrete replace
fill ~163 ~148 ~475 ~163 ~148 ~476 minecraft:light_gray_concrete replace
fill ~166 ~148 ~475 ~166 ~148 ~476 minecraft:light_gray_concrete replace
fill ~169 ~148 ~475 ~169 ~148 ~476 minecraft:light_gray_concrete replace
fill ~172 ~148 ~475 ~172 ~148 ~476 minecraft:light_gray_concrete replace
fill ~175 ~148 ~475 ~175 ~148 ~476 minecraft:light_gray_concrete replace
fill ~178 ~148 ~475 ~178 ~148 ~476 minecraft:light_gray_concrete replace
fill ~181 ~148 ~475 ~181 ~148 ~476 minecraft:light_gray_concrete replace
fill ~184 ~148 ~475 ~184 ~148 ~476 minecraft:light_gray_concrete replace
fill ~187 ~148 ~475 ~187 ~148 ~476 minecraft:light_gray_concrete replace
fill ~190 ~148 ~475 ~190 ~148 ~476 minecraft:light_gray_concrete replace
fill ~193 ~148 ~475 ~193 ~148 ~476 minecraft:light_gray_concrete replace
fill ~196 ~148 ~475 ~196 ~148 ~476 minecraft:light_gray_concrete replace
fill ~199 ~148 ~475 ~199 ~148 ~476 minecraft:light_gray_concrete replace
fill ~202 ~148 ~475 ~202 ~148 ~476 minecraft:light_gray_concrete replace
fill ~205 ~148 ~475 ~205 ~148 ~476 minecraft:light_gray_concrete replace
fill ~208 ~148 ~475 ~208 ~148 ~476 minecraft:light_gray_concrete replace
fill ~211 ~148 ~475 ~211 ~148 ~476 minecraft:light_gray_concrete replace
fill ~214 ~148 ~475 ~214 ~148 ~476 minecraft:light_gray_concrete replace
fill ~217 ~148 ~475 ~217 ~148 ~476 minecraft:light_gray_concrete replace
fill ~220 ~148 ~475 ~220 ~148 ~476 minecraft:light_gray_concrete replace
fill ~223 ~148 ~475 ~223 ~148 ~476 minecraft:light_gray_concrete replace
fill ~226 ~148 ~475 ~226 ~148 ~476 minecraft:light_gray_concrete replace
fill ~229 ~148 ~475 ~229 ~148 ~476 minecraft:light_gray_concrete replace
fill ~99 ~148 ~482 ~248 ~148 ~482 minecraft:light_gray_concrete replace
fill ~235 ~148 ~483 ~235 ~148 ~484 minecraft:light_gray_concrete replace
fill ~247 ~148 ~483 ~247 ~148 ~484 minecraft:light_gray_concrete replace
fill ~105 ~148 ~502 ~248 ~148 ~502 minecraft:light_gray_concrete replace
fill ~241 ~148 ~503 ~241 ~148 ~504 minecraft:light_gray_concrete replace
fill ~247 ~148 ~503 ~247 ~148 ~504 minecraft:light_gray_concrete replace
fill ~102 ~148 ~514 ~248 ~148 ~514 minecraft:light_gray_concrete replace
fill ~238 ~148 ~515 ~238 ~148 ~516 minecraft:light_gray_concrete replace
fill ~247 ~148 ~515 ~247 ~148 ~516 minecraft:light_gray_concrete replace
fill ~108 ~148 ~538 ~248 ~148 ~538 minecraft:light_gray_concrete replace
fill ~244 ~148 ~539 ~244 ~148 ~540 minecraft:light_gray_concrete replace
fill ~247 ~148 ~539 ~247 ~148 ~540 minecraft:light_gray_concrete replace
fill ~111 ~148 ~546 ~257 ~148 ~546 minecraft:light_gray_concrete replace
fill ~247 ~148 ~547 ~247 ~148 ~548 minecraft:light_gray_concrete replace
fill ~250 ~148 ~547 ~250 ~148 ~548 minecraft:light_gray_concrete replace
fill ~256 ~148 ~547 ~256 ~148 ~548 minecraft:light_gray_concrete replace
fill ~117 ~148 ~570 ~260 ~148 ~570 minecraft:light_gray_concrete replace
fill ~247 ~148 ~571 ~247 ~148 ~572 minecraft:light_gray_concrete replace
fill ~256 ~148 ~571 ~256 ~148 ~572 minecraft:light_gray_concrete replace
fill ~259 ~148 ~571 ~259 ~148 ~572 minecraft:light_gray_concrete replace
fill ~114 ~148 ~578 ~257 ~148 ~578 minecraft:light_gray_concrete replace
fill ~247 ~148 ~579 ~247 ~148 ~580 minecraft:light_gray_concrete replace
fill ~253 ~148 ~579 ~253 ~148 ~580 minecraft:light_gray_concrete replace
fill ~256 ~148 ~579 ~256 ~148 ~580 minecraft:light_gray_concrete replace
fill ~123 ~148 ~606 ~269 ~148 ~606 minecraft:light_gray_concrete replace
fill ~247 ~148 ~607 ~247 ~148 ~608 minecraft:light_gray_concrete replace
fill ~256 ~148 ~607 ~256 ~148 ~608 minecraft:light_gray_concrete replace
fill ~265 ~148 ~607 ~265 ~148 ~608 minecraft:light_gray_concrete replace
fill ~268 ~148 ~607 ~268 ~148 ~608 minecraft:light_gray_concrete replace
fill ~120 ~148 ~610 ~263 ~148 ~610 minecraft:light_gray_concrete replace
fill ~247 ~148 ~611 ~247 ~148 ~612 minecraft:light_gray_concrete replace
fill ~256 ~148 ~611 ~256 ~148 ~612 minecraft:light_gray_concrete replace
fill ~262 ~148 ~611 ~262 ~148 ~612 minecraft:light_gray_concrete replace
fill ~132 ~148 ~646 ~278 ~148 ~646 minecraft:light_gray_concrete replace
fill ~277 ~148 ~647 ~277 ~148 ~648 minecraft:light_gray_concrete replace
fill ~84 ~148 ~650 ~230 ~148 ~650 minecraft:light_gray_concrete replace
fill ~85 ~148 ~651 ~85 ~148 ~652 minecraft:light_gray_concrete replace
fill ~88 ~148 ~651 ~88 ~148 ~652 minecraft:light_gray_concrete replace
fill ~91 ~148 ~651 ~91 ~148 ~652 minecraft:light_gray_concrete replace
fill ~94 ~148 ~651 ~94 ~148 ~652 minecraft:light_gray_concrete replace
fill ~97 ~148 ~651 ~97 ~148 ~652 minecraft:light_gray_concrete replace
fill ~100 ~148 ~651 ~100 ~148 ~652 minecraft:light_gray_concrete replace
fill ~103 ~148 ~651 ~103 ~148 ~652 minecraft:light_gray_concrete replace
fill ~106 ~148 ~651 ~106 ~148 ~652 minecraft:light_gray_concrete replace
fill ~109 ~148 ~651 ~109 ~148 ~652 minecraft:light_gray_concrete replace
fill ~112 ~148 ~651 ~112 ~148 ~652 minecraft:light_gray_concrete replace
fill ~115 ~148 ~651 ~115 ~148 ~652 minecraft:light_gray_concrete replace
fill ~118 ~148 ~651 ~118 ~148 ~652 minecraft:light_gray_concrete replace
fill ~121 ~148 ~651 ~121 ~148 ~652 minecraft:light_gray_concrete replace
fill ~124 ~148 ~651 ~124 ~148 ~652 minecraft:light_gray_concrete replace
fill ~127 ~148 ~651 ~127 ~148 ~652 minecraft:light_gray_concrete replace
fill ~130 ~148 ~651 ~130 ~148 ~652 minecraft:light_gray_concrete replace
fill ~133 ~148 ~651 ~133 ~148 ~652 minecraft:light_gray_concrete replace
fill ~136 ~148 ~651 ~136 ~148 ~652 minecraft:light_gray_concrete replace
fill ~139 ~148 ~651 ~139 ~148 ~652 minecraft:light_gray_concrete replace
fill ~142 ~148 ~651 ~142 ~148 ~652 minecraft:light_gray_concrete replace
fill ~145 ~148 ~651 ~145 ~148 ~652 minecraft:light_gray_concrete replace
fill ~148 ~148 ~651 ~148 ~148 ~652 minecraft:light_gray_concrete replace
fill ~151 ~148 ~651 ~151 ~148 ~652 minecraft:light_gray_concrete replace
fill ~154 ~148 ~651 ~154 ~148 ~652 minecraft:light_gray_concrete replace
fill ~157 ~148 ~651 ~157 ~148 ~652 minecraft:light_gray_concrete replace
fill ~160 ~148 ~651 ~160 ~148 ~652 minecraft:light_gray_concrete replace
fill ~163 ~148 ~651 ~163 ~148 ~652 minecraft:light_gray_concrete replace
fill ~166 ~148 ~651 ~166 ~148 ~652 minecraft:light_gray_concrete replace
fill ~169 ~148 ~651 ~169 ~148 ~652 minecraft:light_gray_concrete replace
fill ~172 ~148 ~651 ~172 ~148 ~652 minecraft:light_gray_concrete replace
fill ~175 ~148 ~651 ~175 ~148 ~652 minecraft:light_gray_concrete replace
fill ~178 ~148 ~651 ~178 ~148 ~652 minecraft:light_gray_concrete replace
fill ~181 ~148 ~651 ~181 ~148 ~652 minecraft:light_gray_concrete replace
fill ~184 ~148 ~651 ~184 ~148 ~652 minecraft:light_gray_concrete replace
fill ~187 ~148 ~651 ~187 ~148 ~652 minecraft:light_gray_concrete replace
fill ~190 ~148 ~651 ~190 ~148 ~652 minecraft:light_gray_concrete replace
fill ~193 ~148 ~651 ~193 ~148 ~652 minecraft:light_gray_concrete replace
fill ~196 ~148 ~651 ~196 ~148 ~652 minecraft:light_gray_concrete replace
fill ~199 ~148 ~651 ~199 ~148 ~652 minecraft:light_gray_concrete replace
fill ~202 ~148 ~651 ~202 ~148 ~652 minecraft:light_gray_concrete replace
fill ~205 ~148 ~651 ~205 ~148 ~652 minecraft:light_gray_concrete replace
fill ~208 ~148 ~651 ~208 ~148 ~652 minecraft:light_gray_concrete replace
fill ~211 ~148 ~651 ~211 ~148 ~652 minecraft:light_gray_concrete replace
fill ~214 ~148 ~651 ~214 ~148 ~652 minecraft:light_gray_concrete replace
fill ~217 ~148 ~651 ~217 ~148 ~652 minecraft:light_gray_concrete replace
fill ~220 ~148 ~651 ~220 ~148 ~652 minecraft:light_gray_concrete replace
fill ~223 ~148 ~651 ~223 ~148 ~652 minecraft:light_gray_concrete replace
fill ~226 ~148 ~651 ~226 ~148 ~652 minecraft:light_gray_concrete replace
fill ~229 ~148 ~651 ~229 ~148 ~652 minecraft:light_gray_concrete replace
fill ~126 ~148 ~654 ~272 ~148 ~654 minecraft:light_gray_concrete replace
fill ~271 ~148 ~655 ~271 ~148 ~656 minecraft:light_gray_concrete replace
fill ~129 ~148 ~662 ~275 ~148 ~662 minecraft:light_gray_concrete replace
fill ~274 ~148 ~663 ~274 ~148 ~664 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~105 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~120 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~122 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~137 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~156 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~171 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~173 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~188 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~190 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~205 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~207 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~222 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~224 ~149 ~386 minecraft:light_gray_concrete replace
setblock ~232 ~149 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~149 ~400 minecraft:light_gray_concrete replace
setblock ~85 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~88 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~91 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~94 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~97 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~100 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~103 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~106 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~109 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~112 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~115 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~118 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~121 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~124 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~127 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~130 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~133 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~136 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~139 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~142 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~145 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~148 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~151 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~154 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~157 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~160 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~163 ~149 ~436 minecraft:light_gray_concrete replace
setblock ~166 ~149 ~436 minecraft:light_gray_concrete replace
