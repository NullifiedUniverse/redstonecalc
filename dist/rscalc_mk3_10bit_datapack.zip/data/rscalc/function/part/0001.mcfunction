setblock ~198 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~117 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~119 minecraft:light_gray_concrete replace
setblock ~105 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~121 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~141 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~123 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~141 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~125 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~127 minecraft:light_gray_concrete replace
setblock ~117 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~129 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~131 minecraft:light_gray_concrete replace
setblock ~120 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~133 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~135 minecraft:light_gray_concrete replace
setblock ~123 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~137 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~139 minecraft:light_gray_concrete replace
setblock ~126 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~141 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~143 minecraft:light_gray_concrete replace
setblock ~156 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~145 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~147 minecraft:light_gray_concrete replace
setblock ~138 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~149 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~151 minecraft:light_gray_concrete replace
setblock ~144 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~153 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~155 minecraft:light_gray_concrete replace
setblock ~147 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~157 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~159 minecraft:light_gray_concrete replace
setblock ~150 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~161 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~163 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~189 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~165 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~167 minecraft:light_gray_concrete replace
setblock ~162 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~169 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~171 minecraft:light_gray_concrete replace
setblock ~165 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~173 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~175 minecraft:light_gray_concrete replace
setblock ~168 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~177 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~179 minecraft:light_gray_concrete replace
setblock ~171 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~181 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~183 minecraft:light_gray_concrete replace
setblock ~207 ~19 ~185 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~185 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~185 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~185 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~185 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~185 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~187 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~192 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~189 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~191 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~195 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~193 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~195 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~198 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~197 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~199 minecraft:light_gray_concrete replace
setblock ~201 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~201 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~203 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~219 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~205 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~207 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~213 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~209 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~211 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~216 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~213 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~215 minecraft:light_gray_concrete replace
setblock ~222 ~19 ~217 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~217 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~217 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~219 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~225 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~221 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~223 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~252 ~19 ~225 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~227 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~255 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~229 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~231 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~233 minecraft:light_gray_concrete replace
setblock ~267 ~19 ~233 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~235 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~276 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~239 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~279 ~19 ~241 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~243 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~282 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~245 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~247 minecraft:light_gray_concrete replace
setblock ~234 ~19 ~249 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~249 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~251 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~240 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~253 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~255 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~255 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~255 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~257 minecraft:light_gray_concrete replace
setblock ~243 ~19 ~257 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~257 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~259 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~259 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~246 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~261 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~263 minecraft:light_gray_concrete replace
setblock ~261 ~19 ~265 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~267 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~267 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~267 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~273 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~269 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~271 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~271 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~273 minecraft:light_gray_concrete replace
setblock ~288 ~19 ~273 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~275 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~275 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~291 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~277 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~279 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~279 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~279 minecraft:light_gray_concrete replace
setblock ~294 ~19 ~281 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~283 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~283 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~297 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~285 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~287 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~287 minecraft:light_gray_concrete replace
setblock ~177 ~19 ~289 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~289 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~291 minecraft:light_gray_concrete replace
setblock ~180 ~19 ~293 minecraft:light_gray_concrete replace
setblock ~186 ~19 ~297 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~301 minecraft:light_gray_concrete replace
setblock ~300 ~19 ~301 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~303 minecraft:light_gray_concrete replace
setblock ~228 ~19 ~305 minecraft:light_gray_concrete replace
fill ~78 ~20 ~10 ~80 ~20 ~10 minecraft:light_gray_concrete replace
fill ~79 ~20 ~11 ~79 ~20 ~12 minecraft:light_gray_concrete replace
fill ~102 ~20 ~14 ~108 ~20 ~14 minecraft:light_gray_concrete replace
fill ~103 ~20 ~15 ~103 ~20 ~16 minecraft:light_gray_concrete replace
fill ~90 ~20 ~18 ~93 ~20 ~18 minecraft:light_gray_concrete replace
fill ~91 ~20 ~19 ~91 ~20 ~20 minecraft:light_gray_concrete replace
fill ~108 ~20 ~22 ~114 ~20 ~22 minecraft:light_gray_concrete replace
fill ~109 ~20 ~23 ~109 ~20 ~24 minecraft:light_gray_concrete replace
fill ~105 ~20 ~26 ~111 ~20 ~26 minecraft:light_gray_concrete replace
fill ~106 ~20 ~27 ~106 ~20 ~28 minecraft:light_gray_concrete replace
fill ~123 ~20 ~30 ~132 ~20 ~30 minecraft:light_gray_concrete replace
fill ~124 ~20 ~31 ~124 ~20 ~32 minecraft:light_gray_concrete replace
fill ~126 ~20 ~34 ~135 ~20 ~34 minecraft:light_gray_concrete replace
fill ~127 ~20 ~35 ~127 ~20 ~36 minecraft:light_gray_concrete replace
fill ~144 ~20 ~38 ~153 ~20 ~38 minecraft:light_gray_concrete replace
fill ~145 ~20 ~39 ~145 ~20 ~40 minecraft:light_gray_concrete replace
fill ~150 ~20 ~42 ~159 ~20 ~42 minecraft:light_gray_concrete replace
fill ~151 ~20 ~43 ~151 ~20 ~44 minecraft:light_gray_concrete replace
fill ~168 ~20 ~46 ~174 ~20 ~46 minecraft:light_gray_concrete replace
fill ~169 ~20 ~47 ~169 ~20 ~48 minecraft:light_gray_concrete replace
fill ~174 ~20 ~50 ~183 ~20 ~50 minecraft:light_gray_concrete replace
fill ~175 ~20 ~51 ~175 ~20 ~52 minecraft:light_gray_concrete replace
fill ~198 ~20 ~54 ~204 ~20 ~54 minecraft:light_gray_concrete replace
fill ~199 ~20 ~55 ~199 ~20 ~56 minecraft:light_gray_concrete replace
fill ~207 ~20 ~58 ~210 ~20 ~58 minecraft:light_gray_concrete replace
fill ~208 ~20 ~59 ~208 ~20 ~60 minecraft:light_gray_concrete replace
fill ~231 ~20 ~62 ~237 ~20 ~62 minecraft:light_gray_concrete replace
fill ~232 ~20 ~63 ~232 ~20 ~64 minecraft:light_gray_concrete replace
fill ~240 ~20 ~66 ~249 ~20 ~66 minecraft:light_gray_concrete replace
fill ~241 ~20 ~67 ~241 ~20 ~68 minecraft:light_gray_concrete replace
fill ~255 ~20 ~70 ~264 ~20 ~70 minecraft:light_gray_concrete replace
fill ~256 ~20 ~71 ~256 ~20 ~72 minecraft:light_gray_concrete replace
fill ~225 ~20 ~74 ~231 ~20 ~74 minecraft:light_gray_concrete replace
fill ~226 ~20 ~75 ~226 ~20 ~76 minecraft:light_gray_concrete replace
fill ~261 ~20 ~78 ~270 ~20 ~78 minecraft:light_gray_concrete replace
fill ~262 ~20 ~79 ~262 ~20 ~80 minecraft:light_gray_concrete replace
fill ~249 ~20 ~82 ~258 ~20 ~82 minecraft:light_gray_concrete replace
fill ~250 ~20 ~83 ~250 ~20 ~84 minecraft:light_gray_concrete replace
fill ~273 ~20 ~86 ~285 ~20 ~86 minecraft:light_gray_concrete replace
fill ~274 ~20 ~87 ~274 ~20 ~88 minecraft:light_gray_concrete replace
fill ~81 ~20 ~90 ~83 ~20 ~90 minecraft:light_gray_concrete replace
fill ~82 ~20 ~91 ~82 ~20 ~92 minecraft:light_gray_concrete replace
fill ~84 ~20 ~94 ~86 ~20 ~94 minecraft:light_gray_concrete replace
fill ~85 ~20 ~95 ~85 ~20 ~96 minecraft:light_gray_concrete replace
fill ~87 ~20 ~98 ~89 ~20 ~98 minecraft:light_gray_concrete replace
fill ~88 ~20 ~99 ~88 ~20 ~100 minecraft:light_gray_concrete replace
fill ~87 ~20 ~102 ~90 ~20 ~102 minecraft:light_gray_concrete replace
fill ~88 ~20 ~103 ~88 ~20 ~104 minecraft:light_gray_concrete replace
fill ~120 ~20 ~106 ~129 ~20 ~106 minecraft:light_gray_concrete replace
fill ~121 ~20 ~107 ~121 ~20 ~108 minecraft:light_gray_concrete replace
fill ~93 ~20 ~110 ~96 ~20 ~110 minecraft:light_gray_concrete replace
fill ~94 ~20 ~111 ~94 ~20 ~112 minecraft:light_gray_concrete replace
fill ~96 ~20 ~114 ~99 ~20 ~114 minecraft:light_gray_concrete replace
fill ~97 ~20 ~115 ~97 ~20 ~116 minecraft:light_gray_concrete replace
fill ~99 ~20 ~118 ~102 ~20 ~118 minecraft:light_gray_concrete replace
fill ~100 ~20 ~119 ~100 ~20 ~120 minecraft:light_gray_concrete replace
fill ~99 ~20 ~122 ~105 ~20 ~122 minecraft:light_gray_concrete replace
fill ~100 ~20 ~123 ~100 ~20 ~124 minecraft:light_gray_concrete replace
fill ~132 ~20 ~126 ~141 ~20 ~126 minecraft:light_gray_concrete replace
fill ~133 ~20 ~127 ~133 ~20 ~128 minecraft:light_gray_concrete replace
fill ~111 ~20 ~130 ~117 ~20 ~130 minecraft:light_gray_concrete replace
fill ~112 ~20 ~131 ~112 ~20 ~132 minecraft:light_gray_concrete replace
fill ~114 ~20 ~134 ~120 ~20 ~134 minecraft:light_gray_concrete replace
fill ~115 ~20 ~135 ~115 ~20 ~136 minecraft:light_gray_concrete replace
fill ~117 ~20 ~138 ~123 ~20 ~138 minecraft:light_gray_concrete replace
fill ~118 ~20 ~139 ~118 ~20 ~140 minecraft:light_gray_concrete replace
fill ~117 ~20 ~142 ~126 ~20 ~142 minecraft:light_gray_concrete replace
fill ~118 ~20 ~143 ~118 ~20 ~144 minecraft:light_gray_concrete replace
fill ~147 ~20 ~146 ~156 ~20 ~146 minecraft:light_gray_concrete replace
fill ~148 ~20 ~147 ~148 ~20 ~148 minecraft:light_gray_concrete replace
fill ~129 ~20 ~150 ~138 ~20 ~150 minecraft:light_gray_concrete replace
fill ~130 ~20 ~151 ~130 ~20 ~152 minecraft:light_gray_concrete replace
fill ~138 ~20 ~154 ~144 ~20 ~154 minecraft:light_gray_concrete replace
fill ~139 ~20 ~155 ~139 ~20 ~156 minecraft:light_gray_concrete replace
fill ~141 ~20 ~158 ~147 ~20 ~158 minecraft:light_gray_concrete replace
fill ~142 ~20 ~159 ~142 ~20 ~160 minecraft:light_gray_concrete replace
fill ~141 ~20 ~162 ~150 ~20 ~162 minecraft:light_gray_concrete replace
fill ~142 ~20 ~163 ~142 ~20 ~164 minecraft:light_gray_concrete replace
fill ~180 ~20 ~166 ~189 ~20 ~166 minecraft:light_gray_concrete replace
fill ~181 ~20 ~167 ~181 ~20 ~168 minecraft:light_gray_concrete replace
fill ~153 ~20 ~170 ~162 ~20 ~170 minecraft:light_gray_concrete replace
fill ~154 ~20 ~171 ~154 ~20 ~172 minecraft:light_gray_concrete replace
fill ~156 ~20 ~174 ~165 ~20 ~174 minecraft:light_gray_concrete replace
fill ~157 ~20 ~175 ~157 ~20 ~176 minecraft:light_gray_concrete replace
fill ~159 ~20 ~178 ~168 ~20 ~178 minecraft:light_gray_concrete replace
fill ~160 ~20 ~179 ~160 ~20 ~180 minecraft:light_gray_concrete replace
fill ~159 ~20 ~182 ~171 ~20 ~182 minecraft:light_gray_concrete replace
fill ~160 ~20 ~183 ~160 ~20 ~184 minecraft:light_gray_concrete replace
fill ~201 ~20 ~186 ~207 ~20 ~186 minecraft:light_gray_concrete replace
fill ~202 ~20 ~187 ~202 ~20 ~188 minecraft:light_gray_concrete replace
fill ~189 ~20 ~190 ~192 ~20 ~190 minecraft:light_gray_concrete replace
fill ~190 ~20 ~191 ~190 ~20 ~192 minecraft:light_gray_concrete replace
fill ~192 ~20 ~194 ~195 ~20 ~194 minecraft:light_gray_concrete replace
fill ~193 ~20 ~195 ~193 ~20 ~196 minecraft:light_gray_concrete replace
fill ~195 ~20 ~198 ~198 ~20 ~198 minecraft:light_gray_concrete replace
fill ~196 ~20 ~199 ~196 ~20 ~200 minecraft:light_gray_concrete replace
fill ~195 ~20 ~202 ~201 ~20 ~202 minecraft:light_gray_concrete replace
fill ~196 ~20 ~203 ~196 ~20 ~204 minecraft:light_gray_concrete replace
fill ~216 ~20 ~206 ~219 ~20 ~206 minecraft:light_gray_concrete replace
fill ~217 ~20 ~207 ~217 ~20 ~208 minecraft:light_gray_concrete replace
fill ~210 ~20 ~210 ~213 ~20 ~210 minecraft:light_gray_concrete replace
fill ~211 ~20 ~211 ~211 ~20 ~212 minecraft:light_gray_concrete replace
fill ~213 ~20 ~214 ~216 ~20 ~214 minecraft:light_gray_concrete replace
fill ~214 ~20 ~215 ~214 ~20 ~216 minecraft:light_gray_concrete replace
fill ~219 ~20 ~218 ~222 ~20 ~218 minecraft:light_gray_concrete replace
fill ~220 ~20 ~219 ~220 ~20 ~220 minecraft:light_gray_concrete replace
fill ~219 ~20 ~222 ~225 ~20 ~222 minecraft:light_gray_concrete replace
fill ~220 ~20 ~223 ~220 ~20 ~224 minecraft:light_gray_concrete replace
fill ~243 ~20 ~226 ~252 ~20 ~226 minecraft:light_gray_concrete replace
fill ~244 ~20 ~227 ~244 ~20 ~228 minecraft:light_gray_concrete replace
fill ~246 ~20 ~230 ~255 ~20 ~230 minecraft:light_gray_concrete replace
fill ~247 ~20 ~231 ~247 ~20 ~232 minecraft:light_gray_concrete replace
fill ~258 ~20 ~234 ~267 ~20 ~234 minecraft:light_gray_concrete replace
fill ~259 ~20 ~235 ~259 ~20 ~236 minecraft:light_gray_concrete replace
fill ~267 ~20 ~238 ~276 ~20 ~238 minecraft:light_gray_concrete replace
fill ~268 ~20 ~239 ~268 ~20 ~240 minecraft:light_gray_concrete replace
fill ~270 ~20 ~242 ~279 ~20 ~242 minecraft:light_gray_concrete replace
fill ~271 ~20 ~243 ~271 ~20 ~244 minecraft:light_gray_concrete replace
fill ~270 ~20 ~246 ~282 ~20 ~246 minecraft:light_gray_concrete replace
fill ~271 ~20 ~247 ~271 ~20 ~248 minecraft:light_gray_concrete replace
fill ~228 ~20 ~250 ~234 ~20 ~250 minecraft:light_gray_concrete replace
fill ~229 ~20 ~251 ~229 ~20 ~252 minecraft:light_gray_concrete replace
fill ~234 ~20 ~254 ~240 ~20 ~254 minecraft:light_gray_concrete replace
fill ~235 ~20 ~255 ~235 ~20 ~256 minecraft:light_gray_concrete replace
fill ~237 ~20 ~258 ~243 ~20 ~258 minecraft:light_gray_concrete replace
fill ~238 ~20 ~259 ~238 ~20 ~260 minecraft:light_gray_concrete replace
fill ~237 ~20 ~262 ~246 ~20 ~262 minecraft:light_gray_concrete replace
fill ~238 ~20 ~263 ~238 ~20 ~264 minecraft:light_gray_concrete replace
fill ~252 ~20 ~266 ~261 ~20 ~266 minecraft:light_gray_concrete replace
fill ~253 ~20 ~267 ~253 ~20 ~268 minecraft:light_gray_concrete replace
fill ~264 ~20 ~270 ~273 ~20 ~270 minecraft:light_gray_concrete replace
fill ~265 ~20 ~271 ~265 ~20 ~272 minecraft:light_gray_concrete replace
fill ~276 ~20 ~274 ~288 ~20 ~274 minecraft:light_gray_concrete replace
fill ~277 ~20 ~275 ~277 ~20 ~276 minecraft:light_gray_concrete replace
fill ~279 ~20 ~278 ~291 ~20 ~278 minecraft:light_gray_concrete replace
fill ~280 ~20 ~279 ~280 ~20 ~280 minecraft:light_gray_concrete replace
fill ~282 ~20 ~282 ~294 ~20 ~282 minecraft:light_gray_concrete replace
fill ~283 ~20 ~283 ~283 ~20 ~284 minecraft:light_gray_concrete replace
fill ~282 ~20 ~286 ~297 ~20 ~286 minecraft:light_gray_concrete replace
fill ~283 ~20 ~287 ~283 ~20 ~288 minecraft:light_gray_concrete replace
fill ~135 ~20 ~290 ~206 ~20 ~290 minecraft:light_gray_concrete replace
fill ~136 ~20 ~291 ~136 ~20 ~292 minecraft:light_gray_concrete replace
fill ~163 ~20 ~291 ~163 ~20 ~292 minecraft:light_gray_concrete replace
fill ~166 ~20 ~291 ~166 ~20 ~292 minecraft:light_gray_concrete replace
fill ~172 ~20 ~291 ~172 ~20 ~292 minecraft:light_gray_concrete replace
fill ~178 ~20 ~291 ~178 ~20 ~292 minecraft:light_gray_concrete replace
fill ~184 ~20 ~291 ~184 ~20 ~292 minecraft:light_gray_concrete replace
fill ~187 ~20 ~291 ~187 ~20 ~292 minecraft:light_gray_concrete replace
fill ~205 ~20 ~291 ~205 ~20 ~292 minecraft:light_gray_concrete replace
fill ~135 ~20 ~294 ~206 ~20 ~294 minecraft:light_gray_concrete replace
fill ~136 ~20 ~295 ~136 ~20 ~296 minecraft:light_gray_concrete replace
fill ~163 ~20 ~295 ~163 ~20 ~296 minecraft:light_gray_concrete replace
fill ~166 ~20 ~295 ~166 ~20 ~296 minecraft:light_gray_concrete replace
fill ~172 ~20 ~295 ~172 ~20 ~296 minecraft:light_gray_concrete replace
fill ~178 ~20 ~295 ~178 ~20 ~296 minecraft:light_gray_concrete replace
fill ~184 ~20 ~295 ~184 ~20 ~296 minecraft:light_gray_concrete replace
fill ~187 ~20 ~295 ~187 ~20 ~296 minecraft:light_gray_concrete replace
fill ~205 ~20 ~295 ~205 ~20 ~296 minecraft:light_gray_concrete replace
fill ~162 ~20 ~298 ~206 ~20 ~298 minecraft:light_gray_concrete replace
fill ~163 ~20 ~299 ~163 ~20 ~300 minecraft:light_gray_concrete replace
fill ~166 ~20 ~299 ~166 ~20 ~300 minecraft:light_gray_concrete replace
fill ~172 ~20 ~299 ~172 ~20 ~300 minecraft:light_gray_concrete replace
fill ~178 ~20 ~299 ~178 ~20 ~300 minecraft:light_gray_concrete replace
fill ~184 ~20 ~299 ~184 ~20 ~300 minecraft:light_gray_concrete replace
fill ~187 ~20 ~299 ~187 ~20 ~300 minecraft:light_gray_concrete replace
fill ~205 ~20 ~299 ~205 ~20 ~300 minecraft:light_gray_concrete replace
fill ~285 ~20 ~302 ~300 ~20 ~302 minecraft:light_gray_concrete replace
fill ~286 ~20 ~303 ~286 ~20 ~304 minecraft:light_gray_concrete replace
fill ~222 ~20 ~306 ~228 ~20 ~306 minecraft:light_gray_concrete replace
fill ~223 ~20 ~307 ~223 ~20 ~308 minecraft:light_gray_concrete replace
setblock ~79 ~21 ~12 minecraft:light_gray_concrete replace
setblock ~103 ~21 ~16 minecraft:light_gray_concrete replace
setblock ~91 ~21 ~20 minecraft:light_gray_concrete replace
setblock ~109 ~21 ~24 minecraft:light_gray_concrete replace
setblock ~106 ~21 ~28 minecraft:light_gray_concrete replace
setblock ~124 ~21 ~32 minecraft:light_gray_concrete replace
setblock ~127 ~21 ~36 minecraft:light_gray_concrete replace
setblock ~145 ~21 ~40 minecraft:light_gray_concrete replace
setblock ~151 ~21 ~44 minecraft:light_gray_concrete replace
setblock ~169 ~21 ~48 minecraft:light_gray_concrete replace
setblock ~175 ~21 ~52 minecraft:light_gray_concrete replace
setblock ~199 ~21 ~56 minecraft:light_gray_concrete replace
setblock ~208 ~21 ~60 minecraft:light_gray_concrete replace
setblock ~232 ~21 ~64 minecraft:light_gray_concrete replace
setblock ~241 ~21 ~68 minecraft:light_gray_concrete replace
setblock ~256 ~21 ~72 minecraft:light_gray_concrete replace
setblock ~226 ~21 ~76 minecraft:light_gray_concrete replace
setblock ~262 ~21 ~80 minecraft:light_gray_concrete replace
setblock ~250 ~21 ~84 minecraft:light_gray_concrete replace
setblock ~274 ~21 ~88 minecraft:light_gray_concrete replace
setblock ~82 ~21 ~92 minecraft:light_gray_concrete replace
setblock ~85 ~21 ~96 minecraft:light_gray_concrete replace
setblock ~88 ~21 ~100 minecraft:light_gray_concrete replace
setblock ~88 ~21 ~104 minecraft:light_gray_concrete replace
setblock ~121 ~21 ~108 minecraft:light_gray_concrete replace
setblock ~94 ~21 ~112 minecraft:light_gray_concrete replace
setblock ~97 ~21 ~116 minecraft:light_gray_concrete replace
setblock ~100 ~21 ~120 minecraft:light_gray_concrete replace
setblock ~100 ~21 ~124 minecraft:light_gray_concrete replace
setblock ~133 ~21 ~128 minecraft:light_gray_concrete replace
setblock ~112 ~21 ~132 minecraft:light_gray_concrete replace
setblock ~115 ~21 ~136 minecraft:light_gray_concrete replace
setblock ~118 ~21 ~140 minecraft:light_gray_concrete replace
setblock ~118 ~21 ~144 minecraft:light_gray_concrete replace
setblock ~148 ~21 ~148 minecraft:light_gray_concrete replace
setblock ~130 ~21 ~152 minecraft:light_gray_concrete replace
setblock ~139 ~21 ~156 minecraft:light_gray_concrete replace
setblock ~142 ~21 ~160 minecraft:light_gray_concrete replace
setblock ~142 ~21 ~164 minecraft:light_gray_concrete replace
setblock ~181 ~21 ~168 minecraft:light_gray_concrete replace
setblock ~154 ~21 ~172 minecraft:light_gray_concrete replace
setblock ~157 ~21 ~176 minecraft:light_gray_concrete replace
setblock ~160 ~21 ~180 minecraft:light_gray_concrete replace
setblock ~160 ~21 ~184 minecraft:light_gray_concrete replace
setblock ~202 ~21 ~188 minecraft:light_gray_concrete replace
setblock ~190 ~21 ~192 minecraft:light_gray_concrete replace
setblock ~193 ~21 ~196 minecraft:light_gray_concrete replace
setblock ~196 ~21 ~200 minecraft:light_gray_concrete replace
setblock ~196 ~21 ~204 minecraft:light_gray_concrete replace
setblock ~217 ~21 ~208 minecraft:light_gray_concrete replace
setblock ~211 ~21 ~212 minecraft:light_gray_concrete replace
setblock ~214 ~21 ~216 minecraft:light_gray_concrete replace
setblock ~220 ~21 ~220 minecraft:light_gray_concrete replace
setblock ~220 ~21 ~224 minecraft:light_gray_concrete replace
setblock ~244 ~21 ~228 minecraft:light_gray_concrete replace
setblock ~247 ~21 ~232 minecraft:light_gray_concrete replace
setblock ~259 ~21 ~236 minecraft:light_gray_concrete replace
setblock ~268 ~21 ~240 minecraft:light_gray_concrete replace
setblock ~271 ~21 ~244 minecraft:light_gray_concrete replace
setblock ~272 ~21 ~246 minecraft:light_gray_concrete replace
setblock ~274 ~21 ~246 minecraft:light_gray_concrete replace
setblock ~271 ~21 ~248 minecraft:light_gray_concrete replace
setblock ~229 ~21 ~252 minecraft:light_gray_concrete replace
setblock ~235 ~21 ~256 minecraft:light_gray_concrete replace
setblock ~238 ~21 ~260 minecraft:light_gray_concrete replace
setblock ~238 ~21 ~264 minecraft:light_gray_concrete replace
setblock ~253 ~21 ~268 minecraft:light_gray_concrete replace
setblock ~265 ~21 ~272 minecraft:light_gray_concrete replace
setblock ~277 ~21 ~276 minecraft:light_gray_concrete replace
setblock ~280 ~21 ~280 minecraft:light_gray_concrete replace
setblock ~283 ~21 ~284 minecraft:light_gray_concrete replace
setblock ~287 ~21 ~286 minecraft:light_gray_concrete replace
setblock ~289 ~21 ~286 minecraft:light_gray_concrete replace
setblock ~283 ~21 ~288 minecraft:light_gray_concrete replace
setblock ~147 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~149 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~190 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~192 ~21 ~290 minecraft:light_gray_concrete replace
setblock ~136 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~163 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~166 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~172 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~178 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~184 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~187 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~205 ~21 ~292 minecraft:light_gray_concrete replace
setblock ~140 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~142 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~157 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~159 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~201 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~203 ~21 ~294 minecraft:light_gray_concrete replace
setblock ~136 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~163 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~166 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~172 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~178 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~184 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~187 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~205 ~21 ~296 minecraft:light_gray_concrete replace
setblock ~194 ~21 ~298 minecraft:light_gray_concrete replace
setblock ~196 ~21 ~298 minecraft:light_gray_concrete replace
setblock ~163 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~166 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~172 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~178 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~184 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~187 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~205 ~21 ~300 minecraft:light_gray_concrete replace
setblock ~286 ~21 ~304 minecraft:light_gray_concrete replace
setblock ~223 ~21 ~308 minecraft:light_gray_concrete replace
fill ~78 ~22 ~8 ~78 ~22 ~12 minecraft:light_gray_concrete replace
fill ~102 ~22 ~12 ~102 ~22 ~16 minecraft:light_gray_concrete replace
fill ~90 ~22 ~16 ~90 ~22 ~20 minecraft:light_gray_concrete replace
fill ~108 ~22 ~20 ~108 ~22 ~24 minecraft:light_gray_concrete replace
fill ~105 ~22 ~24 ~105 ~22 ~28 minecraft:light_gray_concrete replace
fill ~123 ~22 ~28 ~123 ~22 ~32 minecraft:light_gray_concrete replace
fill ~126 ~22 ~32 ~126 ~22 ~36 minecraft:light_gray_concrete replace
fill ~144 ~22 ~36 ~144 ~22 ~40 minecraft:light_gray_concrete replace
fill ~150 ~22 ~40 ~150 ~22 ~44 minecraft:light_gray_concrete replace
fill ~168 ~22 ~44 ~168 ~22 ~48 minecraft:light_gray_concrete replace
fill ~174 ~22 ~48 ~174 ~22 ~52 minecraft:light_gray_concrete replace
fill ~198 ~22 ~52 ~198 ~22 ~56 minecraft:light_gray_concrete replace
fill ~207 ~22 ~56 ~207 ~22 ~60 minecraft:light_gray_concrete replace
fill ~231 ~22 ~60 ~231 ~22 ~64 minecraft:light_gray_concrete replace
fill ~240 ~22 ~64 ~240 ~22 ~68 minecraft:light_gray_concrete replace
fill ~255 ~22 ~68 ~255 ~22 ~72 minecraft:light_gray_concrete replace
fill ~225 ~22 ~72 ~225 ~22 ~76 minecraft:light_gray_concrete replace
fill ~261 ~22 ~76 ~261 ~22 ~80 minecraft:light_gray_concrete replace
fill ~249 ~22 ~80 ~249 ~22 ~84 minecraft:light_gray_concrete replace
fill ~273 ~22 ~84 ~273 ~22 ~88 minecraft:light_gray_concrete replace
fill ~81 ~22 ~88 ~81 ~22 ~92 minecraft:light_gray_concrete replace
fill ~84 ~22 ~92 ~84 ~22 ~96 minecraft:light_gray_concrete replace
fill ~87 ~22 ~96 ~87 ~22 ~104 minecraft:light_gray_concrete replace
fill ~120 ~22 ~104 ~120 ~22 ~108 minecraft:light_gray_concrete replace
fill ~93 ~22 ~108 ~93 ~22 ~112 minecraft:light_gray_concrete replace
fill ~96 ~22 ~112 ~96 ~22 ~116 minecraft:light_gray_concrete replace
fill ~99 ~22 ~116 ~99 ~22 ~124 minecraft:light_gray_concrete replace
fill ~132 ~22 ~124 ~132 ~22 ~128 minecraft:light_gray_concrete replace
fill ~111 ~22 ~128 ~111 ~22 ~132 minecraft:light_gray_concrete replace
fill ~114 ~22 ~132 ~114 ~22 ~136 minecraft:light_gray_concrete replace
fill ~117 ~22 ~136 ~117 ~22 ~144 minecraft:light_gray_concrete replace
fill ~147 ~22 ~144 ~147 ~22 ~148 minecraft:light_gray_concrete replace
fill ~129 ~22 ~148 ~129 ~22 ~152 minecraft:light_gray_concrete replace
fill ~138 ~22 ~152 ~138 ~22 ~156 minecraft:light_gray_concrete replace
fill ~141 ~22 ~156 ~141 ~22 ~164 minecraft:light_gray_concrete replace
fill ~180 ~22 ~160 ~180 ~22 ~168 minecraft:light_gray_concrete replace
fill ~153 ~22 ~164 ~153 ~22 ~172 minecraft:light_gray_concrete replace
fill ~156 ~22 ~168 ~156 ~22 ~176 minecraft:light_gray_concrete replace
fill ~159 ~22 ~172 ~159 ~22 ~184 minecraft:light_gray_concrete replace
fill ~201 ~22 ~176 ~201 ~22 ~188 minecraft:light_gray_concrete replace
fill ~189 ~22 ~180 ~189 ~22 ~192 minecraft:light_gray_concrete replace
fill ~192 ~22 ~184 ~192 ~22 ~196 minecraft:light_gray_concrete replace
fill ~195 ~22 ~188 ~195 ~22 ~204 minecraft:light_gray_concrete replace
fill ~216 ~22 ~192 ~216 ~22 ~208 minecraft:light_gray_concrete replace
fill ~210 ~22 ~196 ~210 ~22 ~212 minecraft:light_gray_concrete replace
fill ~213 ~22 ~200 ~213 ~22 ~216 minecraft:light_gray_concrete replace
fill ~219 ~22 ~204 ~219 ~22 ~224 minecraft:light_gray_concrete replace
fill ~243 ~22 ~208 ~243 ~22 ~228 minecraft:light_gray_concrete replace
fill ~246 ~22 ~212 ~246 ~22 ~232 minecraft:light_gray_concrete replace
fill ~258 ~22 ~216 ~258 ~22 ~236 minecraft:light_gray_concrete replace
fill ~267 ~22 ~220 ~267 ~22 ~240 minecraft:light_gray_concrete replace
fill ~270 ~22 ~224 ~270 ~22 ~248 minecraft:light_gray_concrete replace
fill ~228 ~22 ~228 ~228 ~22 ~252 minecraft:light_gray_concrete replace
fill ~234 ~22 ~232 ~234 ~22 ~256 minecraft:light_gray_concrete replace
fill ~237 ~22 ~236 ~237 ~22 ~264 minecraft:light_gray_concrete replace
fill ~252 ~22 ~240 ~252 ~22 ~268 minecraft:light_gray_concrete replace
fill ~264 ~22 ~244 ~264 ~22 ~272 minecraft:light_gray_concrete replace
fill ~276 ~22 ~248 ~276 ~22 ~276 minecraft:light_gray_concrete replace
fill ~279 ~22 ~252 ~279 ~22 ~280 minecraft:light_gray_concrete replace
fill ~282 ~22 ~256 ~282 ~22 ~288 minecraft:light_gray_concrete replace
fill ~204 ~22 ~260 ~204 ~22 ~300 minecraft:light_gray_concrete replace
fill ~186 ~22 ~264 ~186 ~22 ~300 minecraft:light_gray_concrete replace
fill ~183 ~22 ~268 ~183 ~22 ~300 minecraft:light_gray_concrete replace
fill ~177 ~22 ~272 ~177 ~22 ~300 minecraft:light_gray_concrete replace
fill ~171 ~22 ~276 ~171 ~22 ~300 minecraft:light_gray_concrete replace
fill ~165 ~22 ~280 ~165 ~22 ~300 minecraft:light_gray_concrete replace
fill ~162 ~22 ~284 ~162 ~22 ~300 minecraft:light_gray_concrete replace
fill ~135 ~22 ~288 ~135 ~22 ~296 minecraft:light_gray_concrete replace
fill ~285 ~22 ~300 ~285 ~22 ~304 minecraft:light_gray_concrete replace
fill ~222 ~22 ~304 ~222 ~22 ~308 minecraft:light_gray_concrete replace
setblock ~78 ~23 ~7 minecraft:light_gray_concrete replace
setblock ~102 ~23 ~11 minecraft:light_gray_concrete replace
setblock ~90 ~23 ~15 minecraft:light_gray_concrete replace
setblock ~108 ~23 ~19 minecraft:light_gray_concrete replace
setblock ~105 ~23 ~23 minecraft:light_gray_concrete replace
setblock ~123 ~23 ~27 minecraft:light_gray_concrete replace
setblock ~126 ~23 ~31 minecraft:light_gray_concrete replace
setblock ~144 ~23 ~35 minecraft:light_gray_concrete replace
setblock ~150 ~23 ~39 minecraft:light_gray_concrete replace
setblock ~168 ~23 ~43 minecraft:light_gray_concrete replace
setblock ~174 ~23 ~47 minecraft:light_gray_concrete replace
setblock ~198 ~23 ~51 minecraft:light_gray_concrete replace
setblock ~207 ~23 ~55 minecraft:light_gray_concrete replace
setblock ~231 ~23 ~59 minecraft:light_gray_concrete replace
setblock ~240 ~23 ~63 minecraft:light_gray_concrete replace
setblock ~255 ~23 ~67 minecraft:light_gray_concrete replace
setblock ~225 ~23 ~71 minecraft:light_gray_concrete replace
setblock ~261 ~23 ~75 minecraft:light_gray_concrete replace
setblock ~249 ~23 ~79 minecraft:light_gray_concrete replace
setblock ~273 ~23 ~83 minecraft:light_gray_concrete replace
setblock ~81 ~23 ~87 minecraft:light_gray_concrete replace
setblock ~84 ~23 ~91 minecraft:light_gray_concrete replace
setblock ~82 ~23 ~92 minecraft:light_gray_concrete replace
setblock ~87 ~23 ~95 minecraft:light_gray_concrete replace
setblock ~87 ~23 ~97 minecraft:light_gray_concrete replace
setblock ~88 ~23 ~100 minecraft:light_gray_concrete replace
setblock ~120 ~23 ~103 minecraft:light_gray_concrete replace
setblock ~88 ~23 ~104 minecraft:light_gray_concrete replace
setblock ~93 ~23 ~107 minecraft:light_gray_concrete replace
setblock ~96 ~23 ~111 minecraft:light_gray_concrete replace
setblock ~94 ~23 ~112 minecraft:light_gray_concrete replace
setblock ~99 ~23 ~115 minecraft:light_gray_concrete replace
setblock ~99 ~23 ~117 minecraft:light_gray_concrete replace
setblock ~100 ~23 ~120 minecraft:light_gray_concrete replace
setblock ~132 ~23 ~123 minecraft:light_gray_concrete replace
setblock ~100 ~23 ~124 minecraft:light_gray_concrete replace
setblock ~111 ~23 ~127 minecraft:light_gray_concrete replace
setblock ~114 ~23 ~131 minecraft:light_gray_concrete replace
setblock ~112 ~23 ~132 minecraft:light_gray_concrete replace
setblock ~117 ~23 ~135 minecraft:light_gray_concrete replace
setblock ~117 ~23 ~137 minecraft:light_gray_concrete replace
setblock ~118 ~23 ~140 minecraft:light_gray_concrete replace
setblock ~147 ~23 ~143 minecraft:light_gray_concrete replace
setblock ~118 ~23 ~144 minecraft:light_gray_concrete replace
setblock ~129 ~23 ~147 minecraft:light_gray_concrete replace
setblock ~138 ~23 ~151 minecraft:light_gray_concrete replace
setblock ~130 ~23 ~152 minecraft:light_gray_concrete replace
setblock ~141 ~23 ~155 minecraft:light_gray_concrete replace
setblock ~141 ~23 ~157 minecraft:light_gray_concrete replace
setblock ~180 ~23 ~159 minecraft:light_gray_concrete replace
setblock ~142 ~23 ~160 minecraft:light_gray_concrete replace
setblock ~180 ~23 ~161 minecraft:light_gray_concrete replace
setblock ~153 ~23 ~163 minecraft:light_gray_concrete replace
setblock ~142 ~23 ~164 minecraft:light_gray_concrete replace
setblock ~153 ~23 ~165 minecraft:light_gray_concrete replace
setblock ~156 ~23 ~167 minecraft:light_gray_concrete replace
setblock ~156 ~23 ~169 minecraft:light_gray_concrete replace
setblock ~159 ~23 ~171 minecraft:light_gray_concrete replace
setblock ~154 ~23 ~172 minecraft:light_gray_concrete replace
setblock ~159 ~23 ~173 minecraft:light_gray_concrete replace
setblock ~201 ~23 ~175 minecraft:light_gray_concrete replace
setblock ~201 ~23 ~177 minecraft:light_gray_concrete replace
setblock ~189 ~23 ~179 minecraft:light_gray_concrete replace
setblock ~160 ~23 ~180 minecraft:light_gray_concrete replace
setblock ~189 ~23 ~181 minecraft:light_gray_concrete replace
setblock ~192 ~23 ~183 minecraft:light_gray_concrete replace
setblock ~160 ~23 ~184 minecraft:light_gray_concrete replace
setblock ~192 ~23 ~185 minecraft:light_gray_concrete replace
setblock ~195 ~23 ~187 minecraft:light_gray_concrete replace
setblock ~195 ~23 ~189 minecraft:light_gray_concrete replace
setblock ~195 ~23 ~191 minecraft:light_gray_concrete replace
setblock ~216 ~23 ~191 minecraft:light_gray_concrete replace
setblock ~190 ~23 ~192 minecraft:light_gray_concrete replace
setblock ~216 ~23 ~193 minecraft:light_gray_concrete replace
setblock ~210 ~23 ~195 minecraft:light_gray_concrete replace
setblock ~216 ~23 ~195 minecraft:light_gray_concrete replace
setblock ~210 ~23 ~197 minecraft:light_gray_concrete replace
setblock ~210 ~23 ~199 minecraft:light_gray_concrete replace
setblock ~213 ~23 ~199 minecraft:light_gray_concrete replace
setblock ~196 ~23 ~200 minecraft:light_gray_concrete replace
setblock ~213 ~23 ~201 minecraft:light_gray_concrete replace
setblock ~213 ~23 ~203 minecraft:light_gray_concrete replace
setblock ~219 ~23 ~203 minecraft:light_gray_concrete replace
setblock ~196 ~23 ~204 minecraft:light_gray_concrete replace
setblock ~243 ~23 ~207 minecraft:light_gray_concrete replace
setblock ~219 ~23 ~209 minecraft:light_gray_concrete replace
setblock ~219 ~23 ~211 minecraft:light_gray_concrete replace
setblock ~246 ~23 ~211 minecraft:light_gray_concrete replace
setblock ~211 ~23 ~212 minecraft:light_gray_concrete replace
setblock ~243 ~23 ~213 minecraft:light_gray_concrete replace
setblock ~243 ~23 ~215 minecraft:light_gray_concrete replace
setblock ~258 ~23 ~215 minecraft:light_gray_concrete replace
setblock ~246 ~23 ~217 minecraft:light_gray_concrete replace
setblock ~246 ~23 ~219 minecraft:light_gray_concrete replace
setblock ~267 ~23 ~219 minecraft:light_gray_concrete replace
setblock ~220 ~23 ~220 minecraft:light_gray_concrete replace
setblock ~258 ~23 ~221 minecraft:light_gray_concrete replace
setblock ~258 ~23 ~223 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~223 minecraft:light_gray_concrete replace
setblock ~220 ~23 ~224 minecraft:light_gray_concrete replace
setblock ~267 ~23 ~225 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~225 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~227 minecraft:light_gray_concrete replace
setblock ~267 ~23 ~227 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~229 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~231 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~233 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~233 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~235 minecraft:light_gray_concrete replace
setblock ~270 ~23 ~235 minecraft:light_gray_concrete replace
setblock ~259 ~23 ~236 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~237 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~237 minecraft:light_gray_concrete replace
setblock ~228 ~23 ~239 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~239 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~241 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~241 minecraft:light_gray_concrete replace
setblock ~234 ~23 ~243 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~243 minecraft:light_gray_concrete replace
setblock ~271 ~23 ~244 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~245 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~247 minecraft:light_gray_concrete replace
setblock ~271 ~23 ~248 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~249 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~249 minecraft:light_gray_concrete replace
setblock ~237 ~23 ~251 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~251 minecraft:light_gray_concrete replace
setblock ~229 ~23 ~252 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~253 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~253 minecraft:light_gray_concrete replace
setblock ~252 ~23 ~255 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~255 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~257 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~257 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~259 minecraft:light_gray_concrete replace
setblock ~264 ~23 ~259 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~259 minecraft:light_gray_concrete replace
setblock ~238 ~23 ~260 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~261 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~261 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~263 minecraft:light_gray_concrete replace
setblock ~276 ~23 ~263 minecraft:light_gray_concrete replace
setblock ~238 ~23 ~264 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~265 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~267 minecraft:light_gray_concrete replace
setblock ~279 ~23 ~267 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~269 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~269 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~269 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~271 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~273 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~273 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~275 minecraft:light_gray_concrete replace
setblock ~282 ~23 ~275 minecraft:light_gray_concrete replace
setblock ~277 ~23 ~276 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~277 minecraft:light_gray_concrete replace
setblock ~165 ~23 ~279 minecraft:light_gray_concrete replace
setblock ~162 ~23 ~283 minecraft:light_gray_concrete replace
setblock ~283 ~23 ~284 minecraft:light_gray_concrete replace
setblock ~162 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~165 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~285 minecraft:light_gray_concrete replace
setblock ~135 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~162 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~165 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~171 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~177 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~183 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~186 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~204 ~23 ~287 minecraft:light_gray_concrete replace
setblock ~283 ~23 ~288 minecraft:light_gray_concrete replace
setblock ~135 ~23 ~289 minecraft:light_gray_concrete replace
setblock ~163 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~172 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~178 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~187 ~23 ~292 minecraft:light_gray_concrete replace
setblock ~163 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~166 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~184 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~187 ~23 ~296 minecraft:light_gray_concrete replace
setblock ~285 ~23 ~299 minecraft:light_gray_concrete replace
setblock ~166 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~178 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~187 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~205 ~23 ~300 minecraft:light_gray_concrete replace
setblock ~222 ~23 ~303 minecraft:light_gray_concrete replace
fill ~79 ~24 ~4 ~79 ~24 ~5 minecraft:light_gray_concrete replace
fill ~78 ~24 ~6 ~80 ~24 ~6 minecraft:light_gray_concrete replace
fill ~97 ~24 ~8 ~97 ~24 ~9 minecraft:light_gray_concrete replace
fill ~127 ~24 ~8 ~127 ~24 ~9 minecraft:light_gray_concrete replace
fill ~96 ~24 ~10 ~128 ~24 ~10 minecraft:light_gray_concrete replace
fill ~100 ~24 ~12 ~100 ~24 ~13 minecraft:light_gray_concrete replace
fill ~90 ~24 ~14 ~101 ~24 ~14 minecraft:light_gray_concrete replace
fill ~91 ~24 ~16 ~91 ~24 ~17 minecraft:light_gray_concrete replace
fill ~115 ~24 ~16 ~115 ~24 ~17 minecraft:light_gray_concrete replace
fill ~154 ~24 ~16 ~154 ~24 ~17 minecraft:light_gray_concrete replace
fill ~90 ~24 ~18 ~155 ~24 ~18 minecraft:light_gray_concrete replace
fill ~118 ~24 ~20 ~118 ~24 ~21 minecraft:light_gray_concrete replace
fill ~105 ~24 ~22 ~119 ~24 ~22 minecraft:light_gray_concrete replace
fill ~112 ~24 ~24 ~112 ~24 ~25 minecraft:light_gray_concrete replace
fill ~142 ~24 ~24 ~142 ~24 ~25 minecraft:light_gray_concrete replace
fill ~178 ~24 ~24 ~178 ~24 ~25 minecraft:light_gray_concrete replace
fill ~111 ~24 ~26 ~179 ~24 ~26 minecraft:light_gray_concrete replace
fill ~145 ~24 ~28 ~145 ~24 ~29 minecraft:light_gray_concrete replace
fill ~126 ~24 ~30 ~146 ~24 ~30 minecraft:light_gray_concrete replace
fill ~139 ~24 ~32 ~139 ~24 ~33 minecraft:light_gray_concrete replace
fill ~175 ~24 ~32 ~175 ~24 ~33 minecraft:light_gray_concrete replace
fill ~208 ~24 ~32 ~208 ~24 ~33 minecraft:light_gray_concrete replace
fill ~138 ~24 ~34 ~209 ~24 ~34 minecraft:light_gray_concrete replace
fill ~187 ~24 ~36 ~187 ~24 ~37 minecraft:light_gray_concrete replace
fill ~150 ~24 ~38 ~188 ~24 ~38 minecraft:light_gray_concrete replace
fill ~172 ~24 ~40 ~172 ~24 ~41 minecraft:light_gray_concrete replace
fill ~202 ~24 ~40 ~202 ~24 ~41 minecraft:light_gray_concrete replace
fill ~226 ~24 ~40 ~226 ~24 ~41 minecraft:light_gray_concrete replace
fill ~168 ~24 ~42 ~227 ~24 ~42 minecraft:light_gray_concrete replace
fill ~205 ~24 ~44 ~205 ~24 ~45 minecraft:light_gray_concrete replace
fill ~174 ~24 ~46 ~206 ~24 ~46 minecraft:light_gray_concrete replace
fill ~199 ~24 ~48 ~199 ~24 ~49 minecraft:light_gray_concrete replace
fill ~238 ~24 ~48 ~238 ~24 ~49 minecraft:light_gray_concrete replace
fill ~250 ~24 ~48 ~250 ~24 ~49 minecraft:light_gray_concrete replace
fill ~198 ~24 ~50 ~251 ~24 ~50 minecraft:light_gray_concrete replace
fill ~241 ~24 ~52 ~241 ~24 ~53 minecraft:light_gray_concrete replace
fill ~207 ~24 ~54 ~242 ~24 ~54 minecraft:light_gray_concrete replace
fill ~235 ~24 ~56 ~235 ~24 ~57 minecraft:light_gray_concrete replace
fill ~283 ~24 ~56 ~283 ~24 ~57 minecraft:light_gray_concrete replace
fill ~292 ~24 ~56 ~292 ~24 ~57 minecraft:light_gray_concrete replace
fill ~231 ~24 ~58 ~293 ~24 ~58 minecraft:light_gray_concrete replace
fill ~262 ~24 ~60 ~262 ~24 ~61 minecraft:light_gray_concrete replace
fill ~271 ~24 ~60 ~271 ~24 ~61 minecraft:light_gray_concrete replace
fill ~301 ~24 ~60 ~301 ~24 ~61 minecraft:light_gray_concrete replace
fill ~240 ~24 ~62 ~302 ~24 ~62 minecraft:light_gray_concrete replace
fill ~316 ~24 ~64 ~316 ~24 ~65 minecraft:light_gray_concrete replace
fill ~255 ~24 ~66 ~317 ~24 ~66 minecraft:light_gray_concrete replace
fill ~265 ~24 ~68 ~265 ~24 ~69 minecraft:light_gray_concrete replace
fill ~225 ~24 ~70 ~266 ~24 ~70 minecraft:light_gray_concrete replace
fill ~310 ~24 ~72 ~310 ~24 ~73 minecraft:light_gray_concrete replace
fill ~313 ~24 ~72 ~313 ~24 ~73 minecraft:light_gray_concrete replace
fill ~337 ~24 ~72 ~337 ~24 ~73 minecraft:light_gray_concrete replace
fill ~261 ~24 ~74 ~338 ~24 ~74 minecraft:light_gray_concrete replace
fill ~280 ~24 ~76 ~280 ~24 ~77 minecraft:light_gray_concrete replace
fill ~328 ~24 ~76 ~328 ~24 ~77 minecraft:light_gray_concrete replace
fill ~249 ~24 ~78 ~329 ~24 ~78 minecraft:light_gray_concrete replace
fill ~343 ~24 ~80 ~343 ~24 ~81 minecraft:light_gray_concrete replace
fill ~273 ~24 ~82 ~344 ~24 ~82 minecraft:light_gray_concrete replace
fill ~82 ~24 ~84 ~82 ~24 ~85 minecraft:light_gray_concrete replace
fill ~81 ~24 ~86 ~83 ~24 ~86 minecraft:light_gray_concrete replace
fill ~85 ~24 ~88 ~85 ~24 ~89 minecraft:light_gray_concrete replace
fill ~84 ~24 ~90 ~86 ~24 ~90 minecraft:light_gray_concrete replace
fill ~88 ~24 ~92 ~88 ~24 ~93 minecraft:light_gray_concrete replace
fill ~87 ~24 ~94 ~89 ~24 ~94 minecraft:light_gray_concrete replace
fill ~133 ~24 ~100 ~133 ~24 ~101 minecraft:light_gray_concrete replace
fill ~136 ~24 ~100 ~136 ~24 ~101 minecraft:light_gray_concrete replace
fill ~120 ~24 ~102 ~137 ~24 ~102 minecraft:light_gray_concrete replace
fill ~103 ~24 ~104 ~103 ~24 ~105 minecraft:light_gray_concrete replace
fill ~93 ~24 ~106 ~104 ~24 ~106 minecraft:light_gray_concrete replace
fill ~106 ~24 ~108 ~106 ~24 ~109 minecraft:light_gray_concrete replace
fill ~96 ~24 ~110 ~107 ~24 ~110 minecraft:light_gray_concrete replace
fill ~109 ~24 ~112 ~109 ~24 ~113 minecraft:light_gray_concrete replace
fill ~99 ~24 ~114 ~110 ~24 ~114 minecraft:light_gray_concrete replace
fill ~157 ~24 ~120 ~157 ~24 ~121 minecraft:light_gray_concrete replace
fill ~160 ~24 ~120 ~160 ~24 ~121 minecraft:light_gray_concrete replace
fill ~132 ~24 ~122 ~161 ~24 ~122 minecraft:light_gray_concrete replace
fill ~121 ~24 ~124 ~121 ~24 ~125 minecraft:light_gray_concrete replace
fill ~111 ~24 ~126 ~122 ~24 ~126 minecraft:light_gray_concrete replace
fill ~124 ~24 ~128 ~124 ~24 ~129 minecraft:light_gray_concrete replace
fill ~114 ~24 ~130 ~125 ~24 ~130 minecraft:light_gray_concrete replace
fill ~130 ~24 ~132 ~130 ~24 ~133 minecraft:light_gray_concrete replace
fill ~117 ~24 ~134 ~131 ~24 ~134 minecraft:light_gray_concrete replace
fill ~181 ~24 ~140 ~181 ~24 ~141 minecraft:light_gray_concrete replace
fill ~184 ~24 ~140 ~184 ~24 ~141 minecraft:light_gray_concrete replace
fill ~147 ~24 ~142 ~185 ~24 ~142 minecraft:light_gray_concrete replace
fill ~151 ~24 ~144 ~151 ~24 ~145 minecraft:light_gray_concrete replace
fill ~129 ~24 ~146 ~152 ~24 ~146 minecraft:light_gray_concrete replace
fill ~166 ~24 ~148 ~166 ~24 ~149 minecraft:light_gray_concrete replace
fill ~138 ~24 ~150 ~167 ~24 ~150 minecraft:light_gray_concrete replace
fill ~169 ~24 ~152 ~169 ~24 ~153 minecraft:light_gray_concrete replace
fill ~141 ~24 ~154 ~170 ~24 ~154 minecraft:light_gray_concrete replace
fill ~211 ~24 ~156 ~211 ~24 ~157 minecraft:light_gray_concrete replace
fill ~214 ~24 ~156 ~214 ~24 ~157 minecraft:light_gray_concrete replace
fill ~180 ~24 ~158 ~215 ~24 ~158 minecraft:light_gray_concrete replace
fill ~190 ~24 ~160 ~190 ~24 ~161 minecraft:light_gray_concrete replace
fill ~153 ~24 ~162 ~191 ~24 ~162 minecraft:light_gray_concrete replace
fill ~193 ~24 ~164 ~193 ~24 ~165 minecraft:light_gray_concrete replace
fill ~156 ~24 ~166 ~194 ~24 ~166 minecraft:light_gray_concrete replace
fill ~196 ~24 ~168 ~196 ~24 ~169 minecraft:light_gray_concrete replace
fill ~159 ~24 ~170 ~197 ~24 ~170 minecraft:light_gray_concrete replace
fill ~229 ~24 ~172 ~229 ~24 ~173 minecraft:light_gray_concrete replace
fill ~232 ~24 ~172 ~232 ~24 ~173 minecraft:light_gray_concrete replace
fill ~201 ~24 ~174 ~233 ~24 ~174 minecraft:light_gray_concrete replace
fill ~217 ~24 ~176 ~217 ~24 ~177 minecraft:light_gray_concrete replace
fill ~189 ~24 ~178 ~218 ~24 ~178 minecraft:light_gray_concrete replace
fill ~220 ~24 ~180 ~220 ~24 ~181 minecraft:light_gray_concrete replace
fill ~192 ~24 ~182 ~221 ~24 ~182 minecraft:light_gray_concrete replace
fill ~223 ~24 ~184 ~223 ~24 ~185 minecraft:light_gray_concrete replace
fill ~195 ~24 ~186 ~224 ~24 ~186 minecraft:light_gray_concrete replace
fill ~253 ~24 ~188 ~253 ~24 ~189 minecraft:light_gray_concrete replace
fill ~256 ~24 ~188 ~256 ~24 ~189 minecraft:light_gray_concrete replace
fill ~216 ~24 ~190 ~257 ~24 ~190 minecraft:light_gray_concrete replace
fill ~244 ~24 ~192 ~244 ~24 ~193 minecraft:light_gray_concrete replace
fill ~210 ~24 ~194 ~245 ~24 ~194 minecraft:light_gray_concrete replace
fill ~247 ~24 ~196 ~247 ~24 ~197 minecraft:light_gray_concrete replace
fill ~213 ~24 ~198 ~248 ~24 ~198 minecraft:light_gray_concrete replace
fill ~259 ~24 ~200 ~259 ~24 ~201 minecraft:light_gray_concrete replace
fill ~219 ~24 ~202 ~260 ~24 ~202 minecraft:light_gray_concrete replace
fill ~286 ~24 ~204 ~286 ~24 ~205 minecraft:light_gray_concrete replace
fill ~289 ~24 ~204 ~289 ~24 ~205 minecraft:light_gray_concrete replace
fill ~243 ~24 ~206 ~290 ~24 ~206 minecraft:light_gray_concrete replace
fill ~295 ~24 ~208 ~295 ~24 ~209 minecraft:light_gray_concrete replace
fill ~298 ~24 ~208 ~298 ~24 ~209 minecraft:light_gray_concrete replace
fill ~246 ~24 ~210 ~299 ~24 ~210 minecraft:light_gray_concrete replace
fill ~319 ~24 ~212 ~319 ~24 ~213 minecraft:light_gray_concrete replace
fill ~258 ~24 ~214 ~320 ~24 ~214 minecraft:light_gray_concrete replace
fill ~331 ~24 ~216 ~331 ~24 ~217 minecraft:light_gray_concrete replace
fill ~267 ~24 ~218 ~332 ~24 ~218 minecraft:light_gray_concrete replace
fill ~334 ~24 ~220 ~334 ~24 ~221 minecraft:light_gray_concrete replace
fill ~270 ~24 ~222 ~335 ~24 ~222 minecraft:light_gray_concrete replace
fill ~268 ~24 ~224 ~268 ~24 ~225 minecraft:light_gray_concrete replace
fill ~228 ~24 ~226 ~269 ~24 ~226 minecraft:light_gray_concrete replace
fill ~274 ~24 ~228 ~274 ~24 ~229 minecraft:light_gray_concrete replace
fill ~234 ~24 ~230 ~275 ~24 ~230 minecraft:light_gray_concrete replace
fill ~277 ~24 ~232 ~277 ~24 ~233 minecraft:light_gray_concrete replace
fill ~237 ~24 ~234 ~278 ~24 ~234 minecraft:light_gray_concrete replace
fill ~304 ~24 ~236 ~304 ~24 ~237 minecraft:light_gray_concrete replace
fill ~307 ~24 ~236 ~307 ~24 ~237 minecraft:light_gray_concrete replace
fill ~252 ~24 ~238 ~308 ~24 ~238 minecraft:light_gray_concrete replace
fill ~322 ~24 ~240 ~322 ~24 ~241 minecraft:light_gray_concrete replace
fill ~325 ~24 ~240 ~325 ~24 ~241 minecraft:light_gray_concrete replace
fill ~264 ~24 ~242 ~326 ~24 ~242 minecraft:light_gray_concrete replace
fill ~346 ~24 ~244 ~346 ~24 ~245 minecraft:light_gray_concrete replace
fill ~276 ~24 ~246 ~347 ~24 ~246 minecraft:light_gray_concrete replace
fill ~349 ~24 ~248 ~349 ~24 ~249 minecraft:light_gray_concrete replace
fill ~279 ~24 ~250 ~350 ~24 ~250 minecraft:light_gray_concrete replace
fill ~352 ~24 ~252 ~352 ~24 ~253 minecraft:light_gray_concrete replace
fill ~282 ~24 ~254 ~353 ~24 ~254 minecraft:light_gray_concrete replace
fill ~133 ~24 ~256 ~133 ~24 ~257 minecraft:light_gray_concrete replace
fill ~136 ~24 ~256 ~136 ~24 ~257 minecraft:light_gray_concrete replace
fill ~148 ~24 ~256 ~148 ~24 ~257 minecraft:light_gray_concrete replace
fill ~157 ~24 ~256 ~157 ~24 ~257 minecraft:light_gray_concrete replace
fill ~160 ~24 ~256 ~160 ~24 ~257 minecraft:light_gray_concrete replace
fill ~181 ~24 ~256 ~181 ~24 ~257 minecraft:light_gray_concrete replace
fill ~184 ~24 ~256 ~184 ~24 ~257 minecraft:light_gray_concrete replace
fill ~211 ~24 ~256 ~211 ~24 ~257 minecraft:light_gray_concrete replace
fill ~214 ~24 ~256 ~214 ~24 ~257 minecraft:light_gray_concrete replace
fill ~229 ~24 ~256 ~229 ~24 ~257 minecraft:light_gray_concrete replace
fill ~232 ~24 ~256 ~232 ~24 ~257 minecraft:light_gray_concrete replace
fill ~253 ~24 ~256 ~253 ~24 ~257 minecraft:light_gray_concrete replace
fill ~256 ~24 ~256 ~256 ~24 ~257 minecraft:light_gray_concrete replace
fill ~286 ~24 ~256 ~286 ~24 ~257 minecraft:light_gray_concrete replace
fill ~289 ~24 ~256 ~289 ~24 ~257 minecraft:light_gray_concrete replace
fill ~295 ~24 ~256 ~295 ~24 ~257 minecraft:light_gray_concrete replace
fill ~298 ~24 ~256 ~298 ~24 ~257 minecraft:light_gray_concrete replace
fill ~304 ~24 ~256 ~304 ~24 ~257 minecraft:light_gray_concrete replace
fill ~307 ~24 ~256 ~307 ~24 ~257 minecraft:light_gray_concrete replace
fill ~322 ~24 ~256 ~322 ~24 ~257 minecraft:light_gray_concrete replace
fill ~325 ~24 ~256 ~325 ~24 ~257 minecraft:light_gray_concrete replace
fill ~132 ~24 ~258 ~326 ~24 ~258 minecraft:light_gray_concrete replace
fill ~91 ~24 ~260 ~91 ~24 ~261 minecraft:light_gray_concrete replace
fill ~112 ~24 ~260 ~112 ~24 ~261 minecraft:light_gray_concrete replace
fill ~139 ~24 ~260 ~139 ~24 ~261 minecraft:light_gray_concrete replace
fill ~172 ~24 ~260 ~172 ~24 ~261 minecraft:light_gray_concrete replace
fill ~199 ~24 ~260 ~199 ~24 ~261 minecraft:light_gray_concrete replace
fill ~235 ~24 ~260 ~235 ~24 ~261 minecraft:light_gray_concrete replace
fill ~262 ~24 ~260 ~262 ~24 ~261 minecraft:light_gray_concrete replace
fill ~280 ~24 ~260 ~280 ~24 ~261 minecraft:light_gray_concrete replace
fill ~313 ~24 ~260 ~313 ~24 ~261 minecraft:light_gray_concrete replace
fill ~340 ~24 ~260 ~340 ~24 ~261 minecraft:light_gray_concrete replace
fill ~90 ~24 ~262 ~341 ~24 ~262 minecraft:light_gray_concrete replace
fill ~88 ~24 ~264 ~88 ~24 ~265 minecraft:light_gray_concrete replace
fill ~109 ~24 ~264 ~109 ~24 ~265 minecraft:light_gray_concrete replace
fill ~130 ~24 ~264 ~130 ~24 ~265 minecraft:light_gray_concrete replace
fill ~169 ~24 ~264 ~169 ~24 ~265 minecraft:light_gray_concrete replace
fill ~196 ~24 ~264 ~196 ~24 ~265 minecraft:light_gray_concrete replace
fill ~223 ~24 ~264 ~223 ~24 ~265 minecraft:light_gray_concrete replace
fill ~259 ~24 ~264 ~259 ~24 ~265 minecraft:light_gray_concrete replace
fill ~277 ~24 ~264 ~277 ~24 ~265 minecraft:light_gray_concrete replace
fill ~334 ~24 ~264 ~334 ~24 ~265 minecraft:light_gray_concrete replace
fill ~352 ~24 ~264 ~352 ~24 ~265 minecraft:light_gray_concrete replace
fill ~87 ~24 ~266 ~353 ~24 ~266 minecraft:light_gray_concrete replace
fill ~85 ~24 ~268 ~85 ~24 ~269 minecraft:light_gray_concrete replace
fill ~106 ~24 ~268 ~106 ~24 ~269 minecraft:light_gray_concrete replace
fill ~124 ~24 ~268 ~124 ~24 ~269 minecraft:light_gray_concrete replace
fill ~166 ~24 ~268 ~166 ~24 ~269 minecraft:light_gray_concrete replace
fill ~193 ~24 ~268 ~193 ~24 ~269 minecraft:light_gray_concrete replace
fill ~220 ~24 ~268 ~220 ~24 ~269 minecraft:light_gray_concrete replace
fill ~247 ~24 ~268 ~247 ~24 ~269 minecraft:light_gray_concrete replace
fill ~274 ~24 ~268 ~274 ~24 ~269 minecraft:light_gray_concrete replace
fill ~331 ~24 ~268 ~331 ~24 ~269 minecraft:light_gray_concrete replace
fill ~349 ~24 ~268 ~349 ~24 ~269 minecraft:light_gray_concrete replace
fill ~84 ~24 ~270 ~350 ~24 ~270 minecraft:light_gray_concrete replace
fill ~82 ~24 ~272 ~82 ~24 ~273 minecraft:light_gray_concrete replace
fill ~103 ~24 ~272 ~103 ~24 ~273 minecraft:light_gray_concrete replace
fill ~121 ~24 ~272 ~121 ~24 ~273 minecraft:light_gray_concrete replace
fill ~151 ~24 ~272 ~151 ~24 ~273 minecraft:light_gray_concrete replace
fill ~190 ~24 ~272 ~190 ~24 ~273 minecraft:light_gray_concrete replace
fill ~217 ~24 ~272 ~217 ~24 ~273 minecraft:light_gray_concrete replace
fill ~244 ~24 ~272 ~244 ~24 ~273 minecraft:light_gray_concrete replace
fill ~268 ~24 ~272 ~268 ~24 ~273 minecraft:light_gray_concrete replace
fill ~319 ~24 ~272 ~319 ~24 ~273 minecraft:light_gray_concrete replace
fill ~346 ~24 ~272 ~346 ~24 ~273 minecraft:light_gray_concrete replace
fill ~81 ~24 ~274 ~347 ~24 ~274 minecraft:light_gray_concrete replace
fill ~79 ~24 ~276 ~79 ~24 ~277 minecraft:light_gray_concrete replace
fill ~100 ~24 ~276 ~100 ~24 ~277 minecraft:light_gray_concrete replace
fill ~118 ~24 ~276 ~118 ~24 ~277 minecraft:light_gray_concrete replace
fill ~145 ~24 ~276 ~145 ~24 ~277 minecraft:light_gray_concrete replace
fill ~187 ~24 ~276 ~187 ~24 ~277 minecraft:light_gray_concrete replace
fill ~205 ~24 ~276 ~205 ~24 ~277 minecraft:light_gray_concrete replace
fill ~241 ~24 ~276 ~241 ~24 ~277 minecraft:light_gray_concrete replace
fill ~265 ~24 ~276 ~265 ~24 ~277 minecraft:light_gray_concrete replace
fill ~316 ~24 ~276 ~316 ~24 ~277 minecraft:light_gray_concrete replace
fill ~343 ~24 ~276 ~343 ~24 ~277 minecraft:light_gray_concrete replace
fill ~78 ~24 ~278 ~344 ~24 ~278 minecraft:light_gray_concrete replace
fill ~94 ~24 ~280 ~94 ~24 ~281 minecraft:light_gray_concrete replace
fill ~97 ~24 ~280 ~97 ~24 ~281 minecraft:light_gray_concrete replace
fill ~115 ~24 ~280 ~115 ~24 ~281 minecraft:light_gray_concrete replace
fill ~142 ~24 ~280 ~142 ~24 ~281 minecraft:light_gray_concrete replace
fill ~175 ~24 ~280 ~175 ~24 ~281 minecraft:light_gray_concrete replace
fill ~202 ~24 ~280 ~202 ~24 ~281 minecraft:light_gray_concrete replace
fill ~238 ~24 ~280 ~238 ~24 ~281 minecraft:light_gray_concrete replace
fill ~271 ~24 ~280 ~271 ~24 ~281 minecraft:light_gray_concrete replace
fill ~292 ~24 ~280 ~292 ~24 ~281 minecraft:light_gray_concrete replace
fill ~337 ~24 ~280 ~337 ~24 ~281 minecraft:light_gray_concrete replace
fill ~93 ~24 ~282 ~338 ~24 ~282 minecraft:light_gray_concrete replace
fill ~163 ~24 ~284 ~163 ~24 ~285 minecraft:light_gray_concrete replace
fill ~135 ~24 ~286 ~164 ~24 ~286 minecraft:light_gray_concrete replace
fill ~358 ~24 ~296 ~358 ~24 ~297 minecraft:light_gray_concrete replace
fill ~285 ~24 ~298 ~359 ~24 ~298 minecraft:light_gray_concrete replace
fill ~94 ~24 ~300 ~94 ~24 ~301 minecraft:light_gray_concrete replace
fill ~340 ~24 ~300 ~340 ~24 ~301 minecraft:light_gray_concrete replace
fill ~355 ~24 ~300 ~355 ~24 ~301 minecraft:light_gray_concrete replace
fill ~93 ~24 ~302 ~356 ~24 ~302 minecraft:light_gray_concrete replace
setblock ~79 ~25 ~4 minecraft:light_gray_concrete replace
setblock ~97 ~25 ~8 minecraft:light_gray_concrete replace
setblock ~127 ~25 ~8 minecraft:light_gray_concrete replace
setblock ~109 ~25 ~10 minecraft:light_gray_concrete replace
setblock ~111 ~25 ~10 minecraft:light_gray_concrete replace
setblock ~100 ~25 ~12 minecraft:light_gray_concrete replace
setblock ~97 ~25 ~14 minecraft:light_gray_concrete replace
setblock ~99 ~25 ~14 minecraft:light_gray_concrete replace
setblock ~91 ~25 ~16 minecraft:light_gray_concrete replace
setblock ~115 ~25 ~16 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~16 minecraft:light_gray_concrete replace
setblock ~99 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~101 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~128 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~144 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~146 ~25 ~18 minecraft:light_gray_concrete replace
setblock ~118 ~25 ~20 minecraft:light_gray_concrete replace
setblock ~112 ~25 ~22 minecraft:light_gray_concrete replace
setblock ~114 ~25 ~22 minecraft:light_gray_concrete replace
setblock ~112 ~25 ~24 minecraft:light_gray_concrete replace
setblock ~142 ~25 ~24 minecraft:light_gray_concrete replace
setblock ~178 ~25 ~24 minecraft:light_gray_concrete replace
setblock ~114 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~116 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~132 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~149 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~26 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~28 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~30 minecraft:light_gray_concrete replace
setblock ~135 ~25 ~30 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~32 minecraft:light_gray_concrete replace
setblock ~175 ~25 ~32 minecraft:light_gray_concrete replace
setblock ~208 ~25 ~32 minecraft:light_gray_concrete replace
setblock ~151 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~153 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~168 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~170 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~185 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~187 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~204 ~25 ~34 minecraft:light_gray_concrete replace
setblock ~187 ~25 ~36 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~159 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~38 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~40 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~40 minecraft:light_gray_concrete replace
setblock ~226 ~25 ~40 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~192 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~206 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~208 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~222 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~42 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~44 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~183 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~198 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~200 ~25 ~46 minecraft:light_gray_concrete replace
setblock ~199 ~25 ~48 minecraft:light_gray_concrete replace
setblock ~238 ~25 ~48 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~48 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~222 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~50 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~52 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~216 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~231 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~233 ~25 ~54 minecraft:light_gray_concrete replace
setblock ~235 ~25 ~56 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~56 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~56 minecraft:light_gray_concrete replace
setblock ~238 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~240 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~255 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~257 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~272 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~291 ~25 ~58 minecraft:light_gray_concrete replace
setblock ~262 ~25 ~60 minecraft:light_gray_concrete replace
setblock ~271 ~25 ~60 minecraft:light_gray_concrete replace
setblock ~301 ~25 ~60 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~249 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~264 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~281 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~62 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~64 minecraft:light_gray_concrete replace
setblock ~262 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~264 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~279 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~281 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~315 ~25 ~66 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~68 minecraft:light_gray_concrete replace
setblock ~232 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~234 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~249 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~251 ~25 ~70 minecraft:light_gray_concrete replace
setblock ~310 ~25 ~72 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~72 minecraft:light_gray_concrete replace
setblock ~337 ~25 ~72 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~270 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~285 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~287 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~302 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~304 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~321 ~25 ~74 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~76 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~76 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~258 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~273 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~275 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~290 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~324 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~78 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~80 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~297 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~333 ~25 ~82 minecraft:light_gray_concrete replace
setblock ~82 ~25 ~84 minecraft:light_gray_concrete replace
setblock ~85 ~25 ~88 minecraft:light_gray_concrete replace
setblock ~88 ~25 ~92 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~100 minecraft:light_gray_concrete replace
setblock ~136 ~25 ~100 minecraft:light_gray_concrete replace
setblock ~127 ~25 ~102 minecraft:light_gray_concrete replace
setblock ~129 ~25 ~102 minecraft:light_gray_concrete replace
setblock ~103 ~25 ~104 minecraft:light_gray_concrete replace
setblock ~100 ~25 ~106 minecraft:light_gray_concrete replace
setblock ~102 ~25 ~106 minecraft:light_gray_concrete replace
setblock ~106 ~25 ~108 minecraft:light_gray_concrete replace
setblock ~103 ~25 ~110 minecraft:light_gray_concrete replace
setblock ~105 ~25 ~110 minecraft:light_gray_concrete replace
setblock ~109 ~25 ~112 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~120 minecraft:light_gray_concrete replace
setblock ~160 ~25 ~120 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~122 minecraft:light_gray_concrete replace
setblock ~141 ~25 ~122 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~124 minecraft:light_gray_concrete replace
setblock ~118 ~25 ~126 minecraft:light_gray_concrete replace
setblock ~120 ~25 ~126 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~128 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~130 minecraft:light_gray_concrete replace
setblock ~123 ~25 ~130 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~132 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~140 minecraft:light_gray_concrete replace
setblock ~184 ~25 ~140 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~171 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~173 ~25 ~142 minecraft:light_gray_concrete replace
setblock ~151 ~25 ~144 minecraft:light_gray_concrete replace
setblock ~136 ~25 ~146 minecraft:light_gray_concrete replace
setblock ~138 ~25 ~146 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~148 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~162 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~150 minecraft:light_gray_concrete replace
setblock ~169 ~25 ~152 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~154 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~154 minecraft:light_gray_concrete replace
setblock ~211 ~25 ~156 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~156 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~158 minecraft:light_gray_concrete replace
setblock ~195 ~25 ~158 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~160 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~168 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~183 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~185 ~25 ~162 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~164 minecraft:light_gray_concrete replace
setblock ~169 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~171 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~186 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~188 ~25 ~166 minecraft:light_gray_concrete replace
setblock ~196 ~25 ~168 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~189 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~191 ~25 ~170 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~172 minecraft:light_gray_concrete replace
setblock ~232 ~25 ~172 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~174 minecraft:light_gray_concrete replace
setblock ~216 ~25 ~174 minecraft:light_gray_concrete replace
setblock ~217 ~25 ~176 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~178 minecraft:light_gray_concrete replace
setblock ~204 ~25 ~178 minecraft:light_gray_concrete replace
setblock ~220 ~25 ~180 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~182 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~182 minecraft:light_gray_concrete replace
setblock ~223 ~25 ~184 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~186 minecraft:light_gray_concrete replace
setblock ~209 ~25 ~186 minecraft:light_gray_concrete replace
setblock ~253 ~25 ~188 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~188 minecraft:light_gray_concrete replace
setblock ~228 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~230 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~245 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~190 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~192 minecraft:light_gray_concrete replace
setblock ~222 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~239 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~194 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~196 minecraft:light_gray_concrete replace
setblock ~225 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~242 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~198 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~200 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~246 ~25 ~202 minecraft:light_gray_concrete replace
setblock ~286 ~25 ~204 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~204 minecraft:light_gray_concrete replace
setblock ~251 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~253 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~270 ~25 ~206 minecraft:light_gray_concrete replace
setblock ~295 ~25 ~208 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~208 minecraft:light_gray_concrete replace
setblock ~254 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~271 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~273 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~288 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~290 ~25 ~210 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~212 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~285 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~302 ~25 ~214 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~216 minecraft:light_gray_concrete replace
setblock ~275 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~218 minecraft:light_gray_concrete replace
setblock ~334 ~25 ~220 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~284 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~330 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~332 ~25 ~222 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~224 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~243 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~258 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~260 ~25 ~226 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~228 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~249 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~264 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~230 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~232 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~252 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~267 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~269 ~25 ~234 minecraft:light_gray_concrete replace
setblock ~304 ~25 ~236 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~236 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~267 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~284 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~301 ~25 ~238 minecraft:light_gray_concrete replace
setblock ~322 ~25 ~240 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~240 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~279 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~242 minecraft:light_gray_concrete replace
setblock ~346 ~25 ~244 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~291 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~306 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~308 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~323 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~340 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~342 ~25 ~246 minecraft:light_gray_concrete replace
setblock ~349 ~25 ~248 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~345 ~25 ~250 minecraft:light_gray_concrete replace
setblock ~352 ~25 ~252 minecraft:light_gray_concrete replace
setblock ~294 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~311 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~330 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~345 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~347 ~25 ~254 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~136 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~148 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~160 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~181 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~184 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~211 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~214 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~232 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~253 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~256 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~286 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~295 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~304 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~322 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~325 ~25 ~256 minecraft:light_gray_concrete replace
setblock ~143 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~192 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~217 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~219 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~234 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~236 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~266 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~283 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~285 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~300 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~302 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~317 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~258 minecraft:light_gray_concrete replace
setblock ~91 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~112 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~199 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~235 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~262 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~313 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~340 ~25 ~260 minecraft:light_gray_concrete replace
setblock ~108 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~110 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~125 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~127 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~142 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~144 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~159 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~161 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~176 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~178 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~195 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~209 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~211 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~225 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~243 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~257 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~273 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~275 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~289 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~291 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~305 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~321 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~323 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~337 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~339 ~25 ~262 minecraft:light_gray_concrete replace
setblock ~88 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~109 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~169 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~196 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~223 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~277 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~334 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~352 ~25 ~264 minecraft:light_gray_concrete replace
setblock ~92 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~122 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~138 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~140 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~154 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~170 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~210 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~212 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~227 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~229 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~246 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~261 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~263 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~293 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~295 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~310 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~312 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~327 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~329 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~344 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~346 ~25 ~266 minecraft:light_gray_concrete replace
setblock ~85 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~106 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~166 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~193 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~220 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~247 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~331 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~349 ~25 ~268 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~96 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~111 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~113 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~128 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~130 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~147 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~162 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~164 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~192 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~207 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~209 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~224 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~226 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~243 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~258 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~260 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~290 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~307 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~309 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~324 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~326 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~341 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~270 minecraft:light_gray_concrete replace
setblock ~82 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~103 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~151 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~190 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~217 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~244 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~268 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~319 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~346 ~25 ~272 minecraft:light_gray_concrete replace
setblock ~88 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~90 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~105 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~107 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~122 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~124 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~139 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~141 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~156 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~158 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~184 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~186 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~201 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~203 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~233 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~235 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~252 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~284 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~299 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~301 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~318 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~333 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~335 ~25 ~274 minecraft:light_gray_concrete replace
setblock ~79 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~100 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~118 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~145 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~187 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~205 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~241 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~265 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~316 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~343 ~25 ~276 minecraft:light_gray_concrete replace
setblock ~87 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~89 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~104 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~106 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~121 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~123 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~138 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~140 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~155 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~157 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~172 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~174 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~204 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~218 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~220 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~234 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~236 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~250 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~252 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~280 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~282 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~296 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~298 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~312 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~314 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~328 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~330 ~25 ~278 minecraft:light_gray_concrete replace
setblock ~94 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~97 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~115 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~142 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~175 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~202 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~238 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~271 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~292 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~337 ~25 ~280 minecraft:light_gray_concrete replace
setblock ~99 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~101 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~131 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~133 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~148 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~150 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~189 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~191 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~206 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~208 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~223 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~225 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~240 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~242 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~257 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~259 ~25 ~282 minecraft:light_gray_concrete replace
setblock ~274 ~25 ~282 minecraft:light_gray_concrete replace
