setblock ~91 ~26 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~26 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~26 ~16 minecraft:redstone_wire replace
setblock ~118 ~26 ~20 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~26 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~26 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~26 ~24 minecraft:redstone_wire replace
setblock ~145 ~26 ~28 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~26 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~26 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~26 ~32 minecraft:redstone_wire replace
setblock ~187 ~26 ~36 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~26 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~26 ~40 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~26 ~40 minecraft:redstone_wire replace
setblock ~205 ~26 ~44 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~26 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~26 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~26 ~48 minecraft:redstone_wire replace
setblock ~241 ~26 ~52 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~26 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~26 ~56 minecraft:redstone_wire replace
setblock ~292 ~26 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~26 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~26 ~60 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~26 ~60 minecraft:redstone_wire replace
setblock ~316 ~26 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~26 ~68 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~26 ~72 minecraft:redstone_wire replace
setblock ~313 ~26 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~26 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~26 ~76 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~26 ~76 minecraft:redstone_wire replace
setblock ~343 ~26 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~26 ~84 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~26 ~88 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~26 ~92 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~26 ~100 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~26 ~100 minecraft:redstone_wire replace
setblock ~103 ~26 ~104 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~26 ~108 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~26 ~112 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~26 ~120 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~26 ~120 minecraft:redstone_wire replace
setblock ~121 ~26 ~124 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~26 ~128 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~26 ~132 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~26 ~140 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~26 ~140 minecraft:redstone_wire replace
setblock ~151 ~26 ~144 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~26 ~148 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~26 ~152 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~26 ~156 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~26 ~156 minecraft:redstone_wire replace
setblock ~190 ~26 ~160 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~26 ~164 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~26 ~168 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~26 ~172 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~26 ~172 minecraft:redstone_wire replace
setblock ~217 ~26 ~176 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~26 ~180 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~26 ~184 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~26 ~188 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~26 ~188 minecraft:redstone_wire replace
setblock ~244 ~26 ~192 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~26 ~196 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~26 ~200 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~26 ~204 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~26 ~204 minecraft:redstone_wire replace
setblock ~295 ~26 ~208 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~26 ~208 minecraft:redstone_wire replace
setblock ~319 ~26 ~212 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~26 ~216 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~26 ~220 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~26 ~224 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~26 ~228 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~26 ~232 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~26 ~236 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~26 ~236 minecraft:redstone_wire replace
setblock ~322 ~26 ~240 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~26 ~240 minecraft:redstone_wire replace
setblock ~346 ~26 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~26 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~26 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~26 ~256 minecraft:redstone_wire replace
setblock ~148 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~26 ~256 minecraft:redstone_wire replace
setblock ~181 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~26 ~256 minecraft:redstone_wire replace
setblock ~211 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~26 ~256 minecraft:redstone_wire replace
setblock ~229 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~26 ~256 minecraft:redstone_wire replace
setblock ~253 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~26 ~256 minecraft:redstone_wire replace
setblock ~286 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~26 ~256 minecraft:redstone_wire replace
setblock ~295 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~26 ~256 minecraft:redstone_wire replace
setblock ~304 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~26 ~256 minecraft:redstone_wire replace
setblock ~322 ~26 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~26 ~256 minecraft:redstone_wire replace
setblock ~91 ~26 ~260 minecraft:redstone_wire replace
setblock ~112 ~26 ~260 minecraft:redstone_wire replace
setblock ~139 ~26 ~260 minecraft:redstone_wire replace
setblock ~172 ~26 ~260 minecraft:redstone_wire replace
setblock ~199 ~26 ~260 minecraft:redstone_wire replace
setblock ~235 ~26 ~260 minecraft:redstone_wire replace
setblock ~262 ~26 ~260 minecraft:redstone_wire replace
setblock ~280 ~26 ~260 minecraft:redstone_wire replace
setblock ~313 ~26 ~260 minecraft:redstone_wire replace
setblock ~340 ~26 ~260 minecraft:redstone_wire replace
setblock ~88 ~26 ~264 minecraft:redstone_wire replace
setblock ~109 ~26 ~264 minecraft:redstone_wire replace
setblock ~130 ~26 ~264 minecraft:redstone_wire replace
setblock ~169 ~26 ~264 minecraft:redstone_wire replace
setblock ~196 ~26 ~264 minecraft:redstone_wire replace
setblock ~223 ~26 ~264 minecraft:redstone_wire replace
setblock ~259 ~26 ~264 minecraft:redstone_wire replace
setblock ~277 ~26 ~264 minecraft:redstone_wire replace
setblock ~334 ~26 ~264 minecraft:redstone_wire replace
setblock ~352 ~26 ~264 minecraft:redstone_wire replace
setblock ~85 ~26 ~268 minecraft:redstone_wire replace
setblock ~106 ~26 ~268 minecraft:redstone_wire replace
setblock ~124 ~26 ~268 minecraft:redstone_wire replace
setblock ~166 ~26 ~268 minecraft:redstone_wire replace
setblock ~193 ~26 ~268 minecraft:redstone_wire replace
setblock ~220 ~26 ~268 minecraft:redstone_wire replace
setblock ~247 ~26 ~268 minecraft:redstone_wire replace
setblock ~274 ~26 ~268 minecraft:redstone_wire replace
setblock ~331 ~26 ~268 minecraft:redstone_wire replace
setblock ~349 ~26 ~268 minecraft:redstone_wire replace
setblock ~82 ~26 ~272 minecraft:redstone_wire replace
setblock ~103 ~26 ~272 minecraft:redstone_wire replace
setblock ~121 ~26 ~272 minecraft:redstone_wire replace
setblock ~151 ~26 ~272 minecraft:redstone_wire replace
setblock ~190 ~26 ~272 minecraft:redstone_wire replace
setblock ~217 ~26 ~272 minecraft:redstone_wire replace
setblock ~244 ~26 ~272 minecraft:redstone_wire replace
setblock ~268 ~26 ~272 minecraft:redstone_wire replace
setblock ~319 ~26 ~272 minecraft:redstone_wire replace
setblock ~346 ~26 ~272 minecraft:redstone_wire replace
setblock ~79 ~26 ~276 minecraft:redstone_wire replace
setblock ~100 ~26 ~276 minecraft:redstone_wire replace
setblock ~118 ~26 ~276 minecraft:redstone_wire replace
setblock ~145 ~26 ~276 minecraft:redstone_wire replace
setblock ~187 ~26 ~276 minecraft:redstone_wire replace
setblock ~205 ~26 ~276 minecraft:redstone_wire replace
setblock ~241 ~26 ~276 minecraft:redstone_wire replace
setblock ~265 ~26 ~276 minecraft:redstone_wire replace
setblock ~316 ~26 ~276 minecraft:redstone_wire replace
setblock ~343 ~26 ~276 minecraft:redstone_wire replace
setblock ~94 ~26 ~280 minecraft:redstone_wire replace
setblock ~97 ~26 ~280 minecraft:redstone_wire replace
setblock ~115 ~26 ~280 minecraft:redstone_wire replace
setblock ~142 ~26 ~280 minecraft:redstone_wire replace
setblock ~175 ~26 ~280 minecraft:redstone_wire replace
setblock ~202 ~26 ~280 minecraft:redstone_wire replace
setblock ~238 ~26 ~280 minecraft:redstone_wire replace
setblock ~271 ~26 ~280 minecraft:redstone_wire replace
setblock ~292 ~26 ~280 minecraft:redstone_wire replace
setblock ~337 ~26 ~280 minecraft:redstone_wire replace
setblock ~163 ~26 ~284 minecraft:redstone_wire replace
setblock ~358 ~26 ~296 minecraft:redstone_wire replace
setblock ~94 ~26 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~26 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~26 ~300 minecraft:redstone_wire replace
fill ~78 ~27 ~4 ~78 ~27 ~16 minecraft:redstone_wire replace
fill ~96 ~27 ~8 ~96 ~27 ~20 minecraft:redstone_wire replace
fill ~126 ~27 ~8 ~126 ~27 ~12 minecraft:redstone_wire replace
fill ~99 ~27 ~12 ~99 ~27 ~24 minecraft:redstone_wire replace
fill ~90 ~27 ~16 ~90 ~27 ~28 minecraft:redstone_wire replace
fill ~114 ~27 ~16 ~114 ~27 ~28 minecraft:redstone_wire replace
fill ~153 ~27 ~16 ~153 ~27 ~20 minecraft:redstone_wire replace
setblock ~78 ~27 ~18 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~20 ~78 ~27 ~32 minecraft:redstone_wire replace
fill ~117 ~27 ~20 ~117 ~27 ~32 minecraft:redstone_wire replace
setblock ~96 ~27 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~24 ~96 ~27 ~36 minecraft:redstone_wire replace
fill ~111 ~27 ~24 ~111 ~27 ~36 minecraft:redstone_wire replace
fill ~141 ~27 ~24 ~141 ~27 ~36 minecraft:redstone_wire replace
fill ~177 ~27 ~24 ~177 ~27 ~28 minecraft:redstone_wire replace
setblock ~99 ~27 ~26 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~28 ~99 ~27 ~40 minecraft:redstone_wire replace
fill ~144 ~27 ~28 ~144 ~27 ~40 minecraft:redstone_wire replace
setblock ~90 ~27 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~30 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~32 ~90 ~27 ~44 minecraft:redstone_wire replace
fill ~114 ~27 ~32 ~114 ~27 ~44 minecraft:redstone_wire replace
fill ~138 ~27 ~32 ~138 ~27 ~44 minecraft:redstone_wire replace
fill ~174 ~27 ~32 ~174 ~27 ~44 minecraft:redstone_wire replace
fill ~207 ~27 ~32 ~207 ~27 ~36 minecraft:redstone_wire replace
setblock ~78 ~27 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~34 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~36 ~78 ~27 ~48 minecraft:redstone_wire replace
fill ~117 ~27 ~36 ~117 ~27 ~48 minecraft:redstone_wire replace
fill ~186 ~27 ~36 ~186 ~27 ~48 minecraft:redstone_wire replace
setblock ~96 ~27 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~40 ~96 ~27 ~52 minecraft:redstone_wire replace
fill ~111 ~27 ~40 ~111 ~27 ~52 minecraft:redstone_wire replace
fill ~141 ~27 ~40 ~141 ~27 ~52 minecraft:redstone_wire replace
fill ~171 ~27 ~40 ~171 ~27 ~52 minecraft:redstone_wire replace
fill ~201 ~27 ~40 ~201 ~27 ~52 minecraft:redstone_wire replace
fill ~225 ~27 ~40 ~225 ~27 ~44 minecraft:redstone_wire replace
setblock ~99 ~27 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~42 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~44 ~99 ~27 ~56 minecraft:redstone_wire replace
fill ~144 ~27 ~44 ~144 ~27 ~56 minecraft:redstone_wire replace
fill ~204 ~27 ~44 ~204 ~27 ~56 minecraft:redstone_wire replace
setblock ~90 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~46 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~48 ~90 ~27 ~60 minecraft:redstone_wire replace
fill ~114 ~27 ~48 ~114 ~27 ~60 minecraft:redstone_wire replace
fill ~138 ~27 ~48 ~138 ~27 ~60 minecraft:redstone_wire replace
fill ~174 ~27 ~48 ~174 ~27 ~60 minecraft:redstone_wire replace
fill ~198 ~27 ~48 ~198 ~27 ~60 minecraft:redstone_wire replace
fill ~237 ~27 ~48 ~237 ~27 ~60 minecraft:redstone_wire replace
fill ~249 ~27 ~48 ~249 ~27 ~52 minecraft:redstone_wire replace
setblock ~78 ~27 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~50 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~52 ~78 ~27 ~64 minecraft:redstone_wire replace
fill ~117 ~27 ~52 ~117 ~27 ~64 minecraft:redstone_wire replace
fill ~186 ~27 ~52 ~186 ~27 ~64 minecraft:redstone_wire replace
fill ~240 ~27 ~52 ~240 ~27 ~64 minecraft:redstone_wire replace
setblock ~96 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~56 ~96 ~27 ~68 minecraft:redstone_wire replace
fill ~111 ~27 ~56 ~111 ~27 ~68 minecraft:redstone_wire replace
fill ~141 ~27 ~56 ~141 ~27 ~68 minecraft:redstone_wire replace
fill ~171 ~27 ~56 ~171 ~27 ~68 minecraft:redstone_wire replace
fill ~201 ~27 ~56 ~201 ~27 ~68 minecraft:redstone_wire replace
fill ~234 ~27 ~56 ~234 ~27 ~68 minecraft:redstone_wire replace
fill ~282 ~27 ~56 ~282 ~27 ~60 minecraft:redstone_wire replace
fill ~291 ~27 ~56 ~291 ~27 ~68 minecraft:redstone_wire replace
setblock ~99 ~27 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~58 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~60 ~99 ~27 ~72 minecraft:redstone_wire replace
fill ~144 ~27 ~60 ~144 ~27 ~72 minecraft:redstone_wire replace
fill ~204 ~27 ~60 ~204 ~27 ~72 minecraft:redstone_wire replace
fill ~261 ~27 ~60 ~261 ~27 ~72 minecraft:redstone_wire replace
fill ~270 ~27 ~60 ~270 ~27 ~72 minecraft:redstone_wire replace
fill ~300 ~27 ~60 ~300 ~27 ~64 minecraft:redstone_wire replace
setblock ~90 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~62 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~64 ~90 ~27 ~76 minecraft:redstone_wire replace
fill ~114 ~27 ~64 ~114 ~27 ~76 minecraft:redstone_wire replace
fill ~138 ~27 ~64 ~138 ~27 ~76 minecraft:redstone_wire replace
fill ~174 ~27 ~64 ~174 ~27 ~76 minecraft:redstone_wire replace
fill ~198 ~27 ~64 ~198 ~27 ~76 minecraft:redstone_wire replace
fill ~237 ~27 ~64 ~237 ~27 ~76 minecraft:redstone_wire replace
fill ~315 ~27 ~64 ~315 ~27 ~76 minecraft:redstone_wire replace
setblock ~78 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~66 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~68 ~78 ~27 ~80 minecraft:redstone_wire replace
fill ~117 ~27 ~68 ~117 ~27 ~80 minecraft:redstone_wire replace
fill ~186 ~27 ~68 ~186 ~27 ~80 minecraft:redstone_wire replace
fill ~240 ~27 ~68 ~240 ~27 ~80 minecraft:redstone_wire replace
fill ~264 ~27 ~68 ~264 ~27 ~80 minecraft:redstone_wire replace
setblock ~96 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~27 ~72 ~96 ~27 ~84 minecraft:redstone_wire replace
fill ~111 ~27 ~72 ~111 ~27 ~84 minecraft:redstone_wire replace
fill ~141 ~27 ~72 ~141 ~27 ~84 minecraft:redstone_wire replace
fill ~171 ~27 ~72 ~171 ~27 ~84 minecraft:redstone_wire replace
fill ~201 ~27 ~72 ~201 ~27 ~84 minecraft:redstone_wire replace
fill ~234 ~27 ~72 ~234 ~27 ~84 minecraft:redstone_wire replace
fill ~291 ~27 ~72 ~291 ~27 ~84 minecraft:redstone_wire replace
fill ~309 ~27 ~72 ~309 ~27 ~76 minecraft:redstone_wire replace
fill ~312 ~27 ~72 ~312 ~27 ~84 minecraft:redstone_wire replace
fill ~336 ~27 ~72 ~336 ~27 ~84 minecraft:redstone_wire replace
setblock ~99 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~74 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~27 ~76 ~99 ~27 ~88 minecraft:redstone_wire replace
fill ~144 ~27 ~76 ~144 ~27 ~88 minecraft:redstone_wire replace
fill ~204 ~27 ~76 ~204 ~27 ~88 minecraft:redstone_wire replace
fill ~261 ~27 ~76 ~261 ~27 ~88 minecraft:redstone_wire replace
fill ~270 ~27 ~76 ~270 ~27 ~88 minecraft:redstone_wire replace
fill ~279 ~27 ~76 ~279 ~27 ~88 minecraft:redstone_wire replace
fill ~327 ~27 ~76 ~327 ~27 ~80 minecraft:redstone_wire replace
setblock ~90 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~78 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~80 ~90 ~27 ~92 minecraft:redstone_wire replace
fill ~114 ~27 ~80 ~114 ~27 ~92 minecraft:redstone_wire replace
fill ~138 ~27 ~80 ~138 ~27 ~92 minecraft:redstone_wire replace
fill ~174 ~27 ~80 ~174 ~27 ~92 minecraft:redstone_wire replace
fill ~198 ~27 ~80 ~198 ~27 ~92 minecraft:redstone_wire replace
fill ~237 ~27 ~80 ~237 ~27 ~92 minecraft:redstone_wire replace
fill ~315 ~27 ~80 ~315 ~27 ~92 minecraft:redstone_wire replace
fill ~342 ~27 ~80 ~342 ~27 ~92 minecraft:redstone_wire replace
setblock ~78 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~82 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~84 ~78 ~27 ~96 minecraft:redstone_wire replace
fill ~81 ~27 ~84 ~81 ~27 ~96 minecraft:redstone_wire replace
fill ~117 ~27 ~84 ~117 ~27 ~96 minecraft:redstone_wire replace
fill ~186 ~27 ~84 ~186 ~27 ~96 minecraft:redstone_wire replace
fill ~240 ~27 ~84 ~240 ~27 ~96 minecraft:redstone_wire replace
fill ~264 ~27 ~84 ~264 ~27 ~96 minecraft:redstone_wire replace
setblock ~96 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~88 ~84 ~27 ~100 minecraft:redstone_wire replace
fill ~96 ~27 ~88 ~96 ~27 ~100 minecraft:redstone_wire replace
fill ~111 ~27 ~88 ~111 ~27 ~100 minecraft:redstone_wire replace
fill ~141 ~27 ~88 ~141 ~27 ~100 minecraft:redstone_wire replace
fill ~171 ~27 ~88 ~171 ~27 ~100 minecraft:redstone_wire replace
fill ~201 ~27 ~88 ~201 ~27 ~100 minecraft:redstone_wire replace
fill ~234 ~27 ~88 ~234 ~27 ~100 minecraft:redstone_wire replace
fill ~291 ~27 ~88 ~291 ~27 ~100 minecraft:redstone_wire replace
fill ~312 ~27 ~88 ~312 ~27 ~100 minecraft:redstone_wire replace
fill ~336 ~27 ~88 ~336 ~27 ~100 minecraft:redstone_wire replace
setblock ~99 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~90 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~92 ~87 ~27 ~104 minecraft:redstone_wire replace
fill ~99 ~27 ~92 ~99 ~27 ~104 minecraft:redstone_wire replace
fill ~144 ~27 ~92 ~144 ~27 ~104 minecraft:redstone_wire replace
fill ~204 ~27 ~92 ~204 ~27 ~104 minecraft:redstone_wire replace
fill ~261 ~27 ~92 ~261 ~27 ~104 minecraft:redstone_wire replace
fill ~270 ~27 ~92 ~270 ~27 ~104 minecraft:redstone_wire replace
fill ~279 ~27 ~92 ~279 ~27 ~104 minecraft:redstone_wire replace
setblock ~90 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~94 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~96 ~90 ~27 ~108 minecraft:redstone_wire replace
fill ~114 ~27 ~96 ~114 ~27 ~108 minecraft:redstone_wire replace
fill ~138 ~27 ~96 ~138 ~27 ~108 minecraft:redstone_wire replace
fill ~174 ~27 ~96 ~174 ~27 ~108 minecraft:redstone_wire replace
fill ~198 ~27 ~96 ~198 ~27 ~108 minecraft:redstone_wire replace
fill ~237 ~27 ~96 ~237 ~27 ~108 minecraft:redstone_wire replace
fill ~315 ~27 ~96 ~315 ~27 ~108 minecraft:redstone_wire replace
fill ~342 ~27 ~96 ~342 ~27 ~108 minecraft:redstone_wire replace
setblock ~78 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~98 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~100 ~78 ~27 ~112 minecraft:redstone_wire replace
fill ~81 ~27 ~100 ~81 ~27 ~112 minecraft:redstone_wire replace
fill ~117 ~27 ~100 ~117 ~27 ~112 minecraft:redstone_wire replace
fill ~132 ~27 ~100 ~132 ~27 ~112 minecraft:redstone_wire replace
fill ~135 ~27 ~100 ~135 ~27 ~112 minecraft:redstone_wire replace
fill ~186 ~27 ~100 ~186 ~27 ~112 minecraft:redstone_wire replace
fill ~240 ~27 ~100 ~240 ~27 ~112 minecraft:redstone_wire replace
fill ~264 ~27 ~100 ~264 ~27 ~112 minecraft:redstone_wire replace
setblock ~84 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~104 ~84 ~27 ~116 minecraft:redstone_wire replace
fill ~96 ~27 ~104 ~96 ~27 ~116 minecraft:redstone_wire replace
fill ~102 ~27 ~104 ~102 ~27 ~116 minecraft:redstone_wire replace
fill ~111 ~27 ~104 ~111 ~27 ~116 minecraft:redstone_wire replace
fill ~141 ~27 ~104 ~141 ~27 ~116 minecraft:redstone_wire replace
fill ~171 ~27 ~104 ~171 ~27 ~116 minecraft:redstone_wire replace
fill ~201 ~27 ~104 ~201 ~27 ~116 minecraft:redstone_wire replace
fill ~234 ~27 ~104 ~234 ~27 ~116 minecraft:redstone_wire replace
fill ~291 ~27 ~104 ~291 ~27 ~116 minecraft:redstone_wire replace
fill ~312 ~27 ~104 ~312 ~27 ~116 minecraft:redstone_wire replace
fill ~336 ~27 ~104 ~336 ~27 ~116 minecraft:redstone_wire replace
setblock ~87 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~106 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~108 ~87 ~27 ~120 minecraft:redstone_wire replace
fill ~99 ~27 ~108 ~99 ~27 ~120 minecraft:redstone_wire replace
fill ~105 ~27 ~108 ~105 ~27 ~120 minecraft:redstone_wire replace
fill ~144 ~27 ~108 ~144 ~27 ~120 minecraft:redstone_wire replace
fill ~204 ~27 ~108 ~204 ~27 ~120 minecraft:redstone_wire replace
fill ~261 ~27 ~108 ~261 ~27 ~120 minecraft:redstone_wire replace
fill ~270 ~27 ~108 ~270 ~27 ~120 minecraft:redstone_wire replace
fill ~279 ~27 ~108 ~279 ~27 ~120 minecraft:redstone_wire replace
setblock ~90 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~110 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~112 ~90 ~27 ~124 minecraft:redstone_wire replace
fill ~108 ~27 ~112 ~108 ~27 ~124 minecraft:redstone_wire replace
fill ~114 ~27 ~112 ~114 ~27 ~124 minecraft:redstone_wire replace
fill ~138 ~27 ~112 ~138 ~27 ~124 minecraft:redstone_wire replace
fill ~174 ~27 ~112 ~174 ~27 ~124 minecraft:redstone_wire replace
fill ~198 ~27 ~112 ~198 ~27 ~124 minecraft:redstone_wire replace
fill ~237 ~27 ~112 ~237 ~27 ~124 minecraft:redstone_wire replace
fill ~315 ~27 ~112 ~315 ~27 ~124 minecraft:redstone_wire replace
fill ~342 ~27 ~112 ~342 ~27 ~124 minecraft:redstone_wire replace
setblock ~78 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~114 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~116 ~78 ~27 ~128 minecraft:redstone_wire replace
fill ~81 ~27 ~116 ~81 ~27 ~128 minecraft:redstone_wire replace
fill ~117 ~27 ~116 ~117 ~27 ~128 minecraft:redstone_wire replace
fill ~132 ~27 ~116 ~132 ~27 ~128 minecraft:redstone_wire replace
fill ~135 ~27 ~116 ~135 ~27 ~128 minecraft:redstone_wire replace
fill ~186 ~27 ~116 ~186 ~27 ~128 minecraft:redstone_wire replace
fill ~240 ~27 ~116 ~240 ~27 ~128 minecraft:redstone_wire replace
fill ~264 ~27 ~116 ~264 ~27 ~128 minecraft:redstone_wire replace
setblock ~84 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~120 ~84 ~27 ~132 minecraft:redstone_wire replace
fill ~96 ~27 ~120 ~96 ~27 ~132 minecraft:redstone_wire replace
fill ~102 ~27 ~120 ~102 ~27 ~132 minecraft:redstone_wire replace
fill ~111 ~27 ~120 ~111 ~27 ~132 minecraft:redstone_wire replace
fill ~141 ~27 ~120 ~141 ~27 ~132 minecraft:redstone_wire replace
fill ~156 ~27 ~120 ~156 ~27 ~132 minecraft:redstone_wire replace
fill ~159 ~27 ~120 ~159 ~27 ~132 minecraft:redstone_wire replace
fill ~171 ~27 ~120 ~171 ~27 ~132 minecraft:redstone_wire replace
fill ~201 ~27 ~120 ~201 ~27 ~132 minecraft:redstone_wire replace
fill ~234 ~27 ~120 ~234 ~27 ~132 minecraft:redstone_wire replace
fill ~291 ~27 ~120 ~291 ~27 ~132 minecraft:redstone_wire replace
fill ~312 ~27 ~120 ~312 ~27 ~132 minecraft:redstone_wire replace
fill ~336 ~27 ~120 ~336 ~27 ~132 minecraft:redstone_wire replace
setblock ~87 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~122 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~124 ~87 ~27 ~136 minecraft:redstone_wire replace
fill ~99 ~27 ~124 ~99 ~27 ~136 minecraft:redstone_wire replace
fill ~105 ~27 ~124 ~105 ~27 ~136 minecraft:redstone_wire replace
fill ~120 ~27 ~124 ~120 ~27 ~136 minecraft:redstone_wire replace
fill ~144 ~27 ~124 ~144 ~27 ~136 minecraft:redstone_wire replace
fill ~204 ~27 ~124 ~204 ~27 ~136 minecraft:redstone_wire replace
fill ~261 ~27 ~124 ~261 ~27 ~136 minecraft:redstone_wire replace
fill ~270 ~27 ~124 ~270 ~27 ~136 minecraft:redstone_wire replace
fill ~279 ~27 ~124 ~279 ~27 ~136 minecraft:redstone_wire replace
setblock ~90 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~126 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~128 ~90 ~27 ~140 minecraft:redstone_wire replace
fill ~108 ~27 ~128 ~108 ~27 ~140 minecraft:redstone_wire replace
fill ~114 ~27 ~128 ~114 ~27 ~140 minecraft:redstone_wire replace
fill ~123 ~27 ~128 ~123 ~27 ~140 minecraft:redstone_wire replace
fill ~138 ~27 ~128 ~138 ~27 ~140 minecraft:redstone_wire replace
fill ~174 ~27 ~128 ~174 ~27 ~140 minecraft:redstone_wire replace
fill ~198 ~27 ~128 ~198 ~27 ~140 minecraft:redstone_wire replace
fill ~237 ~27 ~128 ~237 ~27 ~140 minecraft:redstone_wire replace
fill ~315 ~27 ~128 ~315 ~27 ~140 minecraft:redstone_wire replace
fill ~342 ~27 ~128 ~342 ~27 ~140 minecraft:redstone_wire replace
setblock ~78 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~27 ~130 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~27 ~132 ~78 ~27 ~144 minecraft:redstone_wire replace
fill ~81 ~27 ~132 ~81 ~27 ~144 minecraft:redstone_wire replace
fill ~117 ~27 ~132 ~117 ~27 ~144 minecraft:redstone_wire replace
fill ~129 ~27 ~132 ~129 ~27 ~144 minecraft:redstone_wire replace
fill ~132 ~27 ~132 ~132 ~27 ~144 minecraft:redstone_wire replace
fill ~135 ~27 ~132 ~135 ~27 ~144 minecraft:redstone_wire replace
fill ~186 ~27 ~132 ~186 ~27 ~144 minecraft:redstone_wire replace
fill ~240 ~27 ~132 ~240 ~27 ~144 minecraft:redstone_wire replace
fill ~264 ~27 ~132 ~264 ~27 ~144 minecraft:redstone_wire replace
setblock ~84 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~27 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~27 ~136 ~84 ~27 ~148 minecraft:redstone_wire replace
fill ~96 ~27 ~136 ~96 ~27 ~148 minecraft:redstone_wire replace
fill ~102 ~27 ~136 ~102 ~27 ~148 minecraft:redstone_wire replace
fill ~111 ~27 ~136 ~111 ~27 ~148 minecraft:redstone_wire replace
fill ~141 ~27 ~136 ~141 ~27 ~148 minecraft:redstone_wire replace
fill ~156 ~27 ~136 ~156 ~27 ~148 minecraft:redstone_wire replace
fill ~159 ~27 ~136 ~159 ~27 ~148 minecraft:redstone_wire replace
fill ~171 ~27 ~136 ~171 ~27 ~148 minecraft:redstone_wire replace
fill ~201 ~27 ~136 ~201 ~27 ~148 minecraft:redstone_wire replace
fill ~234 ~27 ~136 ~234 ~27 ~148 minecraft:redstone_wire replace
fill ~291 ~27 ~136 ~291 ~27 ~148 minecraft:redstone_wire replace
fill ~312 ~27 ~136 ~312 ~27 ~148 minecraft:redstone_wire replace
fill ~336 ~27 ~136 ~336 ~27 ~148 minecraft:redstone_wire replace
setblock ~87 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~27 ~138 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~27 ~140 ~87 ~27 ~152 minecraft:redstone_wire replace
fill ~99 ~27 ~140 ~99 ~27 ~152 minecraft:redstone_wire replace
fill ~105 ~27 ~140 ~105 ~27 ~152 minecraft:redstone_wire replace
fill ~120 ~27 ~140 ~120 ~27 ~152 minecraft:redstone_wire replace
fill ~144 ~27 ~140 ~144 ~27 ~152 minecraft:redstone_wire replace
fill ~180 ~27 ~140 ~180 ~27 ~152 minecraft:redstone_wire replace
fill ~183 ~27 ~140 ~183 ~27 ~152 minecraft:redstone_wire replace
fill ~204 ~27 ~140 ~204 ~27 ~152 minecraft:redstone_wire replace
fill ~261 ~27 ~140 ~261 ~27 ~152 minecraft:redstone_wire replace
fill ~270 ~27 ~140 ~270 ~27 ~152 minecraft:redstone_wire replace
fill ~279 ~27 ~140 ~279 ~27 ~152 minecraft:redstone_wire replace
setblock ~90 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~27 ~142 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~27 ~144 ~90 ~27 ~156 minecraft:redstone_wire replace
fill ~108 ~27 ~144 ~108 ~27 ~156 minecraft:redstone_wire replace
fill ~114 ~27 ~144 ~114 ~27 ~156 minecraft:redstone_wire replace
fill ~123 ~27 ~144 ~123 ~27 ~156 minecraft:redstone_wire replace
fill ~138 ~27 ~144 ~138 ~27 ~156 minecraft:redstone_wire replace
