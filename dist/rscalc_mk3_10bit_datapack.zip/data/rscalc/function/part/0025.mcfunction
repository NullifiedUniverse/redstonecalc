fill ~120 ~63 ~492 ~120 ~63 ~504 minecraft:redstone_wire replace
fill ~138 ~63 ~492 ~138 ~63 ~504 minecraft:redstone_wire replace
fill ~162 ~63 ~492 ~162 ~63 ~504 minecraft:redstone_wire replace
setblock ~81 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~508 ~81 ~63 ~520 minecraft:redstone_wire replace
fill ~102 ~63 ~508 ~102 ~63 ~520 minecraft:redstone_wire replace
fill ~108 ~63 ~508 ~108 ~63 ~512 minecraft:redstone_wire replace
fill ~120 ~63 ~508 ~120 ~63 ~520 minecraft:redstone_wire replace
fill ~138 ~63 ~508 ~138 ~63 ~520 minecraft:redstone_wire replace
fill ~162 ~63 ~508 ~162 ~63 ~520 minecraft:redstone_wire replace
fill ~129 ~63 ~512 ~129 ~63 ~516 minecraft:redstone_wire replace
fill ~150 ~63 ~516 ~150 ~63 ~520 minecraft:redstone_wire replace
fill ~174 ~63 ~520 ~174 ~63 ~524 minecraft:redstone_wire replace
setblock ~81 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~524 ~81 ~63 ~536 minecraft:redstone_wire replace
fill ~102 ~63 ~524 ~102 ~63 ~536 minecraft:redstone_wire replace
fill ~120 ~63 ~524 ~120 ~63 ~536 minecraft:redstone_wire replace
fill ~138 ~63 ~524 ~138 ~63 ~536 minecraft:redstone_wire replace
fill ~162 ~63 ~524 ~162 ~63 ~536 minecraft:redstone_wire replace
fill ~201 ~63 ~524 ~201 ~63 ~528 minecraft:redstone_wire replace
setblock ~81 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~540 ~81 ~63 ~552 minecraft:redstone_wire replace
fill ~102 ~63 ~540 ~102 ~63 ~552 minecraft:redstone_wire replace
fill ~120 ~63 ~540 ~120 ~63 ~552 minecraft:redstone_wire replace
fill ~138 ~63 ~540 ~138 ~63 ~552 minecraft:redstone_wire replace
fill ~162 ~63 ~540 ~162 ~63 ~552 minecraft:redstone_wire replace
fill ~105 ~63 ~548 ~105 ~63 ~552 minecraft:redstone_wire replace
fill ~126 ~63 ~552 ~126 ~63 ~556 minecraft:redstone_wire replace
setblock ~81 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~556 ~81 ~63 ~568 minecraft:redstone_wire replace
fill ~102 ~63 ~556 ~102 ~63 ~568 minecraft:redstone_wire replace
fill ~120 ~63 ~556 ~120 ~63 ~568 minecraft:redstone_wire replace
fill ~138 ~63 ~556 ~138 ~63 ~568 minecraft:redstone_wire replace
fill ~144 ~63 ~556 ~144 ~63 ~560 minecraft:redstone_wire replace
fill ~162 ~63 ~556 ~162 ~63 ~568 minecraft:redstone_wire replace
fill ~171 ~63 ~560 ~171 ~63 ~564 minecraft:redstone_wire replace
fill ~195 ~63 ~564 ~195 ~63 ~568 minecraft:redstone_wire replace
setblock ~81 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~572 ~81 ~63 ~584 minecraft:redstone_wire replace
fill ~102 ~63 ~572 ~102 ~63 ~584 minecraft:redstone_wire replace
fill ~120 ~63 ~572 ~120 ~63 ~584 minecraft:redstone_wire replace
fill ~138 ~63 ~572 ~138 ~63 ~584 minecraft:redstone_wire replace
fill ~162 ~63 ~572 ~162 ~63 ~584 minecraft:redstone_wire replace
setblock ~81 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~588 ~81 ~63 ~600 minecraft:redstone_wire replace
fill ~99 ~63 ~588 ~99 ~63 ~592 minecraft:redstone_wire replace
fill ~102 ~63 ~588 ~102 ~63 ~600 minecraft:redstone_wire replace
fill ~120 ~63 ~588 ~120 ~63 ~600 minecraft:redstone_wire replace
fill ~138 ~63 ~588 ~138 ~63 ~600 minecraft:redstone_wire replace
fill ~162 ~63 ~588 ~162 ~63 ~600 minecraft:redstone_wire replace
fill ~123 ~63 ~592 ~123 ~63 ~596 minecraft:redstone_wire replace
fill ~141 ~63 ~596 ~141 ~63 ~600 minecraft:redstone_wire replace
fill ~168 ~63 ~600 ~168 ~63 ~604 minecraft:redstone_wire replace
setblock ~81 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~604 ~81 ~63 ~616 minecraft:redstone_wire replace
fill ~102 ~63 ~604 ~102 ~63 ~616 minecraft:redstone_wire replace
fill ~120 ~63 ~604 ~120 ~63 ~616 minecraft:redstone_wire replace
fill ~138 ~63 ~604 ~138 ~63 ~616 minecraft:redstone_wire replace
fill ~162 ~63 ~604 ~162 ~63 ~616 minecraft:redstone_wire replace
fill ~192 ~63 ~604 ~192 ~63 ~608 minecraft:redstone_wire replace
fill ~84 ~63 ~608 ~84 ~63 ~612 minecraft:redstone_wire replace
fill ~87 ~63 ~612 ~87 ~63 ~616 minecraft:redstone_wire replace
fill ~90 ~63 ~616 ~90 ~63 ~620 minecraft:redstone_wire replace
setblock ~81 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~620 ~81 ~63 ~632 minecraft:redstone_wire replace
fill ~93 ~63 ~620 ~93 ~63 ~624 minecraft:redstone_wire replace
fill ~102 ~63 ~620 ~102 ~63 ~632 minecraft:redstone_wire replace
fill ~120 ~63 ~620 ~120 ~63 ~632 minecraft:redstone_wire replace
fill ~138 ~63 ~620 ~138 ~63 ~632 minecraft:redstone_wire replace
fill ~162 ~63 ~620 ~162 ~63 ~632 minecraft:redstone_wire replace
fill ~96 ~63 ~624 ~96 ~63 ~628 minecraft:redstone_wire replace
fill ~117 ~63 ~628 ~117 ~63 ~632 minecraft:redstone_wire replace
fill ~147 ~63 ~632 ~147 ~63 ~636 minecraft:redstone_wire replace
setblock ~81 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~636 ~81 ~63 ~648 minecraft:redstone_wire replace
fill ~102 ~63 ~636 ~102 ~63 ~648 minecraft:redstone_wire replace
fill ~120 ~63 ~636 ~120 ~63 ~648 minecraft:redstone_wire replace
fill ~138 ~63 ~636 ~138 ~63 ~648 minecraft:redstone_wire replace
fill ~159 ~63 ~636 ~159 ~63 ~640 minecraft:redstone_wire replace
fill ~162 ~63 ~636 ~162 ~63 ~648 minecraft:redstone_wire replace
fill ~180 ~63 ~640 ~180 ~63 ~644 minecraft:redstone_wire replace
fill ~198 ~63 ~644 ~198 ~63 ~648 minecraft:redstone_wire replace
fill ~216 ~63 ~648 ~216 ~63 ~652 minecraft:redstone_wire replace
fill ~78 ~63 ~652 ~78 ~63 ~656 minecraft:redstone_wire replace
fill ~183 ~63 ~656 ~183 ~63 ~660 minecraft:redstone_wire replace
fill ~213 ~63 ~660 ~213 ~63 ~664 minecraft:redstone_wire replace
setblock ~102 ~64 ~327 minecraft:redstone_wire replace
setblock ~120 ~64 ~343 minecraft:redstone_wire replace
setblock ~162 ~64 ~359 minecraft:redstone_wire replace
setblock ~138 ~64 ~375 minecraft:redstone_wire replace
setblock ~210 ~64 ~379 minecraft:redstone_wire replace
setblock ~207 ~64 ~383 minecraft:redstone_wire replace
setblock ~189 ~64 ~387 minecraft:redstone_wire replace
setblock ~186 ~64 ~391 minecraft:redstone_wire replace
setblock ~81 ~64 ~395 minecraft:redstone_wire replace
setblock ~114 ~64 ~431 minecraft:redstone_wire replace
setblock ~135 ~64 ~435 minecraft:redstone_wire replace
setblock ~156 ~64 ~439 minecraft:redstone_wire replace
setblock ~165 ~64 ~443 minecraft:redstone_wire replace
setblock ~111 ~64 ~467 minecraft:redstone_wire replace
setblock ~132 ~64 ~471 minecraft:redstone_wire replace
setblock ~153 ~64 ~475 minecraft:redstone_wire replace
setblock ~177 ~64 ~479 minecraft:redstone_wire replace
setblock ~204 ~64 ~483 minecraft:redstone_wire replace
setblock ~108 ~64 ~507 minecraft:redstone_wire replace
setblock ~129 ~64 ~511 minecraft:redstone_wire replace
setblock ~150 ~64 ~515 minecraft:redstone_wire replace
setblock ~174 ~64 ~519 minecraft:redstone_wire replace
setblock ~201 ~64 ~523 minecraft:redstone_wire replace
setblock ~105 ~64 ~547 minecraft:redstone_wire replace
setblock ~126 ~64 ~551 minecraft:redstone_wire replace
setblock ~144 ~64 ~555 minecraft:redstone_wire replace
setblock ~171 ~64 ~559 minecraft:redstone_wire replace
setblock ~195 ~64 ~563 minecraft:redstone_wire replace
setblock ~99 ~64 ~587 minecraft:redstone_wire replace
setblock ~123 ~64 ~591 minecraft:redstone_wire replace
setblock ~141 ~64 ~595 minecraft:redstone_wire replace
setblock ~168 ~64 ~599 minecraft:redstone_wire replace
setblock ~192 ~64 ~603 minecraft:redstone_wire replace
setblock ~84 ~64 ~607 minecraft:redstone_wire replace
setblock ~87 ~64 ~611 minecraft:redstone_wire replace
setblock ~90 ~64 ~615 minecraft:redstone_wire replace
setblock ~93 ~64 ~619 minecraft:redstone_wire replace
setblock ~96 ~64 ~623 minecraft:redstone_wire replace
setblock ~117 ~64 ~627 minecraft:redstone_wire replace
setblock ~147 ~64 ~631 minecraft:redstone_wire replace
setblock ~159 ~64 ~635 minecraft:redstone_wire replace
setblock ~180 ~64 ~639 minecraft:redstone_wire replace
setblock ~198 ~64 ~643 minecraft:redstone_wire replace
setblock ~216 ~64 ~647 minecraft:redstone_wire replace
setblock ~78 ~64 ~651 minecraft:redstone_wire replace
setblock ~183 ~64 ~655 minecraft:redstone_wire replace
setblock ~213 ~64 ~659 minecraft:redstone_wire replace
setblock ~97 ~65 ~325 minecraft:redstone_wire replace
fill ~96 ~65 ~326 ~102 ~65 ~326 minecraft:redstone_wire replace
setblock ~100 ~65 ~341 minecraft:redstone_wire replace
fill ~99 ~65 ~342 ~107 ~65 ~342 minecraft:redstone_wire replace
setblock ~109 ~65 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~65 ~342 ~120 ~65 ~342 minecraft:redstone_wire replace
setblock ~106 ~65 ~357 minecraft:redstone_wire replace
fill ~105 ~65 ~358 ~115 ~65 ~358 minecraft:redstone_wire replace
setblock ~117 ~65 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~65 ~358 ~132 ~65 ~358 minecraft:redstone_wire replace
setblock ~134 ~65 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~65 ~358 ~149 ~65 ~358 minecraft:redstone_wire replace
setblock ~151 ~65 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~65 ~358 ~162 ~65 ~358 minecraft:redstone_wire replace
setblock ~103 ~65 ~373 minecraft:redstone_wire replace
fill ~102 ~65 ~374 ~108 ~65 ~374 minecraft:redstone_wire replace
setblock ~110 ~65 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~65 ~374 ~125 ~65 ~374 minecraft:redstone_wire replace
setblock ~127 ~65 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~65 ~374 ~138 ~65 ~374 minecraft:redstone_wire replace
setblock ~133 ~65 ~377 minecraft:redstone_wire replace
fill ~132 ~65 ~378 ~133 ~65 ~378 minecraft:redstone_wire replace
setblock ~134 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~65 ~378 ~148 ~65 ~378 minecraft:redstone_wire replace
setblock ~150 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~65 ~378 ~165 ~65 ~378 minecraft:redstone_wire replace
setblock ~167 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~65 ~378 ~182 ~65 ~378 minecraft:redstone_wire replace
setblock ~184 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~65 ~378 ~199 ~65 ~378 minecraft:redstone_wire replace
setblock ~201 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~65 ~378 ~210 ~65 ~378 minecraft:redstone_wire replace
setblock ~133 ~65 ~381 minecraft:redstone_wire replace
fill ~132 ~65 ~382 ~141 ~65 ~382 minecraft:redstone_wire replace
setblock ~143 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~65 ~382 ~158 ~65 ~382 minecraft:redstone_wire replace
setblock ~160 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~65 ~382 ~175 ~65 ~382 minecraft:redstone_wire replace
setblock ~177 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~65 ~382 ~192 ~65 ~382 minecraft:redstone_wire replace
setblock ~194 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~65 ~382 ~207 ~65 ~382 minecraft:redstone_wire replace
setblock ~115 ~65 ~385 minecraft:redstone_wire replace
fill ~114 ~65 ~386 ~123 ~65 ~386 minecraft:redstone_wire replace
setblock ~125 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~65 ~386 ~140 ~65 ~386 minecraft:redstone_wire replace
setblock ~142 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~65 ~386 ~157 ~65 ~386 minecraft:redstone_wire replace
setblock ~159 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~65 ~386 ~174 ~65 ~386 minecraft:redstone_wire replace
setblock ~176 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~65 ~386 ~189 ~65 ~386 minecraft:redstone_wire replace
setblock ~115 ~65 ~389 minecraft:redstone_wire replace
fill ~114 ~65 ~390 ~119 ~65 ~390 minecraft:redstone_wire replace
setblock ~121 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~390 ~136 ~65 ~390 minecraft:redstone_wire replace
setblock ~138 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~65 ~390 ~153 ~65 ~390 minecraft:redstone_wire replace
setblock ~155 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~65 ~390 ~170 ~65 ~390 minecraft:redstone_wire replace
setblock ~172 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~65 ~390 ~186 ~65 ~390 minecraft:redstone_wire replace
setblock ~82 ~65 ~393 minecraft:redstone_wire replace
fill ~81 ~65 ~394 ~83 ~65 ~394 minecraft:redstone_wire replace
setblock ~97 ~65 ~429 minecraft:redstone_wire replace
fill ~96 ~65 ~430 ~104 ~65 ~430 minecraft:redstone_wire replace
setblock ~106 ~65 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~65 ~430 ~114 ~65 ~430 minecraft:redstone_wire replace
setblock ~100 ~65 ~433 minecraft:redstone_wire replace
fill ~99 ~65 ~434 ~108 ~65 ~434 minecraft:redstone_wire replace
setblock ~110 ~65 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~65 ~434 ~125 ~65 ~434 minecraft:redstone_wire replace
setblock ~127 ~65 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~65 ~434 ~135 ~65 ~434 minecraft:redstone_wire replace
setblock ~103 ~65 ~437 minecraft:redstone_wire replace
fill ~102 ~65 ~438 ~112 ~65 ~438 minecraft:redstone_wire replace
setblock ~114 ~65 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~65 ~438 ~129 ~65 ~438 minecraft:redstone_wire replace
setblock ~131 ~65 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~65 ~438 ~146 ~65 ~438 minecraft:redstone_wire replace
setblock ~148 ~65 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~65 ~438 ~156 ~65 ~438 minecraft:redstone_wire replace
setblock ~106 ~65 ~441 minecraft:redstone_wire replace
fill ~105 ~65 ~442 ~106 ~65 ~442 minecraft:redstone_wire replace
setblock ~107 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~65 ~442 ~121 ~65 ~442 minecraft:redstone_wire replace
setblock ~123 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~65 ~442 ~138 ~65 ~442 minecraft:redstone_wire replace
setblock ~140 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~65 ~442 ~155 ~65 ~442 minecraft:redstone_wire replace
setblock ~157 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~65 ~442 ~165 ~65 ~442 minecraft:redstone_wire replace
setblock ~97 ~65 ~465 minecraft:redstone_wire replace
fill ~96 ~65 ~466 ~101 ~65 ~466 minecraft:redstone_wire replace
setblock ~103 ~65 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~65 ~466 ~111 ~65 ~466 minecraft:redstone_wire replace
setblock ~100 ~65 ~469 minecraft:redstone_wire replace
fill ~99 ~65 ~470 ~105 ~65 ~470 minecraft:redstone_wire replace
setblock ~107 ~65 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~65 ~470 ~122 ~65 ~470 minecraft:redstone_wire replace
setblock ~124 ~65 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~65 ~470 ~132 ~65 ~470 minecraft:redstone_wire replace
setblock ~103 ~65 ~473 minecraft:redstone_wire replace
fill ~102 ~65 ~474 ~109 ~65 ~474 minecraft:redstone_wire replace
setblock ~111 ~65 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~65 ~474 ~126 ~65 ~474 minecraft:redstone_wire replace
setblock ~128 ~65 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~65 ~474 ~143 ~65 ~474 minecraft:redstone_wire replace
setblock ~145 ~65 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~65 ~474 ~153 ~65 ~474 minecraft:redstone_wire replace
setblock ~106 ~65 ~477 minecraft:redstone_wire replace
fill ~105 ~65 ~478 ~116 ~65 ~478 minecraft:redstone_wire replace
setblock ~118 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~65 ~478 ~133 ~65 ~478 minecraft:redstone_wire replace
setblock ~135 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~65 ~478 ~150 ~65 ~478 minecraft:redstone_wire replace
setblock ~152 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~65 ~478 ~167 ~65 ~478 minecraft:redstone_wire replace
setblock ~169 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~65 ~478 ~177 ~65 ~478 minecraft:redstone_wire replace
setblock ~130 ~65 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~65 ~482 ~143 ~65 ~482 minecraft:redstone_wire replace
setblock ~145 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~65 ~482 ~160 ~65 ~482 minecraft:redstone_wire replace
setblock ~162 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~65 ~482 ~177 ~65 ~482 minecraft:redstone_wire replace
setblock ~179 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~65 ~482 ~194 ~65 ~482 minecraft:redstone_wire replace
setblock ~196 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~65 ~482 ~204 ~65 ~482 minecraft:redstone_wire replace
setblock ~97 ~65 ~505 minecraft:redstone_wire replace
fill ~96 ~65 ~506 ~98 ~65 ~506 minecraft:redstone_wire replace
setblock ~100 ~65 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~65 ~506 ~108 ~65 ~506 minecraft:redstone_wire replace
setblock ~100 ~65 ~509 minecraft:redstone_wire replace
fill ~99 ~65 ~510 ~102 ~65 ~510 minecraft:redstone_wire replace
setblock ~104 ~65 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~65 ~510 ~119 ~65 ~510 minecraft:redstone_wire replace
setblock ~121 ~65 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~510 ~129 ~65 ~510 minecraft:redstone_wire replace
setblock ~103 ~65 ~513 minecraft:redstone_wire replace
fill ~102 ~65 ~514 ~106 ~65 ~514 minecraft:redstone_wire replace
setblock ~108 ~65 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~65 ~514 ~123 ~65 ~514 minecraft:redstone_wire replace
setblock ~125 ~65 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~65 ~514 ~140 ~65 ~514 minecraft:redstone_wire replace
setblock ~142 ~65 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~65 ~514 ~150 ~65 ~514 minecraft:redstone_wire replace
setblock ~106 ~65 ~517 minecraft:redstone_wire replace
fill ~105 ~65 ~518 ~113 ~65 ~518 minecraft:redstone_wire replace
setblock ~115 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~65 ~518 ~130 ~65 ~518 minecraft:redstone_wire replace
setblock ~132 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~65 ~518 ~147 ~65 ~518 minecraft:redstone_wire replace
setblock ~149 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~65 ~518 ~164 ~65 ~518 minecraft:redstone_wire replace
setblock ~166 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~65 ~518 ~174 ~65 ~518 minecraft:redstone_wire replace
setblock ~127 ~65 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~65 ~522 ~140 ~65 ~522 minecraft:redstone_wire replace
setblock ~142 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~65 ~522 ~157 ~65 ~522 minecraft:redstone_wire replace
setblock ~159 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~65 ~522 ~174 ~65 ~522 minecraft:redstone_wire replace
setblock ~176 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~65 ~522 ~191 ~65 ~522 minecraft:redstone_wire replace
setblock ~193 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~65 ~522 ~201 ~65 ~522 minecraft:redstone_wire replace
setblock ~97 ~65 ~545 minecraft:redstone_wire replace
fill ~96 ~65 ~546 ~97 ~65 ~546 minecraft:redstone_wire replace
setblock ~98 ~65 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~65 ~546 ~105 ~65 ~546 minecraft:redstone_wire replace
setblock ~100 ~65 ~549 minecraft:redstone_wire replace
fill ~99 ~65 ~550 ~101 ~65 ~550 minecraft:redstone_wire replace
setblock ~102 ~65 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~65 ~550 ~116 ~65 ~550 minecraft:redstone_wire replace
setblock ~118 ~65 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~65 ~550 ~126 ~65 ~550 minecraft:redstone_wire replace
setblock ~103 ~65 ~553 minecraft:redstone_wire replace
fill ~102 ~65 ~554 ~103 ~65 ~554 minecraft:redstone_wire replace
setblock ~105 ~65 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~65 ~554 ~119 ~65 ~554 minecraft:redstone_wire replace
setblock ~121 ~65 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~554 ~135 ~65 ~554 minecraft:redstone_wire replace
setblock ~137 ~65 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~65 ~554 ~144 ~65 ~554 minecraft:redstone_wire replace
setblock ~106 ~65 ~557 minecraft:redstone_wire replace
fill ~105 ~65 ~558 ~110 ~65 ~558 minecraft:redstone_wire replace
setblock ~112 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~65 ~558 ~127 ~65 ~558 minecraft:redstone_wire replace
setblock ~129 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~65 ~558 ~144 ~65 ~558 minecraft:redstone_wire replace
setblock ~146 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~65 ~558 ~161 ~65 ~558 minecraft:redstone_wire replace
setblock ~163 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~65 ~558 ~171 ~65 ~558 minecraft:redstone_wire replace
setblock ~121 ~65 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~65 ~562 ~134 ~65 ~562 minecraft:redstone_wire replace
setblock ~136 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~65 ~562 ~151 ~65 ~562 minecraft:redstone_wire replace
setblock ~153 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~65 ~562 ~168 ~65 ~562 minecraft:redstone_wire replace
setblock ~170 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~65 ~562 ~185 ~65 ~562 minecraft:redstone_wire replace
setblock ~187 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~65 ~562 ~195 ~65 ~562 minecraft:redstone_wire replace
setblock ~97 ~65 ~585 minecraft:redstone_wire replace
fill ~96 ~65 ~586 ~99 ~65 ~586 minecraft:redstone_wire replace
setblock ~100 ~65 ~589 minecraft:redstone_wire replace
setblock ~99 ~65 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~65 ~590 ~113 ~65 ~590 minecraft:redstone_wire replace
setblock ~115 ~65 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~65 ~590 ~123 ~65 ~590 minecraft:redstone_wire replace
setblock ~103 ~65 ~593 minecraft:redstone_wire replace
fill ~102 ~65 ~594 ~114 ~65 ~594 minecraft:redstone_wire replace
setblock ~116 ~65 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~65 ~594 ~131 ~65 ~594 minecraft:redstone_wire replace
setblock ~133 ~65 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~65 ~594 ~141 ~65 ~594 minecraft:redstone_wire replace
setblock ~106 ~65 ~597 minecraft:redstone_wire replace
fill ~105 ~65 ~598 ~107 ~65 ~598 minecraft:redstone_wire replace
setblock ~109 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~65 ~598 ~124 ~65 ~598 minecraft:redstone_wire replace
setblock ~126 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~65 ~598 ~141 ~65 ~598 minecraft:redstone_wire replace
setblock ~143 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~65 ~598 ~158 ~65 ~598 minecraft:redstone_wire replace
setblock ~160 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~65 ~598 ~168 ~65 ~598 minecraft:redstone_wire replace
setblock ~118 ~65 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~65 ~602 ~131 ~65 ~602 minecraft:redstone_wire replace
setblock ~133 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~65 ~602 ~148 ~65 ~602 minecraft:redstone_wire replace
setblock ~150 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~65 ~602 ~165 ~65 ~602 minecraft:redstone_wire replace
setblock ~167 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~65 ~602 ~182 ~65 ~602 minecraft:redstone_wire replace
setblock ~184 ~65 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~65 ~602 ~192 ~65 ~602 minecraft:redstone_wire replace
setblock ~85 ~65 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~65 ~606 ~86 ~65 ~606 minecraft:redstone_wire replace
setblock ~88 ~65 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~65 ~610 ~89 ~65 ~610 minecraft:redstone_wire replace
setblock ~91 ~65 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~65 ~614 ~92 ~65 ~614 minecraft:redstone_wire replace
setblock ~94 ~65 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~65 ~618 ~95 ~65 ~618 minecraft:redstone_wire replace
setblock ~97 ~65 ~621 minecraft:redstone_wire replace
fill ~96 ~65 ~622 ~98 ~65 ~622 minecraft:redstone_wire replace
setblock ~100 ~65 ~625 minecraft:redstone_wire replace
fill ~99 ~65 ~626 ~107 ~65 ~626 minecraft:redstone_wire replace
setblock ~109 ~65 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~65 ~626 ~117 ~65 ~626 minecraft:redstone_wire replace
setblock ~103 ~65 ~629 minecraft:redstone_wire replace
fill ~102 ~65 ~630 ~103 ~65 ~630 minecraft:redstone_wire replace
setblock ~105 ~65 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~65 ~630 ~120 ~65 ~630 minecraft:redstone_wire replace
setblock ~122 ~65 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~65 ~630 ~137 ~65 ~630 minecraft:redstone_wire replace
setblock ~139 ~65 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~65 ~630 ~147 ~65 ~630 minecraft:redstone_wire replace
setblock ~106 ~65 ~633 minecraft:redstone_wire replace
fill ~105 ~65 ~634 ~115 ~65 ~634 minecraft:redstone_wire replace
setblock ~117 ~65 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~65 ~634 ~132 ~65 ~634 minecraft:redstone_wire replace
setblock ~134 ~65 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~65 ~634 ~149 ~65 ~634 minecraft:redstone_wire replace
setblock ~151 ~65 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~65 ~634 ~159 ~65 ~634 minecraft:redstone_wire replace
setblock ~109 ~65 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~65 ~638 ~119 ~65 ~638 minecraft:redstone_wire replace
setblock ~121 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~638 ~136 ~65 ~638 minecraft:redstone_wire replace
setblock ~138 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~65 ~638 ~153 ~65 ~638 minecraft:redstone_wire replace
setblock ~155 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~65 ~638 ~170 ~65 ~638 minecraft:redstone_wire replace
setblock ~172 ~65 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~65 ~638 ~180 ~65 ~638 minecraft:redstone_wire replace
setblock ~124 ~65 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~65 ~642 ~137 ~65 ~642 minecraft:redstone_wire replace
setblock ~139 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~65 ~642 ~154 ~65 ~642 minecraft:redstone_wire replace
setblock ~156 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~65 ~642 ~171 ~65 ~642 minecraft:redstone_wire replace
setblock ~173 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~65 ~642 ~188 ~65 ~642 minecraft:redstone_wire replace
setblock ~190 ~65 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~65 ~642 ~198 ~65 ~642 minecraft:redstone_wire replace
setblock ~139 ~65 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~65 ~646 ~140 ~65 ~646 minecraft:redstone_wire replace
setblock ~141 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~65 ~646 ~155 ~65 ~646 minecraft:redstone_wire replace
setblock ~157 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~65 ~646 ~172 ~65 ~646 minecraft:redstone_wire replace
setblock ~174 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~65 ~646 ~189 ~65 ~646 minecraft:redstone_wire replace
setblock ~191 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~65 ~646 ~206 ~65 ~646 minecraft:redstone_wire replace
setblock ~208 ~65 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~65 ~646 ~216 ~65 ~646 minecraft:redstone_wire replace
setblock ~79 ~65 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~65 ~650 ~80 ~65 ~650 minecraft:redstone_wire replace
setblock ~112 ~65 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~65 ~654 ~122 ~65 ~654 minecraft:redstone_wire replace
setblock ~124 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~65 ~654 ~139 ~65 ~654 minecraft:redstone_wire replace
setblock ~141 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~65 ~654 ~156 ~65 ~654 minecraft:redstone_wire replace
setblock ~158 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~65 ~654 ~173 ~65 ~654 minecraft:redstone_wire replace
setblock ~175 ~65 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~65 ~654 ~183 ~65 ~654 minecraft:redstone_wire replace
setblock ~136 ~65 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~65 ~658 ~137 ~65 ~658 minecraft:redstone_wire replace
setblock ~138 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~65 ~658 ~152 ~65 ~658 minecraft:redstone_wire replace
setblock ~154 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~65 ~658 ~169 ~65 ~658 minecraft:redstone_wire replace
setblock ~171 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~65 ~658 ~186 ~65 ~658 minecraft:redstone_wire replace
setblock ~188 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~65 ~658 ~203 ~65 ~658 minecraft:redstone_wire replace
setblock ~205 ~65 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~65 ~658 ~213 ~65 ~658 minecraft:redstone_wire replace
setblock ~97 ~66 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~66 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~66 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~66 ~384 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~66 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~66 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~66 ~428 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~432 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~440 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~66 ~464 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~468 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~66 ~480 minecraft:redstone_wire replace
setblock ~97 ~66 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~512 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~66 ~520 minecraft:redstone_wire replace
setblock ~97 ~66 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~66 ~560 minecraft:redstone_wire replace
setblock ~97 ~66 ~584 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~66 ~600 minecraft:redstone_wire replace
setblock ~85 ~66 ~604 minecraft:redstone_wire replace
setblock ~88 ~66 ~608 minecraft:redstone_wire replace
setblock ~91 ~66 ~612 minecraft:redstone_wire replace
setblock ~94 ~66 ~616 minecraft:redstone_wire replace
setblock ~97 ~66 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~66 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~66 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~66 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~66 ~636 minecraft:redstone_wire replace
setblock ~124 ~66 ~640 minecraft:redstone_wire replace
setblock ~139 ~66 ~644 minecraft:redstone_wire replace
setblock ~79 ~66 ~648 minecraft:redstone_wire replace
setblock ~112 ~66 ~652 minecraft:redstone_wire replace
setblock ~136 ~66 ~656 minecraft:redstone_wire replace
fill ~96 ~67 ~324 ~96 ~67 ~336 minecraft:redstone_wire replace
setblock ~96 ~67 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~340 ~96 ~67 ~352 minecraft:redstone_wire replace
fill ~99 ~67 ~340 ~99 ~67 ~352 minecraft:redstone_wire replace
setblock ~96 ~67 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~356 ~96 ~67 ~368 minecraft:redstone_wire replace
fill ~99 ~67 ~356 ~99 ~67 ~368 minecraft:redstone_wire replace
fill ~105 ~67 ~356 ~105 ~67 ~368 minecraft:redstone_wire replace
setblock ~96 ~67 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~372 ~96 ~67 ~384 minecraft:redstone_wire replace
fill ~99 ~67 ~372 ~99 ~67 ~384 minecraft:redstone_wire replace
fill ~102 ~67 ~372 ~102 ~67 ~384 minecraft:redstone_wire replace
fill ~105 ~67 ~372 ~105 ~67 ~384 minecraft:redstone_wire replace
fill ~132 ~67 ~376 ~132 ~67 ~382 minecraft:redstone_wire replace
fill ~114 ~67 ~384 ~114 ~67 ~390 minecraft:redstone_wire replace
setblock ~132 ~67 ~384 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~388 ~96 ~67 ~400 minecraft:redstone_wire replace
fill ~99 ~67 ~388 ~99 ~67 ~400 minecraft:redstone_wire replace
fill ~102 ~67 ~388 ~102 ~67 ~400 minecraft:redstone_wire replace
fill ~105 ~67 ~388 ~105 ~67 ~400 minecraft:redstone_wire replace
fill ~81 ~67 ~392 ~81 ~67 ~396 minecraft:redstone_wire replace
setblock ~114 ~67 ~392 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~404 ~96 ~67 ~416 minecraft:redstone_wire replace
fill ~99 ~67 ~404 ~99 ~67 ~416 minecraft:redstone_wire replace
fill ~102 ~67 ~404 ~102 ~67 ~416 minecraft:redstone_wire replace
fill ~105 ~67 ~404 ~105 ~67 ~416 minecraft:redstone_wire replace
setblock ~96 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~420 ~96 ~67 ~432 minecraft:redstone_wire replace
fill ~99 ~67 ~420 ~99 ~67 ~432 minecraft:redstone_wire replace
fill ~102 ~67 ~420 ~102 ~67 ~432 minecraft:redstone_wire replace
fill ~105 ~67 ~420 ~105 ~67 ~432 minecraft:redstone_wire replace
setblock ~99 ~67 ~433 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~434 ~99 ~67 ~446 minecraft:redstone_wire replace
setblock ~102 ~67 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~436 ~96 ~67 ~448 minecraft:redstone_wire replace
fill ~102 ~67 ~436 ~102 ~67 ~448 minecraft:redstone_wire replace
fill ~105 ~67 ~436 ~105 ~67 ~448 minecraft:redstone_wire replace
setblock ~99 ~67 ~448 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~450 ~99 ~67 ~462 minecraft:redstone_wire replace
setblock ~102 ~67 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~452 ~96 ~67 ~464 minecraft:redstone_wire replace
fill ~102 ~67 ~452 ~102 ~67 ~464 minecraft:redstone_wire replace
fill ~105 ~67 ~452 ~105 ~67 ~464 minecraft:redstone_wire replace
setblock ~99 ~67 ~464 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~67 ~465 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~466 ~96 ~67 ~478 minecraft:redstone_wire replace
fill ~99 ~67 ~466 ~99 ~67 ~478 minecraft:redstone_wire replace
setblock ~102 ~67 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~468 ~102 ~67 ~480 minecraft:redstone_wire replace
fill ~105 ~67 ~468 ~105 ~67 ~480 minecraft:redstone_wire replace
setblock ~96 ~67 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~480 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~67 ~480 ~129 ~67 ~484 minecraft:redstone_wire replace
fill ~96 ~67 ~482 ~96 ~67 ~494 minecraft:redstone_wire replace
fill ~99 ~67 ~482 ~99 ~67 ~494 minecraft:redstone_wire replace
setblock ~102 ~67 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~484 ~102 ~67 ~496 minecraft:redstone_wire replace
fill ~105 ~67 ~484 ~105 ~67 ~496 minecraft:redstone_wire replace
setblock ~96 ~67 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~498 ~96 ~67 ~510 minecraft:redstone_wire replace
fill ~99 ~67 ~498 ~99 ~67 ~510 minecraft:redstone_wire replace
setblock ~102 ~67 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~500 ~102 ~67 ~512 minecraft:redstone_wire replace
fill ~105 ~67 ~500 ~105 ~67 ~512 minecraft:redstone_wire replace
setblock ~96 ~67 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~513 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~514 ~96 ~67 ~526 minecraft:redstone_wire replace
fill ~99 ~67 ~514 ~99 ~67 ~526 minecraft:redstone_wire replace
fill ~102 ~67 ~514 ~102 ~67 ~526 minecraft:redstone_wire replace
setblock ~105 ~67 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~516 ~105 ~67 ~528 minecraft:redstone_wire replace
fill ~126 ~67 ~520 ~126 ~67 ~524 minecraft:redstone_wire replace
setblock ~96 ~67 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~530 ~96 ~67 ~542 minecraft:redstone_wire replace
fill ~99 ~67 ~530 ~99 ~67 ~542 minecraft:redstone_wire replace
fill ~102 ~67 ~530 ~102 ~67 ~542 minecraft:redstone_wire replace
setblock ~105 ~67 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~532 ~105 ~67 ~544 minecraft:redstone_wire replace
setblock ~96 ~67 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~544 ~96 ~67 ~556 minecraft:redstone_wire replace
setblock ~99 ~67 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~546 ~99 ~67 ~558 minecraft:redstone_wire replace
fill ~102 ~67 ~546 ~102 ~67 ~558 minecraft:redstone_wire replace
setblock ~105 ~67 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~548 ~105 ~67 ~560 minecraft:redstone_wire replace
setblock ~96 ~67 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~560 ~96 ~67 ~572 minecraft:redstone_wire replace
setblock ~99 ~67 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~67 ~560 ~120 ~67 ~564 minecraft:redstone_wire replace
fill ~99 ~67 ~562 ~99 ~67 ~574 minecraft:redstone_wire replace
fill ~102 ~67 ~562 ~102 ~67 ~574 minecraft:redstone_wire replace
setblock ~105 ~67 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~564 ~105 ~67 ~576 minecraft:redstone_wire replace
setblock ~96 ~67 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~576 ~96 ~67 ~588 minecraft:redstone_wire replace
setblock ~99 ~67 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~578 ~99 ~67 ~590 minecraft:redstone_wire replace
fill ~102 ~67 ~578 ~102 ~67 ~590 minecraft:redstone_wire replace
setblock ~105 ~67 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~580 ~105 ~67 ~592 minecraft:redstone_wire replace
setblock ~96 ~67 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~592 ~96 ~67 ~604 minecraft:redstone_wire replace
setblock ~99 ~67 ~592 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~592 ~102 ~67 ~604 minecraft:redstone_wire replace
fill ~99 ~67 ~594 ~99 ~67 ~606 minecraft:redstone_wire replace
setblock ~105 ~67 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~596 ~105 ~67 ~608 minecraft:redstone_wire replace
fill ~117 ~67 ~600 ~117 ~67 ~604 minecraft:redstone_wire replace
fill ~84 ~67 ~604 ~84 ~67 ~608 minecraft:redstone_wire replace
setblock ~96 ~67 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~67 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~67 ~608 ~87 ~67 ~612 minecraft:redstone_wire replace
fill ~96 ~67 ~608 ~96 ~67 ~620 minecraft:redstone_wire replace
setblock ~99 ~67 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~67 ~608 ~102 ~67 ~620 minecraft:redstone_wire replace
fill ~99 ~67 ~610 ~99 ~67 ~622 minecraft:redstone_wire replace
setblock ~105 ~67 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~67 ~612 ~90 ~67 ~616 minecraft:redstone_wire replace
fill ~105 ~67 ~612 ~105 ~67 ~624 minecraft:redstone_wire replace
fill ~93 ~67 ~616 ~93 ~67 ~620 minecraft:redstone_wire replace
setblock ~96 ~67 ~621 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~67 ~622 ~96 ~67 ~624 minecraft:redstone_wire replace
setblock ~102 ~67 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~67 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~67 ~624 ~99 ~67 ~628 minecraft:redstone_wire replace
fill ~102 ~67 ~624 ~102 ~67 ~630 minecraft:redstone_wire replace
setblock ~105 ~67 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~67 ~628 ~105 ~67 ~634 minecraft:redstone_wire replace
setblock ~102 ~67 ~632 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~67 ~636 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~67 ~636 ~108 ~67 ~640 minecraft:redstone_wire replace
fill ~123 ~67 ~640 ~123 ~67 ~644 minecraft:redstone_wire replace
fill ~138 ~67 ~644 ~138 ~67 ~648 minecraft:redstone_wire replace
fill ~78 ~67 ~648 ~78 ~67 ~652 minecraft:redstone_wire replace
fill ~111 ~67 ~652 ~111 ~67 ~656 minecraft:redstone_wire replace
fill ~135 ~67 ~656 ~135 ~67 ~660 minecraft:redstone_wire replace
setblock ~132 ~68 ~385 minecraft:redstone_wire replace
setblock ~114 ~68 ~393 minecraft:redstone_wire replace
setblock ~81 ~68 ~397 minecraft:redstone_wire replace
setblock ~129 ~68 ~485 minecraft:redstone_wire replace
setblock ~126 ~68 ~525 minecraft:redstone_wire replace
setblock ~120 ~68 ~565 minecraft:redstone_wire replace
setblock ~117 ~68 ~605 minecraft:redstone_wire replace
setblock ~84 ~68 ~609 minecraft:redstone_wire replace
setblock ~87 ~68 ~613 minecraft:redstone_wire replace
setblock ~90 ~68 ~617 minecraft:redstone_wire replace
setblock ~93 ~68 ~621 minecraft:redstone_wire replace
setblock ~96 ~68 ~625 minecraft:redstone_wire replace
setblock ~99 ~68 ~629 minecraft:redstone_wire replace
setblock ~102 ~68 ~633 minecraft:redstone_wire replace
setblock ~105 ~68 ~637 minecraft:redstone_wire replace
setblock ~108 ~68 ~641 minecraft:redstone_wire replace
setblock ~123 ~68 ~645 minecraft:redstone_wire replace
setblock ~138 ~68 ~649 minecraft:redstone_wire replace
setblock ~78 ~68 ~653 minecraft:redstone_wire replace
setblock ~111 ~68 ~657 minecraft:redstone_wire replace
setblock ~135 ~68 ~661 minecraft:redstone_wire replace
fill ~132 ~69 ~386 ~134 ~69 ~386 minecraft:redstone_wire replace
setblock ~133 ~69 ~387 minecraft:redstone_wire replace
fill ~114 ~69 ~394 ~116 ~69 ~394 minecraft:redstone_wire replace
setblock ~115 ~69 ~395 minecraft:redstone_wire replace
fill ~81 ~69 ~398 ~86 ~69 ~398 minecraft:redstone_wire replace
setblock ~85 ~69 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~69 ~486 ~129 ~69 ~486 minecraft:redstone_wire replace
setblock ~127 ~69 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~69 ~526 ~126 ~69 ~526 minecraft:redstone_wire replace
setblock ~124 ~69 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~69 ~566 ~122 ~69 ~566 minecraft:redstone_wire replace
setblock ~121 ~69 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~69 ~606 ~119 ~69 ~606 minecraft:redstone_wire replace
setblock ~118 ~69 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~69 ~610 ~89 ~69 ~610 minecraft:redstone_wire replace
setblock ~88 ~69 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~69 ~614 ~92 ~69 ~614 minecraft:redstone_wire replace
setblock ~91 ~69 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~69 ~618 ~95 ~69 ~618 minecraft:redstone_wire replace
setblock ~94 ~69 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~69 ~622 ~98 ~69 ~622 minecraft:redstone_wire replace
setblock ~97 ~69 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~69 ~626 ~101 ~69 ~626 minecraft:redstone_wire replace
setblock ~100 ~69 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~69 ~630 ~104 ~69 ~630 minecraft:redstone_wire replace
setblock ~103 ~69 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~69 ~634 ~86 ~69 ~634 minecraft:redstone_wire replace
setblock ~88 ~69 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~69 ~634 ~114 ~69 ~634 minecraft:redstone_wire replace
setblock ~116 ~69 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~69 ~634 ~131 ~69 ~634 minecraft:redstone_wire replace
setblock ~79 ~69 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~69 ~635 minecraft:redstone_wire replace
fill ~105 ~69 ~638 ~107 ~69 ~638 minecraft:redstone_wire replace
setblock ~106 ~69 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~69 ~642 ~110 ~69 ~642 minecraft:redstone_wire replace
setblock ~109 ~69 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~69 ~646 ~115 ~69 ~646 minecraft:redstone_wire replace
setblock ~116 ~69 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~69 ~646 ~129 ~69 ~646 minecraft:redstone_wire replace
setblock ~131 ~69 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~69 ~646 ~134 ~69 ~646 minecraft:redstone_wire replace
setblock ~115 ~69 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~69 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~69 ~650 ~140 ~69 ~650 minecraft:redstone_wire replace
setblock ~139 ~69 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~69 ~654 ~83 ~69 ~654 minecraft:redstone_wire replace
setblock ~82 ~69 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~69 ~658 ~113 ~69 ~658 minecraft:redstone_wire replace
setblock ~112 ~69 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~69 ~662 ~137 ~69 ~662 minecraft:redstone_wire replace
setblock ~136 ~69 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~70 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~70 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~70 ~400 minecraft:redstone_wire replace
setblock ~127 ~70 ~488 minecraft:redstone_wire replace
setblock ~124 ~70 ~528 minecraft:redstone_wire replace
setblock ~121 ~70 ~568 minecraft:redstone_wire replace
setblock ~118 ~70 ~608 minecraft:redstone_wire replace
setblock ~88 ~70 ~612 minecraft:redstone_wire replace
setblock ~91 ~70 ~616 minecraft:redstone_wire replace
setblock ~94 ~70 ~620 minecraft:redstone_wire replace
setblock ~97 ~70 ~624 minecraft:redstone_wire replace
setblock ~100 ~70 ~628 minecraft:redstone_wire replace
setblock ~103 ~70 ~632 minecraft:redstone_wire replace
setblock ~79 ~70 ~636 minecraft:redstone_wire replace
setblock ~130 ~70 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~70 ~640 minecraft:redstone_wire replace
setblock ~109 ~70 ~644 minecraft:redstone_wire replace
setblock ~115 ~70 ~648 minecraft:redstone_wire replace
setblock ~133 ~70 ~648 minecraft:redstone_wire replace
setblock ~139 ~70 ~652 minecraft:redstone_wire replace
setblock ~82 ~70 ~656 minecraft:redstone_wire replace
setblock ~112 ~70 ~660 minecraft:redstone_wire replace
setblock ~136 ~70 ~664 minecraft:redstone_wire replace
setblock ~132 ~71 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~71 ~386 ~132 ~71 ~392 minecraft:redstone_wire replace
fill ~114 ~71 ~392 ~114 ~71 ~394 minecraft:redstone_wire replace
setblock ~132 ~71 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~71 ~395 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~71 ~396 ~84 ~71 ~400 minecraft:redstone_wire replace
fill ~114 ~71 ~396 ~114 ~71 ~408 minecraft:redstone_wire replace
fill ~132 ~71 ~396 ~132 ~71 ~408 minecraft:redstone_wire replace
setblock ~114 ~71 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~412 ~114 ~71 ~424 minecraft:redstone_wire replace
fill ~132 ~71 ~412 ~132 ~71 ~424 minecraft:redstone_wire replace
setblock ~114 ~71 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~428 ~114 ~71 ~440 minecraft:redstone_wire replace
fill ~132 ~71 ~428 ~132 ~71 ~440 minecraft:redstone_wire replace
setblock ~114 ~71 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~444 ~114 ~71 ~456 minecraft:redstone_wire replace
fill ~132 ~71 ~444 ~132 ~71 ~456 minecraft:redstone_wire replace
setblock ~114 ~71 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~460 ~114 ~71 ~472 minecraft:redstone_wire replace
fill ~132 ~71 ~460 ~132 ~71 ~472 minecraft:redstone_wire replace
setblock ~114 ~71 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~476 ~114 ~71 ~488 minecraft:redstone_wire replace
fill ~132 ~71 ~476 ~132 ~71 ~488 minecraft:redstone_wire replace
fill ~126 ~71 ~484 ~126 ~71 ~488 minecraft:redstone_wire replace
setblock ~114 ~71 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~492 ~114 ~71 ~504 minecraft:redstone_wire replace
fill ~132 ~71 ~492 ~132 ~71 ~504 minecraft:redstone_wire replace
setblock ~114 ~71 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~508 ~114 ~71 ~520 minecraft:redstone_wire replace
fill ~132 ~71 ~508 ~132 ~71 ~520 minecraft:redstone_wire replace
setblock ~114 ~71 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~524 ~114 ~71 ~536 minecraft:redstone_wire replace
fill ~123 ~71 ~524 ~123 ~71 ~528 minecraft:redstone_wire replace
fill ~132 ~71 ~524 ~132 ~71 ~536 minecraft:redstone_wire replace
setblock ~114 ~71 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~540 ~114 ~71 ~552 minecraft:redstone_wire replace
fill ~132 ~71 ~540 ~132 ~71 ~552 minecraft:redstone_wire replace
setblock ~114 ~71 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~556 ~114 ~71 ~568 minecraft:redstone_wire replace
fill ~132 ~71 ~556 ~132 ~71 ~568 minecraft:redstone_wire replace
fill ~120 ~71 ~564 ~120 ~71 ~568 minecraft:redstone_wire replace
setblock ~114 ~71 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~572 ~114 ~71 ~584 minecraft:redstone_wire replace
fill ~132 ~71 ~572 ~132 ~71 ~584 minecraft:redstone_wire replace
setblock ~114 ~71 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~588 ~114 ~71 ~600 minecraft:redstone_wire replace
fill ~132 ~71 ~588 ~132 ~71 ~600 minecraft:redstone_wire replace
setblock ~117 ~71 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~71 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~71 ~602 ~117 ~71 ~608 minecraft:redstone_wire replace
setblock ~132 ~71 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~71 ~604 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~604 ~114 ~71 ~616 minecraft:redstone_wire replace
fill ~132 ~71 ~604 ~132 ~71 ~616 minecraft:redstone_wire replace
fill ~87 ~71 ~606 ~87 ~71 ~612 minecraft:redstone_wire replace
setblock ~90 ~71 ~608 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~71 ~610 ~90 ~71 ~616 minecraft:redstone_wire replace
setblock ~93 ~71 ~612 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~71 ~614 ~93 ~71 ~620 minecraft:redstone_wire replace
setblock ~96 ~71 ~616 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~71 ~618 ~96 ~71 ~624 minecraft:redstone_wire replace
setblock ~114 ~71 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~71 ~620 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~71 ~620 ~114 ~71 ~632 minecraft:redstone_wire replace
fill ~132 ~71 ~620 ~132 ~71 ~632 minecraft:redstone_wire replace
fill ~99 ~71 ~622 ~99 ~71 ~628 minecraft:redstone_wire replace
setblock ~102 ~71 ~624 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~71 ~626 ~102 ~71 ~632 minecraft:redstone_wire replace
setblock ~129 ~71 ~628 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~71 ~630 ~129 ~71 ~636 minecraft:redstone_wire replace
fill ~78 ~71 ~632 ~78 ~71 ~636 minecraft:redstone_wire replace
setblock ~114 ~71 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~71 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~71 ~636 ~105 ~71 ~640 minecraft:redstone_wire replace
fill ~114 ~71 ~636 ~114 ~71 ~648 minecraft:redstone_wire replace
fill ~132 ~71 ~636 ~132 ~71 ~648 minecraft:redstone_wire replace
fill ~108 ~71 ~640 ~108 ~71 ~644 minecraft:redstone_wire replace
fill ~138 ~71 ~648 ~138 ~71 ~652 minecraft:redstone_wire replace
fill ~81 ~71 ~652 ~81 ~71 ~656 minecraft:redstone_wire replace
fill ~111 ~71 ~656 ~111 ~71 ~660 minecraft:redstone_wire replace
fill ~135 ~71 ~660 ~135 ~71 ~664 minecraft:redstone_wire replace
setblock ~132 ~72 ~383 minecraft:redstone_wire replace
setblock ~114 ~72 ~391 minecraft:redstone_wire replace
setblock ~84 ~72 ~395 minecraft:redstone_wire replace
setblock ~126 ~72 ~483 minecraft:redstone_wire replace
setblock ~123 ~72 ~523 minecraft:redstone_wire replace
setblock ~120 ~72 ~563 minecraft:redstone_wire replace
setblock ~117 ~72 ~599 minecraft:redstone_wire replace
setblock ~87 ~72 ~603 minecraft:redstone_wire replace
setblock ~90 ~72 ~607 minecraft:redstone_wire replace
setblock ~93 ~72 ~611 minecraft:redstone_wire replace
setblock ~96 ~72 ~615 minecraft:redstone_wire replace
setblock ~99 ~72 ~619 minecraft:redstone_wire replace
setblock ~102 ~72 ~623 minecraft:redstone_wire replace
setblock ~129 ~72 ~627 minecraft:redstone_wire replace
setblock ~78 ~72 ~631 minecraft:redstone_wire replace
setblock ~105 ~72 ~635 minecraft:redstone_wire replace
setblock ~108 ~72 ~639 minecraft:redstone_wire replace
setblock ~138 ~72 ~647 minecraft:redstone_wire replace
setblock ~81 ~72 ~651 minecraft:redstone_wire replace
setblock ~111 ~72 ~655 minecraft:redstone_wire replace
setblock ~135 ~72 ~659 minecraft:redstone_wire replace
setblock ~115 ~73 ~381 minecraft:redstone_wire replace
fill ~114 ~73 ~382 ~116 ~73 ~382 minecraft:redstone_wire replace
setblock ~118 ~73 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~73 ~382 ~132 ~73 ~382 minecraft:redstone_wire replace
setblock ~109 ~73 ~389 minecraft:redstone_wire replace
fill ~108 ~73 ~390 ~114 ~73 ~390 minecraft:redstone_wire replace
setblock ~85 ~73 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~73 ~394 ~86 ~73 ~394 minecraft:redstone_wire replace
setblock ~109 ~73 ~481 minecraft:redstone_wire replace
fill ~108 ~73 ~482 ~116 ~73 ~482 minecraft:redstone_wire replace
setblock ~118 ~73 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~73 ~482 ~126 ~73 ~482 minecraft:redstone_wire replace
setblock ~109 ~73 ~521 minecraft:redstone_wire replace
fill ~108 ~73 ~522 ~113 ~73 ~522 minecraft:redstone_wire replace
setblock ~115 ~73 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~73 ~522 ~123 ~73 ~522 minecraft:redstone_wire replace
setblock ~109 ~73 ~561 minecraft:redstone_wire replace
fill ~108 ~73 ~562 ~110 ~73 ~562 minecraft:redstone_wire replace
setblock ~112 ~73 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~73 ~562 ~120 ~73 ~562 minecraft:redstone_wire replace
setblock ~109 ~73 ~597 minecraft:redstone_wire replace
fill ~108 ~73 ~598 ~117 ~73 ~598 minecraft:redstone_wire replace
setblock ~88 ~73 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~73 ~602 ~89 ~73 ~602 minecraft:redstone_wire replace
setblock ~91 ~73 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~73 ~606 ~92 ~73 ~606 minecraft:redstone_wire replace
setblock ~94 ~73 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~73 ~610 ~95 ~73 ~610 minecraft:redstone_wire replace
setblock ~97 ~73 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~73 ~614 ~98 ~73 ~614 minecraft:redstone_wire replace
setblock ~100 ~73 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~73 ~618 ~101 ~73 ~618 minecraft:redstone_wire replace
setblock ~103 ~73 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~73 ~622 ~104 ~73 ~622 minecraft:redstone_wire replace
setblock ~112 ~73 ~625 minecraft:redstone_wire replace
fill ~111 ~73 ~626 ~113 ~73 ~626 minecraft:redstone_wire replace
setblock ~115 ~73 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~73 ~626 ~129 ~73 ~626 minecraft:redstone_wire replace
setblock ~79 ~73 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~73 ~630 ~80 ~73 ~630 minecraft:redstone_wire replace
setblock ~106 ~73 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~73 ~634 ~107 ~73 ~634 minecraft:redstone_wire replace
setblock ~109 ~73 ~637 minecraft:redstone_wire replace
fill ~108 ~73 ~638 ~110 ~73 ~638 minecraft:redstone_wire replace
setblock ~121 ~73 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~73 ~646 ~128 ~73 ~646 minecraft:redstone_wire replace
setblock ~130 ~73 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~73 ~646 ~138 ~73 ~646 minecraft:redstone_wire replace
setblock ~82 ~73 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~73 ~650 ~83 ~73 ~650 minecraft:redstone_wire replace
setblock ~109 ~73 ~653 minecraft:redstone_wire replace
fill ~108 ~73 ~654 ~111 ~73 ~654 minecraft:redstone_wire replace
setblock ~118 ~73 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~73 ~658 ~125 ~73 ~658 minecraft:redstone_wire replace
setblock ~127 ~73 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~73 ~658 ~135 ~73 ~658 minecraft:redstone_wire replace
setblock ~115 ~74 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~74 ~392 minecraft:redstone_wire replace
setblock ~109 ~74 ~480 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~520 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~74 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~74 ~600 minecraft:redstone_wire replace
setblock ~91 ~74 ~604 minecraft:redstone_wire replace
setblock ~94 ~74 ~608 minecraft:redstone_wire replace
setblock ~97 ~74 ~612 minecraft:redstone_wire replace
setblock ~100 ~74 ~616 minecraft:redstone_wire replace
setblock ~103 ~74 ~620 minecraft:redstone_wire replace
setblock ~112 ~74 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~74 ~628 minecraft:redstone_wire replace
setblock ~106 ~74 ~632 minecraft:redstone_wire replace
setblock ~109 ~74 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~74 ~644 minecraft:redstone_wire replace
setblock ~82 ~74 ~648 minecraft:redstone_wire replace
setblock ~109 ~74 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~74 ~656 minecraft:redstone_wire replace
fill ~114 ~75 ~380 ~114 ~75 ~384 minecraft:redstone_wire replace
fill ~108 ~75 ~388 ~108 ~75 ~400 minecraft:redstone_wire replace
fill ~84 ~75 ~392 ~84 ~75 ~396 minecraft:redstone_wire replace
setblock ~108 ~75 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~404 ~108 ~75 ~416 minecraft:redstone_wire replace
setblock ~108 ~75 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~420 ~108 ~75 ~432 minecraft:redstone_wire replace
setblock ~108 ~75 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~436 ~108 ~75 ~448 minecraft:redstone_wire replace
setblock ~108 ~75 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~452 ~108 ~75 ~464 minecraft:redstone_wire replace
setblock ~108 ~75 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~468 ~108 ~75 ~480 minecraft:redstone_wire replace
setblock ~108 ~75 ~481 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~482 ~108 ~75 ~494 minecraft:redstone_wire replace
setblock ~108 ~75 ~496 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~498 ~108 ~75 ~510 minecraft:redstone_wire replace
setblock ~108 ~75 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~514 ~108 ~75 ~526 minecraft:redstone_wire replace
setblock ~108 ~75 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~530 ~108 ~75 ~542 minecraft:redstone_wire replace
setblock ~108 ~75 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~546 ~108 ~75 ~558 minecraft:redstone_wire replace
setblock ~108 ~75 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~560 ~108 ~75 ~572 minecraft:redstone_wire replace
setblock ~108 ~75 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~576 ~108 ~75 ~588 minecraft:redstone_wire replace
setblock ~108 ~75 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~592 ~108 ~75 ~604 minecraft:redstone_wire replace
fill ~87 ~75 ~600 ~87 ~75 ~604 minecraft:redstone_wire replace
fill ~90 ~75 ~604 ~90 ~75 ~608 minecraft:redstone_wire replace
setblock ~108 ~75 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~75 ~608 ~93 ~75 ~612 minecraft:redstone_wire replace
fill ~108 ~75 ~608 ~108 ~75 ~620 minecraft:redstone_wire replace
fill ~96 ~75 ~612 ~96 ~75 ~616 minecraft:redstone_wire replace
fill ~99 ~75 ~616 ~99 ~75 ~620 minecraft:redstone_wire replace
fill ~102 ~75 ~620 ~102 ~75 ~624 minecraft:redstone_wire replace
setblock ~108 ~75 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~624 ~108 ~75 ~636 minecraft:redstone_wire replace
fill ~111 ~75 ~624 ~111 ~75 ~628 minecraft:redstone_wire replace
fill ~78 ~75 ~628 ~78 ~75 ~632 minecraft:redstone_wire replace
fill ~105 ~75 ~632 ~105 ~75 ~636 minecraft:redstone_wire replace
setblock ~108 ~75 ~637 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~638 ~108 ~75 ~650 minecraft:redstone_wire replace
fill ~120 ~75 ~644 ~120 ~75 ~648 minecraft:redstone_wire replace
fill ~81 ~75 ~648 ~81 ~75 ~652 minecraft:redstone_wire replace
setblock ~108 ~75 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~75 ~652 ~108 ~75 ~656 minecraft:redstone_wire replace
fill ~117 ~75 ~656 ~117 ~75 ~660 minecraft:redstone_wire replace
setblock ~114 ~76 ~385 minecraft:redstone_wire replace
setblock ~84 ~76 ~397 minecraft:redstone_wire replace
setblock ~87 ~76 ~605 minecraft:redstone_wire replace
setblock ~90 ~76 ~609 minecraft:redstone_wire replace
setblock ~93 ~76 ~613 minecraft:redstone_wire replace
setblock ~96 ~76 ~617 minecraft:redstone_wire replace
setblock ~99 ~76 ~621 minecraft:redstone_wire replace
setblock ~102 ~76 ~625 minecraft:redstone_wire replace
setblock ~111 ~76 ~629 minecraft:redstone_wire replace
setblock ~78 ~76 ~633 minecraft:redstone_wire replace
setblock ~105 ~76 ~637 minecraft:redstone_wire replace
setblock ~120 ~76 ~649 minecraft:redstone_wire replace
setblock ~81 ~76 ~653 minecraft:redstone_wire replace
setblock ~108 ~76 ~657 minecraft:redstone_wire replace
setblock ~117 ~76 ~661 minecraft:redstone_wire replace
fill ~114 ~77 ~386 ~116 ~77 ~386 minecraft:redstone_wire replace
setblock ~115 ~77 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~77 ~398 ~84 ~77 ~398 minecraft:redstone_wire replace
setblock ~82 ~77 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~606 ~79 ~77 ~606 minecraft:redstone_wire replace
setblock ~80 ~77 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~81 ~77 ~606 ~89 ~77 ~606 minecraft:redstone_wire replace
setblock ~79 ~77 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~77 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~610 ~80 ~77 ~610 minecraft:redstone_wire replace
setblock ~82 ~77 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~84 ~77 ~610 ~92 ~77 ~610 minecraft:redstone_wire replace
setblock ~79 ~77 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~77 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~614 ~83 ~77 ~614 minecraft:redstone_wire replace
setblock ~85 ~77 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~87 ~77 ~614 ~95 ~77 ~614 minecraft:redstone_wire replace
setblock ~79 ~77 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~77 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~618 ~86 ~77 ~618 minecraft:redstone_wire replace
setblock ~88 ~77 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~77 ~618 ~98 ~77 ~618 minecraft:redstone_wire replace
setblock ~79 ~77 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~77 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~622 ~89 ~77 ~622 minecraft:redstone_wire replace
setblock ~91 ~77 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~77 ~622 ~101 ~77 ~622 minecraft:redstone_wire replace
setblock ~79 ~77 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~77 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~77 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~79 ~77 ~626 ~92 ~77 ~626 minecraft:redstone_wire replace
setblock ~94 ~77 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~96 ~77 ~626 ~104 ~77 ~626 minecraft:redstone_wire replace
setblock ~79 ~77 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~77 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~77 ~630 ~111 ~77 ~630 minecraft:redstone_wire replace
setblock ~109 ~77 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~634 ~80 ~77 ~634 minecraft:redstone_wire replace
setblock ~79 ~77 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~638 ~80 ~77 ~638 minecraft:redstone_wire replace
setblock ~81 ~77 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~82 ~77 ~638 ~95 ~77 ~638 minecraft:redstone_wire replace
setblock ~97 ~77 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~77 ~638 ~107 ~77 ~638 minecraft:redstone_wire replace
setblock ~79 ~77 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~77 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~77 ~650 ~125 ~77 ~650 minecraft:redstone_wire replace
setblock ~124 ~77 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~654 ~86 ~77 ~654 minecraft:redstone_wire replace
setblock ~79 ~77 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~85 ~77 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~77 ~658 ~81 ~77 ~658 minecraft:redstone_wire replace
setblock ~83 ~77 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~77 ~658 ~98 ~77 ~658 minecraft:redstone_wire replace
setblock ~100 ~77 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~77 ~658 ~114 ~77 ~658 minecraft:redstone_wire replace
setblock ~116 ~77 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~77 ~658 ~119 ~77 ~658 minecraft:redstone_wire replace
setblock ~79 ~77 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~77 ~659 minecraft:redstone_wire replace
setblock ~118 ~77 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~77 ~662 ~122 ~77 ~662 minecraft:redstone_wire replace
setblock ~121 ~77 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~78 ~388 minecraft:redstone_wire replace
setblock ~82 ~78 ~400 minecraft:redstone_wire replace
setblock ~79 ~78 ~608 minecraft:redstone_wire replace
setblock ~88 ~78 ~608 minecraft:redstone_wire replace
setblock ~79 ~78 ~612 minecraft:redstone_wire replace
setblock ~91 ~78 ~612 minecraft:redstone_wire replace
setblock ~79 ~78 ~616 minecraft:redstone_wire replace
setblock ~94 ~78 ~616 minecraft:redstone_wire replace
setblock ~79 ~78 ~620 minecraft:redstone_wire replace
setblock ~97 ~78 ~620 minecraft:redstone_wire replace
setblock ~79 ~78 ~624 minecraft:redstone_wire replace
setblock ~100 ~78 ~624 minecraft:redstone_wire replace
setblock ~79 ~78 ~628 minecraft:redstone_wire replace
setblock ~103 ~78 ~628 minecraft:redstone_wire replace
setblock ~109 ~78 ~632 minecraft:redstone_wire replace
setblock ~79 ~78 ~636 minecraft:redstone_wire replace
setblock ~79 ~78 ~640 minecraft:redstone_wire replace
setblock ~106 ~78 ~640 minecraft:redstone_wire replace
setblock ~124 ~78 ~652 minecraft:redstone_wire replace
setblock ~79 ~78 ~656 minecraft:redstone_wire replace
setblock ~85 ~78 ~656 minecraft:redstone_wire replace
setblock ~79 ~78 ~660 minecraft:redstone_wire replace
setblock ~112 ~78 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~78 ~660 minecraft:redstone_wire replace
setblock ~121 ~78 ~664 minecraft:redstone_wire replace
fill ~114 ~79 ~384 ~114 ~79 ~388 minecraft:redstone_wire replace
fill ~81 ~79 ~396 ~81 ~79 ~400 minecraft:redstone_wire replace
setblock ~87 ~79 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~79 ~602 ~87 ~79 ~608 minecraft:redstone_wire replace
setblock ~78 ~79 ~604 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~79 ~606 ~78 ~79 ~614 minecraft:redstone_wire replace
fill ~90 ~79 ~608 ~90 ~79 ~612 minecraft:redstone_wire replace
fill ~93 ~79 ~612 ~93 ~79 ~616 minecraft:redstone_wire replace
setblock ~78 ~79 ~615 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~79 ~616 ~78 ~79 ~628 minecraft:redstone_wire replace
fill ~96 ~79 ~616 ~96 ~79 ~620 minecraft:redstone_wire replace
fill ~99 ~79 ~620 ~99 ~79 ~624 minecraft:redstone_wire replace
fill ~102 ~79 ~624 ~102 ~79 ~628 minecraft:redstone_wire replace
fill ~108 ~79 ~628 ~108 ~79 ~632 minecraft:redstone_wire replace
setblock ~78 ~79 ~630 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~79 ~632 ~78 ~79 ~644 minecraft:redstone_wire replace
fill ~105 ~79 ~636 ~105 ~79 ~640 minecraft:redstone_wire replace
setblock ~123 ~79 ~644 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~79 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~79 ~646 ~123 ~79 ~652 minecraft:redstone_wire replace
fill ~78 ~79 ~648 ~78 ~79 ~660 minecraft:redstone_wire replace
setblock ~84 ~79 ~648 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~79 ~650 ~84 ~79 ~656 minecraft:redstone_wire replace
setblock ~117 ~79 ~652 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~79 ~654 ~117 ~79 ~660 minecraft:redstone_wire replace
fill ~111 ~79 ~656 ~111 ~79 ~660 minecraft:redstone_wire replace
fill ~120 ~79 ~660 ~120 ~79 ~664 minecraft:redstone_wire replace
setblock ~114 ~80 ~383 minecraft:redstone_wire replace
setblock ~81 ~80 ~395 minecraft:redstone_wire replace
setblock ~87 ~80 ~599 minecraft:redstone_wire replace
setblock ~78 ~80 ~603 minecraft:redstone_wire replace
setblock ~90 ~80 ~607 minecraft:redstone_wire replace
setblock ~93 ~80 ~611 minecraft:redstone_wire replace
setblock ~96 ~80 ~615 minecraft:redstone_wire replace
setblock ~99 ~80 ~619 minecraft:redstone_wire replace
setblock ~102 ~80 ~623 minecraft:redstone_wire replace
setblock ~108 ~80 ~627 minecraft:redstone_wire replace
setblock ~105 ~80 ~635 minecraft:redstone_wire replace
setblock ~123 ~80 ~643 minecraft:redstone_wire replace
setblock ~84 ~80 ~647 minecraft:redstone_wire replace
setblock ~117 ~80 ~651 minecraft:redstone_wire replace
setblock ~111 ~80 ~655 minecraft:redstone_wire replace
setblock ~120 ~80 ~659 minecraft:redstone_wire replace
setblock ~115 ~81 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~81 ~382 ~116 ~81 ~382 minecraft:redstone_wire replace
setblock ~82 ~81 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~81 ~394 ~83 ~81 ~394 minecraft:redstone_wire replace
setblock ~88 ~81 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~81 ~598 ~89 ~81 ~598 minecraft:redstone_wire replace
setblock ~79 ~81 ~601 minecraft:redstone_wire replace
fill ~78 ~81 ~602 ~80 ~81 ~602 minecraft:redstone_wire replace
setblock ~91 ~81 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~81 ~606 ~92 ~81 ~606 minecraft:redstone_wire replace
setblock ~94 ~81 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~81 ~610 ~95 ~81 ~610 minecraft:redstone_wire replace
setblock ~97 ~81 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~81 ~614 ~98 ~81 ~614 minecraft:redstone_wire replace
setblock ~100 ~81 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~81 ~618 ~101 ~81 ~618 minecraft:redstone_wire replace
setblock ~103 ~81 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~81 ~622 ~104 ~81 ~622 minecraft:redstone_wire replace
setblock ~109 ~81 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~81 ~626 ~110 ~81 ~626 minecraft:redstone_wire replace
setblock ~106 ~81 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~81 ~634 ~107 ~81 ~634 minecraft:redstone_wire replace
setblock ~124 ~81 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~81 ~642 ~125 ~81 ~642 minecraft:redstone_wire replace
setblock ~85 ~81 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~81 ~646 ~86 ~81 ~646 minecraft:redstone_wire replace
setblock ~118 ~81 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~81 ~650 ~119 ~81 ~650 minecraft:redstone_wire replace
setblock ~112 ~81 ~653 minecraft:redstone_wire replace
fill ~111 ~81 ~654 ~113 ~81 ~654 minecraft:redstone_wire replace
setblock ~121 ~81 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~81 ~658 ~122 ~81 ~658 minecraft:redstone_wire replace
setblock ~115 ~82 ~380 minecraft:redstone_wire replace
setblock ~82 ~82 ~392 minecraft:redstone_wire replace
setblock ~88 ~82 ~596 minecraft:redstone_wire replace
setblock ~79 ~82 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~82 ~604 minecraft:redstone_wire replace
setblock ~94 ~82 ~608 minecraft:redstone_wire replace
setblock ~97 ~82 ~612 minecraft:redstone_wire replace
setblock ~100 ~82 ~616 minecraft:redstone_wire replace
setblock ~103 ~82 ~620 minecraft:redstone_wire replace
setblock ~109 ~82 ~624 minecraft:redstone_wire replace
setblock ~106 ~82 ~632 minecraft:redstone_wire replace
setblock ~124 ~82 ~640 minecraft:redstone_wire replace
setblock ~85 ~82 ~644 minecraft:redstone_wire replace
setblock ~118 ~82 ~648 minecraft:redstone_wire replace
setblock ~112 ~82 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~82 ~656 minecraft:redstone_wire replace
fill ~114 ~83 ~380 ~114 ~83 ~384 minecraft:redstone_wire replace
fill ~81 ~83 ~392 ~81 ~83 ~396 minecraft:redstone_wire replace
fill ~87 ~83 ~596 ~87 ~83 ~600 minecraft:redstone_wire replace
fill ~78 ~83 ~600 ~78 ~83 ~604 minecraft:redstone_wire replace
fill ~90 ~83 ~604 ~90 ~83 ~608 minecraft:redstone_wire replace
fill ~93 ~83 ~608 ~93 ~83 ~612 minecraft:redstone_wire replace
fill ~96 ~83 ~612 ~96 ~83 ~616 minecraft:redstone_wire replace
fill ~99 ~83 ~616 ~99 ~83 ~620 minecraft:redstone_wire replace
fill ~102 ~83 ~620 ~102 ~83 ~624 minecraft:redstone_wire replace
fill ~108 ~83 ~624 ~108 ~83 ~628 minecraft:redstone_wire replace
fill ~105 ~83 ~632 ~105 ~83 ~636 minecraft:redstone_wire replace
fill ~123 ~83 ~640 ~123 ~83 ~644 minecraft:redstone_wire replace
fill ~84 ~83 ~644 ~84 ~83 ~648 minecraft:redstone_wire replace
fill ~117 ~83 ~648 ~117 ~83 ~652 minecraft:redstone_wire replace
fill ~111 ~83 ~652 ~111 ~83 ~656 minecraft:redstone_wire replace
fill ~120 ~83 ~656 ~120 ~83 ~660 minecraft:redstone_wire replace
setblock ~114 ~84 ~385 minecraft:redstone_wire replace
setblock ~81 ~84 ~397 minecraft:redstone_wire replace
setblock ~87 ~84 ~601 minecraft:redstone_wire replace
setblock ~78 ~84 ~605 minecraft:redstone_wire replace
setblock ~90 ~84 ~609 minecraft:redstone_wire replace
setblock ~93 ~84 ~613 minecraft:redstone_wire replace
setblock ~96 ~84 ~617 minecraft:redstone_wire replace
setblock ~99 ~84 ~621 minecraft:redstone_wire replace
setblock ~102 ~84 ~625 minecraft:redstone_wire replace
setblock ~108 ~84 ~629 minecraft:redstone_wire replace
setblock ~105 ~84 ~637 minecraft:redstone_wire replace
setblock ~123 ~84 ~645 minecraft:redstone_wire replace
setblock ~84 ~84 ~649 minecraft:redstone_wire replace
setblock ~117 ~84 ~653 minecraft:redstone_wire replace
setblock ~111 ~84 ~657 minecraft:redstone_wire replace
setblock ~120 ~84 ~661 minecraft:redstone_wire replace
fill ~114 ~85 ~386 ~116 ~85 ~386 minecraft:redstone_wire replace
setblock ~115 ~85 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~85 ~398 ~83 ~85 ~398 minecraft:redstone_wire replace
setblock ~82 ~85 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~85 ~602 ~89 ~85 ~602 minecraft:redstone_wire replace
setblock ~88 ~85 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~85 ~606 ~80 ~85 ~606 minecraft:redstone_wire replace
setblock ~79 ~85 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~85 ~610 ~92 ~85 ~610 minecraft:redstone_wire replace
setblock ~91 ~85 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~85 ~614 ~95 ~85 ~614 minecraft:redstone_wire replace
setblock ~94 ~85 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~85 ~618 ~98 ~85 ~618 minecraft:redstone_wire replace
setblock ~97 ~85 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~85 ~622 ~101 ~85 ~622 minecraft:redstone_wire replace
setblock ~100 ~85 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~85 ~626 ~104 ~85 ~626 minecraft:redstone_wire replace
setblock ~103 ~85 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~85 ~630 ~110 ~85 ~630 minecraft:redstone_wire replace
setblock ~109 ~85 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~85 ~638 ~107 ~85 ~638 minecraft:redstone_wire replace
setblock ~106 ~85 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~85 ~646 ~125 ~85 ~646 minecraft:redstone_wire replace
setblock ~124 ~85 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~85 ~650 ~86 ~85 ~650 minecraft:redstone_wire replace
setblock ~85 ~85 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~85 ~654 ~119 ~85 ~654 minecraft:redstone_wire replace
setblock ~118 ~85 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~85 ~658 ~113 ~85 ~658 minecraft:redstone_wire replace
setblock ~112 ~85 ~659 minecraft:redstone_wire replace
fill ~120 ~85 ~662 ~122 ~85 ~662 minecraft:redstone_wire replace
setblock ~121 ~85 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~86 ~388 minecraft:redstone_wire replace
setblock ~82 ~86 ~400 minecraft:redstone_wire replace
setblock ~88 ~86 ~604 minecraft:redstone_wire replace
setblock ~79 ~86 ~608 minecraft:redstone_wire replace
setblock ~91 ~86 ~612 minecraft:redstone_wire replace
setblock ~94 ~86 ~616 minecraft:redstone_wire replace
setblock ~97 ~86 ~620 minecraft:redstone_wire replace
setblock ~100 ~86 ~624 minecraft:redstone_wire replace
setblock ~103 ~86 ~628 minecraft:redstone_wire replace
setblock ~109 ~86 ~632 minecraft:redstone_wire replace
setblock ~106 ~86 ~640 minecraft:redstone_wire replace
setblock ~124 ~86 ~648 minecraft:redstone_wire replace
setblock ~85 ~86 ~652 minecraft:redstone_wire replace
setblock ~118 ~86 ~656 minecraft:redstone_wire replace
setblock ~112 ~86 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~86 ~664 minecraft:redstone_wire replace
fill ~114 ~87 ~384 ~114 ~87 ~388 minecraft:redstone_wire replace
fill ~81 ~87 ~396 ~81 ~87 ~400 minecraft:redstone_wire replace
fill ~87 ~87 ~600 ~87 ~87 ~604 minecraft:redstone_wire replace
fill ~78 ~87 ~604 ~78 ~87 ~608 minecraft:redstone_wire replace
fill ~90 ~87 ~608 ~90 ~87 ~612 minecraft:redstone_wire replace
fill ~93 ~87 ~612 ~93 ~87 ~616 minecraft:redstone_wire replace
fill ~96 ~87 ~616 ~96 ~87 ~620 minecraft:redstone_wire replace
fill ~99 ~87 ~620 ~99 ~87 ~624 minecraft:redstone_wire replace
fill ~102 ~87 ~624 ~102 ~87 ~628 minecraft:redstone_wire replace
fill ~108 ~87 ~628 ~108 ~87 ~632 minecraft:redstone_wire replace
fill ~105 ~87 ~636 ~105 ~87 ~640 minecraft:redstone_wire replace
fill ~123 ~87 ~644 ~123 ~87 ~648 minecraft:redstone_wire replace
fill ~84 ~87 ~648 ~84 ~87 ~652 minecraft:redstone_wire replace
fill ~117 ~87 ~652 ~117 ~87 ~656 minecraft:redstone_wire replace
fill ~111 ~87 ~656 ~111 ~87 ~660 minecraft:redstone_wire replace
fill ~120 ~87 ~660 ~120 ~87 ~664 minecraft:redstone_wire replace
setblock ~114 ~88 ~383 minecraft:redstone_wire replace
setblock ~81 ~88 ~395 minecraft:redstone_wire replace
setblock ~87 ~88 ~599 minecraft:redstone_wire replace
setblock ~78 ~88 ~603 minecraft:redstone_wire replace
setblock ~90 ~88 ~607 minecraft:redstone_wire replace
setblock ~93 ~88 ~611 minecraft:redstone_wire replace
setblock ~96 ~88 ~615 minecraft:redstone_wire replace
setblock ~99 ~88 ~619 minecraft:redstone_wire replace
setblock ~102 ~88 ~623 minecraft:redstone_wire replace
setblock ~108 ~88 ~627 minecraft:redstone_wire replace
setblock ~105 ~88 ~635 minecraft:redstone_wire replace
setblock ~123 ~88 ~643 minecraft:redstone_wire replace
setblock ~84 ~88 ~647 minecraft:redstone_wire replace
setblock ~117 ~88 ~651 minecraft:redstone_wire replace
setblock ~111 ~88 ~655 minecraft:redstone_wire replace
setblock ~120 ~88 ~659 minecraft:redstone_wire replace
setblock ~115 ~89 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~89 ~382 ~116 ~89 ~382 minecraft:redstone_wire replace
setblock ~82 ~89 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~89 ~394 ~83 ~89 ~394 minecraft:redstone_wire replace
setblock ~88 ~89 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~89 ~598 ~89 ~89 ~598 minecraft:redstone_wire replace
setblock ~79 ~89 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~89 ~602 ~80 ~89 ~602 minecraft:redstone_wire replace
setblock ~91 ~89 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~89 ~606 ~92 ~89 ~606 minecraft:redstone_wire replace
setblock ~94 ~89 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~89 ~610 ~95 ~89 ~610 minecraft:redstone_wire replace
setblock ~97 ~89 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~89 ~614 ~98 ~89 ~614 minecraft:redstone_wire replace
setblock ~100 ~89 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~89 ~618 ~101 ~89 ~618 minecraft:redstone_wire replace
setblock ~103 ~89 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~89 ~622 ~104 ~89 ~622 minecraft:redstone_wire replace
setblock ~109 ~89 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~89 ~626 ~110 ~89 ~626 minecraft:redstone_wire replace
setblock ~106 ~89 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~89 ~634 ~107 ~89 ~634 minecraft:redstone_wire replace
setblock ~124 ~89 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~89 ~642 ~125 ~89 ~642 minecraft:redstone_wire replace
setblock ~85 ~89 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~89 ~646 ~86 ~89 ~646 minecraft:redstone_wire replace
setblock ~118 ~89 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~89 ~650 ~119 ~89 ~650 minecraft:redstone_wire replace
setblock ~112 ~89 ~653 minecraft:redstone_wire replace
fill ~111 ~89 ~654 ~113 ~89 ~654 minecraft:redstone_wire replace
setblock ~121 ~89 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~89 ~658 ~122 ~89 ~658 minecraft:redstone_wire replace
setblock ~115 ~90 ~380 minecraft:redstone_wire replace
setblock ~82 ~90 ~392 minecraft:redstone_wire replace
setblock ~88 ~90 ~596 minecraft:redstone_wire replace
setblock ~79 ~90 ~600 minecraft:redstone_wire replace
setblock ~91 ~90 ~604 minecraft:redstone_wire replace
setblock ~94 ~90 ~608 minecraft:redstone_wire replace
setblock ~97 ~90 ~612 minecraft:redstone_wire replace
setblock ~100 ~90 ~616 minecraft:redstone_wire replace
setblock ~103 ~90 ~620 minecraft:redstone_wire replace
setblock ~109 ~90 ~624 minecraft:redstone_wire replace
setblock ~106 ~90 ~632 minecraft:redstone_wire replace
setblock ~124 ~90 ~640 minecraft:redstone_wire replace
setblock ~85 ~90 ~644 minecraft:redstone_wire replace
setblock ~118 ~90 ~648 minecraft:redstone_wire replace
setblock ~112 ~90 ~652 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~90 ~656 minecraft:redstone_wire replace
fill ~114 ~91 ~380 ~114 ~91 ~384 minecraft:redstone_wire replace
fill ~81 ~91 ~392 ~81 ~91 ~396 minecraft:redstone_wire replace
fill ~87 ~91 ~596 ~87 ~91 ~600 minecraft:redstone_wire replace
fill ~78 ~91 ~600 ~78 ~91 ~604 minecraft:redstone_wire replace
fill ~90 ~91 ~604 ~90 ~91 ~608 minecraft:redstone_wire replace
fill ~93 ~91 ~608 ~93 ~91 ~612 minecraft:redstone_wire replace
fill ~96 ~91 ~612 ~96 ~91 ~616 minecraft:redstone_wire replace
fill ~99 ~91 ~616 ~99 ~91 ~620 minecraft:redstone_wire replace
fill ~102 ~91 ~620 ~102 ~91 ~624 minecraft:redstone_wire replace
fill ~108 ~91 ~624 ~108 ~91 ~628 minecraft:redstone_wire replace
fill ~105 ~91 ~632 ~105 ~91 ~636 minecraft:redstone_wire replace
fill ~123 ~91 ~640 ~123 ~91 ~644 minecraft:redstone_wire replace
fill ~84 ~91 ~644 ~84 ~91 ~648 minecraft:redstone_wire replace
fill ~117 ~91 ~648 ~117 ~91 ~652 minecraft:redstone_wire replace
fill ~111 ~91 ~652 ~111 ~91 ~656 minecraft:redstone_wire replace
fill ~120 ~91 ~656 ~120 ~91 ~660 minecraft:redstone_wire replace
setblock ~114 ~92 ~385 minecraft:redstone_wire replace
setblock ~81 ~92 ~397 minecraft:redstone_wire replace
setblock ~87 ~92 ~601 minecraft:redstone_wire replace
setblock ~78 ~92 ~605 minecraft:redstone_wire replace
setblock ~90 ~92 ~609 minecraft:redstone_wire replace
setblock ~93 ~92 ~613 minecraft:redstone_wire replace
setblock ~96 ~92 ~617 minecraft:redstone_wire replace
setblock ~99 ~92 ~621 minecraft:redstone_wire replace
setblock ~102 ~92 ~625 minecraft:redstone_wire replace
setblock ~108 ~92 ~629 minecraft:redstone_wire replace
setblock ~105 ~92 ~637 minecraft:redstone_wire replace
setblock ~123 ~92 ~645 minecraft:redstone_wire replace
setblock ~84 ~92 ~649 minecraft:redstone_wire replace
setblock ~117 ~92 ~653 minecraft:redstone_wire replace
setblock ~111 ~92 ~657 minecraft:redstone_wire replace
setblock ~120 ~92 ~661 minecraft:redstone_wire replace
fill ~114 ~93 ~386 ~119 ~93 ~386 minecraft:redstone_wire replace
setblock ~120 ~93 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~93 ~386 ~122 ~93 ~386 minecraft:redstone_wire replace
setblock ~121 ~93 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~93 ~398 ~83 ~93 ~398 minecraft:redstone_wire replace
setblock ~82 ~93 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~93 ~602 ~89 ~93 ~602 minecraft:redstone_wire replace
setblock ~88 ~93 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~93 ~606 ~80 ~93 ~606 minecraft:redstone_wire replace
setblock ~79 ~93 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~93 ~610 ~92 ~93 ~610 minecraft:redstone_wire replace
setblock ~91 ~93 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~93 ~614 ~95 ~93 ~614 minecraft:redstone_wire replace
setblock ~94 ~93 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~93 ~618 ~98 ~93 ~618 minecraft:redstone_wire replace
setblock ~97 ~93 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~93 ~622 ~101 ~93 ~622 minecraft:redstone_wire replace
setblock ~100 ~93 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~93 ~626 ~104 ~93 ~626 minecraft:redstone_wire replace
setblock ~103 ~93 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~93 ~630 ~113 ~93 ~630 minecraft:redstone_wire replace
setblock ~114 ~93 ~630 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~93 ~630 ~125 ~93 ~630 minecraft:redstone_wire replace
setblock ~106 ~93 ~631 minecraft:redstone_wire replace
setblock ~112 ~93 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~93 ~631 minecraft:redstone_wire replace
setblock ~118 ~93 ~631 minecraft:redstone_wire replace
setblock ~124 ~93 ~631 minecraft:redstone_wire replace
fill ~105 ~93 ~638 ~110 ~93 ~638 minecraft:redstone_wire replace
setblock ~111 ~93 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~93 ~638 ~124 ~93 ~638 minecraft:redstone_wire replace
setblock ~125 ~93 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~93 ~638 ~128 ~93 ~638 minecraft:redstone_wire replace
setblock ~106 ~93 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~93 ~639 minecraft:redstone_wire replace
setblock ~112 ~93 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~93 ~639 minecraft:redstone_wire replace
setblock ~127 ~93 ~639 minecraft:redstone_wire replace
fill ~123 ~93 ~646 ~129 ~93 ~646 minecraft:redstone_wire replace
setblock ~131 ~93 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~93 ~646 ~137 ~93 ~646 minecraft:redstone_wire replace
setblock ~136 ~93 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~93 ~650 ~86 ~93 ~650 minecraft:redstone_wire replace
setblock ~85 ~93 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~93 ~654 ~123 ~93 ~654 minecraft:redstone_wire replace
setblock ~125 ~93 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~93 ~654 ~131 ~93 ~654 minecraft:redstone_wire replace
setblock ~130 ~93 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~93 ~658 ~116 ~93 ~658 minecraft:redstone_wire replace
setblock ~117 ~93 ~658 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~93 ~658 ~128 ~93 ~658 minecraft:redstone_wire replace
setblock ~106 ~93 ~659 minecraft:redstone_wire replace
setblock ~109 ~93 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~93 ~659 minecraft:redstone_wire replace
setblock ~115 ~93 ~659 minecraft:redstone_wire replace
setblock ~118 ~93 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~93 ~659 minecraft:redstone_wire replace
setblock ~127 ~93 ~659 minecraft:redstone_wire replace
fill ~120 ~93 ~662 ~126 ~93 ~662 minecraft:redstone_wire replace
setblock ~128 ~93 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~93 ~662 ~134 ~93 ~662 minecraft:redstone_wire replace
setblock ~133 ~93 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~94 ~388 minecraft:redstone_wire replace
setblock ~82 ~94 ~400 minecraft:redstone_wire replace
setblock ~88 ~94 ~604 minecraft:redstone_wire replace
setblock ~79 ~94 ~608 minecraft:redstone_wire replace
setblock ~91 ~94 ~612 minecraft:redstone_wire replace
setblock ~94 ~94 ~616 minecraft:redstone_wire replace
setblock ~97 ~94 ~620 minecraft:redstone_wire replace
setblock ~100 ~94 ~624 minecraft:redstone_wire replace
setblock ~103 ~94 ~628 minecraft:redstone_wire replace
setblock ~106 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~94 ~632 minecraft:redstone_wire replace
setblock ~115 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~94 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~94 ~640 minecraft:redstone_wire replace
setblock ~109 ~94 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~94 ~640 minecraft:redstone_wire replace
setblock ~115 ~94 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~94 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~94 ~648 minecraft:redstone_wire replace
setblock ~85 ~94 ~652 minecraft:redstone_wire replace
setblock ~130 ~94 ~656 minecraft:redstone_wire replace
setblock ~106 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~94 ~660 minecraft:redstone_wire replace
setblock ~112 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~94 ~660 minecraft:redstone_wire replace
setblock ~124 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~94 ~660 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~94 ~664 minecraft:redstone_wire replace
fill ~120 ~95 ~384 ~120 ~95 ~388 minecraft:redstone_wire replace
fill ~81 ~95 ~396 ~81 ~95 ~400 minecraft:redstone_wire replace
fill ~87 ~95 ~584 ~87 ~95 ~588 minecraft:redstone_wire replace
fill ~78 ~95 ~588 ~78 ~95 ~592 minecraft:redstone_wire replace
setblock ~87 ~95 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~95 ~592 ~87 ~95 ~604 minecraft:redstone_wire replace
fill ~90 ~95 ~592 ~90 ~95 ~596 minecraft:redstone_wire replace
setblock ~78 ~95 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~95 ~596 ~78 ~95 ~608 minecraft:redstone_wire replace
fill ~93 ~95 ~596 ~93 ~95 ~600 minecraft:redstone_wire replace
setblock ~90 ~95 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~95 ~600 ~90 ~95 ~612 minecraft:redstone_wire replace
fill ~96 ~95 ~600 ~96 ~95 ~604 minecraft:redstone_wire replace
setblock ~93 ~95 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~95 ~604 ~93 ~95 ~616 minecraft:redstone_wire replace
fill ~99 ~95 ~604 ~99 ~95 ~608 minecraft:redstone_wire replace
setblock ~96 ~95 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~95 ~608 ~96 ~95 ~620 minecraft:redstone_wire replace
fill ~102 ~95 ~608 ~102 ~95 ~612 minecraft:redstone_wire replace
setblock ~99 ~95 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~95 ~612 ~99 ~95 ~624 minecraft:redstone_wire replace
fill ~123 ~95 ~612 ~123 ~95 ~614 minecraft:redstone_wire replace
setblock ~102 ~95 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~95 ~616 ~102 ~95 ~628 minecraft:redstone_wire replace
setblock ~117 ~95 ~616 minecraft:redstone_wire replace
setblock ~123 ~95 ~616 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~95 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~95 ~618 ~117 ~95 ~630 minecraft:redstone_wire replace
fill ~123 ~95 ~618 ~123 ~95 ~630 minecraft:redstone_wire replace
setblock ~114 ~95 ~620 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~95 ~622 ~114 ~95 ~630 minecraft:redstone_wire replace
fill ~111 ~95 ~624 ~111 ~95 ~630 minecraft:redstone_wire replace
fill ~105 ~95 ~628 ~105 ~95 ~630 minecraft:redstone_wire replace
setblock ~105 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~95 ~631 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~95 ~632 ~105 ~95 ~644 minecraft:redstone_wire replace
fill ~111 ~95 ~632 ~111 ~95 ~644 minecraft:redstone_wire replace
fill ~114 ~95 ~632 ~114 ~95 ~644 minecraft:redstone_wire replace
fill ~117 ~95 ~632 ~117 ~95 ~644 minecraft:redstone_wire replace
fill ~123 ~95 ~632 ~123 ~95 ~644 minecraft:redstone_wire replace
setblock ~126 ~95 ~632 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~95 ~634 ~126 ~95 ~644 minecraft:redstone_wire replace
setblock ~108 ~95 ~636 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~95 ~638 ~108 ~95 ~644 minecraft:redstone_wire replace
fill ~135 ~95 ~644 ~135 ~95 ~648 minecraft:redstone_wire replace
setblock ~105 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~95 ~646 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~95 ~648 ~84 ~95 ~652 minecraft:redstone_wire replace
fill ~105 ~95 ~648 ~105 ~95 ~660 minecraft:redstone_wire replace
fill ~108 ~95 ~648 ~108 ~95 ~660 minecraft:redstone_wire replace
fill ~111 ~95 ~648 ~111 ~95 ~660 minecraft:redstone_wire replace
fill ~114 ~95 ~648 ~114 ~95 ~660 minecraft:redstone_wire replace
fill ~117 ~95 ~648 ~117 ~95 ~660 minecraft:redstone_wire replace
fill ~123 ~95 ~648 ~123 ~95 ~660 minecraft:redstone_wire replace
fill ~126 ~95 ~648 ~126 ~95 ~660 minecraft:redstone_wire replace
fill ~129 ~95 ~652 ~129 ~95 ~656 minecraft:redstone_wire replace
fill ~132 ~95 ~660 ~132 ~95 ~664 minecraft:redstone_wire replace
setblock ~120 ~96 ~383 minecraft:redstone_wire replace
setblock ~81 ~96 ~395 minecraft:redstone_wire replace
setblock ~87 ~96 ~583 minecraft:redstone_wire replace
setblock ~78 ~96 ~587 minecraft:redstone_wire replace
setblock ~90 ~96 ~591 minecraft:redstone_wire replace
setblock ~93 ~96 ~595 minecraft:redstone_wire replace
setblock ~96 ~96 ~599 minecraft:redstone_wire replace
setblock ~99 ~96 ~603 minecraft:redstone_wire replace
setblock ~102 ~96 ~607 minecraft:redstone_wire replace
setblock ~123 ~96 ~611 minecraft:redstone_wire replace
setblock ~117 ~96 ~615 minecraft:redstone_wire replace
setblock ~114 ~96 ~619 minecraft:redstone_wire replace
setblock ~111 ~96 ~623 minecraft:redstone_wire replace
setblock ~105 ~96 ~627 minecraft:redstone_wire replace
setblock ~126 ~96 ~631 minecraft:redstone_wire replace
setblock ~108 ~96 ~635 minecraft:redstone_wire replace
setblock ~135 ~96 ~643 minecraft:redstone_wire replace
setblock ~84 ~96 ~647 minecraft:redstone_wire replace
setblock ~129 ~96 ~651 minecraft:redstone_wire replace
setblock ~132 ~96 ~659 minecraft:redstone_wire replace
setblock ~115 ~97 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~97 ~382 ~120 ~97 ~382 minecraft:redstone_wire replace
setblock ~82 ~97 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~97 ~394 ~83 ~97 ~394 minecraft:redstone_wire replace
setblock ~88 ~97 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~97 ~582 ~89 ~97 ~582 minecraft:redstone_wire replace
setblock ~79 ~97 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~97 ~586 ~80 ~97 ~586 minecraft:redstone_wire replace
setblock ~91 ~97 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~97 ~590 ~92 ~97 ~590 minecraft:redstone_wire replace
setblock ~94 ~97 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~97 ~594 ~95 ~97 ~594 minecraft:redstone_wire replace
setblock ~97 ~97 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~97 ~598 ~98 ~97 ~598 minecraft:redstone_wire replace
setblock ~100 ~97 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~97 ~602 ~101 ~97 ~602 minecraft:redstone_wire replace
setblock ~103 ~97 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~97 ~606 ~104 ~97 ~606 minecraft:redstone_wire replace
setblock ~118 ~97 ~609 minecraft:redstone_wire replace
fill ~117 ~97 ~610 ~123 ~97 ~610 minecraft:redstone_wire replace
setblock ~112 ~97 ~613 minecraft:redstone_wire replace
fill ~111 ~97 ~614 ~117 ~97 ~614 minecraft:redstone_wire replace
setblock ~112 ~97 ~617 minecraft:redstone_wire replace
fill ~111 ~97 ~618 ~114 ~97 ~618 minecraft:redstone_wire replace
setblock ~109 ~97 ~621 minecraft:redstone_wire replace
fill ~108 ~97 ~622 ~111 ~97 ~622 minecraft:redstone_wire replace
setblock ~106 ~97 ~625 minecraft:redstone_wire replace
fill ~105 ~97 ~626 ~107 ~97 ~626 minecraft:redstone_wire replace
setblock ~118 ~97 ~629 minecraft:redstone_wire replace
fill ~117 ~97 ~630 ~126 ~97 ~630 minecraft:redstone_wire replace
setblock ~106 ~97 ~633 minecraft:redstone_wire replace
fill ~105 ~97 ~634 ~108 ~97 ~634 minecraft:redstone_wire replace
setblock ~127 ~97 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~97 ~642 ~127 ~97 ~642 minecraft:redstone_wire replace
setblock ~128 ~97 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~97 ~642 ~135 ~97 ~642 minecraft:redstone_wire replace
setblock ~85 ~97 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~97 ~646 ~86 ~97 ~646 minecraft:redstone_wire replace
setblock ~121 ~97 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~97 ~650 ~121 ~97 ~650 minecraft:redstone_wire replace
setblock ~122 ~97 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~97 ~650 ~129 ~97 ~650 minecraft:redstone_wire replace
setblock ~124 ~97 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~97 ~658 ~124 ~97 ~658 minecraft:redstone_wire replace
setblock ~125 ~97 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~97 ~658 ~132 ~97 ~658 minecraft:redstone_wire replace
setblock ~115 ~98 ~380 minecraft:redstone_wire replace
setblock ~82 ~98 ~392 minecraft:redstone_wire replace
setblock ~88 ~98 ~580 minecraft:redstone_wire replace
setblock ~79 ~98 ~584 minecraft:redstone_wire replace
setblock ~91 ~98 ~588 minecraft:redstone_wire replace
setblock ~94 ~98 ~592 minecraft:redstone_wire replace
setblock ~97 ~98 ~596 minecraft:redstone_wire replace
setblock ~100 ~98 ~600 minecraft:redstone_wire replace
setblock ~103 ~98 ~604 minecraft:redstone_wire replace
setblock ~118 ~98 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~98 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~98 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~98 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~98 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~98 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~98 ~632 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~98 ~640 minecraft:redstone_wire replace
setblock ~85 ~98 ~644 minecraft:redstone_wire replace
setblock ~121 ~98 ~648 minecraft:redstone_wire replace
setblock ~124 ~98 ~656 minecraft:redstone_wire replace
fill ~114 ~99 ~380 ~114 ~99 ~384 minecraft:redstone_wire replace
fill ~81 ~99 ~392 ~81 ~99 ~396 minecraft:redstone_wire replace
fill ~87 ~99 ~580 ~87 ~99 ~584 minecraft:redstone_wire replace
fill ~78 ~99 ~584 ~78 ~99 ~588 minecraft:redstone_wire replace
fill ~90 ~99 ~588 ~90 ~99 ~592 minecraft:redstone_wire replace
fill ~93 ~99 ~592 ~93 ~99 ~596 minecraft:redstone_wire replace
fill ~96 ~99 ~596 ~96 ~99 ~600 minecraft:redstone_wire replace
fill ~99 ~99 ~600 ~99 ~99 ~604 minecraft:redstone_wire replace
fill ~102 ~99 ~604 ~102 ~99 ~608 minecraft:redstone_wire replace
fill ~117 ~99 ~608 ~117 ~99 ~620 minecraft:redstone_wire replace
fill ~111 ~99 ~612 ~111 ~99 ~618 minecraft:redstone_wire replace
fill ~108 ~99 ~620 ~108 ~99 ~624 minecraft:redstone_wire replace
setblock ~111 ~99 ~620 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~99 ~622 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~99 ~624 ~105 ~99 ~634 minecraft:redstone_wire replace
fill ~117 ~99 ~624 ~117 ~99 ~630 minecraft:redstone_wire replace
setblock ~117 ~99 ~632 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~99 ~636 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~99 ~640 ~126 ~99 ~644 minecraft:redstone_wire replace
fill ~84 ~99 ~644 ~84 ~99 ~648 minecraft:redstone_wire replace
fill ~120 ~99 ~648 ~120 ~99 ~652 minecraft:redstone_wire replace
fill ~123 ~99 ~656 ~123 ~99 ~660 minecraft:redstone_wire replace
setblock ~114 ~100 ~385 minecraft:redstone_wire replace
setblock ~81 ~100 ~397 minecraft:redstone_wire replace
setblock ~87 ~100 ~585 minecraft:redstone_wire replace
setblock ~78 ~100 ~589 minecraft:redstone_wire replace
setblock ~90 ~100 ~593 minecraft:redstone_wire replace
setblock ~93 ~100 ~597 minecraft:redstone_wire replace
setblock ~96 ~100 ~601 minecraft:redstone_wire replace
setblock ~99 ~100 ~605 minecraft:redstone_wire replace
setblock ~102 ~100 ~609 minecraft:redstone_wire replace
setblock ~111 ~100 ~621 minecraft:redstone_wire replace
setblock ~108 ~100 ~625 minecraft:redstone_wire replace
setblock ~117 ~100 ~633 minecraft:redstone_wire replace
setblock ~105 ~100 ~637 minecraft:redstone_wire replace
setblock ~126 ~100 ~645 minecraft:redstone_wire replace
setblock ~84 ~100 ~649 minecraft:redstone_wire replace
setblock ~120 ~100 ~653 minecraft:redstone_wire replace
setblock ~123 ~100 ~661 minecraft:redstone_wire replace
fill ~114 ~101 ~386 ~120 ~101 ~386 minecraft:redstone_wire replace
setblock ~122 ~101 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~101 ~386 ~128 ~101 ~386 minecraft:redstone_wire replace
setblock ~127 ~101 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~101 ~398 ~83 ~101 ~398 minecraft:redstone_wire replace
setblock ~82 ~101 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~101 ~586 ~89 ~101 ~586 minecraft:redstone_wire replace
setblock ~88 ~101 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~101 ~590 ~80 ~101 ~590 minecraft:redstone_wire replace
setblock ~79 ~101 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~101 ~594 ~92 ~101 ~594 minecraft:redstone_wire replace
setblock ~91 ~101 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~101 ~598 ~95 ~101 ~598 minecraft:redstone_wire replace
setblock ~94 ~101 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~101 ~602 ~98 ~101 ~602 minecraft:redstone_wire replace
setblock ~97 ~101 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~101 ~606 ~101 ~101 ~606 minecraft:redstone_wire replace
setblock ~100 ~101 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~101 ~610 ~107 ~101 ~610 minecraft:redstone_wire replace
setblock ~108 ~101 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~101 ~610 ~121 ~101 ~610 minecraft:redstone_wire replace
setblock ~122 ~101 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~101 ~610 ~131 ~101 ~610 minecraft:redstone_wire replace
setblock ~103 ~101 ~611 minecraft:redstone_wire replace
setblock ~106 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~101 ~611 minecraft:redstone_wire replace
setblock ~115 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~101 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~101 ~611 minecraft:redstone_wire replace
setblock ~130 ~101 ~611 minecraft:redstone_wire replace
fill ~105 ~101 ~622 ~122 ~101 ~622 minecraft:redstone_wire replace
setblock ~123 ~101 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~101 ~622 ~136 ~101 ~622 minecraft:redstone_wire replace
setblock ~137 ~101 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~106 ~101 ~623 minecraft:redstone_wire replace
setblock ~112 ~101 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~101 ~623 minecraft:redstone_wire replace
setblock ~121 ~101 ~623 minecraft:redstone_wire replace
setblock ~124 ~101 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~101 ~623 minecraft:redstone_wire replace
setblock ~136 ~101 ~623 minecraft:redstone_wire replace
fill ~102 ~101 ~626 ~114 ~101 ~626 minecraft:redstone_wire replace
setblock ~116 ~101 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~101 ~626 ~131 ~101 ~626 minecraft:redstone_wire replace
setblock ~132 ~101 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~101 ~626 ~134 ~101 ~626 minecraft:redstone_wire replace
setblock ~103 ~101 ~627 minecraft:redstone_wire replace
setblock ~109 ~101 ~627 minecraft:redstone_wire replace
setblock ~112 ~101 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~101 ~627 minecraft:redstone_wire replace
setblock ~124 ~101 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~101 ~627 minecraft:redstone_wire replace
fill ~117 ~101 ~634 ~129 ~101 ~634 minecraft:redstone_wire replace
setblock ~131 ~101 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~101 ~634 ~140 ~101 ~634 minecraft:redstone_wire replace
setblock ~139 ~101 ~635 minecraft:redstone_wire replace
fill ~102 ~101 ~638 ~117 ~101 ~638 minecraft:redstone_wire replace
setblock ~119 ~101 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~101 ~638 ~134 ~101 ~638 minecraft:redstone_wire replace
setblock ~135 ~101 ~638 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~101 ~638 ~137 ~101 ~638 minecraft:redstone_wire replace
setblock ~103 ~101 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~101 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~101 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~101 ~639 minecraft:redstone_wire replace
setblock ~121 ~101 ~639 minecraft:redstone_wire replace
setblock ~124 ~101 ~639 minecraft:redstone_wire replace
setblock ~136 ~101 ~639 minecraft:redstone_wire replace
fill ~126 ~101 ~646 ~132 ~101 ~646 minecraft:redstone_wire replace
setblock ~134 ~101 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~101 ~646 ~149 ~101 ~646 minecraft:redstone_wire replace
setblock ~148 ~101 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~101 ~650 ~86 ~101 ~650 minecraft:redstone_wire replace
setblock ~85 ~101 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~101 ~654 ~126 ~101 ~654 minecraft:redstone_wire replace
setblock ~128 ~101 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~101 ~654 ~143 ~101 ~654 minecraft:redstone_wire replace
setblock ~142 ~101 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~101 ~662 ~129 ~101 ~662 minecraft:redstone_wire replace
setblock ~131 ~101 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~101 ~662 ~146 ~101 ~662 minecraft:redstone_wire replace
setblock ~145 ~101 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~102 ~388 minecraft:redstone_wire replace
setblock ~82 ~102 ~400 minecraft:redstone_wire replace
setblock ~88 ~102 ~588 minecraft:redstone_wire replace
setblock ~79 ~102 ~592 minecraft:redstone_wire replace
setblock ~91 ~102 ~596 minecraft:redstone_wire replace
setblock ~94 ~102 ~600 minecraft:redstone_wire replace
setblock ~97 ~102 ~604 minecraft:redstone_wire replace
setblock ~100 ~102 ~608 minecraft:redstone_wire replace
setblock ~103 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~102 ~612 minecraft:redstone_wire replace
setblock ~109 ~102 ~612 minecraft:redstone_wire replace
setblock ~112 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~102 ~612 minecraft:redstone_wire replace
setblock ~118 ~102 ~612 minecraft:redstone_wire replace
setblock ~121 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~102 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~102 ~624 minecraft:redstone_wire replace
setblock ~115 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~102 ~624 minecraft:redstone_wire replace
setblock ~130 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~102 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~102 ~628 minecraft:redstone_wire replace
setblock ~118 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~102 ~628 minecraft:redstone_wire replace
setblock ~133 ~102 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~102 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~102 ~640 minecraft:redstone_wire replace
setblock ~106 ~102 ~640 minecraft:redstone_wire replace
setblock ~109 ~102 ~640 minecraft:redstone_wire replace
setblock ~115 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~102 ~640 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~102 ~648 minecraft:redstone_wire replace
setblock ~85 ~102 ~652 minecraft:redstone_wire replace
setblock ~142 ~102 ~656 minecraft:redstone_wire replace
setblock ~145 ~102 ~664 minecraft:redstone_wire replace
fill ~126 ~103 ~384 ~126 ~103 ~388 minecraft:redstone_wire replace
fill ~81 ~103 ~396 ~81 ~103 ~400 minecraft:redstone_wire replace
setblock ~87 ~103 ~556 minecraft:redstone_wire replace
setblock ~87 ~103 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~103 ~560 minecraft:redstone_wire replace
fill ~87 ~103 ~560 ~87 ~103 ~572 minecraft:redstone_wire replace
setblock ~78 ~103 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~103 ~564 ~78 ~103 ~576 minecraft:redstone_wire replace
setblock ~90 ~103 ~564 minecraft:redstone_wire replace
setblock ~90 ~103 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~103 ~568 ~90 ~103 ~580 minecraft:redstone_wire replace
setblock ~93 ~103 ~568 minecraft:redstone_wire replace
setblock ~93 ~103 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~103 ~572 ~93 ~103 ~584 minecraft:redstone_wire replace
setblock ~96 ~103 ~572 minecraft:redstone_wire replace
setblock ~87 ~103 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~103 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~103 ~576 ~87 ~103 ~588 minecraft:redstone_wire replace
fill ~96 ~103 ~576 ~96 ~103 ~588 minecraft:redstone_wire replace
setblock ~99 ~103 ~576 minecraft:redstone_wire replace
setblock ~78 ~103 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~103 ~578 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~103 ~580 ~78 ~103 ~592 minecraft:redstone_wire replace
fill ~99 ~103 ~580 ~99 ~103 ~592 minecraft:redstone_wire replace
setblock ~129 ~103 ~580 minecraft:redstone_wire replace
setblock ~129 ~103 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~103 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~103 ~582 ~129 ~103 ~594 minecraft:redstone_wire replace
fill ~90 ~103 ~584 ~90 ~103 ~596 minecraft:redstone_wire replace
setblock ~120 ~103 ~584 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~103 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~103 ~586 ~120 ~103 ~594 minecraft:redstone_wire replace
fill ~93 ~103 ~588 ~93 ~103 ~600 minecraft:redstone_wire replace
setblock ~117 ~103 ~588 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~103 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~103 ~590 ~117 ~103 ~596 minecraft:redstone_wire replace
fill ~96 ~103 ~592 ~96 ~103 ~604 minecraft:redstone_wire replace
fill ~114 ~103 ~592 ~114 ~103 ~594 minecraft:redstone_wire replace
setblock ~99 ~103 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~103 ~596 ~99 ~103 ~608 minecraft:redstone_wire replace
setblock ~111 ~103 ~596 minecraft:redstone_wire replace
setblock ~114 ~103 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~103 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~103 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~103 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~103 ~598 ~114 ~103 ~610 minecraft:redstone_wire replace
setblock ~117 ~103 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~103 ~598 ~120 ~103 ~610 minecraft:redstone_wire replace
fill ~129 ~103 ~598 ~129 ~103 ~610 minecraft:redstone_wire replace
setblock ~108 ~103 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~103 ~600 ~111 ~103 ~612 minecraft:redstone_wire replace
fill ~117 ~103 ~600 ~117 ~103 ~612 minecraft:redstone_wire replace
fill ~108 ~103 ~602 ~108 ~103 ~612 minecraft:redstone_wire replace
fill ~105 ~103 ~604 ~105 ~103 ~610 minecraft:redstone_wire replace
fill ~102 ~103 ~608 ~102 ~103 ~612 minecraft:redstone_wire replace
setblock ~105 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~103 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~103 ~612 ~105 ~103 ~624 minecraft:redstone_wire replace
fill ~114 ~103 ~612 ~114 ~103 ~624 minecraft:redstone_wire replace
fill ~120 ~103 ~612 ~120 ~103 ~624 minecraft:redstone_wire replace
fill ~129 ~103 ~612 ~129 ~103 ~624 minecraft:redstone_wire replace
setblock ~102 ~103 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~103 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~103 ~614 ~102 ~103 ~626 minecraft:redstone_wire replace
fill ~108 ~103 ~614 ~108 ~103 ~626 minecraft:redstone_wire replace
setblock ~111 ~103 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~103 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~103 ~616 ~111 ~103 ~628 minecraft:redstone_wire replace
fill ~117 ~103 ~616 ~117 ~103 ~628 minecraft:redstone_wire replace
setblock ~135 ~103 ~616 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~103 ~618 ~135 ~103 ~624 minecraft:redstone_wire replace
fill ~123 ~103 ~620 ~123 ~103 ~626 minecraft:redstone_wire replace
fill ~132 ~103 ~624 ~132 ~103 ~628 minecraft:redstone_wire replace
setblock ~105 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~103 ~626 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~103 ~627 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~103 ~627 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~103 ~627 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~103 ~628 ~102 ~103 ~640 minecraft:redstone_wire replace
fill ~105 ~103 ~628 ~105 ~103 ~640 minecraft:redstone_wire replace
fill ~108 ~103 ~628 ~108 ~103 ~640 minecraft:redstone_wire replace
fill ~114 ~103 ~628 ~114 ~103 ~640 minecraft:redstone_wire replace
fill ~120 ~103 ~628 ~120 ~103 ~640 minecraft:redstone_wire replace
fill ~123 ~103 ~628 ~123 ~103 ~640 minecraft:redstone_wire replace
fill ~135 ~103 ~628 ~135 ~103 ~640 minecraft:redstone_wire replace
fill ~138 ~103 ~632 ~138 ~103 ~636 minecraft:redstone_wire replace
fill ~147 ~103 ~644 ~147 ~103 ~648 minecraft:redstone_wire replace
fill ~84 ~103 ~648 ~84 ~103 ~652 minecraft:redstone_wire replace
fill ~141 ~103 ~652 ~141 ~103 ~656 minecraft:redstone_wire replace
fill ~144 ~103 ~660 ~144 ~103 ~664 minecraft:redstone_wire replace
setblock ~126 ~104 ~383 minecraft:redstone_wire replace
setblock ~81 ~104 ~395 minecraft:redstone_wire replace
setblock ~87 ~104 ~555 minecraft:redstone_wire replace
setblock ~78 ~104 ~559 minecraft:redstone_wire replace
setblock ~90 ~104 ~563 minecraft:redstone_wire replace
setblock ~93 ~104 ~567 minecraft:redstone_wire replace
setblock ~96 ~104 ~571 minecraft:redstone_wire replace
setblock ~99 ~104 ~575 minecraft:redstone_wire replace
setblock ~129 ~104 ~579 minecraft:redstone_wire replace
setblock ~120 ~104 ~583 minecraft:redstone_wire replace
setblock ~117 ~104 ~587 minecraft:redstone_wire replace
setblock ~114 ~104 ~591 minecraft:redstone_wire replace
setblock ~111 ~104 ~595 minecraft:redstone_wire replace
setblock ~108 ~104 ~599 minecraft:redstone_wire replace
setblock ~105 ~104 ~603 minecraft:redstone_wire replace
setblock ~102 ~104 ~607 minecraft:redstone_wire replace
setblock ~135 ~104 ~615 minecraft:redstone_wire replace
setblock ~123 ~104 ~619 minecraft:redstone_wire replace
setblock ~132 ~104 ~623 minecraft:redstone_wire replace
setblock ~138 ~104 ~631 minecraft:redstone_wire replace
setblock ~147 ~104 ~643 minecraft:redstone_wire replace
setblock ~84 ~104 ~647 minecraft:redstone_wire replace
setblock ~141 ~104 ~651 minecraft:redstone_wire replace
setblock ~144 ~104 ~659 minecraft:redstone_wire replace
setblock ~112 ~105 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~105 ~382 ~116 ~105 ~382 minecraft:redstone_wire replace
setblock ~118 ~105 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~105 ~382 ~126 ~105 ~382 minecraft:redstone_wire replace
setblock ~82 ~105 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~105 ~394 ~83 ~105 ~394 minecraft:redstone_wire replace
setblock ~88 ~105 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~105 ~554 ~89 ~105 ~554 minecraft:redstone_wire replace
setblock ~79 ~105 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~105 ~558 ~80 ~105 ~558 minecraft:redstone_wire replace
setblock ~91 ~105 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~105 ~562 ~92 ~105 ~562 minecraft:redstone_wire replace
setblock ~94 ~105 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~105 ~566 ~95 ~105 ~566 minecraft:redstone_wire replace
setblock ~97 ~105 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~105 ~570 ~98 ~105 ~570 minecraft:redstone_wire replace
setblock ~100 ~105 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~105 ~574 ~101 ~105 ~574 minecraft:redstone_wire replace
setblock ~115 ~105 ~577 minecraft:redstone_wire replace
fill ~114 ~105 ~578 ~116 ~105 ~578 minecraft:redstone_wire replace
setblock ~117 ~105 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~105 ~578 ~129 ~105 ~578 minecraft:redstone_wire replace
setblock ~109 ~105 ~581 minecraft:redstone_wire replace
fill ~108 ~105 ~582 ~120 ~105 ~582 minecraft:redstone_wire replace
setblock ~109 ~105 ~585 minecraft:redstone_wire replace
fill ~108 ~105 ~586 ~117 ~105 ~586 minecraft:redstone_wire replace
setblock ~106 ~105 ~589 minecraft:redstone_wire replace
fill ~105 ~105 ~590 ~114 ~105 ~590 minecraft:redstone_wire replace
setblock ~106 ~105 ~593 minecraft:redstone_wire replace
fill ~105 ~105 ~594 ~111 ~105 ~594 minecraft:redstone_wire replace
setblock ~106 ~105 ~597 minecraft:redstone_wire replace
fill ~105 ~105 ~598 ~108 ~105 ~598 minecraft:redstone_wire replace
setblock ~103 ~105 ~601 minecraft:redstone_wire replace
fill ~102 ~105 ~602 ~105 ~105 ~602 minecraft:redstone_wire replace
setblock ~103 ~105 ~605 minecraft:redstone_wire replace
fill ~102 ~105 ~606 ~104 ~105 ~606 minecraft:redstone_wire replace
setblock ~115 ~105 ~613 minecraft:redstone_wire replace
fill ~114 ~105 ~614 ~119 ~105 ~614 minecraft:redstone_wire replace
setblock ~121 ~105 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~105 ~614 ~135 ~105 ~614 minecraft:redstone_wire replace
setblock ~109 ~105 ~617 minecraft:redstone_wire replace
fill ~108 ~105 ~618 ~114 ~105 ~618 minecraft:redstone_wire replace
