setblock ~160 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~220 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~154 ~472 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~154 ~476 minecraft:redstone_wire replace
setblock ~112 ~154 ~476 minecraft:redstone_wire replace
setblock ~115 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~154 ~476 minecraft:redstone_wire replace
setblock ~124 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~476 minecraft:redstone_wire replace
setblock ~130 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~154 ~476 minecraft:redstone_wire replace
setblock ~136 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~154 ~476 minecraft:redstone_wire replace
setblock ~142 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~154 ~476 minecraft:redstone_wire replace
setblock ~148 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~476 minecraft:redstone_wire replace
setblock ~154 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~154 ~476 minecraft:redstone_wire replace
setblock ~160 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~154 ~476 minecraft:redstone_wire replace
setblock ~169 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~154 ~476 minecraft:redstone_wire replace
setblock ~175 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~476 minecraft:redstone_wire replace
setblock ~181 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~154 ~476 minecraft:redstone_wire replace
setblock ~187 ~154 ~476 minecraft:redstone_wire replace
setblock ~190 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~154 ~476 minecraft:redstone_wire replace
setblock ~199 ~154 ~476 minecraft:redstone_wire replace
setblock ~202 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~154 ~476 minecraft:redstone_wire replace
setblock ~208 ~154 ~476 minecraft:redstone_wire replace
setblock ~211 ~154 ~476 minecraft:redstone_wire replace
setblock ~214 ~154 ~476 minecraft:redstone_wire replace
setblock ~217 ~154 ~476 minecraft:redstone_wire replace
setblock ~220 ~154 ~476 minecraft:redstone_wire replace
setblock ~223 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~154 ~476 minecraft:redstone_wire replace
setblock ~229 ~154 ~476 minecraft:redstone_wire replace
setblock ~232 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~154 ~476 minecraft:redstone_wire replace
setblock ~238 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~154 ~476 minecraft:redstone_wire replace
setblock ~244 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~154 ~476 minecraft:redstone_wire replace
setblock ~250 ~154 ~476 minecraft:redstone_wire replace
setblock ~253 ~154 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~154 ~496 minecraft:redstone_wire replace
setblock ~112 ~154 ~496 minecraft:redstone_wire replace
setblock ~115 ~154 ~496 minecraft:redstone_wire replace
setblock ~118 ~154 ~496 minecraft:redstone_wire replace
setblock ~121 ~154 ~496 minecraft:redstone_wire replace
setblock ~124 ~154 ~496 minecraft:redstone_wire replace
setblock ~127 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~154 ~496 minecraft:redstone_wire replace
setblock ~136 ~154 ~496 minecraft:redstone_wire replace
setblock ~139 ~154 ~496 minecraft:redstone_wire replace
setblock ~142 ~154 ~496 minecraft:redstone_wire replace
setblock ~145 ~154 ~496 minecraft:redstone_wire replace
setblock ~148 ~154 ~496 minecraft:redstone_wire replace
setblock ~151 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~154 ~496 minecraft:redstone_wire replace
setblock ~160 ~154 ~496 minecraft:redstone_wire replace
setblock ~163 ~154 ~496 minecraft:redstone_wire replace
setblock ~166 ~154 ~496 minecraft:redstone_wire replace
setblock ~169 ~154 ~496 minecraft:redstone_wire replace
setblock ~172 ~154 ~496 minecraft:redstone_wire replace
setblock ~175 ~154 ~496 minecraft:redstone_wire replace
setblock ~178 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~154 ~496 minecraft:redstone_wire replace
setblock ~187 ~154 ~496 minecraft:redstone_wire replace
setblock ~190 ~154 ~496 minecraft:redstone_wire replace
setblock ~193 ~154 ~496 minecraft:redstone_wire replace
setblock ~196 ~154 ~496 minecraft:redstone_wire replace
setblock ~199 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~202 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~154 ~496 minecraft:redstone_wire replace
setblock ~208 ~154 ~496 minecraft:redstone_wire replace
setblock ~211 ~154 ~496 minecraft:redstone_wire replace
setblock ~214 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~154 ~496 minecraft:redstone_wire replace
setblock ~220 ~154 ~496 minecraft:redstone_wire replace
setblock ~223 ~154 ~496 minecraft:redstone_wire replace
setblock ~226 ~154 ~496 minecraft:redstone_wire replace
setblock ~229 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~235 ~154 ~496 minecraft:redstone_wire replace
setblock ~238 ~154 ~496 minecraft:redstone_wire replace
setblock ~241 ~154 ~496 minecraft:redstone_wire replace
setblock ~244 ~154 ~496 minecraft:redstone_wire replace
setblock ~247 ~154 ~496 minecraft:redstone_wire replace
setblock ~250 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~154 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~154 ~508 minecraft:redstone_wire replace
setblock ~112 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~154 ~508 minecraft:redstone_wire replace
setblock ~121 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~508 minecraft:redstone_wire replace
setblock ~130 ~154 ~508 minecraft:redstone_wire replace
setblock ~133 ~154 ~508 minecraft:redstone_wire replace
setblock ~136 ~154 ~508 minecraft:redstone_wire replace
setblock ~139 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~154 ~508 minecraft:redstone_wire replace
setblock ~148 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~508 minecraft:redstone_wire replace
setblock ~154 ~154 ~508 minecraft:redstone_wire replace
setblock ~157 ~154 ~508 minecraft:redstone_wire replace
setblock ~160 ~154 ~508 minecraft:redstone_wire replace
setblock ~163 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~154 ~508 minecraft:redstone_wire replace
setblock ~169 ~154 ~508 minecraft:redstone_wire replace
setblock ~172 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~508 minecraft:redstone_wire replace
setblock ~181 ~154 ~508 minecraft:redstone_wire replace
setblock ~184 ~154 ~508 minecraft:redstone_wire replace
setblock ~187 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~154 ~508 minecraft:redstone_wire replace
setblock ~196 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~154 ~508 minecraft:redstone_wire replace
setblock ~202 ~154 ~508 minecraft:redstone_wire replace
setblock ~205 ~154 ~508 minecraft:redstone_wire replace
setblock ~208 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~154 ~508 minecraft:redstone_wire replace
setblock ~217 ~154 ~508 minecraft:redstone_wire replace
setblock ~220 ~154 ~508 minecraft:redstone_wire replace
setblock ~223 ~154 ~508 minecraft:redstone_wire replace
setblock ~226 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~154 ~508 minecraft:redstone_wire replace
setblock ~232 ~154 ~508 minecraft:redstone_wire replace
setblock ~235 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~238 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~241 ~154 ~508 minecraft:redstone_wire replace
setblock ~244 ~154 ~508 minecraft:redstone_wire replace
setblock ~247 ~154 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~154 ~508 minecraft:redstone_wire replace
setblock ~253 ~154 ~508 minecraft:redstone_wire replace
setblock ~109 ~154 ~532 minecraft:redstone_wire replace
setblock ~112 ~154 ~532 minecraft:redstone_wire replace
setblock ~115 ~154 ~532 minecraft:redstone_wire replace
setblock ~118 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~154 ~532 minecraft:redstone_wire replace
setblock ~130 ~154 ~532 minecraft:redstone_wire replace
setblock ~133 ~154 ~532 minecraft:redstone_wire replace
setblock ~136 ~154 ~532 minecraft:redstone_wire replace
setblock ~139 ~154 ~532 minecraft:redstone_wire replace
setblock ~142 ~154 ~532 minecraft:redstone_wire replace
setblock ~145 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~154 ~532 minecraft:redstone_wire replace
setblock ~154 ~154 ~532 minecraft:redstone_wire replace
setblock ~157 ~154 ~532 minecraft:redstone_wire replace
setblock ~160 ~154 ~532 minecraft:redstone_wire replace
setblock ~163 ~154 ~532 minecraft:redstone_wire replace
setblock ~166 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~154 ~532 minecraft:redstone_wire replace
setblock ~181 ~154 ~532 minecraft:redstone_wire replace
setblock ~184 ~154 ~532 minecraft:redstone_wire replace
setblock ~187 ~154 ~532 minecraft:redstone_wire replace
setblock ~190 ~154 ~532 minecraft:redstone_wire replace
setblock ~193 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~196 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~154 ~532 minecraft:redstone_wire replace
setblock ~202 ~154 ~532 minecraft:redstone_wire replace
setblock ~205 ~154 ~532 minecraft:redstone_wire replace
setblock ~208 ~154 ~532 minecraft:redstone_wire replace
setblock ~211 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~154 ~532 minecraft:redstone_wire replace
setblock ~217 ~154 ~532 minecraft:redstone_wire replace
setblock ~220 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~154 ~532 minecraft:redstone_wire replace
setblock ~232 ~154 ~532 minecraft:redstone_wire replace
setblock ~235 ~154 ~532 minecraft:redstone_wire replace
setblock ~238 ~154 ~532 minecraft:redstone_wire replace
setblock ~241 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~154 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~154 ~532 minecraft:redstone_wire replace
setblock ~253 ~154 ~532 minecraft:redstone_wire replace
setblock ~256 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~307 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~313 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~346 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~355 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~358 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~364 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~367 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~370 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~373 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~379 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~382 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~385 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~388 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~391 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~394 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~397 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~400 ~154 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~540 minecraft:redstone_wire replace
setblock ~259 ~154 ~540 minecraft:redstone_wire replace
setblock ~262 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~154 ~540 minecraft:redstone_wire replace
setblock ~271 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~540 minecraft:redstone_wire replace
setblock ~277 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~154 ~540 minecraft:redstone_wire replace
setblock ~283 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~154 ~540 minecraft:redstone_wire replace
setblock ~289 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~154 ~540 minecraft:redstone_wire replace
setblock ~295 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~540 minecraft:redstone_wire replace
setblock ~301 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~154 ~540 minecraft:redstone_wire replace
setblock ~307 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~310 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~313 ~154 ~540 minecraft:redstone_wire replace
setblock ~316 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~154 ~540 minecraft:redstone_wire replace
setblock ~322 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~540 minecraft:redstone_wire replace
setblock ~328 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~154 ~540 minecraft:redstone_wire replace
setblock ~334 ~154 ~540 minecraft:redstone_wire replace
setblock ~337 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~154 ~540 minecraft:redstone_wire replace
setblock ~346 ~154 ~540 minecraft:redstone_wire replace
setblock ~349 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~154 ~540 minecraft:redstone_wire replace
setblock ~355 ~154 ~540 minecraft:redstone_wire replace
setblock ~358 ~154 ~540 minecraft:redstone_wire replace
setblock ~361 ~154 ~540 minecraft:redstone_wire replace
setblock ~364 ~154 ~540 minecraft:redstone_wire replace
setblock ~367 ~154 ~540 minecraft:redstone_wire replace
setblock ~370 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~373 ~154 ~540 minecraft:redstone_wire replace
setblock ~376 ~154 ~540 minecraft:redstone_wire replace
setblock ~379 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~382 ~154 ~540 minecraft:redstone_wire replace
setblock ~385 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~388 ~154 ~540 minecraft:redstone_wire replace
setblock ~391 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~394 ~154 ~540 minecraft:redstone_wire replace
setblock ~397 ~154 ~540 minecraft:redstone_wire replace
setblock ~400 ~154 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~564 minecraft:redstone_wire replace
setblock ~259 ~154 ~564 minecraft:redstone_wire replace
setblock ~262 ~154 ~564 minecraft:redstone_wire replace
setblock ~265 ~154 ~564 minecraft:redstone_wire replace
setblock ~268 ~154 ~564 minecraft:redstone_wire replace
setblock ~271 ~154 ~564 minecraft:redstone_wire replace
setblock ~274 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~277 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~154 ~564 minecraft:redstone_wire replace
setblock ~283 ~154 ~564 minecraft:redstone_wire replace
setblock ~286 ~154 ~564 minecraft:redstone_wire replace
setblock ~289 ~154 ~564 minecraft:redstone_wire replace
setblock ~292 ~154 ~564 minecraft:redstone_wire replace
setblock ~295 ~154 ~564 minecraft:redstone_wire replace
setblock ~298 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~304 ~154 ~564 minecraft:redstone_wire replace
setblock ~307 ~154 ~564 minecraft:redstone_wire replace
setblock ~310 ~154 ~564 minecraft:redstone_wire replace
setblock ~313 ~154 ~564 minecraft:redstone_wire replace
setblock ~316 ~154 ~564 minecraft:redstone_wire replace
setblock ~319 ~154 ~564 minecraft:redstone_wire replace
setblock ~322 ~154 ~564 minecraft:redstone_wire replace
setblock ~325 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~154 ~564 minecraft:redstone_wire replace
setblock ~334 ~154 ~564 minecraft:redstone_wire replace
setblock ~337 ~154 ~564 minecraft:redstone_wire replace
setblock ~340 ~154 ~564 minecraft:redstone_wire replace
setblock ~343 ~154 ~564 minecraft:redstone_wire replace
setblock ~346 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~352 ~154 ~564 minecraft:redstone_wire replace
setblock ~355 ~154 ~564 minecraft:redstone_wire replace
setblock ~358 ~154 ~564 minecraft:redstone_wire replace
setblock ~361 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~364 ~154 ~564 minecraft:redstone_wire replace
setblock ~367 ~154 ~564 minecraft:redstone_wire replace
setblock ~370 ~154 ~564 minecraft:redstone_wire replace
setblock ~373 ~154 ~564 minecraft:redstone_wire replace
setblock ~376 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~379 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~382 ~154 ~564 minecraft:redstone_wire replace
setblock ~385 ~154 ~564 minecraft:redstone_wire replace
setblock ~388 ~154 ~564 minecraft:redstone_wire replace
setblock ~391 ~154 ~564 minecraft:redstone_wire replace
setblock ~394 ~154 ~564 minecraft:redstone_wire replace
setblock ~397 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~400 ~154 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~572 minecraft:redstone_wire replace
setblock ~259 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~154 ~572 minecraft:redstone_wire replace
setblock ~268 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~572 minecraft:redstone_wire replace
setblock ~277 ~154 ~572 minecraft:redstone_wire replace
setblock ~280 ~154 ~572 minecraft:redstone_wire replace
setblock ~283 ~154 ~572 minecraft:redstone_wire replace
setblock ~286 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~289 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~154 ~572 minecraft:redstone_wire replace
setblock ~295 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~572 minecraft:redstone_wire replace
setblock ~301 ~154 ~572 minecraft:redstone_wire replace
setblock ~304 ~154 ~572 minecraft:redstone_wire replace
setblock ~307 ~154 ~572 minecraft:redstone_wire replace
setblock ~310 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~313 ~154 ~572 minecraft:redstone_wire replace
setblock ~316 ~154 ~572 minecraft:redstone_wire replace
setblock ~319 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~572 minecraft:redstone_wire replace
setblock ~328 ~154 ~572 minecraft:redstone_wire replace
setblock ~331 ~154 ~572 minecraft:redstone_wire replace
setblock ~334 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~154 ~572 minecraft:redstone_wire replace
setblock ~343 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~346 ~154 ~572 minecraft:redstone_wire replace
setblock ~349 ~154 ~572 minecraft:redstone_wire replace
setblock ~352 ~154 ~572 minecraft:redstone_wire replace
setblock ~355 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~358 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~154 ~572 minecraft:redstone_wire replace
setblock ~364 ~154 ~572 minecraft:redstone_wire replace
setblock ~367 ~154 ~572 minecraft:redstone_wire replace
setblock ~370 ~154 ~572 minecraft:redstone_wire replace
setblock ~373 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~154 ~572 minecraft:redstone_wire replace
setblock ~379 ~154 ~572 minecraft:redstone_wire replace
setblock ~382 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~385 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~388 ~154 ~572 minecraft:redstone_wire replace
setblock ~391 ~154 ~572 minecraft:redstone_wire replace
setblock ~394 ~154 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~397 ~154 ~572 minecraft:redstone_wire replace
setblock ~400 ~154 ~572 minecraft:redstone_wire replace
setblock ~403 ~154 ~596 minecraft:redstone_wire replace
setblock ~406 ~154 ~596 minecraft:redstone_wire replace
setblock ~409 ~154 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~412 ~154 ~596 minecraft:redstone_wire replace
setblock ~415 ~154 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~418 ~154 ~596 minecraft:redstone_wire replace
setblock ~421 ~154 ~596 minecraft:redstone_wire replace
setblock ~424 ~154 ~596 minecraft:redstone_wire replace
setblock ~403 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~406 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~409 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~412 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~415 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~418 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~421 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~424 ~154 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~154 ~604 minecraft:redstone_wire replace
setblock ~259 ~154 ~604 minecraft:redstone_wire replace
setblock ~262 ~154 ~604 minecraft:redstone_wire replace
setblock ~265 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~268 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~271 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~274 ~154 ~604 minecraft:redstone_wire replace
setblock ~277 ~154 ~604 minecraft:redstone_wire replace
setblock ~280 ~154 ~604 minecraft:redstone_wire replace
setblock ~283 ~154 ~604 minecraft:redstone_wire replace
setblock ~286 ~154 ~604 minecraft:redstone_wire replace
setblock ~289 ~154 ~604 minecraft:redstone_wire replace
setblock ~292 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~295 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~154 ~604 minecraft:redstone_wire replace
setblock ~301 ~154 ~604 minecraft:redstone_wire replace
setblock ~304 ~154 ~604 minecraft:redstone_wire replace
setblock ~307 ~154 ~604 minecraft:redstone_wire replace
setblock ~310 ~154 ~604 minecraft:redstone_wire replace
setblock ~313 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~154 ~604 minecraft:redstone_wire replace
setblock ~328 ~154 ~604 minecraft:redstone_wire replace
setblock ~331 ~154 ~604 minecraft:redstone_wire replace
setblock ~334 ~154 ~604 minecraft:redstone_wire replace
setblock ~337 ~154 ~604 minecraft:redstone_wire replace
setblock ~340 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~343 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~346 ~154 ~604 minecraft:redstone_wire replace
setblock ~349 ~154 ~604 minecraft:redstone_wire replace
setblock ~352 ~154 ~604 minecraft:redstone_wire replace
setblock ~355 ~154 ~604 minecraft:redstone_wire replace
setblock ~358 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~361 ~154 ~604 minecraft:redstone_wire replace
setblock ~364 ~154 ~604 minecraft:redstone_wire replace
setblock ~367 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~370 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~373 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~154 ~604 minecraft:redstone_wire replace
setblock ~379 ~154 ~604 minecraft:redstone_wire replace
setblock ~382 ~154 ~604 minecraft:redstone_wire replace
setblock ~385 ~154 ~604 minecraft:redstone_wire replace
setblock ~388 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~391 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~394 ~154 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~397 ~154 ~604 minecraft:redstone_wire replace
setblock ~400 ~154 ~604 minecraft:redstone_wire replace
setblock ~433 ~154 ~640 minecraft:redstone_wire replace
setblock ~427 ~154 ~648 minecraft:redstone_wire replace
setblock ~430 ~154 ~656 minecraft:redstone_wire replace
fill ~105 ~155 ~228 ~105 ~155 ~232 minecraft:redstone_wire replace
fill ~81 ~155 ~232 ~81 ~155 ~236 minecraft:redstone_wire replace
fill ~102 ~155 ~236 ~102 ~155 ~248 minecraft:redstone_wire replace
setblock ~102 ~155 ~249 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~155 ~250 ~102 ~155 ~262 minecraft:redstone_wire replace
setblock ~102 ~155 ~263 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~155 ~264 ~99 ~155 ~276 minecraft:redstone_wire replace
setblock ~102 ~155 ~264 minecraft:redstone_wire replace
setblock ~99 ~155 ~277 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~155 ~278 ~99 ~155 ~286 minecraft:redstone_wire replace
fill ~96 ~155 ~288 ~96 ~155 ~300 minecraft:redstone_wire replace
setblock ~99 ~155 ~288 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~155 ~301 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~155 ~302 ~96 ~155 ~304 minecraft:redstone_wire replace
fill ~93 ~155 ~304 ~93 ~155 ~316 minecraft:redstone_wire replace
setblock ~93 ~155 ~317 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~155 ~318 ~93 ~155 ~330 minecraft:redstone_wire replace
setblock ~93 ~155 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~155 ~332 ~90 ~155 ~344 minecraft:redstone_wire replace
setblock ~93 ~155 ~332 minecraft:redstone_wire replace
setblock ~90 ~155 ~345 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~155 ~346 ~90 ~155 ~358 minecraft:redstone_wire replace
setblock ~90 ~155 ~359 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~155 ~360 ~90 ~155 ~366 minecraft:redstone_wire replace
fill ~87 ~155 ~368 ~87 ~155 ~380 minecraft:redstone_wire replace
setblock ~90 ~155 ~368 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~155 ~381 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~155 ~382 ~87 ~155 ~394 minecraft:redstone_wire replace
setblock ~87 ~155 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~155 ~396 ~87 ~155 ~400 minecraft:redstone_wire replace
fill ~84 ~155 ~400 ~84 ~155 ~412 minecraft:redstone_wire replace
setblock ~84 ~155 ~413 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~155 ~414 ~84 ~155 ~426 minecraft:redstone_wire replace
setblock ~84 ~155 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~155 ~428 ~84 ~155 ~432 minecraft:redstone_wire replace
fill ~78 ~155 ~444 ~78 ~155 ~448 minecraft:redstone_wire replace
fill ~108 ~155 ~472 ~108 ~155 ~484 minecraft:redstone_wire replace
fill ~111 ~155 ~472 ~111 ~155 ~484 minecraft:redstone_wire replace
fill ~114 ~155 ~472 ~114 ~155 ~484 minecraft:redstone_wire replace
fill ~117 ~155 ~472 ~117 ~155 ~484 minecraft:redstone_wire replace
fill ~120 ~155 ~472 ~120 ~155 ~484 minecraft:redstone_wire replace
fill ~123 ~155 ~472 ~123 ~155 ~484 minecraft:redstone_wire replace
fill ~126 ~155 ~472 ~126 ~155 ~484 minecraft:redstone_wire replace
fill ~129 ~155 ~472 ~129 ~155 ~484 minecraft:redstone_wire replace
fill ~132 ~155 ~472 ~132 ~155 ~484 minecraft:redstone_wire replace
fill ~135 ~155 ~472 ~135 ~155 ~484 minecraft:redstone_wire replace
fill ~138 ~155 ~472 ~138 ~155 ~484 minecraft:redstone_wire replace
fill ~141 ~155 ~472 ~141 ~155 ~484 minecraft:redstone_wire replace
fill ~144 ~155 ~472 ~144 ~155 ~484 minecraft:redstone_wire replace
fill ~147 ~155 ~472 ~147 ~155 ~484 minecraft:redstone_wire replace
fill ~150 ~155 ~472 ~150 ~155 ~484 minecraft:redstone_wire replace
fill ~153 ~155 ~472 ~153 ~155 ~484 minecraft:redstone_wire replace
fill ~156 ~155 ~472 ~156 ~155 ~484 minecraft:redstone_wire replace
fill ~159 ~155 ~472 ~159 ~155 ~484 minecraft:redstone_wire replace
fill ~162 ~155 ~472 ~162 ~155 ~484 minecraft:redstone_wire replace
fill ~165 ~155 ~472 ~165 ~155 ~484 minecraft:redstone_wire replace
fill ~168 ~155 ~472 ~168 ~155 ~484 minecraft:redstone_wire replace
fill ~171 ~155 ~472 ~171 ~155 ~484 minecraft:redstone_wire replace
fill ~174 ~155 ~472 ~174 ~155 ~484 minecraft:redstone_wire replace
fill ~177 ~155 ~472 ~177 ~155 ~484 minecraft:redstone_wire replace
fill ~180 ~155 ~472 ~180 ~155 ~484 minecraft:redstone_wire replace
fill ~183 ~155 ~472 ~183 ~155 ~484 minecraft:redstone_wire replace
fill ~186 ~155 ~472 ~186 ~155 ~484 minecraft:redstone_wire replace
fill ~189 ~155 ~472 ~189 ~155 ~484 minecraft:redstone_wire replace
fill ~192 ~155 ~472 ~192 ~155 ~484 minecraft:redstone_wire replace
fill ~195 ~155 ~472 ~195 ~155 ~484 minecraft:redstone_wire replace
fill ~198 ~155 ~472 ~198 ~155 ~484 minecraft:redstone_wire replace
fill ~201 ~155 ~472 ~201 ~155 ~484 minecraft:redstone_wire replace
fill ~204 ~155 ~472 ~204 ~155 ~484 minecraft:redstone_wire replace
fill ~207 ~155 ~472 ~207 ~155 ~484 minecraft:redstone_wire replace
fill ~210 ~155 ~472 ~210 ~155 ~484 minecraft:redstone_wire replace
fill ~213 ~155 ~472 ~213 ~155 ~484 minecraft:redstone_wire replace
fill ~216 ~155 ~472 ~216 ~155 ~484 minecraft:redstone_wire replace
fill ~219 ~155 ~472 ~219 ~155 ~484 minecraft:redstone_wire replace
fill ~222 ~155 ~472 ~222 ~155 ~484 minecraft:redstone_wire replace
fill ~225 ~155 ~472 ~225 ~155 ~484 minecraft:redstone_wire replace
fill ~228 ~155 ~472 ~228 ~155 ~484 minecraft:redstone_wire replace
fill ~231 ~155 ~472 ~231 ~155 ~484 minecraft:redstone_wire replace
fill ~234 ~155 ~472 ~234 ~155 ~484 minecraft:redstone_wire replace
fill ~237 ~155 ~472 ~237 ~155 ~484 minecraft:redstone_wire replace
fill ~240 ~155 ~472 ~240 ~155 ~484 minecraft:redstone_wire replace
fill ~243 ~155 ~472 ~243 ~155 ~484 minecraft:redstone_wire replace
fill ~246 ~155 ~472 ~246 ~155 ~484 minecraft:redstone_wire replace
fill ~249 ~155 ~472 ~249 ~155 ~484 minecraft:redstone_wire replace
fill ~252 ~155 ~472 ~252 ~155 ~484 minecraft:redstone_wire replace
setblock ~108 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~111 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~117 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~126 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~129 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~132 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~135 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~138 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~141 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~144 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~147 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~150 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~153 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~156 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~159 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~162 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~171 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~174 ~155 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
