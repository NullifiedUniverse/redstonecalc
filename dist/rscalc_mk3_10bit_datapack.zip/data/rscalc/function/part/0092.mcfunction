setblock ~130 ~149 ~435 minecraft:redstone_wire replace
setblock ~133 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~149 ~435 minecraft:redstone_wire replace
setblock ~157 ~149 ~435 minecraft:redstone_wire replace
setblock ~160 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~175 ~149 ~435 minecraft:redstone_wire replace
setblock ~178 ~149 ~435 minecraft:redstone_wire replace
setblock ~181 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~190 ~149 ~435 minecraft:redstone_wire replace
setblock ~193 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~202 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~205 ~149 ~435 minecraft:redstone_wire replace
setblock ~208 ~149 ~435 minecraft:redstone_wire replace
setblock ~211 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~217 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~220 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~149 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~226 ~149 ~435 minecraft:redstone_wire replace
setblock ~229 ~149 ~435 minecraft:redstone_wire replace
fill ~84 ~149 ~446 ~98 ~149 ~446 minecraft:redstone_wire replace
setblock ~99 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~100 ~149 ~446 ~112 ~149 ~446 minecraft:redstone_wire replace
setblock ~113 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~114 ~149 ~446 ~127 ~149 ~446 minecraft:redstone_wire replace
setblock ~128 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~129 ~149 ~446 ~142 ~149 ~446 minecraft:redstone_wire replace
setblock ~143 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~149 ~446 ~157 ~149 ~446 minecraft:redstone_wire replace
setblock ~158 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~149 ~446 ~172 ~149 ~446 minecraft:redstone_wire replace
setblock ~173 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~174 ~149 ~446 ~187 ~149 ~446 minecraft:redstone_wire replace
setblock ~188 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~149 ~446 ~202 ~149 ~446 minecraft:redstone_wire replace
setblock ~203 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~149 ~446 ~217 ~149 ~446 minecraft:redstone_wire replace
setblock ~218 ~149 ~446 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~219 ~149 ~446 ~230 ~149 ~446 minecraft:redstone_wire replace
setblock ~85 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~447 minecraft:redstone_wire replace
setblock ~91 ~149 ~447 minecraft:redstone_wire replace
setblock ~94 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~149 ~447 minecraft:redstone_wire replace
setblock ~100 ~149 ~447 minecraft:redstone_wire replace
setblock ~103 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~149 ~447 minecraft:redstone_wire replace
setblock ~118 ~149 ~447 minecraft:redstone_wire replace
setblock ~121 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~149 ~447 minecraft:redstone_wire replace
setblock ~127 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~149 ~447 minecraft:redstone_wire replace
setblock ~142 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~149 ~447 minecraft:redstone_wire replace
setblock ~151 ~149 ~447 minecraft:redstone_wire replace
setblock ~154 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~447 minecraft:redstone_wire replace
setblock ~166 ~149 ~447 minecraft:redstone_wire replace
setblock ~169 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~172 ~149 ~447 minecraft:redstone_wire replace
setblock ~175 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~447 minecraft:redstone_wire replace
setblock ~187 ~149 ~447 minecraft:redstone_wire replace
setblock ~190 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~202 ~149 ~447 minecraft:redstone_wire replace
setblock ~205 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~208 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~211 ~149 ~447 minecraft:redstone_wire replace
setblock ~214 ~149 ~447 minecraft:redstone_wire replace
setblock ~217 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~220 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~223 ~149 ~447 minecraft:redstone_wire replace
setblock ~226 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~149 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~149 ~450 ~80 ~149 ~450 minecraft:redstone_wire replace
setblock ~79 ~149 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~149 ~474 ~104 ~149 ~474 minecraft:redstone_wire replace
setblock ~105 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~149 ~474 ~118 ~149 ~474 minecraft:redstone_wire replace
setblock ~119 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~149 ~474 ~133 ~149 ~474 minecraft:redstone_wire replace
setblock ~134 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~474 ~148 ~149 ~474 minecraft:redstone_wire replace
setblock ~149 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~149 ~474 ~163 ~149 ~474 minecraft:redstone_wire replace
setblock ~164 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~149 ~474 ~178 ~149 ~474 minecraft:redstone_wire replace
setblock ~179 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~180 ~149 ~474 ~193 ~149 ~474 minecraft:redstone_wire replace
setblock ~194 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~149 ~474 ~208 ~149 ~474 minecraft:redstone_wire replace
setblock ~209 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~149 ~474 ~223 ~149 ~474 minecraft:redstone_wire replace
setblock ~224 ~149 ~474 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~149 ~474 ~230 ~149 ~474 minecraft:redstone_wire replace
setblock ~85 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~149 ~475 minecraft:redstone_wire replace
setblock ~97 ~149 ~475 minecraft:redstone_wire replace
setblock ~100 ~149 ~475 minecraft:redstone_wire replace
setblock ~103 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~149 ~475 minecraft:redstone_wire replace
setblock ~124 ~149 ~475 minecraft:redstone_wire replace
setblock ~127 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~149 ~475 minecraft:redstone_wire replace
setblock ~145 ~149 ~475 minecraft:redstone_wire replace
setblock ~148 ~149 ~475 minecraft:redstone_wire replace
setblock ~151 ~149 ~475 minecraft:redstone_wire replace
setblock ~154 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~149 ~475 minecraft:redstone_wire replace
setblock ~172 ~149 ~475 minecraft:redstone_wire replace
setblock ~175 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~181 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~149 ~475 minecraft:redstone_wire replace
setblock ~190 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~475 minecraft:redstone_wire replace
setblock ~199 ~149 ~475 minecraft:redstone_wire replace
setblock ~202 ~149 ~475 minecraft:redstone_wire replace
setblock ~205 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~208 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~211 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~217 ~149 ~475 minecraft:redstone_wire replace
setblock ~220 ~149 ~475 minecraft:redstone_wire replace
setblock ~223 ~149 ~475 minecraft:redstone_wire replace
setblock ~226 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~149 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~149 ~482 ~105 ~149 ~482 minecraft:redstone_wire replace
setblock ~107 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~149 ~482 ~122 ~149 ~482 minecraft:redstone_wire replace
setblock ~124 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~149 ~482 ~139 ~149 ~482 minecraft:redstone_wire replace
setblock ~141 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~143 ~149 ~482 ~156 ~149 ~482 minecraft:redstone_wire replace
setblock ~158 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~149 ~482 ~173 ~149 ~482 minecraft:redstone_wire replace
setblock ~175 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~149 ~482 ~190 ~149 ~482 minecraft:redstone_wire replace
setblock ~192 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~194 ~149 ~482 ~207 ~149 ~482 minecraft:redstone_wire replace
setblock ~209 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~211 ~149 ~482 ~224 ~149 ~482 minecraft:redstone_wire replace
setblock ~226 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~228 ~149 ~482 ~241 ~149 ~482 minecraft:redstone_wire replace
setblock ~243 ~149 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~245 ~149 ~482 ~248 ~149 ~482 minecraft:redstone_wire replace
setblock ~235 ~149 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~149 ~502 ~117 ~149 ~502 minecraft:redstone_wire replace
setblock ~119 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~149 ~502 ~134 ~149 ~502 minecraft:redstone_wire replace
setblock ~136 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~138 ~149 ~502 ~151 ~149 ~502 minecraft:redstone_wire replace
setblock ~153 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~155 ~149 ~502 ~168 ~149 ~502 minecraft:redstone_wire replace
setblock ~170 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~172 ~149 ~502 ~185 ~149 ~502 minecraft:redstone_wire replace
setblock ~187 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~189 ~149 ~502 ~202 ~149 ~502 minecraft:redstone_wire replace
setblock ~204 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~206 ~149 ~502 ~219 ~149 ~502 minecraft:redstone_wire replace
setblock ~221 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~149 ~502 ~236 ~149 ~502 minecraft:redstone_wire replace
setblock ~238 ~149 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~149 ~502 ~248 ~149 ~502 minecraft:redstone_wire replace
setblock ~241 ~149 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~149 ~514 ~114 ~149 ~514 minecraft:redstone_wire replace
setblock ~116 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~149 ~514 ~131 ~149 ~514 minecraft:redstone_wire replace
setblock ~133 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~514 ~148 ~149 ~514 minecraft:redstone_wire replace
setblock ~150 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~152 ~149 ~514 ~165 ~149 ~514 minecraft:redstone_wire replace
setblock ~167 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~149 ~514 ~182 ~149 ~514 minecraft:redstone_wire replace
setblock ~184 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~149 ~514 ~199 ~149 ~514 minecraft:redstone_wire replace
setblock ~201 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~203 ~149 ~514 ~216 ~149 ~514 minecraft:redstone_wire replace
setblock ~218 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~149 ~514 ~233 ~149 ~514 minecraft:redstone_wire replace
setblock ~235 ~149 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~149 ~514 ~248 ~149 ~514 minecraft:redstone_wire replace
setblock ~238 ~149 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~149 ~538 ~114 ~149 ~538 minecraft:redstone_wire replace
setblock ~116 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~149 ~538 ~131 ~149 ~538 minecraft:redstone_wire replace
setblock ~133 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~538 ~148 ~149 ~538 minecraft:redstone_wire replace
setblock ~150 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~152 ~149 ~538 ~165 ~149 ~538 minecraft:redstone_wire replace
setblock ~167 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~169 ~149 ~538 ~182 ~149 ~538 minecraft:redstone_wire replace
setblock ~184 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~186 ~149 ~538 ~199 ~149 ~538 minecraft:redstone_wire replace
setblock ~201 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~203 ~149 ~538 ~216 ~149 ~538 minecraft:redstone_wire replace
setblock ~218 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~220 ~149 ~538 ~233 ~149 ~538 minecraft:redstone_wire replace
setblock ~235 ~149 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~237 ~149 ~538 ~248 ~149 ~538 minecraft:redstone_wire replace
setblock ~244 ~149 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~247 ~149 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~149 ~546 ~120 ~149 ~546 minecraft:redstone_wire replace
setblock ~122 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~149 ~546 ~137 ~149 ~546 minecraft:redstone_wire replace
setblock ~139 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~149 ~546 ~154 ~149 ~546 minecraft:redstone_wire replace
setblock ~156 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~158 ~149 ~546 ~171 ~149 ~546 minecraft:redstone_wire replace
setblock ~173 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~175 ~149 ~546 ~188 ~149 ~546 minecraft:redstone_wire replace
setblock ~190 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~192 ~149 ~546 ~205 ~149 ~546 minecraft:redstone_wire replace
setblock ~207 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~209 ~149 ~546 ~222 ~149 ~546 minecraft:redstone_wire replace
setblock ~224 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~226 ~149 ~546 ~239 ~149 ~546 minecraft:redstone_wire replace
setblock ~241 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~243 ~149 ~546 ~256 ~149 ~546 minecraft:redstone_wire replace
setblock ~257 ~149 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~247 ~149 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~250 ~149 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~149 ~570 ~123 ~149 ~570 minecraft:redstone_wire replace
setblock ~125 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~149 ~570 ~140 ~149 ~570 minecraft:redstone_wire replace
setblock ~142 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~149 ~570 ~157 ~149 ~570 minecraft:redstone_wire replace
setblock ~159 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~161 ~149 ~570 ~174 ~149 ~570 minecraft:redstone_wire replace
setblock ~176 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~149 ~570 ~191 ~149 ~570 minecraft:redstone_wire replace
setblock ~193 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~149 ~570 ~208 ~149 ~570 minecraft:redstone_wire replace
setblock ~210 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~212 ~149 ~570 ~225 ~149 ~570 minecraft:redstone_wire replace
setblock ~227 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~149 ~570 ~242 ~149 ~570 minecraft:redstone_wire replace
setblock ~244 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~246 ~149 ~570 ~259 ~149 ~570 minecraft:redstone_wire replace
setblock ~260 ~149 ~570 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~247 ~149 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~259 ~149 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~149 ~578 ~126 ~149 ~578 minecraft:redstone_wire replace
setblock ~128 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~149 ~578 ~143 ~149 ~578 minecraft:redstone_wire replace
setblock ~145 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~149 ~578 ~160 ~149 ~578 minecraft:redstone_wire replace
setblock ~162 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~164 ~149 ~578 ~177 ~149 ~578 minecraft:redstone_wire replace
setblock ~179 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~181 ~149 ~578 ~194 ~149 ~578 minecraft:redstone_wire replace
setblock ~196 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~198 ~149 ~578 ~211 ~149 ~578 minecraft:redstone_wire replace
setblock ~213 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~215 ~149 ~578 ~228 ~149 ~578 minecraft:redstone_wire replace
setblock ~230 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~149 ~578 ~245 ~149 ~578 minecraft:redstone_wire replace
setblock ~246 ~149 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~247 ~149 ~578 ~257 ~149 ~578 minecraft:redstone_wire replace
setblock ~247 ~149 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~253 ~149 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~149 ~606 ~132 ~149 ~606 minecraft:redstone_wire replace
setblock ~134 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~149 ~606 ~149 ~149 ~606 minecraft:redstone_wire replace
setblock ~151 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~149 ~606 ~166 ~149 ~606 minecraft:redstone_wire replace
setblock ~168 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~170 ~149 ~606 ~183 ~149 ~606 minecraft:redstone_wire replace
setblock ~185 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~149 ~606 ~200 ~149 ~606 minecraft:redstone_wire replace
setblock ~202 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~149 ~606 ~217 ~149 ~606 minecraft:redstone_wire replace
setblock ~219 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~149 ~606 ~234 ~149 ~606 minecraft:redstone_wire replace
setblock ~236 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~149 ~606 ~251 ~149 ~606 minecraft:redstone_wire replace
setblock ~253 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~149 ~606 ~268 ~149 ~606 minecraft:redstone_wire replace
setblock ~269 ~149 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~247 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~265 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~268 ~149 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~149 ~610 ~129 ~149 ~610 minecraft:redstone_wire replace
setblock ~131 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~149 ~610 ~146 ~149 ~610 minecraft:redstone_wire replace
setblock ~148 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~149 ~610 ~163 ~149 ~610 minecraft:redstone_wire replace
setblock ~165 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~167 ~149 ~610 ~180 ~149 ~610 minecraft:redstone_wire replace
setblock ~182 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~184 ~149 ~610 ~197 ~149 ~610 minecraft:redstone_wire replace
setblock ~199 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~201 ~149 ~610 ~214 ~149 ~610 minecraft:redstone_wire replace
setblock ~216 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~218 ~149 ~610 ~231 ~149 ~610 minecraft:redstone_wire replace
setblock ~233 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~149 ~610 ~248 ~149 ~610 minecraft:redstone_wire replace
setblock ~250 ~149 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~149 ~610 ~263 ~149 ~610 minecraft:redstone_wire replace
setblock ~247 ~149 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~256 ~149 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~262 ~149 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~149 ~646 ~138 ~149 ~646 minecraft:redstone_wire replace
setblock ~140 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~149 ~646 ~155 ~149 ~646 minecraft:redstone_wire replace
setblock ~157 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~149 ~646 ~172 ~149 ~646 minecraft:redstone_wire replace
setblock ~174 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~176 ~149 ~646 ~189 ~149 ~646 minecraft:redstone_wire replace
setblock ~191 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~193 ~149 ~646 ~206 ~149 ~646 minecraft:redstone_wire replace
setblock ~208 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~149 ~646 ~223 ~149 ~646 minecraft:redstone_wire replace
setblock ~225 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~227 ~149 ~646 ~240 ~149 ~646 minecraft:redstone_wire replace
setblock ~242 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~244 ~149 ~646 ~257 ~149 ~646 minecraft:redstone_wire replace
setblock ~259 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~261 ~149 ~646 ~274 ~149 ~646 minecraft:redstone_wire replace
setblock ~275 ~149 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~276 ~149 ~646 ~278 ~149 ~646 minecraft:redstone_wire replace
setblock ~277 ~149 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~149 ~650 ~89 ~149 ~650 minecraft:redstone_wire replace
setblock ~90 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~91 ~149 ~650 ~103 ~149 ~650 minecraft:redstone_wire replace
setblock ~104 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~105 ~149 ~650 ~118 ~149 ~650 minecraft:redstone_wire replace
setblock ~119 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~149 ~650 ~133 ~149 ~650 minecraft:redstone_wire replace
setblock ~134 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~135 ~149 ~650 ~148 ~149 ~650 minecraft:redstone_wire replace
setblock ~149 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~149 ~650 ~163 ~149 ~650 minecraft:redstone_wire replace
setblock ~164 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~149 ~650 ~178 ~149 ~650 minecraft:redstone_wire replace
setblock ~179 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~180 ~149 ~650 ~193 ~149 ~650 minecraft:redstone_wire replace
setblock ~194 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~149 ~650 ~208 ~149 ~650 minecraft:redstone_wire replace
setblock ~209 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~149 ~650 ~223 ~149 ~650 minecraft:redstone_wire replace
setblock ~224 ~149 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~225 ~149 ~650 ~230 ~149 ~650 minecraft:redstone_wire replace
setblock ~85 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~88 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~91 ~149 ~651 minecraft:redstone_wire replace
setblock ~94 ~149 ~651 minecraft:redstone_wire replace
setblock ~97 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~149 ~651 minecraft:redstone_wire replace
setblock ~103 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~149 ~651 minecraft:redstone_wire replace
setblock ~109 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~149 ~651 minecraft:redstone_wire replace
setblock ~115 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~149 ~651 minecraft:redstone_wire replace
setblock ~121 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~149 ~651 minecraft:redstone_wire replace
setblock ~127 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~149 ~651 minecraft:redstone_wire replace
setblock ~133 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~149 ~651 minecraft:redstone_wire replace
setblock ~139 ~149 ~651 minecraft:redstone_wire replace
setblock ~142 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~149 ~651 minecraft:redstone_wire replace
setblock ~148 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~149 ~651 minecraft:redstone_wire replace
setblock ~154 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~149 ~651 minecraft:redstone_wire replace
setblock ~160 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~166 ~149 ~651 minecraft:redstone_wire replace
setblock ~169 ~149 ~651 minecraft:redstone_wire replace
setblock ~172 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~175 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~178 ~149 ~651 minecraft:redstone_wire replace
setblock ~181 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~184 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~190 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~193 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~196 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~149 ~651 minecraft:redstone_wire replace
setblock ~202 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~205 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~208 ~149 ~651 minecraft:redstone_wire replace
setblock ~211 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~214 ~149 ~651 minecraft:redstone_wire replace
setblock ~217 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~220 ~149 ~651 minecraft:redstone_wire replace
setblock ~223 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~226 ~149 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~229 ~149 ~651 minecraft:redstone_wire replace
fill ~126 ~149 ~654 ~132 ~149 ~654 minecraft:redstone_wire replace
setblock ~134 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~149 ~654 ~149 ~149 ~654 minecraft:redstone_wire replace
setblock ~151 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~149 ~654 ~166 ~149 ~654 minecraft:redstone_wire replace
setblock ~168 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~170 ~149 ~654 ~183 ~149 ~654 minecraft:redstone_wire replace
setblock ~185 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~149 ~654 ~200 ~149 ~654 minecraft:redstone_wire replace
setblock ~202 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~204 ~149 ~654 ~217 ~149 ~654 minecraft:redstone_wire replace
setblock ~219 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~221 ~149 ~654 ~234 ~149 ~654 minecraft:redstone_wire replace
setblock ~236 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~238 ~149 ~654 ~251 ~149 ~654 minecraft:redstone_wire replace
setblock ~253 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~149 ~654 ~268 ~149 ~654 minecraft:redstone_wire replace
setblock ~269 ~149 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~270 ~149 ~654 ~272 ~149 ~654 minecraft:redstone_wire replace
setblock ~271 ~149 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~149 ~662 ~135 ~149 ~662 minecraft:redstone_wire replace
setblock ~137 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~149 ~662 ~152 ~149 ~662 minecraft:redstone_wire replace
setblock ~154 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~149 ~662 ~169 ~149 ~662 minecraft:redstone_wire replace
setblock ~171 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~173 ~149 ~662 ~186 ~149 ~662 minecraft:redstone_wire replace
setblock ~188 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~190 ~149 ~662 ~203 ~149 ~662 minecraft:redstone_wire replace
setblock ~205 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~207 ~149 ~662 ~220 ~149 ~662 minecraft:redstone_wire replace
setblock ~222 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~224 ~149 ~662 ~237 ~149 ~662 minecraft:redstone_wire replace
setblock ~239 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~241 ~149 ~662 ~254 ~149 ~662 minecraft:redstone_wire replace
setblock ~256 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~258 ~149 ~662 ~271 ~149 ~662 minecraft:redstone_wire replace
setblock ~272 ~149 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~273 ~149 ~662 ~275 ~149 ~662 minecraft:redstone_wire replace
setblock ~274 ~149 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~232 ~150 ~388 minecraft:redstone_wire replace
setblock ~82 ~150 ~400 minecraft:redstone_wire replace
setblock ~85 ~150 ~436 minecraft:redstone_wire replace
setblock ~88 ~150 ~436 minecraft:redstone_wire replace
setblock ~91 ~150 ~436 minecraft:redstone_wire replace
setblock ~94 ~150 ~436 minecraft:redstone_wire replace
setblock ~97 ~150 ~436 minecraft:redstone_wire replace
setblock ~100 ~150 ~436 minecraft:redstone_wire replace
setblock ~103 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~150 ~436 minecraft:redstone_wire replace
setblock ~112 ~150 ~436 minecraft:redstone_wire replace
setblock ~115 ~150 ~436 minecraft:redstone_wire replace
setblock ~118 ~150 ~436 minecraft:redstone_wire replace
setblock ~121 ~150 ~436 minecraft:redstone_wire replace
setblock ~124 ~150 ~436 minecraft:redstone_wire replace
setblock ~127 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~150 ~436 minecraft:redstone_wire replace
setblock ~136 ~150 ~436 minecraft:redstone_wire replace
setblock ~139 ~150 ~436 minecraft:redstone_wire replace
setblock ~142 ~150 ~436 minecraft:redstone_wire replace
setblock ~145 ~150 ~436 minecraft:redstone_wire replace
setblock ~148 ~150 ~436 minecraft:redstone_wire replace
setblock ~151 ~150 ~436 minecraft:redstone_wire replace
setblock ~154 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~150 ~436 minecraft:redstone_wire replace
setblock ~163 ~150 ~436 minecraft:redstone_wire replace
setblock ~166 ~150 ~436 minecraft:redstone_wire replace
setblock ~169 ~150 ~436 minecraft:redstone_wire replace
setblock ~172 ~150 ~436 minecraft:redstone_wire replace
setblock ~175 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~150 ~436 minecraft:redstone_wire replace
setblock ~184 ~150 ~436 minecraft:redstone_wire replace
setblock ~187 ~150 ~436 minecraft:redstone_wire replace
setblock ~190 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~193 ~150 ~436 minecraft:redstone_wire replace
setblock ~196 ~150 ~436 minecraft:redstone_wire replace
setblock ~199 ~150 ~436 minecraft:redstone_wire replace
setblock ~202 ~150 ~436 minecraft:redstone_wire replace
setblock ~205 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~150 ~436 minecraft:redstone_wire replace
setblock ~214 ~150 ~436 minecraft:redstone_wire replace
setblock ~217 ~150 ~436 minecraft:redstone_wire replace
setblock ~220 ~150 ~436 minecraft:redstone_wire replace
setblock ~223 ~150 ~436 minecraft:redstone_wire replace
setblock ~226 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~229 ~150 ~436 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~150 ~448 minecraft:redstone_wire replace
setblock ~88 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~150 ~448 minecraft:redstone_wire replace
setblock ~97 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~150 ~448 minecraft:redstone_wire replace
setblock ~106 ~150 ~448 minecraft:redstone_wire replace
setblock ~109 ~150 ~448 minecraft:redstone_wire replace
setblock ~112 ~150 ~448 minecraft:redstone_wire replace
setblock ~115 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~150 ~448 minecraft:redstone_wire replace
setblock ~124 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~150 ~448 minecraft:redstone_wire replace
setblock ~130 ~150 ~448 minecraft:redstone_wire replace
setblock ~133 ~150 ~448 minecraft:redstone_wire replace
setblock ~136 ~150 ~448 minecraft:redstone_wire replace
setblock ~139 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~150 ~448 minecraft:redstone_wire replace
setblock ~145 ~150 ~448 minecraft:redstone_wire replace
setblock ~148 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~150 ~448 minecraft:redstone_wire replace
setblock ~157 ~150 ~448 minecraft:redstone_wire replace
setblock ~160 ~150 ~448 minecraft:redstone_wire replace
setblock ~163 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~150 ~448 minecraft:redstone_wire replace
setblock ~172 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~150 ~448 minecraft:redstone_wire replace
setblock ~178 ~150 ~448 minecraft:redstone_wire replace
setblock ~181 ~150 ~448 minecraft:redstone_wire replace
setblock ~184 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~150 ~448 minecraft:redstone_wire replace
setblock ~193 ~150 ~448 minecraft:redstone_wire replace
setblock ~196 ~150 ~448 minecraft:redstone_wire replace
setblock ~199 ~150 ~448 minecraft:redstone_wire replace
setblock ~202 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~150 ~448 minecraft:redstone_wire replace
setblock ~208 ~150 ~448 minecraft:redstone_wire replace
setblock ~211 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~214 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~217 ~150 ~448 minecraft:redstone_wire replace
setblock ~220 ~150 ~448 minecraft:redstone_wire replace
setblock ~223 ~150 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~150 ~448 minecraft:redstone_wire replace
setblock ~229 ~150 ~448 minecraft:redstone_wire replace
setblock ~79 ~150 ~452 minecraft:redstone_wire replace
setblock ~85 ~150 ~476 minecraft:redstone_wire replace
setblock ~88 ~150 ~476 minecraft:redstone_wire replace
setblock ~91 ~150 ~476 minecraft:redstone_wire replace
setblock ~94 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~150 ~476 minecraft:redstone_wire replace
setblock ~106 ~150 ~476 minecraft:redstone_wire replace
setblock ~109 ~150 ~476 minecraft:redstone_wire replace
setblock ~112 ~150 ~476 minecraft:redstone_wire replace
setblock ~115 ~150 ~476 minecraft:redstone_wire replace
setblock ~118 ~150 ~476 minecraft:redstone_wire replace
setblock ~121 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~150 ~476 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~150 ~476 minecraft:redstone_wire replace
