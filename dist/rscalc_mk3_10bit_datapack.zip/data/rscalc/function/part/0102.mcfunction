setblock ~309 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~612 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~612 ~402 ~155 ~624 minecraft:redstone_wire replace
fill ~405 ~155 ~612 ~405 ~155 ~624 minecraft:redstone_wire replace
fill ~408 ~155 ~612 ~408 ~155 ~624 minecraft:redstone_wire replace
fill ~411 ~155 ~612 ~411 ~155 ~624 minecraft:redstone_wire replace
fill ~414 ~155 ~612 ~414 ~155 ~624 minecraft:redstone_wire replace
fill ~417 ~155 ~612 ~417 ~155 ~624 minecraft:redstone_wire replace
fill ~420 ~155 ~612 ~420 ~155 ~624 minecraft:redstone_wire replace
fill ~423 ~155 ~612 ~423 ~155 ~624 minecraft:redstone_wire replace
fill ~168 ~155 ~614 ~168 ~155 ~616 minecraft:redstone_wire replace
fill ~171 ~155 ~614 ~171 ~155 ~620 minecraft:redstone_wire replace
fill ~174 ~155 ~614 ~174 ~155 ~622 minecraft:redstone_wire replace
fill ~177 ~155 ~614 ~177 ~155 ~626 minecraft:redstone_wire replace
fill ~180 ~155 ~614 ~180 ~155 ~626 minecraft:redstone_wire replace
fill ~183 ~155 ~614 ~183 ~155 ~626 minecraft:redstone_wire replace
fill ~186 ~155 ~614 ~186 ~155 ~626 minecraft:redstone_wire replace
fill ~189 ~155 ~614 ~189 ~155 ~626 minecraft:redstone_wire replace
fill ~192 ~155 ~614 ~192 ~155 ~626 minecraft:redstone_wire replace
fill ~195 ~155 ~614 ~195 ~155 ~626 minecraft:redstone_wire replace
fill ~198 ~155 ~614 ~198 ~155 ~626 minecraft:redstone_wire replace
fill ~201 ~155 ~614 ~201 ~155 ~626 minecraft:redstone_wire replace
fill ~204 ~155 ~614 ~204 ~155 ~626 minecraft:redstone_wire replace
fill ~207 ~155 ~614 ~207 ~155 ~626 minecraft:redstone_wire replace
fill ~210 ~155 ~614 ~210 ~155 ~626 minecraft:redstone_wire replace
fill ~213 ~155 ~614 ~213 ~155 ~626 minecraft:redstone_wire replace
fill ~216 ~155 ~614 ~216 ~155 ~626 minecraft:redstone_wire replace
fill ~219 ~155 ~614 ~219 ~155 ~626 minecraft:redstone_wire replace
fill ~222 ~155 ~614 ~222 ~155 ~626 minecraft:redstone_wire replace
fill ~225 ~155 ~614 ~225 ~155 ~626 minecraft:redstone_wire replace
fill ~228 ~155 ~614 ~228 ~155 ~626 minecraft:redstone_wire replace
fill ~231 ~155 ~614 ~231 ~155 ~626 minecraft:redstone_wire replace
fill ~234 ~155 ~614 ~234 ~155 ~626 minecraft:redstone_wire replace
fill ~237 ~155 ~614 ~237 ~155 ~626 minecraft:redstone_wire replace
fill ~240 ~155 ~614 ~240 ~155 ~626 minecraft:redstone_wire replace
fill ~243 ~155 ~614 ~243 ~155 ~626 minecraft:redstone_wire replace
fill ~246 ~155 ~614 ~246 ~155 ~626 minecraft:redstone_wire replace
fill ~249 ~155 ~614 ~249 ~155 ~626 minecraft:redstone_wire replace
fill ~252 ~155 ~614 ~252 ~155 ~626 minecraft:redstone_wire replace
fill ~255 ~155 ~614 ~255 ~155 ~626 minecraft:redstone_wire replace
fill ~258 ~155 ~614 ~258 ~155 ~626 minecraft:redstone_wire replace
fill ~261 ~155 ~614 ~261 ~155 ~626 minecraft:redstone_wire replace
fill ~264 ~155 ~614 ~264 ~155 ~626 minecraft:redstone_wire replace
fill ~267 ~155 ~614 ~267 ~155 ~626 minecraft:redstone_wire replace
fill ~270 ~155 ~614 ~270 ~155 ~626 minecraft:redstone_wire replace
fill ~273 ~155 ~614 ~273 ~155 ~626 minecraft:redstone_wire replace
fill ~276 ~155 ~614 ~276 ~155 ~626 minecraft:redstone_wire replace
fill ~279 ~155 ~614 ~279 ~155 ~626 minecraft:redstone_wire replace
fill ~282 ~155 ~614 ~282 ~155 ~626 minecraft:redstone_wire replace
fill ~285 ~155 ~614 ~285 ~155 ~626 minecraft:redstone_wire replace
fill ~288 ~155 ~614 ~288 ~155 ~626 minecraft:redstone_wire replace
fill ~291 ~155 ~614 ~291 ~155 ~626 minecraft:redstone_wire replace
fill ~294 ~155 ~614 ~294 ~155 ~626 minecraft:redstone_wire replace
fill ~297 ~155 ~614 ~297 ~155 ~626 minecraft:redstone_wire replace
fill ~300 ~155 ~614 ~300 ~155 ~626 minecraft:redstone_wire replace
fill ~303 ~155 ~614 ~303 ~155 ~626 minecraft:redstone_wire replace
fill ~306 ~155 ~614 ~306 ~155 ~626 minecraft:redstone_wire replace
fill ~309 ~155 ~614 ~309 ~155 ~626 minecraft:redstone_wire replace
fill ~312 ~155 ~614 ~312 ~155 ~626 minecraft:redstone_wire replace
fill ~315 ~155 ~614 ~315 ~155 ~626 minecraft:redstone_wire replace
fill ~318 ~155 ~614 ~318 ~155 ~626 minecraft:redstone_wire replace
fill ~321 ~155 ~614 ~321 ~155 ~626 minecraft:redstone_wire replace
fill ~324 ~155 ~614 ~324 ~155 ~626 minecraft:redstone_wire replace
fill ~327 ~155 ~614 ~327 ~155 ~626 minecraft:redstone_wire replace
fill ~330 ~155 ~614 ~330 ~155 ~626 minecraft:redstone_wire replace
fill ~333 ~155 ~614 ~333 ~155 ~626 minecraft:redstone_wire replace
fill ~336 ~155 ~614 ~336 ~155 ~626 minecraft:redstone_wire replace
fill ~339 ~155 ~614 ~339 ~155 ~626 minecraft:redstone_wire replace
fill ~342 ~155 ~614 ~342 ~155 ~626 minecraft:redstone_wire replace
fill ~345 ~155 ~614 ~345 ~155 ~626 minecraft:redstone_wire replace
fill ~348 ~155 ~614 ~348 ~155 ~626 minecraft:redstone_wire replace
fill ~351 ~155 ~614 ~351 ~155 ~626 minecraft:redstone_wire replace
fill ~354 ~155 ~614 ~354 ~155 ~626 minecraft:redstone_wire replace
fill ~357 ~155 ~614 ~357 ~155 ~626 minecraft:redstone_wire replace
fill ~360 ~155 ~614 ~360 ~155 ~626 minecraft:redstone_wire replace
fill ~363 ~155 ~614 ~363 ~155 ~626 minecraft:redstone_wire replace
fill ~366 ~155 ~614 ~366 ~155 ~626 minecraft:redstone_wire replace
fill ~369 ~155 ~614 ~369 ~155 ~626 minecraft:redstone_wire replace
fill ~372 ~155 ~614 ~372 ~155 ~626 minecraft:redstone_wire replace
fill ~375 ~155 ~614 ~375 ~155 ~626 minecraft:redstone_wire replace
fill ~378 ~155 ~614 ~378 ~155 ~626 minecraft:redstone_wire replace
fill ~381 ~155 ~614 ~381 ~155 ~626 minecraft:redstone_wire replace
fill ~384 ~155 ~614 ~384 ~155 ~626 minecraft:redstone_wire replace
fill ~387 ~155 ~614 ~387 ~155 ~626 minecraft:redstone_wire replace
fill ~390 ~155 ~614 ~390 ~155 ~626 minecraft:redstone_wire replace
fill ~393 ~155 ~614 ~393 ~155 ~626 minecraft:redstone_wire replace
fill ~396 ~155 ~614 ~396 ~155 ~626 minecraft:redstone_wire replace
fill ~399 ~155 ~614 ~399 ~155 ~626 minecraft:redstone_wire replace
setblock ~174 ~155 ~624 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~402 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~177 ~155 ~628 minecraft:redstone_wire replace
setblock ~180 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~183 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~186 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~192 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~628 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~628 ~402 ~155 ~640 minecraft:redstone_wire replace
fill ~405 ~155 ~628 ~405 ~155 ~640 minecraft:redstone_wire replace
fill ~408 ~155 ~628 ~408 ~155 ~640 minecraft:redstone_wire replace
fill ~411 ~155 ~628 ~411 ~155 ~640 minecraft:redstone_wire replace
fill ~414 ~155 ~628 ~414 ~155 ~640 minecraft:redstone_wire replace
fill ~417 ~155 ~628 ~417 ~155 ~640 minecraft:redstone_wire replace
fill ~420 ~155 ~628 ~420 ~155 ~640 minecraft:redstone_wire replace
fill ~423 ~155 ~628 ~423 ~155 ~640 minecraft:redstone_wire replace
fill ~180 ~155 ~630 ~180 ~155 ~632 minecraft:redstone_wire replace
fill ~183 ~155 ~630 ~183 ~155 ~636 minecraft:redstone_wire replace
fill ~186 ~155 ~630 ~186 ~155 ~638 minecraft:redstone_wire replace
fill ~189 ~155 ~630 ~189 ~155 ~642 minecraft:redstone_wire replace
fill ~192 ~155 ~630 ~192 ~155 ~642 minecraft:redstone_wire replace
fill ~195 ~155 ~630 ~195 ~155 ~642 minecraft:redstone_wire replace
fill ~198 ~155 ~630 ~198 ~155 ~642 minecraft:redstone_wire replace
fill ~201 ~155 ~630 ~201 ~155 ~642 minecraft:redstone_wire replace
fill ~204 ~155 ~630 ~204 ~155 ~642 minecraft:redstone_wire replace
fill ~207 ~155 ~630 ~207 ~155 ~642 minecraft:redstone_wire replace
fill ~210 ~155 ~630 ~210 ~155 ~642 minecraft:redstone_wire replace
fill ~213 ~155 ~630 ~213 ~155 ~642 minecraft:redstone_wire replace
fill ~216 ~155 ~630 ~216 ~155 ~642 minecraft:redstone_wire replace
fill ~219 ~155 ~630 ~219 ~155 ~642 minecraft:redstone_wire replace
fill ~222 ~155 ~630 ~222 ~155 ~642 minecraft:redstone_wire replace
fill ~225 ~155 ~630 ~225 ~155 ~642 minecraft:redstone_wire replace
fill ~228 ~155 ~630 ~228 ~155 ~642 minecraft:redstone_wire replace
fill ~231 ~155 ~630 ~231 ~155 ~642 minecraft:redstone_wire replace
fill ~234 ~155 ~630 ~234 ~155 ~642 minecraft:redstone_wire replace
fill ~237 ~155 ~630 ~237 ~155 ~642 minecraft:redstone_wire replace
fill ~240 ~155 ~630 ~240 ~155 ~642 minecraft:redstone_wire replace
fill ~243 ~155 ~630 ~243 ~155 ~642 minecraft:redstone_wire replace
fill ~246 ~155 ~630 ~246 ~155 ~642 minecraft:redstone_wire replace
fill ~249 ~155 ~630 ~249 ~155 ~642 minecraft:redstone_wire replace
fill ~252 ~155 ~630 ~252 ~155 ~642 minecraft:redstone_wire replace
fill ~255 ~155 ~630 ~255 ~155 ~642 minecraft:redstone_wire replace
fill ~258 ~155 ~630 ~258 ~155 ~642 minecraft:redstone_wire replace
fill ~261 ~155 ~630 ~261 ~155 ~642 minecraft:redstone_wire replace
fill ~264 ~155 ~630 ~264 ~155 ~642 minecraft:redstone_wire replace
fill ~267 ~155 ~630 ~267 ~155 ~642 minecraft:redstone_wire replace
fill ~270 ~155 ~630 ~270 ~155 ~642 minecraft:redstone_wire replace
fill ~273 ~155 ~630 ~273 ~155 ~642 minecraft:redstone_wire replace
fill ~276 ~155 ~630 ~276 ~155 ~642 minecraft:redstone_wire replace
fill ~279 ~155 ~630 ~279 ~155 ~642 minecraft:redstone_wire replace
fill ~282 ~155 ~630 ~282 ~155 ~642 minecraft:redstone_wire replace
fill ~285 ~155 ~630 ~285 ~155 ~642 minecraft:redstone_wire replace
fill ~288 ~155 ~630 ~288 ~155 ~642 minecraft:redstone_wire replace
fill ~291 ~155 ~630 ~291 ~155 ~642 minecraft:redstone_wire replace
fill ~294 ~155 ~630 ~294 ~155 ~642 minecraft:redstone_wire replace
fill ~297 ~155 ~630 ~297 ~155 ~642 minecraft:redstone_wire replace
fill ~300 ~155 ~630 ~300 ~155 ~642 minecraft:redstone_wire replace
fill ~303 ~155 ~630 ~303 ~155 ~642 minecraft:redstone_wire replace
fill ~306 ~155 ~630 ~306 ~155 ~642 minecraft:redstone_wire replace
fill ~309 ~155 ~630 ~309 ~155 ~642 minecraft:redstone_wire replace
fill ~312 ~155 ~630 ~312 ~155 ~642 minecraft:redstone_wire replace
fill ~315 ~155 ~630 ~315 ~155 ~642 minecraft:redstone_wire replace
fill ~318 ~155 ~630 ~318 ~155 ~642 minecraft:redstone_wire replace
fill ~321 ~155 ~630 ~321 ~155 ~642 minecraft:redstone_wire replace
fill ~324 ~155 ~630 ~324 ~155 ~642 minecraft:redstone_wire replace
fill ~327 ~155 ~630 ~327 ~155 ~642 minecraft:redstone_wire replace
fill ~330 ~155 ~630 ~330 ~155 ~642 minecraft:redstone_wire replace
fill ~333 ~155 ~630 ~333 ~155 ~642 minecraft:redstone_wire replace
fill ~336 ~155 ~630 ~336 ~155 ~642 minecraft:redstone_wire replace
fill ~339 ~155 ~630 ~339 ~155 ~642 minecraft:redstone_wire replace
fill ~342 ~155 ~630 ~342 ~155 ~642 minecraft:redstone_wire replace
fill ~345 ~155 ~630 ~345 ~155 ~642 minecraft:redstone_wire replace
fill ~348 ~155 ~630 ~348 ~155 ~642 minecraft:redstone_wire replace
fill ~351 ~155 ~630 ~351 ~155 ~642 minecraft:redstone_wire replace
fill ~354 ~155 ~630 ~354 ~155 ~642 minecraft:redstone_wire replace
fill ~357 ~155 ~630 ~357 ~155 ~642 minecraft:redstone_wire replace
fill ~360 ~155 ~630 ~360 ~155 ~642 minecraft:redstone_wire replace
fill ~363 ~155 ~630 ~363 ~155 ~642 minecraft:redstone_wire replace
fill ~366 ~155 ~630 ~366 ~155 ~642 minecraft:redstone_wire replace
fill ~369 ~155 ~630 ~369 ~155 ~642 minecraft:redstone_wire replace
fill ~372 ~155 ~630 ~372 ~155 ~642 minecraft:redstone_wire replace
fill ~375 ~155 ~630 ~375 ~155 ~642 minecraft:redstone_wire replace
fill ~378 ~155 ~630 ~378 ~155 ~642 minecraft:redstone_wire replace
fill ~381 ~155 ~630 ~381 ~155 ~642 minecraft:redstone_wire replace
fill ~384 ~155 ~630 ~384 ~155 ~642 minecraft:redstone_wire replace
fill ~387 ~155 ~630 ~387 ~155 ~642 minecraft:redstone_wire replace
fill ~390 ~155 ~630 ~390 ~155 ~642 minecraft:redstone_wire replace
fill ~393 ~155 ~630 ~393 ~155 ~642 minecraft:redstone_wire replace
fill ~396 ~155 ~630 ~396 ~155 ~642 minecraft:redstone_wire replace
fill ~399 ~155 ~630 ~399 ~155 ~642 minecraft:redstone_wire replace
setblock ~186 ~155 ~640 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~432 ~155 ~640 ~432 ~155 ~652 minecraft:redstone_wire replace
setblock ~402 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~189 ~155 ~644 minecraft:redstone_wire replace
setblock ~192 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~195 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~204 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~644 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~644 ~402 ~155 ~656 minecraft:redstone_wire replace
fill ~405 ~155 ~644 ~405 ~155 ~656 minecraft:redstone_wire replace
fill ~408 ~155 ~644 ~408 ~155 ~656 minecraft:redstone_wire replace
fill ~411 ~155 ~644 ~411 ~155 ~656 minecraft:redstone_wire replace
fill ~414 ~155 ~644 ~414 ~155 ~656 minecraft:redstone_wire replace
fill ~417 ~155 ~644 ~417 ~155 ~656 minecraft:redstone_wire replace
fill ~420 ~155 ~644 ~420 ~155 ~656 minecraft:redstone_wire replace
fill ~423 ~155 ~644 ~423 ~155 ~656 minecraft:redstone_wire replace
fill ~192 ~155 ~646 ~192 ~155 ~648 minecraft:redstone_wire replace
fill ~195 ~155 ~646 ~195 ~155 ~652 minecraft:redstone_wire replace
fill ~198 ~155 ~646 ~198 ~155 ~654 minecraft:redstone_wire replace
fill ~201 ~155 ~646 ~201 ~155 ~658 minecraft:redstone_wire replace
fill ~204 ~155 ~646 ~204 ~155 ~658 minecraft:redstone_wire replace
fill ~207 ~155 ~646 ~207 ~155 ~658 minecraft:redstone_wire replace
fill ~210 ~155 ~646 ~210 ~155 ~658 minecraft:redstone_wire replace
fill ~213 ~155 ~646 ~213 ~155 ~658 minecraft:redstone_wire replace
fill ~216 ~155 ~646 ~216 ~155 ~658 minecraft:redstone_wire replace
fill ~219 ~155 ~646 ~219 ~155 ~658 minecraft:redstone_wire replace
fill ~222 ~155 ~646 ~222 ~155 ~658 minecraft:redstone_wire replace
fill ~225 ~155 ~646 ~225 ~155 ~658 minecraft:redstone_wire replace
fill ~228 ~155 ~646 ~228 ~155 ~658 minecraft:redstone_wire replace
fill ~231 ~155 ~646 ~231 ~155 ~658 minecraft:redstone_wire replace
fill ~234 ~155 ~646 ~234 ~155 ~658 minecraft:redstone_wire replace
fill ~237 ~155 ~646 ~237 ~155 ~658 minecraft:redstone_wire replace
fill ~240 ~155 ~646 ~240 ~155 ~658 minecraft:redstone_wire replace
fill ~243 ~155 ~646 ~243 ~155 ~658 minecraft:redstone_wire replace
fill ~246 ~155 ~646 ~246 ~155 ~658 minecraft:redstone_wire replace
fill ~249 ~155 ~646 ~249 ~155 ~658 minecraft:redstone_wire replace
fill ~252 ~155 ~646 ~252 ~155 ~658 minecraft:redstone_wire replace
fill ~255 ~155 ~646 ~255 ~155 ~658 minecraft:redstone_wire replace
fill ~258 ~155 ~646 ~258 ~155 ~658 minecraft:redstone_wire replace
fill ~261 ~155 ~646 ~261 ~155 ~658 minecraft:redstone_wire replace
fill ~264 ~155 ~646 ~264 ~155 ~658 minecraft:redstone_wire replace
fill ~267 ~155 ~646 ~267 ~155 ~658 minecraft:redstone_wire replace
fill ~270 ~155 ~646 ~270 ~155 ~658 minecraft:redstone_wire replace
fill ~273 ~155 ~646 ~273 ~155 ~658 minecraft:redstone_wire replace
fill ~276 ~155 ~646 ~276 ~155 ~658 minecraft:redstone_wire replace
fill ~279 ~155 ~646 ~279 ~155 ~658 minecraft:redstone_wire replace
fill ~282 ~155 ~646 ~282 ~155 ~658 minecraft:redstone_wire replace
fill ~285 ~155 ~646 ~285 ~155 ~658 minecraft:redstone_wire replace
fill ~288 ~155 ~646 ~288 ~155 ~658 minecraft:redstone_wire replace
fill ~291 ~155 ~646 ~291 ~155 ~658 minecraft:redstone_wire replace
fill ~294 ~155 ~646 ~294 ~155 ~658 minecraft:redstone_wire replace
fill ~297 ~155 ~646 ~297 ~155 ~658 minecraft:redstone_wire replace
fill ~300 ~155 ~646 ~300 ~155 ~658 minecraft:redstone_wire replace
fill ~303 ~155 ~646 ~303 ~155 ~658 minecraft:redstone_wire replace
fill ~306 ~155 ~646 ~306 ~155 ~658 minecraft:redstone_wire replace
fill ~309 ~155 ~646 ~309 ~155 ~658 minecraft:redstone_wire replace
fill ~312 ~155 ~646 ~312 ~155 ~658 minecraft:redstone_wire replace
fill ~315 ~155 ~646 ~315 ~155 ~658 minecraft:redstone_wire replace
fill ~318 ~155 ~646 ~318 ~155 ~658 minecraft:redstone_wire replace
fill ~321 ~155 ~646 ~321 ~155 ~658 minecraft:redstone_wire replace
fill ~324 ~155 ~646 ~324 ~155 ~658 minecraft:redstone_wire replace
fill ~327 ~155 ~646 ~327 ~155 ~658 minecraft:redstone_wire replace
fill ~330 ~155 ~646 ~330 ~155 ~658 minecraft:redstone_wire replace
fill ~333 ~155 ~646 ~333 ~155 ~658 minecraft:redstone_wire replace
fill ~336 ~155 ~646 ~336 ~155 ~658 minecraft:redstone_wire replace
fill ~339 ~155 ~646 ~339 ~155 ~658 minecraft:redstone_wire replace
fill ~342 ~155 ~646 ~342 ~155 ~658 minecraft:redstone_wire replace
fill ~345 ~155 ~646 ~345 ~155 ~658 minecraft:redstone_wire replace
fill ~348 ~155 ~646 ~348 ~155 ~658 minecraft:redstone_wire replace
fill ~351 ~155 ~646 ~351 ~155 ~658 minecraft:redstone_wire replace
fill ~354 ~155 ~646 ~354 ~155 ~658 minecraft:redstone_wire replace
fill ~357 ~155 ~646 ~357 ~155 ~658 minecraft:redstone_wire replace
fill ~360 ~155 ~646 ~360 ~155 ~658 minecraft:redstone_wire replace
fill ~363 ~155 ~646 ~363 ~155 ~658 minecraft:redstone_wire replace
fill ~366 ~155 ~646 ~366 ~155 ~658 minecraft:redstone_wire replace
fill ~369 ~155 ~646 ~369 ~155 ~658 minecraft:redstone_wire replace
fill ~372 ~155 ~646 ~372 ~155 ~658 minecraft:redstone_wire replace
fill ~375 ~155 ~646 ~375 ~155 ~658 minecraft:redstone_wire replace
fill ~378 ~155 ~646 ~378 ~155 ~658 minecraft:redstone_wire replace
fill ~381 ~155 ~646 ~381 ~155 ~658 minecraft:redstone_wire replace
fill ~384 ~155 ~646 ~384 ~155 ~658 minecraft:redstone_wire replace
fill ~387 ~155 ~646 ~387 ~155 ~658 minecraft:redstone_wire replace
fill ~390 ~155 ~646 ~390 ~155 ~658 minecraft:redstone_wire replace
fill ~393 ~155 ~646 ~393 ~155 ~658 minecraft:redstone_wire replace
fill ~396 ~155 ~646 ~396 ~155 ~658 minecraft:redstone_wire replace
fill ~399 ~155 ~646 ~399 ~155 ~658 minecraft:redstone_wire replace
fill ~426 ~155 ~648 ~426 ~155 ~660 minecraft:redstone_wire replace
setblock ~432 ~155 ~654 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~155 ~656 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~656 ~429 ~155 ~668 minecraft:redstone_wire replace
fill ~432 ~155 ~656 ~432 ~155 ~668 minecraft:redstone_wire replace
setblock ~402 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~658 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~201 ~155 ~660 minecraft:redstone_wire replace
setblock ~204 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~207 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~210 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~213 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~216 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~219 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~222 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~225 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~228 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~231 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~240 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~660 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~660 ~402 ~155 ~672 minecraft:redstone_wire replace
fill ~405 ~155 ~660 ~405 ~155 ~672 minecraft:redstone_wire replace
fill ~408 ~155 ~660 ~408 ~155 ~672 minecraft:redstone_wire replace
fill ~411 ~155 ~660 ~411 ~155 ~672 minecraft:redstone_wire replace
fill ~414 ~155 ~660 ~414 ~155 ~672 minecraft:redstone_wire replace
fill ~417 ~155 ~660 ~417 ~155 ~672 minecraft:redstone_wire replace
fill ~420 ~155 ~660 ~420 ~155 ~672 minecraft:redstone_wire replace
fill ~423 ~155 ~660 ~423 ~155 ~672 minecraft:redstone_wire replace
fill ~204 ~155 ~662 ~204 ~155 ~664 minecraft:redstone_wire replace
fill ~207 ~155 ~662 ~207 ~155 ~668 minecraft:redstone_wire replace
fill ~210 ~155 ~662 ~210 ~155 ~670 minecraft:redstone_wire replace
fill ~213 ~155 ~662 ~213 ~155 ~674 minecraft:redstone_wire replace
fill ~216 ~155 ~662 ~216 ~155 ~674 minecraft:redstone_wire replace
fill ~219 ~155 ~662 ~219 ~155 ~674 minecraft:redstone_wire replace
fill ~222 ~155 ~662 ~222 ~155 ~674 minecraft:redstone_wire replace
fill ~225 ~155 ~662 ~225 ~155 ~674 minecraft:redstone_wire replace
fill ~228 ~155 ~662 ~228 ~155 ~674 minecraft:redstone_wire replace
fill ~231 ~155 ~662 ~231 ~155 ~674 minecraft:redstone_wire replace
fill ~234 ~155 ~662 ~234 ~155 ~674 minecraft:redstone_wire replace
fill ~237 ~155 ~662 ~237 ~155 ~674 minecraft:redstone_wire replace
fill ~240 ~155 ~662 ~240 ~155 ~674 minecraft:redstone_wire replace
fill ~243 ~155 ~662 ~243 ~155 ~674 minecraft:redstone_wire replace
fill ~246 ~155 ~662 ~246 ~155 ~674 minecraft:redstone_wire replace
fill ~249 ~155 ~662 ~249 ~155 ~674 minecraft:redstone_wire replace
fill ~252 ~155 ~662 ~252 ~155 ~674 minecraft:redstone_wire replace
fill ~255 ~155 ~662 ~255 ~155 ~674 minecraft:redstone_wire replace
fill ~258 ~155 ~662 ~258 ~155 ~674 minecraft:redstone_wire replace
fill ~261 ~155 ~662 ~261 ~155 ~674 minecraft:redstone_wire replace
fill ~264 ~155 ~662 ~264 ~155 ~674 minecraft:redstone_wire replace
fill ~267 ~155 ~662 ~267 ~155 ~674 minecraft:redstone_wire replace
fill ~270 ~155 ~662 ~270 ~155 ~674 minecraft:redstone_wire replace
fill ~273 ~155 ~662 ~273 ~155 ~674 minecraft:redstone_wire replace
fill ~276 ~155 ~662 ~276 ~155 ~674 minecraft:redstone_wire replace
fill ~279 ~155 ~662 ~279 ~155 ~674 minecraft:redstone_wire replace
fill ~282 ~155 ~662 ~282 ~155 ~674 minecraft:redstone_wire replace
fill ~285 ~155 ~662 ~285 ~155 ~674 minecraft:redstone_wire replace
fill ~288 ~155 ~662 ~288 ~155 ~674 minecraft:redstone_wire replace
fill ~291 ~155 ~662 ~291 ~155 ~674 minecraft:redstone_wire replace
fill ~294 ~155 ~662 ~294 ~155 ~674 minecraft:redstone_wire replace
fill ~297 ~155 ~662 ~297 ~155 ~674 minecraft:redstone_wire replace
fill ~300 ~155 ~662 ~300 ~155 ~674 minecraft:redstone_wire replace
fill ~303 ~155 ~662 ~303 ~155 ~674 minecraft:redstone_wire replace
fill ~306 ~155 ~662 ~306 ~155 ~674 minecraft:redstone_wire replace
fill ~309 ~155 ~662 ~309 ~155 ~674 minecraft:redstone_wire replace
fill ~312 ~155 ~662 ~312 ~155 ~674 minecraft:redstone_wire replace
fill ~315 ~155 ~662 ~315 ~155 ~674 minecraft:redstone_wire replace
fill ~318 ~155 ~662 ~318 ~155 ~674 minecraft:redstone_wire replace
fill ~321 ~155 ~662 ~321 ~155 ~674 minecraft:redstone_wire replace
fill ~324 ~155 ~662 ~324 ~155 ~674 minecraft:redstone_wire replace
fill ~327 ~155 ~662 ~327 ~155 ~674 minecraft:redstone_wire replace
fill ~330 ~155 ~662 ~330 ~155 ~674 minecraft:redstone_wire replace
fill ~333 ~155 ~662 ~333 ~155 ~674 minecraft:redstone_wire replace
fill ~336 ~155 ~662 ~336 ~155 ~674 minecraft:redstone_wire replace
fill ~339 ~155 ~662 ~339 ~155 ~674 minecraft:redstone_wire replace
fill ~342 ~155 ~662 ~342 ~155 ~674 minecraft:redstone_wire replace
fill ~345 ~155 ~662 ~345 ~155 ~674 minecraft:redstone_wire replace
fill ~348 ~155 ~662 ~348 ~155 ~674 minecraft:redstone_wire replace
fill ~351 ~155 ~662 ~351 ~155 ~674 minecraft:redstone_wire replace
fill ~354 ~155 ~662 ~354 ~155 ~674 minecraft:redstone_wire replace
fill ~357 ~155 ~662 ~357 ~155 ~674 minecraft:redstone_wire replace
fill ~360 ~155 ~662 ~360 ~155 ~674 minecraft:redstone_wire replace
fill ~363 ~155 ~662 ~363 ~155 ~674 minecraft:redstone_wire replace
fill ~366 ~155 ~662 ~366 ~155 ~674 minecraft:redstone_wire replace
fill ~369 ~155 ~662 ~369 ~155 ~674 minecraft:redstone_wire replace
fill ~372 ~155 ~662 ~372 ~155 ~674 minecraft:redstone_wire replace
fill ~375 ~155 ~662 ~375 ~155 ~674 minecraft:redstone_wire replace
fill ~378 ~155 ~662 ~378 ~155 ~674 minecraft:redstone_wire replace
fill ~381 ~155 ~662 ~381 ~155 ~674 minecraft:redstone_wire replace
fill ~384 ~155 ~662 ~384 ~155 ~674 minecraft:redstone_wire replace
fill ~387 ~155 ~662 ~387 ~155 ~674 minecraft:redstone_wire replace
fill ~390 ~155 ~662 ~390 ~155 ~674 minecraft:redstone_wire replace
fill ~393 ~155 ~662 ~393 ~155 ~674 minecraft:redstone_wire replace
fill ~396 ~155 ~662 ~396 ~155 ~674 minecraft:redstone_wire replace
fill ~399 ~155 ~662 ~399 ~155 ~674 minecraft:redstone_wire replace
setblock ~426 ~155 ~662 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
