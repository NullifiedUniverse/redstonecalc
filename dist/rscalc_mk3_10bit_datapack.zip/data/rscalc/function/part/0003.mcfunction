setblock ~198 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~288 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~294 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~297 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~321 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~324 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~317 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~294 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~297 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~321 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~324 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~319 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~294 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~321 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~171 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~323 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~171 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~297 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~325 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~303 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~327 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~303 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~306 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~329 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~306 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~331 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~306 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~321 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~324 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~333 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~321 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~324 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~335 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~321 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~337 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~171 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~339 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~171 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~324 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~341 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~343 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~90 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~345 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~347 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~111 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~349 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~351 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~138 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~353 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~355 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~171 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~357 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~359 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~198 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~361 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~363 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~234 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~365 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~367 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~261 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~369 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~371 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~279 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~373 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~375 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~312 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~377 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~379 minecraft:light_gray_concrete replace
setblock ~87 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~381 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~383 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~108 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~385 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~387 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~129 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~389 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~391 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~168 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~393 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~395 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~195 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~397 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~399 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~222 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~401 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~403 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~258 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~405 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~407 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~276 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~409 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~411 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~333 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~413 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~415 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~351 ~27 ~417 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~419 minecraft:light_gray_concrete replace
setblock ~84 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~421 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~423 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~105 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~425 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~427 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~427 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~427 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~427 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~427 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~427 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~123 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~429 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~431 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~165 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~433 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~435 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~192 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~437 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~439 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~219 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~441 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~443 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~246 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~445 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~447 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~273 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~449 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~451 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~330 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~453 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~455 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~348 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~457 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~459 minecraft:light_gray_concrete replace
setblock ~81 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~461 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~463 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~102 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~465 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~467 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~120 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~469 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~471 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~150 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~473 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~475 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~475 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~475 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~475 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~475 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~475 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~189 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~477 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~479 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~216 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~481 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~483 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~483 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~483 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~483 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~483 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~483 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~243 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~485 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~487 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~267 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~489 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~491 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~491 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~491 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~491 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~491 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~491 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~493 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~493 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~493 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~493 minecraft:light_gray_concrete replace
setblock ~318 ~27 ~493 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~493 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~495 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~495 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~495 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~495 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~495 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~345 ~27 ~497 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~499 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~499 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~499 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~499 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~499 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~499 minecraft:light_gray_concrete replace
setblock ~78 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~501 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~503 minecraft:light_gray_concrete replace
setblock ~99 ~27 ~505 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~505 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~505 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~505 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~505 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~505 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~507 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~507 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~507 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~507 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~507 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~509 minecraft:light_gray_concrete replace
setblock ~117 ~27 ~509 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~509 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~509 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~509 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~509 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~511 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~511 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~511 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~511 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~511 minecraft:light_gray_concrete replace
setblock ~144 ~27 ~513 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~513 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~513 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~513 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~513 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~515 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~515 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~515 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~515 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~186 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~517 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~519 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~521 minecraft:light_gray_concrete replace
setblock ~204 ~27 ~521 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~521 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~521 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~523 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~523 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~523 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~525 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~525 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~525 minecraft:light_gray_concrete replace
setblock ~240 ~27 ~525 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~525 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~525 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~527 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~527 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~527 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~527 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~527 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~527 minecraft:light_gray_concrete replace
setblock ~264 ~27 ~529 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~529 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~531 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~315 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~533 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~535 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~537 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~537 minecraft:light_gray_concrete replace
setblock ~342 ~27 ~537 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~537 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~539 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~539 minecraft:light_gray_concrete replace
setblock ~96 ~27 ~541 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~541 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~541 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~541 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~543 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~543 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~543 minecraft:light_gray_concrete replace
setblock ~114 ~27 ~545 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~545 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~547 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~547 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~549 minecraft:light_gray_concrete replace
setblock ~141 ~27 ~549 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~549 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~549 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~549 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~549 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~551 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~553 minecraft:light_gray_concrete replace
setblock ~174 ~27 ~553 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~553 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~553 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~555 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~555 minecraft:light_gray_concrete replace
setblock ~201 ~27 ~557 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~557 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~559 minecraft:light_gray_concrete replace
setblock ~237 ~27 ~561 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~561 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~563 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~563 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~565 minecraft:light_gray_concrete replace
setblock ~270 ~27 ~565 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~565 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~565 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~565 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~567 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~567 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~567 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~567 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~569 minecraft:light_gray_concrete replace
setblock ~291 ~27 ~569 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~569 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~571 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~571 minecraft:light_gray_concrete replace
setblock ~336 ~27 ~573 minecraft:light_gray_concrete replace
setblock ~162 ~27 ~577 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~577 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~579 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~579 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~581 minecraft:light_gray_concrete replace
setblock ~357 ~27 ~581 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~583 minecraft:light_gray_concrete replace
setblock ~93 ~27 ~585 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~585 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~587 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~587 minecraft:light_gray_concrete replace
setblock ~339 ~27 ~589 minecraft:light_gray_concrete replace
setblock ~354 ~27 ~593 minecraft:light_gray_concrete replace
fill ~126 ~28 ~14 ~128 ~28 ~14 minecraft:light_gray_concrete replace
fill ~127 ~28 ~15 ~127 ~28 ~16 minecraft:light_gray_concrete replace
fill ~150 ~28 ~22 ~153 ~28 ~22 minecraft:light_gray_concrete replace
fill ~151 ~28 ~23 ~151 ~28 ~24 minecraft:light_gray_concrete replace
fill ~171 ~28 ~30 ~177 ~28 ~30 minecraft:light_gray_concrete replace
fill ~172 ~28 ~31 ~172 ~28 ~32 minecraft:light_gray_concrete replace
fill ~198 ~28 ~38 ~207 ~28 ~38 minecraft:light_gray_concrete replace
fill ~199 ~28 ~39 ~199 ~28 ~40 minecraft:light_gray_concrete replace
fill ~213 ~28 ~46 ~225 ~28 ~46 minecraft:light_gray_concrete replace
fill ~214 ~28 ~47 ~214 ~28 ~48 minecraft:light_gray_concrete replace
fill ~234 ~28 ~54 ~249 ~28 ~54 minecraft:light_gray_concrete replace
fill ~235 ~28 ~55 ~235 ~28 ~56 minecraft:light_gray_concrete replace
fill ~264 ~28 ~62 ~282 ~28 ~62 minecraft:light_gray_concrete replace
fill ~265 ~28 ~63 ~265 ~28 ~64 minecraft:light_gray_concrete replace
fill ~276 ~28 ~66 ~300 ~28 ~66 minecraft:light_gray_concrete replace
fill ~277 ~28 ~67 ~277 ~28 ~68 minecraft:light_gray_concrete replace
fill ~282 ~28 ~78 ~309 ~28 ~78 minecraft:light_gray_concrete replace
fill ~283 ~28 ~79 ~283 ~28 ~80 minecraft:light_gray_concrete replace
fill ~297 ~28 ~82 ~327 ~28 ~82 minecraft:light_gray_concrete replace
fill ~298 ~28 ~83 ~298 ~28 ~84 minecraft:light_gray_concrete replace
fill ~132 ~28 ~262 ~134 ~28 ~262 minecraft:light_gray_concrete replace
fill ~133 ~28 ~263 ~133 ~28 ~264 minecraft:light_gray_concrete replace
fill ~132 ~28 ~266 ~135 ~28 ~266 minecraft:light_gray_concrete replace
fill ~133 ~28 ~267 ~133 ~28 ~268 minecraft:light_gray_concrete replace
fill ~144 ~28 ~270 ~147 ~28 ~270 minecraft:light_gray_concrete replace
fill ~145 ~28 ~271 ~145 ~28 ~272 minecraft:light_gray_concrete replace
fill ~153 ~28 ~274 ~156 ~28 ~274 minecraft:light_gray_concrete replace
fill ~154 ~28 ~275 ~154 ~28 ~276 minecraft:light_gray_concrete replace
fill ~153 ~28 ~278 ~159 ~28 ~278 minecraft:light_gray_concrete replace
fill ~154 ~28 ~279 ~154 ~28 ~280 minecraft:light_gray_concrete replace
fill ~174 ~28 ~282 ~180 ~28 ~282 minecraft:light_gray_concrete replace
fill ~175 ~28 ~283 ~175 ~28 ~284 minecraft:light_gray_concrete replace
fill ~174 ~28 ~286 ~183 ~28 ~286 minecraft:light_gray_concrete replace
fill ~175 ~28 ~287 ~175 ~28 ~288 minecraft:light_gray_concrete replace
fill ~201 ~28 ~290 ~210 ~28 ~290 minecraft:light_gray_concrete replace
fill ~202 ~28 ~291 ~202 ~28 ~292 minecraft:light_gray_concrete replace
fill ~201 ~28 ~294 ~213 ~28 ~294 minecraft:light_gray_concrete replace
fill ~202 ~28 ~295 ~202 ~28 ~296 minecraft:light_gray_concrete replace
fill ~216 ~28 ~298 ~228 ~28 ~298 minecraft:light_gray_concrete replace
fill ~217 ~28 ~299 ~217 ~28 ~300 minecraft:light_gray_concrete replace
fill ~216 ~28 ~302 ~231 ~28 ~302 minecraft:light_gray_concrete replace
fill ~217 ~28 ~303 ~217 ~28 ~304 minecraft:light_gray_concrete replace
fill ~237 ~28 ~306 ~252 ~28 ~306 minecraft:light_gray_concrete replace
fill ~238 ~28 ~307 ~238 ~28 ~308 minecraft:light_gray_concrete replace
fill ~237 ~28 ~310 ~255 ~28 ~310 minecraft:light_gray_concrete replace
fill ~238 ~28 ~311 ~238 ~28 ~312 minecraft:light_gray_concrete replace
fill ~267 ~28 ~314 ~285 ~28 ~314 minecraft:light_gray_concrete replace
fill ~268 ~28 ~315 ~268 ~28 ~316 minecraft:light_gray_concrete replace
fill ~267 ~28 ~318 ~288 ~28 ~318 minecraft:light_gray_concrete replace
fill ~268 ~28 ~319 ~268 ~28 ~320 minecraft:light_gray_concrete replace
fill ~273 ~28 ~322 ~294 ~28 ~322 minecraft:light_gray_concrete replace
fill ~274 ~28 ~323 ~274 ~28 ~324 minecraft:light_gray_concrete replace
fill ~273 ~28 ~326 ~297 ~28 ~326 minecraft:light_gray_concrete replace
fill ~274 ~28 ~327 ~274 ~28 ~328 minecraft:light_gray_concrete replace
fill ~279 ~28 ~330 ~303 ~28 ~330 minecraft:light_gray_concrete replace
fill ~280 ~28 ~331 ~280 ~28 ~332 minecraft:light_gray_concrete replace
fill ~279 ~28 ~334 ~306 ~28 ~334 minecraft:light_gray_concrete replace
fill ~280 ~28 ~335 ~280 ~28 ~336 minecraft:light_gray_concrete replace
fill ~294 ~28 ~338 ~321 ~28 ~338 minecraft:light_gray_concrete replace
fill ~295 ~28 ~339 ~295 ~28 ~340 minecraft:light_gray_concrete replace
fill ~294 ~28 ~342 ~324 ~28 ~342 minecraft:light_gray_concrete replace
fill ~295 ~28 ~343 ~295 ~28 ~344 minecraft:light_gray_concrete replace
fill ~90 ~28 ~346 ~92 ~28 ~346 minecraft:light_gray_concrete replace
fill ~91 ~28 ~347 ~91 ~28 ~348 minecraft:light_gray_concrete replace
fill ~111 ~28 ~350 ~113 ~28 ~350 minecraft:light_gray_concrete replace
fill ~112 ~28 ~351 ~112 ~28 ~352 minecraft:light_gray_concrete replace
fill ~135 ~28 ~354 ~138 ~28 ~354 minecraft:light_gray_concrete replace
fill ~136 ~28 ~355 ~136 ~28 ~356 minecraft:light_gray_concrete replace
fill ~165 ~28 ~358 ~171 ~28 ~358 minecraft:light_gray_concrete replace
fill ~166 ~28 ~359 ~166 ~28 ~360 minecraft:light_gray_concrete replace
fill ~189 ~28 ~362 ~198 ~28 ~362 minecraft:light_gray_concrete replace
fill ~190 ~28 ~363 ~190 ~28 ~364 minecraft:light_gray_concrete replace
fill ~219 ~28 ~366 ~234 ~28 ~366 minecraft:light_gray_concrete replace
fill ~220 ~28 ~367 ~220 ~28 ~368 minecraft:light_gray_concrete replace
fill ~243 ~28 ~370 ~261 ~28 ~370 minecraft:light_gray_concrete replace
fill ~244 ~28 ~371 ~244 ~28 ~372 minecraft:light_gray_concrete replace
fill ~261 ~28 ~374 ~279 ~28 ~374 minecraft:light_gray_concrete replace
fill ~262 ~28 ~375 ~262 ~28 ~376 minecraft:light_gray_concrete replace
fill ~285 ~28 ~378 ~312 ~28 ~378 minecraft:light_gray_concrete replace
fill ~286 ~28 ~379 ~286 ~28 ~380 minecraft:light_gray_concrete replace
fill ~87 ~28 ~382 ~89 ~28 ~382 minecraft:light_gray_concrete replace
fill ~88 ~28 ~383 ~88 ~28 ~384 minecraft:light_gray_concrete replace
fill ~108 ~28 ~386 ~110 ~28 ~386 minecraft:light_gray_concrete replace
fill ~109 ~28 ~387 ~109 ~28 ~388 minecraft:light_gray_concrete replace
fill ~129 ~28 ~390 ~131 ~28 ~390 minecraft:light_gray_concrete replace
fill ~130 ~28 ~391 ~130 ~28 ~392 minecraft:light_gray_concrete replace
fill ~162 ~28 ~394 ~168 ~28 ~394 minecraft:light_gray_concrete replace
fill ~163 ~28 ~395 ~163 ~28 ~396 minecraft:light_gray_concrete replace
fill ~186 ~28 ~398 ~195 ~28 ~398 minecraft:light_gray_concrete replace
fill ~187 ~28 ~399 ~187 ~28 ~400 minecraft:light_gray_concrete replace
fill ~210 ~28 ~402 ~222 ~28 ~402 minecraft:light_gray_concrete replace
fill ~211 ~28 ~403 ~211 ~28 ~404 minecraft:light_gray_concrete replace
fill ~240 ~28 ~406 ~258 ~28 ~406 minecraft:light_gray_concrete replace
fill ~241 ~28 ~407 ~241 ~28 ~408 minecraft:light_gray_concrete replace
fill ~258 ~28 ~410 ~276 ~28 ~410 minecraft:light_gray_concrete replace
fill ~259 ~28 ~411 ~259 ~28 ~412 minecraft:light_gray_concrete replace
fill ~303 ~28 ~414 ~333 ~28 ~414 minecraft:light_gray_concrete replace
fill ~304 ~28 ~415 ~304 ~28 ~416 minecraft:light_gray_concrete replace
fill ~321 ~28 ~418 ~351 ~28 ~418 minecraft:light_gray_concrete replace
fill ~322 ~28 ~419 ~322 ~28 ~420 minecraft:light_gray_concrete replace
fill ~84 ~28 ~422 ~86 ~28 ~422 minecraft:light_gray_concrete replace
fill ~85 ~28 ~423 ~85 ~28 ~424 minecraft:light_gray_concrete replace
fill ~105 ~28 ~426 ~107 ~28 ~426 minecraft:light_gray_concrete replace
fill ~106 ~28 ~427 ~106 ~28 ~428 minecraft:light_gray_concrete replace
fill ~123 ~28 ~430 ~125 ~28 ~430 minecraft:light_gray_concrete replace
fill ~124 ~28 ~431 ~124 ~28 ~432 minecraft:light_gray_concrete replace
fill ~159 ~28 ~434 ~165 ~28 ~434 minecraft:light_gray_concrete replace
fill ~160 ~28 ~435 ~160 ~28 ~436 minecraft:light_gray_concrete replace
fill ~183 ~28 ~438 ~192 ~28 ~438 minecraft:light_gray_concrete replace
fill ~184 ~28 ~439 ~184 ~28 ~440 minecraft:light_gray_concrete replace
fill ~207 ~28 ~442 ~219 ~28 ~442 minecraft:light_gray_concrete replace
fill ~208 ~28 ~443 ~208 ~28 ~444 minecraft:light_gray_concrete replace
fill ~231 ~28 ~446 ~246 ~28 ~446 minecraft:light_gray_concrete replace
fill ~232 ~28 ~447 ~232 ~28 ~448 minecraft:light_gray_concrete replace
fill ~255 ~28 ~450 ~273 ~28 ~450 minecraft:light_gray_concrete replace
fill ~256 ~28 ~451 ~256 ~28 ~452 minecraft:light_gray_concrete replace
fill ~300 ~28 ~454 ~330 ~28 ~454 minecraft:light_gray_concrete replace
fill ~301 ~28 ~455 ~301 ~28 ~456 minecraft:light_gray_concrete replace
fill ~318 ~28 ~458 ~348 ~28 ~458 minecraft:light_gray_concrete replace
fill ~319 ~28 ~459 ~319 ~28 ~460 minecraft:light_gray_concrete replace
fill ~81 ~28 ~462 ~83 ~28 ~462 minecraft:light_gray_concrete replace
fill ~82 ~28 ~463 ~82 ~28 ~464 minecraft:light_gray_concrete replace
fill ~102 ~28 ~466 ~104 ~28 ~466 minecraft:light_gray_concrete replace
fill ~103 ~28 ~467 ~103 ~28 ~468 minecraft:light_gray_concrete replace
fill ~120 ~28 ~470 ~122 ~28 ~470 minecraft:light_gray_concrete replace
fill ~121 ~28 ~471 ~121 ~28 ~472 minecraft:light_gray_concrete replace
fill ~147 ~28 ~474 ~150 ~28 ~474 minecraft:light_gray_concrete replace
fill ~148 ~28 ~475 ~148 ~28 ~476 minecraft:light_gray_concrete replace
fill ~180 ~28 ~478 ~189 ~28 ~478 minecraft:light_gray_concrete replace
fill ~181 ~28 ~479 ~181 ~28 ~480 minecraft:light_gray_concrete replace
fill ~204 ~28 ~482 ~216 ~28 ~482 minecraft:light_gray_concrete replace
fill ~205 ~28 ~483 ~205 ~28 ~484 minecraft:light_gray_concrete replace
fill ~228 ~28 ~486 ~243 ~28 ~486 minecraft:light_gray_concrete replace
fill ~229 ~28 ~487 ~229 ~28 ~488 minecraft:light_gray_concrete replace
fill ~249 ~28 ~490 ~267 ~28 ~490 minecraft:light_gray_concrete replace
fill ~250 ~28 ~491 ~250 ~28 ~492 minecraft:light_gray_concrete replace
fill ~291 ~28 ~494 ~318 ~28 ~494 minecraft:light_gray_concrete replace
fill ~292 ~28 ~495 ~292 ~28 ~496 minecraft:light_gray_concrete replace
fill ~315 ~28 ~498 ~345 ~28 ~498 minecraft:light_gray_concrete replace
fill ~316 ~28 ~499 ~316 ~28 ~500 minecraft:light_gray_concrete replace
fill ~78 ~28 ~502 ~80 ~28 ~502 minecraft:light_gray_concrete replace
fill ~79 ~28 ~503 ~79 ~28 ~504 minecraft:light_gray_concrete replace
fill ~99 ~28 ~506 ~101 ~28 ~506 minecraft:light_gray_concrete replace
fill ~100 ~28 ~507 ~100 ~28 ~508 minecraft:light_gray_concrete replace
fill ~117 ~28 ~510 ~119 ~28 ~510 minecraft:light_gray_concrete replace
fill ~118 ~28 ~511 ~118 ~28 ~512 minecraft:light_gray_concrete replace
fill ~141 ~28 ~514 ~144 ~28 ~514 minecraft:light_gray_concrete replace
fill ~142 ~28 ~515 ~142 ~28 ~516 minecraft:light_gray_concrete replace
fill ~177 ~28 ~518 ~186 ~28 ~518 minecraft:light_gray_concrete replace
fill ~178 ~28 ~519 ~178 ~28 ~520 minecraft:light_gray_concrete replace
fill ~195 ~28 ~522 ~204 ~28 ~522 minecraft:light_gray_concrete replace
fill ~196 ~28 ~523 ~196 ~28 ~524 minecraft:light_gray_concrete replace
fill ~225 ~28 ~526 ~240 ~28 ~526 minecraft:light_gray_concrete replace
fill ~226 ~28 ~527 ~226 ~28 ~528 minecraft:light_gray_concrete replace
fill ~246 ~28 ~530 ~264 ~28 ~530 minecraft:light_gray_concrete replace
fill ~247 ~28 ~531 ~247 ~28 ~532 minecraft:light_gray_concrete replace
fill ~288 ~28 ~534 ~315 ~28 ~534 minecraft:light_gray_concrete replace
fill ~289 ~28 ~535 ~289 ~28 ~536 minecraft:light_gray_concrete replace
fill ~312 ~28 ~538 ~342 ~28 ~538 minecraft:light_gray_concrete replace
fill ~313 ~28 ~539 ~313 ~28 ~540 minecraft:light_gray_concrete replace
fill ~96 ~28 ~542 ~98 ~28 ~542 minecraft:light_gray_concrete replace
fill ~97 ~28 ~543 ~97 ~28 ~544 minecraft:light_gray_concrete replace
fill ~114 ~28 ~546 ~116 ~28 ~546 minecraft:light_gray_concrete replace
fill ~115 ~28 ~547 ~115 ~28 ~548 minecraft:light_gray_concrete replace
fill ~138 ~28 ~550 ~141 ~28 ~550 minecraft:light_gray_concrete replace
fill ~139 ~28 ~551 ~139 ~28 ~552 minecraft:light_gray_concrete replace
fill ~168 ~28 ~554 ~174 ~28 ~554 minecraft:light_gray_concrete replace
fill ~169 ~28 ~555 ~169 ~28 ~556 minecraft:light_gray_concrete replace
fill ~192 ~28 ~558 ~201 ~28 ~558 minecraft:light_gray_concrete replace
fill ~193 ~28 ~559 ~193 ~28 ~560 minecraft:light_gray_concrete replace
fill ~222 ~28 ~562 ~237 ~28 ~562 minecraft:light_gray_concrete replace
fill ~223 ~28 ~563 ~223 ~28 ~564 minecraft:light_gray_concrete replace
fill ~252 ~28 ~566 ~270 ~28 ~566 minecraft:light_gray_concrete replace
fill ~253 ~28 ~567 ~253 ~28 ~568 minecraft:light_gray_concrete replace
fill ~270 ~28 ~570 ~291 ~28 ~570 minecraft:light_gray_concrete replace
fill ~271 ~28 ~571 ~271 ~28 ~572 minecraft:light_gray_concrete replace
fill ~306 ~28 ~574 ~336 ~28 ~574 minecraft:light_gray_concrete replace
fill ~307 ~28 ~575 ~307 ~28 ~576 minecraft:light_gray_concrete replace
fill ~156 ~28 ~578 ~162 ~28 ~578 minecraft:light_gray_concrete replace
fill ~157 ~28 ~579 ~157 ~28 ~580 minecraft:light_gray_concrete replace
fill ~327 ~28 ~582 ~357 ~28 ~582 minecraft:light_gray_concrete replace
fill ~328 ~28 ~583 ~328 ~28 ~584 minecraft:light_gray_concrete replace
fill ~93 ~28 ~586 ~95 ~28 ~586 minecraft:light_gray_concrete replace
fill ~94 ~28 ~587 ~94 ~28 ~588 minecraft:light_gray_concrete replace
fill ~309 ~28 ~590 ~339 ~28 ~590 minecraft:light_gray_concrete replace
fill ~310 ~28 ~591 ~310 ~28 ~592 minecraft:light_gray_concrete replace
fill ~324 ~28 ~594 ~354 ~28 ~594 minecraft:light_gray_concrete replace
fill ~325 ~28 ~595 ~325 ~28 ~596 minecraft:light_gray_concrete replace
setblock ~127 ~29 ~16 minecraft:light_gray_concrete replace
setblock ~151 ~29 ~24 minecraft:light_gray_concrete replace
setblock ~172 ~29 ~32 minecraft:light_gray_concrete replace
setblock ~199 ~29 ~40 minecraft:light_gray_concrete replace
setblock ~216 ~29 ~46 minecraft:light_gray_concrete replace
setblock ~218 ~29 ~46 minecraft:light_gray_concrete replace
setblock ~214 ~29 ~48 minecraft:light_gray_concrete replace
setblock ~240 ~29 ~54 minecraft:light_gray_concrete replace
setblock ~242 ~29 ~54 minecraft:light_gray_concrete replace
setblock ~235 ~29 ~56 minecraft:light_gray_concrete replace
setblock ~273 ~29 ~62 minecraft:light_gray_concrete replace
setblock ~275 ~29 ~62 minecraft:light_gray_concrete replace
setblock ~265 ~29 ~64 minecraft:light_gray_concrete replace
setblock ~291 ~29 ~66 minecraft:light_gray_concrete replace
setblock ~293 ~29 ~66 minecraft:light_gray_concrete replace
setblock ~277 ~29 ~68 minecraft:light_gray_concrete replace
setblock ~300 ~29 ~78 minecraft:light_gray_concrete replace
setblock ~302 ~29 ~78 minecraft:light_gray_concrete replace
setblock ~283 ~29 ~80 minecraft:light_gray_concrete replace
setblock ~301 ~29 ~82 minecraft:light_gray_concrete replace
setblock ~303 ~29 ~82 minecraft:light_gray_concrete replace
setblock ~318 ~29 ~82 minecraft:light_gray_concrete replace
setblock ~320 ~29 ~82 minecraft:light_gray_concrete replace
setblock ~298 ~29 ~84 minecraft:light_gray_concrete replace
setblock ~133 ~29 ~264 minecraft:light_gray_concrete replace
setblock ~133 ~29 ~268 minecraft:light_gray_concrete replace
setblock ~145 ~29 ~272 minecraft:light_gray_concrete replace
setblock ~154 ~29 ~276 minecraft:light_gray_concrete replace
setblock ~154 ~29 ~280 minecraft:light_gray_concrete replace
setblock ~175 ~29 ~284 minecraft:light_gray_concrete replace
setblock ~175 ~29 ~288 minecraft:light_gray_concrete replace
setblock ~202 ~29 ~292 minecraft:light_gray_concrete replace
setblock ~202 ~29 ~296 minecraft:light_gray_concrete replace
setblock ~217 ~29 ~300 minecraft:light_gray_concrete replace
setblock ~217 ~29 ~304 minecraft:light_gray_concrete replace
setblock ~242 ~29 ~306 minecraft:light_gray_concrete replace
setblock ~244 ~29 ~306 minecraft:light_gray_concrete replace
setblock ~238 ~29 ~308 minecraft:light_gray_concrete replace
setblock ~240 ~29 ~310 minecraft:light_gray_concrete replace
setblock ~242 ~29 ~310 minecraft:light_gray_concrete replace
setblock ~238 ~29 ~312 minecraft:light_gray_concrete replace
setblock ~270 ~29 ~314 minecraft:light_gray_concrete replace
setblock ~272 ~29 ~314 minecraft:light_gray_concrete replace
setblock ~268 ~29 ~316 minecraft:light_gray_concrete replace
setblock ~274 ~29 ~318 minecraft:light_gray_concrete replace
setblock ~276 ~29 ~318 minecraft:light_gray_concrete replace
setblock ~268 ~29 ~320 minecraft:light_gray_concrete replace
setblock ~280 ~29 ~322 minecraft:light_gray_concrete replace
setblock ~282 ~29 ~322 minecraft:light_gray_concrete replace
setblock ~274 ~29 ~324 minecraft:light_gray_concrete replace
setblock ~287 ~29 ~326 minecraft:light_gray_concrete replace
setblock ~289 ~29 ~326 minecraft:light_gray_concrete replace
setblock ~274 ~29 ~328 minecraft:light_gray_concrete replace
setblock ~288 ~29 ~330 minecraft:light_gray_concrete replace
setblock ~290 ~29 ~330 minecraft:light_gray_concrete replace
setblock ~280 ~29 ~332 minecraft:light_gray_concrete replace
setblock ~292 ~29 ~334 minecraft:light_gray_concrete replace
setblock ~294 ~29 ~334 minecraft:light_gray_concrete replace
setblock ~280 ~29 ~336 minecraft:light_gray_concrete replace
setblock ~307 ~29 ~338 minecraft:light_gray_concrete replace
setblock ~309 ~29 ~338 minecraft:light_gray_concrete replace
setblock ~295 ~29 ~340 minecraft:light_gray_concrete replace
setblock ~297 ~29 ~342 minecraft:light_gray_concrete replace
setblock ~299 ~29 ~342 minecraft:light_gray_concrete replace
setblock ~314 ~29 ~342 minecraft:light_gray_concrete replace
setblock ~316 ~29 ~342 minecraft:light_gray_concrete replace
setblock ~295 ~29 ~344 minecraft:light_gray_concrete replace
setblock ~91 ~29 ~348 minecraft:light_gray_concrete replace
setblock ~112 ~29 ~352 minecraft:light_gray_concrete replace
setblock ~136 ~29 ~356 minecraft:light_gray_concrete replace
setblock ~166 ~29 ~360 minecraft:light_gray_concrete replace
setblock ~190 ~29 ~364 minecraft:light_gray_concrete replace
setblock ~226 ~29 ~366 minecraft:light_gray_concrete replace
setblock ~228 ~29 ~366 minecraft:light_gray_concrete replace
setblock ~220 ~29 ~368 minecraft:light_gray_concrete replace
setblock ~251 ~29 ~370 minecraft:light_gray_concrete replace
setblock ~253 ~29 ~370 minecraft:light_gray_concrete replace
setblock ~244 ~29 ~372 minecraft:light_gray_concrete replace
setblock ~264 ~29 ~374 minecraft:light_gray_concrete replace
setblock ~266 ~29 ~374 minecraft:light_gray_concrete replace
setblock ~262 ~29 ~376 minecraft:light_gray_concrete replace
setblock ~300 ~29 ~378 minecraft:light_gray_concrete replace
setblock ~302 ~29 ~378 minecraft:light_gray_concrete replace
setblock ~286 ~29 ~380 minecraft:light_gray_concrete replace
setblock ~88 ~29 ~384 minecraft:light_gray_concrete replace
setblock ~109 ~29 ~388 minecraft:light_gray_concrete replace
setblock ~130 ~29 ~392 minecraft:light_gray_concrete replace
setblock ~163 ~29 ~396 minecraft:light_gray_concrete replace
setblock ~187 ~29 ~400 minecraft:light_gray_concrete replace
setblock ~211 ~29 ~404 minecraft:light_gray_concrete replace
setblock ~243 ~29 ~406 minecraft:light_gray_concrete replace
setblock ~245 ~29 ~406 minecraft:light_gray_concrete replace
setblock ~241 ~29 ~408 minecraft:light_gray_concrete replace
setblock ~262 ~29 ~410 minecraft:light_gray_concrete replace
setblock ~264 ~29 ~410 minecraft:light_gray_concrete replace
setblock ~259 ~29 ~412 minecraft:light_gray_concrete replace
setblock ~321 ~29 ~414 minecraft:light_gray_concrete replace
setblock ~323 ~29 ~414 minecraft:light_gray_concrete replace
setblock ~304 ~29 ~416 minecraft:light_gray_concrete replace
setblock ~326 ~29 ~418 minecraft:light_gray_concrete replace
setblock ~328 ~29 ~418 minecraft:light_gray_concrete replace
setblock ~343 ~29 ~418 minecraft:light_gray_concrete replace
setblock ~345 ~29 ~418 minecraft:light_gray_concrete replace
setblock ~322 ~29 ~420 minecraft:light_gray_concrete replace
setblock ~85 ~29 ~424 minecraft:light_gray_concrete replace
setblock ~106 ~29 ~428 minecraft:light_gray_concrete replace
setblock ~124 ~29 ~432 minecraft:light_gray_concrete replace
setblock ~160 ~29 ~436 minecraft:light_gray_concrete replace
setblock ~184 ~29 ~440 minecraft:light_gray_concrete replace
setblock ~209 ~29 ~442 minecraft:light_gray_concrete replace
setblock ~211 ~29 ~442 minecraft:light_gray_concrete replace
setblock ~208 ~29 ~444 minecraft:light_gray_concrete replace
setblock ~232 ~29 ~448 minecraft:light_gray_concrete replace
setblock ~258 ~29 ~450 minecraft:light_gray_concrete replace
setblock ~260 ~29 ~450 minecraft:light_gray_concrete replace
setblock ~256 ~29 ~452 minecraft:light_gray_concrete replace
setblock ~315 ~29 ~454 minecraft:light_gray_concrete replace
setblock ~317 ~29 ~454 minecraft:light_gray_concrete replace
setblock ~301 ~29 ~456 minecraft:light_gray_concrete replace
setblock ~335 ~29 ~458 minecraft:light_gray_concrete replace
setblock ~337 ~29 ~458 minecraft:light_gray_concrete replace
setblock ~319 ~29 ~460 minecraft:light_gray_concrete replace
setblock ~82 ~29 ~464 minecraft:light_gray_concrete replace
setblock ~103 ~29 ~468 minecraft:light_gray_concrete replace
setblock ~121 ~29 ~472 minecraft:light_gray_concrete replace
setblock ~148 ~29 ~476 minecraft:light_gray_concrete replace
setblock ~181 ~29 ~480 minecraft:light_gray_concrete replace
setblock ~205 ~29 ~484 minecraft:light_gray_concrete replace
setblock ~233 ~29 ~486 minecraft:light_gray_concrete replace
setblock ~235 ~29 ~486 minecraft:light_gray_concrete replace
setblock ~229 ~29 ~488 minecraft:light_gray_concrete replace
setblock ~252 ~29 ~490 minecraft:light_gray_concrete replace
setblock ~254 ~29 ~490 minecraft:light_gray_concrete replace
setblock ~250 ~29 ~492 minecraft:light_gray_concrete replace
setblock ~303 ~29 ~494 minecraft:light_gray_concrete replace
setblock ~305 ~29 ~494 minecraft:light_gray_concrete replace
setblock ~292 ~29 ~496 minecraft:light_gray_concrete replace
setblock ~332 ~29 ~498 minecraft:light_gray_concrete replace
setblock ~334 ~29 ~498 minecraft:light_gray_concrete replace
setblock ~316 ~29 ~500 minecraft:light_gray_concrete replace
setblock ~79 ~29 ~504 minecraft:light_gray_concrete replace
setblock ~100 ~29 ~508 minecraft:light_gray_concrete replace
setblock ~118 ~29 ~512 minecraft:light_gray_concrete replace
setblock ~142 ~29 ~516 minecraft:light_gray_concrete replace
setblock ~178 ~29 ~520 minecraft:light_gray_concrete replace
setblock ~196 ~29 ~524 minecraft:light_gray_concrete replace
setblock ~226 ~29 ~528 minecraft:light_gray_concrete replace
setblock ~249 ~29 ~530 minecraft:light_gray_concrete replace
setblock ~251 ~29 ~530 minecraft:light_gray_concrete replace
setblock ~247 ~29 ~532 minecraft:light_gray_concrete replace
setblock ~305 ~29 ~534 minecraft:light_gray_concrete replace
setblock ~307 ~29 ~534 minecraft:light_gray_concrete replace
setblock ~289 ~29 ~536 minecraft:light_gray_concrete replace
setblock ~327 ~29 ~538 minecraft:light_gray_concrete replace
setblock ~329 ~29 ~538 minecraft:light_gray_concrete replace
setblock ~313 ~29 ~540 minecraft:light_gray_concrete replace
setblock ~97 ~29 ~544 minecraft:light_gray_concrete replace
setblock ~115 ~29 ~548 minecraft:light_gray_concrete replace
setblock ~139 ~29 ~552 minecraft:light_gray_concrete replace
setblock ~169 ~29 ~556 minecraft:light_gray_concrete replace
setblock ~193 ~29 ~560 minecraft:light_gray_concrete replace
setblock ~223 ~29 ~564 minecraft:light_gray_concrete replace
setblock ~255 ~29 ~566 minecraft:light_gray_concrete replace
setblock ~257 ~29 ~566 minecraft:light_gray_concrete replace
setblock ~253 ~29 ~568 minecraft:light_gray_concrete replace
setblock ~277 ~29 ~570 minecraft:light_gray_concrete replace
setblock ~279 ~29 ~570 minecraft:light_gray_concrete replace
setblock ~271 ~29 ~572 minecraft:light_gray_concrete replace
setblock ~309 ~29 ~574 minecraft:light_gray_concrete replace
setblock ~311 ~29 ~574 minecraft:light_gray_concrete replace
setblock ~326 ~29 ~574 minecraft:light_gray_concrete replace
setblock ~328 ~29 ~574 minecraft:light_gray_concrete replace
setblock ~307 ~29 ~576 minecraft:light_gray_concrete replace
setblock ~157 ~29 ~580 minecraft:light_gray_concrete replace
setblock ~342 ~29 ~582 minecraft:light_gray_concrete replace
setblock ~344 ~29 ~582 minecraft:light_gray_concrete replace
setblock ~328 ~29 ~584 minecraft:light_gray_concrete replace
setblock ~94 ~29 ~588 minecraft:light_gray_concrete replace
setblock ~324 ~29 ~590 minecraft:light_gray_concrete replace
setblock ~326 ~29 ~590 minecraft:light_gray_concrete replace
setblock ~310 ~29 ~592 minecraft:light_gray_concrete replace
setblock ~327 ~29 ~594 minecraft:light_gray_concrete replace
setblock ~329 ~29 ~594 minecraft:light_gray_concrete replace
setblock ~344 ~29 ~594 minecraft:light_gray_concrete replace
setblock ~346 ~29 ~594 minecraft:light_gray_concrete replace
setblock ~325 ~29 ~596 minecraft:light_gray_concrete replace
fill ~126 ~30 ~12 ~126 ~30 ~16 minecraft:light_gray_concrete replace
fill ~150 ~30 ~20 ~150 ~30 ~24 minecraft:light_gray_concrete replace
fill ~171 ~30 ~28 ~171 ~30 ~32 minecraft:light_gray_concrete replace
fill ~198 ~30 ~36 ~198 ~30 ~40 minecraft:light_gray_concrete replace
fill ~213 ~30 ~44 ~213 ~30 ~48 minecraft:light_gray_concrete replace
fill ~234 ~30 ~52 ~234 ~30 ~56 minecraft:light_gray_concrete replace
fill ~264 ~30 ~60 ~264 ~30 ~64 minecraft:light_gray_concrete replace
fill ~276 ~30 ~64 ~276 ~30 ~68 minecraft:light_gray_concrete replace
fill ~282 ~30 ~76 ~282 ~30 ~80 minecraft:light_gray_concrete replace
fill ~297 ~30 ~80 ~297 ~30 ~84 minecraft:light_gray_concrete replace
fill ~132 ~30 ~260 ~132 ~30 ~268 minecraft:light_gray_concrete replace
fill ~144 ~30 ~268 ~144 ~30 ~272 minecraft:light_gray_concrete replace
fill ~153 ~30 ~272 ~153 ~30 ~280 minecraft:light_gray_concrete replace
fill ~174 ~30 ~280 ~174 ~30 ~288 minecraft:light_gray_concrete replace
fill ~201 ~30 ~288 ~201 ~30 ~296 minecraft:light_gray_concrete replace
fill ~216 ~30 ~296 ~216 ~30 ~304 minecraft:light_gray_concrete replace
fill ~237 ~30 ~304 ~237 ~30 ~312 minecraft:light_gray_concrete replace
fill ~267 ~30 ~312 ~267 ~30 ~320 minecraft:light_gray_concrete replace
fill ~273 ~30 ~320 ~273 ~30 ~328 minecraft:light_gray_concrete replace
fill ~279 ~30 ~328 ~279 ~30 ~336 minecraft:light_gray_concrete replace
fill ~294 ~30 ~336 ~294 ~30 ~344 minecraft:light_gray_concrete replace
fill ~90 ~30 ~344 ~90 ~30 ~348 minecraft:light_gray_concrete replace
fill ~111 ~30 ~348 ~111 ~30 ~352 minecraft:light_gray_concrete replace
fill ~135 ~30 ~352 ~135 ~30 ~356 minecraft:light_gray_concrete replace
fill ~165 ~30 ~356 ~165 ~30 ~360 minecraft:light_gray_concrete replace
fill ~189 ~30 ~360 ~189 ~30 ~364 minecraft:light_gray_concrete replace
fill ~219 ~30 ~364 ~219 ~30 ~368 minecraft:light_gray_concrete replace
fill ~243 ~30 ~368 ~243 ~30 ~372 minecraft:light_gray_concrete replace
fill ~261 ~30 ~372 ~261 ~30 ~376 minecraft:light_gray_concrete replace
fill ~285 ~30 ~376 ~285 ~30 ~380 minecraft:light_gray_concrete replace
fill ~87 ~30 ~380 ~87 ~30 ~384 minecraft:light_gray_concrete replace
fill ~108 ~30 ~384 ~108 ~30 ~388 minecraft:light_gray_concrete replace
fill ~129 ~30 ~388 ~129 ~30 ~392 minecraft:light_gray_concrete replace
fill ~162 ~30 ~392 ~162 ~30 ~396 minecraft:light_gray_concrete replace
fill ~186 ~30 ~396 ~186 ~30 ~400 minecraft:light_gray_concrete replace
fill ~210 ~30 ~400 ~210 ~30 ~404 minecraft:light_gray_concrete replace
fill ~240 ~30 ~404 ~240 ~30 ~408 minecraft:light_gray_concrete replace
fill ~258 ~30 ~408 ~258 ~30 ~412 minecraft:light_gray_concrete replace
fill ~303 ~30 ~412 ~303 ~30 ~416 minecraft:light_gray_concrete replace
fill ~321 ~30 ~416 ~321 ~30 ~420 minecraft:light_gray_concrete replace
fill ~84 ~30 ~420 ~84 ~30 ~424 minecraft:light_gray_concrete replace
fill ~105 ~30 ~424 ~105 ~30 ~428 minecraft:light_gray_concrete replace
fill ~123 ~30 ~428 ~123 ~30 ~432 minecraft:light_gray_concrete replace
fill ~159 ~30 ~432 ~159 ~30 ~436 minecraft:light_gray_concrete replace
fill ~183 ~30 ~436 ~183 ~30 ~440 minecraft:light_gray_concrete replace
fill ~207 ~30 ~440 ~207 ~30 ~444 minecraft:light_gray_concrete replace
fill ~231 ~30 ~444 ~231 ~30 ~448 minecraft:light_gray_concrete replace
fill ~255 ~30 ~448 ~255 ~30 ~452 minecraft:light_gray_concrete replace
fill ~300 ~30 ~452 ~300 ~30 ~456 minecraft:light_gray_concrete replace
fill ~318 ~30 ~456 ~318 ~30 ~460 minecraft:light_gray_concrete replace
fill ~81 ~30 ~460 ~81 ~30 ~464 minecraft:light_gray_concrete replace
fill ~102 ~30 ~464 ~102 ~30 ~468 minecraft:light_gray_concrete replace
fill ~120 ~30 ~468 ~120 ~30 ~472 minecraft:light_gray_concrete replace
fill ~147 ~30 ~472 ~147 ~30 ~476 minecraft:light_gray_concrete replace
fill ~180 ~30 ~476 ~180 ~30 ~480 minecraft:light_gray_concrete replace
fill ~204 ~30 ~480 ~204 ~30 ~484 minecraft:light_gray_concrete replace
fill ~228 ~30 ~484 ~228 ~30 ~488 minecraft:light_gray_concrete replace
fill ~249 ~30 ~488 ~249 ~30 ~492 minecraft:light_gray_concrete replace
fill ~291 ~30 ~492 ~291 ~30 ~496 minecraft:light_gray_concrete replace
fill ~315 ~30 ~496 ~315 ~30 ~500 minecraft:light_gray_concrete replace
fill ~78 ~30 ~500 ~78 ~30 ~504 minecraft:light_gray_concrete replace
fill ~99 ~30 ~504 ~99 ~30 ~508 minecraft:light_gray_concrete replace
fill ~117 ~30 ~508 ~117 ~30 ~512 minecraft:light_gray_concrete replace
fill ~141 ~30 ~512 ~141 ~30 ~516 minecraft:light_gray_concrete replace
fill ~177 ~30 ~516 ~177 ~30 ~520 minecraft:light_gray_concrete replace
fill ~195 ~30 ~520 ~195 ~30 ~524 minecraft:light_gray_concrete replace
fill ~225 ~30 ~524 ~225 ~30 ~528 minecraft:light_gray_concrete replace
fill ~246 ~30 ~528 ~246 ~30 ~532 minecraft:light_gray_concrete replace
fill ~288 ~30 ~532 ~288 ~30 ~536 minecraft:light_gray_concrete replace
fill ~312 ~30 ~536 ~312 ~30 ~540 minecraft:light_gray_concrete replace
fill ~96 ~30 ~540 ~96 ~30 ~544 minecraft:light_gray_concrete replace
fill ~114 ~30 ~544 ~114 ~30 ~548 minecraft:light_gray_concrete replace
fill ~138 ~30 ~548 ~138 ~30 ~552 minecraft:light_gray_concrete replace
fill ~168 ~30 ~552 ~168 ~30 ~556 minecraft:light_gray_concrete replace
fill ~192 ~30 ~556 ~192 ~30 ~560 minecraft:light_gray_concrete replace
fill ~222 ~30 ~560 ~222 ~30 ~564 minecraft:light_gray_concrete replace
fill ~252 ~30 ~564 ~252 ~30 ~568 minecraft:light_gray_concrete replace
fill ~270 ~30 ~568 ~270 ~30 ~572 minecraft:light_gray_concrete replace
fill ~306 ~30 ~572 ~306 ~30 ~576 minecraft:light_gray_concrete replace
fill ~156 ~30 ~576 ~156 ~30 ~580 minecraft:light_gray_concrete replace
fill ~327 ~30 ~580 ~327 ~30 ~584 minecraft:light_gray_concrete replace
fill ~93 ~30 ~584 ~93 ~30 ~588 minecraft:light_gray_concrete replace
fill ~309 ~30 ~588 ~309 ~30 ~592 minecraft:light_gray_concrete replace
fill ~324 ~30 ~592 ~324 ~30 ~596 minecraft:light_gray_concrete replace
setblock ~126 ~31 ~11 minecraft:light_gray_concrete replace
setblock ~150 ~31 ~19 minecraft:light_gray_concrete replace
setblock ~171 ~31 ~27 minecraft:light_gray_concrete replace
setblock ~198 ~31 ~35 minecraft:light_gray_concrete replace
setblock ~213 ~31 ~43 minecraft:light_gray_concrete replace
setblock ~234 ~31 ~51 minecraft:light_gray_concrete replace
setblock ~264 ~31 ~59 minecraft:light_gray_concrete replace
setblock ~276 ~31 ~63 minecraft:light_gray_concrete replace
setblock ~282 ~31 ~75 minecraft:light_gray_concrete replace
setblock ~297 ~31 ~79 minecraft:light_gray_concrete replace
setblock ~132 ~31 ~259 minecraft:light_gray_concrete replace
setblock ~132 ~31 ~261 minecraft:light_gray_concrete replace
setblock ~133 ~31 ~264 minecraft:light_gray_concrete replace
setblock ~144 ~31 ~267 minecraft:light_gray_concrete replace
setblock ~133 ~31 ~268 minecraft:light_gray_concrete replace
setblock ~153 ~31 ~271 minecraft:light_gray_concrete replace
setblock ~153 ~31 ~273 minecraft:light_gray_concrete replace
setblock ~154 ~31 ~276 minecraft:light_gray_concrete replace
setblock ~174 ~31 ~279 minecraft:light_gray_concrete replace
setblock ~154 ~31 ~280 minecraft:light_gray_concrete replace
setblock ~174 ~31 ~281 minecraft:light_gray_concrete replace
setblock ~175 ~31 ~284 minecraft:light_gray_concrete replace
setblock ~201 ~31 ~287 minecraft:light_gray_concrete replace
setblock ~175 ~31 ~288 minecraft:light_gray_concrete replace
setblock ~201 ~31 ~289 minecraft:light_gray_concrete replace
setblock ~202 ~31 ~292 minecraft:light_gray_concrete replace
setblock ~216 ~31 ~295 minecraft:light_gray_concrete replace
setblock ~202 ~31 ~296 minecraft:light_gray_concrete replace
setblock ~216 ~31 ~297 minecraft:light_gray_concrete replace
setblock ~217 ~31 ~300 minecraft:light_gray_concrete replace
setblock ~237 ~31 ~303 minecraft:light_gray_concrete replace
setblock ~217 ~31 ~304 minecraft:light_gray_concrete replace
setblock ~237 ~31 ~305 minecraft:light_gray_concrete replace
setblock ~238 ~31 ~308 minecraft:light_gray_concrete replace
setblock ~267 ~31 ~311 minecraft:light_gray_concrete replace
setblock ~238 ~31 ~312 minecraft:light_gray_concrete replace
setblock ~267 ~31 ~313 minecraft:light_gray_concrete replace
setblock ~268 ~31 ~316 minecraft:light_gray_concrete replace
setblock ~273 ~31 ~319 minecraft:light_gray_concrete replace
setblock ~268 ~31 ~320 minecraft:light_gray_concrete replace
setblock ~273 ~31 ~321 minecraft:light_gray_concrete replace
setblock ~274 ~31 ~324 minecraft:light_gray_concrete replace
setblock ~279 ~31 ~327 minecraft:light_gray_concrete replace
setblock ~274 ~31 ~328 minecraft:light_gray_concrete replace
setblock ~279 ~31 ~329 minecraft:light_gray_concrete replace
setblock ~280 ~31 ~332 minecraft:light_gray_concrete replace
setblock ~294 ~31 ~335 minecraft:light_gray_concrete replace
setblock ~280 ~31 ~336 minecraft:light_gray_concrete replace
setblock ~294 ~31 ~337 minecraft:light_gray_concrete replace
setblock ~295 ~31 ~340 minecraft:light_gray_concrete replace
setblock ~90 ~31 ~343 minecraft:light_gray_concrete replace
setblock ~295 ~31 ~344 minecraft:light_gray_concrete replace
setblock ~111 ~31 ~347 minecraft:light_gray_concrete replace
setblock ~135 ~31 ~351 minecraft:light_gray_concrete replace
setblock ~165 ~31 ~355 minecraft:light_gray_concrete replace
setblock ~189 ~31 ~359 minecraft:light_gray_concrete replace
setblock ~219 ~31 ~363 minecraft:light_gray_concrete replace
setblock ~243 ~31 ~367 minecraft:light_gray_concrete replace
setblock ~261 ~31 ~371 minecraft:light_gray_concrete replace
setblock ~285 ~31 ~375 minecraft:light_gray_concrete replace
setblock ~87 ~31 ~379 minecraft:light_gray_concrete replace
setblock ~108 ~31 ~383 minecraft:light_gray_concrete replace
setblock ~129 ~31 ~387 minecraft:light_gray_concrete replace
setblock ~162 ~31 ~391 minecraft:light_gray_concrete replace
setblock ~186 ~31 ~395 minecraft:light_gray_concrete replace
setblock ~210 ~31 ~399 minecraft:light_gray_concrete replace
setblock ~240 ~31 ~403 minecraft:light_gray_concrete replace
setblock ~258 ~31 ~407 minecraft:light_gray_concrete replace
setblock ~303 ~31 ~411 minecraft:light_gray_concrete replace
setblock ~321 ~31 ~415 minecraft:light_gray_concrete replace
setblock ~84 ~31 ~419 minecraft:light_gray_concrete replace
setblock ~105 ~31 ~423 minecraft:light_gray_concrete replace
setblock ~123 ~31 ~427 minecraft:light_gray_concrete replace
setblock ~159 ~31 ~431 minecraft:light_gray_concrete replace
setblock ~183 ~31 ~435 minecraft:light_gray_concrete replace
setblock ~207 ~31 ~439 minecraft:light_gray_concrete replace
setblock ~231 ~31 ~443 minecraft:light_gray_concrete replace
setblock ~255 ~31 ~447 minecraft:light_gray_concrete replace
setblock ~300 ~31 ~451 minecraft:light_gray_concrete replace
setblock ~318 ~31 ~455 minecraft:light_gray_concrete replace
setblock ~81 ~31 ~459 minecraft:light_gray_concrete replace
setblock ~102 ~31 ~463 minecraft:light_gray_concrete replace
setblock ~120 ~31 ~467 minecraft:light_gray_concrete replace
setblock ~147 ~31 ~471 minecraft:light_gray_concrete replace
setblock ~180 ~31 ~475 minecraft:light_gray_concrete replace
setblock ~204 ~31 ~479 minecraft:light_gray_concrete replace
setblock ~228 ~31 ~483 minecraft:light_gray_concrete replace
setblock ~249 ~31 ~487 minecraft:light_gray_concrete replace
setblock ~291 ~31 ~491 minecraft:light_gray_concrete replace
setblock ~315 ~31 ~495 minecraft:light_gray_concrete replace
setblock ~78 ~31 ~499 minecraft:light_gray_concrete replace
setblock ~99 ~31 ~503 minecraft:light_gray_concrete replace
setblock ~117 ~31 ~507 minecraft:light_gray_concrete replace
setblock ~141 ~31 ~511 minecraft:light_gray_concrete replace
setblock ~177 ~31 ~515 minecraft:light_gray_concrete replace
setblock ~195 ~31 ~519 minecraft:light_gray_concrete replace
setblock ~225 ~31 ~523 minecraft:light_gray_concrete replace
setblock ~246 ~31 ~527 minecraft:light_gray_concrete replace
setblock ~288 ~31 ~531 minecraft:light_gray_concrete replace
setblock ~312 ~31 ~535 minecraft:light_gray_concrete replace
setblock ~96 ~31 ~539 minecraft:light_gray_concrete replace
setblock ~114 ~31 ~543 minecraft:light_gray_concrete replace
setblock ~138 ~31 ~547 minecraft:light_gray_concrete replace
setblock ~168 ~31 ~551 minecraft:light_gray_concrete replace
setblock ~192 ~31 ~555 minecraft:light_gray_concrete replace
setblock ~222 ~31 ~559 minecraft:light_gray_concrete replace
setblock ~252 ~31 ~563 minecraft:light_gray_concrete replace
setblock ~270 ~31 ~567 minecraft:light_gray_concrete replace
setblock ~306 ~31 ~571 minecraft:light_gray_concrete replace
setblock ~156 ~31 ~575 minecraft:light_gray_concrete replace
setblock ~327 ~31 ~579 minecraft:light_gray_concrete replace
setblock ~93 ~31 ~583 minecraft:light_gray_concrete replace
setblock ~309 ~31 ~587 minecraft:light_gray_concrete replace
setblock ~324 ~31 ~591 minecraft:light_gray_concrete replace
fill ~94 ~32 ~8 ~94 ~32 ~9 minecraft:light_gray_concrete replace
fill ~121 ~32 ~8 ~121 ~32 ~9 minecraft:light_gray_concrete replace
fill ~151 ~32 ~8 ~151 ~32 ~9 minecraft:light_gray_concrete replace
fill ~178 ~32 ~8 ~178 ~32 ~9 minecraft:light_gray_concrete replace
fill ~93 ~32 ~10 ~179 ~32 ~10 minecraft:light_gray_concrete replace
fill ~118 ~32 ~16 ~118 ~32 ~17 minecraft:light_gray_concrete replace
fill ~142 ~32 ~16 ~142 ~32 ~17 minecraft:light_gray_concrete replace
fill ~172 ~32 ~16 ~172 ~32 ~17 minecraft:light_gray_concrete replace
fill ~211 ~32 ~16 ~211 ~32 ~17 minecraft:light_gray_concrete replace
fill ~117 ~32 ~18 ~212 ~32 ~18 minecraft:light_gray_concrete replace
fill ~145 ~32 ~24 ~145 ~32 ~25 minecraft:light_gray_concrete replace
fill ~169 ~32 ~24 ~169 ~32 ~25 minecraft:light_gray_concrete replace
fill ~202 ~32 ~24 ~202 ~32 ~25 minecraft:light_gray_concrete replace
fill ~253 ~32 ~24 ~253 ~32 ~25 minecraft:light_gray_concrete replace
fill ~144 ~32 ~26 ~254 ~32 ~26 minecraft:light_gray_concrete replace
fill ~175 ~32 ~32 ~175 ~32 ~33 minecraft:light_gray_concrete replace
fill ~241 ~32 ~32 ~241 ~32 ~33 minecraft:light_gray_concrete replace
fill ~259 ~32 ~32 ~259 ~32 ~33 minecraft:light_gray_concrete replace
fill ~174 ~32 ~34 ~260 ~32 ~34 minecraft:light_gray_concrete replace
fill ~196 ~32 ~40 ~196 ~32 ~41 minecraft:light_gray_concrete replace
fill ~226 ~32 ~40 ~226 ~32 ~41 minecraft:light_gray_concrete replace
fill ~247 ~32 ~40 ~247 ~32 ~41 minecraft:light_gray_concrete replace
fill ~301 ~32 ~40 ~301 ~32 ~41 minecraft:light_gray_concrete replace
fill ~195 ~32 ~42 ~302 ~32 ~42 minecraft:light_gray_concrete replace
fill ~229 ~32 ~48 ~229 ~32 ~49 minecraft:light_gray_concrete replace
fill ~262 ~32 ~48 ~262 ~32 ~49 minecraft:light_gray_concrete replace
fill ~283 ~32 ~48 ~283 ~32 ~49 minecraft:light_gray_concrete replace
fill ~331 ~32 ~48 ~331 ~32 ~49 minecraft:light_gray_concrete replace
fill ~228 ~32 ~50 ~332 ~32 ~50 minecraft:light_gray_concrete replace
fill ~265 ~32 ~56 ~265 ~32 ~57 minecraft:light_gray_concrete replace
fill ~316 ~32 ~56 ~316 ~32 ~57 minecraft:light_gray_concrete replace
fill ~322 ~32 ~56 ~322 ~32 ~57 minecraft:light_gray_concrete replace
fill ~340 ~32 ~56 ~340 ~32 ~57 minecraft:light_gray_concrete replace
fill ~264 ~32 ~58 ~341 ~32 ~58 minecraft:light_gray_concrete replace
fill ~319 ~32 ~60 ~319 ~32 ~61 minecraft:light_gray_concrete replace
fill ~337 ~32 ~60 ~337 ~32 ~61 minecraft:light_gray_concrete replace
fill ~343 ~32 ~60 ~343 ~32 ~61 minecraft:light_gray_concrete replace
fill ~276 ~32 ~62 ~344 ~32 ~62 minecraft:light_gray_concrete replace
fill ~286 ~32 ~72 ~286 ~32 ~73 minecraft:light_gray_concrete replace
fill ~328 ~32 ~72 ~328 ~32 ~73 minecraft:light_gray_concrete replace
fill ~352 ~32 ~72 ~352 ~32 ~73 minecraft:light_gray_concrete replace
fill ~388 ~32 ~72 ~388 ~32 ~73 minecraft:light_gray_concrete replace
fill ~282 ~32 ~74 ~389 ~32 ~74 minecraft:light_gray_concrete replace
fill ~355 ~32 ~76 ~355 ~32 ~77 minecraft:light_gray_concrete replace
fill ~361 ~32 ~76 ~361 ~32 ~77 minecraft:light_gray_concrete replace
fill ~379 ~32 ~76 ~379 ~32 ~77 minecraft:light_gray_concrete replace
fill ~297 ~32 ~78 ~380 ~32 ~78 minecraft:light_gray_concrete replace
fill ~94 ~32 ~256 ~94 ~32 ~257 minecraft:light_gray_concrete replace
fill ~121 ~32 ~256 ~121 ~32 ~257 minecraft:light_gray_concrete replace
fill ~151 ~32 ~256 ~151 ~32 ~257 minecraft:light_gray_concrete replace
fill ~181 ~32 ~256 ~181 ~32 ~257 minecraft:light_gray_concrete replace
fill ~93 ~32 ~258 ~182 ~32 ~258 minecraft:light_gray_concrete replace
fill ~157 ~32 ~264 ~157 ~32 ~265 minecraft:light_gray_concrete replace
fill ~144 ~32 ~266 ~158 ~32 ~266 minecraft:light_gray_concrete replace
fill ~118 ~32 ~268 ~118 ~32 ~269 minecraft:light_gray_concrete replace
fill ~142 ~32 ~268 ~142 ~32 ~269 minecraft:light_gray_concrete replace
fill ~172 ~32 ~268 ~172 ~32 ~269 minecraft:light_gray_concrete replace
fill ~214 ~32 ~268 ~214 ~32 ~269 minecraft:light_gray_concrete replace
fill ~117 ~32 ~270 ~215 ~32 ~270 minecraft:light_gray_concrete replace
fill ~145 ~32 ~276 ~145 ~32 ~277 minecraft:light_gray_concrete replace
fill ~169 ~32 ~276 ~169 ~32 ~277 minecraft:light_gray_concrete replace
fill ~202 ~32 ~276 ~202 ~32 ~277 minecraft:light_gray_concrete replace
fill ~256 ~32 ~276 ~256 ~32 ~277 minecraft:light_gray_concrete replace
fill ~144 ~32 ~278 ~257 ~32 ~278 minecraft:light_gray_concrete replace
fill ~175 ~32 ~284 ~175 ~32 ~285 minecraft:light_gray_concrete replace
fill ~241 ~32 ~284 ~241 ~32 ~285 minecraft:light_gray_concrete replace
fill ~259 ~32 ~284 ~259 ~32 ~285 minecraft:light_gray_concrete replace
fill ~174 ~32 ~286 ~260 ~32 ~286 minecraft:light_gray_concrete replace
fill ~196 ~32 ~292 ~196 ~32 ~293 minecraft:light_gray_concrete replace
fill ~226 ~32 ~292 ~226 ~32 ~293 minecraft:light_gray_concrete replace
fill ~247 ~32 ~292 ~247 ~32 ~293 minecraft:light_gray_concrete replace
fill ~304 ~32 ~292 ~304 ~32 ~293 minecraft:light_gray_concrete replace
fill ~195 ~32 ~294 ~305 ~32 ~294 minecraft:light_gray_concrete replace
fill ~229 ~32 ~300 ~229 ~32 ~301 minecraft:light_gray_concrete replace
fill ~262 ~32 ~300 ~262 ~32 ~301 minecraft:light_gray_concrete replace
fill ~283 ~32 ~300 ~283 ~32 ~301 minecraft:light_gray_concrete replace
fill ~334 ~32 ~300 ~334 ~32 ~301 minecraft:light_gray_concrete replace
fill ~228 ~32 ~302 ~335 ~32 ~302 minecraft:light_gray_concrete replace
fill ~265 ~32 ~308 ~265 ~32 ~309 minecraft:light_gray_concrete replace
fill ~316 ~32 ~308 ~316 ~32 ~309 minecraft:light_gray_concrete replace
fill ~325 ~32 ~308 ~325 ~32 ~309 minecraft:light_gray_concrete replace
fill ~340 ~32 ~308 ~340 ~32 ~309 minecraft:light_gray_concrete replace
fill ~264 ~32 ~310 ~341 ~32 ~310 minecraft:light_gray_concrete replace
fill ~319 ~32 ~316 ~319 ~32 ~317 minecraft:light_gray_concrete replace
fill ~337 ~32 ~316 ~337 ~32 ~317 minecraft:light_gray_concrete replace
fill ~343 ~32 ~316 ~343 ~32 ~317 minecraft:light_gray_concrete replace
fill ~273 ~32 ~318 ~344 ~32 ~318 minecraft:light_gray_concrete replace
fill ~286 ~32 ~324 ~286 ~32 ~325 minecraft:light_gray_concrete replace
fill ~328 ~32 ~324 ~328 ~32 ~325 minecraft:light_gray_concrete replace
fill ~349 ~32 ~324 ~349 ~32 ~325 minecraft:light_gray_concrete replace
fill ~388 ~32 ~324 ~388 ~32 ~325 minecraft:light_gray_concrete replace
fill ~279 ~32 ~326 ~389 ~32 ~326 minecraft:light_gray_concrete replace
fill ~355 ~32 ~332 ~355 ~32 ~333 minecraft:light_gray_concrete replace
fill ~361 ~32 ~332 ~361 ~32 ~333 minecraft:light_gray_concrete replace
fill ~379 ~32 ~332 ~379 ~32 ~333 minecraft:light_gray_concrete replace
fill ~294 ~32 ~334 ~380 ~32 ~334 minecraft:light_gray_concrete replace
fill ~91 ~32 ~340 ~91 ~32 ~341 minecraft:light_gray_concrete replace
fill ~90 ~32 ~342 ~92 ~32 ~342 minecraft:light_gray_concrete replace
fill ~115 ~32 ~344 ~115 ~32 ~345 minecraft:light_gray_concrete replace
fill ~111 ~32 ~346 ~116 ~32 ~346 minecraft:light_gray_concrete replace
fill ~139 ~32 ~348 ~139 ~32 ~349 minecraft:light_gray_concrete replace
fill ~135 ~32 ~350 ~140 ~32 ~350 minecraft:light_gray_concrete replace
fill ~187 ~32 ~352 ~187 ~32 ~353 minecraft:light_gray_concrete replace
fill ~165 ~32 ~354 ~188 ~32 ~354 minecraft:light_gray_concrete replace
fill ~217 ~32 ~356 ~217 ~32 ~357 minecraft:light_gray_concrete replace
fill ~189 ~32 ~358 ~218 ~32 ~358 minecraft:light_gray_concrete replace
fill ~244 ~32 ~360 ~244 ~32 ~361 minecraft:light_gray_concrete replace
fill ~219 ~32 ~362 ~245 ~32 ~362 minecraft:light_gray_concrete replace
fill ~280 ~32 ~364 ~280 ~32 ~365 minecraft:light_gray_concrete replace
fill ~243 ~32 ~366 ~281 ~32 ~366 minecraft:light_gray_concrete replace
fill ~310 ~32 ~368 ~310 ~32 ~369 minecraft:light_gray_concrete replace
fill ~261 ~32 ~370 ~311 ~32 ~370 minecraft:light_gray_concrete replace
fill ~346 ~32 ~372 ~346 ~32 ~373 minecraft:light_gray_concrete replace
fill ~285 ~32 ~374 ~347 ~32 ~374 minecraft:light_gray_concrete replace
fill ~88 ~32 ~376 ~88 ~32 ~377 minecraft:light_gray_concrete replace
fill ~87 ~32 ~378 ~89 ~32 ~378 minecraft:light_gray_concrete replace
fill ~112 ~32 ~380 ~112 ~32 ~381 minecraft:light_gray_concrete replace
fill ~108 ~32 ~382 ~113 ~32 ~382 minecraft:light_gray_concrete replace
fill ~136 ~32 ~384 ~136 ~32 ~385 minecraft:light_gray_concrete replace
fill ~129 ~32 ~386 ~137 ~32 ~386 minecraft:light_gray_concrete replace
fill ~184 ~32 ~388 ~184 ~32 ~389 minecraft:light_gray_concrete replace
fill ~162 ~32 ~390 ~185 ~32 ~390 minecraft:light_gray_concrete replace
fill ~208 ~32 ~392 ~208 ~32 ~393 minecraft:light_gray_concrete replace
fill ~186 ~32 ~394 ~209 ~32 ~394 minecraft:light_gray_concrete replace
fill ~238 ~32 ~396 ~238 ~32 ~397 minecraft:light_gray_concrete replace
