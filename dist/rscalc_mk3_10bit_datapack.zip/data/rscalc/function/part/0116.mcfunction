setblock ~466 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~389 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~390 ~446 ~169 ~400 minecraft:redstone_wire replace
fill ~452 ~169 ~390 ~452 ~169 ~400 minecraft:redstone_wire replace
fill ~454 ~169 ~390 ~454 ~169 ~400 minecraft:redstone_wire replace
fill ~464 ~169 ~390 ~464 ~169 ~400 minecraft:redstone_wire replace
fill ~466 ~169 ~390 ~466 ~169 ~400 minecraft:redstone_wire replace
fill ~468 ~169 ~390 ~468 ~169 ~400 minecraft:redstone_wire replace
fill ~478 ~169 ~390 ~478 ~169 ~400 minecraft:redstone_wire replace
fill ~480 ~169 ~390 ~480 ~169 ~400 minecraft:redstone_wire replace
setblock ~440 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~393 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~394 ~440 ~169 ~404 minecraft:redstone_wire replace
fill ~444 ~169 ~394 ~444 ~169 ~404 minecraft:redstone_wire replace
fill ~448 ~169 ~394 ~448 ~169 ~404 minecraft:redstone_wire replace
fill ~458 ~169 ~394 ~458 ~169 ~404 minecraft:redstone_wire replace
fill ~460 ~169 ~394 ~460 ~169 ~404 minecraft:redstone_wire replace
fill ~472 ~169 ~394 ~472 ~169 ~404 minecraft:redstone_wire replace
fill ~474 ~169 ~394 ~474 ~169 ~404 minecraft:redstone_wire replace
fill ~494 ~169 ~394 ~494 ~169 ~404 minecraft:redstone_wire replace
setblock ~442 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~492 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~397 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~398 ~442 ~169 ~408 minecraft:redstone_wire replace
fill ~450 ~169 ~398 ~450 ~169 ~408 minecraft:redstone_wire replace
fill ~456 ~169 ~398 ~456 ~169 ~408 minecraft:redstone_wire replace
fill ~462 ~169 ~398 ~462 ~169 ~408 minecraft:redstone_wire replace
fill ~470 ~169 ~398 ~470 ~169 ~408 minecraft:redstone_wire replace
fill ~476 ~169 ~398 ~476 ~169 ~408 minecraft:redstone_wire replace
fill ~500 ~169 ~398 ~500 ~169 ~408 minecraft:redstone_wire replace
fill ~502 ~169 ~398 ~502 ~169 ~408 minecraft:redstone_wire replace
setblock ~446 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~401 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~402 ~446 ~169 ~412 minecraft:redstone_wire replace
fill ~452 ~169 ~402 ~452 ~169 ~412 minecraft:redstone_wire replace
fill ~454 ~169 ~402 ~454 ~169 ~412 minecraft:redstone_wire replace
fill ~464 ~169 ~402 ~464 ~169 ~412 minecraft:redstone_wire replace
fill ~466 ~169 ~402 ~466 ~169 ~412 minecraft:redstone_wire replace
fill ~468 ~169 ~402 ~468 ~169 ~412 minecraft:redstone_wire replace
fill ~478 ~169 ~402 ~478 ~169 ~412 minecraft:redstone_wire replace
fill ~480 ~169 ~402 ~480 ~169 ~412 minecraft:redstone_wire replace
setblock ~440 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~405 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~406 ~440 ~169 ~416 minecraft:redstone_wire replace
fill ~444 ~169 ~406 ~444 ~169 ~416 minecraft:redstone_wire replace
fill ~448 ~169 ~406 ~448 ~169 ~416 minecraft:redstone_wire replace
fill ~458 ~169 ~406 ~458 ~169 ~416 minecraft:redstone_wire replace
fill ~460 ~169 ~406 ~460 ~169 ~416 minecraft:redstone_wire replace
fill ~472 ~169 ~406 ~472 ~169 ~416 minecraft:redstone_wire replace
fill ~474 ~169 ~406 ~474 ~169 ~416 minecraft:redstone_wire replace
fill ~494 ~169 ~406 ~494 ~169 ~416 minecraft:redstone_wire replace
setblock ~442 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~409 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~410 ~442 ~169 ~420 minecraft:redstone_wire replace
fill ~450 ~169 ~410 ~450 ~169 ~420 minecraft:redstone_wire replace
fill ~456 ~169 ~410 ~456 ~169 ~420 minecraft:redstone_wire replace
fill ~462 ~169 ~410 ~462 ~169 ~420 minecraft:redstone_wire replace
fill ~470 ~169 ~410 ~470 ~169 ~420 minecraft:redstone_wire replace
fill ~476 ~169 ~410 ~476 ~169 ~420 minecraft:redstone_wire replace
fill ~500 ~169 ~410 ~500 ~169 ~420 minecraft:redstone_wire replace
fill ~502 ~169 ~410 ~502 ~169 ~420 minecraft:redstone_wire replace
setblock ~446 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~413 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~414 ~446 ~169 ~424 minecraft:redstone_wire replace
fill ~452 ~169 ~414 ~452 ~169 ~424 minecraft:redstone_wire replace
fill ~454 ~169 ~414 ~454 ~169 ~424 minecraft:redstone_wire replace
fill ~464 ~169 ~414 ~464 ~169 ~424 minecraft:redstone_wire replace
fill ~466 ~169 ~414 ~466 ~169 ~424 minecraft:redstone_wire replace
fill ~468 ~169 ~414 ~468 ~169 ~424 minecraft:redstone_wire replace
fill ~478 ~169 ~414 ~478 ~169 ~424 minecraft:redstone_wire replace
fill ~480 ~169 ~414 ~480 ~169 ~424 minecraft:redstone_wire replace
setblock ~440 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~417 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~418 ~440 ~169 ~428 minecraft:redstone_wire replace
fill ~444 ~169 ~418 ~444 ~169 ~428 minecraft:redstone_wire replace
fill ~448 ~169 ~418 ~448 ~169 ~428 minecraft:redstone_wire replace
fill ~458 ~169 ~418 ~458 ~169 ~428 minecraft:redstone_wire replace
fill ~460 ~169 ~418 ~460 ~169 ~428 minecraft:redstone_wire replace
fill ~472 ~169 ~418 ~472 ~169 ~428 minecraft:redstone_wire replace
fill ~474 ~169 ~418 ~474 ~169 ~428 minecraft:redstone_wire replace
fill ~494 ~169 ~418 ~494 ~169 ~428 minecraft:redstone_wire replace
setblock ~442 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~421 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~422 ~442 ~169 ~432 minecraft:redstone_wire replace
fill ~450 ~169 ~422 ~450 ~169 ~432 minecraft:redstone_wire replace
fill ~456 ~169 ~422 ~456 ~169 ~432 minecraft:redstone_wire replace
fill ~462 ~169 ~422 ~462 ~169 ~432 minecraft:redstone_wire replace
fill ~470 ~169 ~422 ~470 ~169 ~432 minecraft:redstone_wire replace
fill ~476 ~169 ~422 ~476 ~169 ~432 minecraft:redstone_wire replace
fill ~500 ~169 ~422 ~500 ~169 ~432 minecraft:redstone_wire replace
fill ~502 ~169 ~422 ~502 ~169 ~432 minecraft:redstone_wire replace
setblock ~446 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~425 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~426 ~446 ~169 ~436 minecraft:redstone_wire replace
fill ~452 ~169 ~426 ~452 ~169 ~436 minecraft:redstone_wire replace
fill ~454 ~169 ~426 ~454 ~169 ~436 minecraft:redstone_wire replace
fill ~464 ~169 ~426 ~464 ~169 ~436 minecraft:redstone_wire replace
fill ~466 ~169 ~426 ~466 ~169 ~436 minecraft:redstone_wire replace
fill ~468 ~169 ~426 ~468 ~169 ~436 minecraft:redstone_wire replace
fill ~478 ~169 ~426 ~478 ~169 ~436 minecraft:redstone_wire replace
fill ~480 ~169 ~426 ~480 ~169 ~436 minecraft:redstone_wire replace
setblock ~440 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~494 ~169 ~429 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~430 ~440 ~169 ~440 minecraft:redstone_wire replace
fill ~444 ~169 ~430 ~444 ~169 ~440 minecraft:redstone_wire replace
fill ~448 ~169 ~430 ~448 ~169 ~440 minecraft:redstone_wire replace
fill ~458 ~169 ~430 ~458 ~169 ~440 minecraft:redstone_wire replace
fill ~460 ~169 ~430 ~460 ~169 ~440 minecraft:redstone_wire replace
fill ~472 ~169 ~430 ~472 ~169 ~440 minecraft:redstone_wire replace
fill ~474 ~169 ~430 ~474 ~169 ~440 minecraft:redstone_wire replace
setblock ~442 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~433 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~434 ~442 ~169 ~444 minecraft:redstone_wire replace
fill ~450 ~169 ~434 ~450 ~169 ~444 minecraft:redstone_wire replace
fill ~456 ~169 ~434 ~456 ~169 ~444 minecraft:redstone_wire replace
fill ~462 ~169 ~434 ~462 ~169 ~444 minecraft:redstone_wire replace
fill ~470 ~169 ~434 ~470 ~169 ~444 minecraft:redstone_wire replace
fill ~476 ~169 ~434 ~476 ~169 ~444 minecraft:redstone_wire replace
fill ~500 ~169 ~434 ~500 ~169 ~444 minecraft:redstone_wire replace
fill ~502 ~169 ~434 ~502 ~169 ~444 minecraft:redstone_wire replace
setblock ~446 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~437 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~438 ~446 ~169 ~448 minecraft:redstone_wire replace
fill ~452 ~169 ~438 ~452 ~169 ~448 minecraft:redstone_wire replace
fill ~454 ~169 ~438 ~454 ~169 ~448 minecraft:redstone_wire replace
fill ~464 ~169 ~438 ~464 ~169 ~448 minecraft:redstone_wire replace
fill ~466 ~169 ~438 ~466 ~169 ~448 minecraft:redstone_wire replace
fill ~468 ~169 ~438 ~468 ~169 ~448 minecraft:redstone_wire replace
fill ~478 ~169 ~438 ~478 ~169 ~448 minecraft:redstone_wire replace
fill ~480 ~169 ~438 ~480 ~169 ~448 minecraft:redstone_wire replace
setblock ~440 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~441 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~442 ~440 ~169 ~452 minecraft:redstone_wire replace
fill ~444 ~169 ~442 ~444 ~169 ~452 minecraft:redstone_wire replace
fill ~448 ~169 ~442 ~448 ~169 ~452 minecraft:redstone_wire replace
fill ~458 ~169 ~442 ~458 ~169 ~452 minecraft:redstone_wire replace
fill ~460 ~169 ~442 ~460 ~169 ~452 minecraft:redstone_wire replace
fill ~472 ~169 ~442 ~472 ~169 ~452 minecraft:redstone_wire replace
fill ~474 ~169 ~442 ~474 ~169 ~452 minecraft:redstone_wire replace
setblock ~442 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~500 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~445 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~446 ~442 ~169 ~456 minecraft:redstone_wire replace
fill ~450 ~169 ~446 ~450 ~169 ~456 minecraft:redstone_wire replace
fill ~456 ~169 ~446 ~456 ~169 ~456 minecraft:redstone_wire replace
fill ~462 ~169 ~446 ~462 ~169 ~456 minecraft:redstone_wire replace
fill ~470 ~169 ~446 ~470 ~169 ~456 minecraft:redstone_wire replace
fill ~476 ~169 ~446 ~476 ~169 ~456 minecraft:redstone_wire replace
fill ~502 ~169 ~446 ~502 ~169 ~456 minecraft:redstone_wire replace
setblock ~446 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~449 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~450 ~446 ~169 ~460 minecraft:redstone_wire replace
fill ~452 ~169 ~450 ~452 ~169 ~460 minecraft:redstone_wire replace
fill ~454 ~169 ~450 ~454 ~169 ~460 minecraft:redstone_wire replace
fill ~464 ~169 ~450 ~464 ~169 ~460 minecraft:redstone_wire replace
fill ~466 ~169 ~450 ~466 ~169 ~460 minecraft:redstone_wire replace
fill ~468 ~169 ~450 ~468 ~169 ~460 minecraft:redstone_wire replace
fill ~478 ~169 ~450 ~478 ~169 ~460 minecraft:redstone_wire replace
fill ~480 ~169 ~450 ~480 ~169 ~460 minecraft:redstone_wire replace
setblock ~440 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~453 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~454 ~440 ~169 ~464 minecraft:redstone_wire replace
fill ~444 ~169 ~454 ~444 ~169 ~464 minecraft:redstone_wire replace
fill ~448 ~169 ~454 ~448 ~169 ~464 minecraft:redstone_wire replace
fill ~458 ~169 ~454 ~458 ~169 ~464 minecraft:redstone_wire replace
fill ~460 ~169 ~454 ~460 ~169 ~464 minecraft:redstone_wire replace
fill ~472 ~169 ~454 ~472 ~169 ~464 minecraft:redstone_wire replace
fill ~474 ~169 ~454 ~474 ~169 ~464 minecraft:redstone_wire replace
setblock ~442 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~457 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~458 ~442 ~169 ~468 minecraft:redstone_wire replace
fill ~450 ~169 ~458 ~450 ~169 ~468 minecraft:redstone_wire replace
fill ~456 ~169 ~458 ~456 ~169 ~468 minecraft:redstone_wire replace
fill ~462 ~169 ~458 ~462 ~169 ~468 minecraft:redstone_wire replace
fill ~470 ~169 ~458 ~470 ~169 ~468 minecraft:redstone_wire replace
fill ~476 ~169 ~458 ~476 ~169 ~468 minecraft:redstone_wire replace
fill ~502 ~169 ~458 ~502 ~169 ~468 minecraft:redstone_wire replace
setblock ~446 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~461 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~462 ~446 ~169 ~472 minecraft:redstone_wire replace
fill ~452 ~169 ~462 ~452 ~169 ~472 minecraft:redstone_wire replace
fill ~454 ~169 ~462 ~454 ~169 ~472 minecraft:redstone_wire replace
fill ~464 ~169 ~462 ~464 ~169 ~472 minecraft:redstone_wire replace
fill ~466 ~169 ~462 ~466 ~169 ~472 minecraft:redstone_wire replace
fill ~468 ~169 ~462 ~468 ~169 ~472 minecraft:redstone_wire replace
fill ~478 ~169 ~462 ~478 ~169 ~472 minecraft:redstone_wire replace
fill ~480 ~169 ~462 ~480 ~169 ~472 minecraft:redstone_wire replace
setblock ~440 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~465 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~466 ~440 ~169 ~476 minecraft:redstone_wire replace
fill ~444 ~169 ~466 ~444 ~169 ~476 minecraft:redstone_wire replace
fill ~448 ~169 ~466 ~448 ~169 ~476 minecraft:redstone_wire replace
fill ~458 ~169 ~466 ~458 ~169 ~476 minecraft:redstone_wire replace
fill ~460 ~169 ~466 ~460 ~169 ~476 minecraft:redstone_wire replace
fill ~472 ~169 ~466 ~472 ~169 ~476 minecraft:redstone_wire replace
fill ~474 ~169 ~466 ~474 ~169 ~476 minecraft:redstone_wire replace
setblock ~442 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~469 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~470 ~442 ~169 ~480 minecraft:redstone_wire replace
fill ~450 ~169 ~470 ~450 ~169 ~480 minecraft:redstone_wire replace
fill ~456 ~169 ~470 ~456 ~169 ~480 minecraft:redstone_wire replace
fill ~462 ~169 ~470 ~462 ~169 ~480 minecraft:redstone_wire replace
fill ~470 ~169 ~470 ~470 ~169 ~480 minecraft:redstone_wire replace
fill ~476 ~169 ~470 ~476 ~169 ~480 minecraft:redstone_wire replace
fill ~502 ~169 ~470 ~502 ~169 ~480 minecraft:redstone_wire replace
setblock ~446 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~473 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~474 ~446 ~169 ~484 minecraft:redstone_wire replace
fill ~452 ~169 ~474 ~452 ~169 ~484 minecraft:redstone_wire replace
fill ~454 ~169 ~474 ~454 ~169 ~484 minecraft:redstone_wire replace
fill ~464 ~169 ~474 ~464 ~169 ~484 minecraft:redstone_wire replace
fill ~466 ~169 ~474 ~466 ~169 ~484 minecraft:redstone_wire replace
fill ~468 ~169 ~474 ~468 ~169 ~484 minecraft:redstone_wire replace
fill ~478 ~169 ~474 ~478 ~169 ~484 minecraft:redstone_wire replace
fill ~480 ~169 ~474 ~480 ~169 ~484 minecraft:redstone_wire replace
setblock ~440 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~477 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~478 ~440 ~169 ~488 minecraft:redstone_wire replace
fill ~444 ~169 ~478 ~444 ~169 ~488 minecraft:redstone_wire replace
fill ~448 ~169 ~478 ~448 ~169 ~488 minecraft:redstone_wire replace
fill ~458 ~169 ~478 ~458 ~169 ~488 minecraft:redstone_wire replace
fill ~460 ~169 ~478 ~460 ~169 ~488 minecraft:redstone_wire replace
fill ~472 ~169 ~478 ~472 ~169 ~488 minecraft:redstone_wire replace
fill ~474 ~169 ~478 ~474 ~169 ~488 minecraft:redstone_wire replace
setblock ~442 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~481 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~482 ~442 ~169 ~492 minecraft:redstone_wire replace
fill ~450 ~169 ~482 ~450 ~169 ~492 minecraft:redstone_wire replace
fill ~456 ~169 ~482 ~456 ~169 ~492 minecraft:redstone_wire replace
fill ~462 ~169 ~482 ~462 ~169 ~492 minecraft:redstone_wire replace
fill ~470 ~169 ~482 ~470 ~169 ~492 minecraft:redstone_wire replace
fill ~476 ~169 ~482 ~476 ~169 ~492 minecraft:redstone_wire replace
fill ~502 ~169 ~482 ~502 ~169 ~492 minecraft:redstone_wire replace
setblock ~446 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~485 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~486 ~446 ~169 ~496 minecraft:redstone_wire replace
fill ~452 ~169 ~486 ~452 ~169 ~496 minecraft:redstone_wire replace
fill ~454 ~169 ~486 ~454 ~169 ~496 minecraft:redstone_wire replace
fill ~464 ~169 ~486 ~464 ~169 ~496 minecraft:redstone_wire replace
fill ~466 ~169 ~486 ~466 ~169 ~496 minecraft:redstone_wire replace
fill ~468 ~169 ~486 ~468 ~169 ~496 minecraft:redstone_wire replace
fill ~478 ~169 ~486 ~478 ~169 ~496 minecraft:redstone_wire replace
fill ~480 ~169 ~486 ~480 ~169 ~496 minecraft:redstone_wire replace
setblock ~440 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~489 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~490 ~440 ~169 ~500 minecraft:redstone_wire replace
fill ~444 ~169 ~490 ~444 ~169 ~500 minecraft:redstone_wire replace
fill ~448 ~169 ~490 ~448 ~169 ~500 minecraft:redstone_wire replace
fill ~458 ~169 ~490 ~458 ~169 ~500 minecraft:redstone_wire replace
fill ~460 ~169 ~490 ~460 ~169 ~500 minecraft:redstone_wire replace
fill ~472 ~169 ~490 ~472 ~169 ~500 minecraft:redstone_wire replace
fill ~474 ~169 ~490 ~474 ~169 ~500 minecraft:redstone_wire replace
setblock ~442 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~493 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~494 ~442 ~169 ~504 minecraft:redstone_wire replace
fill ~450 ~169 ~494 ~450 ~169 ~504 minecraft:redstone_wire replace
fill ~456 ~169 ~494 ~456 ~169 ~504 minecraft:redstone_wire replace
fill ~462 ~169 ~494 ~462 ~169 ~504 minecraft:redstone_wire replace
fill ~470 ~169 ~494 ~470 ~169 ~504 minecraft:redstone_wire replace
fill ~476 ~169 ~494 ~476 ~169 ~504 minecraft:redstone_wire replace
fill ~502 ~169 ~494 ~502 ~169 ~504 minecraft:redstone_wire replace
setblock ~446 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~497 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~498 ~446 ~169 ~508 minecraft:redstone_wire replace
fill ~452 ~169 ~498 ~452 ~169 ~508 minecraft:redstone_wire replace
fill ~454 ~169 ~498 ~454 ~169 ~508 minecraft:redstone_wire replace
fill ~464 ~169 ~498 ~464 ~169 ~508 minecraft:redstone_wire replace
fill ~466 ~169 ~498 ~466 ~169 ~508 minecraft:redstone_wire replace
fill ~468 ~169 ~498 ~468 ~169 ~508 minecraft:redstone_wire replace
fill ~478 ~169 ~498 ~478 ~169 ~508 minecraft:redstone_wire replace
fill ~480 ~169 ~498 ~480 ~169 ~508 minecraft:redstone_wire replace
setblock ~440 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~501 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~502 ~440 ~169 ~512 minecraft:redstone_wire replace
fill ~444 ~169 ~502 ~444 ~169 ~512 minecraft:redstone_wire replace
fill ~448 ~169 ~502 ~448 ~169 ~512 minecraft:redstone_wire replace
fill ~458 ~169 ~502 ~458 ~169 ~512 minecraft:redstone_wire replace
fill ~460 ~169 ~502 ~460 ~169 ~512 minecraft:redstone_wire replace
fill ~472 ~169 ~502 ~472 ~169 ~512 minecraft:redstone_wire replace
fill ~474 ~169 ~502 ~474 ~169 ~512 minecraft:redstone_wire replace
setblock ~442 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~505 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~506 ~442 ~169 ~516 minecraft:redstone_wire replace
fill ~450 ~169 ~506 ~450 ~169 ~516 minecraft:redstone_wire replace
fill ~456 ~169 ~506 ~456 ~169 ~516 minecraft:redstone_wire replace
fill ~462 ~169 ~506 ~462 ~169 ~516 minecraft:redstone_wire replace
fill ~470 ~169 ~506 ~470 ~169 ~516 minecraft:redstone_wire replace
fill ~476 ~169 ~506 ~476 ~169 ~516 minecraft:redstone_wire replace
fill ~502 ~169 ~506 ~502 ~169 ~516 minecraft:redstone_wire replace
setblock ~446 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~509 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~510 ~446 ~169 ~520 minecraft:redstone_wire replace
fill ~452 ~169 ~510 ~452 ~169 ~520 minecraft:redstone_wire replace
fill ~454 ~169 ~510 ~454 ~169 ~520 minecraft:redstone_wire replace
fill ~464 ~169 ~510 ~464 ~169 ~520 minecraft:redstone_wire replace
fill ~466 ~169 ~510 ~466 ~169 ~520 minecraft:redstone_wire replace
fill ~468 ~169 ~510 ~468 ~169 ~520 minecraft:redstone_wire replace
fill ~478 ~169 ~510 ~478 ~169 ~520 minecraft:redstone_wire replace
fill ~480 ~169 ~510 ~480 ~169 ~520 minecraft:redstone_wire replace
setblock ~440 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~513 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~514 ~440 ~169 ~524 minecraft:redstone_wire replace
fill ~444 ~169 ~514 ~444 ~169 ~524 minecraft:redstone_wire replace
fill ~448 ~169 ~514 ~448 ~169 ~524 minecraft:redstone_wire replace
fill ~458 ~169 ~514 ~458 ~169 ~524 minecraft:redstone_wire replace
fill ~460 ~169 ~514 ~460 ~169 ~524 minecraft:redstone_wire replace
fill ~472 ~169 ~514 ~472 ~169 ~524 minecraft:redstone_wire replace
fill ~474 ~169 ~514 ~474 ~169 ~524 minecraft:redstone_wire replace
setblock ~442 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~517 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~518 ~442 ~169 ~528 minecraft:redstone_wire replace
fill ~450 ~169 ~518 ~450 ~169 ~528 minecraft:redstone_wire replace
fill ~456 ~169 ~518 ~456 ~169 ~528 minecraft:redstone_wire replace
fill ~462 ~169 ~518 ~462 ~169 ~528 minecraft:redstone_wire replace
fill ~470 ~169 ~518 ~470 ~169 ~528 minecraft:redstone_wire replace
fill ~476 ~169 ~518 ~476 ~169 ~528 minecraft:redstone_wire replace
fill ~502 ~169 ~518 ~502 ~169 ~528 minecraft:redstone_wire replace
setblock ~446 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~521 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~522 ~446 ~169 ~532 minecraft:redstone_wire replace
fill ~452 ~169 ~522 ~452 ~169 ~532 minecraft:redstone_wire replace
fill ~454 ~169 ~522 ~454 ~169 ~532 minecraft:redstone_wire replace
fill ~464 ~169 ~522 ~464 ~169 ~532 minecraft:redstone_wire replace
fill ~466 ~169 ~522 ~466 ~169 ~532 minecraft:redstone_wire replace
fill ~468 ~169 ~522 ~468 ~169 ~532 minecraft:redstone_wire replace
fill ~478 ~169 ~522 ~478 ~169 ~532 minecraft:redstone_wire replace
fill ~480 ~169 ~522 ~480 ~169 ~532 minecraft:redstone_wire replace
setblock ~440 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~525 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~526 ~440 ~169 ~536 minecraft:redstone_wire replace
fill ~444 ~169 ~526 ~444 ~169 ~536 minecraft:redstone_wire replace
fill ~448 ~169 ~526 ~448 ~169 ~536 minecraft:redstone_wire replace
fill ~458 ~169 ~526 ~458 ~169 ~536 minecraft:redstone_wire replace
fill ~460 ~169 ~526 ~460 ~169 ~536 minecraft:redstone_wire replace
fill ~472 ~169 ~526 ~472 ~169 ~536 minecraft:redstone_wire replace
fill ~474 ~169 ~526 ~474 ~169 ~536 minecraft:redstone_wire replace
setblock ~442 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~529 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~530 ~442 ~169 ~540 minecraft:redstone_wire replace
fill ~450 ~169 ~530 ~450 ~169 ~540 minecraft:redstone_wire replace
fill ~456 ~169 ~530 ~456 ~169 ~540 minecraft:redstone_wire replace
fill ~462 ~169 ~530 ~462 ~169 ~540 minecraft:redstone_wire replace
fill ~470 ~169 ~530 ~470 ~169 ~540 minecraft:redstone_wire replace
fill ~476 ~169 ~530 ~476 ~169 ~540 minecraft:redstone_wire replace
fill ~502 ~169 ~530 ~502 ~169 ~540 minecraft:redstone_wire replace
setblock ~446 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~468 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~533 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~534 ~446 ~169 ~544 minecraft:redstone_wire replace
fill ~452 ~169 ~534 ~452 ~169 ~544 minecraft:redstone_wire replace
fill ~454 ~169 ~534 ~454 ~169 ~544 minecraft:redstone_wire replace
fill ~464 ~169 ~534 ~464 ~169 ~544 minecraft:redstone_wire replace
fill ~466 ~169 ~534 ~466 ~169 ~544 minecraft:redstone_wire replace
fill ~478 ~169 ~534 ~478 ~169 ~544 minecraft:redstone_wire replace
fill ~480 ~169 ~534 ~480 ~169 ~544 minecraft:redstone_wire replace
setblock ~440 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~448 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~458 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~460 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~472 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~474 ~169 ~537 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~440 ~169 ~538 ~440 ~169 ~548 minecraft:redstone_wire replace
fill ~444 ~169 ~538 ~444 ~169 ~548 minecraft:redstone_wire replace
fill ~448 ~169 ~538 ~448 ~169 ~548 minecraft:redstone_wire replace
fill ~458 ~169 ~538 ~458 ~169 ~548 minecraft:redstone_wire replace
fill ~460 ~169 ~538 ~460 ~169 ~548 minecraft:redstone_wire replace
fill ~472 ~169 ~538 ~472 ~169 ~548 minecraft:redstone_wire replace
fill ~474 ~169 ~538 ~474 ~169 ~548 minecraft:redstone_wire replace
setblock ~442 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~450 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~456 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~462 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~470 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~476 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~502 ~169 ~541 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~442 ~169 ~542 ~442 ~169 ~552 minecraft:redstone_wire replace
fill ~450 ~169 ~542 ~450 ~169 ~552 minecraft:redstone_wire replace
fill ~456 ~169 ~542 ~456 ~169 ~552 minecraft:redstone_wire replace
fill ~462 ~169 ~542 ~462 ~169 ~552 minecraft:redstone_wire replace
fill ~470 ~169 ~542 ~470 ~169 ~552 minecraft:redstone_wire replace
fill ~476 ~169 ~542 ~476 ~169 ~552 minecraft:redstone_wire replace
fill ~502 ~169 ~542 ~502 ~169 ~552 minecraft:redstone_wire replace
setblock ~446 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~452 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~454 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~464 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~466 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~478 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~480 ~169 ~545 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
fill ~446 ~169 ~546 ~446 ~169 ~556 minecraft:redstone_wire replace
fill ~452 ~169 ~546 ~452 ~169 ~556 minecraft:redstone_wire replace
fill ~454 ~169 ~546 ~454 ~169 ~556 minecraft:redstone_wire replace
fill ~464 ~169 ~546 ~464 ~169 ~556 minecraft:redstone_wire replace
fill ~466 ~169 ~546 ~466 ~169 ~556 minecraft:redstone_wire replace
fill ~478 ~169 ~546 ~478 ~169 ~556 minecraft:redstone_wire replace
fill ~480 ~169 ~546 ~480 ~169 ~556 minecraft:redstone_wire replace
setblock ~440 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
setblock ~444 ~169 ~549 minecraft:repeater[delay=1,facing=south,locked=false,powered=false] replace
