setblock ~262 ~41 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~261 ~41 ~554 ~264 ~41 ~554 minecraft:redstone_wire replace
setblock ~266 ~41 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~41 ~554 ~281 ~41 ~554 minecraft:redstone_wire replace
setblock ~283 ~41 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~41 ~554 ~291 ~41 ~554 minecraft:redstone_wire replace
setblock ~328 ~41 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~327 ~41 ~558 ~330 ~41 ~558 minecraft:redstone_wire replace
setblock ~332 ~41 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~41 ~558 ~347 ~41 ~558 minecraft:redstone_wire replace
setblock ~349 ~41 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~41 ~558 ~357 ~41 ~558 minecraft:redstone_wire replace
setblock ~352 ~41 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~351 ~41 ~562 ~354 ~41 ~562 minecraft:redstone_wire replace
setblock ~356 ~41 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~41 ~562 ~371 ~41 ~562 minecraft:redstone_wire replace
setblock ~373 ~41 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~41 ~562 ~381 ~41 ~562 minecraft:redstone_wire replace
setblock ~79 ~41 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~41 ~566 ~80 ~41 ~566 minecraft:redstone_wire replace
setblock ~106 ~41 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~41 ~570 ~107 ~41 ~570 minecraft:redstone_wire replace
setblock ~130 ~41 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~41 ~574 ~132 ~41 ~574 minecraft:redstone_wire replace
setblock ~154 ~41 ~577 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~41 ~578 ~154 ~41 ~578 minecraft:redstone_wire replace
setblock ~155 ~41 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~41 ~578 ~162 ~41 ~578 minecraft:redstone_wire replace
setblock ~181 ~41 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~41 ~582 ~188 ~41 ~582 minecraft:redstone_wire replace
setblock ~190 ~41 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~41 ~582 ~198 ~41 ~582 minecraft:redstone_wire replace
setblock ~202 ~41 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~41 ~586 ~209 ~41 ~586 minecraft:redstone_wire replace
setblock ~211 ~41 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~41 ~586 ~219 ~41 ~586 minecraft:redstone_wire replace
setblock ~238 ~41 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~41 ~590 ~240 ~41 ~590 minecraft:redstone_wire replace
setblock ~242 ~41 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~41 ~590 ~257 ~41 ~590 minecraft:redstone_wire replace
setblock ~259 ~41 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~41 ~590 ~267 ~41 ~590 minecraft:redstone_wire replace
setblock ~259 ~41 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~41 ~594 ~261 ~41 ~594 minecraft:redstone_wire replace
setblock ~263 ~41 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~41 ~594 ~278 ~41 ~594 minecraft:redstone_wire replace
setblock ~280 ~41 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~41 ~594 ~288 ~41 ~594 minecraft:redstone_wire replace
setblock ~325 ~41 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~41 ~598 ~327 ~41 ~598 minecraft:redstone_wire replace
setblock ~329 ~41 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~41 ~598 ~344 ~41 ~598 minecraft:redstone_wire replace
setblock ~346 ~41 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~41 ~598 ~354 ~41 ~598 minecraft:redstone_wire replace
setblock ~349 ~41 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~41 ~602 ~351 ~41 ~602 minecraft:redstone_wire replace
setblock ~353 ~41 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~355 ~41 ~602 ~368 ~41 ~602 minecraft:redstone_wire replace
setblock ~370 ~41 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~372 ~41 ~602 ~378 ~41 ~602 minecraft:redstone_wire replace
setblock ~103 ~41 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~41 ~606 ~104 ~41 ~606 minecraft:redstone_wire replace
setblock ~127 ~41 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~41 ~610 ~129 ~41 ~610 minecraft:redstone_wire replace
setblock ~151 ~41 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~41 ~614 ~151 ~41 ~614 minecraft:redstone_wire replace
setblock ~152 ~41 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~41 ~614 ~159 ~41 ~614 minecraft:redstone_wire replace
setblock ~178 ~41 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~41 ~618 ~185 ~41 ~618 minecraft:redstone_wire replace
setblock ~187 ~41 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~41 ~618 ~195 ~41 ~618 minecraft:redstone_wire replace
setblock ~199 ~41 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~41 ~622 ~206 ~41 ~622 minecraft:redstone_wire replace
setblock ~208 ~41 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~41 ~622 ~216 ~41 ~622 minecraft:redstone_wire replace
setblock ~223 ~41 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~222 ~41 ~626 ~230 ~41 ~626 minecraft:redstone_wire replace
setblock ~232 ~41 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~41 ~626 ~240 ~41 ~626 minecraft:redstone_wire replace
setblock ~265 ~41 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~41 ~630 ~267 ~41 ~630 minecraft:redstone_wire replace
setblock ~269 ~41 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~41 ~630 ~284 ~41 ~630 minecraft:redstone_wire replace
setblock ~286 ~41 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~41 ~630 ~294 ~41 ~630 minecraft:redstone_wire replace
setblock ~280 ~41 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~41 ~634 ~282 ~41 ~634 minecraft:redstone_wire replace
setblock ~284 ~41 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~41 ~634 ~299 ~41 ~634 minecraft:redstone_wire replace
setblock ~301 ~41 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~41 ~634 ~309 ~41 ~634 minecraft:redstone_wire replace
setblock ~340 ~41 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~339 ~41 ~638 ~342 ~41 ~638 minecraft:redstone_wire replace
setblock ~344 ~41 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~41 ~638 ~359 ~41 ~638 minecraft:redstone_wire replace
setblock ~361 ~41 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~41 ~638 ~369 ~41 ~638 minecraft:redstone_wire replace
setblock ~160 ~41 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~41 ~642 ~160 ~41 ~642 minecraft:redstone_wire replace
setblock ~161 ~41 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~41 ~642 ~168 ~41 ~642 minecraft:redstone_wire replace
setblock ~367 ~41 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~366 ~41 ~646 ~369 ~41 ~646 minecraft:redstone_wire replace
setblock ~371 ~41 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~373 ~41 ~646 ~386 ~41 ~646 minecraft:redstone_wire replace
setblock ~388 ~41 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~390 ~41 ~646 ~396 ~41 ~646 minecraft:redstone_wire replace
setblock ~100 ~41 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~41 ~650 ~101 ~41 ~650 minecraft:redstone_wire replace
setblock ~343 ~41 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~342 ~41 ~654 ~345 ~41 ~654 minecraft:redstone_wire replace
setblock ~347 ~41 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~349 ~41 ~654 ~362 ~41 ~654 minecraft:redstone_wire replace
setblock ~364 ~41 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~366 ~41 ~654 ~372 ~41 ~654 minecraft:redstone_wire replace
setblock ~364 ~41 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~363 ~41 ~658 ~366 ~41 ~658 minecraft:redstone_wire replace
setblock ~368 ~41 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~41 ~658 ~383 ~41 ~658 minecraft:redstone_wire replace
setblock ~385 ~41 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~387 ~41 ~658 ~393 ~41 ~658 minecraft:redstone_wire replace
setblock ~226 ~42 ~0 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~42 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~42 ~32 minecraft:redstone_wire replace
setblock ~286 ~42 ~36 minecraft:redstone_wire replace
setblock ~229 ~42 ~40 minecraft:redstone_wire replace
setblock ~304 ~42 ~44 minecraft:redstone_wire replace
setblock ~289 ~42 ~48 minecraft:redstone_wire replace
setblock ~295 ~42 ~56 minecraft:redstone_wire replace
setblock ~319 ~42 ~72 minecraft:redstone_wire replace
setblock ~94 ~42 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~42 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~42 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~42 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~42 ~272 minecraft:redstone_wire replace
setblock ~121 ~42 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~42 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~42 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~42 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~42 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~42 ~324 minecraft:redstone_wire replace
setblock ~250 ~42 ~328 minecraft:redstone_wire replace
setblock ~208 ~42 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~42 ~340 minecraft:redstone_wire replace
setblock ~268 ~42 ~344 minecraft:redstone_wire replace
setblock ~235 ~42 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~42 ~356 minecraft:redstone_wire replace
setblock ~307 ~42 ~360 minecraft:redstone_wire replace
setblock ~310 ~42 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~42 ~368 minecraft:redstone_wire replace
setblock ~298 ~42 ~372 minecraft:redstone_wire replace
setblock ~256 ~42 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~42 ~384 minecraft:redstone_wire replace
setblock ~355 ~42 ~388 minecraft:redstone_wire replace
setblock ~322 ~42 ~392 minecraft:redstone_wire replace
setblock ~346 ~42 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~42 ~400 minecraft:redstone_wire replace
setblock ~91 ~42 ~408 minecraft:redstone_wire replace
setblock ~118 ~42 ~412 minecraft:redstone_wire replace
setblock ~142 ~42 ~416 minecraft:redstone_wire replace
setblock ~175 ~42 ~420 minecraft:redstone_wire replace
setblock ~196 ~42 ~424 minecraft:redstone_wire replace
setblock ~220 ~42 ~428 minecraft:redstone_wire replace
setblock ~253 ~42 ~432 minecraft:redstone_wire replace
setblock ~277 ~42 ~436 minecraft:redstone_wire replace
setblock ~313 ~42 ~440 minecraft:redstone_wire replace
setblock ~88 ~42 ~444 minecraft:redstone_wire replace
setblock ~115 ~42 ~448 minecraft:redstone_wire replace
setblock ~139 ~42 ~452 minecraft:redstone_wire replace
setblock ~172 ~42 ~456 minecraft:redstone_wire replace
setblock ~193 ~42 ~460 minecraft:redstone_wire replace
setblock ~217 ~42 ~464 minecraft:redstone_wire replace
setblock ~247 ~42 ~468 minecraft:redstone_wire replace
setblock ~274 ~42 ~472 minecraft:redstone_wire replace
setblock ~337 ~42 ~476 minecraft:redstone_wire replace
setblock ~361 ~42 ~480 minecraft:redstone_wire replace
setblock ~85 ~42 ~484 minecraft:redstone_wire replace
setblock ~112 ~42 ~488 minecraft:redstone_wire replace
setblock ~136 ~42 ~492 minecraft:redstone_wire replace
setblock ~163 ~42 ~496 minecraft:redstone_wire replace
setblock ~190 ~42 ~500 minecraft:redstone_wire replace
setblock ~214 ~42 ~504 minecraft:redstone_wire replace
setblock ~244 ~42 ~508 minecraft:redstone_wire replace
setblock ~271 ~42 ~512 minecraft:redstone_wire replace
setblock ~331 ~42 ~516 minecraft:redstone_wire replace
setblock ~358 ~42 ~520 minecraft:redstone_wire replace
setblock ~82 ~42 ~524 minecraft:redstone_wire replace
setblock ~109 ~42 ~528 minecraft:redstone_wire replace
setblock ~133 ~42 ~532 minecraft:redstone_wire replace
setblock ~157 ~42 ~536 minecraft:redstone_wire replace
setblock ~187 ~42 ~540 minecraft:redstone_wire replace
setblock ~211 ~42 ~544 minecraft:redstone_wire replace
setblock ~241 ~42 ~548 minecraft:redstone_wire replace
setblock ~262 ~42 ~552 minecraft:redstone_wire replace
setblock ~328 ~42 ~556 minecraft:redstone_wire replace
setblock ~352 ~42 ~560 minecraft:redstone_wire replace
setblock ~79 ~42 ~564 minecraft:redstone_wire replace
setblock ~106 ~42 ~568 minecraft:redstone_wire replace
setblock ~130 ~42 ~572 minecraft:redstone_wire replace
setblock ~154 ~42 ~576 minecraft:redstone_wire replace
setblock ~181 ~42 ~580 minecraft:redstone_wire replace
setblock ~202 ~42 ~584 minecraft:redstone_wire replace
setblock ~238 ~42 ~588 minecraft:redstone_wire replace
setblock ~259 ~42 ~592 minecraft:redstone_wire replace
setblock ~325 ~42 ~596 minecraft:redstone_wire replace
setblock ~349 ~42 ~600 minecraft:redstone_wire replace
setblock ~103 ~42 ~604 minecraft:redstone_wire replace
setblock ~127 ~42 ~608 minecraft:redstone_wire replace
setblock ~151 ~42 ~612 minecraft:redstone_wire replace
setblock ~178 ~42 ~616 minecraft:redstone_wire replace
setblock ~199 ~42 ~620 minecraft:redstone_wire replace
setblock ~223 ~42 ~624 minecraft:redstone_wire replace
setblock ~265 ~42 ~628 minecraft:redstone_wire replace
setblock ~280 ~42 ~632 minecraft:redstone_wire replace
setblock ~340 ~42 ~636 minecraft:redstone_wire replace
setblock ~160 ~42 ~640 minecraft:redstone_wire replace
setblock ~367 ~42 ~644 minecraft:redstone_wire replace
setblock ~100 ~42 ~648 minecraft:redstone_wire replace
setblock ~343 ~42 ~652 minecraft:redstone_wire replace
setblock ~364 ~42 ~656 minecraft:redstone_wire replace
fill ~225 ~43 ~0 ~225 ~43 ~12 minecraft:redstone_wire replace
fill ~165 ~43 ~4 ~165 ~43 ~16 minecraft:redstone_wire replace
fill ~144 ~43 ~8 ~144 ~43 ~20 minecraft:redstone_wire replace
setblock ~225 ~43 ~13 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~14 ~225 ~43 ~26 minecraft:redstone_wire replace
setblock ~165 ~43 ~17 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~18 ~165 ~43 ~30 minecraft:redstone_wire replace
setblock ~144 ~43 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~24 ~144 ~43 ~36 minecraft:redstone_wire replace
setblock ~225 ~43 ~28 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~30 ~225 ~43 ~42 minecraft:redstone_wire replace
setblock ~165 ~43 ~32 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~43 ~32 ~300 ~43 ~36 minecraft:redstone_wire replace
fill ~165 ~43 ~34 ~165 ~43 ~46 minecraft:redstone_wire replace
fill ~285 ~43 ~36 ~285 ~43 ~40 minecraft:redstone_wire replace
setblock ~144 ~43 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~40 ~144 ~43 ~52 minecraft:redstone_wire replace
fill ~228 ~43 ~40 ~228 ~43 ~44 minecraft:redstone_wire replace
setblock ~225 ~43 ~44 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~43 ~44 ~303 ~43 ~48 minecraft:redstone_wire replace
fill ~225 ~43 ~46 ~225 ~43 ~58 minecraft:redstone_wire replace
setblock ~165 ~43 ~48 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~43 ~48 ~288 ~43 ~52 minecraft:redstone_wire replace
fill ~165 ~43 ~50 ~165 ~43 ~62 minecraft:redstone_wire replace
setblock ~144 ~43 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~56 ~144 ~43 ~68 minecraft:redstone_wire replace
fill ~294 ~43 ~56 ~294 ~43 ~60 minecraft:redstone_wire replace
setblock ~225 ~43 ~60 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~62 ~225 ~43 ~74 minecraft:redstone_wire replace
setblock ~165 ~43 ~64 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~66 ~165 ~43 ~78 minecraft:redstone_wire replace
setblock ~144 ~43 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~72 ~144 ~43 ~84 minecraft:redstone_wire replace
fill ~318 ~43 ~72 ~318 ~43 ~76 minecraft:redstone_wire replace
setblock ~225 ~43 ~76 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~78 ~225 ~43 ~90 minecraft:redstone_wire replace
setblock ~165 ~43 ~80 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~82 ~165 ~43 ~94 minecraft:redstone_wire replace
setblock ~144 ~43 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~88 ~144 ~43 ~100 minecraft:redstone_wire replace
setblock ~225 ~43 ~92 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~94 ~225 ~43 ~106 minecraft:redstone_wire replace
setblock ~165 ~43 ~96 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~98 ~165 ~43 ~110 minecraft:redstone_wire replace
setblock ~144 ~43 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~104 ~144 ~43 ~116 minecraft:redstone_wire replace
setblock ~225 ~43 ~108 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~110 ~225 ~43 ~122 minecraft:redstone_wire replace
setblock ~165 ~43 ~112 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~114 ~165 ~43 ~126 minecraft:redstone_wire replace
setblock ~144 ~43 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~120 ~144 ~43 ~132 minecraft:redstone_wire replace
setblock ~225 ~43 ~124 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~126 ~225 ~43 ~138 minecraft:redstone_wire replace
setblock ~165 ~43 ~128 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~130 ~165 ~43 ~142 minecraft:redstone_wire replace
setblock ~144 ~43 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~136 ~144 ~43 ~148 minecraft:redstone_wire replace
setblock ~225 ~43 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~142 ~225 ~43 ~154 minecraft:redstone_wire replace
setblock ~165 ~43 ~144 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~146 ~165 ~43 ~158 minecraft:redstone_wire replace
setblock ~144 ~43 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~152 ~144 ~43 ~164 minecraft:redstone_wire replace
setblock ~225 ~43 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~158 ~225 ~43 ~170 minecraft:redstone_wire replace
setblock ~165 ~43 ~160 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~162 ~165 ~43 ~174 minecraft:redstone_wire replace
setblock ~144 ~43 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~168 ~144 ~43 ~180 minecraft:redstone_wire replace
setblock ~225 ~43 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~174 ~225 ~43 ~186 minecraft:redstone_wire replace
setblock ~165 ~43 ~176 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~178 ~165 ~43 ~190 minecraft:redstone_wire replace
setblock ~144 ~43 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~184 ~144 ~43 ~196 minecraft:redstone_wire replace
setblock ~225 ~43 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~190 ~225 ~43 ~202 minecraft:redstone_wire replace
setblock ~165 ~43 ~192 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~194 ~165 ~43 ~206 minecraft:redstone_wire replace
setblock ~144 ~43 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~200 ~144 ~43 ~212 minecraft:redstone_wire replace
setblock ~225 ~43 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~206 ~225 ~43 ~218 minecraft:redstone_wire replace
setblock ~165 ~43 ~208 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~210 ~165 ~43 ~222 minecraft:redstone_wire replace
setblock ~144 ~43 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~216 ~144 ~43 ~228 minecraft:redstone_wire replace
setblock ~225 ~43 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~222 ~225 ~43 ~234 minecraft:redstone_wire replace
setblock ~165 ~43 ~224 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~226 ~165 ~43 ~238 minecraft:redstone_wire replace
setblock ~144 ~43 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~232 ~144 ~43 ~244 minecraft:redstone_wire replace
setblock ~225 ~43 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~238 ~225 ~43 ~250 minecraft:redstone_wire replace
setblock ~165 ~43 ~240 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~242 ~165 ~43 ~254 minecraft:redstone_wire replace
fill ~93 ~43 ~244 ~93 ~43 ~248 minecraft:redstone_wire replace
setblock ~144 ~43 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~43 ~248 ~123 ~43 ~260 minecraft:redstone_wire replace
fill ~144 ~43 ~248 ~144 ~43 ~260 minecraft:redstone_wire replace
setblock ~225 ~43 ~251 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~252 ~225 ~43 ~264 minecraft:redstone_wire replace
setblock ~165 ~43 ~255 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~256 ~165 ~43 ~268 minecraft:redstone_wire replace
setblock ~144 ~43 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~43 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~262 ~144 ~43 ~274 minecraft:redstone_wire replace
fill ~123 ~43 ~264 ~123 ~43 ~268 minecraft:redstone_wire replace
setblock ~225 ~43 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~268 ~225 ~43 ~280 minecraft:redstone_wire replace
setblock ~165 ~43 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~43 ~272 ~96 ~43 ~276 minecraft:redstone_wire replace
fill ~165 ~43 ~272 ~165 ~43 ~284 minecraft:redstone_wire replace
fill ~120 ~43 ~276 ~120 ~43 ~280 minecraft:redstone_wire replace
setblock ~144 ~43 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~278 ~144 ~43 ~284 minecraft:redstone_wire replace
setblock ~225 ~43 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~284 ~225 ~43 ~296 minecraft:redstone_wire replace
setblock ~165 ~43 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~288 ~165 ~43 ~298 minecraft:redstone_wire replace
fill ~147 ~43 ~292 ~147 ~43 ~296 minecraft:redstone_wire replace
setblock ~225 ~43 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~43 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~300 ~225 ~43 ~312 minecraft:redstone_wire replace
fill ~168 ~43 ~308 ~168 ~43 ~312 minecraft:redstone_wire replace
setblock ~225 ~43 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~316 ~225 ~43 ~320 minecraft:redstone_wire replace
fill ~183 ~43 ~320 ~183 ~43 ~324 minecraft:redstone_wire replace
fill ~204 ~43 ~324 ~204 ~43 ~328 minecraft:redstone_wire replace
fill ~249 ~43 ~328 ~249 ~43 ~332 minecraft:redstone_wire replace
fill ~207 ~43 ~336 ~207 ~43 ~340 minecraft:redstone_wire replace
fill ~231 ~43 ~340 ~231 ~43 ~344 minecraft:redstone_wire replace
fill ~267 ~43 ~344 ~267 ~43 ~348 minecraft:redstone_wire replace
fill ~234 ~43 ~352 ~234 ~43 ~356 minecraft:redstone_wire replace
fill ~291 ~43 ~356 ~291 ~43 ~360 minecraft:redstone_wire replace
fill ~306 ~43 ~360 ~306 ~43 ~364 minecraft:redstone_wire replace
fill ~309 ~43 ~364 ~309 ~43 ~368 minecraft:redstone_wire replace
fill ~282 ~43 ~368 ~282 ~43 ~372 minecraft:redstone_wire replace
fill ~297 ~43 ~372 ~297 ~43 ~376 minecraft:redstone_wire replace
fill ~255 ~43 ~380 ~255 ~43 ~384 minecraft:redstone_wire replace
fill ~333 ~43 ~384 ~333 ~43 ~388 minecraft:redstone_wire replace
fill ~354 ~43 ~388 ~354 ~43 ~392 minecraft:redstone_wire replace
fill ~321 ~43 ~392 ~321 ~43 ~396 minecraft:redstone_wire replace
fill ~345 ~43 ~396 ~345 ~43 ~400 minecraft:redstone_wire replace
fill ~315 ~43 ~400 ~315 ~43 ~404 minecraft:redstone_wire replace
fill ~90 ~43 ~408 ~90 ~43 ~412 minecraft:redstone_wire replace
fill ~117 ~43 ~412 ~117 ~43 ~416 minecraft:redstone_wire replace
fill ~141 ~43 ~416 ~141 ~43 ~420 minecraft:redstone_wire replace
fill ~174 ~43 ~420 ~174 ~43 ~424 minecraft:redstone_wire replace
fill ~195 ~43 ~424 ~195 ~43 ~428 minecraft:redstone_wire replace
fill ~219 ~43 ~428 ~219 ~43 ~432 minecraft:redstone_wire replace
fill ~252 ~43 ~432 ~252 ~43 ~436 minecraft:redstone_wire replace
fill ~276 ~43 ~436 ~276 ~43 ~440 minecraft:redstone_wire replace
fill ~312 ~43 ~440 ~312 ~43 ~444 minecraft:redstone_wire replace
fill ~87 ~43 ~444 ~87 ~43 ~448 minecraft:redstone_wire replace
fill ~114 ~43 ~448 ~114 ~43 ~452 minecraft:redstone_wire replace
fill ~138 ~43 ~452 ~138 ~43 ~456 minecraft:redstone_wire replace
fill ~171 ~43 ~456 ~171 ~43 ~460 minecraft:redstone_wire replace
fill ~192 ~43 ~460 ~192 ~43 ~464 minecraft:redstone_wire replace
fill ~216 ~43 ~464 ~216 ~43 ~468 minecraft:redstone_wire replace
fill ~246 ~43 ~468 ~246 ~43 ~472 minecraft:redstone_wire replace
fill ~273 ~43 ~472 ~273 ~43 ~476 minecraft:redstone_wire replace
fill ~336 ~43 ~476 ~336 ~43 ~480 minecraft:redstone_wire replace
fill ~360 ~43 ~480 ~360 ~43 ~484 minecraft:redstone_wire replace
fill ~84 ~43 ~484 ~84 ~43 ~488 minecraft:redstone_wire replace
fill ~111 ~43 ~488 ~111 ~43 ~492 minecraft:redstone_wire replace
fill ~135 ~43 ~492 ~135 ~43 ~496 minecraft:redstone_wire replace
fill ~162 ~43 ~496 ~162 ~43 ~500 minecraft:redstone_wire replace
fill ~189 ~43 ~500 ~189 ~43 ~504 minecraft:redstone_wire replace
fill ~213 ~43 ~504 ~213 ~43 ~508 minecraft:redstone_wire replace
fill ~243 ~43 ~508 ~243 ~43 ~512 minecraft:redstone_wire replace
fill ~270 ~43 ~512 ~270 ~43 ~516 minecraft:redstone_wire replace
fill ~330 ~43 ~516 ~330 ~43 ~520 minecraft:redstone_wire replace
fill ~357 ~43 ~520 ~357 ~43 ~524 minecraft:redstone_wire replace
fill ~81 ~43 ~524 ~81 ~43 ~528 minecraft:redstone_wire replace
fill ~108 ~43 ~528 ~108 ~43 ~532 minecraft:redstone_wire replace
fill ~132 ~43 ~532 ~132 ~43 ~536 minecraft:redstone_wire replace
fill ~156 ~43 ~536 ~156 ~43 ~540 minecraft:redstone_wire replace
fill ~186 ~43 ~540 ~186 ~43 ~544 minecraft:redstone_wire replace
fill ~210 ~43 ~544 ~210 ~43 ~548 minecraft:redstone_wire replace
fill ~240 ~43 ~548 ~240 ~43 ~552 minecraft:redstone_wire replace
fill ~261 ~43 ~552 ~261 ~43 ~556 minecraft:redstone_wire replace
fill ~327 ~43 ~556 ~327 ~43 ~560 minecraft:redstone_wire replace
fill ~351 ~43 ~560 ~351 ~43 ~564 minecraft:redstone_wire replace
fill ~78 ~43 ~564 ~78 ~43 ~568 minecraft:redstone_wire replace
fill ~105 ~43 ~568 ~105 ~43 ~572 minecraft:redstone_wire replace
fill ~129 ~43 ~572 ~129 ~43 ~576 minecraft:redstone_wire replace
fill ~153 ~43 ~576 ~153 ~43 ~580 minecraft:redstone_wire replace
fill ~180 ~43 ~580 ~180 ~43 ~584 minecraft:redstone_wire replace
fill ~201 ~43 ~584 ~201 ~43 ~588 minecraft:redstone_wire replace
fill ~237 ~43 ~588 ~237 ~43 ~592 minecraft:redstone_wire replace
fill ~258 ~43 ~592 ~258 ~43 ~596 minecraft:redstone_wire replace
fill ~324 ~43 ~596 ~324 ~43 ~600 minecraft:redstone_wire replace
fill ~348 ~43 ~600 ~348 ~43 ~604 minecraft:redstone_wire replace
fill ~102 ~43 ~604 ~102 ~43 ~608 minecraft:redstone_wire replace
fill ~126 ~43 ~608 ~126 ~43 ~612 minecraft:redstone_wire replace
fill ~150 ~43 ~612 ~150 ~43 ~616 minecraft:redstone_wire replace
fill ~177 ~43 ~616 ~177 ~43 ~620 minecraft:redstone_wire replace
fill ~198 ~43 ~620 ~198 ~43 ~624 minecraft:redstone_wire replace
fill ~222 ~43 ~624 ~222 ~43 ~628 minecraft:redstone_wire replace
fill ~264 ~43 ~628 ~264 ~43 ~632 minecraft:redstone_wire replace
fill ~279 ~43 ~632 ~279 ~43 ~636 minecraft:redstone_wire replace
fill ~339 ~43 ~636 ~339 ~43 ~640 minecraft:redstone_wire replace
fill ~159 ~43 ~640 ~159 ~43 ~644 minecraft:redstone_wire replace
fill ~366 ~43 ~644 ~366 ~43 ~648 minecraft:redstone_wire replace
fill ~99 ~43 ~648 ~99 ~43 ~652 minecraft:redstone_wire replace
fill ~342 ~43 ~652 ~342 ~43 ~656 minecraft:redstone_wire replace
fill ~363 ~43 ~656 ~363 ~43 ~660 minecraft:redstone_wire replace
setblock ~300 ~44 ~37 minecraft:redstone_wire replace
setblock ~285 ~44 ~41 minecraft:redstone_wire replace
setblock ~228 ~44 ~45 minecraft:redstone_wire replace
setblock ~303 ~44 ~49 minecraft:redstone_wire replace
setblock ~288 ~44 ~53 minecraft:redstone_wire replace
setblock ~294 ~44 ~61 minecraft:redstone_wire replace
setblock ~318 ~44 ~77 minecraft:redstone_wire replace
setblock ~93 ~44 ~249 minecraft:redstone_wire replace
setblock ~123 ~44 ~269 minecraft:redstone_wire replace
setblock ~96 ~44 ~277 minecraft:redstone_wire replace
setblock ~120 ~44 ~281 minecraft:redstone_wire replace
setblock ~144 ~44 ~285 minecraft:redstone_wire replace
setblock ~147 ~44 ~297 minecraft:redstone_wire replace
setblock ~165 ~44 ~301 minecraft:redstone_wire replace
setblock ~168 ~44 ~313 minecraft:redstone_wire replace
setblock ~225 ~44 ~321 minecraft:redstone_wire replace
setblock ~183 ~44 ~325 minecraft:redstone_wire replace
setblock ~204 ~44 ~329 minecraft:redstone_wire replace
setblock ~249 ~44 ~333 minecraft:redstone_wire replace
setblock ~207 ~44 ~341 minecraft:redstone_wire replace
setblock ~231 ~44 ~345 minecraft:redstone_wire replace
setblock ~267 ~44 ~349 minecraft:redstone_wire replace
setblock ~234 ~44 ~357 minecraft:redstone_wire replace
setblock ~291 ~44 ~361 minecraft:redstone_wire replace
setblock ~306 ~44 ~365 minecraft:redstone_wire replace
setblock ~309 ~44 ~369 minecraft:redstone_wire replace
setblock ~282 ~44 ~373 minecraft:redstone_wire replace
setblock ~297 ~44 ~377 minecraft:redstone_wire replace
setblock ~255 ~44 ~385 minecraft:redstone_wire replace
setblock ~333 ~44 ~389 minecraft:redstone_wire replace
setblock ~354 ~44 ~393 minecraft:redstone_wire replace
setblock ~321 ~44 ~397 minecraft:redstone_wire replace
setblock ~345 ~44 ~401 minecraft:redstone_wire replace
setblock ~315 ~44 ~405 minecraft:redstone_wire replace
setblock ~90 ~44 ~413 minecraft:redstone_wire replace
setblock ~117 ~44 ~417 minecraft:redstone_wire replace
setblock ~141 ~44 ~421 minecraft:redstone_wire replace
setblock ~174 ~44 ~425 minecraft:redstone_wire replace
setblock ~195 ~44 ~429 minecraft:redstone_wire replace
setblock ~219 ~44 ~433 minecraft:redstone_wire replace
setblock ~252 ~44 ~437 minecraft:redstone_wire replace
setblock ~276 ~44 ~441 minecraft:redstone_wire replace
setblock ~312 ~44 ~445 minecraft:redstone_wire replace
setblock ~87 ~44 ~449 minecraft:redstone_wire replace
setblock ~114 ~44 ~453 minecraft:redstone_wire replace
setblock ~138 ~44 ~457 minecraft:redstone_wire replace
setblock ~171 ~44 ~461 minecraft:redstone_wire replace
setblock ~192 ~44 ~465 minecraft:redstone_wire replace
setblock ~216 ~44 ~469 minecraft:redstone_wire replace
setblock ~246 ~44 ~473 minecraft:redstone_wire replace
setblock ~273 ~44 ~477 minecraft:redstone_wire replace
setblock ~336 ~44 ~481 minecraft:redstone_wire replace
setblock ~360 ~44 ~485 minecraft:redstone_wire replace
setblock ~84 ~44 ~489 minecraft:redstone_wire replace
setblock ~111 ~44 ~493 minecraft:redstone_wire replace
setblock ~135 ~44 ~497 minecraft:redstone_wire replace
setblock ~162 ~44 ~501 minecraft:redstone_wire replace
setblock ~189 ~44 ~505 minecraft:redstone_wire replace
setblock ~213 ~44 ~509 minecraft:redstone_wire replace
setblock ~243 ~44 ~513 minecraft:redstone_wire replace
setblock ~270 ~44 ~517 minecraft:redstone_wire replace
setblock ~330 ~44 ~521 minecraft:redstone_wire replace
setblock ~357 ~44 ~525 minecraft:redstone_wire replace
setblock ~81 ~44 ~529 minecraft:redstone_wire replace
setblock ~108 ~44 ~533 minecraft:redstone_wire replace
setblock ~132 ~44 ~537 minecraft:redstone_wire replace
setblock ~156 ~44 ~541 minecraft:redstone_wire replace
setblock ~186 ~44 ~545 minecraft:redstone_wire replace
setblock ~210 ~44 ~549 minecraft:redstone_wire replace
setblock ~240 ~44 ~553 minecraft:redstone_wire replace
setblock ~261 ~44 ~557 minecraft:redstone_wire replace
setblock ~327 ~44 ~561 minecraft:redstone_wire replace
setblock ~351 ~44 ~565 minecraft:redstone_wire replace
setblock ~78 ~44 ~569 minecraft:redstone_wire replace
setblock ~105 ~44 ~573 minecraft:redstone_wire replace
setblock ~129 ~44 ~577 minecraft:redstone_wire replace
setblock ~153 ~44 ~581 minecraft:redstone_wire replace
setblock ~180 ~44 ~585 minecraft:redstone_wire replace
setblock ~201 ~44 ~589 minecraft:redstone_wire replace
setblock ~237 ~44 ~593 minecraft:redstone_wire replace
setblock ~258 ~44 ~597 minecraft:redstone_wire replace
setblock ~324 ~44 ~601 minecraft:redstone_wire replace
setblock ~348 ~44 ~605 minecraft:redstone_wire replace
setblock ~102 ~44 ~609 minecraft:redstone_wire replace
setblock ~126 ~44 ~613 minecraft:redstone_wire replace
setblock ~150 ~44 ~617 minecraft:redstone_wire replace
setblock ~177 ~44 ~621 minecraft:redstone_wire replace
setblock ~198 ~44 ~625 minecraft:redstone_wire replace
setblock ~222 ~44 ~629 minecraft:redstone_wire replace
setblock ~264 ~44 ~633 minecraft:redstone_wire replace
setblock ~279 ~44 ~637 minecraft:redstone_wire replace
setblock ~339 ~44 ~641 minecraft:redstone_wire replace
setblock ~159 ~44 ~645 minecraft:redstone_wire replace
setblock ~366 ~44 ~649 minecraft:redstone_wire replace
setblock ~99 ~44 ~653 minecraft:redstone_wire replace
setblock ~342 ~44 ~657 minecraft:redstone_wire replace
setblock ~363 ~44 ~661 minecraft:redstone_wire replace
fill ~300 ~45 ~38 ~302 ~45 ~38 minecraft:redstone_wire replace
setblock ~301 ~45 ~39 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~285 ~45 ~42 ~287 ~45 ~42 minecraft:redstone_wire replace
setblock ~286 ~45 ~43 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~45 ~46 ~233 ~45 ~46 minecraft:redstone_wire replace
setblock ~234 ~45 ~46 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~45 ~46 ~236 ~45 ~46 minecraft:redstone_wire replace
setblock ~235 ~45 ~47 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~45 ~50 ~305 ~45 ~50 minecraft:redstone_wire replace
setblock ~304 ~45 ~51 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~45 ~54 ~290 ~45 ~54 minecraft:redstone_wire replace
setblock ~289 ~45 ~55 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~45 ~62 ~294 ~45 ~62 minecraft:redstone_wire replace
setblock ~292 ~45 ~63 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~318 ~45 ~78 ~320 ~45 ~78 minecraft:redstone_wire replace
setblock ~319 ~45 ~79 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~45 ~250 ~98 ~45 ~250 minecraft:redstone_wire replace
setblock ~94 ~45 ~251 minecraft:redstone_wire replace
setblock ~97 ~45 ~251 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~45 ~270 ~125 ~45 ~270 minecraft:redstone_wire replace
setblock ~121 ~45 ~271 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~45 ~271 minecraft:redstone_wire replace
fill ~93 ~45 ~278 ~98 ~45 ~278 minecraft:redstone_wire replace
setblock ~94 ~45 ~279 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~45 ~279 minecraft:redstone_wire replace
fill ~120 ~45 ~282 ~125 ~45 ~282 minecraft:redstone_wire replace
setblock ~121 ~45 ~283 minecraft:redstone_wire replace
setblock ~124 ~45 ~283 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~45 ~286 ~149 ~45 ~286 minecraft:redstone_wire replace
setblock ~145 ~45 ~287 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~45 ~287 minecraft:redstone_wire replace
fill ~144 ~45 ~298 ~149 ~45 ~298 minecraft:redstone_wire replace
setblock ~145 ~45 ~299 minecraft:redstone_wire replace
setblock ~148 ~45 ~299 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~45 ~302 ~170 ~45 ~302 minecraft:redstone_wire replace
setblock ~166 ~45 ~303 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~169 ~45 ~303 minecraft:redstone_wire replace
fill ~165 ~45 ~314 ~170 ~45 ~314 minecraft:redstone_wire replace
setblock ~166 ~45 ~315 minecraft:redstone_wire replace
setblock ~169 ~45 ~315 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~45 ~322 ~185 ~45 ~322 minecraft:redstone_wire replace
setblock ~186 ~45 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~45 ~322 ~200 ~45 ~322 minecraft:redstone_wire replace
setblock ~202 ~45 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~45 ~322 ~216 ~45 ~322 minecraft:redstone_wire replace
setblock ~218 ~45 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~45 ~322 ~230 ~45 ~322 minecraft:redstone_wire replace
setblock ~231 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~232 ~45 ~322 ~244 ~45 ~322 minecraft:redstone_wire replace
setblock ~246 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~248 ~45 ~322 ~260 ~45 ~322 minecraft:redstone_wire replace
setblock ~262 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~264 ~45 ~322 ~276 ~45 ~322 minecraft:redstone_wire replace
setblock ~278 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~280 ~45 ~322 ~292 ~45 ~322 minecraft:redstone_wire replace
setblock ~294 ~45 ~322 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~296 ~45 ~322 ~299 ~45 ~322 minecraft:redstone_wire replace
setblock ~184 ~45 ~323 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~187 ~45 ~323 minecraft:redstone_wire replace
setblock ~208 ~45 ~323 minecraft:redstone_wire replace
setblock ~232 ~45 ~323 minecraft:redstone_wire replace
setblock ~283 ~45 ~323 minecraft:redstone_wire replace
setblock ~298 ~45 ~323 minecraft:redstone_wire replace
fill ~183 ~45 ~326 ~188 ~45 ~326 minecraft:redstone_wire replace
