setblock ~116 ~105 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~105 ~618 ~123 ~105 ~618 minecraft:redstone_wire replace
setblock ~115 ~105 ~621 minecraft:redstone_wire replace
fill ~114 ~105 ~622 ~122 ~105 ~622 minecraft:redstone_wire replace
setblock ~124 ~105 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~105 ~622 ~132 ~105 ~622 minecraft:redstone_wire replace
setblock ~118 ~105 ~629 minecraft:redstone_wire replace
fill ~117 ~105 ~630 ~128 ~105 ~630 minecraft:redstone_wire replace
setblock ~130 ~105 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~105 ~630 ~138 ~105 ~630 minecraft:redstone_wire replace
setblock ~127 ~105 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~105 ~642 ~137 ~105 ~642 minecraft:redstone_wire replace
setblock ~139 ~105 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~105 ~642 ~147 ~105 ~642 minecraft:redstone_wire replace
setblock ~85 ~105 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~105 ~646 ~86 ~105 ~646 minecraft:redstone_wire replace
setblock ~121 ~105 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~105 ~650 ~131 ~105 ~650 minecraft:redstone_wire replace
setblock ~133 ~105 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~105 ~650 ~141 ~105 ~650 minecraft:redstone_wire replace
setblock ~124 ~105 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~105 ~658 ~134 ~105 ~658 minecraft:redstone_wire replace
setblock ~136 ~105 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~105 ~658 ~144 ~105 ~658 minecraft:redstone_wire replace
setblock ~112 ~106 ~380 minecraft:redstone_wire replace
setblock ~82 ~106 ~392 minecraft:redstone_wire replace
setblock ~88 ~106 ~552 minecraft:redstone_wire replace
setblock ~79 ~106 ~556 minecraft:redstone_wire replace
setblock ~91 ~106 ~560 minecraft:redstone_wire replace
setblock ~94 ~106 ~564 minecraft:redstone_wire replace
setblock ~97 ~106 ~568 minecraft:redstone_wire replace
setblock ~100 ~106 ~572 minecraft:redstone_wire replace
setblock ~115 ~106 ~576 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~106 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~106 ~584 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~106 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~106 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~106 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~106 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~106 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~106 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~106 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~106 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~106 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~106 ~640 minecraft:redstone_wire replace
setblock ~85 ~106 ~644 minecraft:redstone_wire replace
setblock ~121 ~106 ~648 minecraft:redstone_wire replace
setblock ~124 ~106 ~656 minecraft:redstone_wire replace
fill ~111 ~107 ~380 ~111 ~107 ~384 minecraft:redstone_wire replace
fill ~81 ~107 ~392 ~81 ~107 ~396 minecraft:redstone_wire replace
fill ~87 ~107 ~552 ~87 ~107 ~556 minecraft:redstone_wire replace
fill ~78 ~107 ~556 ~78 ~107 ~560 minecraft:redstone_wire replace
fill ~90 ~107 ~560 ~90 ~107 ~564 minecraft:redstone_wire replace
fill ~93 ~107 ~564 ~93 ~107 ~568 minecraft:redstone_wire replace
fill ~96 ~107 ~568 ~96 ~107 ~572 minecraft:redstone_wire replace
fill ~99 ~107 ~572 ~99 ~107 ~576 minecraft:redstone_wire replace
fill ~114 ~107 ~576 ~114 ~107 ~588 minecraft:redstone_wire replace
fill ~108 ~107 ~580 ~108 ~107 ~592 minecraft:redstone_wire replace
fill ~105 ~107 ~588 ~105 ~107 ~598 minecraft:redstone_wire replace
setblock ~114 ~107 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~107 ~592 ~114 ~107 ~604 minecraft:redstone_wire replace
setblock ~108 ~107 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~107 ~596 ~108 ~107 ~608 minecraft:redstone_wire replace
fill ~102 ~107 ~600 ~102 ~107 ~606 minecraft:redstone_wire replace
setblock ~105 ~107 ~600 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~107 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~102 ~107 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~107 ~608 ~114 ~107 ~620 minecraft:redstone_wire replace
setblock ~108 ~107 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~107 ~612 ~108 ~107 ~618 minecraft:redstone_wire replace
setblock ~108 ~107 ~620 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~114 ~107 ~621 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~107 ~622 ~114 ~107 ~624 minecraft:redstone_wire replace
fill ~117 ~107 ~628 ~117 ~107 ~632 minecraft:redstone_wire replace
fill ~126 ~107 ~640 ~126 ~107 ~644 minecraft:redstone_wire replace
fill ~84 ~107 ~644 ~84 ~107 ~648 minecraft:redstone_wire replace
fill ~120 ~107 ~648 ~120 ~107 ~652 minecraft:redstone_wire replace
fill ~123 ~107 ~656 ~123 ~107 ~660 minecraft:redstone_wire replace
setblock ~111 ~108 ~385 minecraft:redstone_wire replace
setblock ~81 ~108 ~397 minecraft:redstone_wire replace
setblock ~87 ~108 ~557 minecraft:redstone_wire replace
setblock ~78 ~108 ~561 minecraft:redstone_wire replace
setblock ~90 ~108 ~565 minecraft:redstone_wire replace
setblock ~93 ~108 ~569 minecraft:redstone_wire replace
setblock ~96 ~108 ~573 minecraft:redstone_wire replace
setblock ~99 ~108 ~577 minecraft:redstone_wire replace
setblock ~105 ~108 ~601 minecraft:redstone_wire replace
setblock ~102 ~108 ~609 minecraft:redstone_wire replace
setblock ~108 ~108 ~621 minecraft:redstone_wire replace
setblock ~114 ~108 ~625 minecraft:redstone_wire replace
setblock ~117 ~108 ~633 minecraft:redstone_wire replace
setblock ~126 ~108 ~645 minecraft:redstone_wire replace
setblock ~84 ~108 ~649 minecraft:redstone_wire replace
setblock ~120 ~108 ~653 minecraft:redstone_wire replace
setblock ~123 ~108 ~661 minecraft:redstone_wire replace
fill ~111 ~109 ~386 ~117 ~109 ~386 minecraft:redstone_wire replace
setblock ~119 ~109 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~109 ~386 ~125 ~109 ~386 minecraft:redstone_wire replace
setblock ~124 ~109 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~109 ~398 ~83 ~109 ~398 minecraft:redstone_wire replace
setblock ~82 ~109 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~109 ~558 ~89 ~109 ~558 minecraft:redstone_wire replace
setblock ~88 ~109 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~109 ~562 ~80 ~109 ~562 minecraft:redstone_wire replace
setblock ~79 ~109 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~109 ~566 ~92 ~109 ~566 minecraft:redstone_wire replace
setblock ~91 ~109 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~109 ~570 ~95 ~109 ~570 minecraft:redstone_wire replace
setblock ~94 ~109 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~109 ~574 ~98 ~109 ~574 minecraft:redstone_wire replace
setblock ~97 ~109 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~109 ~578 ~104 ~109 ~578 minecraft:redstone_wire replace
setblock ~105 ~109 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~106 ~109 ~578 ~118 ~109 ~578 minecraft:redstone_wire replace
setblock ~119 ~109 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~120 ~109 ~578 ~128 ~109 ~578 minecraft:redstone_wire replace
setblock ~100 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~109 ~579 minecraft:redstone_wire replace
setblock ~106 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~109 ~579 minecraft:redstone_wire replace
setblock ~112 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~109 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~109 ~579 minecraft:redstone_wire replace
setblock ~127 ~109 ~579 minecraft:redstone_wire replace
fill ~99 ~109 ~602 ~116 ~109 ~602 minecraft:redstone_wire replace
setblock ~117 ~109 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~109 ~602 ~130 ~109 ~602 minecraft:redstone_wire replace
setblock ~131 ~109 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~132 ~109 ~602 ~134 ~109 ~602 minecraft:redstone_wire replace
setblock ~100 ~109 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~109 ~603 minecraft:redstone_wire replace
setblock ~109 ~109 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~109 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~109 ~603 minecraft:redstone_wire replace
setblock ~121 ~109 ~603 minecraft:redstone_wire replace
setblock ~133 ~109 ~603 minecraft:redstone_wire replace
fill ~99 ~109 ~610 ~113 ~109 ~610 minecraft:redstone_wire replace
setblock ~114 ~109 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~109 ~610 ~127 ~109 ~610 minecraft:redstone_wire replace
setblock ~128 ~109 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~129 ~109 ~610 ~131 ~109 ~610 minecraft:redstone_wire replace
setblock ~100 ~109 ~611 minecraft:redstone_wire replace
setblock ~103 ~109 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~109 ~611 minecraft:redstone_wire replace
setblock ~115 ~109 ~611 minecraft:redstone_wire replace
setblock ~121 ~109 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~109 ~611 minecraft:redstone_wire replace
fill ~102 ~109 ~622 ~119 ~109 ~622 minecraft:redstone_wire replace
setblock ~120 ~109 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~109 ~622 ~133 ~109 ~622 minecraft:redstone_wire replace
setblock ~134 ~109 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~103 ~109 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~109 ~623 minecraft:redstone_wire replace
setblock ~112 ~109 ~623 minecraft:redstone_wire replace
setblock ~118 ~109 ~623 minecraft:redstone_wire replace
setblock ~121 ~109 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~109 ~623 minecraft:redstone_wire replace
setblock ~133 ~109 ~623 minecraft:redstone_wire replace
fill ~114 ~109 ~626 ~123 ~109 ~626 minecraft:redstone_wire replace
setblock ~125 ~109 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~109 ~626 ~137 ~109 ~626 minecraft:redstone_wire replace
setblock ~136 ~109 ~627 minecraft:redstone_wire replace
fill ~117 ~109 ~634 ~123 ~109 ~634 minecraft:redstone_wire replace
setblock ~125 ~109 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~109 ~634 ~140 ~109 ~634 minecraft:redstone_wire replace
setblock ~139 ~109 ~635 minecraft:redstone_wire replace
fill ~126 ~109 ~646 ~132 ~109 ~646 minecraft:redstone_wire replace
setblock ~134 ~109 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~109 ~646 ~149 ~109 ~646 minecraft:redstone_wire replace
setblock ~148 ~109 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~109 ~650 ~86 ~109 ~650 minecraft:redstone_wire replace
setblock ~85 ~109 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~109 ~654 ~126 ~109 ~654 minecraft:redstone_wire replace
setblock ~128 ~109 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~109 ~654 ~143 ~109 ~654 minecraft:redstone_wire replace
setblock ~142 ~109 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~109 ~662 ~129 ~109 ~662 minecraft:redstone_wire replace
setblock ~131 ~109 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~109 ~662 ~146 ~109 ~662 minecraft:redstone_wire replace
setblock ~145 ~109 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~110 ~388 minecraft:redstone_wire replace
setblock ~82 ~110 ~400 minecraft:redstone_wire replace
setblock ~88 ~110 ~560 minecraft:redstone_wire replace
setblock ~79 ~110 ~564 minecraft:redstone_wire replace
setblock ~91 ~110 ~568 minecraft:redstone_wire replace
setblock ~94 ~110 ~572 minecraft:redstone_wire replace
setblock ~97 ~110 ~576 minecraft:redstone_wire replace
setblock ~100 ~110 ~580 minecraft:redstone_wire replace
setblock ~103 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~110 ~580 minecraft:redstone_wire replace
setblock ~109 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~110 ~580 minecraft:redstone_wire replace
setblock ~115 ~110 ~580 minecraft:redstone_wire replace
setblock ~118 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~110 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~110 ~604 minecraft:redstone_wire replace
setblock ~106 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~110 ~604 minecraft:redstone_wire replace
setblock ~112 ~110 ~604 minecraft:redstone_wire replace
setblock ~118 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~110 ~612 minecraft:redstone_wire replace
setblock ~109 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~110 ~612 minecraft:redstone_wire replace
setblock ~130 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~110 ~624 minecraft:redstone_wire replace
setblock ~106 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~110 ~624 minecraft:redstone_wire replace
setblock ~127 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~110 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~110 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~110 ~648 minecraft:redstone_wire replace
setblock ~85 ~110 ~652 minecraft:redstone_wire replace
setblock ~142 ~110 ~656 minecraft:redstone_wire replace
setblock ~145 ~110 ~664 minecraft:redstone_wire replace
fill ~123 ~111 ~384 ~123 ~111 ~388 minecraft:redstone_wire replace
fill ~81 ~111 ~396 ~81 ~111 ~400 minecraft:redstone_wire replace
setblock ~87 ~111 ~528 minecraft:redstone_wire replace
setblock ~87 ~111 ~530 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~111 ~532 minecraft:redstone_wire replace
fill ~87 ~111 ~532 ~87 ~111 ~544 minecraft:redstone_wire replace
setblock ~78 ~111 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~111 ~536 ~78 ~111 ~548 minecraft:redstone_wire replace
setblock ~90 ~111 ~536 minecraft:redstone_wire replace
setblock ~90 ~111 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~111 ~540 ~90 ~111 ~552 minecraft:redstone_wire replace
setblock ~93 ~111 ~540 minecraft:redstone_wire replace
setblock ~93 ~111 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~111 ~544 ~93 ~111 ~556 minecraft:redstone_wire replace
setblock ~96 ~111 ~544 minecraft:redstone_wire replace
setblock ~87 ~111 ~546 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~111 ~546 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~111 ~548 ~87 ~111 ~560 minecraft:redstone_wire replace
fill ~96 ~111 ~548 ~96 ~111 ~560 minecraft:redstone_wire replace
setblock ~126 ~111 ~548 minecraft:redstone_wire replace
setblock ~126 ~111 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~111 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~111 ~550 ~126 ~111 ~562 minecraft:redstone_wire replace
fill ~78 ~111 ~552 ~78 ~111 ~564 minecraft:redstone_wire replace
setblock ~117 ~111 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~111 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~111 ~554 ~117 ~111 ~562 minecraft:redstone_wire replace
fill ~90 ~111 ~556 ~90 ~111 ~568 minecraft:redstone_wire replace
setblock ~114 ~111 ~556 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~111 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~111 ~558 ~114 ~111 ~564 minecraft:redstone_wire replace
fill ~93 ~111 ~560 ~93 ~111 ~572 minecraft:redstone_wire replace
fill ~111 ~111 ~560 ~111 ~111 ~562 minecraft:redstone_wire replace
setblock ~96 ~111 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~111 ~564 ~96 ~111 ~576 minecraft:redstone_wire replace
setblock ~108 ~111 ~564 minecraft:redstone_wire replace
setblock ~111 ~111 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~111 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~111 ~566 ~111 ~111 ~578 minecraft:redstone_wire replace
setblock ~114 ~111 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~111 ~566 ~117 ~111 ~578 minecraft:redstone_wire replace
fill ~126 ~111 ~566 ~126 ~111 ~578 minecraft:redstone_wire replace
setblock ~105 ~111 ~568 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~111 ~568 ~108 ~111 ~580 minecraft:redstone_wire replace
fill ~114 ~111 ~568 ~114 ~111 ~580 minecraft:redstone_wire replace
fill ~105 ~111 ~570 ~105 ~111 ~578 minecraft:redstone_wire replace
setblock ~102 ~111 ~572 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~574 ~102 ~111 ~580 minecraft:redstone_wire replace
fill ~99 ~111 ~576 ~99 ~111 ~580 minecraft:redstone_wire replace
setblock ~105 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~111 ~580 ~105 ~111 ~592 minecraft:redstone_wire replace
fill ~111 ~111 ~580 ~111 ~111 ~592 minecraft:redstone_wire replace
fill ~117 ~111 ~580 ~117 ~111 ~592 minecraft:redstone_wire replace
fill ~126 ~111 ~580 ~126 ~111 ~592 minecraft:redstone_wire replace
setblock ~102 ~111 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~111 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~582 ~102 ~111 ~594 minecraft:redstone_wire replace
setblock ~108 ~111 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~111 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~111 ~584 ~99 ~111 ~596 minecraft:redstone_wire replace
fill ~108 ~111 ~584 ~108 ~111 ~596 minecraft:redstone_wire replace
fill ~114 ~111 ~584 ~114 ~111 ~596 minecraft:redstone_wire replace
setblock ~105 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~111 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~111 ~596 ~105 ~111 ~608 minecraft:redstone_wire replace
fill ~111 ~111 ~596 ~111 ~111 ~608 minecraft:redstone_wire replace
fill ~117 ~111 ~596 ~117 ~111 ~608 minecraft:redstone_wire replace
fill ~126 ~111 ~596 ~126 ~111 ~608 minecraft:redstone_wire replace
setblock ~132 ~111 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~111 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~598 ~102 ~111 ~610 minecraft:redstone_wire replace
setblock ~108 ~111 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~111 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~111 ~598 ~132 ~111 ~608 minecraft:redstone_wire replace
fill ~99 ~111 ~600 ~99 ~111 ~612 minecraft:redstone_wire replace
fill ~108 ~111 ~600 ~108 ~111 ~612 minecraft:redstone_wire replace
fill ~114 ~111 ~600 ~114 ~111 ~612 minecraft:redstone_wire replace
setblock ~120 ~111 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~111 ~602 ~120 ~111 ~610 minecraft:redstone_wire replace
fill ~129 ~111 ~608 ~129 ~111 ~612 minecraft:redstone_wire replace
setblock ~105 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~111 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~111 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~612 ~102 ~111 ~624 minecraft:redstone_wire replace
fill ~105 ~111 ~612 ~105 ~111 ~624 minecraft:redstone_wire replace
fill ~111 ~111 ~612 ~111 ~111 ~624 minecraft:redstone_wire replace
fill ~117 ~111 ~612 ~117 ~111 ~624 minecraft:redstone_wire replace
fill ~120 ~111 ~612 ~120 ~111 ~624 minecraft:redstone_wire replace
fill ~126 ~111 ~612 ~126 ~111 ~624 minecraft:redstone_wire replace
fill ~132 ~111 ~612 ~132 ~111 ~624 minecraft:redstone_wire replace
fill ~135 ~111 ~624 ~135 ~111 ~628 minecraft:redstone_wire replace
fill ~138 ~111 ~632 ~138 ~111 ~636 minecraft:redstone_wire replace
fill ~147 ~111 ~644 ~147 ~111 ~648 minecraft:redstone_wire replace
fill ~84 ~111 ~648 ~84 ~111 ~652 minecraft:redstone_wire replace
fill ~141 ~111 ~652 ~141 ~111 ~656 minecraft:redstone_wire replace
fill ~144 ~111 ~660 ~144 ~111 ~664 minecraft:redstone_wire replace
setblock ~123 ~112 ~383 minecraft:redstone_wire replace
setblock ~81 ~112 ~395 minecraft:redstone_wire replace
setblock ~87 ~112 ~527 minecraft:redstone_wire replace
setblock ~78 ~112 ~531 minecraft:redstone_wire replace
setblock ~90 ~112 ~535 minecraft:redstone_wire replace
setblock ~93 ~112 ~539 minecraft:redstone_wire replace
setblock ~96 ~112 ~543 minecraft:redstone_wire replace
setblock ~126 ~112 ~547 minecraft:redstone_wire replace
setblock ~117 ~112 ~551 minecraft:redstone_wire replace
setblock ~114 ~112 ~555 minecraft:redstone_wire replace
setblock ~111 ~112 ~559 minecraft:redstone_wire replace
setblock ~108 ~112 ~563 minecraft:redstone_wire replace
setblock ~105 ~112 ~567 minecraft:redstone_wire replace
setblock ~102 ~112 ~571 minecraft:redstone_wire replace
setblock ~99 ~112 ~575 minecraft:redstone_wire replace
setblock ~132 ~112 ~595 minecraft:redstone_wire replace
setblock ~120 ~112 ~599 minecraft:redstone_wire replace
setblock ~129 ~112 ~607 minecraft:redstone_wire replace
setblock ~135 ~112 ~623 minecraft:redstone_wire replace
setblock ~138 ~112 ~631 minecraft:redstone_wire replace
setblock ~147 ~112 ~643 minecraft:redstone_wire replace
setblock ~84 ~112 ~647 minecraft:redstone_wire replace
setblock ~141 ~112 ~651 minecraft:redstone_wire replace
setblock ~144 ~112 ~659 minecraft:redstone_wire replace
setblock ~109 ~113 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~113 ~382 ~113 ~113 ~382 minecraft:redstone_wire replace
setblock ~115 ~113 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~113 ~382 ~123 ~113 ~382 minecraft:redstone_wire replace
setblock ~82 ~113 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~113 ~394 ~83 ~113 ~394 minecraft:redstone_wire replace
setblock ~88 ~113 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~113 ~526 ~89 ~113 ~526 minecraft:redstone_wire replace
setblock ~79 ~113 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~113 ~530 ~80 ~113 ~530 minecraft:redstone_wire replace
setblock ~91 ~113 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~113 ~534 ~92 ~113 ~534 minecraft:redstone_wire replace
setblock ~94 ~113 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~113 ~538 ~95 ~113 ~538 minecraft:redstone_wire replace
setblock ~97 ~113 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~113 ~542 ~98 ~113 ~542 minecraft:redstone_wire replace
setblock ~112 ~113 ~545 minecraft:redstone_wire replace
fill ~111 ~113 ~546 ~113 ~113 ~546 minecraft:redstone_wire replace
setblock ~114 ~113 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~113 ~546 ~126 ~113 ~546 minecraft:redstone_wire replace
setblock ~106 ~113 ~549 minecraft:redstone_wire replace
fill ~105 ~113 ~550 ~117 ~113 ~550 minecraft:redstone_wire replace
setblock ~106 ~113 ~553 minecraft:redstone_wire replace
fill ~105 ~113 ~554 ~114 ~113 ~554 minecraft:redstone_wire replace
setblock ~103 ~113 ~557 minecraft:redstone_wire replace
fill ~102 ~113 ~558 ~111 ~113 ~558 minecraft:redstone_wire replace
setblock ~103 ~113 ~561 minecraft:redstone_wire replace
fill ~102 ~113 ~562 ~108 ~113 ~562 minecraft:redstone_wire replace
setblock ~100 ~113 ~565 minecraft:redstone_wire replace
fill ~99 ~113 ~566 ~105 ~113 ~566 minecraft:redstone_wire replace
setblock ~100 ~113 ~569 minecraft:redstone_wire replace
fill ~99 ~113 ~570 ~102 ~113 ~570 minecraft:redstone_wire replace
setblock ~100 ~113 ~573 minecraft:redstone_wire replace
fill ~99 ~113 ~574 ~101 ~113 ~574 minecraft:redstone_wire replace
setblock ~112 ~113 ~593 minecraft:redstone_wire replace
fill ~111 ~113 ~594 ~116 ~113 ~594 minecraft:redstone_wire replace
setblock ~118 ~113 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~113 ~594 ~132 ~113 ~594 minecraft:redstone_wire replace
setblock ~106 ~113 ~597 minecraft:redstone_wire replace
fill ~105 ~113 ~598 ~106 ~113 ~598 minecraft:redstone_wire replace
setblock ~107 ~113 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~113 ~598 ~120 ~113 ~598 minecraft:redstone_wire replace
setblock ~112 ~113 ~605 minecraft:redstone_wire replace
fill ~111 ~113 ~606 ~119 ~113 ~606 minecraft:redstone_wire replace
setblock ~121 ~113 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~113 ~606 ~129 ~113 ~606 minecraft:redstone_wire replace
setblock ~115 ~113 ~621 minecraft:redstone_wire replace
fill ~114 ~113 ~622 ~125 ~113 ~622 minecraft:redstone_wire replace
setblock ~127 ~113 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~113 ~622 ~135 ~113 ~622 minecraft:redstone_wire replace
setblock ~118 ~113 ~629 minecraft:redstone_wire replace
fill ~117 ~113 ~630 ~128 ~113 ~630 minecraft:redstone_wire replace
setblock ~130 ~113 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~113 ~630 ~138 ~113 ~630 minecraft:redstone_wire replace
setblock ~127 ~113 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~113 ~642 ~137 ~113 ~642 minecraft:redstone_wire replace
setblock ~139 ~113 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~113 ~642 ~147 ~113 ~642 minecraft:redstone_wire replace
setblock ~85 ~113 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~113 ~646 ~86 ~113 ~646 minecraft:redstone_wire replace
setblock ~121 ~113 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~113 ~650 ~131 ~113 ~650 minecraft:redstone_wire replace
setblock ~133 ~113 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~113 ~650 ~141 ~113 ~650 minecraft:redstone_wire replace
setblock ~124 ~113 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~113 ~658 ~134 ~113 ~658 minecraft:redstone_wire replace
setblock ~136 ~113 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~113 ~658 ~144 ~113 ~658 minecraft:redstone_wire replace
setblock ~109 ~114 ~380 minecraft:redstone_wire replace
setblock ~82 ~114 ~392 minecraft:redstone_wire replace
setblock ~88 ~114 ~524 minecraft:redstone_wire replace
setblock ~79 ~114 ~528 minecraft:redstone_wire replace
setblock ~91 ~114 ~532 minecraft:redstone_wire replace
setblock ~94 ~114 ~536 minecraft:redstone_wire replace
setblock ~97 ~114 ~540 minecraft:redstone_wire replace
setblock ~112 ~114 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~114 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~114 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~114 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~114 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~114 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~114 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~114 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~114 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~114 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~114 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~114 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~114 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~114 ~640 minecraft:redstone_wire replace
setblock ~85 ~114 ~644 minecraft:redstone_wire replace
setblock ~121 ~114 ~648 minecraft:redstone_wire replace
setblock ~124 ~114 ~656 minecraft:redstone_wire replace
fill ~108 ~115 ~380 ~108 ~115 ~384 minecraft:redstone_wire replace
fill ~81 ~115 ~392 ~81 ~115 ~396 minecraft:redstone_wire replace
fill ~87 ~115 ~524 ~87 ~115 ~528 minecraft:redstone_wire replace
fill ~78 ~115 ~528 ~78 ~115 ~532 minecraft:redstone_wire replace
fill ~90 ~115 ~532 ~90 ~115 ~536 minecraft:redstone_wire replace
fill ~93 ~115 ~536 ~93 ~115 ~540 minecraft:redstone_wire replace
fill ~96 ~115 ~540 ~96 ~115 ~544 minecraft:redstone_wire replace
fill ~111 ~115 ~544 ~111 ~115 ~556 minecraft:redstone_wire replace
fill ~105 ~115 ~548 ~105 ~115 ~560 minecraft:redstone_wire replace
fill ~102 ~115 ~556 ~102 ~115 ~562 minecraft:redstone_wire replace
setblock ~111 ~115 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~560 ~111 ~115 ~572 minecraft:redstone_wire replace
setblock ~105 ~115 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~115 ~564 ~99 ~115 ~574 minecraft:redstone_wire replace
setblock ~102 ~115 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~115 ~564 ~105 ~115 ~576 minecraft:redstone_wire replace
setblock ~111 ~115 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~115 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~576 ~111 ~115 ~588 minecraft:redstone_wire replace
setblock ~105 ~115 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~115 ~580 ~105 ~115 ~592 minecraft:redstone_wire replace
setblock ~111 ~115 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~592 ~111 ~115 ~604 minecraft:redstone_wire replace
setblock ~105 ~115 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~115 ~596 ~105 ~115 ~600 minecraft:redstone_wire replace
setblock ~111 ~115 ~605 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~606 ~111 ~115 ~608 minecraft:redstone_wire replace
fill ~114 ~115 ~620 ~114 ~115 ~624 minecraft:redstone_wire replace
fill ~117 ~115 ~628 ~117 ~115 ~632 minecraft:redstone_wire replace
fill ~126 ~115 ~640 ~126 ~115 ~644 minecraft:redstone_wire replace
fill ~84 ~115 ~644 ~84 ~115 ~648 minecraft:redstone_wire replace
fill ~120 ~115 ~648 ~120 ~115 ~652 minecraft:redstone_wire replace
fill ~123 ~115 ~656 ~123 ~115 ~660 minecraft:redstone_wire replace
setblock ~108 ~116 ~385 minecraft:redstone_wire replace
setblock ~81 ~116 ~397 minecraft:redstone_wire replace
setblock ~87 ~116 ~529 minecraft:redstone_wire replace
setblock ~78 ~116 ~533 minecraft:redstone_wire replace
setblock ~90 ~116 ~537 minecraft:redstone_wire replace
setblock ~93 ~116 ~541 minecraft:redstone_wire replace
setblock ~96 ~116 ~545 minecraft:redstone_wire replace
setblock ~102 ~116 ~565 minecraft:redstone_wire replace
setblock ~99 ~116 ~577 minecraft:redstone_wire replace
setblock ~105 ~116 ~601 minecraft:redstone_wire replace
setblock ~111 ~116 ~609 minecraft:redstone_wire replace
setblock ~114 ~116 ~625 minecraft:redstone_wire replace
setblock ~117 ~116 ~633 minecraft:redstone_wire replace
setblock ~126 ~116 ~645 minecraft:redstone_wire replace
setblock ~84 ~116 ~649 minecraft:redstone_wire replace
setblock ~120 ~116 ~653 minecraft:redstone_wire replace
setblock ~123 ~116 ~661 minecraft:redstone_wire replace
fill ~108 ~117 ~386 ~114 ~117 ~386 minecraft:redstone_wire replace
setblock ~116 ~117 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~117 ~386 ~122 ~117 ~386 minecraft:redstone_wire replace
setblock ~121 ~117 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~117 ~398 ~83 ~117 ~398 minecraft:redstone_wire replace
setblock ~82 ~117 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~117 ~530 ~89 ~117 ~530 minecraft:redstone_wire replace
setblock ~88 ~117 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~117 ~534 ~80 ~117 ~534 minecraft:redstone_wire replace
setblock ~79 ~117 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~117 ~538 ~92 ~117 ~538 minecraft:redstone_wire replace
setblock ~91 ~117 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~117 ~542 ~95 ~117 ~542 minecraft:redstone_wire replace
setblock ~94 ~117 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~117 ~546 ~101 ~117 ~546 minecraft:redstone_wire replace
setblock ~102 ~117 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~117 ~546 ~115 ~117 ~546 minecraft:redstone_wire replace
setblock ~116 ~117 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~117 ~117 ~546 ~125 ~117 ~546 minecraft:redstone_wire replace
setblock ~97 ~117 ~547 minecraft:redstone_wire replace
setblock ~100 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~117 ~547 minecraft:redstone_wire replace
setblock ~112 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~117 ~547 minecraft:redstone_wire replace
setblock ~124 ~117 ~547 minecraft:redstone_wire replace
fill ~96 ~117 ~566 ~114 ~117 ~566 minecraft:redstone_wire replace
setblock ~116 ~117 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~117 ~566 ~131 ~117 ~566 minecraft:redstone_wire replace
setblock ~97 ~117 ~567 minecraft:redstone_wire replace
setblock ~103 ~117 ~567 minecraft:redstone_wire replace
setblock ~109 ~117 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~117 ~567 minecraft:redstone_wire replace
setblock ~118 ~117 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~117 ~567 minecraft:redstone_wire replace
fill ~96 ~117 ~578 ~111 ~117 ~578 minecraft:redstone_wire replace
setblock ~113 ~117 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~117 ~578 ~128 ~117 ~578 minecraft:redstone_wire replace
setblock ~97 ~117 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~117 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~117 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~117 ~579 minecraft:redstone_wire replace
setblock ~115 ~117 ~579 minecraft:redstone_wire replace
setblock ~118 ~117 ~579 minecraft:redstone_wire replace
setblock ~127 ~117 ~579 minecraft:redstone_wire replace
fill ~99 ~117 ~602 ~111 ~117 ~602 minecraft:redstone_wire replace
setblock ~113 ~117 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~117 ~602 ~128 ~117 ~602 minecraft:redstone_wire replace
setblock ~100 ~117 ~603 minecraft:redstone_wire replace
setblock ~106 ~117 ~603 minecraft:redstone_wire replace
setblock ~109 ~117 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~117 ~603 minecraft:redstone_wire replace
setblock ~118 ~117 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~117 ~603 minecraft:redstone_wire replace
setblock ~127 ~117 ~603 minecraft:redstone_wire replace
fill ~111 ~117 ~610 ~120 ~117 ~610 minecraft:redstone_wire replace
setblock ~122 ~117 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~117 ~610 ~137 ~117 ~610 minecraft:redstone_wire replace
setblock ~138 ~117 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~117 ~610 ~149 ~117 ~610 minecraft:redstone_wire replace
setblock ~133 ~117 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~117 ~611 minecraft:redstone_wire replace
setblock ~139 ~117 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~117 ~611 minecraft:redstone_wire replace
setblock ~148 ~117 ~611 minecraft:redstone_wire replace
fill ~114 ~117 ~626 ~120 ~117 ~626 minecraft:redstone_wire replace
setblock ~122 ~117 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~117 ~626 ~137 ~117 ~626 minecraft:redstone_wire replace
setblock ~138 ~117 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~117 ~626 ~152 ~117 ~626 minecraft:redstone_wire replace
setblock ~133 ~117 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~117 ~627 minecraft:redstone_wire replace
setblock ~142 ~117 ~627 minecraft:redstone_wire replace
setblock ~145 ~117 ~627 minecraft:redstone_wire replace
setblock ~151 ~117 ~627 minecraft:redstone_wire replace
fill ~117 ~117 ~634 ~123 ~117 ~634 minecraft:redstone_wire replace
setblock ~125 ~117 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~117 ~634 ~140 ~117 ~634 minecraft:redstone_wire replace
setblock ~141 ~117 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~117 ~634 ~152 ~117 ~634 minecraft:redstone_wire replace
setblock ~133 ~117 ~635 minecraft:redstone_wire replace
setblock ~136 ~117 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~117 ~635 minecraft:redstone_wire replace
setblock ~142 ~117 ~635 minecraft:redstone_wire replace
setblock ~145 ~117 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~117 ~635 minecraft:redstone_wire replace
setblock ~151 ~117 ~635 minecraft:redstone_wire replace
fill ~126 ~117 ~646 ~132 ~117 ~646 minecraft:redstone_wire replace
setblock ~134 ~117 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~117 ~646 ~149 ~117 ~646 minecraft:redstone_wire replace
setblock ~151 ~117 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~117 ~646 ~161 ~117 ~646 minecraft:redstone_wire replace
setblock ~160 ~117 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~117 ~650 ~86 ~117 ~650 minecraft:redstone_wire replace
setblock ~85 ~117 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~117 ~654 ~126 ~117 ~654 minecraft:redstone_wire replace
setblock ~128 ~117 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~117 ~654 ~143 ~117 ~654 minecraft:redstone_wire replace
setblock ~145 ~117 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~117 ~654 ~155 ~117 ~654 minecraft:redstone_wire replace
setblock ~154 ~117 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~117 ~662 ~129 ~117 ~662 minecraft:redstone_wire replace
setblock ~131 ~117 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~117 ~662 ~146 ~117 ~662 minecraft:redstone_wire replace
setblock ~148 ~117 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~117 ~662 ~158 ~117 ~662 minecraft:redstone_wire replace
setblock ~157 ~117 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~118 ~388 minecraft:redstone_wire replace
setblock ~82 ~118 ~400 minecraft:redstone_wire replace
setblock ~88 ~118 ~532 minecraft:redstone_wire replace
setblock ~79 ~118 ~536 minecraft:redstone_wire replace
setblock ~91 ~118 ~540 minecraft:redstone_wire replace
setblock ~94 ~118 ~544 minecraft:redstone_wire replace
setblock ~97 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~118 ~548 minecraft:redstone_wire replace
setblock ~103 ~118 ~548 minecraft:redstone_wire replace
setblock ~106 ~118 ~548 minecraft:redstone_wire replace
setblock ~109 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~118 ~548 minecraft:redstone_wire replace
setblock ~115 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~118 ~568 minecraft:redstone_wire replace
setblock ~112 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~118 ~568 minecraft:redstone_wire replace
setblock ~130 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~118 ~580 minecraft:redstone_wire replace
setblock ~100 ~118 ~580 minecraft:redstone_wire replace
setblock ~103 ~118 ~580 minecraft:redstone_wire replace
setblock ~106 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~118 ~604 minecraft:redstone_wire replace
setblock ~115 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~118 ~604 minecraft:redstone_wire replace
setblock ~124 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~118 ~612 minecraft:redstone_wire replace
setblock ~136 ~118 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~118 ~612 minecraft:redstone_wire replace
setblock ~142 ~118 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~118 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~118 ~628 minecraft:redstone_wire replace
setblock ~139 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~118 ~636 minecraft:redstone_wire replace
setblock ~139 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~118 ~636 minecraft:redstone_wire replace
setblock ~148 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~118 ~648 minecraft:redstone_wire replace
setblock ~85 ~118 ~652 minecraft:redstone_wire replace
setblock ~154 ~118 ~656 minecraft:redstone_wire replace
setblock ~157 ~118 ~664 minecraft:redstone_wire replace
fill ~120 ~119 ~384 ~120 ~119 ~388 minecraft:redstone_wire replace
fill ~81 ~119 ~396 ~81 ~119 ~400 minecraft:redstone_wire replace
setblock ~87 ~119 ~500 minecraft:redstone_wire replace
setblock ~87 ~119 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~119 ~504 minecraft:redstone_wire replace
fill ~87 ~119 ~504 ~87 ~119 ~516 minecraft:redstone_wire replace
setblock ~78 ~119 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~119 ~508 ~78 ~119 ~520 minecraft:redstone_wire replace
setblock ~90 ~119 ~508 minecraft:redstone_wire replace
setblock ~90 ~119 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~119 ~512 ~90 ~119 ~524 minecraft:redstone_wire replace
setblock ~93 ~119 ~512 minecraft:redstone_wire replace
setblock ~93 ~119 ~514 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~119 ~516 ~93 ~119 ~528 minecraft:redstone_wire replace
setblock ~123 ~119 ~516 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~119 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~119 ~518 ~123 ~119 ~524 minecraft:redstone_wire replace
fill ~87 ~119 ~520 ~87 ~119 ~532 minecraft:redstone_wire replace
fill ~114 ~119 ~520 ~114 ~119 ~524 minecraft:redstone_wire replace
setblock ~78 ~119 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~119 ~524 ~78 ~119 ~536 minecraft:redstone_wire replace
setblock ~111 ~119 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~119 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~119 ~526 ~111 ~119 ~536 minecraft:redstone_wire replace
setblock ~114 ~119 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~119 ~528 ~90 ~119 ~540 minecraft:redstone_wire replace
setblock ~108 ~119 ~528 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~119 ~528 ~114 ~119 ~540 minecraft:redstone_wire replace
fill ~123 ~119 ~528 ~123 ~119 ~540 minecraft:redstone_wire replace
setblock ~93 ~119 ~530 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~119 ~530 ~108 ~119 ~540 minecraft:redstone_wire replace
fill ~93 ~119 ~532 ~93 ~119 ~544 minecraft:redstone_wire replace
setblock ~105 ~119 ~532 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~119 ~534 ~105 ~119 ~540 minecraft:redstone_wire replace
setblock ~102 ~119 ~536 minecraft:redstone_wire replace
setblock ~102 ~119 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~119 ~538 ~102 ~119 ~550 minecraft:redstone_wire replace
setblock ~111 ~119 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~119 ~540 minecraft:redstone_wire replace
fill ~111 ~119 ~540 ~111 ~119 ~552 minecraft:redstone_wire replace
setblock ~99 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~119 ~544 ~96 ~119 ~550 minecraft:redstone_wire replace
fill ~99 ~119 ~544 ~99 ~119 ~556 minecraft:redstone_wire replace
fill ~105 ~119 ~544 ~105 ~119 ~556 minecraft:redstone_wire replace
fill ~108 ~119 ~544 ~108 ~119 ~556 minecraft:redstone_wire replace
fill ~114 ~119 ~544 ~114 ~119 ~556 minecraft:redstone_wire replace
fill ~123 ~119 ~544 ~123 ~119 ~556 minecraft:redstone_wire replace
setblock ~96 ~119 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~119 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~119 ~554 ~96 ~119 ~566 minecraft:redstone_wire replace
fill ~102 ~119 ~554 ~102 ~119 ~566 minecraft:redstone_wire replace
setblock ~111 ~119 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~119 ~556 ~111 ~119 ~568 minecraft:redstone_wire replace
setblock ~99 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~119 ~560 ~99 ~119 ~572 minecraft:redstone_wire replace
fill ~105 ~119 ~560 ~105 ~119 ~572 minecraft:redstone_wire replace
fill ~108 ~119 ~560 ~108 ~119 ~572 minecraft:redstone_wire replace
fill ~114 ~119 ~560 ~114 ~119 ~572 minecraft:redstone_wire replace
fill ~123 ~119 ~560 ~123 ~119 ~572 minecraft:redstone_wire replace
setblock ~129 ~119 ~560 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~119 ~562 ~129 ~119 ~568 minecraft:redstone_wire replace
setblock ~117 ~119 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~119 ~566 ~117 ~119 ~572 minecraft:redstone_wire replace
setblock ~96 ~119 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~119 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~119 ~568 ~96 ~119 ~580 minecraft:redstone_wire replace
fill ~102 ~119 ~568 ~102 ~119 ~580 minecraft:redstone_wire replace
setblock ~99 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~119 ~576 ~99 ~119 ~588 minecraft:redstone_wire replace
fill ~105 ~119 ~576 ~105 ~119 ~588 minecraft:redstone_wire replace
fill ~108 ~119 ~576 ~108 ~119 ~588 minecraft:redstone_wire replace
fill ~114 ~119 ~576 ~114 ~119 ~588 minecraft:redstone_wire replace
fill ~117 ~119 ~576 ~117 ~119 ~588 minecraft:redstone_wire replace
fill ~123 ~119 ~576 ~123 ~119 ~588 minecraft:redstone_wire replace
setblock ~126 ~119 ~576 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~119 ~578 ~126 ~119 ~588 minecraft:redstone_wire replace
setblock ~99 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~119 ~592 ~99 ~119 ~604 minecraft:redstone_wire replace
fill ~105 ~119 ~592 ~105 ~119 ~604 minecraft:redstone_wire replace
fill ~108 ~119 ~592 ~108 ~119 ~604 minecraft:redstone_wire replace
fill ~114 ~119 ~592 ~114 ~119 ~604 minecraft:redstone_wire replace
fill ~117 ~119 ~592 ~117 ~119 ~604 minecraft:redstone_wire replace
fill ~123 ~119 ~592 ~123 ~119 ~604 minecraft:redstone_wire replace
fill ~126 ~119 ~592 ~126 ~119 ~604 minecraft:redstone_wire replace
setblock ~147 ~119 ~592 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~119 ~594 ~147 ~119 ~604 minecraft:redstone_wire replace
setblock ~141 ~119 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~119 ~598 ~141 ~119 ~604 minecraft:redstone_wire replace
fill ~138 ~119 ~600 ~138 ~119 ~604 minecraft:redstone_wire replace
setblock ~135 ~119 ~604 minecraft:redstone_wire replace
setblock ~135 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~119 ~608 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~119 ~608 ~135 ~119 ~620 minecraft:redstone_wire replace
fill ~138 ~119 ~608 ~138 ~119 ~620 minecraft:redstone_wire replace
fill ~141 ~119 ~608 ~141 ~119 ~620 minecraft:redstone_wire replace
fill ~147 ~119 ~608 ~147 ~119 ~620 minecraft:redstone_wire replace
fill ~132 ~119 ~610 ~132 ~119 ~620 minecraft:redstone_wire replace
setblock ~150 ~119 ~620 minecraft:redstone_wire replace
setblock ~132 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~119 ~624 ~132 ~119 ~636 minecraft:redstone_wire replace
fill ~135 ~119 ~624 ~135 ~119 ~636 minecraft:redstone_wire replace
fill ~138 ~119 ~624 ~138 ~119 ~636 minecraft:redstone_wire replace
fill ~141 ~119 ~624 ~141 ~119 ~636 minecraft:redstone_wire replace
setblock ~144 ~119 ~624 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~119 ~624 ~147 ~119 ~636 minecraft:redstone_wire replace
fill ~150 ~119 ~624 ~150 ~119 ~636 minecraft:redstone_wire replace
fill ~144 ~119 ~626 ~144 ~119 ~636 minecraft:redstone_wire replace
fill ~159 ~119 ~644 ~159 ~119 ~648 minecraft:redstone_wire replace
fill ~84 ~119 ~648 ~84 ~119 ~652 minecraft:redstone_wire replace
fill ~153 ~119 ~652 ~153 ~119 ~656 minecraft:redstone_wire replace
fill ~156 ~119 ~660 ~156 ~119 ~664 minecraft:redstone_wire replace
setblock ~120 ~120 ~383 minecraft:redstone_wire replace
setblock ~81 ~120 ~395 minecraft:redstone_wire replace
setblock ~87 ~120 ~499 minecraft:redstone_wire replace
setblock ~78 ~120 ~503 minecraft:redstone_wire replace
setblock ~90 ~120 ~507 minecraft:redstone_wire replace
setblock ~93 ~120 ~511 minecraft:redstone_wire replace
setblock ~123 ~120 ~515 minecraft:redstone_wire replace
setblock ~114 ~120 ~519 minecraft:redstone_wire replace
setblock ~111 ~120 ~523 minecraft:redstone_wire replace
setblock ~108 ~120 ~527 minecraft:redstone_wire replace
setblock ~105 ~120 ~531 minecraft:redstone_wire replace
setblock ~102 ~120 ~535 minecraft:redstone_wire replace
setblock ~99 ~120 ~539 minecraft:redstone_wire replace
setblock ~96 ~120 ~543 minecraft:redstone_wire replace
setblock ~129 ~120 ~559 minecraft:redstone_wire replace
setblock ~117 ~120 ~563 minecraft:redstone_wire replace
setblock ~126 ~120 ~575 minecraft:redstone_wire replace
setblock ~147 ~120 ~591 minecraft:redstone_wire replace
setblock ~141 ~120 ~595 minecraft:redstone_wire replace
setblock ~138 ~120 ~599 minecraft:redstone_wire replace
setblock ~135 ~120 ~603 minecraft:redstone_wire replace
setblock ~132 ~120 ~607 minecraft:redstone_wire replace
setblock ~150 ~120 ~619 minecraft:redstone_wire replace
setblock ~144 ~120 ~623 minecraft:redstone_wire replace
setblock ~159 ~120 ~643 minecraft:redstone_wire replace
setblock ~84 ~120 ~647 minecraft:redstone_wire replace
setblock ~153 ~120 ~651 minecraft:redstone_wire replace
setblock ~156 ~120 ~659 minecraft:redstone_wire replace
setblock ~106 ~121 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~121 ~382 ~110 ~121 ~382 minecraft:redstone_wire replace
setblock ~112 ~121 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~121 ~382 ~120 ~121 ~382 minecraft:redstone_wire replace
setblock ~82 ~121 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~121 ~394 ~83 ~121 ~394 minecraft:redstone_wire replace
setblock ~88 ~121 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~121 ~498 ~89 ~121 ~498 minecraft:redstone_wire replace
setblock ~79 ~121 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~121 ~502 ~80 ~121 ~502 minecraft:redstone_wire replace
setblock ~91 ~121 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~121 ~506 ~92 ~121 ~506 minecraft:redstone_wire replace
setblock ~94 ~121 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~121 ~510 ~95 ~121 ~510 minecraft:redstone_wire replace
setblock ~109 ~121 ~513 minecraft:redstone_wire replace
fill ~108 ~121 ~514 ~109 ~121 ~514 minecraft:redstone_wire replace
setblock ~110 ~121 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~121 ~514 ~123 ~121 ~514 minecraft:redstone_wire replace
setblock ~103 ~121 ~517 minecraft:redstone_wire replace
fill ~102 ~121 ~518 ~103 ~121 ~518 minecraft:redstone_wire replace
setblock ~105 ~121 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~121 ~518 ~114 ~121 ~518 minecraft:redstone_wire replace
setblock ~103 ~121 ~521 minecraft:redstone_wire replace
fill ~102 ~121 ~522 ~111 ~121 ~522 minecraft:redstone_wire replace
setblock ~100 ~121 ~525 minecraft:redstone_wire replace
fill ~99 ~121 ~526 ~108 ~121 ~526 minecraft:redstone_wire replace
setblock ~100 ~121 ~529 minecraft:redstone_wire replace
fill ~99 ~121 ~530 ~105 ~121 ~530 minecraft:redstone_wire replace
setblock ~100 ~121 ~533 minecraft:redstone_wire replace
fill ~99 ~121 ~534 ~102 ~121 ~534 minecraft:redstone_wire replace
setblock ~97 ~121 ~537 minecraft:redstone_wire replace
fill ~96 ~121 ~538 ~99 ~121 ~538 minecraft:redstone_wire replace
setblock ~97 ~121 ~541 minecraft:redstone_wire replace
fill ~96 ~121 ~542 ~98 ~121 ~542 minecraft:redstone_wire replace
setblock ~109 ~121 ~557 minecraft:redstone_wire replace
fill ~108 ~121 ~558 ~113 ~121 ~558 minecraft:redstone_wire replace
setblock ~115 ~121 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~121 ~558 ~129 ~121 ~558 minecraft:redstone_wire replace
setblock ~103 ~121 ~561 minecraft:redstone_wire replace
fill ~102 ~121 ~562 ~103 ~121 ~562 minecraft:redstone_wire replace
setblock ~104 ~121 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~121 ~562 ~117 ~121 ~562 minecraft:redstone_wire replace
setblock ~109 ~121 ~573 minecraft:redstone_wire replace
fill ~108 ~121 ~574 ~110 ~121 ~574 minecraft:redstone_wire replace
setblock ~112 ~121 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~121 ~574 ~126 ~121 ~574 minecraft:redstone_wire replace
setblock ~121 ~121 ~589 minecraft:redstone_wire replace
fill ~120 ~121 ~590 ~131 ~121 ~590 minecraft:redstone_wire replace
setblock ~133 ~121 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~121 ~590 ~147 ~121 ~590 minecraft:redstone_wire replace
setblock ~118 ~121 ~593 minecraft:redstone_wire replace
fill ~117 ~121 ~594 ~125 ~121 ~594 minecraft:redstone_wire replace
setblock ~127 ~121 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~121 ~594 ~141 ~121 ~594 minecraft:redstone_wire replace
setblock ~115 ~121 ~597 minecraft:redstone_wire replace
fill ~114 ~121 ~598 ~127 ~121 ~598 minecraft:redstone_wire replace
setblock ~129 ~121 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~121 ~598 ~138 ~121 ~598 minecraft:redstone_wire replace
setblock ~115 ~121 ~601 minecraft:redstone_wire replace
fill ~114 ~121 ~602 ~120 ~121 ~602 minecraft:redstone_wire replace
setblock ~122 ~121 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~121 ~602 ~135 ~121 ~602 minecraft:redstone_wire replace
setblock ~112 ~121 ~605 minecraft:redstone_wire replace
fill ~111 ~121 ~606 ~116 ~121 ~606 minecraft:redstone_wire replace
setblock ~118 ~121 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~121 ~606 ~132 ~121 ~606 minecraft:redstone_wire replace
setblock ~121 ~121 ~617 minecraft:redstone_wire replace
fill ~120 ~121 ~618 ~122 ~121 ~618 minecraft:redstone_wire replace
setblock ~123 ~121 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~121 ~618 ~136 ~121 ~618 minecraft:redstone_wire replace
setblock ~138 ~121 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~121 ~618 ~150 ~121 ~618 minecraft:redstone_wire replace
setblock ~118 ~121 ~621 minecraft:redstone_wire replace
fill ~117 ~121 ~622 ~128 ~121 ~622 minecraft:redstone_wire replace
setblock ~130 ~121 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~121 ~622 ~144 ~121 ~622 minecraft:redstone_wire replace
setblock ~130 ~121 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~121 ~642 ~132 ~121 ~642 minecraft:redstone_wire replace
setblock ~134 ~121 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~121 ~642 ~149 ~121 ~642 minecraft:redstone_wire replace
setblock ~151 ~121 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~121 ~642 ~159 ~121 ~642 minecraft:redstone_wire replace
setblock ~85 ~121 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~121 ~646 ~86 ~121 ~646 minecraft:redstone_wire replace
setblock ~124 ~121 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~121 ~650 ~126 ~121 ~650 minecraft:redstone_wire replace
setblock ~128 ~121 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~121 ~650 ~143 ~121 ~650 minecraft:redstone_wire replace
setblock ~145 ~121 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~121 ~650 ~153 ~121 ~650 minecraft:redstone_wire replace
setblock ~127 ~121 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~121 ~658 ~129 ~121 ~658 minecraft:redstone_wire replace
setblock ~131 ~121 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~121 ~658 ~146 ~121 ~658 minecraft:redstone_wire replace
setblock ~148 ~121 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~121 ~658 ~156 ~121 ~658 minecraft:redstone_wire replace
setblock ~106 ~122 ~380 minecraft:redstone_wire replace
setblock ~82 ~122 ~392 minecraft:redstone_wire replace
setblock ~88 ~122 ~496 minecraft:redstone_wire replace
setblock ~79 ~122 ~500 minecraft:redstone_wire replace
setblock ~91 ~122 ~504 minecraft:redstone_wire replace
setblock ~94 ~122 ~508 minecraft:redstone_wire replace
setblock ~109 ~122 ~512 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~122 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~122 ~520 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~122 ~524 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~122 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~122 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~122 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~122 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~122 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~122 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~122 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~122 ~588 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~122 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~122 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~122 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~122 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~122 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~122 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~122 ~640 minecraft:redstone_wire replace
setblock ~85 ~122 ~644 minecraft:redstone_wire replace
setblock ~124 ~122 ~648 minecraft:redstone_wire replace
setblock ~127 ~122 ~656 minecraft:redstone_wire replace
fill ~105 ~123 ~380 ~105 ~123 ~384 minecraft:redstone_wire replace
fill ~81 ~123 ~392 ~81 ~123 ~396 minecraft:redstone_wire replace
fill ~87 ~123 ~496 ~87 ~123 ~500 minecraft:redstone_wire replace
fill ~78 ~123 ~500 ~78 ~123 ~504 minecraft:redstone_wire replace
fill ~90 ~123 ~504 ~90 ~123 ~508 minecraft:redstone_wire replace
fill ~93 ~123 ~508 ~93 ~123 ~512 minecraft:redstone_wire replace
fill ~108 ~123 ~512 ~108 ~123 ~524 minecraft:redstone_wire replace
fill ~102 ~123 ~516 ~102 ~123 ~528 minecraft:redstone_wire replace
fill ~99 ~123 ~524 ~99 ~123 ~534 minecraft:redstone_wire replace
setblock ~108 ~123 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~528 ~108 ~123 ~540 minecraft:redstone_wire replace
setblock ~102 ~123 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~123 ~532 ~102 ~123 ~544 minecraft:redstone_wire replace
fill ~96 ~123 ~536 ~96 ~123 ~542 minecraft:redstone_wire replace
setblock ~99 ~123 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~123 ~542 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~96 ~123 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~544 ~108 ~123 ~556 minecraft:redstone_wire replace
setblock ~102 ~123 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~123 ~548 ~102 ~123 ~560 minecraft:redstone_wire replace
setblock ~108 ~123 ~557 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~558 ~108 ~123 ~570 minecraft:redstone_wire replace
setblock ~102 ~123 ~561 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~123 ~562 ~102 ~123 ~564 minecraft:redstone_wire replace
setblock ~108 ~123 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~123 ~572 ~108 ~123 ~576 minecraft:redstone_wire replace
fill ~120 ~123 ~588 ~120 ~123 ~600 minecraft:redstone_wire replace
fill ~117 ~123 ~592 ~117 ~123 ~604 minecraft:redstone_wire replace
fill ~114 ~123 ~596 ~114 ~123 ~602 minecraft:redstone_wire replace
setblock ~120 ~123 ~602 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~123 ~604 ~111 ~123 ~608 minecraft:redstone_wire replace
setblock ~114 ~123 ~604 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~123 ~604 ~120 ~123 ~616 minecraft:redstone_wire replace
setblock ~117 ~123 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~123 ~608 ~117 ~123 ~620 minecraft:redstone_wire replace
setblock ~120 ~123 ~617 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~123 ~618 ~120 ~123 ~620 minecraft:redstone_wire replace
setblock ~117 ~123 ~621 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~117 ~123 ~622 ~117 ~123 ~624 minecraft:redstone_wire replace
fill ~129 ~123 ~640 ~129 ~123 ~644 minecraft:redstone_wire replace
fill ~84 ~123 ~644 ~84 ~123 ~648 minecraft:redstone_wire replace
fill ~123 ~123 ~648 ~123 ~123 ~652 minecraft:redstone_wire replace
fill ~126 ~123 ~656 ~126 ~123 ~660 minecraft:redstone_wire replace
setblock ~105 ~124 ~385 minecraft:redstone_wire replace
setblock ~81 ~124 ~397 minecraft:redstone_wire replace
setblock ~87 ~124 ~501 minecraft:redstone_wire replace
setblock ~78 ~124 ~505 minecraft:redstone_wire replace
setblock ~90 ~124 ~509 minecraft:redstone_wire replace
setblock ~93 ~124 ~513 minecraft:redstone_wire replace
setblock ~99 ~124 ~537 minecraft:redstone_wire replace
setblock ~96 ~124 ~545 minecraft:redstone_wire replace
setblock ~102 ~124 ~565 minecraft:redstone_wire replace
setblock ~108 ~124 ~577 minecraft:redstone_wire replace
setblock ~114 ~124 ~605 minecraft:redstone_wire replace
setblock ~111 ~124 ~609 minecraft:redstone_wire replace
setblock ~120 ~124 ~621 minecraft:redstone_wire replace
setblock ~117 ~124 ~625 minecraft:redstone_wire replace
setblock ~129 ~124 ~645 minecraft:redstone_wire replace
setblock ~84 ~124 ~649 minecraft:redstone_wire replace
setblock ~123 ~124 ~653 minecraft:redstone_wire replace
setblock ~126 ~124 ~661 minecraft:redstone_wire replace
fill ~105 ~125 ~386 ~111 ~125 ~386 minecraft:redstone_wire replace
setblock ~113 ~125 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~125 ~386 ~119 ~125 ~386 minecraft:redstone_wire replace
setblock ~118 ~125 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~125 ~398 ~83 ~125 ~398 minecraft:redstone_wire replace
setblock ~82 ~125 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~125 ~502 ~89 ~125 ~502 minecraft:redstone_wire replace
setblock ~88 ~125 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~125 ~506 ~80 ~125 ~506 minecraft:redstone_wire replace
setblock ~79 ~125 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~125 ~510 ~92 ~125 ~510 minecraft:redstone_wire replace
setblock ~91 ~125 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~125 ~514 ~98 ~125 ~514 minecraft:redstone_wire replace
setblock ~99 ~125 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~100 ~125 ~514 ~112 ~125 ~514 minecraft:redstone_wire replace
setblock ~113 ~125 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~114 ~125 ~514 ~122 ~125 ~514 minecraft:redstone_wire replace
setblock ~94 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~125 ~515 minecraft:redstone_wire replace
setblock ~100 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~125 ~515 minecraft:redstone_wire replace
setblock ~106 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~125 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~125 ~515 minecraft:redstone_wire replace
setblock ~121 ~125 ~515 minecraft:redstone_wire replace
fill ~93 ~125 ~538 ~110 ~125 ~538 minecraft:redstone_wire replace
setblock ~111 ~125 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~125 ~538 ~124 ~125 ~538 minecraft:redstone_wire replace
setblock ~125 ~125 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~125 ~538 ~128 ~125 ~538 minecraft:redstone_wire replace
setblock ~94 ~125 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~125 ~539 minecraft:redstone_wire replace
setblock ~103 ~125 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~125 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~125 ~539 minecraft:redstone_wire replace
setblock ~115 ~125 ~539 minecraft:redstone_wire replace
setblock ~127 ~125 ~539 minecraft:redstone_wire replace
fill ~93 ~125 ~546 ~107 ~125 ~546 minecraft:redstone_wire replace
setblock ~108 ~125 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~125 ~546 ~121 ~125 ~546 minecraft:redstone_wire replace
setblock ~122 ~125 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~123 ~125 ~546 ~125 ~125 ~546 minecraft:redstone_wire replace
setblock ~94 ~125 ~547 minecraft:redstone_wire replace
setblock ~97 ~125 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~125 ~547 minecraft:redstone_wire replace
setblock ~109 ~125 ~547 minecraft:redstone_wire replace
setblock ~115 ~125 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~125 ~547 minecraft:redstone_wire replace
fill ~96 ~125 ~566 ~110 ~125 ~566 minecraft:redstone_wire replace
setblock ~111 ~125 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~125 ~566 ~124 ~125 ~566 minecraft:redstone_wire replace
setblock ~125 ~125 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~126 ~125 ~566 ~128 ~125 ~566 minecraft:redstone_wire replace
setblock ~97 ~125 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~125 ~567 minecraft:redstone_wire replace
setblock ~106 ~125 ~567 minecraft:redstone_wire replace
setblock ~112 ~125 ~567 minecraft:redstone_wire replace
setblock ~115 ~125 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~125 ~567 minecraft:redstone_wire replace
setblock ~127 ~125 ~567 minecraft:redstone_wire replace
fill ~108 ~125 ~578 ~114 ~125 ~578 minecraft:redstone_wire replace
setblock ~116 ~125 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~125 ~578 ~131 ~125 ~578 minecraft:redstone_wire replace
setblock ~132 ~125 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~125 ~578 ~146 ~125 ~578 minecraft:redstone_wire replace
setblock ~147 ~125 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~148 ~125 ~578 ~161 ~125 ~578 minecraft:redstone_wire replace
setblock ~130 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~125 ~579 minecraft:redstone_wire replace
setblock ~136 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~125 ~579 minecraft:redstone_wire replace
setblock ~142 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~125 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~125 ~579 minecraft:redstone_wire replace
setblock ~160 ~125 ~579 minecraft:redstone_wire replace
fill ~114 ~125 ~606 ~126 ~125 ~606 minecraft:redstone_wire replace
setblock ~128 ~125 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~125 ~606 ~143 ~125 ~606 minecraft:redstone_wire replace
setblock ~145 ~125 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~125 ~606 ~160 ~125 ~606 minecraft:redstone_wire replace
setblock ~161 ~125 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~125 ~606 ~164 ~125 ~606 minecraft:redstone_wire replace
setblock ~130 ~125 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~125 ~607 minecraft:redstone_wire replace
setblock ~139 ~125 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~125 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~125 ~607 minecraft:redstone_wire replace
setblock ~151 ~125 ~607 minecraft:redstone_wire replace
setblock ~163 ~125 ~607 minecraft:redstone_wire replace
fill ~111 ~125 ~610 ~117 ~125 ~610 minecraft:redstone_wire replace
setblock ~119 ~125 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~121 ~125 ~610 ~134 ~125 ~610 minecraft:redstone_wire replace
setblock ~136 ~125 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~138 ~125 ~610 ~151 ~125 ~610 minecraft:redstone_wire replace
setblock ~152 ~125 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~125 ~610 ~158 ~125 ~610 minecraft:redstone_wire replace
setblock ~130 ~125 ~611 minecraft:redstone_wire replace
setblock ~133 ~125 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~125 ~611 minecraft:redstone_wire replace
setblock ~145 ~125 ~611 minecraft:redstone_wire replace
setblock ~151 ~125 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~157 ~125 ~611 minecraft:redstone_wire replace
fill ~120 ~125 ~622 ~129 ~125 ~622 minecraft:redstone_wire replace
setblock ~131 ~125 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~125 ~622 ~146 ~125 ~622 minecraft:redstone_wire replace
setblock ~148 ~125 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~125 ~622 ~155 ~125 ~622 minecraft:redstone_wire replace
setblock ~154 ~125 ~623 minecraft:redstone_wire replace
fill ~117 ~125 ~626 ~126 ~125 ~626 minecraft:redstone_wire replace
setblock ~128 ~125 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~125 ~626 ~143 ~125 ~626 minecraft:redstone_wire replace
setblock ~145 ~125 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~125 ~626 ~160 ~125 ~626 minecraft:redstone_wire replace
setblock ~161 ~125 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~162 ~125 ~626 ~164 ~125 ~626 minecraft:redstone_wire replace
setblock ~133 ~125 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~125 ~627 minecraft:redstone_wire replace
setblock ~142 ~125 ~627 minecraft:redstone_wire replace
setblock ~148 ~125 ~627 minecraft:redstone_wire replace
setblock ~151 ~125 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~160 ~125 ~627 minecraft:redstone_wire replace
setblock ~163 ~125 ~627 minecraft:redstone_wire replace
fill ~129 ~125 ~646 ~135 ~125 ~646 minecraft:redstone_wire replace
setblock ~137 ~125 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~125 ~646 ~152 ~125 ~646 minecraft:redstone_wire replace
setblock ~154 ~125 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~125 ~646 ~169 ~125 ~646 minecraft:redstone_wire replace
setblock ~170 ~125 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~125 ~646 ~173 ~125 ~646 minecraft:redstone_wire replace
setblock ~172 ~125 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~125 ~650 ~86 ~125 ~650 minecraft:redstone_wire replace
setblock ~85 ~125 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~125 ~654 ~129 ~125 ~654 minecraft:redstone_wire replace
setblock ~131 ~125 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~125 ~654 ~146 ~125 ~654 minecraft:redstone_wire replace
setblock ~148 ~125 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~125 ~654 ~163 ~125 ~654 minecraft:redstone_wire replace
setblock ~164 ~125 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~125 ~654 ~167 ~125 ~654 minecraft:redstone_wire replace
setblock ~166 ~125 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~125 ~662 ~132 ~125 ~662 minecraft:redstone_wire replace
setblock ~134 ~125 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~125 ~662 ~149 ~125 ~662 minecraft:redstone_wire replace
setblock ~151 ~125 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~125 ~662 ~166 ~125 ~662 minecraft:redstone_wire replace
setblock ~167 ~125 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~168 ~125 ~662 ~170 ~125 ~662 minecraft:redstone_wire replace
setblock ~169 ~125 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~126 ~388 minecraft:redstone_wire replace
setblock ~82 ~126 ~400 minecraft:redstone_wire replace
setblock ~88 ~126 ~504 minecraft:redstone_wire replace
setblock ~79 ~126 ~508 minecraft:redstone_wire replace
setblock ~91 ~126 ~512 minecraft:redstone_wire replace
setblock ~94 ~126 ~516 minecraft:redstone_wire replace
setblock ~97 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~126 ~516 minecraft:redstone_wire replace
setblock ~103 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~126 ~516 minecraft:redstone_wire replace
setblock ~109 ~126 ~516 minecraft:redstone_wire replace
setblock ~112 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~126 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~126 ~540 minecraft:redstone_wire replace
setblock ~100 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~126 ~540 minecraft:redstone_wire replace
setblock ~106 ~126 ~540 minecraft:redstone_wire replace
setblock ~112 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~126 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~126 ~548 minecraft:redstone_wire replace
setblock ~103 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~126 ~548 minecraft:redstone_wire replace
setblock ~124 ~126 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~126 ~568 minecraft:redstone_wire replace
setblock ~100 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~126 ~568 minecraft:redstone_wire replace
setblock ~121 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~126 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~126 ~580 minecraft:redstone_wire replace
setblock ~133 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~126 ~580 minecraft:redstone_wire replace
setblock ~139 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~126 ~580 minecraft:redstone_wire replace
setblock ~145 ~126 ~580 minecraft:redstone_wire replace
setblock ~148 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~126 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~126 ~608 minecraft:redstone_wire replace
setblock ~136 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~126 ~608 minecraft:redstone_wire replace
setblock ~142 ~126 ~608 minecraft:redstone_wire replace
setblock ~148 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~126 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~126 ~612 minecraft:redstone_wire replace
setblock ~139 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~126 ~612 minecraft:redstone_wire replace
setblock ~157 ~126 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~126 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~126 ~628 minecraft:redstone_wire replace
setblock ~136 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~126 ~628 minecraft:redstone_wire replace
setblock ~160 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~126 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~126 ~648 minecraft:redstone_wire replace
setblock ~85 ~126 ~652 minecraft:redstone_wire replace
setblock ~166 ~126 ~656 minecraft:redstone_wire replace
setblock ~169 ~126 ~664 minecraft:redstone_wire replace
fill ~117 ~127 ~384 ~117 ~127 ~388 minecraft:redstone_wire replace
fill ~81 ~127 ~396 ~81 ~127 ~400 minecraft:redstone_wire replace
setblock ~87 ~127 ~472 minecraft:redstone_wire replace
setblock ~87 ~127 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~127 ~476 minecraft:redstone_wire replace
fill ~87 ~127 ~476 ~87 ~127 ~488 minecraft:redstone_wire replace
setblock ~78 ~127 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~127 ~480 ~78 ~127 ~492 minecraft:redstone_wire replace
setblock ~90 ~127 ~480 minecraft:redstone_wire replace
setblock ~90 ~127 ~482 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~127 ~484 ~90 ~127 ~496 minecraft:redstone_wire replace
fill ~120 ~127 ~484 ~120 ~127 ~488 minecraft:redstone_wire replace
fill ~111 ~127 ~488 ~111 ~127 ~490 minecraft:redstone_wire replace
setblock ~87 ~127 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~127 ~492 ~87 ~127 ~504 minecraft:redstone_wire replace
setblock ~108 ~127 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~492 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~127 ~492 ~120 ~127 ~504 minecraft:redstone_wire replace
setblock ~78 ~127 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~127 ~494 ~108 ~127 ~500 minecraft:redstone_wire replace
fill ~111 ~127 ~494 ~111 ~127 ~506 minecraft:redstone_wire replace
fill ~78 ~127 ~496 ~78 ~127 ~508 minecraft:redstone_wire replace
setblock ~105 ~127 ~496 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~127 ~498 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~127 ~498 ~105 ~127 ~506 minecraft:redstone_wire replace
fill ~90 ~127 ~500 ~90 ~127 ~512 minecraft:redstone_wire replace
setblock ~102 ~127 ~500 minecraft:redstone_wire replace
setblock ~102 ~127 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~127 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~127 ~504 ~99 ~127 ~506 minecraft:redstone_wire replace
fill ~102 ~127 ~504 ~102 ~127 ~516 minecraft:redstone_wire replace
fill ~108 ~127 ~504 ~108 ~127 ~516 minecraft:redstone_wire replace
setblock ~120 ~127 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~508 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~127 ~508 ~120 ~127 ~520 minecraft:redstone_wire replace
fill ~96 ~127 ~510 ~96 ~127 ~520 minecraft:redstone_wire replace
fill ~99 ~127 ~510 ~99 ~127 ~522 minecraft:redstone_wire replace
fill ~105 ~127 ~510 ~105 ~127 ~522 minecraft:redstone_wire replace
fill ~111 ~127 ~510 ~111 ~127 ~522 minecraft:redstone_wire replace
fill ~93 ~127 ~512 ~93 ~127 ~516 minecraft:redstone_wire replace
setblock ~93 ~127 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~127 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~127 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~127 ~520 ~93 ~127 ~532 minecraft:redstone_wire replace
fill ~102 ~127 ~520 ~102 ~127 ~532 minecraft:redstone_wire replace
fill ~108 ~127 ~520 ~108 ~127 ~532 minecraft:redstone_wire replace
setblock ~96 ~127 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~127 ~524 ~96 ~127 ~536 minecraft:redstone_wire replace
setblock ~99 ~127 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~127 ~524 ~120 ~127 ~536 minecraft:redstone_wire replace
fill ~99 ~127 ~526 ~99 ~127 ~538 minecraft:redstone_wire replace
fill ~105 ~127 ~526 ~105 ~127 ~538 minecraft:redstone_wire replace
fill ~111 ~127 ~526 ~111 ~127 ~538 minecraft:redstone_wire replace
fill ~126 ~127 ~532 ~126 ~127 ~538 minecraft:redstone_wire replace
setblock ~93 ~127 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~127 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~127 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~127 ~536 ~93 ~127 ~548 minecraft:redstone_wire replace
fill ~102 ~127 ~536 ~102 ~127 ~548 minecraft:redstone_wire replace
fill ~108 ~127 ~536 ~108 ~127 ~548 minecraft:redstone_wire replace
fill ~114 ~127 ~536 ~114 ~127 ~538 minecraft:redstone_wire replace
setblock ~96 ~127 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~127 ~539 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~127 ~540 ~96 ~127 ~552 minecraft:redstone_wire replace
fill ~99 ~127 ~540 ~99 ~127 ~552 minecraft:redstone_wire replace
fill ~105 ~127 ~540 ~105 ~127 ~552 minecraft:redstone_wire replace
fill ~111 ~127 ~540 ~111 ~127 ~552 minecraft:redstone_wire replace
fill ~114 ~127 ~540 ~114 ~127 ~552 minecraft:redstone_wire replace
fill ~120 ~127 ~540 ~120 ~127 ~552 minecraft:redstone_wire replace
fill ~126 ~127 ~540 ~126 ~127 ~552 minecraft:redstone_wire replace
fill ~123 ~127 ~544 ~123 ~127 ~548 minecraft:redstone_wire replace
setblock ~159 ~127 ~548 minecraft:redstone_wire replace
setblock ~159 ~127 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~127 ~552 ~159 ~127 ~564 minecraft:redstone_wire replace
setblock ~96 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~127 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~127 ~554 ~147 ~127 ~564 minecraft:redstone_wire replace
fill ~96 ~127 ~556 ~96 ~127 ~568 minecraft:redstone_wire replace
fill ~99 ~127 ~556 ~99 ~127 ~568 minecraft:redstone_wire replace
fill ~105 ~127 ~556 ~105 ~127 ~568 minecraft:redstone_wire replace
fill ~111 ~127 ~556 ~111 ~127 ~568 minecraft:redstone_wire replace
fill ~114 ~127 ~556 ~114 ~127 ~568 minecraft:redstone_wire replace
fill ~120 ~127 ~556 ~120 ~127 ~568 minecraft:redstone_wire replace
fill ~126 ~127 ~556 ~126 ~127 ~568 minecraft:redstone_wire replace
setblock ~144 ~127 ~556 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~127 ~558 ~144 ~127 ~564 minecraft:redstone_wire replace
fill ~141 ~127 ~560 ~141 ~127 ~564 minecraft:redstone_wire replace
setblock ~138 ~127 ~564 minecraft:redstone_wire replace
setblock ~138 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~568 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~127 ~568 ~138 ~127 ~580 minecraft:redstone_wire replace
fill ~141 ~127 ~568 ~141 ~127 ~580 minecraft:redstone_wire replace
fill ~144 ~127 ~568 ~144 ~127 ~580 minecraft:redstone_wire replace
fill ~147 ~127 ~568 ~147 ~127 ~580 minecraft:redstone_wire replace
fill ~159 ~127 ~568 ~159 ~127 ~580 minecraft:redstone_wire replace
fill ~135 ~127 ~570 ~135 ~127 ~580 minecraft:redstone_wire replace
setblock ~132 ~127 ~572 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~127 ~574 ~132 ~127 ~580 minecraft:redstone_wire replace
fill ~129 ~127 ~576 ~129 ~127 ~580 minecraft:redstone_wire replace
setblock ~129 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~127 ~584 ~129 ~127 ~596 minecraft:redstone_wire replace
fill ~132 ~127 ~584 ~132 ~127 ~596 minecraft:redstone_wire replace
fill ~135 ~127 ~584 ~135 ~127 ~596 minecraft:redstone_wire replace
fill ~138 ~127 ~584 ~138 ~127 ~596 minecraft:redstone_wire replace
fill ~141 ~127 ~584 ~141 ~127 ~596 minecraft:redstone_wire replace
fill ~144 ~127 ~584 ~144 ~127 ~596 minecraft:redstone_wire replace
fill ~147 ~127 ~584 ~147 ~127 ~596 minecraft:redstone_wire replace
fill ~159 ~127 ~584 ~159 ~127 ~596 minecraft:redstone_wire replace
setblock ~129 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~127 ~600 ~129 ~127 ~612 minecraft:redstone_wire replace
fill ~132 ~127 ~600 ~132 ~127 ~612 minecraft:redstone_wire replace
fill ~135 ~127 ~600 ~135 ~127 ~612 minecraft:redstone_wire replace
fill ~138 ~127 ~600 ~138 ~127 ~612 minecraft:redstone_wire replace
fill ~141 ~127 ~600 ~141 ~127 ~612 minecraft:redstone_wire replace
fill ~144 ~127 ~600 ~144 ~127 ~612 minecraft:redstone_wire replace
fill ~147 ~127 ~600 ~147 ~127 ~612 minecraft:redstone_wire replace
fill ~159 ~127 ~600 ~159 ~127 ~612 minecraft:redstone_wire replace
setblock ~162 ~127 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~127 ~602 ~162 ~127 ~612 minecraft:redstone_wire replace
setblock ~150 ~127 ~604 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~127 ~606 ~150 ~127 ~612 minecraft:redstone_wire replace
fill ~156 ~127 ~608 ~156 ~127 ~612 minecraft:redstone_wire replace
setblock ~132 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~127 ~614 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~127 ~616 ~132 ~127 ~628 minecraft:redstone_wire replace
fill ~135 ~127 ~616 ~135 ~127 ~628 minecraft:redstone_wire replace
fill ~141 ~127 ~616 ~141 ~127 ~628 minecraft:redstone_wire replace
fill ~147 ~127 ~616 ~147 ~127 ~628 minecraft:redstone_wire replace
fill ~150 ~127 ~616 ~150 ~127 ~628 minecraft:redstone_wire replace
fill ~159 ~127 ~616 ~159 ~127 ~628 minecraft:redstone_wire replace
fill ~162 ~127 ~616 ~162 ~127 ~628 minecraft:redstone_wire replace
fill ~153 ~127 ~620 ~153 ~127 ~624 minecraft:redstone_wire replace
fill ~171 ~127 ~644 ~171 ~127 ~648 minecraft:redstone_wire replace
fill ~84 ~127 ~648 ~84 ~127 ~652 minecraft:redstone_wire replace
fill ~165 ~127 ~652 ~165 ~127 ~656 minecraft:redstone_wire replace
fill ~168 ~127 ~660 ~168 ~127 ~664 minecraft:redstone_wire replace
setblock ~117 ~128 ~383 minecraft:redstone_wire replace
setblock ~81 ~128 ~395 minecraft:redstone_wire replace
setblock ~87 ~128 ~471 minecraft:redstone_wire replace
setblock ~78 ~128 ~475 minecraft:redstone_wire replace
setblock ~90 ~128 ~479 minecraft:redstone_wire replace
setblock ~120 ~128 ~483 minecraft:redstone_wire replace
setblock ~111 ~128 ~487 minecraft:redstone_wire replace
setblock ~108 ~128 ~491 minecraft:redstone_wire replace
setblock ~105 ~128 ~495 minecraft:redstone_wire replace
setblock ~102 ~128 ~499 minecraft:redstone_wire replace
setblock ~99 ~128 ~503 minecraft:redstone_wire replace
setblock ~96 ~128 ~507 minecraft:redstone_wire replace
setblock ~93 ~128 ~511 minecraft:redstone_wire replace
setblock ~126 ~128 ~531 minecraft:redstone_wire replace
setblock ~114 ~128 ~535 minecraft:redstone_wire replace
setblock ~123 ~128 ~543 minecraft:redstone_wire replace
setblock ~159 ~128 ~547 minecraft:redstone_wire replace
setblock ~147 ~128 ~551 minecraft:redstone_wire replace
setblock ~144 ~128 ~555 minecraft:redstone_wire replace
setblock ~141 ~128 ~559 minecraft:redstone_wire replace
setblock ~138 ~128 ~563 minecraft:redstone_wire replace
setblock ~135 ~128 ~567 minecraft:redstone_wire replace
setblock ~132 ~128 ~571 minecraft:redstone_wire replace
setblock ~129 ~128 ~575 minecraft:redstone_wire replace
setblock ~162 ~128 ~599 minecraft:redstone_wire replace
setblock ~150 ~128 ~603 minecraft:redstone_wire replace
setblock ~156 ~128 ~607 minecraft:redstone_wire replace
setblock ~153 ~128 ~619 minecraft:redstone_wire replace
setblock ~171 ~128 ~643 minecraft:redstone_wire replace
setblock ~84 ~128 ~647 minecraft:redstone_wire replace
setblock ~165 ~128 ~651 minecraft:redstone_wire replace
setblock ~168 ~128 ~659 minecraft:redstone_wire replace
setblock ~103 ~129 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~129 ~382 ~107 ~129 ~382 minecraft:redstone_wire replace
setblock ~109 ~129 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~129 ~382 ~117 ~129 ~382 minecraft:redstone_wire replace
setblock ~82 ~129 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~129 ~394 ~83 ~129 ~394 minecraft:redstone_wire replace
setblock ~88 ~129 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~129 ~470 ~89 ~129 ~470 minecraft:redstone_wire replace
setblock ~79 ~129 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~129 ~474 ~80 ~129 ~474 minecraft:redstone_wire replace
setblock ~91 ~129 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~129 ~478 ~92 ~129 ~478 minecraft:redstone_wire replace
setblock ~106 ~129 ~481 minecraft:redstone_wire replace
fill ~105 ~129 ~482 ~109 ~129 ~482 minecraft:redstone_wire replace
setblock ~111 ~129 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~129 ~482 ~120 ~129 ~482 minecraft:redstone_wire replace
setblock ~100 ~129 ~485 minecraft:redstone_wire replace
fill ~99 ~129 ~486 ~100 ~129 ~486 minecraft:redstone_wire replace
setblock ~101 ~129 ~486 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~129 ~486 ~111 ~129 ~486 minecraft:redstone_wire replace
setblock ~100 ~129 ~489 minecraft:redstone_wire replace
fill ~99 ~129 ~490 ~108 ~129 ~490 minecraft:redstone_wire replace
setblock ~97 ~129 ~493 minecraft:redstone_wire replace
fill ~96 ~129 ~494 ~105 ~129 ~494 minecraft:redstone_wire replace
setblock ~97 ~129 ~497 minecraft:redstone_wire replace
fill ~96 ~129 ~498 ~102 ~129 ~498 minecraft:redstone_wire replace
setblock ~94 ~129 ~501 minecraft:redstone_wire replace
fill ~93 ~129 ~502 ~99 ~129 ~502 minecraft:redstone_wire replace
setblock ~94 ~129 ~505 minecraft:redstone_wire replace
fill ~93 ~129 ~506 ~96 ~129 ~506 minecraft:redstone_wire replace
setblock ~94 ~129 ~509 minecraft:redstone_wire replace
fill ~93 ~129 ~510 ~95 ~129 ~510 minecraft:redstone_wire replace
setblock ~106 ~129 ~529 minecraft:redstone_wire replace
fill ~105 ~129 ~530 ~117 ~129 ~530 minecraft:redstone_wire replace
setblock ~119 ~129 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~129 ~530 ~126 ~129 ~530 minecraft:redstone_wire replace
setblock ~100 ~129 ~533 minecraft:redstone_wire replace
fill ~99 ~129 ~534 ~101 ~129 ~534 minecraft:redstone_wire replace
setblock ~103 ~129 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~129 ~534 ~114 ~129 ~534 minecraft:redstone_wire replace
setblock ~106 ~129 ~541 minecraft:redstone_wire replace
fill ~105 ~129 ~542 ~113 ~129 ~542 minecraft:redstone_wire replace
setblock ~115 ~129 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~129 ~542 ~123 ~129 ~542 minecraft:redstone_wire replace
setblock ~121 ~129 ~545 minecraft:redstone_wire replace
fill ~120 ~129 ~546 ~127 ~129 ~546 minecraft:redstone_wire replace
setblock ~129 ~129 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~129 ~546 ~144 ~129 ~546 minecraft:redstone_wire replace
setblock ~146 ~129 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~129 ~546 ~159 ~129 ~546 minecraft:redstone_wire replace
setblock ~115 ~129 ~549 minecraft:redstone_wire replace
fill ~114 ~129 ~550 ~116 ~129 ~550 minecraft:redstone_wire replace
setblock ~117 ~129 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~129 ~550 ~131 ~129 ~550 minecraft:redstone_wire replace
setblock ~133 ~129 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~129 ~550 ~147 ~129 ~550 minecraft:redstone_wire replace
setblock ~115 ~129 ~553 minecraft:redstone_wire replace
setblock ~114 ~129 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~129 ~554 ~128 ~129 ~554 minecraft:redstone_wire replace
setblock ~130 ~129 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~129 ~554 ~144 ~129 ~554 minecraft:redstone_wire replace
setblock ~112 ~129 ~557 minecraft:redstone_wire replace
fill ~111 ~129 ~558 ~113 ~129 ~558 minecraft:redstone_wire replace
setblock ~115 ~129 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~129 ~558 ~130 ~129 ~558 minecraft:redstone_wire replace
setblock ~132 ~129 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~129 ~558 ~141 ~129 ~558 minecraft:redstone_wire replace
setblock ~112 ~129 ~561 minecraft:redstone_wire replace
fill ~111 ~129 ~562 ~123 ~129 ~562 minecraft:redstone_wire replace
setblock ~125 ~129 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~129 ~562 ~138 ~129 ~562 minecraft:redstone_wire replace
setblock ~109 ~129 ~565 minecraft:redstone_wire replace
fill ~108 ~129 ~566 ~119 ~129 ~566 minecraft:redstone_wire replace
setblock ~121 ~129 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~129 ~566 ~135 ~129 ~566 minecraft:redstone_wire replace
setblock ~109 ~129 ~569 minecraft:redstone_wire replace
fill ~108 ~129 ~570 ~116 ~129 ~570 minecraft:redstone_wire replace
setblock ~118 ~129 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~129 ~570 ~132 ~129 ~570 minecraft:redstone_wire replace
setblock ~109 ~129 ~573 minecraft:redstone_wire replace
fill ~108 ~129 ~574 ~119 ~129 ~574 minecraft:redstone_wire replace
setblock ~121 ~129 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~129 ~574 ~129 ~129 ~574 minecraft:redstone_wire replace
setblock ~121 ~129 ~597 minecraft:redstone_wire replace
fill ~120 ~129 ~598 ~129 ~129 ~598 minecraft:redstone_wire replace
setblock ~131 ~129 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~129 ~598 ~146 ~129 ~598 minecraft:redstone_wire replace
setblock ~148 ~129 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~129 ~598 ~162 ~129 ~598 minecraft:redstone_wire replace
setblock ~115 ~129 ~601 minecraft:redstone_wire replace
fill ~114 ~129 ~602 ~117 ~129 ~602 minecraft:redstone_wire replace
setblock ~119 ~129 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~129 ~602 ~134 ~129 ~602 minecraft:redstone_wire replace
setblock ~136 ~129 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~129 ~602 ~150 ~129 ~602 minecraft:redstone_wire replace
setblock ~121 ~129 ~605 minecraft:redstone_wire replace
fill ~120 ~129 ~606 ~129 ~129 ~606 minecraft:redstone_wire replace
setblock ~131 ~129 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~129 ~606 ~146 ~129 ~606 minecraft:redstone_wire replace
setblock ~148 ~129 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~129 ~606 ~156 ~129 ~606 minecraft:redstone_wire replace
setblock ~118 ~129 ~617 minecraft:redstone_wire replace
fill ~117 ~129 ~618 ~126 ~129 ~618 minecraft:redstone_wire replace
setblock ~128 ~129 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~129 ~618 ~143 ~129 ~618 minecraft:redstone_wire replace
setblock ~145 ~129 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~129 ~618 ~153 ~129 ~618 minecraft:redstone_wire replace
setblock ~130 ~129 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~129 ~642 ~130 ~129 ~642 minecraft:redstone_wire replace
setblock ~132 ~129 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~129 ~642 ~146 ~129 ~642 minecraft:redstone_wire replace
setblock ~148 ~129 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~129 ~642 ~162 ~129 ~642 minecraft:redstone_wire replace
setblock ~164 ~129 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~129 ~642 ~171 ~129 ~642 minecraft:redstone_wire replace
setblock ~85 ~129 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~129 ~646 ~86 ~129 ~646 minecraft:redstone_wire replace
setblock ~124 ~129 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~129 ~650 ~124 ~129 ~650 minecraft:redstone_wire replace
setblock ~126 ~129 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~129 ~650 ~140 ~129 ~650 minecraft:redstone_wire replace
setblock ~142 ~129 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~129 ~650 ~156 ~129 ~650 minecraft:redstone_wire replace
setblock ~158 ~129 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~129 ~650 ~165 ~129 ~650 minecraft:redstone_wire replace
setblock ~127 ~129 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~129 ~658 ~127 ~129 ~658 minecraft:redstone_wire replace
setblock ~129 ~129 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~129 ~658 ~143 ~129 ~658 minecraft:redstone_wire replace
setblock ~145 ~129 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~129 ~658 ~159 ~129 ~658 minecraft:redstone_wire replace
setblock ~161 ~129 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~129 ~658 ~168 ~129 ~658 minecraft:redstone_wire replace
setblock ~103 ~130 ~380 minecraft:redstone_wire replace
setblock ~82 ~130 ~392 minecraft:redstone_wire replace
setblock ~88 ~130 ~468 minecraft:redstone_wire replace
setblock ~79 ~130 ~472 minecraft:redstone_wire replace
setblock ~91 ~130 ~476 minecraft:redstone_wire replace
setblock ~106 ~130 ~480 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~130 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~130 ~488 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~130 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~130 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~130 ~500 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~130 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~130 ~508 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~130 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~130 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~130 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~130 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~130 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~130 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~130 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~130 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~130 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~130 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~130 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~130 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~130 ~600 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~130 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~130 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~130 ~640 minecraft:redstone_wire replace
setblock ~85 ~130 ~644 minecraft:redstone_wire replace
setblock ~124 ~130 ~648 minecraft:redstone_wire replace
setblock ~127 ~130 ~656 minecraft:redstone_wire replace
fill ~102 ~131 ~380 ~102 ~131 ~384 minecraft:redstone_wire replace
fill ~81 ~131 ~392 ~81 ~131 ~396 minecraft:redstone_wire replace
fill ~87 ~131 ~468 ~87 ~131 ~472 minecraft:redstone_wire replace
fill ~78 ~131 ~472 ~78 ~131 ~476 minecraft:redstone_wire replace
fill ~90 ~131 ~476 ~90 ~131 ~480 minecraft:redstone_wire replace
fill ~105 ~131 ~480 ~105 ~131 ~492 minecraft:redstone_wire replace
fill ~99 ~131 ~484 ~99 ~131 ~496 minecraft:redstone_wire replace
fill ~96 ~131 ~492 ~96 ~131 ~498 minecraft:redstone_wire replace
setblock ~105 ~131 ~494 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~496 ~105 ~131 ~508 minecraft:redstone_wire replace
setblock ~99 ~131 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~131 ~500 ~93 ~131 ~510 minecraft:redstone_wire replace
setblock ~96 ~131 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~131 ~500 ~99 ~131 ~512 minecraft:redstone_wire replace
setblock ~105 ~131 ~510 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~93 ~131 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~512 ~105 ~131 ~524 minecraft:redstone_wire replace
setblock ~99 ~131 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~131 ~516 ~99 ~131 ~528 minecraft:redstone_wire replace
setblock ~105 ~131 ~526 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~528 ~105 ~131 ~540 minecraft:redstone_wire replace
setblock ~99 ~131 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~131 ~532 ~99 ~131 ~536 minecraft:redstone_wire replace
setblock ~105 ~131 ~541 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~131 ~542 ~105 ~131 ~544 minecraft:redstone_wire replace
fill ~120 ~131 ~544 ~120 ~131 ~556 minecraft:redstone_wire replace
fill ~114 ~131 ~548 ~114 ~131 ~560 minecraft:redstone_wire replace
fill ~111 ~131 ~556 ~111 ~131 ~562 minecraft:redstone_wire replace
setblock ~120 ~131 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~560 ~120 ~131 ~572 minecraft:redstone_wire replace
setblock ~114 ~131 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~131 ~564 ~108 ~131 ~574 minecraft:redstone_wire replace
setblock ~111 ~131 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~131 ~564 ~114 ~131 ~576 minecraft:redstone_wire replace
setblock ~120 ~131 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~108 ~131 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~576 ~120 ~131 ~588 minecraft:redstone_wire replace
setblock ~114 ~131 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~131 ~580 ~114 ~131 ~592 minecraft:redstone_wire replace
setblock ~120 ~131 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~592 ~120 ~131 ~604 minecraft:redstone_wire replace
setblock ~114 ~131 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~131 ~596 ~114 ~131 ~602 minecraft:redstone_wire replace
setblock ~114 ~131 ~604 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~120 ~131 ~605 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~131 ~606 ~120 ~131 ~608 minecraft:redstone_wire replace
fill ~117 ~131 ~616 ~117 ~131 ~620 minecraft:redstone_wire replace
fill ~129 ~131 ~640 ~129 ~131 ~644 minecraft:redstone_wire replace
fill ~84 ~131 ~644 ~84 ~131 ~648 minecraft:redstone_wire replace
fill ~123 ~131 ~648 ~123 ~131 ~652 minecraft:redstone_wire replace
fill ~126 ~131 ~656 ~126 ~131 ~660 minecraft:redstone_wire replace
setblock ~102 ~132 ~385 minecraft:redstone_wire replace
setblock ~81 ~132 ~397 minecraft:redstone_wire replace
setblock ~87 ~132 ~473 minecraft:redstone_wire replace
setblock ~78 ~132 ~477 minecraft:redstone_wire replace
setblock ~90 ~132 ~481 minecraft:redstone_wire replace
setblock ~96 ~132 ~501 minecraft:redstone_wire replace
setblock ~93 ~132 ~513 minecraft:redstone_wire replace
setblock ~99 ~132 ~537 minecraft:redstone_wire replace
setblock ~105 ~132 ~545 minecraft:redstone_wire replace
setblock ~111 ~132 ~565 minecraft:redstone_wire replace
setblock ~108 ~132 ~577 minecraft:redstone_wire replace
setblock ~114 ~132 ~605 minecraft:redstone_wire replace
setblock ~120 ~132 ~609 minecraft:redstone_wire replace
setblock ~117 ~132 ~621 minecraft:redstone_wire replace
setblock ~129 ~132 ~645 minecraft:redstone_wire replace
setblock ~84 ~132 ~649 minecraft:redstone_wire replace
setblock ~123 ~132 ~653 minecraft:redstone_wire replace
setblock ~126 ~132 ~661 minecraft:redstone_wire replace
fill ~102 ~133 ~386 ~108 ~133 ~386 minecraft:redstone_wire replace
setblock ~110 ~133 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~133 ~386 ~116 ~133 ~386 minecraft:redstone_wire replace
setblock ~115 ~133 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~133 ~398 ~83 ~133 ~398 minecraft:redstone_wire replace
setblock ~82 ~133 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~133 ~474 ~89 ~133 ~474 minecraft:redstone_wire replace
setblock ~88 ~133 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~133 ~478 ~80 ~133 ~478 minecraft:redstone_wire replace
setblock ~79 ~133 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~133 ~482 ~95 ~133 ~482 minecraft:redstone_wire replace
setblock ~96 ~133 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~97 ~133 ~482 ~109 ~133 ~482 minecraft:redstone_wire replace
setblock ~110 ~133 ~482 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~111 ~133 ~482 ~119 ~133 ~482 minecraft:redstone_wire replace
setblock ~91 ~133 ~483 minecraft:redstone_wire replace
setblock ~94 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~133 ~483 minecraft:redstone_wire replace
setblock ~106 ~133 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~133 ~483 minecraft:redstone_wire replace
setblock ~118 ~133 ~483 minecraft:redstone_wire replace
fill ~90 ~133 ~502 ~108 ~133 ~502 minecraft:redstone_wire replace
setblock ~110 ~133 ~502 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~112 ~133 ~502 ~125 ~133 ~502 minecraft:redstone_wire replace
setblock ~91 ~133 ~503 minecraft:redstone_wire replace
setblock ~97 ~133 ~503 minecraft:redstone_wire replace
setblock ~103 ~133 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~133 ~503 minecraft:redstone_wire replace
setblock ~112 ~133 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~133 ~503 minecraft:redstone_wire replace
fill ~90 ~133 ~514 ~105 ~133 ~514 minecraft:redstone_wire replace
setblock ~107 ~133 ~514 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~133 ~514 ~122 ~133 ~514 minecraft:redstone_wire replace
setblock ~91 ~133 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~94 ~133 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~97 ~133 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~133 ~515 minecraft:redstone_wire replace
setblock ~109 ~133 ~515 minecraft:redstone_wire replace
setblock ~112 ~133 ~515 minecraft:redstone_wire replace
setblock ~121 ~133 ~515 minecraft:redstone_wire replace
fill ~93 ~133 ~538 ~105 ~133 ~538 minecraft:redstone_wire replace
setblock ~107 ~133 ~538 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~109 ~133 ~538 ~122 ~133 ~538 minecraft:redstone_wire replace
setblock ~94 ~133 ~539 minecraft:redstone_wire replace
setblock ~100 ~133 ~539 minecraft:redstone_wire replace
setblock ~103 ~133 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~133 ~539 minecraft:redstone_wire replace
setblock ~112 ~133 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~118 ~133 ~539 minecraft:redstone_wire replace
setblock ~121 ~133 ~539 minecraft:redstone_wire replace
fill ~105 ~133 ~546 ~114 ~133 ~546 minecraft:redstone_wire replace
setblock ~116 ~133 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~133 ~546 ~131 ~133 ~546 minecraft:redstone_wire replace
setblock ~132 ~133 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~133 ~546 ~146 ~133 ~546 minecraft:redstone_wire replace
setblock ~148 ~133 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~133 ~546 ~152 ~133 ~546 minecraft:redstone_wire replace
setblock ~127 ~133 ~547 minecraft:redstone_wire replace
setblock ~130 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~133 ~547 minecraft:redstone_wire replace
setblock ~142 ~133 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~133 ~547 minecraft:redstone_wire replace
setblock ~151 ~133 ~547 minecraft:redstone_wire replace
fill ~111 ~133 ~566 ~123 ~133 ~566 minecraft:redstone_wire replace
setblock ~125 ~133 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~133 ~566 ~140 ~133 ~566 minecraft:redstone_wire replace
setblock ~141 ~133 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~133 ~566 ~155 ~133 ~566 minecraft:redstone_wire replace
setblock ~127 ~133 ~567 minecraft:redstone_wire replace
setblock ~133 ~133 ~567 minecraft:redstone_wire replace
setblock ~139 ~133 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~133 ~567 minecraft:redstone_wire replace
setblock ~148 ~133 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~154 ~133 ~567 minecraft:redstone_wire replace
fill ~108 ~133 ~578 ~120 ~133 ~578 minecraft:redstone_wire replace
setblock ~122 ~133 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~133 ~578 ~137 ~133 ~578 minecraft:redstone_wire replace
setblock ~139 ~133 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~141 ~133 ~578 ~154 ~133 ~578 minecraft:redstone_wire replace
setblock ~155 ~133 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~133 ~578 ~158 ~133 ~578 minecraft:redstone_wire replace
setblock ~127 ~133 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~133 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~133 ~133 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~133 ~579 minecraft:redstone_wire replace
setblock ~145 ~133 ~579 minecraft:redstone_wire replace
setblock ~148 ~133 ~579 minecraft:redstone_wire replace
setblock ~157 ~133 ~579 minecraft:redstone_wire replace
fill ~114 ~133 ~606 ~126 ~133 ~606 minecraft:redstone_wire replace
setblock ~128 ~133 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~133 ~606 ~143 ~133 ~606 minecraft:redstone_wire replace
setblock ~144 ~133 ~606 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~145 ~133 ~606 ~158 ~133 ~606 minecraft:redstone_wire replace
setblock ~130 ~133 ~607 minecraft:redstone_wire replace
setblock ~136 ~133 ~607 minecraft:redstone_wire replace
setblock ~139 ~133 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~145 ~133 ~607 minecraft:redstone_wire replace
setblock ~148 ~133 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~151 ~133 ~607 minecraft:redstone_wire replace
setblock ~157 ~133 ~607 minecraft:redstone_wire replace
fill ~120 ~133 ~610 ~129 ~133 ~610 minecraft:redstone_wire replace
setblock ~131 ~133 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~133 ~610 ~146 ~133 ~610 minecraft:redstone_wire replace
setblock ~148 ~133 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~133 ~610 ~163 ~133 ~610 minecraft:redstone_wire replace
setblock ~164 ~133 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~163 ~133 ~611 minecraft:redstone_wire replace
fill ~117 ~133 ~622 ~123 ~133 ~622 minecraft:redstone_wire replace
setblock ~125 ~133 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~133 ~622 ~140 ~133 ~622 minecraft:redstone_wire replace
setblock ~142 ~133 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~144 ~133 ~622 ~157 ~133 ~622 minecraft:redstone_wire replace
setblock ~158 ~133 ~622 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~159 ~133 ~622 ~161 ~133 ~622 minecraft:redstone_wire replace
setblock ~160 ~133 ~623 minecraft:redstone_wire replace
fill ~129 ~133 ~646 ~135 ~133 ~646 minecraft:redstone_wire replace
setblock ~137 ~133 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~133 ~646 ~152 ~133 ~646 minecraft:redstone_wire replace
setblock ~154 ~133 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~156 ~133 ~646 ~169 ~133 ~646 minecraft:redstone_wire replace
setblock ~170 ~133 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~133 ~646 ~173 ~133 ~646 minecraft:redstone_wire replace
setblock ~172 ~133 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~133 ~650 ~86 ~133 ~650 minecraft:redstone_wire replace
setblock ~85 ~133 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~133 ~654 ~129 ~133 ~654 minecraft:redstone_wire replace
setblock ~131 ~133 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~133 ~654 ~146 ~133 ~654 minecraft:redstone_wire replace
setblock ~148 ~133 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~133 ~654 ~163 ~133 ~654 minecraft:redstone_wire replace
setblock ~164 ~133 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~165 ~133 ~654 ~167 ~133 ~654 minecraft:redstone_wire replace
setblock ~166 ~133 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~133 ~662 ~132 ~133 ~662 minecraft:redstone_wire replace
setblock ~134 ~133 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~133 ~662 ~149 ~133 ~662 minecraft:redstone_wire replace
setblock ~151 ~133 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~133 ~662 ~166 ~133 ~662 minecraft:redstone_wire replace
setblock ~167 ~133 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~168 ~133 ~662 ~170 ~133 ~662 minecraft:redstone_wire replace
setblock ~169 ~133 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~134 ~388 minecraft:redstone_wire replace
setblock ~82 ~134 ~400 minecraft:redstone_wire replace
setblock ~88 ~134 ~476 minecraft:redstone_wire replace
setblock ~79 ~134 ~480 minecraft:redstone_wire replace
setblock ~91 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~134 ~484 minecraft:redstone_wire replace
setblock ~97 ~134 ~484 minecraft:redstone_wire replace
setblock ~100 ~134 ~484 minecraft:redstone_wire replace
setblock ~103 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~134 ~484 minecraft:redstone_wire replace
setblock ~109 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~134 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~134 ~504 minecraft:redstone_wire replace
setblock ~106 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~134 ~504 minecraft:redstone_wire replace
setblock ~124 ~134 ~504 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~134 ~516 minecraft:redstone_wire replace
setblock ~94 ~134 ~516 minecraft:redstone_wire replace
setblock ~97 ~134 ~516 minecraft:redstone_wire replace
setblock ~100 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~134 ~516 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~134 ~540 minecraft:redstone_wire replace
setblock ~109 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~134 ~540 minecraft:redstone_wire replace
setblock ~118 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~134 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~134 ~548 minecraft:redstone_wire replace
setblock ~133 ~134 ~548 minecraft:redstone_wire replace
setblock ~136 ~134 ~548 minecraft:redstone_wire replace
setblock ~139 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~134 ~548 minecraft:redstone_wire replace
setblock ~145 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~134 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~134 ~568 minecraft:redstone_wire replace
setblock ~142 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~134 ~568 minecraft:redstone_wire replace
setblock ~154 ~134 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~134 ~580 minecraft:redstone_wire replace
setblock ~130 ~134 ~580 minecraft:redstone_wire replace
setblock ~133 ~134 ~580 minecraft:redstone_wire replace
setblock ~136 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~134 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~130 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~134 ~608 minecraft:redstone_wire replace
setblock ~145 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~134 ~608 minecraft:redstone_wire replace
setblock ~151 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~134 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~134 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~134 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~172 ~134 ~648 minecraft:redstone_wire replace
setblock ~85 ~134 ~652 minecraft:redstone_wire replace
setblock ~166 ~134 ~656 minecraft:redstone_wire replace
setblock ~169 ~134 ~664 minecraft:redstone_wire replace
fill ~114 ~135 ~384 ~114 ~135 ~388 minecraft:redstone_wire replace
fill ~81 ~135 ~396 ~81 ~135 ~400 minecraft:redstone_wire replace
setblock ~87 ~135 ~444 minecraft:redstone_wire replace
setblock ~87 ~135 ~446 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~135 ~448 minecraft:redstone_wire replace
fill ~87 ~135 ~448 ~87 ~135 ~460 minecraft:redstone_wire replace
setblock ~78 ~135 ~450 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~135 ~452 ~78 ~135 ~464 minecraft:redstone_wire replace
setblock ~117 ~135 ~452 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~135 ~454 ~117 ~135 ~460 minecraft:redstone_wire replace
fill ~108 ~135 ~456 ~108 ~135 ~460 minecraft:redstone_wire replace
setblock ~105 ~135 ~460 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~135 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~135 ~462 ~105 ~135 ~472 minecraft:redstone_wire replace
setblock ~108 ~135 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~462 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~135 ~464 ~87 ~135 ~476 minecraft:redstone_wire replace
setblock ~102 ~135 ~464 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~135 ~464 ~108 ~135 ~476 minecraft:redstone_wire replace
fill ~117 ~135 ~464 ~117 ~135 ~476 minecraft:redstone_wire replace
setblock ~78 ~135 ~466 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~135 ~466 ~102 ~135 ~476 minecraft:redstone_wire replace
fill ~78 ~135 ~468 ~78 ~135 ~480 minecraft:redstone_wire replace
setblock ~99 ~135 ~468 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~135 ~470 ~99 ~135 ~476 minecraft:redstone_wire replace
setblock ~96 ~135 ~472 minecraft:redstone_wire replace
setblock ~96 ~135 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~135 ~474 ~96 ~135 ~486 minecraft:redstone_wire replace
setblock ~105 ~135 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~135 ~476 minecraft:redstone_wire replace
fill ~105 ~135 ~476 ~105 ~135 ~488 minecraft:redstone_wire replace
setblock ~93 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~478 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~135 ~480 ~90 ~135 ~486 minecraft:redstone_wire replace
fill ~93 ~135 ~480 ~93 ~135 ~492 minecraft:redstone_wire replace
fill ~99 ~135 ~480 ~99 ~135 ~492 minecraft:redstone_wire replace
fill ~102 ~135 ~480 ~102 ~135 ~492 minecraft:redstone_wire replace
fill ~108 ~135 ~480 ~108 ~135 ~492 minecraft:redstone_wire replace
fill ~117 ~135 ~480 ~117 ~135 ~492 minecraft:redstone_wire replace
setblock ~90 ~135 ~488 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~135 ~488 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~135 ~490 ~90 ~135 ~502 minecraft:redstone_wire replace
fill ~96 ~135 ~490 ~96 ~135 ~502 minecraft:redstone_wire replace
setblock ~105 ~135 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~135 ~492 ~105 ~135 ~504 minecraft:redstone_wire replace
setblock ~93 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~135 ~496 ~93 ~135 ~508 minecraft:redstone_wire replace
fill ~99 ~135 ~496 ~99 ~135 ~508 minecraft:redstone_wire replace
fill ~102 ~135 ~496 ~102 ~135 ~508 minecraft:redstone_wire replace
fill ~108 ~135 ~496 ~108 ~135 ~508 minecraft:redstone_wire replace
fill ~117 ~135 ~496 ~117 ~135 ~508 minecraft:redstone_wire replace
setblock ~123 ~135 ~496 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~135 ~498 ~123 ~135 ~504 minecraft:redstone_wire replace
setblock ~111 ~135 ~500 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~135 ~502 ~111 ~135 ~508 minecraft:redstone_wire replace
setblock ~90 ~135 ~503 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~135 ~503 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~135 ~504 ~90 ~135 ~516 minecraft:redstone_wire replace
fill ~96 ~135 ~504 ~96 ~135 ~516 minecraft:redstone_wire replace
setblock ~93 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~135 ~512 ~93 ~135 ~524 minecraft:redstone_wire replace
fill ~99 ~135 ~512 ~99 ~135 ~524 minecraft:redstone_wire replace
fill ~102 ~135 ~512 ~102 ~135 ~524 minecraft:redstone_wire replace
fill ~108 ~135 ~512 ~108 ~135 ~524 minecraft:redstone_wire replace
fill ~111 ~135 ~512 ~111 ~135 ~524 minecraft:redstone_wire replace
fill ~117 ~135 ~512 ~117 ~135 ~524 minecraft:redstone_wire replace
setblock ~120 ~135 ~512 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~135 ~514 ~120 ~135 ~524 minecraft:redstone_wire replace
setblock ~150 ~135 ~516 minecraft:redstone_wire replace
setblock ~150 ~135 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~135 ~518 ~150 ~135 ~530 minecraft:redstone_wire replace
setblock ~144 ~135 ~520 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~135 ~522 ~144 ~135 ~532 minecraft:redstone_wire replace
setblock ~141 ~135 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~135 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~135 ~526 ~141 ~135 ~536 minecraft:redstone_wire replace
fill ~93 ~135 ~528 ~93 ~135 ~540 minecraft:redstone_wire replace
fill ~99 ~135 ~528 ~99 ~135 ~540 minecraft:redstone_wire replace
fill ~102 ~135 ~528 ~102 ~135 ~540 minecraft:redstone_wire replace
fill ~108 ~135 ~528 ~108 ~135 ~540 minecraft:redstone_wire replace
fill ~111 ~135 ~528 ~111 ~135 ~540 minecraft:redstone_wire replace
fill ~117 ~135 ~528 ~117 ~135 ~540 minecraft:redstone_wire replace
fill ~120 ~135 ~528 ~120 ~135 ~540 minecraft:redstone_wire replace
fill ~138 ~135 ~528 ~138 ~135 ~530 minecraft:redstone_wire replace
setblock ~135 ~135 ~532 minecraft:redstone_wire replace
setblock ~138 ~135 ~532 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~532 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~135 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~135 ~534 ~138 ~135 ~546 minecraft:redstone_wire replace
setblock ~144 ~135 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~135 ~534 ~150 ~135 ~546 minecraft:redstone_wire replace
setblock ~132 ~135 ~536 minecraft:redstone_wire replace
fill ~135 ~135 ~536 ~135 ~135 ~548 minecraft:redstone_wire replace
fill ~144 ~135 ~536 ~144 ~135 ~548 minecraft:redstone_wire replace
setblock ~132 ~135 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~135 ~538 ~132 ~135 ~550 minecraft:redstone_wire replace
setblock ~141 ~135 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~135 ~540 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~135 ~540 ~141 ~135 ~552 minecraft:redstone_wire replace
fill ~129 ~135 ~542 ~129 ~135 ~548 minecraft:redstone_wire replace
fill ~126 ~135 ~544 ~126 ~135 ~550 minecraft:redstone_wire replace
setblock ~138 ~135 ~547 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~135 ~547 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~135 ~548 ~138 ~135 ~560 minecraft:redstone_wire replace
