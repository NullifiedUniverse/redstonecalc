setblock ~121 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~110 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~110 ~612 minecraft:redstone_wire replace
setblock ~109 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~110 ~612 minecraft:redstone_wire replace
setblock ~130 ~110 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~110 ~624 minecraft:redstone_wire replace
setblock ~106 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~110 ~624 minecraft:redstone_wire replace
setblock ~127 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~110 ~624 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~110 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~110 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~110 ~648 minecraft:redstone_wire replace
setblock ~85 ~110 ~652 minecraft:redstone_wire replace
setblock ~142 ~110 ~656 minecraft:redstone_wire replace
setblock ~145 ~110 ~664 minecraft:redstone_wire replace
fill ~123 ~111 ~384 ~123 ~111 ~388 minecraft:redstone_wire replace
fill ~81 ~111 ~396 ~81 ~111 ~400 minecraft:redstone_wire replace
setblock ~87 ~111 ~528 minecraft:redstone_wire replace
setblock ~87 ~111 ~530 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~111 ~532 minecraft:redstone_wire replace
fill ~87 ~111 ~532 ~87 ~111 ~544 minecraft:redstone_wire replace
setblock ~78 ~111 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~111 ~536 ~78 ~111 ~548 minecraft:redstone_wire replace
setblock ~90 ~111 ~536 minecraft:redstone_wire replace
setblock ~90 ~111 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~111 ~540 ~90 ~111 ~552 minecraft:redstone_wire replace
setblock ~93 ~111 ~540 minecraft:redstone_wire replace
setblock ~93 ~111 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~111 ~544 ~93 ~111 ~556 minecraft:redstone_wire replace
setblock ~96 ~111 ~544 minecraft:redstone_wire replace
setblock ~87 ~111 ~546 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~111 ~546 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~111 ~548 ~87 ~111 ~560 minecraft:redstone_wire replace
fill ~96 ~111 ~548 ~96 ~111 ~560 minecraft:redstone_wire replace
setblock ~126 ~111 ~548 minecraft:redstone_wire replace
setblock ~126 ~111 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~111 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~111 ~550 ~126 ~111 ~562 minecraft:redstone_wire replace
fill ~78 ~111 ~552 ~78 ~111 ~564 minecraft:redstone_wire replace
setblock ~117 ~111 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~111 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~111 ~554 ~117 ~111 ~562 minecraft:redstone_wire replace
fill ~90 ~111 ~556 ~90 ~111 ~568 minecraft:redstone_wire replace
setblock ~114 ~111 ~556 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~111 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~111 ~558 ~114 ~111 ~564 minecraft:redstone_wire replace
fill ~93 ~111 ~560 ~93 ~111 ~572 minecraft:redstone_wire replace
fill ~111 ~111 ~560 ~111 ~111 ~562 minecraft:redstone_wire replace
setblock ~96 ~111 ~562 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~111 ~564 ~96 ~111 ~576 minecraft:redstone_wire replace
setblock ~108 ~111 ~564 minecraft:redstone_wire replace
setblock ~111 ~111 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~111 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~111 ~566 ~111 ~111 ~578 minecraft:redstone_wire replace
setblock ~114 ~111 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~111 ~566 ~117 ~111 ~578 minecraft:redstone_wire replace
fill ~126 ~111 ~566 ~126 ~111 ~578 minecraft:redstone_wire replace
setblock ~105 ~111 ~568 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~111 ~568 ~108 ~111 ~580 minecraft:redstone_wire replace
fill ~114 ~111 ~568 ~114 ~111 ~580 minecraft:redstone_wire replace
fill ~105 ~111 ~570 ~105 ~111 ~578 minecraft:redstone_wire replace
setblock ~102 ~111 ~572 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~574 ~102 ~111 ~580 minecraft:redstone_wire replace
fill ~99 ~111 ~576 ~99 ~111 ~580 minecraft:redstone_wire replace
setblock ~105 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~579 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~111 ~580 ~105 ~111 ~592 minecraft:redstone_wire replace
fill ~111 ~111 ~580 ~111 ~111 ~592 minecraft:redstone_wire replace
fill ~117 ~111 ~580 ~117 ~111 ~592 minecraft:redstone_wire replace
fill ~126 ~111 ~580 ~126 ~111 ~592 minecraft:redstone_wire replace
setblock ~102 ~111 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~111 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~582 ~102 ~111 ~594 minecraft:redstone_wire replace
setblock ~108 ~111 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~111 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~111 ~584 ~99 ~111 ~596 minecraft:redstone_wire replace
fill ~108 ~111 ~584 ~108 ~111 ~596 minecraft:redstone_wire replace
fill ~114 ~111 ~584 ~114 ~111 ~596 minecraft:redstone_wire replace
setblock ~105 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~594 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~111 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~111 ~596 ~105 ~111 ~608 minecraft:redstone_wire replace
fill ~111 ~111 ~596 ~111 ~111 ~608 minecraft:redstone_wire replace
fill ~117 ~111 ~596 ~117 ~111 ~608 minecraft:redstone_wire replace
fill ~126 ~111 ~596 ~126 ~111 ~608 minecraft:redstone_wire replace
setblock ~132 ~111 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~111 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~598 ~102 ~111 ~610 minecraft:redstone_wire replace
setblock ~108 ~111 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~111 ~598 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~111 ~598 ~132 ~111 ~608 minecraft:redstone_wire replace
fill ~99 ~111 ~600 ~99 ~111 ~612 minecraft:redstone_wire replace
fill ~108 ~111 ~600 ~108 ~111 ~612 minecraft:redstone_wire replace
fill ~114 ~111 ~600 ~114 ~111 ~612 minecraft:redstone_wire replace
setblock ~120 ~111 ~600 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~111 ~602 ~120 ~111 ~610 minecraft:redstone_wire replace
fill ~129 ~111 ~608 ~129 ~111 ~612 minecraft:redstone_wire replace
setblock ~105 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~111 ~610 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~111 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~111 ~611 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~111 ~612 ~102 ~111 ~624 minecraft:redstone_wire replace
fill ~105 ~111 ~612 ~105 ~111 ~624 minecraft:redstone_wire replace
fill ~111 ~111 ~612 ~111 ~111 ~624 minecraft:redstone_wire replace
fill ~117 ~111 ~612 ~117 ~111 ~624 minecraft:redstone_wire replace
fill ~120 ~111 ~612 ~120 ~111 ~624 minecraft:redstone_wire replace
fill ~126 ~111 ~612 ~126 ~111 ~624 minecraft:redstone_wire replace
fill ~132 ~111 ~612 ~132 ~111 ~624 minecraft:redstone_wire replace
fill ~135 ~111 ~624 ~135 ~111 ~628 minecraft:redstone_wire replace
fill ~138 ~111 ~632 ~138 ~111 ~636 minecraft:redstone_wire replace
fill ~147 ~111 ~644 ~147 ~111 ~648 minecraft:redstone_wire replace
fill ~84 ~111 ~648 ~84 ~111 ~652 minecraft:redstone_wire replace
fill ~141 ~111 ~652 ~141 ~111 ~656 minecraft:redstone_wire replace
fill ~144 ~111 ~660 ~144 ~111 ~664 minecraft:redstone_wire replace
setblock ~123 ~112 ~383 minecraft:redstone_wire replace
setblock ~81 ~112 ~395 minecraft:redstone_wire replace
setblock ~87 ~112 ~527 minecraft:redstone_wire replace
setblock ~78 ~112 ~531 minecraft:redstone_wire replace
setblock ~90 ~112 ~535 minecraft:redstone_wire replace
setblock ~93 ~112 ~539 minecraft:redstone_wire replace
setblock ~96 ~112 ~543 minecraft:redstone_wire replace
setblock ~126 ~112 ~547 minecraft:redstone_wire replace
setblock ~117 ~112 ~551 minecraft:redstone_wire replace
setblock ~114 ~112 ~555 minecraft:redstone_wire replace
setblock ~111 ~112 ~559 minecraft:redstone_wire replace
setblock ~108 ~112 ~563 minecraft:redstone_wire replace
setblock ~105 ~112 ~567 minecraft:redstone_wire replace
setblock ~102 ~112 ~571 minecraft:redstone_wire replace
setblock ~99 ~112 ~575 minecraft:redstone_wire replace
setblock ~132 ~112 ~595 minecraft:redstone_wire replace
setblock ~120 ~112 ~599 minecraft:redstone_wire replace
setblock ~129 ~112 ~607 minecraft:redstone_wire replace
setblock ~135 ~112 ~623 minecraft:redstone_wire replace
setblock ~138 ~112 ~631 minecraft:redstone_wire replace
setblock ~147 ~112 ~643 minecraft:redstone_wire replace
setblock ~84 ~112 ~647 minecraft:redstone_wire replace
setblock ~141 ~112 ~651 minecraft:redstone_wire replace
setblock ~144 ~112 ~659 minecraft:redstone_wire replace
setblock ~109 ~113 ~381 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~113 ~382 ~113 ~113 ~382 minecraft:redstone_wire replace
setblock ~115 ~113 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~113 ~382 ~123 ~113 ~382 minecraft:redstone_wire replace
setblock ~82 ~113 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~113 ~394 ~83 ~113 ~394 minecraft:redstone_wire replace
setblock ~88 ~113 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~113 ~526 ~89 ~113 ~526 minecraft:redstone_wire replace
setblock ~79 ~113 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~113 ~530 ~80 ~113 ~530 minecraft:redstone_wire replace
setblock ~91 ~113 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~113 ~534 ~92 ~113 ~534 minecraft:redstone_wire replace
setblock ~94 ~113 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~113 ~538 ~95 ~113 ~538 minecraft:redstone_wire replace
setblock ~97 ~113 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~113 ~542 ~98 ~113 ~542 minecraft:redstone_wire replace
setblock ~112 ~113 ~545 minecraft:redstone_wire replace
fill ~111 ~113 ~546 ~113 ~113 ~546 minecraft:redstone_wire replace
setblock ~114 ~113 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~113 ~546 ~126 ~113 ~546 minecraft:redstone_wire replace
setblock ~106 ~113 ~549 minecraft:redstone_wire replace
fill ~105 ~113 ~550 ~117 ~113 ~550 minecraft:redstone_wire replace
setblock ~106 ~113 ~553 minecraft:redstone_wire replace
fill ~105 ~113 ~554 ~114 ~113 ~554 minecraft:redstone_wire replace
setblock ~103 ~113 ~557 minecraft:redstone_wire replace
fill ~102 ~113 ~558 ~111 ~113 ~558 minecraft:redstone_wire replace
setblock ~103 ~113 ~561 minecraft:redstone_wire replace
fill ~102 ~113 ~562 ~108 ~113 ~562 minecraft:redstone_wire replace
setblock ~100 ~113 ~565 minecraft:redstone_wire replace
fill ~99 ~113 ~566 ~105 ~113 ~566 minecraft:redstone_wire replace
setblock ~100 ~113 ~569 minecraft:redstone_wire replace
fill ~99 ~113 ~570 ~102 ~113 ~570 minecraft:redstone_wire replace
setblock ~100 ~113 ~573 minecraft:redstone_wire replace
fill ~99 ~113 ~574 ~101 ~113 ~574 minecraft:redstone_wire replace
setblock ~112 ~113 ~593 minecraft:redstone_wire replace
fill ~111 ~113 ~594 ~116 ~113 ~594 minecraft:redstone_wire replace
setblock ~118 ~113 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~113 ~594 ~132 ~113 ~594 minecraft:redstone_wire replace
setblock ~106 ~113 ~597 minecraft:redstone_wire replace
fill ~105 ~113 ~598 ~106 ~113 ~598 minecraft:redstone_wire replace
setblock ~107 ~113 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~113 ~598 ~120 ~113 ~598 minecraft:redstone_wire replace
setblock ~112 ~113 ~605 minecraft:redstone_wire replace
fill ~111 ~113 ~606 ~119 ~113 ~606 minecraft:redstone_wire replace
setblock ~121 ~113 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~113 ~606 ~129 ~113 ~606 minecraft:redstone_wire replace
setblock ~115 ~113 ~621 minecraft:redstone_wire replace
fill ~114 ~113 ~622 ~125 ~113 ~622 minecraft:redstone_wire replace
setblock ~127 ~113 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~113 ~622 ~135 ~113 ~622 minecraft:redstone_wire replace
setblock ~118 ~113 ~629 minecraft:redstone_wire replace
fill ~117 ~113 ~630 ~128 ~113 ~630 minecraft:redstone_wire replace
setblock ~130 ~113 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~113 ~630 ~138 ~113 ~630 minecraft:redstone_wire replace
setblock ~127 ~113 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~113 ~642 ~137 ~113 ~642 minecraft:redstone_wire replace
setblock ~139 ~113 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~113 ~642 ~147 ~113 ~642 minecraft:redstone_wire replace
setblock ~85 ~113 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~113 ~646 ~86 ~113 ~646 minecraft:redstone_wire replace
setblock ~121 ~113 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~113 ~650 ~131 ~113 ~650 minecraft:redstone_wire replace
setblock ~133 ~113 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~113 ~650 ~141 ~113 ~650 minecraft:redstone_wire replace
setblock ~124 ~113 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~113 ~658 ~134 ~113 ~658 minecraft:redstone_wire replace
setblock ~136 ~113 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~113 ~658 ~144 ~113 ~658 minecraft:redstone_wire replace
setblock ~109 ~114 ~380 minecraft:redstone_wire replace
setblock ~82 ~114 ~392 minecraft:redstone_wire replace
setblock ~88 ~114 ~524 minecraft:redstone_wire replace
setblock ~79 ~114 ~528 minecraft:redstone_wire replace
setblock ~91 ~114 ~532 minecraft:redstone_wire replace
setblock ~94 ~114 ~536 minecraft:redstone_wire replace
setblock ~97 ~114 ~540 minecraft:redstone_wire replace
setblock ~112 ~114 ~544 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~114 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~114 ~552 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~114 ~556 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~114 ~560 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~114 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~114 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~114 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~114 ~592 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~114 ~596 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~114 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~114 ~620 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~114 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~114 ~640 minecraft:redstone_wire replace
setblock ~85 ~114 ~644 minecraft:redstone_wire replace
setblock ~121 ~114 ~648 minecraft:redstone_wire replace
setblock ~124 ~114 ~656 minecraft:redstone_wire replace
fill ~108 ~115 ~380 ~108 ~115 ~384 minecraft:redstone_wire replace
fill ~81 ~115 ~392 ~81 ~115 ~396 minecraft:redstone_wire replace
fill ~87 ~115 ~524 ~87 ~115 ~528 minecraft:redstone_wire replace
fill ~78 ~115 ~528 ~78 ~115 ~532 minecraft:redstone_wire replace
fill ~90 ~115 ~532 ~90 ~115 ~536 minecraft:redstone_wire replace
fill ~93 ~115 ~536 ~93 ~115 ~540 minecraft:redstone_wire replace
fill ~96 ~115 ~540 ~96 ~115 ~544 minecraft:redstone_wire replace
fill ~111 ~115 ~544 ~111 ~115 ~556 minecraft:redstone_wire replace
fill ~105 ~115 ~548 ~105 ~115 ~560 minecraft:redstone_wire replace
fill ~102 ~115 ~556 ~102 ~115 ~562 minecraft:redstone_wire replace
setblock ~111 ~115 ~558 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~560 ~111 ~115 ~572 minecraft:redstone_wire replace
setblock ~105 ~115 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~115 ~564 ~99 ~115 ~574 minecraft:redstone_wire replace
setblock ~102 ~115 ~564 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~115 ~564 ~105 ~115 ~576 minecraft:redstone_wire replace
setblock ~111 ~115 ~574 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~99 ~115 ~576 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~576 ~111 ~115 ~588 minecraft:redstone_wire replace
setblock ~105 ~115 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~115 ~580 ~105 ~115 ~592 minecraft:redstone_wire replace
setblock ~111 ~115 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~592 ~111 ~115 ~604 minecraft:redstone_wire replace
setblock ~105 ~115 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~115 ~596 ~105 ~115 ~600 minecraft:redstone_wire replace
setblock ~111 ~115 ~605 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~115 ~606 ~111 ~115 ~608 minecraft:redstone_wire replace
fill ~114 ~115 ~620 ~114 ~115 ~624 minecraft:redstone_wire replace
fill ~117 ~115 ~628 ~117 ~115 ~632 minecraft:redstone_wire replace
fill ~126 ~115 ~640 ~126 ~115 ~644 minecraft:redstone_wire replace
fill ~84 ~115 ~644 ~84 ~115 ~648 minecraft:redstone_wire replace
fill ~120 ~115 ~648 ~120 ~115 ~652 minecraft:redstone_wire replace
fill ~123 ~115 ~656 ~123 ~115 ~660 minecraft:redstone_wire replace
setblock ~108 ~116 ~385 minecraft:redstone_wire replace
setblock ~81 ~116 ~397 minecraft:redstone_wire replace
setblock ~87 ~116 ~529 minecraft:redstone_wire replace
setblock ~78 ~116 ~533 minecraft:redstone_wire replace
setblock ~90 ~116 ~537 minecraft:redstone_wire replace
setblock ~93 ~116 ~541 minecraft:redstone_wire replace
setblock ~96 ~116 ~545 minecraft:redstone_wire replace
setblock ~102 ~116 ~565 minecraft:redstone_wire replace
setblock ~99 ~116 ~577 minecraft:redstone_wire replace
setblock ~105 ~116 ~601 minecraft:redstone_wire replace
setblock ~111 ~116 ~609 minecraft:redstone_wire replace
setblock ~114 ~116 ~625 minecraft:redstone_wire replace
setblock ~117 ~116 ~633 minecraft:redstone_wire replace
setblock ~126 ~116 ~645 minecraft:redstone_wire replace
setblock ~84 ~116 ~649 minecraft:redstone_wire replace
setblock ~120 ~116 ~653 minecraft:redstone_wire replace
setblock ~123 ~116 ~661 minecraft:redstone_wire replace
fill ~108 ~117 ~386 ~114 ~117 ~386 minecraft:redstone_wire replace
setblock ~116 ~117 ~386 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~117 ~386 ~122 ~117 ~386 minecraft:redstone_wire replace
setblock ~121 ~117 ~387 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~117 ~398 ~83 ~117 ~398 minecraft:redstone_wire replace
setblock ~82 ~117 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~117 ~530 ~89 ~117 ~530 minecraft:redstone_wire replace
setblock ~88 ~117 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~117 ~534 ~80 ~117 ~534 minecraft:redstone_wire replace
setblock ~79 ~117 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~117 ~538 ~92 ~117 ~538 minecraft:redstone_wire replace
setblock ~91 ~117 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~117 ~542 ~95 ~117 ~542 minecraft:redstone_wire replace
setblock ~94 ~117 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~117 ~546 ~101 ~117 ~546 minecraft:redstone_wire replace
setblock ~102 ~117 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~103 ~117 ~546 ~115 ~117 ~546 minecraft:redstone_wire replace
setblock ~116 ~117 ~546 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~117 ~117 ~546 ~125 ~117 ~546 minecraft:redstone_wire replace
setblock ~97 ~117 ~547 minecraft:redstone_wire replace
setblock ~100 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~109 ~117 ~547 minecraft:redstone_wire replace
setblock ~112 ~117 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~117 ~547 minecraft:redstone_wire replace
setblock ~124 ~117 ~547 minecraft:redstone_wire replace
fill ~96 ~117 ~566 ~114 ~117 ~566 minecraft:redstone_wire replace
setblock ~116 ~117 ~566 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~118 ~117 ~566 ~131 ~117 ~566 minecraft:redstone_wire replace
setblock ~97 ~117 ~567 minecraft:redstone_wire replace
setblock ~103 ~117 ~567 minecraft:redstone_wire replace
setblock ~109 ~117 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~112 ~117 ~567 minecraft:redstone_wire replace
setblock ~118 ~117 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~130 ~117 ~567 minecraft:redstone_wire replace
fill ~96 ~117 ~578 ~111 ~117 ~578 minecraft:redstone_wire replace
setblock ~113 ~117 ~578 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~117 ~578 ~128 ~117 ~578 minecraft:redstone_wire replace
setblock ~97 ~117 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~100 ~117 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~117 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~106 ~117 ~579 minecraft:redstone_wire replace
setblock ~115 ~117 ~579 minecraft:redstone_wire replace
setblock ~118 ~117 ~579 minecraft:redstone_wire replace
setblock ~127 ~117 ~579 minecraft:redstone_wire replace
fill ~99 ~117 ~602 ~111 ~117 ~602 minecraft:redstone_wire replace
setblock ~113 ~117 ~602 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~115 ~117 ~602 ~128 ~117 ~602 minecraft:redstone_wire replace
setblock ~100 ~117 ~603 minecraft:redstone_wire replace
setblock ~106 ~117 ~603 minecraft:redstone_wire replace
setblock ~109 ~117 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~115 ~117 ~603 minecraft:redstone_wire replace
setblock ~118 ~117 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~124 ~117 ~603 minecraft:redstone_wire replace
setblock ~127 ~117 ~603 minecraft:redstone_wire replace
fill ~111 ~117 ~610 ~120 ~117 ~610 minecraft:redstone_wire replace
setblock ~122 ~117 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~117 ~610 ~137 ~117 ~610 minecraft:redstone_wire replace
setblock ~138 ~117 ~610 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~117 ~610 ~149 ~117 ~610 minecraft:redstone_wire replace
setblock ~133 ~117 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~136 ~117 ~611 minecraft:redstone_wire replace
setblock ~139 ~117 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~142 ~117 ~611 minecraft:redstone_wire replace
setblock ~148 ~117 ~611 minecraft:redstone_wire replace
fill ~114 ~117 ~626 ~120 ~117 ~626 minecraft:redstone_wire replace
setblock ~122 ~117 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~124 ~117 ~626 ~137 ~117 ~626 minecraft:redstone_wire replace
setblock ~138 ~117 ~626 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~117 ~626 ~152 ~117 ~626 minecraft:redstone_wire replace
setblock ~133 ~117 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~117 ~627 minecraft:redstone_wire replace
setblock ~142 ~117 ~627 minecraft:redstone_wire replace
setblock ~145 ~117 ~627 minecraft:redstone_wire replace
setblock ~151 ~117 ~627 minecraft:redstone_wire replace
fill ~117 ~117 ~634 ~123 ~117 ~634 minecraft:redstone_wire replace
setblock ~125 ~117 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~127 ~117 ~634 ~140 ~117 ~634 minecraft:redstone_wire replace
setblock ~141 ~117 ~634 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~142 ~117 ~634 ~152 ~117 ~634 minecraft:redstone_wire replace
setblock ~133 ~117 ~635 minecraft:redstone_wire replace
setblock ~136 ~117 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~117 ~635 minecraft:redstone_wire replace
setblock ~142 ~117 ~635 minecraft:redstone_wire replace
setblock ~145 ~117 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~117 ~635 minecraft:redstone_wire replace
setblock ~151 ~117 ~635 minecraft:redstone_wire replace
fill ~126 ~117 ~646 ~132 ~117 ~646 minecraft:redstone_wire replace
setblock ~134 ~117 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~136 ~117 ~646 ~149 ~117 ~646 minecraft:redstone_wire replace
setblock ~151 ~117 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~153 ~117 ~646 ~161 ~117 ~646 minecraft:redstone_wire replace
setblock ~160 ~117 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~117 ~650 ~86 ~117 ~650 minecraft:redstone_wire replace
setblock ~85 ~117 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~117 ~654 ~126 ~117 ~654 minecraft:redstone_wire replace
setblock ~128 ~117 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~130 ~117 ~654 ~143 ~117 ~654 minecraft:redstone_wire replace
setblock ~145 ~117 ~654 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~147 ~117 ~654 ~155 ~117 ~654 minecraft:redstone_wire replace
setblock ~154 ~117 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~117 ~662 ~129 ~117 ~662 minecraft:redstone_wire replace
setblock ~131 ~117 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~133 ~117 ~662 ~146 ~117 ~662 minecraft:redstone_wire replace
setblock ~148 ~117 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~150 ~117 ~662 ~158 ~117 ~662 minecraft:redstone_wire replace
setblock ~157 ~117 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~118 ~388 minecraft:redstone_wire replace
setblock ~82 ~118 ~400 minecraft:redstone_wire replace
setblock ~88 ~118 ~532 minecraft:redstone_wire replace
setblock ~79 ~118 ~536 minecraft:redstone_wire replace
setblock ~91 ~118 ~540 minecraft:redstone_wire replace
setblock ~94 ~118 ~544 minecraft:redstone_wire replace
setblock ~97 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~118 ~548 minecraft:redstone_wire replace
setblock ~103 ~118 ~548 minecraft:redstone_wire replace
setblock ~106 ~118 ~548 minecraft:redstone_wire replace
setblock ~109 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~118 ~548 minecraft:redstone_wire replace
setblock ~115 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~118 ~548 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~118 ~568 minecraft:redstone_wire replace
setblock ~112 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~118 ~568 minecraft:redstone_wire replace
setblock ~130 ~118 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~118 ~580 minecraft:redstone_wire replace
setblock ~100 ~118 ~580 minecraft:redstone_wire replace
setblock ~103 ~118 ~580 minecraft:redstone_wire replace
setblock ~106 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~115 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~118 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~118 ~604 minecraft:redstone_wire replace
setblock ~115 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~118 ~604 minecraft:redstone_wire replace
setblock ~124 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~118 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~118 ~612 minecraft:redstone_wire replace
setblock ~136 ~118 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~118 ~612 minecraft:redstone_wire replace
setblock ~142 ~118 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~118 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~118 ~628 minecraft:redstone_wire replace
setblock ~139 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~118 ~628 minecraft:redstone_torch[lit=true] replace
setblock ~133 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~136 ~118 ~636 minecraft:redstone_wire replace
setblock ~139 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~142 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~118 ~636 minecraft:redstone_wire replace
setblock ~148 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~118 ~636 minecraft:redstone_torch[lit=true] replace
setblock ~160 ~118 ~648 minecraft:redstone_wire replace
setblock ~85 ~118 ~652 minecraft:redstone_wire replace
setblock ~154 ~118 ~656 minecraft:redstone_wire replace
setblock ~157 ~118 ~664 minecraft:redstone_wire replace
fill ~120 ~119 ~384 ~120 ~119 ~388 minecraft:redstone_wire replace
fill ~81 ~119 ~396 ~81 ~119 ~400 minecraft:redstone_wire replace
setblock ~87 ~119 ~500 minecraft:redstone_wire replace
setblock ~87 ~119 ~502 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~78 ~119 ~504 minecraft:redstone_wire replace
fill ~87 ~119 ~504 ~87 ~119 ~516 minecraft:redstone_wire replace
setblock ~78 ~119 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~119 ~508 ~78 ~119 ~520 minecraft:redstone_wire replace
setblock ~90 ~119 ~508 minecraft:redstone_wire replace
setblock ~90 ~119 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~119 ~512 ~90 ~119 ~524 minecraft:redstone_wire replace
setblock ~93 ~119 ~512 minecraft:redstone_wire replace
setblock ~93 ~119 ~514 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~119 ~516 ~93 ~119 ~528 minecraft:redstone_wire replace
setblock ~123 ~119 ~516 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~119 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~119 ~518 ~123 ~119 ~524 minecraft:redstone_wire replace
fill ~87 ~119 ~520 ~87 ~119 ~532 minecraft:redstone_wire replace
fill ~114 ~119 ~520 ~114 ~119 ~524 minecraft:redstone_wire replace
setblock ~78 ~119 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~119 ~524 ~78 ~119 ~536 minecraft:redstone_wire replace
setblock ~111 ~119 ~524 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~119 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~119 ~526 ~111 ~119 ~536 minecraft:redstone_wire replace
setblock ~114 ~119 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~119 ~528 ~90 ~119 ~540 minecraft:redstone_wire replace
setblock ~108 ~119 ~528 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~119 ~528 ~114 ~119 ~540 minecraft:redstone_wire replace
fill ~123 ~119 ~528 ~123 ~119 ~540 minecraft:redstone_wire replace
setblock ~93 ~119 ~530 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~119 ~530 ~108 ~119 ~540 minecraft:redstone_wire replace
fill ~93 ~119 ~532 ~93 ~119 ~544 minecraft:redstone_wire replace
setblock ~105 ~119 ~532 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~119 ~534 ~105 ~119 ~540 minecraft:redstone_wire replace
setblock ~102 ~119 ~536 minecraft:redstone_wire replace
setblock ~102 ~119 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~119 ~538 ~102 ~119 ~550 minecraft:redstone_wire replace
setblock ~111 ~119 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~119 ~540 minecraft:redstone_wire replace
fill ~111 ~119 ~540 ~111 ~119 ~552 minecraft:redstone_wire replace
setblock ~99 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~119 ~544 ~96 ~119 ~550 minecraft:redstone_wire replace
fill ~99 ~119 ~544 ~99 ~119 ~556 minecraft:redstone_wire replace
fill ~105 ~119 ~544 ~105 ~119 ~556 minecraft:redstone_wire replace
fill ~108 ~119 ~544 ~108 ~119 ~556 minecraft:redstone_wire replace
fill ~114 ~119 ~544 ~114 ~119 ~556 minecraft:redstone_wire replace
fill ~123 ~119 ~544 ~123 ~119 ~556 minecraft:redstone_wire replace
setblock ~96 ~119 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~119 ~552 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~119 ~554 ~96 ~119 ~566 minecraft:redstone_wire replace
fill ~102 ~119 ~554 ~102 ~119 ~566 minecraft:redstone_wire replace
setblock ~111 ~119 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~119 ~556 ~111 ~119 ~568 minecraft:redstone_wire replace
setblock ~99 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~119 ~560 ~99 ~119 ~572 minecraft:redstone_wire replace
fill ~105 ~119 ~560 ~105 ~119 ~572 minecraft:redstone_wire replace
fill ~108 ~119 ~560 ~108 ~119 ~572 minecraft:redstone_wire replace
fill ~114 ~119 ~560 ~114 ~119 ~572 minecraft:redstone_wire replace
fill ~123 ~119 ~560 ~123 ~119 ~572 minecraft:redstone_wire replace
setblock ~129 ~119 ~560 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~119 ~562 ~129 ~119 ~568 minecraft:redstone_wire replace
setblock ~117 ~119 ~564 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~119 ~566 ~117 ~119 ~572 minecraft:redstone_wire replace
setblock ~96 ~119 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~119 ~567 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~119 ~568 ~96 ~119 ~580 minecraft:redstone_wire replace
fill ~102 ~119 ~568 ~102 ~119 ~580 minecraft:redstone_wire replace
setblock ~99 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~119 ~576 ~99 ~119 ~588 minecraft:redstone_wire replace
fill ~105 ~119 ~576 ~105 ~119 ~588 minecraft:redstone_wire replace
fill ~108 ~119 ~576 ~108 ~119 ~588 minecraft:redstone_wire replace
fill ~114 ~119 ~576 ~114 ~119 ~588 minecraft:redstone_wire replace
fill ~117 ~119 ~576 ~117 ~119 ~588 minecraft:redstone_wire replace
fill ~123 ~119 ~576 ~123 ~119 ~588 minecraft:redstone_wire replace
setblock ~126 ~119 ~576 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~119 ~578 ~126 ~119 ~588 minecraft:redstone_wire replace
setblock ~99 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~119 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~119 ~592 ~99 ~119 ~604 minecraft:redstone_wire replace
fill ~105 ~119 ~592 ~105 ~119 ~604 minecraft:redstone_wire replace
fill ~108 ~119 ~592 ~108 ~119 ~604 minecraft:redstone_wire replace
fill ~114 ~119 ~592 ~114 ~119 ~604 minecraft:redstone_wire replace
fill ~117 ~119 ~592 ~117 ~119 ~604 minecraft:redstone_wire replace
fill ~123 ~119 ~592 ~123 ~119 ~604 minecraft:redstone_wire replace
fill ~126 ~119 ~592 ~126 ~119 ~604 minecraft:redstone_wire replace
setblock ~147 ~119 ~592 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~119 ~594 ~147 ~119 ~604 minecraft:redstone_wire replace
setblock ~141 ~119 ~596 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~119 ~598 ~141 ~119 ~604 minecraft:redstone_wire replace
fill ~138 ~119 ~600 ~138 ~119 ~604 minecraft:redstone_wire replace
setblock ~135 ~119 ~604 minecraft:redstone_wire replace
setblock ~135 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~119 ~606 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~119 ~608 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~119 ~608 ~135 ~119 ~620 minecraft:redstone_wire replace
fill ~138 ~119 ~608 ~138 ~119 ~620 minecraft:redstone_wire replace
fill ~141 ~119 ~608 ~141 ~119 ~620 minecraft:redstone_wire replace
fill ~147 ~119 ~608 ~147 ~119 ~620 minecraft:redstone_wire replace
fill ~132 ~119 ~610 ~132 ~119 ~620 minecraft:redstone_wire replace
setblock ~150 ~119 ~620 minecraft:redstone_wire replace
setblock ~132 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~119 ~622 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~119 ~624 ~132 ~119 ~636 minecraft:redstone_wire replace
fill ~135 ~119 ~624 ~135 ~119 ~636 minecraft:redstone_wire replace
fill ~138 ~119 ~624 ~138 ~119 ~636 minecraft:redstone_wire replace
fill ~141 ~119 ~624 ~141 ~119 ~636 minecraft:redstone_wire replace
setblock ~144 ~119 ~624 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~119 ~624 ~147 ~119 ~636 minecraft:redstone_wire replace
fill ~150 ~119 ~624 ~150 ~119 ~636 minecraft:redstone_wire replace
fill ~144 ~119 ~626 ~144 ~119 ~636 minecraft:redstone_wire replace
fill ~159 ~119 ~644 ~159 ~119 ~648 minecraft:redstone_wire replace
fill ~84 ~119 ~648 ~84 ~119 ~652 minecraft:redstone_wire replace
fill ~153 ~119 ~652 ~153 ~119 ~656 minecraft:redstone_wire replace
fill ~156 ~119 ~660 ~156 ~119 ~664 minecraft:redstone_wire replace
setblock ~120 ~120 ~383 minecraft:redstone_wire replace
setblock ~81 ~120 ~395 minecraft:redstone_wire replace
setblock ~87 ~120 ~499 minecraft:redstone_wire replace
