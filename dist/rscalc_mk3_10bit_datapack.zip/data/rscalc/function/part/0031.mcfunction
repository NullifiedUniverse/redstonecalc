setblock ~333 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~692 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~692 ~402 ~155 ~704 minecraft:redstone_wire replace
fill ~405 ~155 ~692 ~405 ~155 ~704 minecraft:redstone_wire replace
fill ~408 ~155 ~692 ~408 ~155 ~704 minecraft:redstone_wire replace
fill ~411 ~155 ~692 ~411 ~155 ~704 minecraft:redstone_wire replace
fill ~414 ~155 ~692 ~414 ~155 ~704 minecraft:redstone_wire replace
fill ~417 ~155 ~692 ~417 ~155 ~704 minecraft:redstone_wire replace
fill ~420 ~155 ~692 ~420 ~155 ~704 minecraft:redstone_wire replace
fill ~423 ~155 ~692 ~423 ~155 ~704 minecraft:redstone_wire replace
fill ~228 ~155 ~694 ~228 ~155 ~696 minecraft:redstone_wire replace
fill ~231 ~155 ~694 ~231 ~155 ~700 minecraft:redstone_wire replace
fill ~234 ~155 ~694 ~234 ~155 ~702 minecraft:redstone_wire replace
fill ~237 ~155 ~694 ~237 ~155 ~706 minecraft:redstone_wire replace
fill ~240 ~155 ~694 ~240 ~155 ~706 minecraft:redstone_wire replace
fill ~243 ~155 ~694 ~243 ~155 ~706 minecraft:redstone_wire replace
fill ~246 ~155 ~694 ~246 ~155 ~706 minecraft:redstone_wire replace
fill ~249 ~155 ~694 ~249 ~155 ~706 minecraft:redstone_wire replace
fill ~252 ~155 ~694 ~252 ~155 ~706 minecraft:redstone_wire replace
fill ~255 ~155 ~694 ~255 ~155 ~706 minecraft:redstone_wire replace
fill ~258 ~155 ~694 ~258 ~155 ~706 minecraft:redstone_wire replace
fill ~261 ~155 ~694 ~261 ~155 ~706 minecraft:redstone_wire replace
fill ~264 ~155 ~694 ~264 ~155 ~706 minecraft:redstone_wire replace
fill ~267 ~155 ~694 ~267 ~155 ~706 minecraft:redstone_wire replace
fill ~270 ~155 ~694 ~270 ~155 ~706 minecraft:redstone_wire replace
fill ~273 ~155 ~694 ~273 ~155 ~706 minecraft:redstone_wire replace
fill ~276 ~155 ~694 ~276 ~155 ~706 minecraft:redstone_wire replace
fill ~279 ~155 ~694 ~279 ~155 ~706 minecraft:redstone_wire replace
fill ~282 ~155 ~694 ~282 ~155 ~706 minecraft:redstone_wire replace
fill ~285 ~155 ~694 ~285 ~155 ~706 minecraft:redstone_wire replace
fill ~288 ~155 ~694 ~288 ~155 ~706 minecraft:redstone_wire replace
fill ~291 ~155 ~694 ~291 ~155 ~706 minecraft:redstone_wire replace
fill ~294 ~155 ~694 ~294 ~155 ~706 minecraft:redstone_wire replace
fill ~297 ~155 ~694 ~297 ~155 ~706 minecraft:redstone_wire replace
fill ~300 ~155 ~694 ~300 ~155 ~706 minecraft:redstone_wire replace
fill ~303 ~155 ~694 ~303 ~155 ~706 minecraft:redstone_wire replace
fill ~306 ~155 ~694 ~306 ~155 ~706 minecraft:redstone_wire replace
fill ~309 ~155 ~694 ~309 ~155 ~706 minecraft:redstone_wire replace
fill ~312 ~155 ~694 ~312 ~155 ~706 minecraft:redstone_wire replace
fill ~315 ~155 ~694 ~315 ~155 ~706 minecraft:redstone_wire replace
fill ~318 ~155 ~694 ~318 ~155 ~706 minecraft:redstone_wire replace
fill ~321 ~155 ~694 ~321 ~155 ~706 minecraft:redstone_wire replace
fill ~324 ~155 ~694 ~324 ~155 ~706 minecraft:redstone_wire replace
fill ~327 ~155 ~694 ~327 ~155 ~706 minecraft:redstone_wire replace
fill ~330 ~155 ~694 ~330 ~155 ~706 minecraft:redstone_wire replace
fill ~333 ~155 ~694 ~333 ~155 ~706 minecraft:redstone_wire replace
fill ~336 ~155 ~694 ~336 ~155 ~706 minecraft:redstone_wire replace
fill ~339 ~155 ~694 ~339 ~155 ~706 minecraft:redstone_wire replace
fill ~342 ~155 ~694 ~342 ~155 ~706 minecraft:redstone_wire replace
fill ~345 ~155 ~694 ~345 ~155 ~706 minecraft:redstone_wire replace
fill ~348 ~155 ~694 ~348 ~155 ~706 minecraft:redstone_wire replace
fill ~351 ~155 ~694 ~351 ~155 ~706 minecraft:redstone_wire replace
fill ~354 ~155 ~694 ~354 ~155 ~706 minecraft:redstone_wire replace
fill ~357 ~155 ~694 ~357 ~155 ~706 minecraft:redstone_wire replace
fill ~360 ~155 ~694 ~360 ~155 ~706 minecraft:redstone_wire replace
fill ~363 ~155 ~694 ~363 ~155 ~706 minecraft:redstone_wire replace
fill ~366 ~155 ~694 ~366 ~155 ~706 minecraft:redstone_wire replace
fill ~369 ~155 ~694 ~369 ~155 ~706 minecraft:redstone_wire replace
fill ~372 ~155 ~694 ~372 ~155 ~706 minecraft:redstone_wire replace
fill ~375 ~155 ~694 ~375 ~155 ~706 minecraft:redstone_wire replace
fill ~378 ~155 ~694 ~378 ~155 ~706 minecraft:redstone_wire replace
fill ~381 ~155 ~694 ~381 ~155 ~706 minecraft:redstone_wire replace
fill ~384 ~155 ~694 ~384 ~155 ~706 minecraft:redstone_wire replace
fill ~387 ~155 ~694 ~387 ~155 ~706 minecraft:redstone_wire replace
fill ~390 ~155 ~694 ~390 ~155 ~706 minecraft:redstone_wire replace
fill ~393 ~155 ~694 ~393 ~155 ~706 minecraft:redstone_wire replace
fill ~396 ~155 ~694 ~396 ~155 ~706 minecraft:redstone_wire replace
fill ~399 ~155 ~694 ~399 ~155 ~706 minecraft:redstone_wire replace
setblock ~426 ~155 ~694 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~696 ~426 ~155 ~708 minecraft:redstone_wire replace
setblock ~429 ~155 ~702 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~702 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~234 ~155 ~704 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~704 ~429 ~155 ~716 minecraft:redstone_wire replace
fill ~432 ~155 ~704 ~432 ~155 ~716 minecraft:redstone_wire replace
setblock ~402 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~706 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~707 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~237 ~155 ~708 minecraft:redstone_wire replace
setblock ~240 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~243 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~252 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~708 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~708 ~402 ~155 ~720 minecraft:redstone_wire replace
fill ~405 ~155 ~708 ~405 ~155 ~720 minecraft:redstone_wire replace
fill ~408 ~155 ~708 ~408 ~155 ~720 minecraft:redstone_wire replace
fill ~411 ~155 ~708 ~411 ~155 ~720 minecraft:redstone_wire replace
fill ~414 ~155 ~708 ~414 ~155 ~720 minecraft:redstone_wire replace
fill ~417 ~155 ~708 ~417 ~155 ~720 minecraft:redstone_wire replace
fill ~420 ~155 ~708 ~420 ~155 ~720 minecraft:redstone_wire replace
fill ~423 ~155 ~708 ~423 ~155 ~720 minecraft:redstone_wire replace
fill ~240 ~155 ~710 ~240 ~155 ~712 minecraft:redstone_wire replace
fill ~243 ~155 ~710 ~243 ~155 ~716 minecraft:redstone_wire replace
fill ~246 ~155 ~710 ~246 ~155 ~718 minecraft:redstone_wire replace
fill ~249 ~155 ~710 ~249 ~155 ~722 minecraft:redstone_wire replace
fill ~252 ~155 ~710 ~252 ~155 ~722 minecraft:redstone_wire replace
fill ~255 ~155 ~710 ~255 ~155 ~722 minecraft:redstone_wire replace
fill ~258 ~155 ~710 ~258 ~155 ~722 minecraft:redstone_wire replace
fill ~261 ~155 ~710 ~261 ~155 ~722 minecraft:redstone_wire replace
fill ~264 ~155 ~710 ~264 ~155 ~722 minecraft:redstone_wire replace
fill ~267 ~155 ~710 ~267 ~155 ~722 minecraft:redstone_wire replace
fill ~270 ~155 ~710 ~270 ~155 ~722 minecraft:redstone_wire replace
fill ~273 ~155 ~710 ~273 ~155 ~722 minecraft:redstone_wire replace
fill ~276 ~155 ~710 ~276 ~155 ~722 minecraft:redstone_wire replace
fill ~279 ~155 ~710 ~279 ~155 ~722 minecraft:redstone_wire replace
fill ~282 ~155 ~710 ~282 ~155 ~722 minecraft:redstone_wire replace
fill ~285 ~155 ~710 ~285 ~155 ~722 minecraft:redstone_wire replace
fill ~288 ~155 ~710 ~288 ~155 ~722 minecraft:redstone_wire replace
fill ~291 ~155 ~710 ~291 ~155 ~722 minecraft:redstone_wire replace
fill ~294 ~155 ~710 ~294 ~155 ~722 minecraft:redstone_wire replace
fill ~297 ~155 ~710 ~297 ~155 ~722 minecraft:redstone_wire replace
fill ~300 ~155 ~710 ~300 ~155 ~722 minecraft:redstone_wire replace
fill ~303 ~155 ~710 ~303 ~155 ~722 minecraft:redstone_wire replace
fill ~306 ~155 ~710 ~306 ~155 ~722 minecraft:redstone_wire replace
fill ~309 ~155 ~710 ~309 ~155 ~722 minecraft:redstone_wire replace
fill ~312 ~155 ~710 ~312 ~155 ~722 minecraft:redstone_wire replace
fill ~315 ~155 ~710 ~315 ~155 ~722 minecraft:redstone_wire replace
fill ~318 ~155 ~710 ~318 ~155 ~722 minecraft:redstone_wire replace
fill ~321 ~155 ~710 ~321 ~155 ~722 minecraft:redstone_wire replace
fill ~324 ~155 ~710 ~324 ~155 ~722 minecraft:redstone_wire replace
fill ~327 ~155 ~710 ~327 ~155 ~722 minecraft:redstone_wire replace
fill ~330 ~155 ~710 ~330 ~155 ~722 minecraft:redstone_wire replace
fill ~333 ~155 ~710 ~333 ~155 ~722 minecraft:redstone_wire replace
fill ~336 ~155 ~710 ~336 ~155 ~722 minecraft:redstone_wire replace
fill ~339 ~155 ~710 ~339 ~155 ~722 minecraft:redstone_wire replace
fill ~342 ~155 ~710 ~342 ~155 ~722 minecraft:redstone_wire replace
fill ~345 ~155 ~710 ~345 ~155 ~722 minecraft:redstone_wire replace
fill ~348 ~155 ~710 ~348 ~155 ~722 minecraft:redstone_wire replace
fill ~351 ~155 ~710 ~351 ~155 ~722 minecraft:redstone_wire replace
fill ~354 ~155 ~710 ~354 ~155 ~722 minecraft:redstone_wire replace
fill ~357 ~155 ~710 ~357 ~155 ~722 minecraft:redstone_wire replace
fill ~360 ~155 ~710 ~360 ~155 ~722 minecraft:redstone_wire replace
fill ~363 ~155 ~710 ~363 ~155 ~722 minecraft:redstone_wire replace
fill ~366 ~155 ~710 ~366 ~155 ~722 minecraft:redstone_wire replace
fill ~369 ~155 ~710 ~369 ~155 ~722 minecraft:redstone_wire replace
fill ~372 ~155 ~710 ~372 ~155 ~722 minecraft:redstone_wire replace
fill ~375 ~155 ~710 ~375 ~155 ~722 minecraft:redstone_wire replace
fill ~378 ~155 ~710 ~378 ~155 ~722 minecraft:redstone_wire replace
fill ~381 ~155 ~710 ~381 ~155 ~722 minecraft:redstone_wire replace
fill ~384 ~155 ~710 ~384 ~155 ~722 minecraft:redstone_wire replace
fill ~387 ~155 ~710 ~387 ~155 ~722 minecraft:redstone_wire replace
fill ~390 ~155 ~710 ~390 ~155 ~722 minecraft:redstone_wire replace
fill ~393 ~155 ~710 ~393 ~155 ~722 minecraft:redstone_wire replace
fill ~396 ~155 ~710 ~396 ~155 ~722 minecraft:redstone_wire replace
fill ~399 ~155 ~710 ~399 ~155 ~722 minecraft:redstone_wire replace
setblock ~426 ~155 ~710 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~712 ~426 ~155 ~724 minecraft:redstone_wire replace
setblock ~429 ~155 ~718 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~718 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~246 ~155 ~720 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~720 ~429 ~155 ~732 minecraft:redstone_wire replace
fill ~432 ~155 ~720 ~432 ~155 ~732 minecraft:redstone_wire replace
setblock ~402 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~722 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~723 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~249 ~155 ~724 minecraft:redstone_wire replace
setblock ~252 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~724 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~402 ~155 ~724 ~402 ~155 ~730 minecraft:redstone_wire replace
fill ~405 ~155 ~724 ~405 ~155 ~734 minecraft:redstone_wire replace
fill ~408 ~155 ~724 ~408 ~155 ~736 minecraft:redstone_wire replace
fill ~411 ~155 ~724 ~411 ~155 ~736 minecraft:redstone_wire replace
fill ~414 ~155 ~724 ~414 ~155 ~736 minecraft:redstone_wire replace
fill ~417 ~155 ~724 ~417 ~155 ~736 minecraft:redstone_wire replace
fill ~420 ~155 ~724 ~420 ~155 ~736 minecraft:redstone_wire replace
fill ~423 ~155 ~724 ~423 ~155 ~736 minecraft:redstone_wire replace
fill ~252 ~155 ~726 ~252 ~155 ~728 minecraft:redstone_wire replace
fill ~255 ~155 ~726 ~255 ~155 ~738 minecraft:redstone_wire replace
fill ~258 ~155 ~726 ~258 ~155 ~738 minecraft:redstone_wire replace
fill ~261 ~155 ~726 ~261 ~155 ~738 minecraft:redstone_wire replace
fill ~264 ~155 ~726 ~264 ~155 ~738 minecraft:redstone_wire replace
fill ~267 ~155 ~726 ~267 ~155 ~738 minecraft:redstone_wire replace
fill ~270 ~155 ~726 ~270 ~155 ~738 minecraft:redstone_wire replace
fill ~273 ~155 ~726 ~273 ~155 ~738 minecraft:redstone_wire replace
fill ~276 ~155 ~726 ~276 ~155 ~738 minecraft:redstone_wire replace
fill ~279 ~155 ~726 ~279 ~155 ~738 minecraft:redstone_wire replace
fill ~282 ~155 ~726 ~282 ~155 ~738 minecraft:redstone_wire replace
fill ~285 ~155 ~726 ~285 ~155 ~738 minecraft:redstone_wire replace
fill ~288 ~155 ~726 ~288 ~155 ~738 minecraft:redstone_wire replace
fill ~291 ~155 ~726 ~291 ~155 ~738 minecraft:redstone_wire replace
fill ~294 ~155 ~726 ~294 ~155 ~738 minecraft:redstone_wire replace
fill ~297 ~155 ~726 ~297 ~155 ~738 minecraft:redstone_wire replace
fill ~300 ~155 ~726 ~300 ~155 ~738 minecraft:redstone_wire replace
fill ~303 ~155 ~726 ~303 ~155 ~738 minecraft:redstone_wire replace
fill ~306 ~155 ~726 ~306 ~155 ~738 minecraft:redstone_wire replace
fill ~309 ~155 ~726 ~309 ~155 ~738 minecraft:redstone_wire replace
fill ~312 ~155 ~726 ~312 ~155 ~738 minecraft:redstone_wire replace
fill ~315 ~155 ~726 ~315 ~155 ~738 minecraft:redstone_wire replace
fill ~318 ~155 ~726 ~318 ~155 ~738 minecraft:redstone_wire replace
fill ~321 ~155 ~726 ~321 ~155 ~738 minecraft:redstone_wire replace
fill ~324 ~155 ~726 ~324 ~155 ~738 minecraft:redstone_wire replace
fill ~327 ~155 ~726 ~327 ~155 ~738 minecraft:redstone_wire replace
fill ~330 ~155 ~726 ~330 ~155 ~738 minecraft:redstone_wire replace
fill ~333 ~155 ~726 ~333 ~155 ~738 minecraft:redstone_wire replace
fill ~336 ~155 ~726 ~336 ~155 ~738 minecraft:redstone_wire replace
fill ~339 ~155 ~726 ~339 ~155 ~738 minecraft:redstone_wire replace
fill ~342 ~155 ~726 ~342 ~155 ~738 minecraft:redstone_wire replace
fill ~345 ~155 ~726 ~345 ~155 ~738 minecraft:redstone_wire replace
fill ~348 ~155 ~726 ~348 ~155 ~738 minecraft:redstone_wire replace
fill ~351 ~155 ~726 ~351 ~155 ~738 minecraft:redstone_wire replace
fill ~354 ~155 ~726 ~354 ~155 ~738 minecraft:redstone_wire replace
fill ~357 ~155 ~726 ~357 ~155 ~738 minecraft:redstone_wire replace
fill ~360 ~155 ~726 ~360 ~155 ~738 minecraft:redstone_wire replace
fill ~363 ~155 ~726 ~363 ~155 ~738 minecraft:redstone_wire replace
fill ~366 ~155 ~726 ~366 ~155 ~738 minecraft:redstone_wire replace
fill ~369 ~155 ~726 ~369 ~155 ~738 minecraft:redstone_wire replace
fill ~372 ~155 ~726 ~372 ~155 ~738 minecraft:redstone_wire replace
fill ~375 ~155 ~726 ~375 ~155 ~738 minecraft:redstone_wire replace
fill ~378 ~155 ~726 ~378 ~155 ~738 minecraft:redstone_wire replace
fill ~381 ~155 ~726 ~381 ~155 ~738 minecraft:redstone_wire replace
fill ~384 ~155 ~726 ~384 ~155 ~738 minecraft:redstone_wire replace
fill ~387 ~155 ~726 ~387 ~155 ~738 minecraft:redstone_wire replace
fill ~390 ~155 ~726 ~390 ~155 ~738 minecraft:redstone_wire replace
fill ~393 ~155 ~726 ~393 ~155 ~738 minecraft:redstone_wire replace
fill ~396 ~155 ~726 ~396 ~155 ~738 minecraft:redstone_wire replace
fill ~399 ~155 ~726 ~399 ~155 ~738 minecraft:redstone_wire replace
setblock ~426 ~155 ~726 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~728 ~426 ~155 ~740 minecraft:redstone_wire replace
setblock ~402 ~155 ~732 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~429 ~155 ~734 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~734 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~405 ~155 ~736 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~736 ~429 ~155 ~748 minecraft:redstone_wire replace
fill ~432 ~155 ~736 ~432 ~155 ~748 minecraft:redstone_wire replace
setblock ~408 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~411 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~414 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~738 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~740 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~408 ~155 ~740 minecraft:redstone_wire replace
fill ~411 ~155 ~740 ~411 ~155 ~744 minecraft:redstone_wire replace
fill ~414 ~155 ~740 ~414 ~155 ~746 minecraft:redstone_wire replace
fill ~417 ~155 ~740 ~417 ~155 ~750 minecraft:redstone_wire replace
fill ~420 ~155 ~740 ~420 ~155 ~752 minecraft:redstone_wire replace
fill ~423 ~155 ~740 ~423 ~155 ~752 minecraft:redstone_wire replace
fill ~255 ~155 ~742 ~255 ~155 ~754 minecraft:redstone_wire replace
fill ~258 ~155 ~742 ~258 ~155 ~754 minecraft:redstone_wire replace
fill ~261 ~155 ~742 ~261 ~155 ~754 minecraft:redstone_wire replace
fill ~264 ~155 ~742 ~264 ~155 ~754 minecraft:redstone_wire replace
fill ~267 ~155 ~742 ~267 ~155 ~754 minecraft:redstone_wire replace
fill ~270 ~155 ~742 ~270 ~155 ~754 minecraft:redstone_wire replace
fill ~273 ~155 ~742 ~273 ~155 ~754 minecraft:redstone_wire replace
fill ~276 ~155 ~742 ~276 ~155 ~754 minecraft:redstone_wire replace
fill ~279 ~155 ~742 ~279 ~155 ~754 minecraft:redstone_wire replace
fill ~282 ~155 ~742 ~282 ~155 ~754 minecraft:redstone_wire replace
fill ~285 ~155 ~742 ~285 ~155 ~754 minecraft:redstone_wire replace
fill ~288 ~155 ~742 ~288 ~155 ~754 minecraft:redstone_wire replace
fill ~291 ~155 ~742 ~291 ~155 ~754 minecraft:redstone_wire replace
fill ~294 ~155 ~742 ~294 ~155 ~754 minecraft:redstone_wire replace
fill ~297 ~155 ~742 ~297 ~155 ~754 minecraft:redstone_wire replace
fill ~300 ~155 ~742 ~300 ~155 ~754 minecraft:redstone_wire replace
fill ~303 ~155 ~742 ~303 ~155 ~754 minecraft:redstone_wire replace
fill ~306 ~155 ~742 ~306 ~155 ~754 minecraft:redstone_wire replace
fill ~309 ~155 ~742 ~309 ~155 ~754 minecraft:redstone_wire replace
fill ~312 ~155 ~742 ~312 ~155 ~754 minecraft:redstone_wire replace
fill ~315 ~155 ~742 ~315 ~155 ~754 minecraft:redstone_wire replace
fill ~318 ~155 ~742 ~318 ~155 ~754 minecraft:redstone_wire replace
fill ~321 ~155 ~742 ~321 ~155 ~754 minecraft:redstone_wire replace
fill ~324 ~155 ~742 ~324 ~155 ~754 minecraft:redstone_wire replace
fill ~327 ~155 ~742 ~327 ~155 ~754 minecraft:redstone_wire replace
fill ~330 ~155 ~742 ~330 ~155 ~754 minecraft:redstone_wire replace
fill ~333 ~155 ~742 ~333 ~155 ~754 minecraft:redstone_wire replace
fill ~336 ~155 ~742 ~336 ~155 ~754 minecraft:redstone_wire replace
fill ~339 ~155 ~742 ~339 ~155 ~754 minecraft:redstone_wire replace
fill ~342 ~155 ~742 ~342 ~155 ~754 minecraft:redstone_wire replace
fill ~345 ~155 ~742 ~345 ~155 ~754 minecraft:redstone_wire replace
fill ~348 ~155 ~742 ~348 ~155 ~754 minecraft:redstone_wire replace
fill ~351 ~155 ~742 ~351 ~155 ~754 minecraft:redstone_wire replace
fill ~354 ~155 ~742 ~354 ~155 ~754 minecraft:redstone_wire replace
fill ~357 ~155 ~742 ~357 ~155 ~754 minecraft:redstone_wire replace
fill ~360 ~155 ~742 ~360 ~155 ~754 minecraft:redstone_wire replace
fill ~363 ~155 ~742 ~363 ~155 ~754 minecraft:redstone_wire replace
fill ~366 ~155 ~742 ~366 ~155 ~754 minecraft:redstone_wire replace
fill ~369 ~155 ~742 ~369 ~155 ~754 minecraft:redstone_wire replace
fill ~372 ~155 ~742 ~372 ~155 ~754 minecraft:redstone_wire replace
fill ~375 ~155 ~742 ~375 ~155 ~754 minecraft:redstone_wire replace
fill ~378 ~155 ~742 ~378 ~155 ~754 minecraft:redstone_wire replace
fill ~381 ~155 ~742 ~381 ~155 ~754 minecraft:redstone_wire replace
fill ~384 ~155 ~742 ~384 ~155 ~754 minecraft:redstone_wire replace
fill ~387 ~155 ~742 ~387 ~155 ~754 minecraft:redstone_wire replace
fill ~390 ~155 ~742 ~390 ~155 ~754 minecraft:redstone_wire replace
fill ~393 ~155 ~742 ~393 ~155 ~754 minecraft:redstone_wire replace
fill ~396 ~155 ~742 ~396 ~155 ~754 minecraft:redstone_wire replace
fill ~399 ~155 ~742 ~399 ~155 ~754 minecraft:redstone_wire replace
setblock ~426 ~155 ~742 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~744 ~426 ~155 ~756 minecraft:redstone_wire replace
setblock ~414 ~155 ~748 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~429 ~155 ~750 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~750 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~417 ~155 ~752 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~752 ~429 ~155 ~764 minecraft:redstone_wire replace
fill ~432 ~155 ~752 ~432 ~155 ~764 minecraft:redstone_wire replace
setblock ~420 ~155 ~754 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~423 ~155 ~754 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~255 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~264 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~756 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~420 ~155 ~756 minecraft:redstone_wire replace
fill ~423 ~155 ~756 ~423 ~155 ~760 minecraft:redstone_wire replace
fill ~255 ~155 ~758 ~255 ~155 ~764 minecraft:redstone_wire replace
fill ~258 ~155 ~758 ~258 ~155 ~766 minecraft:redstone_wire replace
fill ~261 ~155 ~758 ~261 ~155 ~770 minecraft:redstone_wire replace
fill ~264 ~155 ~758 ~264 ~155 ~770 minecraft:redstone_wire replace
fill ~267 ~155 ~758 ~267 ~155 ~770 minecraft:redstone_wire replace
fill ~270 ~155 ~758 ~270 ~155 ~770 minecraft:redstone_wire replace
fill ~273 ~155 ~758 ~273 ~155 ~770 minecraft:redstone_wire replace
fill ~276 ~155 ~758 ~276 ~155 ~770 minecraft:redstone_wire replace
fill ~279 ~155 ~758 ~279 ~155 ~770 minecraft:redstone_wire replace
fill ~282 ~155 ~758 ~282 ~155 ~770 minecraft:redstone_wire replace
fill ~285 ~155 ~758 ~285 ~155 ~770 minecraft:redstone_wire replace
fill ~288 ~155 ~758 ~288 ~155 ~770 minecraft:redstone_wire replace
fill ~291 ~155 ~758 ~291 ~155 ~770 minecraft:redstone_wire replace
fill ~294 ~155 ~758 ~294 ~155 ~770 minecraft:redstone_wire replace
fill ~297 ~155 ~758 ~297 ~155 ~770 minecraft:redstone_wire replace
fill ~300 ~155 ~758 ~300 ~155 ~770 minecraft:redstone_wire replace
fill ~303 ~155 ~758 ~303 ~155 ~770 minecraft:redstone_wire replace
fill ~306 ~155 ~758 ~306 ~155 ~770 minecraft:redstone_wire replace
fill ~309 ~155 ~758 ~309 ~155 ~770 minecraft:redstone_wire replace
fill ~312 ~155 ~758 ~312 ~155 ~770 minecraft:redstone_wire replace
fill ~315 ~155 ~758 ~315 ~155 ~770 minecraft:redstone_wire replace
fill ~318 ~155 ~758 ~318 ~155 ~770 minecraft:redstone_wire replace
fill ~321 ~155 ~758 ~321 ~155 ~770 minecraft:redstone_wire replace
fill ~324 ~155 ~758 ~324 ~155 ~770 minecraft:redstone_wire replace
fill ~327 ~155 ~758 ~327 ~155 ~770 minecraft:redstone_wire replace
fill ~330 ~155 ~758 ~330 ~155 ~770 minecraft:redstone_wire replace
fill ~333 ~155 ~758 ~333 ~155 ~770 minecraft:redstone_wire replace
fill ~336 ~155 ~758 ~336 ~155 ~770 minecraft:redstone_wire replace
fill ~339 ~155 ~758 ~339 ~155 ~770 minecraft:redstone_wire replace
fill ~342 ~155 ~758 ~342 ~155 ~770 minecraft:redstone_wire replace
fill ~345 ~155 ~758 ~345 ~155 ~770 minecraft:redstone_wire replace
fill ~348 ~155 ~758 ~348 ~155 ~770 minecraft:redstone_wire replace
fill ~351 ~155 ~758 ~351 ~155 ~770 minecraft:redstone_wire replace
fill ~354 ~155 ~758 ~354 ~155 ~770 minecraft:redstone_wire replace
fill ~357 ~155 ~758 ~357 ~155 ~770 minecraft:redstone_wire replace
fill ~360 ~155 ~758 ~360 ~155 ~770 minecraft:redstone_wire replace
fill ~363 ~155 ~758 ~363 ~155 ~770 minecraft:redstone_wire replace
fill ~366 ~155 ~758 ~366 ~155 ~770 minecraft:redstone_wire replace
fill ~369 ~155 ~758 ~369 ~155 ~770 minecraft:redstone_wire replace
fill ~372 ~155 ~758 ~372 ~155 ~770 minecraft:redstone_wire replace
fill ~375 ~155 ~758 ~375 ~155 ~770 minecraft:redstone_wire replace
fill ~378 ~155 ~758 ~378 ~155 ~770 minecraft:redstone_wire replace
fill ~381 ~155 ~758 ~381 ~155 ~770 minecraft:redstone_wire replace
fill ~384 ~155 ~758 ~384 ~155 ~770 minecraft:redstone_wire replace
fill ~387 ~155 ~758 ~387 ~155 ~770 minecraft:redstone_wire replace
fill ~390 ~155 ~758 ~390 ~155 ~770 minecraft:redstone_wire replace
fill ~393 ~155 ~758 ~393 ~155 ~770 minecraft:redstone_wire replace
fill ~396 ~155 ~758 ~396 ~155 ~770 minecraft:redstone_wire replace
fill ~399 ~155 ~758 ~399 ~155 ~770 minecraft:redstone_wire replace
setblock ~426 ~155 ~758 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~760 ~426 ~155 ~772 minecraft:redstone_wire replace
setblock ~429 ~155 ~766 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~766 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~258 ~155 ~768 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~768 ~429 ~155 ~780 minecraft:redstone_wire replace
fill ~432 ~155 ~768 ~432 ~155 ~780 minecraft:redstone_wire replace
setblock ~261 ~155 ~771 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~261 ~155 ~772 minecraft:redstone_wire replace
setblock ~264 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~267 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~276 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~772 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~264 ~155 ~774 ~264 ~155 ~776 minecraft:redstone_wire replace
fill ~267 ~155 ~774 ~267 ~155 ~780 minecraft:redstone_wire replace
fill ~270 ~155 ~774 ~270 ~155 ~782 minecraft:redstone_wire replace
fill ~273 ~155 ~774 ~273 ~155 ~786 minecraft:redstone_wire replace
fill ~276 ~155 ~774 ~276 ~155 ~786 minecraft:redstone_wire replace
fill ~279 ~155 ~774 ~279 ~155 ~786 minecraft:redstone_wire replace
fill ~282 ~155 ~774 ~282 ~155 ~786 minecraft:redstone_wire replace
fill ~285 ~155 ~774 ~285 ~155 ~786 minecraft:redstone_wire replace
fill ~288 ~155 ~774 ~288 ~155 ~786 minecraft:redstone_wire replace
fill ~291 ~155 ~774 ~291 ~155 ~786 minecraft:redstone_wire replace
fill ~294 ~155 ~774 ~294 ~155 ~786 minecraft:redstone_wire replace
fill ~297 ~155 ~774 ~297 ~155 ~786 minecraft:redstone_wire replace
fill ~300 ~155 ~774 ~300 ~155 ~786 minecraft:redstone_wire replace
fill ~303 ~155 ~774 ~303 ~155 ~786 minecraft:redstone_wire replace
fill ~306 ~155 ~774 ~306 ~155 ~786 minecraft:redstone_wire replace
fill ~309 ~155 ~774 ~309 ~155 ~786 minecraft:redstone_wire replace
fill ~312 ~155 ~774 ~312 ~155 ~786 minecraft:redstone_wire replace
fill ~315 ~155 ~774 ~315 ~155 ~786 minecraft:redstone_wire replace
fill ~318 ~155 ~774 ~318 ~155 ~786 minecraft:redstone_wire replace
fill ~321 ~155 ~774 ~321 ~155 ~786 minecraft:redstone_wire replace
fill ~324 ~155 ~774 ~324 ~155 ~786 minecraft:redstone_wire replace
fill ~327 ~155 ~774 ~327 ~155 ~786 minecraft:redstone_wire replace
fill ~330 ~155 ~774 ~330 ~155 ~786 minecraft:redstone_wire replace
fill ~333 ~155 ~774 ~333 ~155 ~786 minecraft:redstone_wire replace
fill ~336 ~155 ~774 ~336 ~155 ~786 minecraft:redstone_wire replace
fill ~339 ~155 ~774 ~339 ~155 ~786 minecraft:redstone_wire replace
fill ~342 ~155 ~774 ~342 ~155 ~786 minecraft:redstone_wire replace
fill ~345 ~155 ~774 ~345 ~155 ~786 minecraft:redstone_wire replace
fill ~348 ~155 ~774 ~348 ~155 ~786 minecraft:redstone_wire replace
fill ~351 ~155 ~774 ~351 ~155 ~786 minecraft:redstone_wire replace
fill ~354 ~155 ~774 ~354 ~155 ~786 minecraft:redstone_wire replace
fill ~357 ~155 ~774 ~357 ~155 ~786 minecraft:redstone_wire replace
fill ~360 ~155 ~774 ~360 ~155 ~786 minecraft:redstone_wire replace
fill ~363 ~155 ~774 ~363 ~155 ~786 minecraft:redstone_wire replace
fill ~366 ~155 ~774 ~366 ~155 ~786 minecraft:redstone_wire replace
fill ~369 ~155 ~774 ~369 ~155 ~786 minecraft:redstone_wire replace
fill ~372 ~155 ~774 ~372 ~155 ~786 minecraft:redstone_wire replace
fill ~375 ~155 ~774 ~375 ~155 ~786 minecraft:redstone_wire replace
fill ~378 ~155 ~774 ~378 ~155 ~786 minecraft:redstone_wire replace
fill ~381 ~155 ~774 ~381 ~155 ~786 minecraft:redstone_wire replace
fill ~384 ~155 ~774 ~384 ~155 ~786 minecraft:redstone_wire replace
fill ~387 ~155 ~774 ~387 ~155 ~786 minecraft:redstone_wire replace
fill ~390 ~155 ~774 ~390 ~155 ~786 minecraft:redstone_wire replace
fill ~393 ~155 ~774 ~393 ~155 ~786 minecraft:redstone_wire replace
fill ~396 ~155 ~774 ~396 ~155 ~786 minecraft:redstone_wire replace
fill ~399 ~155 ~774 ~399 ~155 ~786 minecraft:redstone_wire replace
setblock ~426 ~155 ~774 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~776 ~426 ~155 ~788 minecraft:redstone_wire replace
setblock ~429 ~155 ~782 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~782 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~270 ~155 ~784 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~784 ~429 ~155 ~796 minecraft:redstone_wire replace
fill ~432 ~155 ~784 ~432 ~155 ~796 minecraft:redstone_wire replace
setblock ~273 ~155 ~787 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~273 ~155 ~788 minecraft:redstone_wire replace
setblock ~276 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~279 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~288 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~788 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~155 ~790 ~276 ~155 ~792 minecraft:redstone_wire replace
fill ~279 ~155 ~790 ~279 ~155 ~796 minecraft:redstone_wire replace
fill ~282 ~155 ~790 ~282 ~155 ~798 minecraft:redstone_wire replace
fill ~285 ~155 ~790 ~285 ~155 ~802 minecraft:redstone_wire replace
fill ~288 ~155 ~790 ~288 ~155 ~802 minecraft:redstone_wire replace
fill ~291 ~155 ~790 ~291 ~155 ~802 minecraft:redstone_wire replace
fill ~294 ~155 ~790 ~294 ~155 ~802 minecraft:redstone_wire replace
fill ~297 ~155 ~790 ~297 ~155 ~802 minecraft:redstone_wire replace
fill ~300 ~155 ~790 ~300 ~155 ~802 minecraft:redstone_wire replace
fill ~303 ~155 ~790 ~303 ~155 ~802 minecraft:redstone_wire replace
fill ~306 ~155 ~790 ~306 ~155 ~802 minecraft:redstone_wire replace
fill ~309 ~155 ~790 ~309 ~155 ~802 minecraft:redstone_wire replace
fill ~312 ~155 ~790 ~312 ~155 ~802 minecraft:redstone_wire replace
fill ~315 ~155 ~790 ~315 ~155 ~802 minecraft:redstone_wire replace
fill ~318 ~155 ~790 ~318 ~155 ~802 minecraft:redstone_wire replace
fill ~321 ~155 ~790 ~321 ~155 ~802 minecraft:redstone_wire replace
fill ~324 ~155 ~790 ~324 ~155 ~802 minecraft:redstone_wire replace
fill ~327 ~155 ~790 ~327 ~155 ~802 minecraft:redstone_wire replace
fill ~330 ~155 ~790 ~330 ~155 ~802 minecraft:redstone_wire replace
fill ~333 ~155 ~790 ~333 ~155 ~802 minecraft:redstone_wire replace
fill ~336 ~155 ~790 ~336 ~155 ~802 minecraft:redstone_wire replace
fill ~339 ~155 ~790 ~339 ~155 ~802 minecraft:redstone_wire replace
fill ~342 ~155 ~790 ~342 ~155 ~802 minecraft:redstone_wire replace
fill ~345 ~155 ~790 ~345 ~155 ~802 minecraft:redstone_wire replace
fill ~348 ~155 ~790 ~348 ~155 ~802 minecraft:redstone_wire replace
fill ~351 ~155 ~790 ~351 ~155 ~802 minecraft:redstone_wire replace
fill ~354 ~155 ~790 ~354 ~155 ~802 minecraft:redstone_wire replace
fill ~357 ~155 ~790 ~357 ~155 ~802 minecraft:redstone_wire replace
fill ~360 ~155 ~790 ~360 ~155 ~802 minecraft:redstone_wire replace
fill ~363 ~155 ~790 ~363 ~155 ~802 minecraft:redstone_wire replace
fill ~366 ~155 ~790 ~366 ~155 ~802 minecraft:redstone_wire replace
fill ~369 ~155 ~790 ~369 ~155 ~802 minecraft:redstone_wire replace
fill ~372 ~155 ~790 ~372 ~155 ~802 minecraft:redstone_wire replace
fill ~375 ~155 ~790 ~375 ~155 ~802 minecraft:redstone_wire replace
fill ~378 ~155 ~790 ~378 ~155 ~802 minecraft:redstone_wire replace
fill ~381 ~155 ~790 ~381 ~155 ~802 minecraft:redstone_wire replace
fill ~384 ~155 ~790 ~384 ~155 ~802 minecraft:redstone_wire replace
fill ~387 ~155 ~790 ~387 ~155 ~802 minecraft:redstone_wire replace
fill ~390 ~155 ~790 ~390 ~155 ~802 minecraft:redstone_wire replace
fill ~393 ~155 ~790 ~393 ~155 ~802 minecraft:redstone_wire replace
fill ~396 ~155 ~790 ~396 ~155 ~802 minecraft:redstone_wire replace
fill ~399 ~155 ~790 ~399 ~155 ~802 minecraft:redstone_wire replace
setblock ~426 ~155 ~790 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~792 ~426 ~155 ~804 minecraft:redstone_wire replace
setblock ~429 ~155 ~798 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~798 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~282 ~155 ~800 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~800 ~429 ~155 ~812 minecraft:redstone_wire replace
fill ~432 ~155 ~800 ~432 ~155 ~812 minecraft:redstone_wire replace
setblock ~285 ~155 ~803 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~285 ~155 ~804 minecraft:redstone_wire replace
setblock ~288 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~291 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~300 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~804 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~155 ~806 ~288 ~155 ~808 minecraft:redstone_wire replace
fill ~291 ~155 ~806 ~291 ~155 ~812 minecraft:redstone_wire replace
fill ~294 ~155 ~806 ~294 ~155 ~814 minecraft:redstone_wire replace
fill ~297 ~155 ~806 ~297 ~155 ~818 minecraft:redstone_wire replace
fill ~300 ~155 ~806 ~300 ~155 ~818 minecraft:redstone_wire replace
fill ~303 ~155 ~806 ~303 ~155 ~818 minecraft:redstone_wire replace
fill ~306 ~155 ~806 ~306 ~155 ~818 minecraft:redstone_wire replace
fill ~309 ~155 ~806 ~309 ~155 ~818 minecraft:redstone_wire replace
fill ~312 ~155 ~806 ~312 ~155 ~818 minecraft:redstone_wire replace
fill ~315 ~155 ~806 ~315 ~155 ~818 minecraft:redstone_wire replace
fill ~318 ~155 ~806 ~318 ~155 ~818 minecraft:redstone_wire replace
fill ~321 ~155 ~806 ~321 ~155 ~818 minecraft:redstone_wire replace
fill ~324 ~155 ~806 ~324 ~155 ~818 minecraft:redstone_wire replace
fill ~327 ~155 ~806 ~327 ~155 ~818 minecraft:redstone_wire replace
fill ~330 ~155 ~806 ~330 ~155 ~818 minecraft:redstone_wire replace
fill ~333 ~155 ~806 ~333 ~155 ~818 minecraft:redstone_wire replace
fill ~336 ~155 ~806 ~336 ~155 ~818 minecraft:redstone_wire replace
fill ~339 ~155 ~806 ~339 ~155 ~818 minecraft:redstone_wire replace
fill ~342 ~155 ~806 ~342 ~155 ~818 minecraft:redstone_wire replace
fill ~345 ~155 ~806 ~345 ~155 ~818 minecraft:redstone_wire replace
fill ~348 ~155 ~806 ~348 ~155 ~818 minecraft:redstone_wire replace
fill ~351 ~155 ~806 ~351 ~155 ~818 minecraft:redstone_wire replace
fill ~354 ~155 ~806 ~354 ~155 ~818 minecraft:redstone_wire replace
fill ~357 ~155 ~806 ~357 ~155 ~818 minecraft:redstone_wire replace
fill ~360 ~155 ~806 ~360 ~155 ~818 minecraft:redstone_wire replace
fill ~363 ~155 ~806 ~363 ~155 ~818 minecraft:redstone_wire replace
fill ~366 ~155 ~806 ~366 ~155 ~818 minecraft:redstone_wire replace
fill ~369 ~155 ~806 ~369 ~155 ~818 minecraft:redstone_wire replace
fill ~372 ~155 ~806 ~372 ~155 ~818 minecraft:redstone_wire replace
fill ~375 ~155 ~806 ~375 ~155 ~818 minecraft:redstone_wire replace
fill ~378 ~155 ~806 ~378 ~155 ~818 minecraft:redstone_wire replace
fill ~381 ~155 ~806 ~381 ~155 ~818 minecraft:redstone_wire replace
fill ~384 ~155 ~806 ~384 ~155 ~818 minecraft:redstone_wire replace
fill ~387 ~155 ~806 ~387 ~155 ~818 minecraft:redstone_wire replace
fill ~390 ~155 ~806 ~390 ~155 ~818 minecraft:redstone_wire replace
fill ~393 ~155 ~806 ~393 ~155 ~818 minecraft:redstone_wire replace
fill ~396 ~155 ~806 ~396 ~155 ~818 minecraft:redstone_wire replace
fill ~399 ~155 ~806 ~399 ~155 ~818 minecraft:redstone_wire replace
setblock ~426 ~155 ~806 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~808 ~426 ~155 ~820 minecraft:redstone_wire replace
setblock ~429 ~155 ~814 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~814 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~294 ~155 ~816 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~816 ~429 ~155 ~828 minecraft:redstone_wire replace
fill ~432 ~155 ~816 ~432 ~155 ~828 minecraft:redstone_wire replace
setblock ~297 ~155 ~819 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~297 ~155 ~820 minecraft:redstone_wire replace
setblock ~300 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~303 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~312 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~820 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~155 ~822 ~300 ~155 ~824 minecraft:redstone_wire replace
fill ~303 ~155 ~822 ~303 ~155 ~828 minecraft:redstone_wire replace
fill ~306 ~155 ~822 ~306 ~155 ~830 minecraft:redstone_wire replace
fill ~309 ~155 ~822 ~309 ~155 ~834 minecraft:redstone_wire replace
fill ~312 ~155 ~822 ~312 ~155 ~834 minecraft:redstone_wire replace
fill ~315 ~155 ~822 ~315 ~155 ~834 minecraft:redstone_wire replace
fill ~318 ~155 ~822 ~318 ~155 ~834 minecraft:redstone_wire replace
fill ~321 ~155 ~822 ~321 ~155 ~834 minecraft:redstone_wire replace
fill ~324 ~155 ~822 ~324 ~155 ~834 minecraft:redstone_wire replace
fill ~327 ~155 ~822 ~327 ~155 ~834 minecraft:redstone_wire replace
fill ~330 ~155 ~822 ~330 ~155 ~834 minecraft:redstone_wire replace
fill ~333 ~155 ~822 ~333 ~155 ~834 minecraft:redstone_wire replace
fill ~336 ~155 ~822 ~336 ~155 ~834 minecraft:redstone_wire replace
fill ~339 ~155 ~822 ~339 ~155 ~834 minecraft:redstone_wire replace
fill ~342 ~155 ~822 ~342 ~155 ~834 minecraft:redstone_wire replace
fill ~345 ~155 ~822 ~345 ~155 ~834 minecraft:redstone_wire replace
fill ~348 ~155 ~822 ~348 ~155 ~834 minecraft:redstone_wire replace
fill ~351 ~155 ~822 ~351 ~155 ~834 minecraft:redstone_wire replace
fill ~354 ~155 ~822 ~354 ~155 ~834 minecraft:redstone_wire replace
fill ~357 ~155 ~822 ~357 ~155 ~834 minecraft:redstone_wire replace
fill ~360 ~155 ~822 ~360 ~155 ~834 minecraft:redstone_wire replace
fill ~363 ~155 ~822 ~363 ~155 ~834 minecraft:redstone_wire replace
fill ~366 ~155 ~822 ~366 ~155 ~834 minecraft:redstone_wire replace
fill ~369 ~155 ~822 ~369 ~155 ~834 minecraft:redstone_wire replace
fill ~372 ~155 ~822 ~372 ~155 ~834 minecraft:redstone_wire replace
fill ~375 ~155 ~822 ~375 ~155 ~834 minecraft:redstone_wire replace
fill ~378 ~155 ~822 ~378 ~155 ~834 minecraft:redstone_wire replace
fill ~381 ~155 ~822 ~381 ~155 ~834 minecraft:redstone_wire replace
fill ~384 ~155 ~822 ~384 ~155 ~834 minecraft:redstone_wire replace
fill ~387 ~155 ~822 ~387 ~155 ~834 minecraft:redstone_wire replace
fill ~390 ~155 ~822 ~390 ~155 ~834 minecraft:redstone_wire replace
fill ~393 ~155 ~822 ~393 ~155 ~834 minecraft:redstone_wire replace
fill ~396 ~155 ~822 ~396 ~155 ~834 minecraft:redstone_wire replace
fill ~399 ~155 ~822 ~399 ~155 ~834 minecraft:redstone_wire replace
setblock ~426 ~155 ~822 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~824 ~426 ~155 ~836 minecraft:redstone_wire replace
setblock ~429 ~155 ~830 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~830 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~306 ~155 ~832 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~832 ~429 ~155 ~844 minecraft:redstone_wire replace
fill ~432 ~155 ~832 ~432 ~155 ~844 minecraft:redstone_wire replace
setblock ~309 ~155 ~835 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~309 ~155 ~836 minecraft:redstone_wire replace
setblock ~312 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~315 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~324 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~836 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~155 ~838 ~312 ~155 ~840 minecraft:redstone_wire replace
fill ~315 ~155 ~838 ~315 ~155 ~844 minecraft:redstone_wire replace
fill ~318 ~155 ~838 ~318 ~155 ~846 minecraft:redstone_wire replace
fill ~321 ~155 ~838 ~321 ~155 ~850 minecraft:redstone_wire replace
fill ~324 ~155 ~838 ~324 ~155 ~850 minecraft:redstone_wire replace
fill ~327 ~155 ~838 ~327 ~155 ~850 minecraft:redstone_wire replace
fill ~330 ~155 ~838 ~330 ~155 ~850 minecraft:redstone_wire replace
fill ~333 ~155 ~838 ~333 ~155 ~850 minecraft:redstone_wire replace
fill ~336 ~155 ~838 ~336 ~155 ~850 minecraft:redstone_wire replace
fill ~339 ~155 ~838 ~339 ~155 ~850 minecraft:redstone_wire replace
fill ~342 ~155 ~838 ~342 ~155 ~850 minecraft:redstone_wire replace
fill ~345 ~155 ~838 ~345 ~155 ~850 minecraft:redstone_wire replace
fill ~348 ~155 ~838 ~348 ~155 ~850 minecraft:redstone_wire replace
fill ~351 ~155 ~838 ~351 ~155 ~850 minecraft:redstone_wire replace
fill ~354 ~155 ~838 ~354 ~155 ~850 minecraft:redstone_wire replace
fill ~357 ~155 ~838 ~357 ~155 ~850 minecraft:redstone_wire replace
fill ~360 ~155 ~838 ~360 ~155 ~850 minecraft:redstone_wire replace
fill ~363 ~155 ~838 ~363 ~155 ~850 minecraft:redstone_wire replace
fill ~366 ~155 ~838 ~366 ~155 ~850 minecraft:redstone_wire replace
fill ~369 ~155 ~838 ~369 ~155 ~850 minecraft:redstone_wire replace
fill ~372 ~155 ~838 ~372 ~155 ~850 minecraft:redstone_wire replace
fill ~375 ~155 ~838 ~375 ~155 ~850 minecraft:redstone_wire replace
fill ~378 ~155 ~838 ~378 ~155 ~850 minecraft:redstone_wire replace
fill ~381 ~155 ~838 ~381 ~155 ~850 minecraft:redstone_wire replace
fill ~384 ~155 ~838 ~384 ~155 ~850 minecraft:redstone_wire replace
fill ~387 ~155 ~838 ~387 ~155 ~850 minecraft:redstone_wire replace
fill ~390 ~155 ~838 ~390 ~155 ~850 minecraft:redstone_wire replace
fill ~393 ~155 ~838 ~393 ~155 ~850 minecraft:redstone_wire replace
fill ~396 ~155 ~838 ~396 ~155 ~850 minecraft:redstone_wire replace
fill ~399 ~155 ~838 ~399 ~155 ~850 minecraft:redstone_wire replace
setblock ~426 ~155 ~838 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~840 ~426 ~155 ~852 minecraft:redstone_wire replace
setblock ~429 ~155 ~846 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~846 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~318 ~155 ~848 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~848 ~429 ~155 ~860 minecraft:redstone_wire replace
fill ~432 ~155 ~848 ~432 ~155 ~860 minecraft:redstone_wire replace
setblock ~321 ~155 ~851 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~321 ~155 ~852 minecraft:redstone_wire replace
setblock ~324 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~327 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~336 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~852 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~324 ~155 ~854 ~324 ~155 ~856 minecraft:redstone_wire replace
fill ~327 ~155 ~854 ~327 ~155 ~860 minecraft:redstone_wire replace
fill ~330 ~155 ~854 ~330 ~155 ~862 minecraft:redstone_wire replace
fill ~333 ~155 ~854 ~333 ~155 ~866 minecraft:redstone_wire replace
fill ~336 ~155 ~854 ~336 ~155 ~866 minecraft:redstone_wire replace
fill ~339 ~155 ~854 ~339 ~155 ~866 minecraft:redstone_wire replace
fill ~342 ~155 ~854 ~342 ~155 ~866 minecraft:redstone_wire replace
fill ~345 ~155 ~854 ~345 ~155 ~866 minecraft:redstone_wire replace
fill ~348 ~155 ~854 ~348 ~155 ~866 minecraft:redstone_wire replace
fill ~351 ~155 ~854 ~351 ~155 ~866 minecraft:redstone_wire replace
fill ~354 ~155 ~854 ~354 ~155 ~866 minecraft:redstone_wire replace
fill ~357 ~155 ~854 ~357 ~155 ~866 minecraft:redstone_wire replace
fill ~360 ~155 ~854 ~360 ~155 ~866 minecraft:redstone_wire replace
fill ~363 ~155 ~854 ~363 ~155 ~866 minecraft:redstone_wire replace
fill ~366 ~155 ~854 ~366 ~155 ~866 minecraft:redstone_wire replace
fill ~369 ~155 ~854 ~369 ~155 ~866 minecraft:redstone_wire replace
fill ~372 ~155 ~854 ~372 ~155 ~866 minecraft:redstone_wire replace
fill ~375 ~155 ~854 ~375 ~155 ~866 minecraft:redstone_wire replace
fill ~378 ~155 ~854 ~378 ~155 ~866 minecraft:redstone_wire replace
fill ~381 ~155 ~854 ~381 ~155 ~866 minecraft:redstone_wire replace
fill ~384 ~155 ~854 ~384 ~155 ~866 minecraft:redstone_wire replace
fill ~387 ~155 ~854 ~387 ~155 ~866 minecraft:redstone_wire replace
fill ~390 ~155 ~854 ~390 ~155 ~866 minecraft:redstone_wire replace
fill ~393 ~155 ~854 ~393 ~155 ~866 minecraft:redstone_wire replace
fill ~396 ~155 ~854 ~396 ~155 ~866 minecraft:redstone_wire replace
fill ~399 ~155 ~854 ~399 ~155 ~866 minecraft:redstone_wire replace
setblock ~426 ~155 ~854 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~856 ~426 ~155 ~868 minecraft:redstone_wire replace
setblock ~429 ~155 ~862 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~862 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~330 ~155 ~864 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~864 ~429 ~155 ~876 minecraft:redstone_wire replace
fill ~432 ~155 ~864 ~432 ~155 ~876 minecraft:redstone_wire replace
setblock ~333 ~155 ~867 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~333 ~155 ~868 minecraft:redstone_wire replace
setblock ~336 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~339 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~348 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~868 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~336 ~155 ~870 ~336 ~155 ~872 minecraft:redstone_wire replace
fill ~339 ~155 ~870 ~339 ~155 ~876 minecraft:redstone_wire replace
fill ~342 ~155 ~870 ~342 ~155 ~878 minecraft:redstone_wire replace
fill ~345 ~155 ~870 ~345 ~155 ~882 minecraft:redstone_wire replace
fill ~348 ~155 ~870 ~348 ~155 ~882 minecraft:redstone_wire replace
fill ~351 ~155 ~870 ~351 ~155 ~882 minecraft:redstone_wire replace
fill ~354 ~155 ~870 ~354 ~155 ~882 minecraft:redstone_wire replace
fill ~357 ~155 ~870 ~357 ~155 ~882 minecraft:redstone_wire replace
fill ~360 ~155 ~870 ~360 ~155 ~882 minecraft:redstone_wire replace
fill ~363 ~155 ~870 ~363 ~155 ~882 minecraft:redstone_wire replace
fill ~366 ~155 ~870 ~366 ~155 ~882 minecraft:redstone_wire replace
fill ~369 ~155 ~870 ~369 ~155 ~882 minecraft:redstone_wire replace
fill ~372 ~155 ~870 ~372 ~155 ~882 minecraft:redstone_wire replace
fill ~375 ~155 ~870 ~375 ~155 ~882 minecraft:redstone_wire replace
fill ~378 ~155 ~870 ~378 ~155 ~882 minecraft:redstone_wire replace
fill ~381 ~155 ~870 ~381 ~155 ~882 minecraft:redstone_wire replace
fill ~384 ~155 ~870 ~384 ~155 ~882 minecraft:redstone_wire replace
fill ~387 ~155 ~870 ~387 ~155 ~882 minecraft:redstone_wire replace
fill ~390 ~155 ~870 ~390 ~155 ~882 minecraft:redstone_wire replace
fill ~393 ~155 ~870 ~393 ~155 ~882 minecraft:redstone_wire replace
fill ~396 ~155 ~870 ~396 ~155 ~882 minecraft:redstone_wire replace
fill ~399 ~155 ~870 ~399 ~155 ~882 minecraft:redstone_wire replace
setblock ~426 ~155 ~870 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~872 ~426 ~155 ~884 minecraft:redstone_wire replace
setblock ~429 ~155 ~878 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~878 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~342 ~155 ~880 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~880 ~429 ~155 ~892 minecraft:redstone_wire replace
fill ~432 ~155 ~880 ~432 ~155 ~892 minecraft:redstone_wire replace
setblock ~345 ~155 ~883 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~345 ~155 ~884 minecraft:redstone_wire replace
setblock ~348 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~351 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~360 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~884 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~155 ~886 ~348 ~155 ~888 minecraft:redstone_wire replace
fill ~351 ~155 ~886 ~351 ~155 ~892 minecraft:redstone_wire replace
fill ~354 ~155 ~886 ~354 ~155 ~894 minecraft:redstone_wire replace
fill ~357 ~155 ~886 ~357 ~155 ~898 minecraft:redstone_wire replace
fill ~360 ~155 ~886 ~360 ~155 ~898 minecraft:redstone_wire replace
fill ~363 ~155 ~886 ~363 ~155 ~898 minecraft:redstone_wire replace
fill ~366 ~155 ~886 ~366 ~155 ~898 minecraft:redstone_wire replace
fill ~369 ~155 ~886 ~369 ~155 ~898 minecraft:redstone_wire replace
fill ~372 ~155 ~886 ~372 ~155 ~898 minecraft:redstone_wire replace
fill ~375 ~155 ~886 ~375 ~155 ~898 minecraft:redstone_wire replace
fill ~378 ~155 ~886 ~378 ~155 ~898 minecraft:redstone_wire replace
fill ~381 ~155 ~886 ~381 ~155 ~898 minecraft:redstone_wire replace
fill ~384 ~155 ~886 ~384 ~155 ~898 minecraft:redstone_wire replace
fill ~387 ~155 ~886 ~387 ~155 ~898 minecraft:redstone_wire replace
fill ~390 ~155 ~886 ~390 ~155 ~898 minecraft:redstone_wire replace
fill ~393 ~155 ~886 ~393 ~155 ~898 minecraft:redstone_wire replace
fill ~396 ~155 ~886 ~396 ~155 ~898 minecraft:redstone_wire replace
fill ~399 ~155 ~886 ~399 ~155 ~898 minecraft:redstone_wire replace
setblock ~426 ~155 ~886 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~888 ~426 ~155 ~900 minecraft:redstone_wire replace
setblock ~429 ~155 ~894 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~894 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~354 ~155 ~896 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~896 ~429 ~155 ~908 minecraft:redstone_wire replace
fill ~432 ~155 ~896 ~432 ~155 ~908 minecraft:redstone_wire replace
setblock ~357 ~155 ~899 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~357 ~155 ~900 minecraft:redstone_wire replace
setblock ~360 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~363 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~372 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~900 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~360 ~155 ~902 ~360 ~155 ~904 minecraft:redstone_wire replace
fill ~363 ~155 ~902 ~363 ~155 ~908 minecraft:redstone_wire replace
fill ~366 ~155 ~902 ~366 ~155 ~910 minecraft:redstone_wire replace
fill ~369 ~155 ~902 ~369 ~155 ~914 minecraft:redstone_wire replace
fill ~372 ~155 ~902 ~372 ~155 ~914 minecraft:redstone_wire replace
fill ~375 ~155 ~902 ~375 ~155 ~914 minecraft:redstone_wire replace
fill ~378 ~155 ~902 ~378 ~155 ~914 minecraft:redstone_wire replace
fill ~381 ~155 ~902 ~381 ~155 ~914 minecraft:redstone_wire replace
fill ~384 ~155 ~902 ~384 ~155 ~914 minecraft:redstone_wire replace
fill ~387 ~155 ~902 ~387 ~155 ~914 minecraft:redstone_wire replace
fill ~390 ~155 ~902 ~390 ~155 ~914 minecraft:redstone_wire replace
fill ~393 ~155 ~902 ~393 ~155 ~914 minecraft:redstone_wire replace
fill ~396 ~155 ~902 ~396 ~155 ~914 minecraft:redstone_wire replace
fill ~399 ~155 ~902 ~399 ~155 ~914 minecraft:redstone_wire replace
setblock ~426 ~155 ~902 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~904 ~426 ~155 ~916 minecraft:redstone_wire replace
setblock ~429 ~155 ~910 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~910 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~366 ~155 ~912 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~912 ~429 ~155 ~924 minecraft:redstone_wire replace
fill ~432 ~155 ~912 ~432 ~155 ~924 minecraft:redstone_wire replace
setblock ~369 ~155 ~915 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~369 ~155 ~916 minecraft:redstone_wire replace
setblock ~372 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~375 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~384 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~916 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~155 ~918 ~372 ~155 ~920 minecraft:redstone_wire replace
fill ~375 ~155 ~918 ~375 ~155 ~924 minecraft:redstone_wire replace
fill ~378 ~155 ~918 ~378 ~155 ~926 minecraft:redstone_wire replace
fill ~381 ~155 ~918 ~381 ~155 ~930 minecraft:redstone_wire replace
fill ~384 ~155 ~918 ~384 ~155 ~930 minecraft:redstone_wire replace
fill ~387 ~155 ~918 ~387 ~155 ~930 minecraft:redstone_wire replace
fill ~390 ~155 ~918 ~390 ~155 ~930 minecraft:redstone_wire replace
fill ~393 ~155 ~918 ~393 ~155 ~930 minecraft:redstone_wire replace
fill ~396 ~155 ~918 ~396 ~155 ~930 minecraft:redstone_wire replace
fill ~399 ~155 ~918 ~399 ~155 ~930 minecraft:redstone_wire replace
setblock ~426 ~155 ~918 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~920 ~426 ~155 ~932 minecraft:redstone_wire replace
setblock ~429 ~155 ~926 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~926 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~378 ~155 ~928 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~928 ~429 ~155 ~940 minecraft:redstone_wire replace
fill ~432 ~155 ~928 ~432 ~155 ~940 minecraft:redstone_wire replace
setblock ~381 ~155 ~931 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~381 ~155 ~932 minecraft:redstone_wire replace
setblock ~384 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~387 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~396 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~932 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~384 ~155 ~934 ~384 ~155 ~936 minecraft:redstone_wire replace
fill ~387 ~155 ~934 ~387 ~155 ~940 minecraft:redstone_wire replace
fill ~390 ~155 ~934 ~390 ~155 ~942 minecraft:redstone_wire replace
fill ~393 ~155 ~934 ~393 ~155 ~946 minecraft:redstone_wire replace
fill ~396 ~155 ~934 ~396 ~155 ~946 minecraft:redstone_wire replace
fill ~399 ~155 ~934 ~399 ~155 ~946 minecraft:redstone_wire replace
setblock ~426 ~155 ~934 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~936 ~426 ~155 ~948 minecraft:redstone_wire replace
setblock ~429 ~155 ~942 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~942 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~390 ~155 ~944 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~944 ~429 ~155 ~956 minecraft:redstone_wire replace
fill ~432 ~155 ~944 ~432 ~155 ~956 minecraft:redstone_wire replace
setblock ~393 ~155 ~947 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~393 ~155 ~948 minecraft:redstone_wire replace
setblock ~396 ~155 ~948 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~399 ~155 ~948 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~155 ~950 ~396 ~155 ~952 minecraft:redstone_wire replace
fill ~399 ~155 ~950 ~399 ~155 ~956 minecraft:redstone_wire replace
setblock ~426 ~155 ~950 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~426 ~155 ~952 ~426 ~155 ~962 minecraft:redstone_wire replace
setblock ~429 ~155 ~958 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~432 ~155 ~958 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~429 ~155 ~960 ~429 ~155 ~966 minecraft:redstone_wire replace
setblock ~432 ~155 ~960 minecraft:redstone_wire replace
setblock ~426 ~155 ~964 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~429 ~155 ~968 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~105 ~156 ~233 minecraft:redstone_wire replace
setblock ~81 ~156 ~237 minecraft:redstone_wire replace
setblock ~102 ~156 ~265 minecraft:redstone_wire replace
setblock ~99 ~156 ~289 minecraft:redstone_wire replace
setblock ~96 ~156 ~305 minecraft:redstone_wire replace
setblock ~93 ~156 ~333 minecraft:redstone_wire replace
setblock ~90 ~156 ~369 minecraft:redstone_wire replace
setblock ~87 ~156 ~401 minecraft:redstone_wire replace
setblock ~84 ~156 ~433 minecraft:redstone_wire replace
setblock ~78 ~156 ~449 minecraft:redstone_wire replace
setblock ~108 ~156 ~537 minecraft:redstone_wire replace
setblock ~111 ~156 ~541 minecraft:redstone_wire replace
setblock ~114 ~156 ~545 minecraft:redstone_wire replace
setblock ~117 ~156 ~549 minecraft:redstone_wire replace
setblock ~120 ~156 ~553 minecraft:redstone_wire replace
setblock ~123 ~156 ~557 minecraft:redstone_wire replace
setblock ~126 ~156 ~561 minecraft:redstone_wire replace
setblock ~129 ~156 ~565 minecraft:redstone_wire replace
setblock ~132 ~156 ~569 minecraft:redstone_wire replace
setblock ~135 ~156 ~573 minecraft:redstone_wire replace
setblock ~138 ~156 ~577 minecraft:redstone_wire replace
setblock ~141 ~156 ~581 minecraft:redstone_wire replace
setblock ~144 ~156 ~585 minecraft:redstone_wire replace
setblock ~147 ~156 ~589 minecraft:redstone_wire replace
setblock ~150 ~156 ~593 minecraft:redstone_wire replace
setblock ~153 ~156 ~597 minecraft:redstone_wire replace
setblock ~156 ~156 ~601 minecraft:redstone_wire replace
setblock ~159 ~156 ~605 minecraft:redstone_wire replace
setblock ~162 ~156 ~609 minecraft:redstone_wire replace
setblock ~165 ~156 ~613 minecraft:redstone_wire replace
setblock ~168 ~156 ~617 minecraft:redstone_wire replace
setblock ~171 ~156 ~621 minecraft:redstone_wire replace
setblock ~174 ~156 ~625 minecraft:redstone_wire replace
setblock ~177 ~156 ~629 minecraft:redstone_wire replace
setblock ~180 ~156 ~633 minecraft:redstone_wire replace
setblock ~183 ~156 ~637 minecraft:redstone_wire replace
setblock ~186 ~156 ~641 minecraft:redstone_wire replace
setblock ~189 ~156 ~645 minecraft:redstone_wire replace
setblock ~192 ~156 ~649 minecraft:redstone_wire replace
setblock ~195 ~156 ~653 minecraft:redstone_wire replace
setblock ~198 ~156 ~657 minecraft:redstone_wire replace
setblock ~201 ~156 ~661 minecraft:redstone_wire replace
setblock ~204 ~156 ~665 minecraft:redstone_wire replace
setblock ~207 ~156 ~669 minecraft:redstone_wire replace
setblock ~210 ~156 ~673 minecraft:redstone_wire replace
setblock ~213 ~156 ~677 minecraft:redstone_wire replace
setblock ~216 ~156 ~681 minecraft:redstone_wire replace
setblock ~219 ~156 ~685 minecraft:redstone_wire replace
setblock ~222 ~156 ~689 minecraft:redstone_wire replace
setblock ~225 ~156 ~693 minecraft:redstone_wire replace
setblock ~228 ~156 ~697 minecraft:redstone_wire replace
setblock ~231 ~156 ~701 minecraft:redstone_wire replace
setblock ~234 ~156 ~705 minecraft:redstone_wire replace
setblock ~237 ~156 ~709 minecraft:redstone_wire replace
setblock ~240 ~156 ~713 minecraft:redstone_wire replace
setblock ~243 ~156 ~717 minecraft:redstone_wire replace
setblock ~246 ~156 ~721 minecraft:redstone_wire replace
setblock ~249 ~156 ~725 minecraft:redstone_wire replace
setblock ~252 ~156 ~729 minecraft:redstone_wire replace
setblock ~402 ~156 ~733 minecraft:redstone_wire replace
setblock ~405 ~156 ~737 minecraft:redstone_wire replace
setblock ~408 ~156 ~741 minecraft:redstone_wire replace
setblock ~411 ~156 ~745 minecraft:redstone_wire replace
setblock ~414 ~156 ~749 minecraft:redstone_wire replace
setblock ~417 ~156 ~753 minecraft:redstone_wire replace
setblock ~420 ~156 ~757 minecraft:redstone_wire replace
setblock ~423 ~156 ~761 minecraft:redstone_wire replace
setblock ~255 ~156 ~765 minecraft:redstone_wire replace
setblock ~258 ~156 ~769 minecraft:redstone_wire replace
setblock ~261 ~156 ~773 minecraft:redstone_wire replace
setblock ~264 ~156 ~777 minecraft:redstone_wire replace
setblock ~267 ~156 ~781 minecraft:redstone_wire replace
setblock ~270 ~156 ~785 minecraft:redstone_wire replace
setblock ~273 ~156 ~789 minecraft:redstone_wire replace
setblock ~276 ~156 ~793 minecraft:redstone_wire replace
setblock ~279 ~156 ~797 minecraft:redstone_wire replace
setblock ~282 ~156 ~801 minecraft:redstone_wire replace
setblock ~285 ~156 ~805 minecraft:redstone_wire replace
setblock ~288 ~156 ~809 minecraft:redstone_wire replace
setblock ~291 ~156 ~813 minecraft:redstone_wire replace
setblock ~294 ~156 ~817 minecraft:redstone_wire replace
setblock ~297 ~156 ~821 minecraft:redstone_wire replace
setblock ~300 ~156 ~825 minecraft:redstone_wire replace
setblock ~303 ~156 ~829 minecraft:redstone_wire replace
setblock ~306 ~156 ~833 minecraft:redstone_wire replace
setblock ~309 ~156 ~837 minecraft:redstone_wire replace
setblock ~312 ~156 ~841 minecraft:redstone_wire replace
setblock ~315 ~156 ~845 minecraft:redstone_wire replace
setblock ~318 ~156 ~849 minecraft:redstone_wire replace
setblock ~321 ~156 ~853 minecraft:redstone_wire replace
setblock ~324 ~156 ~857 minecraft:redstone_wire replace
setblock ~327 ~156 ~861 minecraft:redstone_wire replace
setblock ~330 ~156 ~865 minecraft:redstone_wire replace
setblock ~333 ~156 ~869 minecraft:redstone_wire replace
setblock ~336 ~156 ~873 minecraft:redstone_wire replace
setblock ~339 ~156 ~877 minecraft:redstone_wire replace
setblock ~342 ~156 ~881 minecraft:redstone_wire replace
setblock ~345 ~156 ~885 minecraft:redstone_wire replace
setblock ~348 ~156 ~889 minecraft:redstone_wire replace
setblock ~351 ~156 ~893 minecraft:redstone_wire replace
setblock ~354 ~156 ~897 minecraft:redstone_wire replace
setblock ~357 ~156 ~901 minecraft:redstone_wire replace
setblock ~360 ~156 ~905 minecraft:redstone_wire replace
setblock ~363 ~156 ~909 minecraft:redstone_wire replace
setblock ~366 ~156 ~913 minecraft:redstone_wire replace
setblock ~369 ~156 ~917 minecraft:redstone_wire replace
setblock ~372 ~156 ~921 minecraft:redstone_wire replace
setblock ~375 ~156 ~925 minecraft:redstone_wire replace
setblock ~378 ~156 ~929 minecraft:redstone_wire replace
setblock ~381 ~156 ~933 minecraft:redstone_wire replace
setblock ~384 ~156 ~937 minecraft:redstone_wire replace
setblock ~387 ~156 ~941 minecraft:redstone_wire replace
setblock ~390 ~156 ~945 minecraft:redstone_wire replace
setblock ~393 ~156 ~949 minecraft:redstone_wire replace
setblock ~396 ~156 ~953 minecraft:redstone_wire replace
setblock ~399 ~156 ~957 minecraft:redstone_wire replace
setblock ~432 ~156 ~961 minecraft:redstone_wire replace
setblock ~426 ~156 ~965 minecraft:redstone_wire replace
setblock ~429 ~156 ~969 minecraft:redstone_wire replace
fill ~105 ~157 ~234 ~107 ~157 ~234 minecraft:redstone_wire replace
setblock ~106 ~157 ~235 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~157 ~238 ~83 ~157 ~238 minecraft:redstone_wire replace
setblock ~82 ~157 ~239 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~157 ~266 ~104 ~157 ~266 minecraft:redstone_wire replace
setblock ~103 ~157 ~267 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~157 ~290 ~101 ~157 ~290 minecraft:redstone_wire replace
setblock ~100 ~157 ~291 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~157 ~306 ~98 ~157 ~306 minecraft:redstone_wire replace
setblock ~97 ~157 ~307 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~157 ~334 ~95 ~157 ~334 minecraft:redstone_wire replace
setblock ~94 ~157 ~335 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~157 ~370 ~92 ~157 ~370 minecraft:redstone_wire replace
setblock ~91 ~157 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~157 ~402 ~89 ~157 ~402 minecraft:redstone_wire replace
setblock ~88 ~157 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~157 ~434 ~86 ~157 ~434 minecraft:redstone_wire replace
setblock ~85 ~157 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~157 ~450 ~80 ~157 ~450 minecraft:redstone_wire replace
setblock ~79 ~157 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~157 ~538 ~110 ~157 ~538 minecraft:redstone_wire replace
setblock ~109 ~157 ~539 minecraft:redstone_wire replace
fill ~108 ~157 ~542 ~111 ~157 ~542 minecraft:redstone_wire replace
setblock ~109 ~157 ~543 minecraft:redstone_wire replace
fill ~108 ~157 ~546 ~114 ~157 ~546 minecraft:redstone_wire replace
setblock ~109 ~157 ~547 minecraft:redstone_wire replace
fill ~108 ~157 ~550 ~117 ~157 ~550 minecraft:redstone_wire replace
setblock ~109 ~157 ~551 minecraft:redstone_wire replace
fill ~108 ~157 ~554 ~109 ~157 ~554 minecraft:redstone_wire replace
setblock ~110 ~157 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~157 ~554 ~120 ~157 ~554 minecraft:redstone_wire replace
setblock ~109 ~157 ~555 minecraft:redstone_wire replace
fill ~108 ~157 ~558 ~114 ~157 ~558 minecraft:redstone_wire replace
setblock ~116 ~157 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~558 ~123 ~157 ~558 minecraft:redstone_wire replace
setblock ~109 ~157 ~559 minecraft:redstone_wire replace
fill ~108 ~157 ~562 ~110 ~157 ~562 minecraft:redstone_wire replace
setblock ~112 ~157 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~157 ~562 ~126 ~157 ~562 minecraft:redstone_wire replace
setblock ~109 ~157 ~563 minecraft:redstone_wire replace
fill ~108 ~157 ~566 ~114 ~157 ~566 minecraft:redstone_wire replace
setblock ~116 ~157 ~566 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~566 ~129 ~157 ~566 minecraft:redstone_wire replace
setblock ~109 ~157 ~567 minecraft:redstone_wire replace
fill ~111 ~157 ~570 ~119 ~157 ~570 minecraft:redstone_wire replace
setblock ~121 ~157 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~157 ~570 ~132 ~157 ~570 minecraft:redstone_wire replace
setblock ~112 ~157 ~571 minecraft:redstone_wire replace
fill ~111 ~157 ~574 ~113 ~157 ~574 minecraft:redstone_wire replace
setblock ~114 ~157 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~574 ~127 ~157 ~574 minecraft:redstone_wire replace
setblock ~129 ~157 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~157 ~574 ~135 ~157 ~574 minecraft:redstone_wire replace
setblock ~112 ~157 ~575 minecraft:redstone_wire replace
fill ~111 ~157 ~578 ~122 ~157 ~578 minecraft:redstone_wire replace
setblock ~124 ~157 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~157 ~578 ~138 ~157 ~578 minecraft:redstone_wire replace
setblock ~112 ~157 ~579 minecraft:redstone_wire replace
fill ~111 ~157 ~582 ~113 ~157 ~582 minecraft:redstone_wire replace
setblock ~114 ~157 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~582 ~127 ~157 ~582 minecraft:redstone_wire replace
setblock ~129 ~157 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~157 ~582 ~141 ~157 ~582 minecraft:redstone_wire replace
setblock ~112 ~157 ~583 minecraft:redstone_wire replace
fill ~111 ~157 ~586 ~114 ~157 ~586 minecraft:redstone_wire replace
setblock ~116 ~157 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~586 ~131 ~157 ~586 minecraft:redstone_wire replace
setblock ~133 ~157 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~157 ~586 ~144 ~157 ~586 minecraft:redstone_wire replace
setblock ~112 ~157 ~587 minecraft:redstone_wire replace
fill ~111 ~157 ~590 ~121 ~157 ~590 minecraft:redstone_wire replace
setblock ~123 ~157 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~157 ~590 ~138 ~157 ~590 minecraft:redstone_wire replace
setblock ~140 ~157 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~590 ~147 ~157 ~590 minecraft:redstone_wire replace
setblock ~112 ~157 ~591 minecraft:redstone_wire replace
fill ~111 ~157 ~594 ~117 ~157 ~594 minecraft:redstone_wire replace
setblock ~119 ~157 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~157 ~594 ~134 ~157 ~594 minecraft:redstone_wire replace
setblock ~136 ~157 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~157 ~594 ~150 ~157 ~594 minecraft:redstone_wire replace
setblock ~112 ~157 ~595 minecraft:redstone_wire replace
fill ~111 ~157 ~598 ~121 ~157 ~598 minecraft:redstone_wire replace
setblock ~123 ~157 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~157 ~598 ~138 ~157 ~598 minecraft:redstone_wire replace
setblock ~140 ~157 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~598 ~153 ~157 ~598 minecraft:redstone_wire replace
setblock ~112 ~157 ~599 minecraft:redstone_wire replace
fill ~114 ~157 ~602 ~126 ~157 ~602 minecraft:redstone_wire replace
setblock ~128 ~157 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~157 ~602 ~143 ~157 ~602 minecraft:redstone_wire replace
setblock ~145 ~157 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~602 ~156 ~157 ~602 minecraft:redstone_wire replace
setblock ~115 ~157 ~603 minecraft:redstone_wire replace
fill ~114 ~157 ~606 ~116 ~157 ~606 minecraft:redstone_wire replace
setblock ~118 ~157 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~157 ~606 ~133 ~157 ~606 minecraft:redstone_wire replace
setblock ~135 ~157 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~606 ~150 ~157 ~606 minecraft:redstone_wire replace
setblock ~152 ~157 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~606 ~159 ~157 ~606 minecraft:redstone_wire replace
setblock ~115 ~157 ~607 minecraft:redstone_wire replace
fill ~114 ~157 ~610 ~115 ~157 ~610 minecraft:redstone_wire replace
setblock ~117 ~157 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~157 ~610 ~131 ~157 ~610 minecraft:redstone_wire replace
setblock ~133 ~157 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~157 ~610 ~147 ~157 ~610 minecraft:redstone_wire replace
setblock ~149 ~157 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~610 ~162 ~157 ~610 minecraft:redstone_wire replace
setblock ~115 ~157 ~611 minecraft:redstone_wire replace
fill ~114 ~157 ~614 ~116 ~157 ~614 minecraft:redstone_wire replace
setblock ~118 ~157 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~157 ~614 ~133 ~157 ~614 minecraft:redstone_wire replace
setblock ~135 ~157 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~614 ~150 ~157 ~614 minecraft:redstone_wire replace
setblock ~152 ~157 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~614 ~165 ~157 ~614 minecraft:redstone_wire replace
setblock ~115 ~157 ~615 minecraft:redstone_wire replace
fill ~114 ~157 ~618 ~121 ~157 ~618 minecraft:redstone_wire replace
setblock ~123 ~157 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~157 ~618 ~138 ~157 ~618 minecraft:redstone_wire replace
setblock ~140 ~157 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~157 ~618 ~155 ~157 ~618 minecraft:redstone_wire replace
setblock ~157 ~157 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~618 ~168 ~157 ~618 minecraft:redstone_wire replace
setblock ~115 ~157 ~619 minecraft:redstone_wire replace
setblock ~114 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~622 ~128 ~157 ~622 minecraft:redstone_wire replace
setblock ~130 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~622 ~145 ~157 ~622 minecraft:redstone_wire replace
setblock ~147 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~622 ~162 ~157 ~622 minecraft:redstone_wire replace
setblock ~164 ~157 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~622 ~171 ~157 ~622 minecraft:redstone_wire replace
setblock ~115 ~157 ~623 minecraft:redstone_wire replace
fill ~114 ~157 ~626 ~124 ~157 ~626 minecraft:redstone_wire replace
setblock ~126 ~157 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~157 ~626 ~141 ~157 ~626 minecraft:redstone_wire replace
setblock ~143 ~157 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~157 ~626 ~158 ~157 ~626 minecraft:redstone_wire replace
setblock ~160 ~157 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~157 ~626 ~174 ~157 ~626 minecraft:redstone_wire replace
setblock ~115 ~157 ~627 minecraft:redstone_wire replace
setblock ~114 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~115 ~157 ~630 ~128 ~157 ~630 minecraft:redstone_wire replace
setblock ~130 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~630 ~145 ~157 ~630 minecraft:redstone_wire replace
setblock ~147 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~630 ~162 ~157 ~630 minecraft:redstone_wire replace
setblock ~164 ~157 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~630 ~177 ~157 ~630 minecraft:redstone_wire replace
setblock ~115 ~157 ~631 minecraft:redstone_wire replace
fill ~114 ~157 ~634 ~116 ~157 ~634 minecraft:redstone_wire replace
setblock ~118 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~157 ~634 ~133 ~157 ~634 minecraft:redstone_wire replace
setblock ~135 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~634 ~150 ~157 ~634 minecraft:redstone_wire replace
setblock ~152 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~634 ~167 ~157 ~634 minecraft:redstone_wire replace
setblock ~169 ~157 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~634 ~180 ~157 ~634 minecraft:redstone_wire replace
setblock ~115 ~157 ~635 minecraft:redstone_wire replace
fill ~117 ~157 ~638 ~123 ~157 ~638 minecraft:redstone_wire replace
setblock ~125 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~157 ~638 ~140 ~157 ~638 minecraft:redstone_wire replace
setblock ~142 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~638 ~157 ~157 ~638 minecraft:redstone_wire replace
setblock ~159 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~638 ~174 ~157 ~638 minecraft:redstone_wire replace
setblock ~176 ~157 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~638 ~183 ~157 ~638 minecraft:redstone_wire replace
setblock ~118 ~157 ~639 minecraft:redstone_wire replace
fill ~117 ~157 ~642 ~119 ~157 ~642 minecraft:redstone_wire replace
setblock ~121 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~157 ~642 ~136 ~157 ~642 minecraft:redstone_wire replace
setblock ~138 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~157 ~642 ~153 ~157 ~642 minecraft:redstone_wire replace
setblock ~155 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~157 ~642 ~170 ~157 ~642 minecraft:redstone_wire replace
setblock ~172 ~157 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~157 ~642 ~186 ~157 ~642 minecraft:redstone_wire replace
setblock ~118 ~157 ~643 minecraft:redstone_wire replace
fill ~117 ~157 ~646 ~123 ~157 ~646 minecraft:redstone_wire replace
setblock ~125 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~157 ~646 ~140 ~157 ~646 minecraft:redstone_wire replace
setblock ~142 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~646 ~157 ~157 ~646 minecraft:redstone_wire replace
setblock ~159 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~646 ~174 ~157 ~646 minecraft:redstone_wire replace
setblock ~176 ~157 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~646 ~189 ~157 ~646 minecraft:redstone_wire replace
setblock ~118 ~157 ~647 minecraft:redstone_wire replace
fill ~117 ~157 ~650 ~128 ~157 ~650 minecraft:redstone_wire replace
setblock ~130 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~650 ~145 ~157 ~650 minecraft:redstone_wire replace
setblock ~147 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~650 ~162 ~157 ~650 minecraft:redstone_wire replace
setblock ~164 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~650 ~179 ~157 ~650 minecraft:redstone_wire replace
setblock ~181 ~157 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~650 ~192 ~157 ~650 minecraft:redstone_wire replace
setblock ~118 ~157 ~651 minecraft:redstone_wire replace
fill ~117 ~157 ~654 ~118 ~157 ~654 minecraft:redstone_wire replace
setblock ~120 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~157 ~654 ~135 ~157 ~654 minecraft:redstone_wire replace
setblock ~137 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~654 ~152 ~157 ~654 minecraft:redstone_wire replace
setblock ~154 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~654 ~169 ~157 ~654 minecraft:redstone_wire replace
setblock ~171 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~654 ~186 ~157 ~654 minecraft:redstone_wire replace
setblock ~188 ~157 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~654 ~195 ~157 ~654 minecraft:redstone_wire replace
setblock ~118 ~157 ~655 minecraft:redstone_wire replace
setblock ~117 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~658 ~131 ~157 ~658 minecraft:redstone_wire replace
setblock ~133 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~157 ~658 ~148 ~157 ~658 minecraft:redstone_wire replace
setblock ~150 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~658 ~165 ~157 ~658 minecraft:redstone_wire replace
setblock ~167 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~658 ~182 ~157 ~658 minecraft:redstone_wire replace
setblock ~184 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~658 ~198 ~157 ~658 minecraft:redstone_wire replace
setblock ~118 ~157 ~659 minecraft:redstone_wire replace
fill ~117 ~157 ~662 ~118 ~157 ~662 minecraft:redstone_wire replace
setblock ~120 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~157 ~662 ~135 ~157 ~662 minecraft:redstone_wire replace
setblock ~137 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~662 ~152 ~157 ~662 minecraft:redstone_wire replace
setblock ~154 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~662 ~169 ~157 ~662 minecraft:redstone_wire replace
setblock ~171 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~662 ~186 ~157 ~662 minecraft:redstone_wire replace
setblock ~188 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~662 ~201 ~157 ~662 minecraft:redstone_wire replace
setblock ~118 ~157 ~663 minecraft:redstone_wire replace
fill ~120 ~157 ~666 ~123 ~157 ~666 minecraft:redstone_wire replace
setblock ~125 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~157 ~666 ~140 ~157 ~666 minecraft:redstone_wire replace
setblock ~142 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~666 ~157 ~157 ~666 minecraft:redstone_wire replace
setblock ~159 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~666 ~174 ~157 ~666 minecraft:redstone_wire replace
setblock ~176 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~666 ~191 ~157 ~666 minecraft:redstone_wire replace
setblock ~193 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~666 ~204 ~157 ~666 minecraft:redstone_wire replace
setblock ~121 ~157 ~667 minecraft:redstone_wire replace
fill ~120 ~157 ~670 ~130 ~157 ~670 minecraft:redstone_wire replace
setblock ~132 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~157 ~670 ~147 ~157 ~670 minecraft:redstone_wire replace
setblock ~149 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~670 ~164 ~157 ~670 minecraft:redstone_wire replace
setblock ~166 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~670 ~181 ~157 ~670 minecraft:redstone_wire replace
setblock ~183 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~157 ~670 ~198 ~157 ~670 minecraft:redstone_wire replace
setblock ~200 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~670 ~207 ~157 ~670 minecraft:redstone_wire replace
setblock ~121 ~157 ~671 minecraft:redstone_wire replace
fill ~120 ~157 ~674 ~126 ~157 ~674 minecraft:redstone_wire replace
setblock ~128 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~157 ~674 ~143 ~157 ~674 minecraft:redstone_wire replace
setblock ~145 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~674 ~160 ~157 ~674 minecraft:redstone_wire replace
setblock ~162 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~674 ~177 ~157 ~674 minecraft:redstone_wire replace
setblock ~179 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~674 ~194 ~157 ~674 minecraft:redstone_wire replace
setblock ~196 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~674 ~210 ~157 ~674 minecraft:redstone_wire replace
setblock ~121 ~157 ~675 minecraft:redstone_wire replace
fill ~120 ~157 ~678 ~130 ~157 ~678 minecraft:redstone_wire replace
setblock ~132 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~157 ~678 ~147 ~157 ~678 minecraft:redstone_wire replace
setblock ~149 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~678 ~164 ~157 ~678 minecraft:redstone_wire replace
setblock ~166 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~678 ~181 ~157 ~678 minecraft:redstone_wire replace
setblock ~183 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~157 ~678 ~198 ~157 ~678 minecraft:redstone_wire replace
setblock ~200 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~678 ~213 ~157 ~678 minecraft:redstone_wire replace
setblock ~121 ~157 ~679 minecraft:redstone_wire replace
fill ~123 ~157 ~682 ~135 ~157 ~682 minecraft:redstone_wire replace
setblock ~137 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~682 ~152 ~157 ~682 minecraft:redstone_wire replace
setblock ~154 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~682 ~169 ~157 ~682 minecraft:redstone_wire replace
setblock ~171 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~682 ~186 ~157 ~682 minecraft:redstone_wire replace
setblock ~188 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~682 ~203 ~157 ~682 minecraft:redstone_wire replace
setblock ~205 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~682 ~216 ~157 ~682 minecraft:redstone_wire replace
setblock ~124 ~157 ~683 minecraft:redstone_wire replace
fill ~123 ~157 ~686 ~125 ~157 ~686 minecraft:redstone_wire replace
setblock ~127 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~157 ~686 ~142 ~157 ~686 minecraft:redstone_wire replace
setblock ~144 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~686 ~159 ~157 ~686 minecraft:redstone_wire replace
setblock ~161 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~686 ~176 ~157 ~686 minecraft:redstone_wire replace
setblock ~178 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~686 ~193 ~157 ~686 minecraft:redstone_wire replace
setblock ~195 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~686 ~210 ~157 ~686 minecraft:redstone_wire replace
setblock ~212 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~686 ~219 ~157 ~686 minecraft:redstone_wire replace
setblock ~124 ~157 ~687 minecraft:redstone_wire replace
fill ~123 ~157 ~690 ~127 ~157 ~690 minecraft:redstone_wire replace
setblock ~129 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~157 ~690 ~143 ~157 ~690 minecraft:redstone_wire replace
setblock ~145 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~690 ~159 ~157 ~690 minecraft:redstone_wire replace
setblock ~161 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~690 ~175 ~157 ~690 minecraft:redstone_wire replace
setblock ~177 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~690 ~191 ~157 ~690 minecraft:redstone_wire replace
setblock ~193 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~690 ~207 ~157 ~690 minecraft:redstone_wire replace
setblock ~209 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~690 ~222 ~157 ~690 minecraft:redstone_wire replace
setblock ~124 ~157 ~691 minecraft:redstone_wire replace
fill ~123 ~157 ~694 ~125 ~157 ~694 minecraft:redstone_wire replace
setblock ~127 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~157 ~694 ~142 ~157 ~694 minecraft:redstone_wire replace
setblock ~144 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~694 ~159 ~157 ~694 minecraft:redstone_wire replace
setblock ~161 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~694 ~176 ~157 ~694 minecraft:redstone_wire replace
setblock ~178 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~694 ~193 ~157 ~694 minecraft:redstone_wire replace
setblock ~195 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~694 ~210 ~157 ~694 minecraft:redstone_wire replace
setblock ~212 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~694 ~225 ~157 ~694 minecraft:redstone_wire replace
setblock ~124 ~157 ~695 minecraft:redstone_wire replace
fill ~123 ~157 ~698 ~130 ~157 ~698 minecraft:redstone_wire replace
setblock ~132 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~157 ~698 ~147 ~157 ~698 minecraft:redstone_wire replace
setblock ~149 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~698 ~164 ~157 ~698 minecraft:redstone_wire replace
setblock ~166 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~698 ~181 ~157 ~698 minecraft:redstone_wire replace
setblock ~183 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~157 ~698 ~198 ~157 ~698 minecraft:redstone_wire replace
setblock ~200 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~698 ~215 ~157 ~698 minecraft:redstone_wire replace
setblock ~217 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~157 ~698 ~228 ~157 ~698 minecraft:redstone_wire replace
setblock ~124 ~157 ~699 minecraft:redstone_wire replace
setblock ~123 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~157 ~702 ~137 ~157 ~702 minecraft:redstone_wire replace
setblock ~139 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~702 ~154 ~157 ~702 minecraft:redstone_wire replace
setblock ~156 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~702 ~171 ~157 ~702 minecraft:redstone_wire replace
setblock ~173 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~702 ~188 ~157 ~702 minecraft:redstone_wire replace
setblock ~190 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~702 ~205 ~157 ~702 minecraft:redstone_wire replace
setblock ~207 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~702 ~222 ~157 ~702 minecraft:redstone_wire replace
setblock ~224 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~702 ~231 ~157 ~702 minecraft:redstone_wire replace
setblock ~124 ~157 ~703 minecraft:redstone_wire replace
fill ~126 ~157 ~706 ~133 ~157 ~706 minecraft:redstone_wire replace
setblock ~135 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~706 ~150 ~157 ~706 minecraft:redstone_wire replace
setblock ~152 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~706 ~167 ~157 ~706 minecraft:redstone_wire replace
setblock ~169 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~706 ~184 ~157 ~706 minecraft:redstone_wire replace
setblock ~186 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~706 ~201 ~157 ~706 minecraft:redstone_wire replace
setblock ~203 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~706 ~218 ~157 ~706 minecraft:redstone_wire replace
setblock ~220 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~706 ~234 ~157 ~706 minecraft:redstone_wire replace
setblock ~127 ~157 ~707 minecraft:redstone_wire replace
fill ~126 ~157 ~710 ~137 ~157 ~710 minecraft:redstone_wire replace
setblock ~139 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~710 ~154 ~157 ~710 minecraft:redstone_wire replace
setblock ~156 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~710 ~171 ~157 ~710 minecraft:redstone_wire replace
setblock ~173 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~710 ~188 ~157 ~710 minecraft:redstone_wire replace
setblock ~190 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~710 ~205 ~157 ~710 minecraft:redstone_wire replace
setblock ~207 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~710 ~222 ~157 ~710 minecraft:redstone_wire replace
setblock ~224 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~710 ~237 ~157 ~710 minecraft:redstone_wire replace
setblock ~127 ~157 ~711 minecraft:redstone_wire replace
fill ~126 ~157 ~714 ~127 ~157 ~714 minecraft:redstone_wire replace
setblock ~128 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~157 ~714 ~142 ~157 ~714 minecraft:redstone_wire replace
setblock ~144 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~714 ~159 ~157 ~714 minecraft:redstone_wire replace
setblock ~161 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~714 ~176 ~157 ~714 minecraft:redstone_wire replace
setblock ~178 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~714 ~193 ~157 ~714 minecraft:redstone_wire replace
setblock ~195 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~714 ~210 ~157 ~714 minecraft:redstone_wire replace
setblock ~212 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~714 ~227 ~157 ~714 minecraft:redstone_wire replace
setblock ~229 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~157 ~714 ~240 ~157 ~714 minecraft:redstone_wire replace
setblock ~127 ~157 ~715 minecraft:redstone_wire replace
fill ~126 ~157 ~718 ~132 ~157 ~718 minecraft:redstone_wire replace
setblock ~134 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~718 ~149 ~157 ~718 minecraft:redstone_wire replace
setblock ~151 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~718 ~166 ~157 ~718 minecraft:redstone_wire replace
setblock ~168 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~718 ~183 ~157 ~718 minecraft:redstone_wire replace
setblock ~185 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~718 ~200 ~157 ~718 minecraft:redstone_wire replace
setblock ~202 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~718 ~217 ~157 ~718 minecraft:redstone_wire replace
setblock ~219 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~718 ~234 ~157 ~718 minecraft:redstone_wire replace
setblock ~236 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~718 ~243 ~157 ~718 minecraft:redstone_wire replace
setblock ~127 ~157 ~719 minecraft:redstone_wire replace
fill ~126 ~157 ~722 ~128 ~157 ~722 minecraft:redstone_wire replace
setblock ~130 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~722 ~145 ~157 ~722 minecraft:redstone_wire replace
setblock ~147 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~722 ~162 ~157 ~722 minecraft:redstone_wire replace
setblock ~164 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~722 ~179 ~157 ~722 minecraft:redstone_wire replace
setblock ~181 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~722 ~196 ~157 ~722 minecraft:redstone_wire replace
setblock ~198 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~722 ~213 ~157 ~722 minecraft:redstone_wire replace
setblock ~215 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~722 ~230 ~157 ~722 minecraft:redstone_wire replace
setblock ~232 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~722 ~246 ~157 ~722 minecraft:redstone_wire replace
setblock ~127 ~157 ~723 minecraft:redstone_wire replace
fill ~126 ~157 ~726 ~132 ~157 ~726 minecraft:redstone_wire replace
setblock ~134 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~726 ~149 ~157 ~726 minecraft:redstone_wire replace
setblock ~151 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~726 ~166 ~157 ~726 minecraft:redstone_wire replace
setblock ~168 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~726 ~183 ~157 ~726 minecraft:redstone_wire replace
setblock ~185 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~726 ~200 ~157 ~726 minecraft:redstone_wire replace
setblock ~202 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~726 ~217 ~157 ~726 minecraft:redstone_wire replace
setblock ~219 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~726 ~234 ~157 ~726 minecraft:redstone_wire replace
setblock ~236 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~726 ~249 ~157 ~726 minecraft:redstone_wire replace
setblock ~127 ~157 ~727 minecraft:redstone_wire replace
fill ~126 ~157 ~730 ~137 ~157 ~730 minecraft:redstone_wire replace
setblock ~139 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~730 ~154 ~157 ~730 minecraft:redstone_wire replace
setblock ~156 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~730 ~171 ~157 ~730 minecraft:redstone_wire replace
setblock ~173 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~730 ~188 ~157 ~730 minecraft:redstone_wire replace
setblock ~190 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~730 ~205 ~157 ~730 minecraft:redstone_wire replace
setblock ~207 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~730 ~222 ~157 ~730 minecraft:redstone_wire replace
setblock ~224 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~730 ~239 ~157 ~730 minecraft:redstone_wire replace
setblock ~241 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~157 ~730 ~252 ~157 ~730 minecraft:redstone_wire replace
setblock ~127 ~157 ~731 minecraft:redstone_wire replace
setblock ~150 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~734 ~163 ~157 ~734 minecraft:redstone_wire replace
setblock ~165 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~734 ~179 ~157 ~734 minecraft:redstone_wire replace
setblock ~181 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~734 ~195 ~157 ~734 minecraft:redstone_wire replace
setblock ~197 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~157 ~734 ~211 ~157 ~734 minecraft:redstone_wire replace
setblock ~213 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~734 ~227 ~157 ~734 minecraft:redstone_wire replace
setblock ~229 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~157 ~734 ~243 ~157 ~734 minecraft:redstone_wire replace
setblock ~245 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~734 ~259 ~157 ~734 minecraft:redstone_wire replace
setblock ~261 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~734 ~275 ~157 ~734 minecraft:redstone_wire replace
setblock ~277 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~157 ~734 ~291 ~157 ~734 minecraft:redstone_wire replace
setblock ~293 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~734 ~307 ~157 ~734 minecraft:redstone_wire replace
setblock ~309 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~311 ~157 ~734 ~323 ~157 ~734 minecraft:redstone_wire replace
setblock ~325 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~157 ~734 ~339 ~157 ~734 minecraft:redstone_wire replace
setblock ~341 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~157 ~734 ~355 ~157 ~734 minecraft:redstone_wire replace
setblock ~357 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~359 ~157 ~734 ~371 ~157 ~734 minecraft:redstone_wire replace
setblock ~373 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~157 ~734 ~387 ~157 ~734 minecraft:redstone_wire replace
setblock ~389 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~391 ~157 ~734 ~402 ~157 ~734 minecraft:redstone_wire replace
setblock ~151 ~157 ~735 minecraft:redstone_wire replace
setblock ~153 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~738 ~166 ~157 ~738 minecraft:redstone_wire replace
setblock ~168 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~738 ~182 ~157 ~738 minecraft:redstone_wire replace
setblock ~184 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~738 ~198 ~157 ~738 minecraft:redstone_wire replace
setblock ~200 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~738 ~214 ~157 ~738 minecraft:redstone_wire replace
setblock ~216 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~738 ~230 ~157 ~738 minecraft:redstone_wire replace
setblock ~232 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~738 ~246 ~157 ~738 minecraft:redstone_wire replace
setblock ~248 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~157 ~738 ~262 ~157 ~738 minecraft:redstone_wire replace
setblock ~264 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~738 ~278 ~157 ~738 minecraft:redstone_wire replace
setblock ~280 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~157 ~738 ~294 ~157 ~738 minecraft:redstone_wire replace
setblock ~296 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~738 ~310 ~157 ~738 minecraft:redstone_wire replace
setblock ~312 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~738 ~326 ~157 ~738 minecraft:redstone_wire replace
setblock ~328 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~157 ~738 ~342 ~157 ~738 minecraft:redstone_wire replace
setblock ~344 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~738 ~358 ~157 ~738 minecraft:redstone_wire replace
setblock ~360 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~362 ~157 ~738 ~374 ~157 ~738 minecraft:redstone_wire replace
setblock ~376 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~378 ~157 ~738 ~390 ~157 ~738 minecraft:redstone_wire replace
setblock ~392 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~394 ~157 ~738 ~405 ~157 ~738 minecraft:redstone_wire replace
setblock ~154 ~157 ~739 minecraft:redstone_wire replace
fill ~153 ~157 ~742 ~155 ~157 ~742 minecraft:redstone_wire replace
setblock ~157 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~742 ~172 ~157 ~742 minecraft:redstone_wire replace
setblock ~174 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~742 ~189 ~157 ~742 minecraft:redstone_wire replace
setblock ~191 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~742 ~206 ~157 ~742 minecraft:redstone_wire replace
setblock ~208 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~742 ~223 ~157 ~742 minecraft:redstone_wire replace
setblock ~225 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~742 ~240 ~157 ~742 minecraft:redstone_wire replace
setblock ~242 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~742 ~257 ~157 ~742 minecraft:redstone_wire replace
setblock ~259 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~742 ~274 ~157 ~742 minecraft:redstone_wire replace
setblock ~276 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~742 ~291 ~157 ~742 minecraft:redstone_wire replace
setblock ~293 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~742 ~308 ~157 ~742 minecraft:redstone_wire replace
setblock ~310 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~742 ~325 ~157 ~742 minecraft:redstone_wire replace
setblock ~327 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~742 ~342 ~157 ~742 minecraft:redstone_wire replace
setblock ~344 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~742 ~359 ~157 ~742 minecraft:redstone_wire replace
setblock ~361 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~157 ~742 ~376 ~157 ~742 minecraft:redstone_wire replace
setblock ~378 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~380 ~157 ~742 ~393 ~157 ~742 minecraft:redstone_wire replace
setblock ~395 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~397 ~157 ~742 ~408 ~157 ~742 minecraft:redstone_wire replace
setblock ~154 ~157 ~743 minecraft:redstone_wire replace
fill ~156 ~157 ~746 ~162 ~157 ~746 minecraft:redstone_wire replace
setblock ~164 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~746 ~179 ~157 ~746 minecraft:redstone_wire replace
setblock ~181 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~746 ~196 ~157 ~746 minecraft:redstone_wire replace
setblock ~198 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~746 ~213 ~157 ~746 minecraft:redstone_wire replace
setblock ~215 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~746 ~230 ~157 ~746 minecraft:redstone_wire replace
setblock ~232 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~746 ~247 ~157 ~746 minecraft:redstone_wire replace
setblock ~249 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~746 ~264 ~157 ~746 minecraft:redstone_wire replace
setblock ~266 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~746 ~281 ~157 ~746 minecraft:redstone_wire replace
setblock ~283 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~157 ~746 ~298 ~157 ~746 minecraft:redstone_wire replace
setblock ~300 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~157 ~746 ~315 ~157 ~746 minecraft:redstone_wire replace
setblock ~317 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~157 ~746 ~332 ~157 ~746 minecraft:redstone_wire replace
setblock ~334 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~157 ~746 ~349 ~157 ~746 minecraft:redstone_wire replace
setblock ~351 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~353 ~157 ~746 ~366 ~157 ~746 minecraft:redstone_wire replace
setblock ~368 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~157 ~746 ~383 ~157 ~746 minecraft:redstone_wire replace
setblock ~385 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~387 ~157 ~746 ~400 ~157 ~746 minecraft:redstone_wire replace
setblock ~402 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~404 ~157 ~746 ~411 ~157 ~746 minecraft:redstone_wire replace
setblock ~157 ~157 ~747 minecraft:redstone_wire replace
fill ~156 ~157 ~750 ~160 ~157 ~750 minecraft:redstone_wire replace
setblock ~162 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~750 ~177 ~157 ~750 minecraft:redstone_wire replace
setblock ~179 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~750 ~194 ~157 ~750 minecraft:redstone_wire replace
setblock ~196 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~750 ~211 ~157 ~750 minecraft:redstone_wire replace
setblock ~213 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
