setblock ~117 ~105 ~618 minecraft:light_gray_concrete replace
setblock ~115 ~105 ~620 minecraft:light_gray_concrete replace
setblock ~123 ~105 ~622 minecraft:light_gray_concrete replace
setblock ~125 ~105 ~622 minecraft:light_gray_concrete replace
setblock ~118 ~105 ~628 minecraft:light_gray_concrete replace
setblock ~129 ~105 ~630 minecraft:light_gray_concrete replace
setblock ~131 ~105 ~630 minecraft:light_gray_concrete replace
setblock ~127 ~105 ~640 minecraft:light_gray_concrete replace
setblock ~138 ~105 ~642 minecraft:light_gray_concrete replace
setblock ~140 ~105 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~105 ~644 minecraft:light_gray_concrete replace
setblock ~121 ~105 ~648 minecraft:light_gray_concrete replace
setblock ~132 ~105 ~650 minecraft:light_gray_concrete replace
setblock ~134 ~105 ~650 minecraft:light_gray_concrete replace
setblock ~124 ~105 ~656 minecraft:light_gray_concrete replace
setblock ~135 ~105 ~658 minecraft:light_gray_concrete replace
setblock ~137 ~105 ~658 minecraft:light_gray_concrete replace
fill ~111 ~106 ~380 ~111 ~106 ~384 minecraft:light_gray_concrete replace
fill ~81 ~106 ~392 ~81 ~106 ~396 minecraft:light_gray_concrete replace
fill ~87 ~106 ~552 ~87 ~106 ~556 minecraft:light_gray_concrete replace
fill ~78 ~106 ~556 ~78 ~106 ~560 minecraft:light_gray_concrete replace
fill ~90 ~106 ~560 ~90 ~106 ~564 minecraft:light_gray_concrete replace
fill ~93 ~106 ~564 ~93 ~106 ~568 minecraft:light_gray_concrete replace
fill ~96 ~106 ~568 ~96 ~106 ~572 minecraft:light_gray_concrete replace
fill ~99 ~106 ~572 ~99 ~106 ~576 minecraft:light_gray_concrete replace
fill ~114 ~106 ~576 ~114 ~106 ~624 minecraft:light_gray_concrete replace
fill ~108 ~106 ~580 ~108 ~106 ~620 minecraft:light_gray_concrete replace
fill ~105 ~106 ~588 ~105 ~106 ~600 minecraft:light_gray_concrete replace
fill ~102 ~106 ~600 ~102 ~106 ~608 minecraft:light_gray_concrete replace
fill ~117 ~106 ~628 ~117 ~106 ~632 minecraft:light_gray_concrete replace
fill ~126 ~106 ~640 ~126 ~106 ~644 minecraft:light_gray_concrete replace
fill ~84 ~106 ~644 ~84 ~106 ~648 minecraft:light_gray_concrete replace
fill ~120 ~106 ~648 ~120 ~106 ~652 minecraft:light_gray_concrete replace
fill ~123 ~106 ~656 ~123 ~106 ~660 minecraft:light_gray_concrete replace
setblock ~111 ~107 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~107 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~107 ~557 minecraft:light_gray_concrete replace
setblock ~78 ~107 ~561 minecraft:light_gray_concrete replace
setblock ~90 ~107 ~565 minecraft:light_gray_concrete replace
setblock ~93 ~107 ~569 minecraft:light_gray_concrete replace
setblock ~96 ~107 ~573 minecraft:light_gray_concrete replace
setblock ~115 ~107 ~576 minecraft:light_gray_concrete replace
setblock ~99 ~107 ~577 minecraft:light_gray_concrete replace
setblock ~109 ~107 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~107 ~584 minecraft:light_gray_concrete replace
setblock ~106 ~107 ~588 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~589 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~591 minecraft:light_gray_concrete replace
setblock ~106 ~107 ~592 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~593 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~595 minecraft:light_gray_concrete replace
setblock ~106 ~107 ~596 minecraft:light_gray_concrete replace
setblock ~105 ~107 ~599 minecraft:light_gray_concrete replace
setblock ~103 ~107 ~600 minecraft:light_gray_concrete replace
setblock ~105 ~107 ~601 minecraft:light_gray_concrete replace
setblock ~103 ~107 ~604 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~605 minecraft:light_gray_concrete replace
setblock ~102 ~107 ~607 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~607 minecraft:light_gray_concrete replace
setblock ~102 ~107 ~609 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~609 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~611 minecraft:light_gray_concrete replace
setblock ~115 ~107 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~107 ~616 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~619 minecraft:light_gray_concrete replace
setblock ~115 ~107 ~620 minecraft:light_gray_concrete replace
setblock ~108 ~107 ~621 minecraft:light_gray_concrete replace
setblock ~114 ~107 ~625 minecraft:light_gray_concrete replace
setblock ~118 ~107 ~628 minecraft:light_gray_concrete replace
setblock ~117 ~107 ~633 minecraft:light_gray_concrete replace
setblock ~126 ~107 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~107 ~649 minecraft:light_gray_concrete replace
setblock ~120 ~107 ~653 minecraft:light_gray_concrete replace
setblock ~123 ~107 ~661 minecraft:light_gray_concrete replace
fill ~111 ~108 ~386 ~125 ~108 ~386 minecraft:light_gray_concrete replace
fill ~124 ~108 ~387 ~124 ~108 ~388 minecraft:light_gray_concrete replace
fill ~81 ~108 ~398 ~83 ~108 ~398 minecraft:light_gray_concrete replace
fill ~82 ~108 ~399 ~82 ~108 ~400 minecraft:light_gray_concrete replace
fill ~87 ~108 ~558 ~89 ~108 ~558 minecraft:light_gray_concrete replace
fill ~88 ~108 ~559 ~88 ~108 ~560 minecraft:light_gray_concrete replace
fill ~78 ~108 ~562 ~80 ~108 ~562 minecraft:light_gray_concrete replace
fill ~79 ~108 ~563 ~79 ~108 ~564 minecraft:light_gray_concrete replace
fill ~90 ~108 ~566 ~92 ~108 ~566 minecraft:light_gray_concrete replace
fill ~91 ~108 ~567 ~91 ~108 ~568 minecraft:light_gray_concrete replace
fill ~93 ~108 ~570 ~95 ~108 ~570 minecraft:light_gray_concrete replace
fill ~94 ~108 ~571 ~94 ~108 ~572 minecraft:light_gray_concrete replace
fill ~96 ~108 ~574 ~98 ~108 ~574 minecraft:light_gray_concrete replace
fill ~97 ~108 ~575 ~97 ~108 ~576 minecraft:light_gray_concrete replace
fill ~99 ~108 ~578 ~128 ~108 ~578 minecraft:light_gray_concrete replace
fill ~100 ~108 ~579 ~100 ~108 ~580 minecraft:light_gray_concrete replace
fill ~103 ~108 ~579 ~103 ~108 ~580 minecraft:light_gray_concrete replace
fill ~106 ~108 ~579 ~106 ~108 ~580 minecraft:light_gray_concrete replace
fill ~109 ~108 ~579 ~109 ~108 ~580 minecraft:light_gray_concrete replace
fill ~112 ~108 ~579 ~112 ~108 ~580 minecraft:light_gray_concrete replace
fill ~115 ~108 ~579 ~115 ~108 ~580 minecraft:light_gray_concrete replace
fill ~118 ~108 ~579 ~118 ~108 ~580 minecraft:light_gray_concrete replace
fill ~127 ~108 ~579 ~127 ~108 ~580 minecraft:light_gray_concrete replace
fill ~99 ~108 ~602 ~134 ~108 ~602 minecraft:light_gray_concrete replace
fill ~100 ~108 ~603 ~100 ~108 ~604 minecraft:light_gray_concrete replace
fill ~106 ~108 ~603 ~106 ~108 ~604 minecraft:light_gray_concrete replace
fill ~109 ~108 ~603 ~109 ~108 ~604 minecraft:light_gray_concrete replace
fill ~112 ~108 ~603 ~112 ~108 ~604 minecraft:light_gray_concrete replace
fill ~118 ~108 ~603 ~118 ~108 ~604 minecraft:light_gray_concrete replace
fill ~121 ~108 ~603 ~121 ~108 ~604 minecraft:light_gray_concrete replace
fill ~133 ~108 ~603 ~133 ~108 ~604 minecraft:light_gray_concrete replace
fill ~99 ~108 ~610 ~131 ~108 ~610 minecraft:light_gray_concrete replace
fill ~100 ~108 ~611 ~100 ~108 ~612 minecraft:light_gray_concrete replace
fill ~103 ~108 ~611 ~103 ~108 ~612 minecraft:light_gray_concrete replace
fill ~109 ~108 ~611 ~109 ~108 ~612 minecraft:light_gray_concrete replace
fill ~115 ~108 ~611 ~115 ~108 ~612 minecraft:light_gray_concrete replace
fill ~121 ~108 ~611 ~121 ~108 ~612 minecraft:light_gray_concrete replace
fill ~130 ~108 ~611 ~130 ~108 ~612 minecraft:light_gray_concrete replace
fill ~102 ~108 ~622 ~134 ~108 ~622 minecraft:light_gray_concrete replace
fill ~103 ~108 ~623 ~103 ~108 ~624 minecraft:light_gray_concrete replace
fill ~106 ~108 ~623 ~106 ~108 ~624 minecraft:light_gray_concrete replace
fill ~112 ~108 ~623 ~112 ~108 ~624 minecraft:light_gray_concrete replace
fill ~118 ~108 ~623 ~118 ~108 ~624 minecraft:light_gray_concrete replace
fill ~121 ~108 ~623 ~121 ~108 ~624 minecraft:light_gray_concrete replace
fill ~127 ~108 ~623 ~127 ~108 ~624 minecraft:light_gray_concrete replace
fill ~133 ~108 ~623 ~133 ~108 ~624 minecraft:light_gray_concrete replace
fill ~114 ~108 ~626 ~137 ~108 ~626 minecraft:light_gray_concrete replace
fill ~136 ~108 ~627 ~136 ~108 ~628 minecraft:light_gray_concrete replace
fill ~117 ~108 ~634 ~140 ~108 ~634 minecraft:light_gray_concrete replace
fill ~139 ~108 ~635 ~139 ~108 ~636 minecraft:light_gray_concrete replace
fill ~126 ~108 ~646 ~149 ~108 ~646 minecraft:light_gray_concrete replace
fill ~148 ~108 ~647 ~148 ~108 ~648 minecraft:light_gray_concrete replace
fill ~84 ~108 ~650 ~86 ~108 ~650 minecraft:light_gray_concrete replace
fill ~85 ~108 ~651 ~85 ~108 ~652 minecraft:light_gray_concrete replace
fill ~120 ~108 ~654 ~143 ~108 ~654 minecraft:light_gray_concrete replace
fill ~142 ~108 ~655 ~142 ~108 ~656 minecraft:light_gray_concrete replace
fill ~123 ~108 ~662 ~146 ~108 ~662 minecraft:light_gray_concrete replace
fill ~145 ~108 ~663 ~145 ~108 ~664 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~386 minecraft:light_gray_concrete replace
setblock ~120 ~109 ~386 minecraft:light_gray_concrete replace
setblock ~124 ~109 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~109 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~109 ~560 minecraft:light_gray_concrete replace
setblock ~79 ~109 ~564 minecraft:light_gray_concrete replace
setblock ~91 ~109 ~568 minecraft:light_gray_concrete replace
setblock ~94 ~109 ~572 minecraft:light_gray_concrete replace
setblock ~97 ~109 ~576 minecraft:light_gray_concrete replace
setblock ~100 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~103 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~106 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~112 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~115 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~109 ~580 minecraft:light_gray_concrete replace
setblock ~100 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~106 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~109 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~112 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~133 ~109 ~604 minecraft:light_gray_concrete replace
setblock ~100 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~103 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~109 ~612 minecraft:light_gray_concrete replace
setblock ~103 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~106 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~112 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~118 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~121 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~127 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~133 ~109 ~624 minecraft:light_gray_concrete replace
setblock ~124 ~109 ~626 minecraft:light_gray_concrete replace
setblock ~126 ~109 ~626 minecraft:light_gray_concrete replace
setblock ~136 ~109 ~628 minecraft:light_gray_concrete replace
setblock ~124 ~109 ~634 minecraft:light_gray_concrete replace
setblock ~126 ~109 ~634 minecraft:light_gray_concrete replace
setblock ~139 ~109 ~636 minecraft:light_gray_concrete replace
setblock ~133 ~109 ~646 minecraft:light_gray_concrete replace
setblock ~135 ~109 ~646 minecraft:light_gray_concrete replace
setblock ~148 ~109 ~648 minecraft:light_gray_concrete replace
setblock ~85 ~109 ~652 minecraft:light_gray_concrete replace
setblock ~127 ~109 ~654 minecraft:light_gray_concrete replace
setblock ~129 ~109 ~654 minecraft:light_gray_concrete replace
setblock ~142 ~109 ~656 minecraft:light_gray_concrete replace
setblock ~130 ~109 ~662 minecraft:light_gray_concrete replace
setblock ~132 ~109 ~662 minecraft:light_gray_concrete replace
setblock ~145 ~109 ~664 minecraft:light_gray_concrete replace
fill ~123 ~110 ~384 ~123 ~110 ~388 minecraft:light_gray_concrete replace
fill ~81 ~110 ~396 ~81 ~110 ~400 minecraft:light_gray_concrete replace
fill ~87 ~110 ~528 ~87 ~110 ~560 minecraft:light_gray_concrete replace
fill ~78 ~110 ~532 ~78 ~110 ~564 minecraft:light_gray_concrete replace
fill ~90 ~110 ~536 ~90 ~110 ~568 minecraft:light_gray_concrete replace
fill ~93 ~110 ~540 ~93 ~110 ~572 minecraft:light_gray_concrete replace
fill ~96 ~110 ~544 ~96 ~110 ~576 minecraft:light_gray_concrete replace
fill ~126 ~110 ~548 ~126 ~110 ~624 minecraft:light_gray_concrete replace
fill ~117 ~110 ~552 ~117 ~110 ~624 minecraft:light_gray_concrete replace
fill ~114 ~110 ~556 ~114 ~110 ~612 minecraft:light_gray_concrete replace
fill ~111 ~110 ~560 ~111 ~110 ~624 minecraft:light_gray_concrete replace
fill ~108 ~110 ~564 ~108 ~110 ~612 minecraft:light_gray_concrete replace
fill ~105 ~110 ~568 ~105 ~110 ~624 minecraft:light_gray_concrete replace
fill ~102 ~110 ~572 ~102 ~110 ~624 minecraft:light_gray_concrete replace
fill ~99 ~110 ~576 ~99 ~110 ~612 minecraft:light_gray_concrete replace
fill ~132 ~110 ~596 ~132 ~110 ~624 minecraft:light_gray_concrete replace
fill ~120 ~110 ~600 ~120 ~110 ~624 minecraft:light_gray_concrete replace
fill ~129 ~110 ~608 ~129 ~110 ~612 minecraft:light_gray_concrete replace
fill ~135 ~110 ~624 ~135 ~110 ~628 minecraft:light_gray_concrete replace
fill ~138 ~110 ~632 ~138 ~110 ~636 minecraft:light_gray_concrete replace
fill ~147 ~110 ~644 ~147 ~110 ~648 minecraft:light_gray_concrete replace
fill ~84 ~110 ~648 ~84 ~110 ~652 minecraft:light_gray_concrete replace
fill ~141 ~110 ~652 ~141 ~110 ~656 minecraft:light_gray_concrete replace
fill ~144 ~110 ~660 ~144 ~110 ~664 minecraft:light_gray_concrete replace
setblock ~123 ~111 ~383 minecraft:light_gray_concrete replace
setblock ~81 ~111 ~395 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~527 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~529 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~531 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~531 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~533 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~535 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~535 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~537 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~539 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~539 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~541 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~543 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~543 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~545 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~545 minecraft:light_gray_concrete replace
setblock ~87 ~111 ~547 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~547 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~547 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~549 minecraft:light_gray_concrete replace
setblock ~78 ~111 ~551 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~551 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~553 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~553 minecraft:light_gray_concrete replace
setblock ~90 ~111 ~555 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~555 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~557 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~557 minecraft:light_gray_concrete replace
setblock ~93 ~111 ~559 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~559 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~561 minecraft:light_gray_concrete replace
setblock ~96 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~563 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~565 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~567 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~567 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~567 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~569 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~573 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~575 minecraft:light_gray_concrete replace
setblock ~103 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~109 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~111 ~580 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~581 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~581 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~581 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~583 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~583 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~583 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~593 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~595 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~102 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~597 minecraft:light_gray_concrete replace
setblock ~99 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~108 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~114 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~120 ~111 ~599 minecraft:light_gray_concrete replace
setblock ~120 ~111 ~601 minecraft:light_gray_concrete replace
setblock ~106 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~133 ~111 ~604 minecraft:light_gray_concrete replace
setblock ~129 ~111 ~607 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~609 minecraft:light_gray_concrete replace
setblock ~105 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~111 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~117 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~126 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~132 ~111 ~611 minecraft:light_gray_concrete replace
setblock ~100 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~109 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~115 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~130 ~111 ~612 minecraft:light_gray_concrete replace
setblock ~135 ~111 ~623 minecraft:light_gray_concrete replace
setblock ~106 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~112 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~118 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~127 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~133 ~111 ~624 minecraft:light_gray_concrete replace
setblock ~136 ~111 ~628 minecraft:light_gray_concrete replace
setblock ~138 ~111 ~631 minecraft:light_gray_concrete replace
setblock ~139 ~111 ~636 minecraft:light_gray_concrete replace
setblock ~147 ~111 ~643 minecraft:light_gray_concrete replace
setblock ~84 ~111 ~647 minecraft:light_gray_concrete replace
setblock ~141 ~111 ~651 minecraft:light_gray_concrete replace
setblock ~144 ~111 ~659 minecraft:light_gray_concrete replace
fill ~109 ~112 ~380 ~109 ~112 ~381 minecraft:light_gray_concrete replace
fill ~108 ~112 ~382 ~123 ~112 ~382 minecraft:light_gray_concrete replace
fill ~82 ~112 ~392 ~82 ~112 ~393 minecraft:light_gray_concrete replace
fill ~81 ~112 ~394 ~83 ~112 ~394 minecraft:light_gray_concrete replace
fill ~88 ~112 ~524 ~88 ~112 ~525 minecraft:light_gray_concrete replace
fill ~87 ~112 ~526 ~89 ~112 ~526 minecraft:light_gray_concrete replace
fill ~79 ~112 ~528 ~79 ~112 ~529 minecraft:light_gray_concrete replace
fill ~78 ~112 ~530 ~80 ~112 ~530 minecraft:light_gray_concrete replace
fill ~91 ~112 ~532 ~91 ~112 ~533 minecraft:light_gray_concrete replace
fill ~90 ~112 ~534 ~92 ~112 ~534 minecraft:light_gray_concrete replace
fill ~94 ~112 ~536 ~94 ~112 ~537 minecraft:light_gray_concrete replace
fill ~93 ~112 ~538 ~95 ~112 ~538 minecraft:light_gray_concrete replace
fill ~97 ~112 ~540 ~97 ~112 ~541 minecraft:light_gray_concrete replace
fill ~96 ~112 ~542 ~98 ~112 ~542 minecraft:light_gray_concrete replace
fill ~112 ~112 ~544 ~112 ~112 ~545 minecraft:light_gray_concrete replace
fill ~111 ~112 ~546 ~126 ~112 ~546 minecraft:light_gray_concrete replace
fill ~106 ~112 ~548 ~106 ~112 ~549 minecraft:light_gray_concrete replace
fill ~105 ~112 ~550 ~117 ~112 ~550 minecraft:light_gray_concrete replace
fill ~106 ~112 ~552 ~106 ~112 ~553 minecraft:light_gray_concrete replace
fill ~105 ~112 ~554 ~114 ~112 ~554 minecraft:light_gray_concrete replace
fill ~103 ~112 ~556 ~103 ~112 ~557 minecraft:light_gray_concrete replace
fill ~102 ~112 ~558 ~111 ~112 ~558 minecraft:light_gray_concrete replace
fill ~103 ~112 ~560 ~103 ~112 ~561 minecraft:light_gray_concrete replace
fill ~102 ~112 ~562 ~108 ~112 ~562 minecraft:light_gray_concrete replace
fill ~100 ~112 ~564 ~100 ~112 ~565 minecraft:light_gray_concrete replace
fill ~99 ~112 ~566 ~105 ~112 ~566 minecraft:light_gray_concrete replace
fill ~100 ~112 ~568 ~100 ~112 ~569 minecraft:light_gray_concrete replace
fill ~99 ~112 ~570 ~102 ~112 ~570 minecraft:light_gray_concrete replace
fill ~100 ~112 ~572 ~100 ~112 ~573 minecraft:light_gray_concrete replace
fill ~99 ~112 ~574 ~101 ~112 ~574 minecraft:light_gray_concrete replace
fill ~112 ~112 ~592 ~112 ~112 ~593 minecraft:light_gray_concrete replace
fill ~111 ~112 ~594 ~132 ~112 ~594 minecraft:light_gray_concrete replace
fill ~106 ~112 ~596 ~106 ~112 ~597 minecraft:light_gray_concrete replace
fill ~105 ~112 ~598 ~120 ~112 ~598 minecraft:light_gray_concrete replace
fill ~112 ~112 ~604 ~112 ~112 ~605 minecraft:light_gray_concrete replace
fill ~111 ~112 ~606 ~129 ~112 ~606 minecraft:light_gray_concrete replace
fill ~115 ~112 ~620 ~115 ~112 ~621 minecraft:light_gray_concrete replace
fill ~114 ~112 ~622 ~135 ~112 ~622 minecraft:light_gray_concrete replace
fill ~118 ~112 ~628 ~118 ~112 ~629 minecraft:light_gray_concrete replace
fill ~117 ~112 ~630 ~138 ~112 ~630 minecraft:light_gray_concrete replace
fill ~127 ~112 ~640 ~127 ~112 ~641 minecraft:light_gray_concrete replace
fill ~126 ~112 ~642 ~147 ~112 ~642 minecraft:light_gray_concrete replace
fill ~85 ~112 ~644 ~85 ~112 ~645 minecraft:light_gray_concrete replace
fill ~84 ~112 ~646 ~86 ~112 ~646 minecraft:light_gray_concrete replace
fill ~121 ~112 ~648 ~121 ~112 ~649 minecraft:light_gray_concrete replace
fill ~120 ~112 ~650 ~141 ~112 ~650 minecraft:light_gray_concrete replace
fill ~124 ~112 ~656 ~124 ~112 ~657 minecraft:light_gray_concrete replace
fill ~123 ~112 ~658 ~144 ~112 ~658 minecraft:light_gray_concrete replace
setblock ~109 ~113 ~380 minecraft:light_gray_concrete replace
setblock ~114 ~113 ~382 minecraft:light_gray_concrete replace
setblock ~116 ~113 ~382 minecraft:light_gray_concrete replace
setblock ~82 ~113 ~392 minecraft:light_gray_concrete replace
setblock ~88 ~113 ~524 minecraft:light_gray_concrete replace
setblock ~79 ~113 ~528 minecraft:light_gray_concrete replace
setblock ~91 ~113 ~532 minecraft:light_gray_concrete replace
setblock ~94 ~113 ~536 minecraft:light_gray_concrete replace
setblock ~97 ~113 ~540 minecraft:light_gray_concrete replace
setblock ~112 ~113 ~544 minecraft:light_gray_concrete replace
setblock ~106 ~113 ~548 minecraft:light_gray_concrete replace
setblock ~106 ~113 ~552 minecraft:light_gray_concrete replace
setblock ~103 ~113 ~556 minecraft:light_gray_concrete replace
setblock ~103 ~113 ~560 minecraft:light_gray_concrete replace
setblock ~100 ~113 ~564 minecraft:light_gray_concrete replace
setblock ~100 ~113 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~113 ~572 minecraft:light_gray_concrete replace
setblock ~112 ~113 ~592 minecraft:light_gray_concrete replace
setblock ~117 ~113 ~594 minecraft:light_gray_concrete replace
setblock ~119 ~113 ~594 minecraft:light_gray_concrete replace
setblock ~106 ~113 ~596 minecraft:light_gray_concrete replace
setblock ~112 ~113 ~604 minecraft:light_gray_concrete replace
setblock ~120 ~113 ~606 minecraft:light_gray_concrete replace
setblock ~122 ~113 ~606 minecraft:light_gray_concrete replace
setblock ~115 ~113 ~620 minecraft:light_gray_concrete replace
setblock ~126 ~113 ~622 minecraft:light_gray_concrete replace
setblock ~128 ~113 ~622 minecraft:light_gray_concrete replace
setblock ~118 ~113 ~628 minecraft:light_gray_concrete replace
setblock ~129 ~113 ~630 minecraft:light_gray_concrete replace
setblock ~131 ~113 ~630 minecraft:light_gray_concrete replace
setblock ~127 ~113 ~640 minecraft:light_gray_concrete replace
setblock ~138 ~113 ~642 minecraft:light_gray_concrete replace
setblock ~140 ~113 ~642 minecraft:light_gray_concrete replace
setblock ~85 ~113 ~644 minecraft:light_gray_concrete replace
setblock ~121 ~113 ~648 minecraft:light_gray_concrete replace
setblock ~132 ~113 ~650 minecraft:light_gray_concrete replace
setblock ~134 ~113 ~650 minecraft:light_gray_concrete replace
setblock ~124 ~113 ~656 minecraft:light_gray_concrete replace
setblock ~135 ~113 ~658 minecraft:light_gray_concrete replace
setblock ~137 ~113 ~658 minecraft:light_gray_concrete replace
fill ~108 ~114 ~380 ~108 ~114 ~384 minecraft:light_gray_concrete replace
fill ~81 ~114 ~392 ~81 ~114 ~396 minecraft:light_gray_concrete replace
fill ~87 ~114 ~524 ~87 ~114 ~528 minecraft:light_gray_concrete replace
fill ~78 ~114 ~528 ~78 ~114 ~532 minecraft:light_gray_concrete replace
fill ~90 ~114 ~532 ~90 ~114 ~536 minecraft:light_gray_concrete replace
fill ~93 ~114 ~536 ~93 ~114 ~540 minecraft:light_gray_concrete replace
fill ~96 ~114 ~540 ~96 ~114 ~544 minecraft:light_gray_concrete replace
fill ~111 ~114 ~544 ~111 ~114 ~608 minecraft:light_gray_concrete replace
fill ~105 ~114 ~548 ~105 ~114 ~600 minecraft:light_gray_concrete replace
fill ~102 ~114 ~556 ~102 ~114 ~564 minecraft:light_gray_concrete replace
fill ~99 ~114 ~564 ~99 ~114 ~576 minecraft:light_gray_concrete replace
fill ~114 ~114 ~620 ~114 ~114 ~624 minecraft:light_gray_concrete replace
fill ~117 ~114 ~628 ~117 ~114 ~632 minecraft:light_gray_concrete replace
fill ~126 ~114 ~640 ~126 ~114 ~644 minecraft:light_gray_concrete replace
fill ~84 ~114 ~644 ~84 ~114 ~648 minecraft:light_gray_concrete replace
fill ~120 ~114 ~648 ~120 ~114 ~652 minecraft:light_gray_concrete replace
fill ~123 ~114 ~656 ~123 ~114 ~660 minecraft:light_gray_concrete replace
setblock ~108 ~115 ~385 minecraft:light_gray_concrete replace
setblock ~81 ~115 ~397 minecraft:light_gray_concrete replace
setblock ~87 ~115 ~529 minecraft:light_gray_concrete replace
setblock ~78 ~115 ~533 minecraft:light_gray_concrete replace
setblock ~90 ~115 ~537 minecraft:light_gray_concrete replace
setblock ~93 ~115 ~541 minecraft:light_gray_concrete replace
setblock ~112 ~115 ~544 minecraft:light_gray_concrete replace
setblock ~96 ~115 ~545 minecraft:light_gray_concrete replace
setblock ~106 ~115 ~548 minecraft:light_gray_concrete replace
setblock ~106 ~115 ~552 minecraft:light_gray_concrete replace
setblock ~103 ~115 ~556 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~557 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~559 minecraft:light_gray_concrete replace
setblock ~103 ~115 ~560 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~561 minecraft:light_gray_concrete replace
setblock ~102 ~115 ~563 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~563 minecraft:light_gray_concrete replace
setblock ~100 ~115 ~564 minecraft:light_gray_concrete replace
setblock ~102 ~115 ~565 minecraft:light_gray_concrete replace
setblock ~100 ~115 ~568 minecraft:light_gray_concrete replace
setblock ~100 ~115 ~572 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~573 minecraft:light_gray_concrete replace
setblock ~99 ~115 ~575 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~575 minecraft:light_gray_concrete replace
setblock ~99 ~115 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~577 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~579 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~589 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~591 minecraft:light_gray_concrete replace
setblock ~112 ~115 ~592 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~593 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~595 minecraft:light_gray_concrete replace
setblock ~106 ~115 ~596 minecraft:light_gray_concrete replace
setblock ~105 ~115 ~601 minecraft:light_gray_concrete replace
setblock ~112 ~115 ~604 minecraft:light_gray_concrete replace
setblock ~111 ~115 ~609 minecraft:light_gray_concrete replace
setblock ~115 ~115 ~620 minecraft:light_gray_concrete replace
setblock ~114 ~115 ~625 minecraft:light_gray_concrete replace
setblock ~118 ~115 ~628 minecraft:light_gray_concrete replace
setblock ~117 ~115 ~633 minecraft:light_gray_concrete replace
setblock ~126 ~115 ~645 minecraft:light_gray_concrete replace
setblock ~84 ~115 ~649 minecraft:light_gray_concrete replace
setblock ~120 ~115 ~653 minecraft:light_gray_concrete replace
setblock ~123 ~115 ~661 minecraft:light_gray_concrete replace
fill ~108 ~116 ~386 ~122 ~116 ~386 minecraft:light_gray_concrete replace
fill ~121 ~116 ~387 ~121 ~116 ~388 minecraft:light_gray_concrete replace
fill ~81 ~116 ~398 ~83 ~116 ~398 minecraft:light_gray_concrete replace
fill ~82 ~116 ~399 ~82 ~116 ~400 minecraft:light_gray_concrete replace
fill ~87 ~116 ~530 ~89 ~116 ~530 minecraft:light_gray_concrete replace
fill ~88 ~116 ~531 ~88 ~116 ~532 minecraft:light_gray_concrete replace
fill ~78 ~116 ~534 ~80 ~116 ~534 minecraft:light_gray_concrete replace
fill ~79 ~116 ~535 ~79 ~116 ~536 minecraft:light_gray_concrete replace
fill ~90 ~116 ~538 ~92 ~116 ~538 minecraft:light_gray_concrete replace
fill ~91 ~116 ~539 ~91 ~116 ~540 minecraft:light_gray_concrete replace
fill ~93 ~116 ~542 ~95 ~116 ~542 minecraft:light_gray_concrete replace
fill ~94 ~116 ~543 ~94 ~116 ~544 minecraft:light_gray_concrete replace
fill ~96 ~116 ~546 ~125 ~116 ~546 minecraft:light_gray_concrete replace
fill ~97 ~116 ~547 ~97 ~116 ~548 minecraft:light_gray_concrete replace
fill ~100 ~116 ~547 ~100 ~116 ~548 minecraft:light_gray_concrete replace
fill ~103 ~116 ~547 ~103 ~116 ~548 minecraft:light_gray_concrete replace
fill ~106 ~116 ~547 ~106 ~116 ~548 minecraft:light_gray_concrete replace
fill ~109 ~116 ~547 ~109 ~116 ~548 minecraft:light_gray_concrete replace
fill ~112 ~116 ~547 ~112 ~116 ~548 minecraft:light_gray_concrete replace
fill ~115 ~116 ~547 ~115 ~116 ~548 minecraft:light_gray_concrete replace
fill ~124 ~116 ~547 ~124 ~116 ~548 minecraft:light_gray_concrete replace
fill ~96 ~116 ~566 ~131 ~116 ~566 minecraft:light_gray_concrete replace
fill ~97 ~116 ~567 ~97 ~116 ~568 minecraft:light_gray_concrete replace
fill ~103 ~116 ~567 ~103 ~116 ~568 minecraft:light_gray_concrete replace
fill ~109 ~116 ~567 ~109 ~116 ~568 minecraft:light_gray_concrete replace
fill ~112 ~116 ~567 ~112 ~116 ~568 minecraft:light_gray_concrete replace
fill ~118 ~116 ~567 ~118 ~116 ~568 minecraft:light_gray_concrete replace
fill ~130 ~116 ~567 ~130 ~116 ~568 minecraft:light_gray_concrete replace
fill ~96 ~116 ~578 ~128 ~116 ~578 minecraft:light_gray_concrete replace
fill ~97 ~116 ~579 ~97 ~116 ~580 minecraft:light_gray_concrete replace
fill ~100 ~116 ~579 ~100 ~116 ~580 minecraft:light_gray_concrete replace
fill ~103 ~116 ~579 ~103 ~116 ~580 minecraft:light_gray_concrete replace
fill ~106 ~116 ~579 ~106 ~116 ~580 minecraft:light_gray_concrete replace
fill ~115 ~116 ~579 ~115 ~116 ~580 minecraft:light_gray_concrete replace
fill ~118 ~116 ~579 ~118 ~116 ~580 minecraft:light_gray_concrete replace
fill ~127 ~116 ~579 ~127 ~116 ~580 minecraft:light_gray_concrete replace
fill ~99 ~116 ~602 ~128 ~116 ~602 minecraft:light_gray_concrete replace
fill ~100 ~116 ~603 ~100 ~116 ~604 minecraft:light_gray_concrete replace
fill ~106 ~116 ~603 ~106 ~116 ~604 minecraft:light_gray_concrete replace
fill ~109 ~116 ~603 ~109 ~116 ~604 minecraft:light_gray_concrete replace
fill ~115 ~116 ~603 ~115 ~116 ~604 minecraft:light_gray_concrete replace
fill ~118 ~116 ~603 ~118 ~116 ~604 minecraft:light_gray_concrete replace
fill ~124 ~116 ~603 ~124 ~116 ~604 minecraft:light_gray_concrete replace
fill ~127 ~116 ~603 ~127 ~116 ~604 minecraft:light_gray_concrete replace
fill ~111 ~116 ~610 ~149 ~116 ~610 minecraft:light_gray_concrete replace
fill ~133 ~116 ~611 ~133 ~116 ~612 minecraft:light_gray_concrete replace
fill ~136 ~116 ~611 ~136 ~116 ~612 minecraft:light_gray_concrete replace
fill ~139 ~116 ~611 ~139 ~116 ~612 minecraft:light_gray_concrete replace
fill ~142 ~116 ~611 ~142 ~116 ~612 minecraft:light_gray_concrete replace
fill ~148 ~116 ~611 ~148 ~116 ~612 minecraft:light_gray_concrete replace
fill ~114 ~116 ~626 ~152 ~116 ~626 minecraft:light_gray_concrete replace
fill ~133 ~116 ~627 ~133 ~116 ~628 minecraft:light_gray_concrete replace
fill ~139 ~116 ~627 ~139 ~116 ~628 minecraft:light_gray_concrete replace
fill ~142 ~116 ~627 ~142 ~116 ~628 minecraft:light_gray_concrete replace
fill ~145 ~116 ~627 ~145 ~116 ~628 minecraft:light_gray_concrete replace
fill ~151 ~116 ~627 ~151 ~116 ~628 minecraft:light_gray_concrete replace
fill ~117 ~116 ~634 ~152 ~116 ~634 minecraft:light_gray_concrete replace
fill ~133 ~116 ~635 ~133 ~116 ~636 minecraft:light_gray_concrete replace
fill ~136 ~116 ~635 ~136 ~116 ~636 minecraft:light_gray_concrete replace
fill ~139 ~116 ~635 ~139 ~116 ~636 minecraft:light_gray_concrete replace
fill ~142 ~116 ~635 ~142 ~116 ~636 minecraft:light_gray_concrete replace
fill ~145 ~116 ~635 ~145 ~116 ~636 minecraft:light_gray_concrete replace
fill ~148 ~116 ~635 ~148 ~116 ~636 minecraft:light_gray_concrete replace
fill ~151 ~116 ~635 ~151 ~116 ~636 minecraft:light_gray_concrete replace
fill ~126 ~116 ~646 ~161 ~116 ~646 minecraft:light_gray_concrete replace
fill ~160 ~116 ~647 ~160 ~116 ~648 minecraft:light_gray_concrete replace
fill ~84 ~116 ~650 ~86 ~116 ~650 minecraft:light_gray_concrete replace
fill ~85 ~116 ~651 ~85 ~116 ~652 minecraft:light_gray_concrete replace
fill ~120 ~116 ~654 ~155 ~116 ~654 minecraft:light_gray_concrete replace
fill ~154 ~116 ~655 ~154 ~116 ~656 minecraft:light_gray_concrete replace
fill ~123 ~116 ~662 ~158 ~116 ~662 minecraft:light_gray_concrete replace
fill ~157 ~116 ~663 ~157 ~116 ~664 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~386 minecraft:light_gray_concrete replace
setblock ~117 ~117 ~386 minecraft:light_gray_concrete replace
setblock ~121 ~117 ~388 minecraft:light_gray_concrete replace
setblock ~82 ~117 ~400 minecraft:light_gray_concrete replace
setblock ~88 ~117 ~532 minecraft:light_gray_concrete replace
setblock ~79 ~117 ~536 minecraft:light_gray_concrete replace
setblock ~91 ~117 ~540 minecraft:light_gray_concrete replace
setblock ~94 ~117 ~544 minecraft:light_gray_concrete replace
setblock ~97 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~100 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~103 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~106 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~109 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~124 ~117 ~548 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~566 minecraft:light_gray_concrete replace
setblock ~117 ~117 ~566 minecraft:light_gray_concrete replace
setblock ~97 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~103 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~109 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~118 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~130 ~117 ~568 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~578 minecraft:light_gray_concrete replace
setblock ~114 ~117 ~578 minecraft:light_gray_concrete replace
setblock ~97 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~100 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~103 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~106 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~118 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~127 ~117 ~580 minecraft:light_gray_concrete replace
setblock ~112 ~117 ~602 minecraft:light_gray_concrete replace
setblock ~114 ~117 ~602 minecraft:light_gray_concrete replace
setblock ~100 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~106 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~109 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~115 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~118 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~124 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~127 ~117 ~604 minecraft:light_gray_concrete replace
setblock ~121 ~117 ~610 minecraft:light_gray_concrete replace
setblock ~123 ~117 ~610 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~136 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~139 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~142 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~148 ~117 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~117 ~626 minecraft:light_gray_concrete replace
setblock ~123 ~117 ~626 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~139 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~142 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~145 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~151 ~117 ~628 minecraft:light_gray_concrete replace
setblock ~124 ~117 ~634 minecraft:light_gray_concrete replace
setblock ~126 ~117 ~634 minecraft:light_gray_concrete replace
setblock ~133 ~117 ~636 minecraft:light_gray_concrete replace
