setblock ~117 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~157 ~658 ~131 ~157 ~658 minecraft:redstone_wire replace
setblock ~133 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~157 ~658 ~148 ~157 ~658 minecraft:redstone_wire replace
setblock ~150 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~157 ~658 ~165 ~157 ~658 minecraft:redstone_wire replace
setblock ~167 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~157 ~658 ~182 ~157 ~658 minecraft:redstone_wire replace
setblock ~184 ~157 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~658 ~198 ~157 ~658 minecraft:redstone_wire replace
setblock ~118 ~157 ~659 minecraft:redstone_wire replace
fill ~117 ~157 ~662 ~118 ~157 ~662 minecraft:redstone_wire replace
setblock ~120 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~157 ~662 ~135 ~157 ~662 minecraft:redstone_wire replace
setblock ~137 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~662 ~152 ~157 ~662 minecraft:redstone_wire replace
setblock ~154 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~662 ~169 ~157 ~662 minecraft:redstone_wire replace
setblock ~171 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~662 ~186 ~157 ~662 minecraft:redstone_wire replace
setblock ~188 ~157 ~662 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~662 ~201 ~157 ~662 minecraft:redstone_wire replace
setblock ~118 ~157 ~663 minecraft:redstone_wire replace
fill ~120 ~157 ~666 ~123 ~157 ~666 minecraft:redstone_wire replace
setblock ~125 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~157 ~666 ~140 ~157 ~666 minecraft:redstone_wire replace
setblock ~142 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~666 ~157 ~157 ~666 minecraft:redstone_wire replace
setblock ~159 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~666 ~174 ~157 ~666 minecraft:redstone_wire replace
setblock ~176 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~666 ~191 ~157 ~666 minecraft:redstone_wire replace
setblock ~193 ~157 ~666 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~666 ~204 ~157 ~666 minecraft:redstone_wire replace
setblock ~121 ~157 ~667 minecraft:redstone_wire replace
fill ~120 ~157 ~670 ~130 ~157 ~670 minecraft:redstone_wire replace
setblock ~132 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~157 ~670 ~147 ~157 ~670 minecraft:redstone_wire replace
setblock ~149 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~670 ~164 ~157 ~670 minecraft:redstone_wire replace
setblock ~166 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~670 ~181 ~157 ~670 minecraft:redstone_wire replace
setblock ~183 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~157 ~670 ~198 ~157 ~670 minecraft:redstone_wire replace
setblock ~200 ~157 ~670 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~670 ~207 ~157 ~670 minecraft:redstone_wire replace
setblock ~121 ~157 ~671 minecraft:redstone_wire replace
fill ~120 ~157 ~674 ~126 ~157 ~674 minecraft:redstone_wire replace
setblock ~128 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~157 ~674 ~143 ~157 ~674 minecraft:redstone_wire replace
setblock ~145 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~674 ~160 ~157 ~674 minecraft:redstone_wire replace
setblock ~162 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~674 ~177 ~157 ~674 minecraft:redstone_wire replace
setblock ~179 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~674 ~194 ~157 ~674 minecraft:redstone_wire replace
setblock ~196 ~157 ~674 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~674 ~210 ~157 ~674 minecraft:redstone_wire replace
setblock ~121 ~157 ~675 minecraft:redstone_wire replace
fill ~120 ~157 ~678 ~130 ~157 ~678 minecraft:redstone_wire replace
setblock ~132 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~157 ~678 ~147 ~157 ~678 minecraft:redstone_wire replace
setblock ~149 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~678 ~164 ~157 ~678 minecraft:redstone_wire replace
setblock ~166 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~678 ~181 ~157 ~678 minecraft:redstone_wire replace
setblock ~183 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~157 ~678 ~198 ~157 ~678 minecraft:redstone_wire replace
setblock ~200 ~157 ~678 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~678 ~213 ~157 ~678 minecraft:redstone_wire replace
setblock ~121 ~157 ~679 minecraft:redstone_wire replace
fill ~123 ~157 ~682 ~135 ~157 ~682 minecraft:redstone_wire replace
setblock ~137 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~682 ~152 ~157 ~682 minecraft:redstone_wire replace
setblock ~154 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~157 ~682 ~169 ~157 ~682 minecraft:redstone_wire replace
setblock ~171 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~157 ~682 ~186 ~157 ~682 minecraft:redstone_wire replace
setblock ~188 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~157 ~682 ~203 ~157 ~682 minecraft:redstone_wire replace
setblock ~205 ~157 ~682 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~157 ~682 ~216 ~157 ~682 minecraft:redstone_wire replace
setblock ~124 ~157 ~683 minecraft:redstone_wire replace
fill ~123 ~157 ~686 ~125 ~157 ~686 minecraft:redstone_wire replace
setblock ~127 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~157 ~686 ~142 ~157 ~686 minecraft:redstone_wire replace
setblock ~144 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~686 ~159 ~157 ~686 minecraft:redstone_wire replace
setblock ~161 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~686 ~176 ~157 ~686 minecraft:redstone_wire replace
setblock ~178 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~686 ~193 ~157 ~686 minecraft:redstone_wire replace
setblock ~195 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~686 ~210 ~157 ~686 minecraft:redstone_wire replace
setblock ~212 ~157 ~686 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~686 ~219 ~157 ~686 minecraft:redstone_wire replace
setblock ~124 ~157 ~687 minecraft:redstone_wire replace
fill ~123 ~157 ~690 ~127 ~157 ~690 minecraft:redstone_wire replace
setblock ~129 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~157 ~690 ~143 ~157 ~690 minecraft:redstone_wire replace
setblock ~145 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~157 ~690 ~159 ~157 ~690 minecraft:redstone_wire replace
setblock ~161 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~690 ~175 ~157 ~690 minecraft:redstone_wire replace
setblock ~177 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~157 ~690 ~191 ~157 ~690 minecraft:redstone_wire replace
setblock ~193 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~690 ~207 ~157 ~690 minecraft:redstone_wire replace
setblock ~209 ~157 ~690 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~157 ~690 ~222 ~157 ~690 minecraft:redstone_wire replace
setblock ~124 ~157 ~691 minecraft:redstone_wire replace
fill ~123 ~157 ~694 ~125 ~157 ~694 minecraft:redstone_wire replace
setblock ~127 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~157 ~694 ~142 ~157 ~694 minecraft:redstone_wire replace
setblock ~144 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~694 ~159 ~157 ~694 minecraft:redstone_wire replace
setblock ~161 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~694 ~176 ~157 ~694 minecraft:redstone_wire replace
setblock ~178 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~694 ~193 ~157 ~694 minecraft:redstone_wire replace
setblock ~195 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~694 ~210 ~157 ~694 minecraft:redstone_wire replace
setblock ~212 ~157 ~694 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~694 ~225 ~157 ~694 minecraft:redstone_wire replace
setblock ~124 ~157 ~695 minecraft:redstone_wire replace
fill ~123 ~157 ~698 ~130 ~157 ~698 minecraft:redstone_wire replace
setblock ~132 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~157 ~698 ~147 ~157 ~698 minecraft:redstone_wire replace
setblock ~149 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~698 ~164 ~157 ~698 minecraft:redstone_wire replace
setblock ~166 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~157 ~698 ~181 ~157 ~698 minecraft:redstone_wire replace
setblock ~183 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~157 ~698 ~198 ~157 ~698 minecraft:redstone_wire replace
setblock ~200 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~698 ~215 ~157 ~698 minecraft:redstone_wire replace
setblock ~217 ~157 ~698 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~157 ~698 ~228 ~157 ~698 minecraft:redstone_wire replace
setblock ~124 ~157 ~699 minecraft:redstone_wire replace
setblock ~123 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~157 ~702 ~137 ~157 ~702 minecraft:redstone_wire replace
setblock ~139 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~702 ~154 ~157 ~702 minecraft:redstone_wire replace
setblock ~156 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~702 ~171 ~157 ~702 minecraft:redstone_wire replace
setblock ~173 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~702 ~188 ~157 ~702 minecraft:redstone_wire replace
setblock ~190 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~702 ~205 ~157 ~702 minecraft:redstone_wire replace
setblock ~207 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~702 ~222 ~157 ~702 minecraft:redstone_wire replace
setblock ~224 ~157 ~702 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~702 ~231 ~157 ~702 minecraft:redstone_wire replace
setblock ~124 ~157 ~703 minecraft:redstone_wire replace
fill ~126 ~157 ~706 ~133 ~157 ~706 minecraft:redstone_wire replace
setblock ~135 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~157 ~706 ~150 ~157 ~706 minecraft:redstone_wire replace
setblock ~152 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~706 ~167 ~157 ~706 minecraft:redstone_wire replace
setblock ~169 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~706 ~184 ~157 ~706 minecraft:redstone_wire replace
setblock ~186 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~706 ~201 ~157 ~706 minecraft:redstone_wire replace
setblock ~203 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~706 ~218 ~157 ~706 minecraft:redstone_wire replace
setblock ~220 ~157 ~706 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~706 ~234 ~157 ~706 minecraft:redstone_wire replace
setblock ~127 ~157 ~707 minecraft:redstone_wire replace
fill ~126 ~157 ~710 ~137 ~157 ~710 minecraft:redstone_wire replace
setblock ~139 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~710 ~154 ~157 ~710 minecraft:redstone_wire replace
setblock ~156 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~710 ~171 ~157 ~710 minecraft:redstone_wire replace
setblock ~173 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~710 ~188 ~157 ~710 minecraft:redstone_wire replace
setblock ~190 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~710 ~205 ~157 ~710 minecraft:redstone_wire replace
setblock ~207 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~710 ~222 ~157 ~710 minecraft:redstone_wire replace
setblock ~224 ~157 ~710 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~710 ~237 ~157 ~710 minecraft:redstone_wire replace
setblock ~127 ~157 ~711 minecraft:redstone_wire replace
fill ~126 ~157 ~714 ~127 ~157 ~714 minecraft:redstone_wire replace
setblock ~128 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~157 ~714 ~142 ~157 ~714 minecraft:redstone_wire replace
setblock ~144 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~157 ~714 ~159 ~157 ~714 minecraft:redstone_wire replace
setblock ~161 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~157 ~714 ~176 ~157 ~714 minecraft:redstone_wire replace
setblock ~178 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~157 ~714 ~193 ~157 ~714 minecraft:redstone_wire replace
setblock ~195 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~157 ~714 ~210 ~157 ~714 minecraft:redstone_wire replace
setblock ~212 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~157 ~714 ~227 ~157 ~714 minecraft:redstone_wire replace
setblock ~229 ~157 ~714 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~157 ~714 ~240 ~157 ~714 minecraft:redstone_wire replace
setblock ~127 ~157 ~715 minecraft:redstone_wire replace
fill ~126 ~157 ~718 ~132 ~157 ~718 minecraft:redstone_wire replace
setblock ~134 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~718 ~149 ~157 ~718 minecraft:redstone_wire replace
setblock ~151 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~718 ~166 ~157 ~718 minecraft:redstone_wire replace
setblock ~168 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~718 ~183 ~157 ~718 minecraft:redstone_wire replace
setblock ~185 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~718 ~200 ~157 ~718 minecraft:redstone_wire replace
setblock ~202 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~718 ~217 ~157 ~718 minecraft:redstone_wire replace
setblock ~219 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~718 ~234 ~157 ~718 minecraft:redstone_wire replace
setblock ~236 ~157 ~718 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~718 ~243 ~157 ~718 minecraft:redstone_wire replace
setblock ~127 ~157 ~719 minecraft:redstone_wire replace
fill ~126 ~157 ~722 ~128 ~157 ~722 minecraft:redstone_wire replace
setblock ~130 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~157 ~722 ~145 ~157 ~722 minecraft:redstone_wire replace
setblock ~147 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~157 ~722 ~162 ~157 ~722 minecraft:redstone_wire replace
setblock ~164 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~722 ~179 ~157 ~722 minecraft:redstone_wire replace
setblock ~181 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~722 ~196 ~157 ~722 minecraft:redstone_wire replace
setblock ~198 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~722 ~213 ~157 ~722 minecraft:redstone_wire replace
setblock ~215 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~722 ~230 ~157 ~722 minecraft:redstone_wire replace
setblock ~232 ~157 ~722 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~722 ~246 ~157 ~722 minecraft:redstone_wire replace
setblock ~127 ~157 ~723 minecraft:redstone_wire replace
fill ~126 ~157 ~726 ~132 ~157 ~726 minecraft:redstone_wire replace
setblock ~134 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~726 ~149 ~157 ~726 minecraft:redstone_wire replace
setblock ~151 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~726 ~166 ~157 ~726 minecraft:redstone_wire replace
setblock ~168 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~726 ~183 ~157 ~726 minecraft:redstone_wire replace
setblock ~185 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~726 ~200 ~157 ~726 minecraft:redstone_wire replace
setblock ~202 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~726 ~217 ~157 ~726 minecraft:redstone_wire replace
setblock ~219 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~726 ~234 ~157 ~726 minecraft:redstone_wire replace
setblock ~236 ~157 ~726 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~726 ~249 ~157 ~726 minecraft:redstone_wire replace
setblock ~127 ~157 ~727 minecraft:redstone_wire replace
fill ~126 ~157 ~730 ~137 ~157 ~730 minecraft:redstone_wire replace
setblock ~139 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~157 ~730 ~154 ~157 ~730 minecraft:redstone_wire replace
setblock ~156 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~157 ~730 ~171 ~157 ~730 minecraft:redstone_wire replace
setblock ~173 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~157 ~730 ~188 ~157 ~730 minecraft:redstone_wire replace
setblock ~190 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~157 ~730 ~205 ~157 ~730 minecraft:redstone_wire replace
setblock ~207 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~157 ~730 ~222 ~157 ~730 minecraft:redstone_wire replace
setblock ~224 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~157 ~730 ~239 ~157 ~730 minecraft:redstone_wire replace
setblock ~241 ~157 ~730 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~157 ~730 ~252 ~157 ~730 minecraft:redstone_wire replace
setblock ~127 ~157 ~731 minecraft:redstone_wire replace
setblock ~150 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~157 ~734 ~163 ~157 ~734 minecraft:redstone_wire replace
setblock ~165 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~734 ~179 ~157 ~734 minecraft:redstone_wire replace
setblock ~181 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~734 ~195 ~157 ~734 minecraft:redstone_wire replace
setblock ~197 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~157 ~734 ~211 ~157 ~734 minecraft:redstone_wire replace
setblock ~213 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~734 ~227 ~157 ~734 minecraft:redstone_wire replace
setblock ~229 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~157 ~734 ~243 ~157 ~734 minecraft:redstone_wire replace
setblock ~245 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~157 ~734 ~259 ~157 ~734 minecraft:redstone_wire replace
setblock ~261 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~734 ~275 ~157 ~734 minecraft:redstone_wire replace
setblock ~277 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~157 ~734 ~291 ~157 ~734 minecraft:redstone_wire replace
setblock ~293 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~734 ~307 ~157 ~734 minecraft:redstone_wire replace
setblock ~309 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~311 ~157 ~734 ~323 ~157 ~734 minecraft:redstone_wire replace
setblock ~325 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~327 ~157 ~734 ~339 ~157 ~734 minecraft:redstone_wire replace
setblock ~341 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~157 ~734 ~355 ~157 ~734 minecraft:redstone_wire replace
setblock ~357 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~359 ~157 ~734 ~371 ~157 ~734 minecraft:redstone_wire replace
setblock ~373 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~157 ~734 ~387 ~157 ~734 minecraft:redstone_wire replace
setblock ~389 ~157 ~734 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~391 ~157 ~734 ~402 ~157 ~734 minecraft:redstone_wire replace
setblock ~151 ~157 ~735 minecraft:redstone_wire replace
setblock ~153 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~157 ~738 ~166 ~157 ~738 minecraft:redstone_wire replace
setblock ~168 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~738 ~182 ~157 ~738 minecraft:redstone_wire replace
setblock ~184 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~157 ~738 ~198 ~157 ~738 minecraft:redstone_wire replace
setblock ~200 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~157 ~738 ~214 ~157 ~738 minecraft:redstone_wire replace
setblock ~216 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~738 ~230 ~157 ~738 minecraft:redstone_wire replace
setblock ~232 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~738 ~246 ~157 ~738 minecraft:redstone_wire replace
setblock ~248 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~157 ~738 ~262 ~157 ~738 minecraft:redstone_wire replace
setblock ~264 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~738 ~278 ~157 ~738 minecraft:redstone_wire replace
setblock ~280 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~157 ~738 ~294 ~157 ~738 minecraft:redstone_wire replace
setblock ~296 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~157 ~738 ~310 ~157 ~738 minecraft:redstone_wire replace
setblock ~312 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~738 ~326 ~157 ~738 minecraft:redstone_wire replace
setblock ~328 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~330 ~157 ~738 ~342 ~157 ~738 minecraft:redstone_wire replace
setblock ~344 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~738 ~358 ~157 ~738 minecraft:redstone_wire replace
setblock ~360 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~362 ~157 ~738 ~374 ~157 ~738 minecraft:redstone_wire replace
setblock ~376 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~378 ~157 ~738 ~390 ~157 ~738 minecraft:redstone_wire replace
setblock ~392 ~157 ~738 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~394 ~157 ~738 ~405 ~157 ~738 minecraft:redstone_wire replace
setblock ~154 ~157 ~739 minecraft:redstone_wire replace
fill ~153 ~157 ~742 ~155 ~157 ~742 minecraft:redstone_wire replace
setblock ~157 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~157 ~742 ~172 ~157 ~742 minecraft:redstone_wire replace
setblock ~174 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~157 ~742 ~189 ~157 ~742 minecraft:redstone_wire replace
setblock ~191 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~157 ~742 ~206 ~157 ~742 minecraft:redstone_wire replace
setblock ~208 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~157 ~742 ~223 ~157 ~742 minecraft:redstone_wire replace
setblock ~225 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~157 ~742 ~240 ~157 ~742 minecraft:redstone_wire replace
setblock ~242 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~157 ~742 ~257 ~157 ~742 minecraft:redstone_wire replace
setblock ~259 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~157 ~742 ~274 ~157 ~742 minecraft:redstone_wire replace
setblock ~276 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~157 ~742 ~291 ~157 ~742 minecraft:redstone_wire replace
setblock ~293 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~157 ~742 ~308 ~157 ~742 minecraft:redstone_wire replace
setblock ~310 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~157 ~742 ~325 ~157 ~742 minecraft:redstone_wire replace
setblock ~327 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~157 ~742 ~342 ~157 ~742 minecraft:redstone_wire replace
setblock ~344 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~157 ~742 ~359 ~157 ~742 minecraft:redstone_wire replace
setblock ~361 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~157 ~742 ~376 ~157 ~742 minecraft:redstone_wire replace
setblock ~378 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~380 ~157 ~742 ~393 ~157 ~742 minecraft:redstone_wire replace
setblock ~395 ~157 ~742 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~397 ~157 ~742 ~408 ~157 ~742 minecraft:redstone_wire replace
setblock ~154 ~157 ~743 minecraft:redstone_wire replace
fill ~156 ~157 ~746 ~162 ~157 ~746 minecraft:redstone_wire replace
setblock ~164 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~157 ~746 ~179 ~157 ~746 minecraft:redstone_wire replace
setblock ~181 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~157 ~746 ~196 ~157 ~746 minecraft:redstone_wire replace
setblock ~198 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~157 ~746 ~213 ~157 ~746 minecraft:redstone_wire replace
setblock ~215 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~157 ~746 ~230 ~157 ~746 minecraft:redstone_wire replace
setblock ~232 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~157 ~746 ~247 ~157 ~746 minecraft:redstone_wire replace
setblock ~249 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~746 ~264 ~157 ~746 minecraft:redstone_wire replace
setblock ~266 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~157 ~746 ~281 ~157 ~746 minecraft:redstone_wire replace
setblock ~283 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~157 ~746 ~298 ~157 ~746 minecraft:redstone_wire replace
setblock ~300 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~302 ~157 ~746 ~315 ~157 ~746 minecraft:redstone_wire replace
setblock ~317 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~157 ~746 ~332 ~157 ~746 minecraft:redstone_wire replace
setblock ~334 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~157 ~746 ~349 ~157 ~746 minecraft:redstone_wire replace
setblock ~351 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~353 ~157 ~746 ~366 ~157 ~746 minecraft:redstone_wire replace
setblock ~368 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~157 ~746 ~383 ~157 ~746 minecraft:redstone_wire replace
setblock ~385 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~387 ~157 ~746 ~400 ~157 ~746 minecraft:redstone_wire replace
setblock ~402 ~157 ~746 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~404 ~157 ~746 ~411 ~157 ~746 minecraft:redstone_wire replace
setblock ~157 ~157 ~747 minecraft:redstone_wire replace
fill ~156 ~157 ~750 ~160 ~157 ~750 minecraft:redstone_wire replace
setblock ~162 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~157 ~750 ~177 ~157 ~750 minecraft:redstone_wire replace
setblock ~179 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~157 ~750 ~194 ~157 ~750 minecraft:redstone_wire replace
setblock ~196 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~157 ~750 ~211 ~157 ~750 minecraft:redstone_wire replace
setblock ~213 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~157 ~750 ~228 ~157 ~750 minecraft:redstone_wire replace
setblock ~230 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~157 ~750 ~245 ~157 ~750 minecraft:redstone_wire replace
setblock ~247 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~157 ~750 ~262 ~157 ~750 minecraft:redstone_wire replace
setblock ~264 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~266 ~157 ~750 ~279 ~157 ~750 minecraft:redstone_wire replace
setblock ~281 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~157 ~750 ~296 ~157 ~750 minecraft:redstone_wire replace
setblock ~298 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~157 ~750 ~313 ~157 ~750 minecraft:redstone_wire replace
setblock ~315 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~317 ~157 ~750 ~330 ~157 ~750 minecraft:redstone_wire replace
setblock ~332 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~157 ~750 ~347 ~157 ~750 minecraft:redstone_wire replace
setblock ~349 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~157 ~750 ~364 ~157 ~750 minecraft:redstone_wire replace
setblock ~366 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~368 ~157 ~750 ~381 ~157 ~750 minecraft:redstone_wire replace
setblock ~383 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~385 ~157 ~750 ~398 ~157 ~750 minecraft:redstone_wire replace
setblock ~400 ~157 ~750 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~402 ~157 ~750 ~414 ~157 ~750 minecraft:redstone_wire replace
setblock ~157 ~157 ~751 minecraft:redstone_wire replace
fill ~159 ~157 ~754 ~163 ~157 ~754 minecraft:redstone_wire replace
setblock ~165 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~157 ~754 ~180 ~157 ~754 minecraft:redstone_wire replace
setblock ~182 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~157 ~754 ~197 ~157 ~754 minecraft:redstone_wire replace
setblock ~199 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~157 ~754 ~214 ~157 ~754 minecraft:redstone_wire replace
setblock ~216 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~157 ~754 ~231 ~157 ~754 minecraft:redstone_wire replace
setblock ~233 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~754 ~248 ~157 ~754 minecraft:redstone_wire replace
setblock ~250 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~157 ~754 ~265 ~157 ~754 minecraft:redstone_wire replace
setblock ~267 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~157 ~754 ~282 ~157 ~754 minecraft:redstone_wire replace
setblock ~284 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~157 ~754 ~299 ~157 ~754 minecraft:redstone_wire replace
setblock ~301 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~157 ~754 ~316 ~157 ~754 minecraft:redstone_wire replace
setblock ~318 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~320 ~157 ~754 ~333 ~157 ~754 minecraft:redstone_wire replace
setblock ~335 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~157 ~754 ~350 ~157 ~754 minecraft:redstone_wire replace
setblock ~352 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~157 ~754 ~367 ~157 ~754 minecraft:redstone_wire replace
setblock ~369 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~371 ~157 ~754 ~384 ~157 ~754 minecraft:redstone_wire replace
setblock ~386 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~388 ~157 ~754 ~401 ~157 ~754 minecraft:redstone_wire replace
setblock ~403 ~157 ~754 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~405 ~157 ~754 ~417 ~157 ~754 minecraft:redstone_wire replace
setblock ~160 ~157 ~755 minecraft:redstone_wire replace
fill ~162 ~157 ~758 ~167 ~157 ~758 minecraft:redstone_wire replace
setblock ~169 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~758 ~184 ~157 ~758 minecraft:redstone_wire replace
setblock ~186 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~157 ~758 ~201 ~157 ~758 minecraft:redstone_wire replace
setblock ~203 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~157 ~758 ~218 ~157 ~758 minecraft:redstone_wire replace
setblock ~220 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~157 ~758 ~235 ~157 ~758 minecraft:redstone_wire replace
setblock ~237 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~157 ~758 ~252 ~157 ~758 minecraft:redstone_wire replace
setblock ~254 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~157 ~758 ~269 ~157 ~758 minecraft:redstone_wire replace
setblock ~271 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~157 ~758 ~286 ~157 ~758 minecraft:redstone_wire replace
setblock ~288 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~290 ~157 ~758 ~303 ~157 ~758 minecraft:redstone_wire replace
setblock ~305 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~157 ~758 ~320 ~157 ~758 minecraft:redstone_wire replace
setblock ~322 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~157 ~758 ~337 ~157 ~758 minecraft:redstone_wire replace
setblock ~339 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~341 ~157 ~758 ~354 ~157 ~758 minecraft:redstone_wire replace
setblock ~356 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~157 ~758 ~371 ~157 ~758 minecraft:redstone_wire replace
setblock ~373 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~157 ~758 ~388 ~157 ~758 minecraft:redstone_wire replace
setblock ~390 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~392 ~157 ~758 ~405 ~157 ~758 minecraft:redstone_wire replace
setblock ~407 ~157 ~758 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~409 ~157 ~758 ~420 ~157 ~758 minecraft:redstone_wire replace
setblock ~163 ~157 ~759 minecraft:redstone_wire replace
fill ~165 ~157 ~762 ~174 ~157 ~762 minecraft:redstone_wire replace
setblock ~176 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~762 ~191 ~157 ~762 minecraft:redstone_wire replace
setblock ~193 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~762 ~208 ~157 ~762 minecraft:redstone_wire replace
setblock ~210 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~762 ~225 ~157 ~762 minecraft:redstone_wire replace
setblock ~227 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~762 ~242 ~157 ~762 minecraft:redstone_wire replace
setblock ~244 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~762 ~259 ~157 ~762 minecraft:redstone_wire replace
setblock ~261 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~157 ~762 ~276 ~157 ~762 minecraft:redstone_wire replace
setblock ~278 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~157 ~762 ~293 ~157 ~762 minecraft:redstone_wire replace
setblock ~295 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~157 ~762 ~310 ~157 ~762 minecraft:redstone_wire replace
setblock ~312 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~314 ~157 ~762 ~327 ~157 ~762 minecraft:redstone_wire replace
setblock ~329 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~157 ~762 ~344 ~157 ~762 minecraft:redstone_wire replace
setblock ~346 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~157 ~762 ~361 ~157 ~762 minecraft:redstone_wire replace
setblock ~363 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~365 ~157 ~762 ~378 ~157 ~762 minecraft:redstone_wire replace
setblock ~380 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~382 ~157 ~762 ~395 ~157 ~762 minecraft:redstone_wire replace
setblock ~397 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~399 ~157 ~762 ~412 ~157 ~762 minecraft:redstone_wire replace
setblock ~414 ~157 ~762 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~416 ~157 ~762 ~423 ~157 ~762 minecraft:redstone_wire replace
setblock ~166 ~157 ~763 minecraft:redstone_wire replace
fill ~129 ~157 ~766 ~135 ~157 ~766 minecraft:redstone_wire replace
setblock ~137 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~766 ~151 ~157 ~766 minecraft:redstone_wire replace
setblock ~153 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~766 ~167 ~157 ~766 minecraft:redstone_wire replace
setblock ~169 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~766 ~183 ~157 ~766 minecraft:redstone_wire replace
setblock ~185 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~766 ~199 ~157 ~766 minecraft:redstone_wire replace
setblock ~201 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~766 ~215 ~157 ~766 minecraft:redstone_wire replace
setblock ~217 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~157 ~766 ~231 ~157 ~766 minecraft:redstone_wire replace
setblock ~233 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~766 ~247 ~157 ~766 minecraft:redstone_wire replace
setblock ~249 ~157 ~766 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~766 ~255 ~157 ~766 minecraft:redstone_wire replace
setblock ~130 ~157 ~767 minecraft:redstone_wire replace
fill ~129 ~157 ~770 ~140 ~157 ~770 minecraft:redstone_wire replace
setblock ~142 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~157 ~770 ~157 ~157 ~770 minecraft:redstone_wire replace
setblock ~159 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~157 ~770 ~174 ~157 ~770 minecraft:redstone_wire replace
setblock ~176 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~157 ~770 ~191 ~157 ~770 minecraft:redstone_wire replace
setblock ~193 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~157 ~770 ~208 ~157 ~770 minecraft:redstone_wire replace
setblock ~210 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~157 ~770 ~225 ~157 ~770 minecraft:redstone_wire replace
setblock ~227 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~157 ~770 ~242 ~157 ~770 minecraft:redstone_wire replace
setblock ~244 ~157 ~770 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~157 ~770 ~258 ~157 ~770 minecraft:redstone_wire replace
setblock ~130 ~157 ~771 minecraft:redstone_wire replace
fill ~129 ~157 ~774 ~135 ~157 ~774 minecraft:redstone_wire replace
setblock ~137 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~157 ~774 ~151 ~157 ~774 minecraft:redstone_wire replace
setblock ~153 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~157 ~774 ~167 ~157 ~774 minecraft:redstone_wire replace
setblock ~169 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~157 ~774 ~183 ~157 ~774 minecraft:redstone_wire replace
setblock ~185 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~774 ~199 ~157 ~774 minecraft:redstone_wire replace
setblock ~201 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~157 ~774 ~215 ~157 ~774 minecraft:redstone_wire replace
setblock ~217 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~157 ~774 ~231 ~157 ~774 minecraft:redstone_wire replace
setblock ~233 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~157 ~774 ~247 ~157 ~774 minecraft:redstone_wire replace
setblock ~249 ~157 ~774 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~157 ~774 ~261 ~157 ~774 minecraft:redstone_wire replace
setblock ~130 ~157 ~775 minecraft:redstone_wire replace
fill ~129 ~157 ~778 ~132 ~157 ~778 minecraft:redstone_wire replace
setblock ~134 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~157 ~778 ~149 ~157 ~778 minecraft:redstone_wire replace
setblock ~151 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~157 ~778 ~166 ~157 ~778 minecraft:redstone_wire replace
setblock ~168 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~157 ~778 ~183 ~157 ~778 minecraft:redstone_wire replace
setblock ~185 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~157 ~778 ~200 ~157 ~778 minecraft:redstone_wire replace
setblock ~202 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~157 ~778 ~217 ~157 ~778 minecraft:redstone_wire replace
setblock ~219 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~157 ~778 ~234 ~157 ~778 minecraft:redstone_wire replace
setblock ~236 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~157 ~778 ~251 ~157 ~778 minecraft:redstone_wire replace
setblock ~253 ~157 ~778 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~157 ~778 ~264 ~157 ~778 minecraft:redstone_wire replace
setblock ~130 ~157 ~779 minecraft:redstone_wire replace
fill ~129 ~157 ~782 ~139 ~157 ~782 minecraft:redstone_wire replace
setblock ~141 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~157 ~782 ~156 ~157 ~782 minecraft:redstone_wire replace
setblock ~158 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~157 ~782 ~173 ~157 ~782 minecraft:redstone_wire replace
setblock ~175 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~157 ~782 ~190 ~157 ~782 minecraft:redstone_wire replace
setblock ~192 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~157 ~782 ~207 ~157 ~782 minecraft:redstone_wire replace
setblock ~209 ~157 ~782 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
