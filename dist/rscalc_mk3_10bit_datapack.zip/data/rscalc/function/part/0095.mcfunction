setblock ~198 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~494 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~496 ~84 ~151 ~508 minecraft:redstone_wire replace
fill ~87 ~151 ~496 ~87 ~151 ~508 minecraft:redstone_wire replace
fill ~90 ~151 ~496 ~90 ~151 ~508 minecraft:redstone_wire replace
fill ~93 ~151 ~496 ~93 ~151 ~508 minecraft:redstone_wire replace
fill ~96 ~151 ~496 ~96 ~151 ~508 minecraft:redstone_wire replace
fill ~99 ~151 ~496 ~99 ~151 ~508 minecraft:redstone_wire replace
fill ~102 ~151 ~496 ~102 ~151 ~508 minecraft:redstone_wire replace
fill ~105 ~151 ~496 ~105 ~151 ~508 minecraft:redstone_wire replace
fill ~108 ~151 ~496 ~108 ~151 ~508 minecraft:redstone_wire replace
fill ~111 ~151 ~496 ~111 ~151 ~508 minecraft:redstone_wire replace
fill ~114 ~151 ~496 ~114 ~151 ~508 minecraft:redstone_wire replace
fill ~117 ~151 ~496 ~117 ~151 ~508 minecraft:redstone_wire replace
fill ~120 ~151 ~496 ~120 ~151 ~508 minecraft:redstone_wire replace
fill ~123 ~151 ~496 ~123 ~151 ~508 minecraft:redstone_wire replace
fill ~126 ~151 ~496 ~126 ~151 ~508 minecraft:redstone_wire replace
fill ~129 ~151 ~496 ~129 ~151 ~508 minecraft:redstone_wire replace
fill ~132 ~151 ~496 ~132 ~151 ~508 minecraft:redstone_wire replace
fill ~135 ~151 ~496 ~135 ~151 ~508 minecraft:redstone_wire replace
fill ~138 ~151 ~496 ~138 ~151 ~508 minecraft:redstone_wire replace
fill ~141 ~151 ~496 ~141 ~151 ~508 minecraft:redstone_wire replace
fill ~144 ~151 ~496 ~144 ~151 ~508 minecraft:redstone_wire replace
fill ~147 ~151 ~496 ~147 ~151 ~508 minecraft:redstone_wire replace
fill ~150 ~151 ~496 ~150 ~151 ~508 minecraft:redstone_wire replace
fill ~153 ~151 ~496 ~153 ~151 ~508 minecraft:redstone_wire replace
fill ~156 ~151 ~496 ~156 ~151 ~508 minecraft:redstone_wire replace
fill ~159 ~151 ~496 ~159 ~151 ~508 minecraft:redstone_wire replace
fill ~162 ~151 ~496 ~162 ~151 ~508 minecraft:redstone_wire replace
fill ~165 ~151 ~496 ~165 ~151 ~508 minecraft:redstone_wire replace
fill ~168 ~151 ~496 ~168 ~151 ~508 minecraft:redstone_wire replace
fill ~171 ~151 ~496 ~171 ~151 ~508 minecraft:redstone_wire replace
fill ~174 ~151 ~496 ~174 ~151 ~508 minecraft:redstone_wire replace
fill ~177 ~151 ~496 ~177 ~151 ~508 minecraft:redstone_wire replace
fill ~180 ~151 ~496 ~180 ~151 ~508 minecraft:redstone_wire replace
fill ~183 ~151 ~496 ~183 ~151 ~508 minecraft:redstone_wire replace
fill ~186 ~151 ~496 ~186 ~151 ~508 minecraft:redstone_wire replace
fill ~189 ~151 ~496 ~189 ~151 ~508 minecraft:redstone_wire replace
fill ~192 ~151 ~496 ~192 ~151 ~508 minecraft:redstone_wire replace
fill ~195 ~151 ~496 ~195 ~151 ~508 minecraft:redstone_wire replace
fill ~198 ~151 ~496 ~198 ~151 ~508 minecraft:redstone_wire replace
fill ~201 ~151 ~496 ~201 ~151 ~508 minecraft:redstone_wire replace
fill ~204 ~151 ~496 ~204 ~151 ~508 minecraft:redstone_wire replace
fill ~207 ~151 ~496 ~207 ~151 ~508 minecraft:redstone_wire replace
fill ~210 ~151 ~496 ~210 ~151 ~508 minecraft:redstone_wire replace
fill ~213 ~151 ~496 ~213 ~151 ~508 minecraft:redstone_wire replace
fill ~216 ~151 ~496 ~216 ~151 ~508 minecraft:redstone_wire replace
fill ~219 ~151 ~496 ~219 ~151 ~508 minecraft:redstone_wire replace
fill ~222 ~151 ~496 ~222 ~151 ~508 minecraft:redstone_wire replace
fill ~225 ~151 ~496 ~225 ~151 ~508 minecraft:redstone_wire replace
fill ~228 ~151 ~496 ~228 ~151 ~508 minecraft:redstone_wire replace
fill ~240 ~151 ~500 ~240 ~151 ~504 minecraft:redstone_wire replace
setblock ~246 ~151 ~503 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~504 ~246 ~151 ~516 minecraft:redstone_wire replace
setblock ~84 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~510 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~512 ~84 ~151 ~524 minecraft:redstone_wire replace
fill ~87 ~151 ~512 ~87 ~151 ~524 minecraft:redstone_wire replace
fill ~90 ~151 ~512 ~90 ~151 ~524 minecraft:redstone_wire replace
fill ~93 ~151 ~512 ~93 ~151 ~524 minecraft:redstone_wire replace
fill ~96 ~151 ~512 ~96 ~151 ~524 minecraft:redstone_wire replace
fill ~99 ~151 ~512 ~99 ~151 ~524 minecraft:redstone_wire replace
fill ~102 ~151 ~512 ~102 ~151 ~524 minecraft:redstone_wire replace
fill ~105 ~151 ~512 ~105 ~151 ~524 minecraft:redstone_wire replace
fill ~108 ~151 ~512 ~108 ~151 ~524 minecraft:redstone_wire replace
fill ~111 ~151 ~512 ~111 ~151 ~524 minecraft:redstone_wire replace
fill ~114 ~151 ~512 ~114 ~151 ~524 minecraft:redstone_wire replace
fill ~117 ~151 ~512 ~117 ~151 ~524 minecraft:redstone_wire replace
fill ~120 ~151 ~512 ~120 ~151 ~524 minecraft:redstone_wire replace
fill ~123 ~151 ~512 ~123 ~151 ~524 minecraft:redstone_wire replace
fill ~126 ~151 ~512 ~126 ~151 ~524 minecraft:redstone_wire replace
fill ~129 ~151 ~512 ~129 ~151 ~524 minecraft:redstone_wire replace
fill ~132 ~151 ~512 ~132 ~151 ~524 minecraft:redstone_wire replace
fill ~135 ~151 ~512 ~135 ~151 ~524 minecraft:redstone_wire replace
fill ~138 ~151 ~512 ~138 ~151 ~524 minecraft:redstone_wire replace
fill ~141 ~151 ~512 ~141 ~151 ~524 minecraft:redstone_wire replace
fill ~144 ~151 ~512 ~144 ~151 ~524 minecraft:redstone_wire replace
fill ~147 ~151 ~512 ~147 ~151 ~524 minecraft:redstone_wire replace
fill ~150 ~151 ~512 ~150 ~151 ~524 minecraft:redstone_wire replace
fill ~153 ~151 ~512 ~153 ~151 ~524 minecraft:redstone_wire replace
fill ~156 ~151 ~512 ~156 ~151 ~524 minecraft:redstone_wire replace
fill ~159 ~151 ~512 ~159 ~151 ~524 minecraft:redstone_wire replace
fill ~162 ~151 ~512 ~162 ~151 ~524 minecraft:redstone_wire replace
fill ~165 ~151 ~512 ~165 ~151 ~524 minecraft:redstone_wire replace
fill ~168 ~151 ~512 ~168 ~151 ~524 minecraft:redstone_wire replace
fill ~171 ~151 ~512 ~171 ~151 ~524 minecraft:redstone_wire replace
fill ~174 ~151 ~512 ~174 ~151 ~524 minecraft:redstone_wire replace
fill ~177 ~151 ~512 ~177 ~151 ~524 minecraft:redstone_wire replace
fill ~180 ~151 ~512 ~180 ~151 ~524 minecraft:redstone_wire replace
fill ~183 ~151 ~512 ~183 ~151 ~524 minecraft:redstone_wire replace
fill ~186 ~151 ~512 ~186 ~151 ~524 minecraft:redstone_wire replace
fill ~189 ~151 ~512 ~189 ~151 ~524 minecraft:redstone_wire replace
fill ~192 ~151 ~512 ~192 ~151 ~524 minecraft:redstone_wire replace
fill ~195 ~151 ~512 ~195 ~151 ~524 minecraft:redstone_wire replace
fill ~198 ~151 ~512 ~198 ~151 ~524 minecraft:redstone_wire replace
fill ~201 ~151 ~512 ~201 ~151 ~524 minecraft:redstone_wire replace
fill ~204 ~151 ~512 ~204 ~151 ~524 minecraft:redstone_wire replace
fill ~207 ~151 ~512 ~207 ~151 ~524 minecraft:redstone_wire replace
fill ~210 ~151 ~512 ~210 ~151 ~524 minecraft:redstone_wire replace
fill ~213 ~151 ~512 ~213 ~151 ~524 minecraft:redstone_wire replace
fill ~216 ~151 ~512 ~216 ~151 ~524 minecraft:redstone_wire replace
fill ~219 ~151 ~512 ~219 ~151 ~524 minecraft:redstone_wire replace
fill ~222 ~151 ~512 ~222 ~151 ~524 minecraft:redstone_wire replace
fill ~225 ~151 ~512 ~225 ~151 ~524 minecraft:redstone_wire replace
fill ~228 ~151 ~512 ~228 ~151 ~524 minecraft:redstone_wire replace
fill ~237 ~151 ~512 ~237 ~151 ~516 minecraft:redstone_wire replace
setblock ~246 ~151 ~518 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~520 ~246 ~151 ~532 minecraft:redstone_wire replace
setblock ~84 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~526 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~528 ~84 ~151 ~540 minecraft:redstone_wire replace
fill ~87 ~151 ~528 ~87 ~151 ~540 minecraft:redstone_wire replace
fill ~90 ~151 ~528 ~90 ~151 ~540 minecraft:redstone_wire replace
fill ~93 ~151 ~528 ~93 ~151 ~540 minecraft:redstone_wire replace
fill ~96 ~151 ~528 ~96 ~151 ~540 minecraft:redstone_wire replace
fill ~99 ~151 ~528 ~99 ~151 ~540 minecraft:redstone_wire replace
fill ~102 ~151 ~528 ~102 ~151 ~540 minecraft:redstone_wire replace
fill ~105 ~151 ~528 ~105 ~151 ~540 minecraft:redstone_wire replace
fill ~108 ~151 ~528 ~108 ~151 ~540 minecraft:redstone_wire replace
fill ~111 ~151 ~528 ~111 ~151 ~540 minecraft:redstone_wire replace
fill ~114 ~151 ~528 ~114 ~151 ~540 minecraft:redstone_wire replace
fill ~117 ~151 ~528 ~117 ~151 ~540 minecraft:redstone_wire replace
fill ~120 ~151 ~528 ~120 ~151 ~540 minecraft:redstone_wire replace
fill ~123 ~151 ~528 ~123 ~151 ~540 minecraft:redstone_wire replace
fill ~126 ~151 ~528 ~126 ~151 ~540 minecraft:redstone_wire replace
fill ~129 ~151 ~528 ~129 ~151 ~540 minecraft:redstone_wire replace
fill ~132 ~151 ~528 ~132 ~151 ~540 minecraft:redstone_wire replace
fill ~135 ~151 ~528 ~135 ~151 ~540 minecraft:redstone_wire replace
fill ~138 ~151 ~528 ~138 ~151 ~540 minecraft:redstone_wire replace
fill ~141 ~151 ~528 ~141 ~151 ~540 minecraft:redstone_wire replace
fill ~144 ~151 ~528 ~144 ~151 ~540 minecraft:redstone_wire replace
fill ~147 ~151 ~528 ~147 ~151 ~540 minecraft:redstone_wire replace
fill ~150 ~151 ~528 ~150 ~151 ~540 minecraft:redstone_wire replace
fill ~153 ~151 ~528 ~153 ~151 ~540 minecraft:redstone_wire replace
fill ~156 ~151 ~528 ~156 ~151 ~540 minecraft:redstone_wire replace
fill ~159 ~151 ~528 ~159 ~151 ~540 minecraft:redstone_wire replace
fill ~162 ~151 ~528 ~162 ~151 ~540 minecraft:redstone_wire replace
fill ~165 ~151 ~528 ~165 ~151 ~540 minecraft:redstone_wire replace
fill ~168 ~151 ~528 ~168 ~151 ~540 minecraft:redstone_wire replace
fill ~171 ~151 ~528 ~171 ~151 ~540 minecraft:redstone_wire replace
fill ~174 ~151 ~528 ~174 ~151 ~540 minecraft:redstone_wire replace
fill ~177 ~151 ~528 ~177 ~151 ~540 minecraft:redstone_wire replace
fill ~180 ~151 ~528 ~180 ~151 ~540 minecraft:redstone_wire replace
fill ~183 ~151 ~528 ~183 ~151 ~540 minecraft:redstone_wire replace
fill ~186 ~151 ~528 ~186 ~151 ~540 minecraft:redstone_wire replace
fill ~189 ~151 ~528 ~189 ~151 ~540 minecraft:redstone_wire replace
fill ~192 ~151 ~528 ~192 ~151 ~540 minecraft:redstone_wire replace
fill ~195 ~151 ~528 ~195 ~151 ~540 minecraft:redstone_wire replace
fill ~198 ~151 ~528 ~198 ~151 ~540 minecraft:redstone_wire replace
fill ~201 ~151 ~528 ~201 ~151 ~540 minecraft:redstone_wire replace
fill ~204 ~151 ~528 ~204 ~151 ~540 minecraft:redstone_wire replace
fill ~207 ~151 ~528 ~207 ~151 ~540 minecraft:redstone_wire replace
fill ~210 ~151 ~528 ~210 ~151 ~540 minecraft:redstone_wire replace
fill ~213 ~151 ~528 ~213 ~151 ~540 minecraft:redstone_wire replace
fill ~216 ~151 ~528 ~216 ~151 ~540 minecraft:redstone_wire replace
fill ~219 ~151 ~528 ~219 ~151 ~540 minecraft:redstone_wire replace
fill ~222 ~151 ~528 ~222 ~151 ~540 minecraft:redstone_wire replace
fill ~225 ~151 ~528 ~225 ~151 ~540 minecraft:redstone_wire replace
fill ~228 ~151 ~528 ~228 ~151 ~540 minecraft:redstone_wire replace
setblock ~246 ~151 ~534 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~151 ~536 ~243 ~151 ~540 minecraft:redstone_wire replace
fill ~246 ~151 ~536 ~246 ~151 ~548 minecraft:redstone_wire replace
setblock ~255 ~151 ~540 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~84 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~542 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~255 ~151 ~542 ~255 ~151 ~548 minecraft:redstone_wire replace
fill ~84 ~151 ~544 ~84 ~151 ~556 minecraft:redstone_wire replace
fill ~87 ~151 ~544 ~87 ~151 ~556 minecraft:redstone_wire replace
fill ~90 ~151 ~544 ~90 ~151 ~556 minecraft:redstone_wire replace
fill ~93 ~151 ~544 ~93 ~151 ~556 minecraft:redstone_wire replace
fill ~96 ~151 ~544 ~96 ~151 ~556 minecraft:redstone_wire replace
fill ~99 ~151 ~544 ~99 ~151 ~556 minecraft:redstone_wire replace
fill ~102 ~151 ~544 ~102 ~151 ~556 minecraft:redstone_wire replace
fill ~105 ~151 ~544 ~105 ~151 ~556 minecraft:redstone_wire replace
fill ~108 ~151 ~544 ~108 ~151 ~556 minecraft:redstone_wire replace
fill ~111 ~151 ~544 ~111 ~151 ~556 minecraft:redstone_wire replace
fill ~114 ~151 ~544 ~114 ~151 ~556 minecraft:redstone_wire replace
fill ~117 ~151 ~544 ~117 ~151 ~556 minecraft:redstone_wire replace
fill ~120 ~151 ~544 ~120 ~151 ~556 minecraft:redstone_wire replace
fill ~123 ~151 ~544 ~123 ~151 ~556 minecraft:redstone_wire replace
fill ~126 ~151 ~544 ~126 ~151 ~556 minecraft:redstone_wire replace
fill ~129 ~151 ~544 ~129 ~151 ~556 minecraft:redstone_wire replace
fill ~132 ~151 ~544 ~132 ~151 ~556 minecraft:redstone_wire replace
fill ~135 ~151 ~544 ~135 ~151 ~556 minecraft:redstone_wire replace
fill ~138 ~151 ~544 ~138 ~151 ~556 minecraft:redstone_wire replace
fill ~141 ~151 ~544 ~141 ~151 ~556 minecraft:redstone_wire replace
fill ~144 ~151 ~544 ~144 ~151 ~556 minecraft:redstone_wire replace
fill ~147 ~151 ~544 ~147 ~151 ~556 minecraft:redstone_wire replace
fill ~150 ~151 ~544 ~150 ~151 ~556 minecraft:redstone_wire replace
fill ~153 ~151 ~544 ~153 ~151 ~556 minecraft:redstone_wire replace
fill ~156 ~151 ~544 ~156 ~151 ~556 minecraft:redstone_wire replace
fill ~159 ~151 ~544 ~159 ~151 ~556 minecraft:redstone_wire replace
fill ~162 ~151 ~544 ~162 ~151 ~556 minecraft:redstone_wire replace
fill ~165 ~151 ~544 ~165 ~151 ~556 minecraft:redstone_wire replace
fill ~168 ~151 ~544 ~168 ~151 ~556 minecraft:redstone_wire replace
fill ~171 ~151 ~544 ~171 ~151 ~556 minecraft:redstone_wire replace
fill ~174 ~151 ~544 ~174 ~151 ~556 minecraft:redstone_wire replace
fill ~177 ~151 ~544 ~177 ~151 ~556 minecraft:redstone_wire replace
fill ~180 ~151 ~544 ~180 ~151 ~556 minecraft:redstone_wire replace
fill ~183 ~151 ~544 ~183 ~151 ~556 minecraft:redstone_wire replace
fill ~186 ~151 ~544 ~186 ~151 ~556 minecraft:redstone_wire replace
fill ~189 ~151 ~544 ~189 ~151 ~556 minecraft:redstone_wire replace
fill ~192 ~151 ~544 ~192 ~151 ~556 minecraft:redstone_wire replace
fill ~195 ~151 ~544 ~195 ~151 ~556 minecraft:redstone_wire replace
fill ~198 ~151 ~544 ~198 ~151 ~556 minecraft:redstone_wire replace
fill ~201 ~151 ~544 ~201 ~151 ~556 minecraft:redstone_wire replace
fill ~204 ~151 ~544 ~204 ~151 ~556 minecraft:redstone_wire replace
fill ~207 ~151 ~544 ~207 ~151 ~556 minecraft:redstone_wire replace
fill ~210 ~151 ~544 ~210 ~151 ~556 minecraft:redstone_wire replace
fill ~213 ~151 ~544 ~213 ~151 ~556 minecraft:redstone_wire replace
fill ~216 ~151 ~544 ~216 ~151 ~556 minecraft:redstone_wire replace
fill ~219 ~151 ~544 ~219 ~151 ~556 minecraft:redstone_wire replace
fill ~222 ~151 ~544 ~222 ~151 ~556 minecraft:redstone_wire replace
fill ~225 ~151 ~544 ~225 ~151 ~556 minecraft:redstone_wire replace
fill ~228 ~151 ~544 ~228 ~151 ~556 minecraft:redstone_wire replace
fill ~249 ~151 ~544 ~249 ~151 ~548 minecraft:redstone_wire replace
setblock ~246 ~151 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~550 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~552 ~246 ~151 ~564 minecraft:redstone_wire replace
fill ~255 ~151 ~552 ~255 ~151 ~564 minecraft:redstone_wire replace
setblock ~84 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~558 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~560 ~84 ~151 ~572 minecraft:redstone_wire replace
fill ~87 ~151 ~560 ~87 ~151 ~572 minecraft:redstone_wire replace
fill ~90 ~151 ~560 ~90 ~151 ~572 minecraft:redstone_wire replace
fill ~93 ~151 ~560 ~93 ~151 ~572 minecraft:redstone_wire replace
fill ~96 ~151 ~560 ~96 ~151 ~572 minecraft:redstone_wire replace
fill ~99 ~151 ~560 ~99 ~151 ~572 minecraft:redstone_wire replace
fill ~102 ~151 ~560 ~102 ~151 ~572 minecraft:redstone_wire replace
fill ~105 ~151 ~560 ~105 ~151 ~572 minecraft:redstone_wire replace
fill ~108 ~151 ~560 ~108 ~151 ~572 minecraft:redstone_wire replace
fill ~111 ~151 ~560 ~111 ~151 ~572 minecraft:redstone_wire replace
fill ~114 ~151 ~560 ~114 ~151 ~572 minecraft:redstone_wire replace
fill ~117 ~151 ~560 ~117 ~151 ~572 minecraft:redstone_wire replace
fill ~120 ~151 ~560 ~120 ~151 ~572 minecraft:redstone_wire replace
fill ~123 ~151 ~560 ~123 ~151 ~572 minecraft:redstone_wire replace
fill ~126 ~151 ~560 ~126 ~151 ~572 minecraft:redstone_wire replace
fill ~129 ~151 ~560 ~129 ~151 ~572 minecraft:redstone_wire replace
fill ~132 ~151 ~560 ~132 ~151 ~572 minecraft:redstone_wire replace
fill ~135 ~151 ~560 ~135 ~151 ~572 minecraft:redstone_wire replace
fill ~138 ~151 ~560 ~138 ~151 ~572 minecraft:redstone_wire replace
fill ~141 ~151 ~560 ~141 ~151 ~572 minecraft:redstone_wire replace
fill ~144 ~151 ~560 ~144 ~151 ~572 minecraft:redstone_wire replace
fill ~147 ~151 ~560 ~147 ~151 ~572 minecraft:redstone_wire replace
fill ~150 ~151 ~560 ~150 ~151 ~572 minecraft:redstone_wire replace
fill ~153 ~151 ~560 ~153 ~151 ~572 minecraft:redstone_wire replace
fill ~156 ~151 ~560 ~156 ~151 ~572 minecraft:redstone_wire replace
fill ~159 ~151 ~560 ~159 ~151 ~572 minecraft:redstone_wire replace
fill ~162 ~151 ~560 ~162 ~151 ~572 minecraft:redstone_wire replace
fill ~165 ~151 ~560 ~165 ~151 ~572 minecraft:redstone_wire replace
fill ~168 ~151 ~560 ~168 ~151 ~572 minecraft:redstone_wire replace
fill ~171 ~151 ~560 ~171 ~151 ~572 minecraft:redstone_wire replace
fill ~174 ~151 ~560 ~174 ~151 ~572 minecraft:redstone_wire replace
fill ~177 ~151 ~560 ~177 ~151 ~572 minecraft:redstone_wire replace
fill ~180 ~151 ~560 ~180 ~151 ~572 minecraft:redstone_wire replace
fill ~183 ~151 ~560 ~183 ~151 ~572 minecraft:redstone_wire replace
fill ~186 ~151 ~560 ~186 ~151 ~572 minecraft:redstone_wire replace
fill ~189 ~151 ~560 ~189 ~151 ~572 minecraft:redstone_wire replace
fill ~192 ~151 ~560 ~192 ~151 ~572 minecraft:redstone_wire replace
fill ~195 ~151 ~560 ~195 ~151 ~572 minecraft:redstone_wire replace
fill ~198 ~151 ~560 ~198 ~151 ~572 minecraft:redstone_wire replace
fill ~201 ~151 ~560 ~201 ~151 ~572 minecraft:redstone_wire replace
fill ~204 ~151 ~560 ~204 ~151 ~572 minecraft:redstone_wire replace
fill ~207 ~151 ~560 ~207 ~151 ~572 minecraft:redstone_wire replace
fill ~210 ~151 ~560 ~210 ~151 ~572 minecraft:redstone_wire replace
fill ~213 ~151 ~560 ~213 ~151 ~572 minecraft:redstone_wire replace
fill ~216 ~151 ~560 ~216 ~151 ~572 minecraft:redstone_wire replace
fill ~219 ~151 ~560 ~219 ~151 ~572 minecraft:redstone_wire replace
fill ~222 ~151 ~560 ~222 ~151 ~572 minecraft:redstone_wire replace
fill ~225 ~151 ~560 ~225 ~151 ~572 minecraft:redstone_wire replace
fill ~228 ~151 ~560 ~228 ~151 ~572 minecraft:redstone_wire replace
setblock ~246 ~151 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~566 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~568 ~246 ~151 ~580 minecraft:redstone_wire replace
fill ~255 ~151 ~568 ~255 ~151 ~580 minecraft:redstone_wire replace
fill ~258 ~151 ~568 ~258 ~151 ~572 minecraft:redstone_wire replace
setblock ~84 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~159 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~165 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~171 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~177 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~180 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~192 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~195 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~198 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~201 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~204 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~207 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~213 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~216 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~219 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~222 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~228 ~151 ~574 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~151 ~576 ~84 ~151 ~588 minecraft:redstone_wire replace
fill ~87 ~151 ~576 ~87 ~151 ~588 minecraft:redstone_wire replace
fill ~90 ~151 ~576 ~90 ~151 ~588 minecraft:redstone_wire replace
fill ~93 ~151 ~576 ~93 ~151 ~588 minecraft:redstone_wire replace
fill ~96 ~151 ~576 ~96 ~151 ~588 minecraft:redstone_wire replace
fill ~99 ~151 ~576 ~99 ~151 ~588 minecraft:redstone_wire replace
fill ~102 ~151 ~576 ~102 ~151 ~588 minecraft:redstone_wire replace
fill ~105 ~151 ~576 ~105 ~151 ~588 minecraft:redstone_wire replace
fill ~108 ~151 ~576 ~108 ~151 ~588 minecraft:redstone_wire replace
fill ~111 ~151 ~576 ~111 ~151 ~588 minecraft:redstone_wire replace
fill ~114 ~151 ~576 ~114 ~151 ~588 minecraft:redstone_wire replace
fill ~117 ~151 ~576 ~117 ~151 ~588 minecraft:redstone_wire replace
fill ~120 ~151 ~576 ~120 ~151 ~588 minecraft:redstone_wire replace
fill ~123 ~151 ~576 ~123 ~151 ~588 minecraft:redstone_wire replace
fill ~126 ~151 ~576 ~126 ~151 ~588 minecraft:redstone_wire replace
fill ~129 ~151 ~576 ~129 ~151 ~588 minecraft:redstone_wire replace
fill ~132 ~151 ~576 ~132 ~151 ~588 minecraft:redstone_wire replace
fill ~135 ~151 ~576 ~135 ~151 ~588 minecraft:redstone_wire replace
fill ~138 ~151 ~576 ~138 ~151 ~588 minecraft:redstone_wire replace
fill ~141 ~151 ~576 ~141 ~151 ~588 minecraft:redstone_wire replace
fill ~144 ~151 ~576 ~144 ~151 ~588 minecraft:redstone_wire replace
fill ~147 ~151 ~576 ~147 ~151 ~588 minecraft:redstone_wire replace
fill ~150 ~151 ~576 ~150 ~151 ~588 minecraft:redstone_wire replace
fill ~153 ~151 ~576 ~153 ~151 ~588 minecraft:redstone_wire replace
fill ~156 ~151 ~576 ~156 ~151 ~588 minecraft:redstone_wire replace
fill ~159 ~151 ~576 ~159 ~151 ~588 minecraft:redstone_wire replace
fill ~162 ~151 ~576 ~162 ~151 ~588 minecraft:redstone_wire replace
fill ~165 ~151 ~576 ~165 ~151 ~588 minecraft:redstone_wire replace
fill ~168 ~151 ~576 ~168 ~151 ~588 minecraft:redstone_wire replace
fill ~171 ~151 ~576 ~171 ~151 ~588 minecraft:redstone_wire replace
fill ~174 ~151 ~576 ~174 ~151 ~588 minecraft:redstone_wire replace
fill ~177 ~151 ~576 ~177 ~151 ~588 minecraft:redstone_wire replace
fill ~180 ~151 ~576 ~180 ~151 ~588 minecraft:redstone_wire replace
fill ~183 ~151 ~576 ~183 ~151 ~588 minecraft:redstone_wire replace
fill ~186 ~151 ~576 ~186 ~151 ~588 minecraft:redstone_wire replace
fill ~189 ~151 ~576 ~189 ~151 ~588 minecraft:redstone_wire replace
fill ~192 ~151 ~576 ~192 ~151 ~588 minecraft:redstone_wire replace
fill ~195 ~151 ~576 ~195 ~151 ~588 minecraft:redstone_wire replace
fill ~198 ~151 ~576 ~198 ~151 ~588 minecraft:redstone_wire replace
fill ~201 ~151 ~576 ~201 ~151 ~588 minecraft:redstone_wire replace
fill ~204 ~151 ~576 ~204 ~151 ~588 minecraft:redstone_wire replace
fill ~207 ~151 ~576 ~207 ~151 ~588 minecraft:redstone_wire replace
fill ~210 ~151 ~576 ~210 ~151 ~588 minecraft:redstone_wire replace
fill ~213 ~151 ~576 ~213 ~151 ~588 minecraft:redstone_wire replace
fill ~216 ~151 ~576 ~216 ~151 ~588 minecraft:redstone_wire replace
fill ~219 ~151 ~576 ~219 ~151 ~588 minecraft:redstone_wire replace
fill ~222 ~151 ~576 ~222 ~151 ~588 minecraft:redstone_wire replace
fill ~225 ~151 ~576 ~225 ~151 ~588 minecraft:redstone_wire replace
fill ~228 ~151 ~576 ~228 ~151 ~588 minecraft:redstone_wire replace
fill ~252 ~151 ~576 ~252 ~151 ~580 minecraft:redstone_wire replace
setblock ~246 ~151 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~255 ~151 ~582 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~151 ~584 ~246 ~151 ~596 minecraft:redstone_wire replace
fill ~255 ~151 ~584 ~255 ~151 ~596 minecraft:redstone_wire replace
setblock ~84 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~87 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~90 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~93 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~96 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~99 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~105 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~108 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~111 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~114 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~132 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~135 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~141 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~144 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~150 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~151 ~590 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
