fill ~194 ~165 ~634 ~204 ~165 ~634 minecraft:redstone_wire replace
setblock ~205 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~634 ~216 ~165 ~634 minecraft:redstone_wire replace
setblock ~217 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~634 ~228 ~165 ~634 minecraft:redstone_wire replace
setblock ~229 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~634 ~240 ~165 ~634 minecraft:redstone_wire replace
setblock ~241 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~634 ~252 ~165 ~634 minecraft:redstone_wire replace
setblock ~253 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~634 ~264 ~165 ~634 minecraft:redstone_wire replace
setblock ~265 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~634 ~276 ~165 ~634 minecraft:redstone_wire replace
setblock ~277 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~634 ~288 ~165 ~634 minecraft:redstone_wire replace
setblock ~289 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~634 ~300 ~165 ~634 minecraft:redstone_wire replace
setblock ~301 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~634 ~312 ~165 ~634 minecraft:redstone_wire replace
setblock ~313 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~634 ~324 ~165 ~634 minecraft:redstone_wire replace
setblock ~325 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~634 ~336 ~165 ~634 minecraft:redstone_wire replace
setblock ~337 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~634 ~348 ~165 ~634 minecraft:redstone_wire replace
setblock ~349 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~634 ~360 ~165 ~634 minecraft:redstone_wire replace
setblock ~361 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~634 ~372 ~165 ~634 minecraft:redstone_wire replace
setblock ~373 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~634 ~384 ~165 ~634 minecraft:redstone_wire replace
setblock ~385 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~634 ~396 ~165 ~634 minecraft:redstone_wire replace
setblock ~397 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~634 ~408 ~165 ~634 minecraft:redstone_wire replace
setblock ~409 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~634 ~420 ~165 ~634 minecraft:redstone_wire replace
setblock ~421 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~634 ~432 ~165 ~634 minecraft:redstone_wire replace
setblock ~433 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~634 ~444 ~165 ~634 minecraft:redstone_wire replace
setblock ~445 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~634 ~456 ~165 ~634 minecraft:redstone_wire replace
setblock ~457 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~458 ~165 ~634 ~468 ~165 ~634 minecraft:redstone_wire replace
setblock ~469 ~165 ~634 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~470 ~165 ~634 ~473 ~165 ~634 minecraft:redstone_wire replace
setblock ~124 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~125 ~165 ~662 ~135 ~165 ~662 minecraft:redstone_wire replace
setblock ~136 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~662 ~147 ~165 ~662 minecraft:redstone_wire replace
setblock ~148 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~662 ~159 ~165 ~662 minecraft:redstone_wire replace
setblock ~160 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~662 ~171 ~165 ~662 minecraft:redstone_wire replace
setblock ~172 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~662 ~183 ~165 ~662 minecraft:redstone_wire replace
setblock ~184 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~662 ~195 ~165 ~662 minecraft:redstone_wire replace
setblock ~196 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~662 ~207 ~165 ~662 minecraft:redstone_wire replace
setblock ~208 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~662 ~219 ~165 ~662 minecraft:redstone_wire replace
setblock ~220 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~662 ~231 ~165 ~662 minecraft:redstone_wire replace
setblock ~232 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~662 ~243 ~165 ~662 minecraft:redstone_wire replace
setblock ~244 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~662 ~255 ~165 ~662 minecraft:redstone_wire replace
setblock ~256 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~662 ~267 ~165 ~662 minecraft:redstone_wire replace
setblock ~268 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~662 ~279 ~165 ~662 minecraft:redstone_wire replace
setblock ~280 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~662 ~291 ~165 ~662 minecraft:redstone_wire replace
setblock ~292 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~662 ~303 ~165 ~662 minecraft:redstone_wire replace
setblock ~304 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~662 ~315 ~165 ~662 minecraft:redstone_wire replace
setblock ~316 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~662 ~327 ~165 ~662 minecraft:redstone_wire replace
setblock ~328 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~662 ~339 ~165 ~662 minecraft:redstone_wire replace
setblock ~340 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~662 ~351 ~165 ~662 minecraft:redstone_wire replace
setblock ~352 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~662 ~363 ~165 ~662 minecraft:redstone_wire replace
setblock ~364 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~662 ~375 ~165 ~662 minecraft:redstone_wire replace
setblock ~376 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~662 ~387 ~165 ~662 minecraft:redstone_wire replace
setblock ~388 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~662 ~399 ~165 ~662 minecraft:redstone_wire replace
setblock ~400 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~662 ~411 ~165 ~662 minecraft:redstone_wire replace
setblock ~412 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~662 ~423 ~165 ~662 minecraft:redstone_wire replace
setblock ~424 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~662 ~435 ~165 ~662 minecraft:redstone_wire replace
setblock ~436 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~662 ~447 ~165 ~662 minecraft:redstone_wire replace
setblock ~448 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~449 ~165 ~662 ~459 ~165 ~662 minecraft:redstone_wire replace
setblock ~460 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~461 ~165 ~662 ~471 ~165 ~662 minecraft:redstone_wire replace
setblock ~472 ~165 ~662 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~473 ~165 ~662 ~475 ~165 ~662 minecraft:redstone_wire replace
setblock ~127 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~128 ~165 ~678 ~138 ~165 ~678 minecraft:redstone_wire replace
setblock ~139 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~140 ~165 ~678 ~150 ~165 ~678 minecraft:redstone_wire replace
setblock ~151 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~152 ~165 ~678 ~162 ~165 ~678 minecraft:redstone_wire replace
setblock ~163 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~678 ~174 ~165 ~678 minecraft:redstone_wire replace
setblock ~175 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~678 ~186 ~165 ~678 minecraft:redstone_wire replace
setblock ~187 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~678 ~198 ~165 ~678 minecraft:redstone_wire replace
setblock ~199 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~678 ~210 ~165 ~678 minecraft:redstone_wire replace
setblock ~211 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~678 ~222 ~165 ~678 minecraft:redstone_wire replace
setblock ~223 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~678 ~234 ~165 ~678 minecraft:redstone_wire replace
setblock ~235 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~678 ~246 ~165 ~678 minecraft:redstone_wire replace
setblock ~247 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~678 ~258 ~165 ~678 minecraft:redstone_wire replace
setblock ~259 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~678 ~270 ~165 ~678 minecraft:redstone_wire replace
setblock ~271 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~678 ~282 ~165 ~678 minecraft:redstone_wire replace
setblock ~283 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~678 ~294 ~165 ~678 minecraft:redstone_wire replace
setblock ~295 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~678 ~306 ~165 ~678 minecraft:redstone_wire replace
setblock ~307 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~678 ~318 ~165 ~678 minecraft:redstone_wire replace
setblock ~319 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~678 ~330 ~165 ~678 minecraft:redstone_wire replace
setblock ~331 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~678 ~342 ~165 ~678 minecraft:redstone_wire replace
setblock ~343 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~678 ~354 ~165 ~678 minecraft:redstone_wire replace
setblock ~355 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~678 ~366 ~165 ~678 minecraft:redstone_wire replace
setblock ~367 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~678 ~378 ~165 ~678 minecraft:redstone_wire replace
setblock ~379 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~678 ~390 ~165 ~678 minecraft:redstone_wire replace
setblock ~391 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~678 ~402 ~165 ~678 minecraft:redstone_wire replace
setblock ~403 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~678 ~414 ~165 ~678 minecraft:redstone_wire replace
setblock ~415 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~678 ~426 ~165 ~678 minecraft:redstone_wire replace
setblock ~427 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~678 ~438 ~165 ~678 minecraft:redstone_wire replace
setblock ~439 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~678 ~450 ~165 ~678 minecraft:redstone_wire replace
setblock ~451 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~452 ~165 ~678 ~462 ~165 ~678 minecraft:redstone_wire replace
setblock ~463 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~464 ~165 ~678 ~474 ~165 ~678 minecraft:redstone_wire replace
setblock ~475 ~165 ~678 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~476 ~165 ~678 ~477 ~165 ~678 minecraft:redstone_wire replace
setblock ~130 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~131 ~165 ~702 ~141 ~165 ~702 minecraft:redstone_wire replace
setblock ~142 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~143 ~165 ~702 ~153 ~165 ~702 minecraft:redstone_wire replace
setblock ~154 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~702 ~165 ~165 ~702 minecraft:redstone_wire replace
setblock ~166 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~702 ~177 ~165 ~702 minecraft:redstone_wire replace
setblock ~178 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~702 ~189 ~165 ~702 minecraft:redstone_wire replace
setblock ~190 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~702 ~201 ~165 ~702 minecraft:redstone_wire replace
setblock ~202 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~702 ~213 ~165 ~702 minecraft:redstone_wire replace
setblock ~214 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~702 ~225 ~165 ~702 minecraft:redstone_wire replace
setblock ~226 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~702 ~237 ~165 ~702 minecraft:redstone_wire replace
setblock ~238 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~702 ~249 ~165 ~702 minecraft:redstone_wire replace
setblock ~250 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~702 ~261 ~165 ~702 minecraft:redstone_wire replace
setblock ~262 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~702 ~273 ~165 ~702 minecraft:redstone_wire replace
setblock ~274 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~702 ~285 ~165 ~702 minecraft:redstone_wire replace
setblock ~286 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~702 ~297 ~165 ~702 minecraft:redstone_wire replace
setblock ~298 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~702 ~309 ~165 ~702 minecraft:redstone_wire replace
setblock ~310 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~702 ~321 ~165 ~702 minecraft:redstone_wire replace
setblock ~322 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~702 ~333 ~165 ~702 minecraft:redstone_wire replace
setblock ~334 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~702 ~345 ~165 ~702 minecraft:redstone_wire replace
setblock ~346 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~702 ~357 ~165 ~702 minecraft:redstone_wire replace
setblock ~358 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~702 ~369 ~165 ~702 minecraft:redstone_wire replace
setblock ~370 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~702 ~381 ~165 ~702 minecraft:redstone_wire replace
setblock ~382 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~702 ~393 ~165 ~702 minecraft:redstone_wire replace
setblock ~394 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~702 ~405 ~165 ~702 minecraft:redstone_wire replace
setblock ~406 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~702 ~417 ~165 ~702 minecraft:redstone_wire replace
setblock ~418 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~702 ~429 ~165 ~702 minecraft:redstone_wire replace
setblock ~430 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~702 ~441 ~165 ~702 minecraft:redstone_wire replace
setblock ~442 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~702 ~453 ~165 ~702 minecraft:redstone_wire replace
setblock ~454 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~455 ~165 ~702 ~465 ~165 ~702 minecraft:redstone_wire replace
setblock ~466 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~467 ~165 ~702 ~477 ~165 ~702 minecraft:redstone_wire replace
setblock ~478 ~165 ~702 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~479 ~165 ~702 minecraft:redstone_wire replace
setblock ~154 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~155 ~165 ~730 ~165 ~165 ~730 minecraft:redstone_wire replace
setblock ~166 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~730 ~177 ~165 ~730 minecraft:redstone_wire replace
setblock ~178 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~730 ~189 ~165 ~730 minecraft:redstone_wire replace
setblock ~190 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~730 ~201 ~165 ~730 minecraft:redstone_wire replace
setblock ~202 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~730 ~213 ~165 ~730 minecraft:redstone_wire replace
setblock ~214 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~730 ~225 ~165 ~730 minecraft:redstone_wire replace
setblock ~226 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~730 ~237 ~165 ~730 minecraft:redstone_wire replace
setblock ~238 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~730 ~249 ~165 ~730 minecraft:redstone_wire replace
setblock ~250 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~730 ~261 ~165 ~730 minecraft:redstone_wire replace
setblock ~262 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~730 ~273 ~165 ~730 minecraft:redstone_wire replace
setblock ~274 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~730 ~285 ~165 ~730 minecraft:redstone_wire replace
setblock ~286 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~730 ~297 ~165 ~730 minecraft:redstone_wire replace
setblock ~298 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~730 ~309 ~165 ~730 minecraft:redstone_wire replace
setblock ~310 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~730 ~321 ~165 ~730 minecraft:redstone_wire replace
setblock ~322 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~730 ~333 ~165 ~730 minecraft:redstone_wire replace
setblock ~334 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~730 ~345 ~165 ~730 minecraft:redstone_wire replace
setblock ~346 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~730 ~357 ~165 ~730 minecraft:redstone_wire replace
setblock ~358 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~730 ~369 ~165 ~730 minecraft:redstone_wire replace
setblock ~370 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~730 ~381 ~165 ~730 minecraft:redstone_wire replace
setblock ~382 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~730 ~393 ~165 ~730 minecraft:redstone_wire replace
setblock ~394 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~730 ~405 ~165 ~730 minecraft:redstone_wire replace
setblock ~406 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~730 ~417 ~165 ~730 minecraft:redstone_wire replace
setblock ~418 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~730 ~429 ~165 ~730 minecraft:redstone_wire replace
setblock ~430 ~165 ~730 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~730 ~439 ~165 ~730 minecraft:redstone_wire replace
setblock ~157 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~734 ~168 ~165 ~734 minecraft:redstone_wire replace
setblock ~169 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~734 ~180 ~165 ~734 minecraft:redstone_wire replace
setblock ~181 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~734 ~192 ~165 ~734 minecraft:redstone_wire replace
setblock ~193 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~734 ~204 ~165 ~734 minecraft:redstone_wire replace
setblock ~205 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~734 ~216 ~165 ~734 minecraft:redstone_wire replace
setblock ~217 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~734 ~228 ~165 ~734 minecraft:redstone_wire replace
setblock ~229 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~734 ~240 ~165 ~734 minecraft:redstone_wire replace
setblock ~241 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~734 ~252 ~165 ~734 minecraft:redstone_wire replace
setblock ~253 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~734 ~264 ~165 ~734 minecraft:redstone_wire replace
setblock ~265 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~734 ~276 ~165 ~734 minecraft:redstone_wire replace
setblock ~277 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~734 ~288 ~165 ~734 minecraft:redstone_wire replace
setblock ~289 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~734 ~300 ~165 ~734 minecraft:redstone_wire replace
setblock ~301 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~734 ~312 ~165 ~734 minecraft:redstone_wire replace
setblock ~313 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~734 ~324 ~165 ~734 minecraft:redstone_wire replace
setblock ~325 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~734 ~336 ~165 ~734 minecraft:redstone_wire replace
setblock ~337 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~734 ~348 ~165 ~734 minecraft:redstone_wire replace
setblock ~349 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~734 ~360 ~165 ~734 minecraft:redstone_wire replace
setblock ~361 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~734 ~372 ~165 ~734 minecraft:redstone_wire replace
setblock ~373 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~734 ~384 ~165 ~734 minecraft:redstone_wire replace
setblock ~385 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~734 ~396 ~165 ~734 minecraft:redstone_wire replace
setblock ~397 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~734 ~408 ~165 ~734 minecraft:redstone_wire replace
setblock ~409 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~734 ~420 ~165 ~734 minecraft:redstone_wire replace
setblock ~421 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~734 ~432 ~165 ~734 minecraft:redstone_wire replace
setblock ~433 ~165 ~734 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~734 ~441 ~165 ~734 minecraft:redstone_wire replace
setblock ~160 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~742 ~171 ~165 ~742 minecraft:redstone_wire replace
setblock ~172 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~742 ~183 ~165 ~742 minecraft:redstone_wire replace
setblock ~184 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~742 ~195 ~165 ~742 minecraft:redstone_wire replace
setblock ~196 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~742 ~207 ~165 ~742 minecraft:redstone_wire replace
setblock ~208 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~742 ~219 ~165 ~742 minecraft:redstone_wire replace
setblock ~220 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~742 ~231 ~165 ~742 minecraft:redstone_wire replace
setblock ~232 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~742 ~243 ~165 ~742 minecraft:redstone_wire replace
setblock ~244 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~742 ~255 ~165 ~742 minecraft:redstone_wire replace
setblock ~256 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~742 ~267 ~165 ~742 minecraft:redstone_wire replace
setblock ~268 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~742 ~279 ~165 ~742 minecraft:redstone_wire replace
setblock ~280 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~742 ~291 ~165 ~742 minecraft:redstone_wire replace
setblock ~292 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~742 ~303 ~165 ~742 minecraft:redstone_wire replace
setblock ~304 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~742 ~315 ~165 ~742 minecraft:redstone_wire replace
setblock ~316 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~317 ~165 ~742 ~327 ~165 ~742 minecraft:redstone_wire replace
setblock ~328 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~329 ~165 ~742 ~339 ~165 ~742 minecraft:redstone_wire replace
setblock ~340 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~341 ~165 ~742 ~351 ~165 ~742 minecraft:redstone_wire replace
setblock ~352 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~353 ~165 ~742 ~363 ~165 ~742 minecraft:redstone_wire replace
setblock ~364 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~365 ~165 ~742 ~375 ~165 ~742 minecraft:redstone_wire replace
setblock ~376 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~377 ~165 ~742 ~387 ~165 ~742 minecraft:redstone_wire replace
setblock ~388 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~389 ~165 ~742 ~399 ~165 ~742 minecraft:redstone_wire replace
setblock ~400 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~401 ~165 ~742 ~411 ~165 ~742 minecraft:redstone_wire replace
setblock ~412 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~413 ~165 ~742 ~423 ~165 ~742 minecraft:redstone_wire replace
setblock ~424 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~425 ~165 ~742 ~435 ~165 ~742 minecraft:redstone_wire replace
setblock ~436 ~165 ~742 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~437 ~165 ~742 ~443 ~165 ~742 minecraft:redstone_wire replace
setblock ~163 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~164 ~165 ~750 ~174 ~165 ~750 minecraft:redstone_wire replace
setblock ~175 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~176 ~165 ~750 ~186 ~165 ~750 minecraft:redstone_wire replace
setblock ~187 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~188 ~165 ~750 ~198 ~165 ~750 minecraft:redstone_wire replace
setblock ~199 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~200 ~165 ~750 ~210 ~165 ~750 minecraft:redstone_wire replace
setblock ~211 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~212 ~165 ~750 ~222 ~165 ~750 minecraft:redstone_wire replace
setblock ~223 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~224 ~165 ~750 ~234 ~165 ~750 minecraft:redstone_wire replace
setblock ~235 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~236 ~165 ~750 ~246 ~165 ~750 minecraft:redstone_wire replace
setblock ~247 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~248 ~165 ~750 ~258 ~165 ~750 minecraft:redstone_wire replace
setblock ~259 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~260 ~165 ~750 ~270 ~165 ~750 minecraft:redstone_wire replace
setblock ~271 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~272 ~165 ~750 ~282 ~165 ~750 minecraft:redstone_wire replace
setblock ~283 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~284 ~165 ~750 ~294 ~165 ~750 minecraft:redstone_wire replace
setblock ~295 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~296 ~165 ~750 ~306 ~165 ~750 minecraft:redstone_wire replace
setblock ~307 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~308 ~165 ~750 ~318 ~165 ~750 minecraft:redstone_wire replace
setblock ~319 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~320 ~165 ~750 ~330 ~165 ~750 minecraft:redstone_wire replace
setblock ~331 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~332 ~165 ~750 ~342 ~165 ~750 minecraft:redstone_wire replace
setblock ~343 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~344 ~165 ~750 ~354 ~165 ~750 minecraft:redstone_wire replace
setblock ~355 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~356 ~165 ~750 ~366 ~165 ~750 minecraft:redstone_wire replace
setblock ~367 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~368 ~165 ~750 ~378 ~165 ~750 minecraft:redstone_wire replace
setblock ~379 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~380 ~165 ~750 ~390 ~165 ~750 minecraft:redstone_wire replace
setblock ~391 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~392 ~165 ~750 ~402 ~165 ~750 minecraft:redstone_wire replace
setblock ~403 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~404 ~165 ~750 ~414 ~165 ~750 minecraft:redstone_wire replace
setblock ~415 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~416 ~165 ~750 ~426 ~165 ~750 minecraft:redstone_wire replace
setblock ~427 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~428 ~165 ~750 ~438 ~165 ~750 minecraft:redstone_wire replace
setblock ~439 ~165 ~750 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~440 ~165 ~750 ~445 ~165 ~750 minecraft:redstone_wire replace
setblock ~166 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~167 ~165 ~754 ~177 ~165 ~754 minecraft:redstone_wire replace
setblock ~178 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~179 ~165 ~754 ~189 ~165 ~754 minecraft:redstone_wire replace
setblock ~190 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~191 ~165 ~754 ~201 ~165 ~754 minecraft:redstone_wire replace
setblock ~202 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~203 ~165 ~754 ~213 ~165 ~754 minecraft:redstone_wire replace
setblock ~214 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~215 ~165 ~754 ~225 ~165 ~754 minecraft:redstone_wire replace
setblock ~226 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~227 ~165 ~754 ~237 ~165 ~754 minecraft:redstone_wire replace
setblock ~238 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~239 ~165 ~754 ~249 ~165 ~754 minecraft:redstone_wire replace
setblock ~250 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~251 ~165 ~754 ~261 ~165 ~754 minecraft:redstone_wire replace
setblock ~262 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~263 ~165 ~754 ~273 ~165 ~754 minecraft:redstone_wire replace
setblock ~274 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~275 ~165 ~754 ~285 ~165 ~754 minecraft:redstone_wire replace
setblock ~286 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~287 ~165 ~754 ~297 ~165 ~754 minecraft:redstone_wire replace
setblock ~298 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~299 ~165 ~754 ~309 ~165 ~754 minecraft:redstone_wire replace
setblock ~310 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~311 ~165 ~754 ~321 ~165 ~754 minecraft:redstone_wire replace
setblock ~322 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~323 ~165 ~754 ~333 ~165 ~754 minecraft:redstone_wire replace
setblock ~334 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~335 ~165 ~754 ~345 ~165 ~754 minecraft:redstone_wire replace
setblock ~346 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~347 ~165 ~754 ~357 ~165 ~754 minecraft:redstone_wire replace
setblock ~358 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~359 ~165 ~754 ~369 ~165 ~754 minecraft:redstone_wire replace
setblock ~370 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~371 ~165 ~754 ~381 ~165 ~754 minecraft:redstone_wire replace
setblock ~382 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~383 ~165 ~754 ~393 ~165 ~754 minecraft:redstone_wire replace
setblock ~394 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~395 ~165 ~754 ~405 ~165 ~754 minecraft:redstone_wire replace
setblock ~406 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~407 ~165 ~754 ~417 ~165 ~754 minecraft:redstone_wire replace
setblock ~418 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~419 ~165 ~754 ~429 ~165 ~754 minecraft:redstone_wire replace
setblock ~430 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~431 ~165 ~754 ~441 ~165 ~754 minecraft:redstone_wire replace
setblock ~442 ~165 ~754 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~443 ~165 ~754 ~447 ~165 ~754 minecraft:redstone_wire replace
setblock ~169 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~758 ~180 ~165 ~758 minecraft:redstone_wire replace
setblock ~181 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~758 ~192 ~165 ~758 minecraft:redstone_wire replace
setblock ~193 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~758 ~204 ~165 ~758 minecraft:redstone_wire replace
setblock ~205 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~758 ~216 ~165 ~758 minecraft:redstone_wire replace
setblock ~217 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~758 ~228 ~165 ~758 minecraft:redstone_wire replace
setblock ~229 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~758 ~240 ~165 ~758 minecraft:redstone_wire replace
setblock ~241 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~758 ~252 ~165 ~758 minecraft:redstone_wire replace
setblock ~253 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~758 ~264 ~165 ~758 minecraft:redstone_wire replace
setblock ~265 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~758 ~276 ~165 ~758 minecraft:redstone_wire replace
setblock ~277 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~758 ~288 ~165 ~758 minecraft:redstone_wire replace
setblock ~289 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~758 ~300 ~165 ~758 minecraft:redstone_wire replace
setblock ~301 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~758 ~312 ~165 ~758 minecraft:redstone_wire replace
setblock ~313 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~758 ~324 ~165 ~758 minecraft:redstone_wire replace
setblock ~325 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~758 ~336 ~165 ~758 minecraft:redstone_wire replace
setblock ~337 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~758 ~348 ~165 ~758 minecraft:redstone_wire replace
setblock ~349 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~758 ~360 ~165 ~758 minecraft:redstone_wire replace
setblock ~361 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~758 ~372 ~165 ~758 minecraft:redstone_wire replace
setblock ~373 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~758 ~384 ~165 ~758 minecraft:redstone_wire replace
setblock ~385 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~758 ~396 ~165 ~758 minecraft:redstone_wire replace
setblock ~397 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~758 ~408 ~165 ~758 minecraft:redstone_wire replace
setblock ~409 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~758 ~420 ~165 ~758 minecraft:redstone_wire replace
setblock ~421 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~758 ~432 ~165 ~758 minecraft:redstone_wire replace
setblock ~433 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~758 ~444 ~165 ~758 minecraft:redstone_wire replace
setblock ~445 ~165 ~758 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~758 ~449 ~165 ~758 minecraft:redstone_wire replace
setblock ~133 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~134 ~165 ~762 ~144 ~165 ~762 minecraft:redstone_wire replace
setblock ~145 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~146 ~165 ~762 ~156 ~165 ~762 minecraft:redstone_wire replace
setblock ~157 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~158 ~165 ~762 ~168 ~165 ~762 minecraft:redstone_wire replace
setblock ~169 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~170 ~165 ~762 ~180 ~165 ~762 minecraft:redstone_wire replace
setblock ~181 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~182 ~165 ~762 ~192 ~165 ~762 minecraft:redstone_wire replace
setblock ~193 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~194 ~165 ~762 ~204 ~165 ~762 minecraft:redstone_wire replace
setblock ~205 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~206 ~165 ~762 ~216 ~165 ~762 minecraft:redstone_wire replace
setblock ~217 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~218 ~165 ~762 ~228 ~165 ~762 minecraft:redstone_wire replace
setblock ~229 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~230 ~165 ~762 ~240 ~165 ~762 minecraft:redstone_wire replace
setblock ~241 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~242 ~165 ~762 ~252 ~165 ~762 minecraft:redstone_wire replace
setblock ~253 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~254 ~165 ~762 ~264 ~165 ~762 minecraft:redstone_wire replace
setblock ~265 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~266 ~165 ~762 ~276 ~165 ~762 minecraft:redstone_wire replace
setblock ~277 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~278 ~165 ~762 ~288 ~165 ~762 minecraft:redstone_wire replace
setblock ~289 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~290 ~165 ~762 ~300 ~165 ~762 minecraft:redstone_wire replace
setblock ~301 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~302 ~165 ~762 ~312 ~165 ~762 minecraft:redstone_wire replace
setblock ~313 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~314 ~165 ~762 ~324 ~165 ~762 minecraft:redstone_wire replace
setblock ~325 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~326 ~165 ~762 ~336 ~165 ~762 minecraft:redstone_wire replace
setblock ~337 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~338 ~165 ~762 ~348 ~165 ~762 minecraft:redstone_wire replace
setblock ~349 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~350 ~165 ~762 ~360 ~165 ~762 minecraft:redstone_wire replace
setblock ~361 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~362 ~165 ~762 ~372 ~165 ~762 minecraft:redstone_wire replace
setblock ~373 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~374 ~165 ~762 ~384 ~165 ~762 minecraft:redstone_wire replace
setblock ~385 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~386 ~165 ~762 ~396 ~165 ~762 minecraft:redstone_wire replace
setblock ~397 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~398 ~165 ~762 ~408 ~165 ~762 minecraft:redstone_wire replace
setblock ~409 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~410 ~165 ~762 ~420 ~165 ~762 minecraft:redstone_wire replace
setblock ~421 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~422 ~165 ~762 ~432 ~165 ~762 minecraft:redstone_wire replace
setblock ~433 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~434 ~165 ~762 ~444 ~165 ~762 minecraft:redstone_wire replace
setblock ~445 ~165 ~762 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~446 ~165 ~762 ~453 ~165 ~762 minecraft:redstone_wire replace
setblock ~136 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~137 ~165 ~794 ~147 ~165 ~794 minecraft:redstone_wire replace
setblock ~148 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~149 ~165 ~794 ~159 ~165 ~794 minecraft:redstone_wire replace
setblock ~160 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~161 ~165 ~794 ~171 ~165 ~794 minecraft:redstone_wire replace
setblock ~172 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~173 ~165 ~794 ~183 ~165 ~794 minecraft:redstone_wire replace
setblock ~184 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~185 ~165 ~794 ~195 ~165 ~794 minecraft:redstone_wire replace
setblock ~196 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~197 ~165 ~794 ~207 ~165 ~794 minecraft:redstone_wire replace
setblock ~208 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~209 ~165 ~794 ~219 ~165 ~794 minecraft:redstone_wire replace
setblock ~220 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~221 ~165 ~794 ~231 ~165 ~794 minecraft:redstone_wire replace
setblock ~232 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~233 ~165 ~794 ~243 ~165 ~794 minecraft:redstone_wire replace
setblock ~244 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~245 ~165 ~794 ~255 ~165 ~794 minecraft:redstone_wire replace
setblock ~256 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~257 ~165 ~794 ~267 ~165 ~794 minecraft:redstone_wire replace
setblock ~268 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~269 ~165 ~794 ~279 ~165 ~794 minecraft:redstone_wire replace
setblock ~280 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~281 ~165 ~794 ~291 ~165 ~794 minecraft:redstone_wire replace
setblock ~292 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~293 ~165 ~794 ~303 ~165 ~794 minecraft:redstone_wire replace
setblock ~304 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
fill ~305 ~165 ~794 ~315 ~165 ~794 minecraft:redstone_wire replace
setblock ~316 ~165 ~794 minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
