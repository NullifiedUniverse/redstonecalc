setblock ~117 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~261 ~55 ~362 ~261 ~55 ~372 minecraft:redstone_wire replace
fill ~93 ~55 ~364 ~93 ~55 ~376 minecraft:redstone_wire replace
fill ~117 ~55 ~364 ~117 ~55 ~376 minecraft:redstone_wire replace
fill ~138 ~55 ~364 ~138 ~55 ~376 minecraft:redstone_wire replace
fill ~153 ~55 ~364 ~153 ~55 ~376 minecraft:redstone_wire replace
fill ~168 ~55 ~364 ~168 ~55 ~376 minecraft:redstone_wire replace
setblock ~306 ~55 ~364 minecraft:redstone_wire replace
setblock ~306 ~55 ~365 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~306 ~55 ~366 ~306 ~55 ~378 minecraft:redstone_wire replace
setblock ~270 ~55 ~368 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~55 ~370 ~270 ~55 ~378 minecraft:redstone_wire replace
setblock ~237 ~55 ~372 minecraft:redstone_wire replace
setblock ~237 ~55 ~374 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~234 ~55 ~376 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~55 ~376 ~237 ~55 ~388 minecraft:redstone_wire replace
setblock ~93 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~234 ~55 ~378 ~234 ~55 ~388 minecraft:redstone_wire replace
setblock ~270 ~55 ~379 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~306 ~55 ~379 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~380 ~93 ~55 ~392 minecraft:redstone_wire replace
fill ~117 ~55 ~380 ~117 ~55 ~392 minecraft:redstone_wire replace
fill ~138 ~55 ~380 ~138 ~55 ~392 minecraft:redstone_wire replace
fill ~153 ~55 ~380 ~153 ~55 ~392 minecraft:redstone_wire replace
fill ~168 ~55 ~380 ~168 ~55 ~392 minecraft:redstone_wire replace
fill ~270 ~55 ~380 ~270 ~55 ~392 minecraft:redstone_wire replace
fill ~306 ~55 ~380 ~306 ~55 ~392 minecraft:redstone_wire replace
fill ~309 ~55 ~392 ~309 ~55 ~396 minecraft:redstone_wire replace
setblock ~93 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~270 ~55 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~396 ~93 ~55 ~408 minecraft:redstone_wire replace
fill ~117 ~55 ~396 ~117 ~55 ~408 minecraft:redstone_wire replace
fill ~138 ~55 ~396 ~138 ~55 ~408 minecraft:redstone_wire replace
fill ~153 ~55 ~396 ~153 ~55 ~408 minecraft:redstone_wire replace
fill ~168 ~55 ~396 ~168 ~55 ~408 minecraft:redstone_wire replace
fill ~270 ~55 ~396 ~270 ~55 ~408 minecraft:redstone_wire replace
fill ~276 ~55 ~396 ~276 ~55 ~400 minecraft:redstone_wire replace
fill ~297 ~55 ~400 ~297 ~55 ~404 minecraft:redstone_wire replace
setblock ~93 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~55 ~412 ~90 ~55 ~416 minecraft:redstone_wire replace
fill ~93 ~55 ~412 ~93 ~55 ~424 minecraft:redstone_wire replace
fill ~117 ~55 ~412 ~117 ~55 ~424 minecraft:redstone_wire replace
fill ~138 ~55 ~412 ~138 ~55 ~424 minecraft:redstone_wire replace
fill ~153 ~55 ~412 ~153 ~55 ~424 minecraft:redstone_wire replace
fill ~168 ~55 ~412 ~168 ~55 ~424 minecraft:redstone_wire replace
fill ~114 ~55 ~416 ~114 ~55 ~420 minecraft:redstone_wire replace
fill ~135 ~55 ~420 ~135 ~55 ~424 minecraft:redstone_wire replace
fill ~159 ~55 ~424 ~159 ~55 ~428 minecraft:redstone_wire replace
setblock ~93 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~428 ~93 ~55 ~440 minecraft:redstone_wire replace
fill ~117 ~55 ~428 ~117 ~55 ~440 minecraft:redstone_wire replace
fill ~138 ~55 ~428 ~138 ~55 ~440 minecraft:redstone_wire replace
fill ~153 ~55 ~428 ~153 ~55 ~440 minecraft:redstone_wire replace
fill ~168 ~55 ~428 ~168 ~55 ~440 minecraft:redstone_wire replace
fill ~180 ~55 ~428 ~180 ~55 ~432 minecraft:redstone_wire replace
fill ~204 ~55 ~432 ~204 ~55 ~436 minecraft:redstone_wire replace
fill ~231 ~55 ~436 ~231 ~55 ~440 minecraft:redstone_wire replace
fill ~255 ~55 ~440 ~255 ~55 ~444 minecraft:redstone_wire replace
setblock ~93 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~444 ~93 ~55 ~456 minecraft:redstone_wire replace
fill ~117 ~55 ~444 ~117 ~55 ~456 minecraft:redstone_wire replace
fill ~138 ~55 ~444 ~138 ~55 ~456 minecraft:redstone_wire replace
fill ~153 ~55 ~444 ~153 ~55 ~456 minecraft:redstone_wire replace
fill ~168 ~55 ~444 ~168 ~55 ~456 minecraft:redstone_wire replace
fill ~267 ~55 ~444 ~267 ~55 ~448 minecraft:redstone_wire replace
fill ~87 ~55 ~448 ~87 ~55 ~452 minecraft:redstone_wire replace
fill ~111 ~55 ~452 ~111 ~55 ~456 minecraft:redstone_wire replace
fill ~132 ~55 ~456 ~132 ~55 ~460 minecraft:redstone_wire replace
setblock ~93 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~460 ~93 ~55 ~472 minecraft:redstone_wire replace
fill ~117 ~55 ~460 ~117 ~55 ~472 minecraft:redstone_wire replace
fill ~138 ~55 ~460 ~138 ~55 ~472 minecraft:redstone_wire replace
fill ~153 ~55 ~460 ~153 ~55 ~472 minecraft:redstone_wire replace
fill ~156 ~55 ~460 ~156 ~55 ~464 minecraft:redstone_wire replace
fill ~168 ~55 ~460 ~168 ~55 ~472 minecraft:redstone_wire replace
fill ~177 ~55 ~464 ~177 ~55 ~468 minecraft:redstone_wire replace
fill ~201 ~55 ~468 ~201 ~55 ~472 minecraft:redstone_wire replace
fill ~225 ~55 ~472 ~225 ~55 ~476 minecraft:redstone_wire replace
setblock ~93 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~476 ~93 ~55 ~488 minecraft:redstone_wire replace
fill ~117 ~55 ~476 ~117 ~55 ~488 minecraft:redstone_wire replace
fill ~138 ~55 ~476 ~138 ~55 ~488 minecraft:redstone_wire replace
fill ~153 ~55 ~476 ~153 ~55 ~488 minecraft:redstone_wire replace
fill ~168 ~55 ~476 ~168 ~55 ~488 minecraft:redstone_wire replace
fill ~252 ~55 ~476 ~252 ~55 ~480 minecraft:redstone_wire replace
fill ~288 ~55 ~480 ~288 ~55 ~484 minecraft:redstone_wire replace
fill ~315 ~55 ~484 ~315 ~55 ~488 minecraft:redstone_wire replace
fill ~84 ~55 ~488 ~84 ~55 ~492 minecraft:redstone_wire replace
setblock ~93 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~492 ~93 ~55 ~504 minecraft:redstone_wire replace
fill ~108 ~55 ~492 ~108 ~55 ~496 minecraft:redstone_wire replace
fill ~117 ~55 ~492 ~117 ~55 ~504 minecraft:redstone_wire replace
fill ~138 ~55 ~492 ~138 ~55 ~504 minecraft:redstone_wire replace
fill ~153 ~55 ~492 ~153 ~55 ~504 minecraft:redstone_wire replace
fill ~168 ~55 ~492 ~168 ~55 ~504 minecraft:redstone_wire replace
fill ~129 ~55 ~496 ~129 ~55 ~500 minecraft:redstone_wire replace
fill ~150 ~55 ~500 ~150 ~55 ~504 minecraft:redstone_wire replace
fill ~174 ~55 ~504 ~174 ~55 ~508 minecraft:redstone_wire replace
setblock ~93 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~508 ~93 ~55 ~520 minecraft:redstone_wire replace
fill ~117 ~55 ~508 ~117 ~55 ~520 minecraft:redstone_wire replace
fill ~138 ~55 ~508 ~138 ~55 ~520 minecraft:redstone_wire replace
fill ~153 ~55 ~508 ~153 ~55 ~520 minecraft:redstone_wire replace
fill ~168 ~55 ~508 ~168 ~55 ~520 minecraft:redstone_wire replace
fill ~198 ~55 ~508 ~198 ~55 ~512 minecraft:redstone_wire replace
fill ~222 ~55 ~512 ~222 ~55 ~516 minecraft:redstone_wire replace
fill ~249 ~55 ~516 ~249 ~55 ~520 minecraft:redstone_wire replace
fill ~285 ~55 ~520 ~285 ~55 ~524 minecraft:redstone_wire replace
setblock ~93 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~524 ~93 ~55 ~536 minecraft:redstone_wire replace
fill ~117 ~55 ~524 ~117 ~55 ~536 minecraft:redstone_wire replace
fill ~138 ~55 ~524 ~138 ~55 ~536 minecraft:redstone_wire replace
fill ~153 ~55 ~524 ~153 ~55 ~536 minecraft:redstone_wire replace
fill ~168 ~55 ~524 ~168 ~55 ~536 minecraft:redstone_wire replace
fill ~312 ~55 ~524 ~312 ~55 ~528 minecraft:redstone_wire replace
fill ~81 ~55 ~528 ~81 ~55 ~532 minecraft:redstone_wire replace
fill ~105 ~55 ~532 ~105 ~55 ~536 minecraft:redstone_wire replace
fill ~126 ~55 ~536 ~126 ~55 ~540 minecraft:redstone_wire replace
setblock ~93 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~540 ~93 ~55 ~552 minecraft:redstone_wire replace
fill ~117 ~55 ~540 ~117 ~55 ~552 minecraft:redstone_wire replace
fill ~138 ~55 ~540 ~138 ~55 ~552 minecraft:redstone_wire replace
fill ~147 ~55 ~540 ~147 ~55 ~544 minecraft:redstone_wire replace
fill ~153 ~55 ~540 ~153 ~55 ~552 minecraft:redstone_wire replace
fill ~168 ~55 ~540 ~168 ~55 ~552 minecraft:redstone_wire replace
fill ~171 ~55 ~544 ~171 ~55 ~548 minecraft:redstone_wire replace
fill ~195 ~55 ~548 ~195 ~55 ~552 minecraft:redstone_wire replace
fill ~219 ~55 ~552 ~219 ~55 ~556 minecraft:redstone_wire replace
setblock ~93 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~556 ~93 ~55 ~568 minecraft:redstone_wire replace
fill ~117 ~55 ~556 ~117 ~55 ~568 minecraft:redstone_wire replace
fill ~138 ~55 ~556 ~138 ~55 ~568 minecraft:redstone_wire replace
fill ~153 ~55 ~556 ~153 ~55 ~568 minecraft:redstone_wire replace
fill ~168 ~55 ~556 ~168 ~55 ~568 minecraft:redstone_wire replace
fill ~243 ~55 ~556 ~243 ~55 ~560 minecraft:redstone_wire replace
fill ~282 ~55 ~560 ~282 ~55 ~564 minecraft:redstone_wire replace
fill ~303 ~55 ~564 ~303 ~55 ~568 minecraft:redstone_wire replace
fill ~78 ~55 ~568 ~78 ~55 ~572 minecraft:redstone_wire replace
setblock ~93 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~572 ~93 ~55 ~584 minecraft:redstone_wire replace
fill ~102 ~55 ~572 ~102 ~55 ~576 minecraft:redstone_wire replace
fill ~117 ~55 ~572 ~117 ~55 ~584 minecraft:redstone_wire replace
fill ~138 ~55 ~572 ~138 ~55 ~584 minecraft:redstone_wire replace
fill ~153 ~55 ~572 ~153 ~55 ~584 minecraft:redstone_wire replace
fill ~168 ~55 ~572 ~168 ~55 ~584 minecraft:redstone_wire replace
fill ~123 ~55 ~576 ~123 ~55 ~580 minecraft:redstone_wire replace
fill ~144 ~55 ~580 ~144 ~55 ~584 minecraft:redstone_wire replace
fill ~165 ~55 ~584 ~165 ~55 ~588 minecraft:redstone_wire replace
setblock ~93 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~588 ~93 ~55 ~600 minecraft:redstone_wire replace
fill ~117 ~55 ~588 ~117 ~55 ~600 minecraft:redstone_wire replace
fill ~138 ~55 ~588 ~138 ~55 ~600 minecraft:redstone_wire replace
fill ~153 ~55 ~588 ~153 ~55 ~600 minecraft:redstone_wire replace
fill ~168 ~55 ~588 ~168 ~55 ~600 minecraft:redstone_wire replace
fill ~186 ~55 ~588 ~186 ~55 ~592 minecraft:redstone_wire replace
fill ~216 ~55 ~592 ~216 ~55 ~596 minecraft:redstone_wire replace
fill ~240 ~55 ~596 ~240 ~55 ~600 minecraft:redstone_wire replace
fill ~279 ~55 ~600 ~279 ~55 ~604 minecraft:redstone_wire replace
setblock ~93 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~604 ~93 ~55 ~616 minecraft:redstone_wire replace
fill ~117 ~55 ~604 ~117 ~55 ~616 minecraft:redstone_wire replace
fill ~138 ~55 ~604 ~138 ~55 ~616 minecraft:redstone_wire replace
fill ~153 ~55 ~604 ~153 ~55 ~616 minecraft:redstone_wire replace
fill ~168 ~55 ~604 ~168 ~55 ~616 minecraft:redstone_wire replace
fill ~300 ~55 ~604 ~300 ~55 ~608 minecraft:redstone_wire replace
fill ~99 ~55 ~608 ~99 ~55 ~612 minecraft:redstone_wire replace
fill ~120 ~55 ~612 ~120 ~55 ~616 minecraft:redstone_wire replace
fill ~141 ~55 ~616 ~141 ~55 ~620 minecraft:redstone_wire replace
setblock ~93 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~620 ~93 ~55 ~632 minecraft:redstone_wire replace
fill ~117 ~55 ~620 ~117 ~55 ~632 minecraft:redstone_wire replace
fill ~138 ~55 ~620 ~138 ~55 ~632 minecraft:redstone_wire replace
fill ~153 ~55 ~620 ~153 ~55 ~632 minecraft:redstone_wire replace
fill ~162 ~55 ~620 ~162 ~55 ~624 minecraft:redstone_wire replace
fill ~168 ~55 ~620 ~168 ~55 ~632 minecraft:redstone_wire replace
fill ~183 ~55 ~624 ~183 ~55 ~628 minecraft:redstone_wire replace
fill ~207 ~55 ~628 ~207 ~55 ~632 minecraft:redstone_wire replace
fill ~246 ~55 ~632 ~246 ~55 ~636 minecraft:redstone_wire replace
setblock ~93 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~117 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~168 ~55 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~55 ~636 ~93 ~55 ~648 minecraft:redstone_wire replace
fill ~117 ~55 ~636 ~117 ~55 ~648 minecraft:redstone_wire replace
fill ~138 ~55 ~636 ~138 ~55 ~648 minecraft:redstone_wire replace
fill ~153 ~55 ~636 ~153 ~55 ~648 minecraft:redstone_wire replace
fill ~168 ~55 ~636 ~168 ~55 ~648 minecraft:redstone_wire replace
fill ~258 ~55 ~636 ~258 ~55 ~640 minecraft:redstone_wire replace
fill ~291 ~55 ~640 ~291 ~55 ~644 minecraft:redstone_wire replace
fill ~228 ~55 ~644 ~228 ~55 ~648 minecraft:redstone_wire replace
fill ~321 ~55 ~648 ~321 ~55 ~652 minecraft:redstone_wire replace
fill ~96 ~55 ~652 ~96 ~55 ~656 minecraft:redstone_wire replace
fill ~294 ~55 ~656 ~294 ~55 ~660 minecraft:redstone_wire replace
fill ~318 ~55 ~660 ~318 ~55 ~664 minecraft:redstone_wire replace
setblock ~273 ~56 ~75 minecraft:redstone_wire replace
setblock ~93 ~56 ~247 minecraft:redstone_wire replace
setblock ~117 ~56 ~267 minecraft:redstone_wire replace
setblock ~138 ~56 ~283 minecraft:redstone_wire replace
setblock ~153 ~56 ~295 minecraft:redstone_wire replace
setblock ~168 ~56 ~319 minecraft:redstone_wire replace
setblock ~192 ~56 ~323 minecraft:redstone_wire replace
setblock ~189 ~56 ~327 minecraft:redstone_wire replace
setblock ~213 ~56 ~339 minecraft:redstone_wire replace
setblock ~210 ~56 ~343 minecraft:redstone_wire replace
setblock ~264 ~56 ~355 minecraft:redstone_wire replace
setblock ~261 ~56 ~359 minecraft:redstone_wire replace
setblock ~306 ~56 ~363 minecraft:redstone_wire replace
setblock ~270 ~56 ~367 minecraft:redstone_wire replace
setblock ~237 ~56 ~371 minecraft:redstone_wire replace
setblock ~234 ~56 ~375 minecraft:redstone_wire replace
setblock ~309 ~56 ~391 minecraft:redstone_wire replace
setblock ~276 ~56 ~395 minecraft:redstone_wire replace
setblock ~297 ~56 ~399 minecraft:redstone_wire replace
setblock ~90 ~56 ~411 minecraft:redstone_wire replace
setblock ~114 ~56 ~415 minecraft:redstone_wire replace
setblock ~135 ~56 ~419 minecraft:redstone_wire replace
setblock ~159 ~56 ~423 minecraft:redstone_wire replace
setblock ~180 ~56 ~427 minecraft:redstone_wire replace
setblock ~204 ~56 ~431 minecraft:redstone_wire replace
setblock ~231 ~56 ~435 minecraft:redstone_wire replace
setblock ~255 ~56 ~439 minecraft:redstone_wire replace
setblock ~267 ~56 ~443 minecraft:redstone_wire replace
setblock ~87 ~56 ~447 minecraft:redstone_wire replace
setblock ~111 ~56 ~451 minecraft:redstone_wire replace
setblock ~132 ~56 ~455 minecraft:redstone_wire replace
setblock ~156 ~56 ~459 minecraft:redstone_wire replace
setblock ~177 ~56 ~463 minecraft:redstone_wire replace
setblock ~201 ~56 ~467 minecraft:redstone_wire replace
setblock ~225 ~56 ~471 minecraft:redstone_wire replace
setblock ~252 ~56 ~475 minecraft:redstone_wire replace
setblock ~288 ~56 ~479 minecraft:redstone_wire replace
setblock ~315 ~56 ~483 minecraft:redstone_wire replace
setblock ~84 ~56 ~487 minecraft:redstone_wire replace
setblock ~108 ~56 ~491 minecraft:redstone_wire replace
setblock ~129 ~56 ~495 minecraft:redstone_wire replace
setblock ~150 ~56 ~499 minecraft:redstone_wire replace
setblock ~174 ~56 ~503 minecraft:redstone_wire replace
setblock ~198 ~56 ~507 minecraft:redstone_wire replace
setblock ~222 ~56 ~511 minecraft:redstone_wire replace
setblock ~249 ~56 ~515 minecraft:redstone_wire replace
setblock ~285 ~56 ~519 minecraft:redstone_wire replace
setblock ~312 ~56 ~523 minecraft:redstone_wire replace
setblock ~81 ~56 ~527 minecraft:redstone_wire replace
setblock ~105 ~56 ~531 minecraft:redstone_wire replace
setblock ~126 ~56 ~535 minecraft:redstone_wire replace
setblock ~147 ~56 ~539 minecraft:redstone_wire replace
setblock ~171 ~56 ~543 minecraft:redstone_wire replace
setblock ~195 ~56 ~547 minecraft:redstone_wire replace
setblock ~219 ~56 ~551 minecraft:redstone_wire replace
setblock ~243 ~56 ~555 minecraft:redstone_wire replace
setblock ~282 ~56 ~559 minecraft:redstone_wire replace
setblock ~303 ~56 ~563 minecraft:redstone_wire replace
setblock ~78 ~56 ~567 minecraft:redstone_wire replace
setblock ~102 ~56 ~571 minecraft:redstone_wire replace
setblock ~123 ~56 ~575 minecraft:redstone_wire replace
setblock ~144 ~56 ~579 minecraft:redstone_wire replace
setblock ~165 ~56 ~583 minecraft:redstone_wire replace
setblock ~186 ~56 ~587 minecraft:redstone_wire replace
setblock ~216 ~56 ~591 minecraft:redstone_wire replace
setblock ~240 ~56 ~595 minecraft:redstone_wire replace
setblock ~279 ~56 ~599 minecraft:redstone_wire replace
setblock ~300 ~56 ~603 minecraft:redstone_wire replace
setblock ~99 ~56 ~607 minecraft:redstone_wire replace
setblock ~120 ~56 ~611 minecraft:redstone_wire replace
setblock ~141 ~56 ~615 minecraft:redstone_wire replace
setblock ~162 ~56 ~619 minecraft:redstone_wire replace
setblock ~183 ~56 ~623 minecraft:redstone_wire replace
setblock ~207 ~56 ~627 minecraft:redstone_wire replace
setblock ~246 ~56 ~631 minecraft:redstone_wire replace
setblock ~258 ~56 ~635 minecraft:redstone_wire replace
setblock ~291 ~56 ~639 minecraft:redstone_wire replace
setblock ~228 ~56 ~643 minecraft:redstone_wire replace
setblock ~321 ~56 ~647 minecraft:redstone_wire replace
setblock ~96 ~56 ~651 minecraft:redstone_wire replace
setblock ~294 ~56 ~655 minecraft:redstone_wire replace
setblock ~318 ~56 ~659 minecraft:redstone_wire replace
setblock ~169 ~57 ~73 minecraft:redstone_wire replace
fill ~168 ~57 ~74 ~178 ~57 ~74 minecraft:redstone_wire replace
setblock ~180 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~57 ~74 ~195 ~57 ~74 minecraft:redstone_wire replace
setblock ~197 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~57 ~74 ~212 ~57 ~74 minecraft:redstone_wire replace
setblock ~214 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~57 ~74 ~229 ~57 ~74 minecraft:redstone_wire replace
setblock ~231 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~233 ~57 ~74 ~246 ~57 ~74 minecraft:redstone_wire replace
setblock ~248 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~57 ~74 ~263 ~57 ~74 minecraft:redstone_wire replace
setblock ~265 ~57 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~57 ~74 ~273 ~57 ~74 minecraft:redstone_wire replace
setblock ~79 ~57 ~245 minecraft:redstone_wire replace
fill ~78 ~57 ~246 ~80 ~57 ~246 minecraft:redstone_wire replace
setblock ~82 ~57 ~246 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~84 ~57 ~246 ~93 ~57 ~246 minecraft:redstone_wire replace
setblock ~82 ~57 ~265 minecraft:redstone_wire replace
fill ~81 ~57 ~266 ~84 ~57 ~266 minecraft:redstone_wire replace
setblock ~86 ~57 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~57 ~266 ~101 ~57 ~266 minecraft:redstone_wire replace
setblock ~103 ~57 ~266 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~266 ~117 ~57 ~266 minecraft:redstone_wire replace
setblock ~85 ~57 ~281 minecraft:redstone_wire replace
fill ~84 ~57 ~282 ~88 ~57 ~282 minecraft:redstone_wire replace
setblock ~90 ~57 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~57 ~282 ~105 ~57 ~282 minecraft:redstone_wire replace
setblock ~107 ~57 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~57 ~282 ~122 ~57 ~282 minecraft:redstone_wire replace
setblock ~124 ~57 ~282 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~282 ~138 ~57 ~282 minecraft:redstone_wire replace
setblock ~88 ~57 ~293 minecraft:redstone_wire replace
fill ~87 ~57 ~294 ~89 ~57 ~294 minecraft:redstone_wire replace
setblock ~91 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~57 ~294 ~106 ~57 ~294 minecraft:redstone_wire replace
setblock ~108 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~57 ~294 ~123 ~57 ~294 minecraft:redstone_wire replace
setblock ~125 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~57 ~294 ~140 ~57 ~294 minecraft:redstone_wire replace
setblock ~142 ~57 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~57 ~294 ~153 ~57 ~294 minecraft:redstone_wire replace
setblock ~91 ~57 ~317 minecraft:redstone_wire replace
fill ~90 ~57 ~318 ~101 ~57 ~318 minecraft:redstone_wire replace
setblock ~103 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~318 ~118 ~57 ~318 minecraft:redstone_wire replace
setblock ~120 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~57 ~318 ~135 ~57 ~318 minecraft:redstone_wire replace
setblock ~137 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~57 ~318 ~152 ~57 ~318 minecraft:redstone_wire replace
setblock ~154 ~57 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~57 ~318 ~168 ~57 ~318 minecraft:redstone_wire replace
setblock ~100 ~57 ~321 minecraft:redstone_wire replace
fill ~99 ~57 ~322 ~100 ~57 ~322 minecraft:redstone_wire replace
setblock ~101 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~57 ~322 ~115 ~57 ~322 minecraft:redstone_wire replace
setblock ~117 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~57 ~322 ~132 ~57 ~322 minecraft:redstone_wire replace
setblock ~134 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~57 ~322 ~149 ~57 ~322 minecraft:redstone_wire replace
setblock ~151 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~57 ~322 ~166 ~57 ~322 minecraft:redstone_wire replace
setblock ~168 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~57 ~322 ~183 ~57 ~322 minecraft:redstone_wire replace
setblock ~185 ~57 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~187 ~57 ~322 ~192 ~57 ~322 minecraft:redstone_wire replace
setblock ~100 ~57 ~325 minecraft:redstone_wire replace
fill ~99 ~57 ~326 ~108 ~57 ~326 minecraft:redstone_wire replace
setblock ~110 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~57 ~326 ~125 ~57 ~326 minecraft:redstone_wire replace
setblock ~127 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~326 ~142 ~57 ~326 minecraft:redstone_wire replace
setblock ~144 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~57 ~326 ~159 ~57 ~326 minecraft:redstone_wire replace
setblock ~161 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~57 ~326 ~176 ~57 ~326 minecraft:redstone_wire replace
setblock ~178 ~57 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~57 ~326 ~189 ~57 ~326 minecraft:redstone_wire replace
setblock ~118 ~57 ~337 minecraft:redstone_wire replace
fill ~117 ~57 ~338 ~119 ~57 ~338 minecraft:redstone_wire replace
setblock ~121 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~57 ~338 ~136 ~57 ~338 minecraft:redstone_wire replace
setblock ~138 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~57 ~338 ~153 ~57 ~338 minecraft:redstone_wire replace
setblock ~155 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~57 ~338 ~170 ~57 ~338 minecraft:redstone_wire replace
setblock ~172 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~338 ~187 ~57 ~338 minecraft:redstone_wire replace
setblock ~189 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~57 ~338 ~204 ~57 ~338 minecraft:redstone_wire replace
setblock ~206 ~57 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~57 ~338 ~213 ~57 ~338 minecraft:redstone_wire replace
setblock ~118 ~57 ~341 minecraft:redstone_wire replace
fill ~117 ~57 ~342 ~129 ~57 ~342 minecraft:redstone_wire replace
setblock ~131 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~57 ~342 ~146 ~57 ~342 minecraft:redstone_wire replace
setblock ~148 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~57 ~342 ~163 ~57 ~342 minecraft:redstone_wire replace
setblock ~165 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~57 ~342 ~180 ~57 ~342 minecraft:redstone_wire replace
setblock ~182 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~57 ~342 ~197 ~57 ~342 minecraft:redstone_wire replace
setblock ~199 ~57 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~57 ~342 ~210 ~57 ~342 minecraft:redstone_wire replace
setblock ~163 ~57 ~353 minecraft:redstone_wire replace
fill ~162 ~57 ~354 ~164 ~57 ~354 minecraft:redstone_wire replace
setblock ~166 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~57 ~354 ~181 ~57 ~354 minecraft:redstone_wire replace
setblock ~183 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~57 ~354 ~198 ~57 ~354 minecraft:redstone_wire replace
setblock ~200 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~354 ~215 ~57 ~354 minecraft:redstone_wire replace
setblock ~217 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~57 ~354 ~232 ~57 ~354 minecraft:redstone_wire replace
setblock ~234 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~57 ~354 ~249 ~57 ~354 minecraft:redstone_wire replace
setblock ~251 ~57 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~57 ~354 ~264 ~57 ~354 minecraft:redstone_wire replace
setblock ~163 ~57 ~357 minecraft:redstone_wire replace
fill ~162 ~57 ~358 ~166 ~57 ~358 minecraft:redstone_wire replace
setblock ~168 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~57 ~358 ~182 ~57 ~358 minecraft:redstone_wire replace
setblock ~184 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~57 ~358 ~198 ~57 ~358 minecraft:redstone_wire replace
setblock ~200 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~358 ~214 ~57 ~358 minecraft:redstone_wire replace
setblock ~216 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~57 ~358 ~230 ~57 ~358 minecraft:redstone_wire replace
setblock ~232 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~57 ~358 ~246 ~57 ~358 minecraft:redstone_wire replace
setblock ~248 ~57 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~57 ~358 ~261 ~57 ~358 minecraft:redstone_wire replace
setblock ~199 ~57 ~361 minecraft:redstone_wire replace
fill ~198 ~57 ~362 ~206 ~57 ~362 minecraft:redstone_wire replace
setblock ~208 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~362 ~223 ~57 ~362 minecraft:redstone_wire replace
setblock ~225 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~57 ~362 ~240 ~57 ~362 minecraft:redstone_wire replace
setblock ~242 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~57 ~362 ~257 ~57 ~362 minecraft:redstone_wire replace
setblock ~259 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~57 ~362 ~274 ~57 ~362 minecraft:redstone_wire replace
setblock ~276 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~57 ~362 ~291 ~57 ~362 minecraft:redstone_wire replace
setblock ~293 ~57 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~57 ~362 ~306 ~57 ~362 minecraft:redstone_wire replace
setblock ~169 ~57 ~365 minecraft:redstone_wire replace
fill ~168 ~57 ~366 ~169 ~57 ~366 minecraft:redstone_wire replace
setblock ~171 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~173 ~57 ~366 ~186 ~57 ~366 minecraft:redstone_wire replace
setblock ~188 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~57 ~366 ~203 ~57 ~366 minecraft:redstone_wire replace
setblock ~205 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~57 ~366 ~220 ~57 ~366 minecraft:redstone_wire replace
setblock ~222 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~57 ~366 ~237 ~57 ~366 minecraft:redstone_wire replace
setblock ~239 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~57 ~366 ~254 ~57 ~366 minecraft:redstone_wire replace
setblock ~256 ~57 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~57 ~366 ~270 ~57 ~366 minecraft:redstone_wire replace
setblock ~139 ~57 ~369 minecraft:redstone_wire replace
fill ~138 ~57 ~370 ~139 ~57 ~370 minecraft:redstone_wire replace
setblock ~140 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~57 ~370 ~154 ~57 ~370 minecraft:redstone_wire replace
setblock ~156 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~57 ~370 ~171 ~57 ~370 minecraft:redstone_wire replace
setblock ~173 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~57 ~370 ~188 ~57 ~370 minecraft:redstone_wire replace
setblock ~190 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~57 ~370 ~205 ~57 ~370 minecraft:redstone_wire replace
setblock ~207 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~57 ~370 ~222 ~57 ~370 minecraft:redstone_wire replace
setblock ~224 ~57 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~57 ~370 ~237 ~57 ~370 minecraft:redstone_wire replace
setblock ~139 ~57 ~373 minecraft:redstone_wire replace
fill ~138 ~57 ~374 ~150 ~57 ~374 minecraft:redstone_wire replace
setblock ~152 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~374 ~167 ~57 ~374 minecraft:redstone_wire replace
setblock ~169 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~57 ~374 ~184 ~57 ~374 minecraft:redstone_wire replace
setblock ~186 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~57 ~374 ~201 ~57 ~374 minecraft:redstone_wire replace
setblock ~203 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~57 ~374 ~218 ~57 ~374 minecraft:redstone_wire replace
setblock ~220 ~57 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~57 ~374 ~234 ~57 ~374 minecraft:redstone_wire replace
setblock ~199 ~57 ~389 minecraft:redstone_wire replace
fill ~198 ~57 ~390 ~199 ~57 ~390 minecraft:redstone_wire replace
setblock ~200 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~57 ~390 ~214 ~57 ~390 minecraft:redstone_wire replace
setblock ~216 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~57 ~390 ~231 ~57 ~390 minecraft:redstone_wire replace
setblock ~233 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~57 ~390 ~248 ~57 ~390 minecraft:redstone_wire replace
setblock ~250 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~57 ~390 ~265 ~57 ~390 minecraft:redstone_wire replace
setblock ~267 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~269 ~57 ~390 ~282 ~57 ~390 minecraft:redstone_wire replace
setblock ~284 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~57 ~390 ~299 ~57 ~390 minecraft:redstone_wire replace
setblock ~301 ~57 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~57 ~390 ~309 ~57 ~390 minecraft:redstone_wire replace
setblock ~169 ~57 ~393 minecraft:redstone_wire replace
fill ~168 ~57 ~394 ~181 ~57 ~394 minecraft:redstone_wire replace
setblock ~183 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~57 ~394 ~198 ~57 ~394 minecraft:redstone_wire replace
setblock ~200 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~394 ~215 ~57 ~394 minecraft:redstone_wire replace
setblock ~217 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~57 ~394 ~232 ~57 ~394 minecraft:redstone_wire replace
setblock ~234 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~57 ~394 ~249 ~57 ~394 minecraft:redstone_wire replace
setblock ~251 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~57 ~394 ~266 ~57 ~394 minecraft:redstone_wire replace
setblock ~268 ~57 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~57 ~394 ~276 ~57 ~394 minecraft:redstone_wire replace
setblock ~190 ~57 ~397 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~57 ~398 ~202 ~57 ~398 minecraft:redstone_wire replace
setblock ~204 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~57 ~398 ~219 ~57 ~398 minecraft:redstone_wire replace
setblock ~221 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~57 ~398 ~236 ~57 ~398 minecraft:redstone_wire replace
setblock ~238 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~57 ~398 ~253 ~57 ~398 minecraft:redstone_wire replace
setblock ~255 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~257 ~57 ~398 ~270 ~57 ~398 minecraft:redstone_wire replace
setblock ~272 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~57 ~398 ~287 ~57 ~398 minecraft:redstone_wire replace
setblock ~289 ~57 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~57 ~398 ~297 ~57 ~398 minecraft:redstone_wire replace
setblock ~79 ~57 ~409 minecraft:redstone_wire replace
fill ~78 ~57 ~410 ~80 ~57 ~410 minecraft:redstone_wire replace
setblock ~82 ~57 ~410 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~84 ~57 ~410 ~90 ~57 ~410 minecraft:redstone_wire replace
setblock ~82 ~57 ~413 minecraft:redstone_wire replace
fill ~81 ~57 ~414 ~87 ~57 ~414 minecraft:redstone_wire replace
setblock ~89 ~57 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~91 ~57 ~414 ~104 ~57 ~414 minecraft:redstone_wire replace
setblock ~106 ~57 ~414 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~57 ~414 ~114 ~57 ~414 minecraft:redstone_wire replace
setblock ~85 ~57 ~417 minecraft:redstone_wire replace
fill ~84 ~57 ~418 ~91 ~57 ~418 minecraft:redstone_wire replace
setblock ~93 ~57 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~95 ~57 ~418 ~108 ~57 ~418 minecraft:redstone_wire replace
setblock ~110 ~57 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~57 ~418 ~125 ~57 ~418 minecraft:redstone_wire replace
setblock ~127 ~57 ~418 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~418 ~135 ~57 ~418 minecraft:redstone_wire replace
setblock ~88 ~57 ~421 minecraft:redstone_wire replace
fill ~87 ~57 ~422 ~98 ~57 ~422 minecraft:redstone_wire replace
setblock ~100 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~57 ~422 ~115 ~57 ~422 minecraft:redstone_wire replace
setblock ~117 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~57 ~422 ~132 ~57 ~422 minecraft:redstone_wire replace
setblock ~134 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~57 ~422 ~149 ~57 ~422 minecraft:redstone_wire replace
setblock ~151 ~57 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~57 ~422 ~159 ~57 ~422 minecraft:redstone_wire replace
setblock ~91 ~57 ~425 minecraft:redstone_wire replace
fill ~90 ~57 ~426 ~102 ~57 ~426 minecraft:redstone_wire replace
setblock ~104 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~57 ~426 ~119 ~57 ~426 minecraft:redstone_wire replace
setblock ~121 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~57 ~426 ~136 ~57 ~426 minecraft:redstone_wire replace
setblock ~138 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~57 ~426 ~153 ~57 ~426 minecraft:redstone_wire replace
setblock ~155 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~57 ~426 ~170 ~57 ~426 minecraft:redstone_wire replace
setblock ~172 ~57 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~426 ~180 ~57 ~426 minecraft:redstone_wire replace
setblock ~112 ~57 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~57 ~430 ~115 ~57 ~430 minecraft:redstone_wire replace
setblock ~117 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~57 ~430 ~131 ~57 ~430 minecraft:redstone_wire replace
setblock ~133 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~57 ~430 ~147 ~57 ~430 minecraft:redstone_wire replace
setblock ~149 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~57 ~430 ~163 ~57 ~430 minecraft:redstone_wire replace
setblock ~165 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~57 ~430 ~179 ~57 ~430 minecraft:redstone_wire replace
setblock ~181 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~57 ~430 ~195 ~57 ~430 minecraft:redstone_wire replace
setblock ~197 ~57 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~57 ~430 ~204 ~57 ~430 minecraft:redstone_wire replace
setblock ~136 ~57 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~57 ~434 ~136 ~57 ~434 minecraft:redstone_wire replace
setblock ~138 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~57 ~434 ~153 ~57 ~434 minecraft:redstone_wire replace
setblock ~155 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~57 ~434 ~170 ~57 ~434 minecraft:redstone_wire replace
setblock ~172 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~434 ~187 ~57 ~434 minecraft:redstone_wire replace
setblock ~189 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~57 ~434 ~204 ~57 ~434 minecraft:redstone_wire replace
setblock ~206 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~57 ~434 ~221 ~57 ~434 minecraft:redstone_wire replace
setblock ~223 ~57 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~57 ~434 ~231 ~57 ~434 minecraft:redstone_wire replace
setblock ~157 ~57 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~57 ~438 ~160 ~57 ~438 minecraft:redstone_wire replace
setblock ~162 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~57 ~438 ~177 ~57 ~438 minecraft:redstone_wire replace
setblock ~179 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~57 ~438 ~194 ~57 ~438 minecraft:redstone_wire replace
setblock ~196 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~57 ~438 ~211 ~57 ~438 minecraft:redstone_wire replace
setblock ~213 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~215 ~57 ~438 ~228 ~57 ~438 minecraft:redstone_wire replace
setblock ~230 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~57 ~438 ~245 ~57 ~438 minecraft:redstone_wire replace
setblock ~247 ~57 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~57 ~438 ~255 ~57 ~438 minecraft:redstone_wire replace
setblock ~166 ~57 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~165 ~57 ~442 ~172 ~57 ~442 minecraft:redstone_wire replace
setblock ~174 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~57 ~442 ~189 ~57 ~442 minecraft:redstone_wire replace
setblock ~191 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~57 ~442 ~206 ~57 ~442 minecraft:redstone_wire replace
setblock ~208 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~442 ~223 ~57 ~442 minecraft:redstone_wire replace
setblock ~225 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~57 ~442 ~240 ~57 ~442 minecraft:redstone_wire replace
setblock ~242 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~57 ~442 ~257 ~57 ~442 minecraft:redstone_wire replace
setblock ~259 ~57 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~57 ~442 ~267 ~57 ~442 minecraft:redstone_wire replace
setblock ~79 ~57 ~445 minecraft:redstone_wire replace
fill ~78 ~57 ~446 ~79 ~57 ~446 minecraft:redstone_wire replace
setblock ~80 ~57 ~446 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~81 ~57 ~446 ~87 ~57 ~446 minecraft:redstone_wire replace
setblock ~82 ~57 ~449 minecraft:redstone_wire replace
fill ~81 ~57 ~450 ~84 ~57 ~450 minecraft:redstone_wire replace
setblock ~86 ~57 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~88 ~57 ~450 ~101 ~57 ~450 minecraft:redstone_wire replace
setblock ~103 ~57 ~450 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~450 ~111 ~57 ~450 minecraft:redstone_wire replace
setblock ~85 ~57 ~453 minecraft:redstone_wire replace
fill ~84 ~57 ~454 ~88 ~57 ~454 minecraft:redstone_wire replace
setblock ~90 ~57 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~57 ~454 ~105 ~57 ~454 minecraft:redstone_wire replace
setblock ~107 ~57 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~57 ~454 ~122 ~57 ~454 minecraft:redstone_wire replace
setblock ~124 ~57 ~454 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~454 ~132 ~57 ~454 minecraft:redstone_wire replace
setblock ~88 ~57 ~457 minecraft:redstone_wire replace
fill ~87 ~57 ~458 ~95 ~57 ~458 minecraft:redstone_wire replace
setblock ~97 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~57 ~458 ~112 ~57 ~458 minecraft:redstone_wire replace
setblock ~114 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~57 ~458 ~129 ~57 ~458 minecraft:redstone_wire replace
setblock ~131 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~57 ~458 ~146 ~57 ~458 minecraft:redstone_wire replace
setblock ~148 ~57 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~57 ~458 ~156 ~57 ~458 minecraft:redstone_wire replace
setblock ~91 ~57 ~461 minecraft:redstone_wire replace
fill ~90 ~57 ~462 ~99 ~57 ~462 minecraft:redstone_wire replace
setblock ~101 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~57 ~462 ~116 ~57 ~462 minecraft:redstone_wire replace
setblock ~118 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~57 ~462 ~133 ~57 ~462 minecraft:redstone_wire replace
setblock ~135 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~57 ~462 ~150 ~57 ~462 minecraft:redstone_wire replace
setblock ~152 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~462 ~167 ~57 ~462 minecraft:redstone_wire replace
setblock ~169 ~57 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~57 ~462 ~177 ~57 ~462 minecraft:redstone_wire replace
setblock ~109 ~57 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~57 ~466 ~112 ~57 ~466 minecraft:redstone_wire replace
setblock ~114 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~57 ~466 ~128 ~57 ~466 minecraft:redstone_wire replace
setblock ~130 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~132 ~57 ~466 ~144 ~57 ~466 minecraft:redstone_wire replace
setblock ~146 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~57 ~466 ~160 ~57 ~466 minecraft:redstone_wire replace
setblock ~162 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~57 ~466 ~176 ~57 ~466 minecraft:redstone_wire replace
setblock ~178 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~57 ~466 ~192 ~57 ~466 minecraft:redstone_wire replace
setblock ~194 ~57 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~57 ~466 ~201 ~57 ~466 minecraft:redstone_wire replace
setblock ~130 ~57 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~57 ~470 ~130 ~57 ~470 minecraft:redstone_wire replace
setblock ~132 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~57 ~470 ~147 ~57 ~470 minecraft:redstone_wire replace
setblock ~149 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~57 ~470 ~164 ~57 ~470 minecraft:redstone_wire replace
setblock ~166 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~57 ~470 ~181 ~57 ~470 minecraft:redstone_wire replace
setblock ~183 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~185 ~57 ~470 ~198 ~57 ~470 minecraft:redstone_wire replace
setblock ~200 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~470 ~215 ~57 ~470 minecraft:redstone_wire replace
setblock ~217 ~57 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~219 ~57 ~470 ~225 ~57 ~470 minecraft:redstone_wire replace
setblock ~154 ~57 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~57 ~474 ~157 ~57 ~474 minecraft:redstone_wire replace
setblock ~159 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~57 ~474 ~174 ~57 ~474 minecraft:redstone_wire replace
setblock ~176 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~57 ~474 ~191 ~57 ~474 minecraft:redstone_wire replace
setblock ~193 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~57 ~474 ~208 ~57 ~474 minecraft:redstone_wire replace
setblock ~210 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~57 ~474 ~225 ~57 ~474 minecraft:redstone_wire replace
setblock ~227 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~57 ~474 ~242 ~57 ~474 minecraft:redstone_wire replace
setblock ~244 ~57 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~57 ~474 ~252 ~57 ~474 minecraft:redstone_wire replace
setblock ~181 ~57 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~57 ~478 ~193 ~57 ~478 minecraft:redstone_wire replace
setblock ~195 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~197 ~57 ~478 ~210 ~57 ~478 minecraft:redstone_wire replace
setblock ~212 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~214 ~57 ~478 ~227 ~57 ~478 minecraft:redstone_wire replace
setblock ~229 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~57 ~478 ~244 ~57 ~478 minecraft:redstone_wire replace
setblock ~246 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~248 ~57 ~478 ~261 ~57 ~478 minecraft:redstone_wire replace
setblock ~263 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~57 ~478 ~278 ~57 ~478 minecraft:redstone_wire replace
setblock ~280 ~57 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~57 ~478 ~288 ~57 ~478 minecraft:redstone_wire replace
setblock ~205 ~57 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~57 ~482 ~205 ~57 ~482 minecraft:redstone_wire replace
setblock ~206 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~57 ~482 ~220 ~57 ~482 minecraft:redstone_wire replace
setblock ~222 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~57 ~482 ~237 ~57 ~482 minecraft:redstone_wire replace
setblock ~239 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~57 ~482 ~254 ~57 ~482 minecraft:redstone_wire replace
setblock ~256 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~258 ~57 ~482 ~271 ~57 ~482 minecraft:redstone_wire replace
setblock ~273 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~275 ~57 ~482 ~288 ~57 ~482 minecraft:redstone_wire replace
setblock ~290 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~292 ~57 ~482 ~305 ~57 ~482 minecraft:redstone_wire replace
setblock ~307 ~57 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~309 ~57 ~482 ~315 ~57 ~482 minecraft:redstone_wire replace
setblock ~79 ~57 ~485 minecraft:redstone_wire replace
fill ~78 ~57 ~486 ~84 ~57 ~486 minecraft:redstone_wire replace
setblock ~82 ~57 ~489 minecraft:redstone_wire replace
fill ~81 ~57 ~490 ~83 ~57 ~490 minecraft:redstone_wire replace
setblock ~84 ~57 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~85 ~57 ~490 ~98 ~57 ~490 minecraft:redstone_wire replace
setblock ~100 ~57 ~490 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~57 ~490 ~108 ~57 ~490 minecraft:redstone_wire replace
setblock ~85 ~57 ~493 minecraft:redstone_wire replace
fill ~84 ~57 ~494 ~85 ~57 ~494 minecraft:redstone_wire replace
setblock ~87 ~57 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~89 ~57 ~494 ~102 ~57 ~494 minecraft:redstone_wire replace
setblock ~104 ~57 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~57 ~494 ~119 ~57 ~494 minecraft:redstone_wire replace
setblock ~121 ~57 ~494 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~57 ~494 ~129 ~57 ~494 minecraft:redstone_wire replace
setblock ~88 ~57 ~497 minecraft:redstone_wire replace
fill ~87 ~57 ~498 ~89 ~57 ~498 minecraft:redstone_wire replace
setblock ~91 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~57 ~498 ~106 ~57 ~498 minecraft:redstone_wire replace
setblock ~108 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~57 ~498 ~123 ~57 ~498 minecraft:redstone_wire replace
setblock ~125 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~57 ~498 ~140 ~57 ~498 minecraft:redstone_wire replace
setblock ~142 ~57 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~57 ~498 ~150 ~57 ~498 minecraft:redstone_wire replace
setblock ~91 ~57 ~501 minecraft:redstone_wire replace
fill ~90 ~57 ~502 ~96 ~57 ~502 minecraft:redstone_wire replace
setblock ~98 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~57 ~502 ~113 ~57 ~502 minecraft:redstone_wire replace
setblock ~115 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~57 ~502 ~130 ~57 ~502 minecraft:redstone_wire replace
setblock ~132 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~57 ~502 ~147 ~57 ~502 minecraft:redstone_wire replace
setblock ~149 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~57 ~502 ~164 ~57 ~502 minecraft:redstone_wire replace
setblock ~166 ~57 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~57 ~502 ~174 ~57 ~502 minecraft:redstone_wire replace
setblock ~106 ~57 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~57 ~506 ~109 ~57 ~506 minecraft:redstone_wire replace
setblock ~111 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~57 ~506 ~125 ~57 ~506 minecraft:redstone_wire replace
setblock ~127 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~506 ~141 ~57 ~506 minecraft:redstone_wire replace
setblock ~143 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~57 ~506 ~157 ~57 ~506 minecraft:redstone_wire replace
setblock ~159 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~57 ~506 ~173 ~57 ~506 minecraft:redstone_wire replace
setblock ~175 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~57 ~506 ~189 ~57 ~506 minecraft:redstone_wire replace
setblock ~191 ~57 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~57 ~506 ~198 ~57 ~506 minecraft:redstone_wire replace
setblock ~127 ~57 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~57 ~510 ~127 ~57 ~510 minecraft:redstone_wire replace
setblock ~129 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~57 ~510 ~144 ~57 ~510 minecraft:redstone_wire replace
setblock ~146 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~57 ~510 ~161 ~57 ~510 minecraft:redstone_wire replace
setblock ~163 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~57 ~510 ~178 ~57 ~510 minecraft:redstone_wire replace
setblock ~180 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~182 ~57 ~510 ~195 ~57 ~510 minecraft:redstone_wire replace
setblock ~197 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~199 ~57 ~510 ~212 ~57 ~510 minecraft:redstone_wire replace
setblock ~214 ~57 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~57 ~510 ~222 ~57 ~510 minecraft:redstone_wire replace
setblock ~151 ~57 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~57 ~514 ~154 ~57 ~514 minecraft:redstone_wire replace
setblock ~156 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~57 ~514 ~171 ~57 ~514 minecraft:redstone_wire replace
setblock ~173 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~175 ~57 ~514 ~188 ~57 ~514 minecraft:redstone_wire replace
setblock ~190 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~57 ~514 ~205 ~57 ~514 minecraft:redstone_wire replace
setblock ~207 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~57 ~514 ~222 ~57 ~514 minecraft:redstone_wire replace
setblock ~224 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~57 ~514 ~239 ~57 ~514 minecraft:redstone_wire replace
setblock ~241 ~57 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~57 ~514 ~249 ~57 ~514 minecraft:redstone_wire replace
setblock ~178 ~57 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~57 ~518 ~190 ~57 ~518 minecraft:redstone_wire replace
setblock ~192 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~194 ~57 ~518 ~207 ~57 ~518 minecraft:redstone_wire replace
setblock ~209 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~211 ~57 ~518 ~224 ~57 ~518 minecraft:redstone_wire replace
setblock ~226 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~57 ~518 ~241 ~57 ~518 minecraft:redstone_wire replace
setblock ~243 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~245 ~57 ~518 ~258 ~57 ~518 minecraft:redstone_wire replace
setblock ~260 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~262 ~57 ~518 ~275 ~57 ~518 minecraft:redstone_wire replace
setblock ~277 ~57 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~279 ~57 ~518 ~285 ~57 ~518 minecraft:redstone_wire replace
setblock ~202 ~57 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~57 ~522 ~202 ~57 ~522 minecraft:redstone_wire replace
setblock ~203 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~57 ~522 ~217 ~57 ~522 minecraft:redstone_wire replace
setblock ~219 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~221 ~57 ~522 ~234 ~57 ~522 minecraft:redstone_wire replace
setblock ~236 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~57 ~522 ~251 ~57 ~522 minecraft:redstone_wire replace
setblock ~253 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~57 ~522 ~268 ~57 ~522 minecraft:redstone_wire replace
setblock ~270 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~57 ~522 ~285 ~57 ~522 minecraft:redstone_wire replace
setblock ~287 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~57 ~522 ~302 ~57 ~522 minecraft:redstone_wire replace
setblock ~304 ~57 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~57 ~522 ~312 ~57 ~522 minecraft:redstone_wire replace
setblock ~79 ~57 ~525 minecraft:redstone_wire replace
fill ~78 ~57 ~526 ~81 ~57 ~526 minecraft:redstone_wire replace
setblock ~82 ~57 ~529 minecraft:redstone_wire replace
setblock ~81 ~57 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~82 ~57 ~530 ~95 ~57 ~530 minecraft:redstone_wire replace
setblock ~97 ~57 ~530 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~57 ~530 ~105 ~57 ~530 minecraft:redstone_wire replace
setblock ~85 ~57 ~533 minecraft:redstone_wire replace
fill ~84 ~57 ~534 ~85 ~57 ~534 minecraft:redstone_wire replace
setblock ~87 ~57 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~89 ~57 ~534 ~101 ~57 ~534 minecraft:redstone_wire replace
setblock ~103 ~57 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~534 ~117 ~57 ~534 minecraft:redstone_wire replace
setblock ~119 ~57 ~534 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~57 ~534 ~126 ~57 ~534 minecraft:redstone_wire replace
setblock ~88 ~57 ~537 minecraft:redstone_wire replace
fill ~87 ~57 ~538 ~88 ~57 ~538 minecraft:redstone_wire replace
setblock ~89 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~57 ~538 ~103 ~57 ~538 minecraft:redstone_wire replace
setblock ~105 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~57 ~538 ~120 ~57 ~538 minecraft:redstone_wire replace
setblock ~122 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~124 ~57 ~538 ~137 ~57 ~538 minecraft:redstone_wire replace
setblock ~139 ~57 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~141 ~57 ~538 ~147 ~57 ~538 minecraft:redstone_wire replace
setblock ~91 ~57 ~541 minecraft:redstone_wire replace
fill ~90 ~57 ~542 ~93 ~57 ~542 minecraft:redstone_wire replace
setblock ~95 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~57 ~542 ~110 ~57 ~542 minecraft:redstone_wire replace
setblock ~112 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~57 ~542 ~127 ~57 ~542 minecraft:redstone_wire replace
setblock ~129 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~57 ~542 ~144 ~57 ~542 minecraft:redstone_wire replace
setblock ~146 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~57 ~542 ~161 ~57 ~542 minecraft:redstone_wire replace
setblock ~163 ~57 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~57 ~542 ~171 ~57 ~542 minecraft:redstone_wire replace
setblock ~103 ~57 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~57 ~546 ~106 ~57 ~546 minecraft:redstone_wire replace
setblock ~108 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~57 ~546 ~122 ~57 ~546 minecraft:redstone_wire replace
setblock ~124 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~546 ~138 ~57 ~546 minecraft:redstone_wire replace
setblock ~140 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~57 ~546 ~154 ~57 ~546 minecraft:redstone_wire replace
setblock ~156 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~158 ~57 ~546 ~170 ~57 ~546 minecraft:redstone_wire replace
setblock ~172 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~57 ~546 ~186 ~57 ~546 minecraft:redstone_wire replace
setblock ~188 ~57 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~190 ~57 ~546 ~195 ~57 ~546 minecraft:redstone_wire replace
setblock ~124 ~57 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~123 ~57 ~550 ~124 ~57 ~550 minecraft:redstone_wire replace
setblock ~126 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~57 ~550 ~141 ~57 ~550 minecraft:redstone_wire replace
setblock ~143 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~57 ~550 ~158 ~57 ~550 minecraft:redstone_wire replace
setblock ~160 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~57 ~550 ~175 ~57 ~550 minecraft:redstone_wire replace
setblock ~177 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~57 ~550 ~192 ~57 ~550 minecraft:redstone_wire replace
setblock ~194 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~57 ~550 ~209 ~57 ~550 minecraft:redstone_wire replace
setblock ~211 ~57 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~57 ~550 ~219 ~57 ~550 minecraft:redstone_wire replace
setblock ~145 ~57 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~144 ~57 ~554 ~148 ~57 ~554 minecraft:redstone_wire replace
setblock ~150 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~57 ~554 ~165 ~57 ~554 minecraft:redstone_wire replace
setblock ~167 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~57 ~554 ~182 ~57 ~554 minecraft:redstone_wire replace
setblock ~184 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~57 ~554 ~199 ~57 ~554 minecraft:redstone_wire replace
setblock ~201 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~57 ~554 ~216 ~57 ~554 minecraft:redstone_wire replace
setblock ~218 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~57 ~554 ~233 ~57 ~554 minecraft:redstone_wire replace
setblock ~235 ~57 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~57 ~554 ~243 ~57 ~554 minecraft:redstone_wire replace
setblock ~175 ~57 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~57 ~558 ~187 ~57 ~558 minecraft:redstone_wire replace
setblock ~189 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~191 ~57 ~558 ~204 ~57 ~558 minecraft:redstone_wire replace
setblock ~206 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~208 ~57 ~558 ~221 ~57 ~558 minecraft:redstone_wire replace
setblock ~223 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~57 ~558 ~238 ~57 ~558 minecraft:redstone_wire replace
setblock ~240 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~242 ~57 ~558 ~255 ~57 ~558 minecraft:redstone_wire replace
setblock ~257 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~57 ~558 ~272 ~57 ~558 minecraft:redstone_wire replace
setblock ~274 ~57 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~57 ~558 ~282 ~57 ~558 minecraft:redstone_wire replace
setblock ~196 ~57 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~57 ~562 ~208 ~57 ~562 minecraft:redstone_wire replace
setblock ~210 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~57 ~562 ~225 ~57 ~562 minecraft:redstone_wire replace
setblock ~227 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~57 ~562 ~242 ~57 ~562 minecraft:redstone_wire replace
setblock ~244 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~246 ~57 ~562 ~259 ~57 ~562 minecraft:redstone_wire replace
setblock ~261 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~263 ~57 ~562 ~276 ~57 ~562 minecraft:redstone_wire replace
setblock ~278 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~57 ~562 ~293 ~57 ~562 minecraft:redstone_wire replace
setblock ~295 ~57 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~57 ~562 ~303 ~57 ~562 minecraft:redstone_wire replace
setblock ~79 ~57 ~565 minecraft:redstone_wire replace
fill ~78 ~57 ~566 ~80 ~57 ~566 minecraft:redstone_wire replace
setblock ~82 ~57 ~569 minecraft:redstone_wire replace
fill ~81 ~57 ~570 ~92 ~57 ~570 minecraft:redstone_wire replace
setblock ~94 ~57 ~570 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~96 ~57 ~570 ~102 ~57 ~570 minecraft:redstone_wire replace
setblock ~85 ~57 ~573 minecraft:redstone_wire replace
fill ~84 ~57 ~574 ~96 ~57 ~574 minecraft:redstone_wire replace
setblock ~98 ~57 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~57 ~574 ~113 ~57 ~574 minecraft:redstone_wire replace
setblock ~115 ~57 ~574 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~57 ~574 ~123 ~57 ~574 minecraft:redstone_wire replace
setblock ~88 ~57 ~577 minecraft:redstone_wire replace
fill ~87 ~57 ~578 ~100 ~57 ~578 minecraft:redstone_wire replace
setblock ~102 ~57 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~104 ~57 ~578 ~117 ~57 ~578 minecraft:redstone_wire replace
setblock ~119 ~57 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~57 ~578 ~134 ~57 ~578 minecraft:redstone_wire replace
setblock ~136 ~57 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~57 ~578 ~144 ~57 ~578 minecraft:redstone_wire replace
setblock ~91 ~57 ~581 minecraft:redstone_wire replace
setblock ~90 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~91 ~57 ~582 ~104 ~57 ~582 minecraft:redstone_wire replace
setblock ~106 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~57 ~582 ~121 ~57 ~582 minecraft:redstone_wire replace
setblock ~123 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~57 ~582 ~138 ~57 ~582 minecraft:redstone_wire replace
setblock ~140 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~57 ~582 ~155 ~57 ~582 minecraft:redstone_wire replace
setblock ~157 ~57 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~57 ~582 ~165 ~57 ~582 minecraft:redstone_wire replace
setblock ~97 ~57 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~57 ~586 ~108 ~57 ~586 minecraft:redstone_wire replace
setblock ~110 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~57 ~586 ~125 ~57 ~586 minecraft:redstone_wire replace
setblock ~127 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~57 ~586 ~142 ~57 ~586 minecraft:redstone_wire replace
setblock ~144 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~146 ~57 ~586 ~159 ~57 ~586 minecraft:redstone_wire replace
setblock ~161 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~163 ~57 ~586 ~176 ~57 ~586 minecraft:redstone_wire replace
setblock ~178 ~57 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~180 ~57 ~586 ~186 ~57 ~586 minecraft:redstone_wire replace
setblock ~121 ~57 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~120 ~57 ~590 ~121 ~57 ~590 minecraft:redstone_wire replace
setblock ~123 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~57 ~590 ~138 ~57 ~590 minecraft:redstone_wire replace
setblock ~140 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~57 ~590 ~155 ~57 ~590 minecraft:redstone_wire replace
setblock ~157 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~57 ~590 ~172 ~57 ~590 minecraft:redstone_wire replace
setblock ~174 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~176 ~57 ~590 ~189 ~57 ~590 minecraft:redstone_wire replace
setblock ~191 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~193 ~57 ~590 ~206 ~57 ~590 minecraft:redstone_wire replace
setblock ~208 ~57 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~590 ~216 ~57 ~590 minecraft:redstone_wire replace
setblock ~142 ~57 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~57 ~594 ~145 ~57 ~594 minecraft:redstone_wire replace
setblock ~147 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~149 ~57 ~594 ~162 ~57 ~594 minecraft:redstone_wire replace
setblock ~164 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~166 ~57 ~594 ~179 ~57 ~594 minecraft:redstone_wire replace
setblock ~181 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~57 ~594 ~196 ~57 ~594 minecraft:redstone_wire replace
setblock ~198 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~57 ~594 ~213 ~57 ~594 minecraft:redstone_wire replace
setblock ~215 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~57 ~594 ~230 ~57 ~594 minecraft:redstone_wire replace
setblock ~232 ~57 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~57 ~594 ~240 ~57 ~594 minecraft:redstone_wire replace
setblock ~172 ~57 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~57 ~598 ~184 ~57 ~598 minecraft:redstone_wire replace
setblock ~186 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~57 ~598 ~201 ~57 ~598 minecraft:redstone_wire replace
setblock ~203 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~57 ~598 ~218 ~57 ~598 minecraft:redstone_wire replace
setblock ~220 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~57 ~598 ~235 ~57 ~598 minecraft:redstone_wire replace
setblock ~237 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~239 ~57 ~598 ~252 ~57 ~598 minecraft:redstone_wire replace
setblock ~254 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~57 ~598 ~269 ~57 ~598 minecraft:redstone_wire replace
setblock ~271 ~57 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~57 ~598 ~279 ~57 ~598 minecraft:redstone_wire replace
setblock ~193 ~57 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~57 ~602 ~205 ~57 ~602 minecraft:redstone_wire replace
setblock ~207 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~209 ~57 ~602 ~222 ~57 ~602 minecraft:redstone_wire replace
setblock ~224 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~57 ~602 ~239 ~57 ~602 minecraft:redstone_wire replace
setblock ~241 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~57 ~602 ~256 ~57 ~602 minecraft:redstone_wire replace
setblock ~258 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~260 ~57 ~602 ~273 ~57 ~602 minecraft:redstone_wire replace
setblock ~275 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~57 ~602 ~290 ~57 ~602 minecraft:redstone_wire replace
setblock ~292 ~57 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~57 ~602 ~300 ~57 ~602 minecraft:redstone_wire replace
setblock ~82 ~57 ~605 minecraft:redstone_wire replace
fill ~81 ~57 ~606 ~89 ~57 ~606 minecraft:redstone_wire replace
setblock ~91 ~57 ~606 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~93 ~57 ~606 ~99 ~57 ~606 minecraft:redstone_wire replace
setblock ~85 ~57 ~609 minecraft:redstone_wire replace
fill ~84 ~57 ~610 ~93 ~57 ~610 minecraft:redstone_wire replace
setblock ~95 ~57 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~97 ~57 ~610 ~110 ~57 ~610 minecraft:redstone_wire replace
setblock ~112 ~57 ~610 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~57 ~610 ~120 ~57 ~610 minecraft:redstone_wire replace
setblock ~88 ~57 ~613 minecraft:redstone_wire replace
fill ~87 ~57 ~614 ~97 ~57 ~614 minecraft:redstone_wire replace
setblock ~99 ~57 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~101 ~57 ~614 ~114 ~57 ~614 minecraft:redstone_wire replace
setblock ~116 ~57 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~57 ~614 ~131 ~57 ~614 minecraft:redstone_wire replace
setblock ~133 ~57 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~57 ~614 ~141 ~57 ~614 minecraft:redstone_wire replace
setblock ~91 ~57 ~617 minecraft:redstone_wire replace
fill ~90 ~57 ~618 ~101 ~57 ~618 minecraft:redstone_wire replace
setblock ~103 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~57 ~618 ~118 ~57 ~618 minecraft:redstone_wire replace
setblock ~120 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~57 ~618 ~135 ~57 ~618 minecraft:redstone_wire replace
setblock ~137 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~57 ~618 ~152 ~57 ~618 minecraft:redstone_wire replace
setblock ~154 ~57 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~57 ~618 ~162 ~57 ~618 minecraft:redstone_wire replace
setblock ~94 ~57 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~93 ~57 ~622 ~105 ~57 ~622 minecraft:redstone_wire replace
setblock ~107 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~57 ~622 ~122 ~57 ~622 minecraft:redstone_wire replace
setblock ~124 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~57 ~622 ~139 ~57 ~622 minecraft:redstone_wire replace
setblock ~141 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~143 ~57 ~622 ~156 ~57 ~622 minecraft:redstone_wire replace
setblock ~158 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~160 ~57 ~622 ~173 ~57 ~622 minecraft:redstone_wire replace
setblock ~175 ~57 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~177 ~57 ~622 ~183 ~57 ~622 minecraft:redstone_wire replace
setblock ~115 ~57 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~57 ~626 ~118 ~57 ~626 minecraft:redstone_wire replace
setblock ~120 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~122 ~57 ~626 ~134 ~57 ~626 minecraft:redstone_wire replace
setblock ~136 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~57 ~626 ~150 ~57 ~626 minecraft:redstone_wire replace
setblock ~152 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~626 ~166 ~57 ~626 minecraft:redstone_wire replace
setblock ~168 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~170 ~57 ~626 ~182 ~57 ~626 minecraft:redstone_wire replace
setblock ~184 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~57 ~626 ~198 ~57 ~626 minecraft:redstone_wire replace
setblock ~200 ~57 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~202 ~57 ~626 ~207 ~57 ~626 minecraft:redstone_wire replace
setblock ~148 ~57 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~57 ~630 ~151 ~57 ~630 minecraft:redstone_wire replace
setblock ~153 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~57 ~630 ~168 ~57 ~630 minecraft:redstone_wire replace
setblock ~170 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~57 ~630 ~185 ~57 ~630 minecraft:redstone_wire replace
setblock ~187 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~57 ~630 ~202 ~57 ~630 minecraft:redstone_wire replace
setblock ~204 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~206 ~57 ~630 ~219 ~57 ~630 minecraft:redstone_wire replace
setblock ~221 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~223 ~57 ~630 ~236 ~57 ~630 minecraft:redstone_wire replace
setblock ~238 ~57 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~240 ~57 ~630 ~246 ~57 ~630 minecraft:redstone_wire replace
setblock ~160 ~57 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~57 ~634 ~163 ~57 ~634 minecraft:redstone_wire replace
setblock ~165 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~167 ~57 ~634 ~180 ~57 ~634 minecraft:redstone_wire replace
setblock ~182 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~57 ~634 ~197 ~57 ~634 minecraft:redstone_wire replace
setblock ~199 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~57 ~634 ~214 ~57 ~634 minecraft:redstone_wire replace
setblock ~216 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~218 ~57 ~634 ~231 ~57 ~634 minecraft:redstone_wire replace
setblock ~233 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~57 ~634 ~248 ~57 ~634 minecraft:redstone_wire replace
setblock ~250 ~57 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~57 ~634 ~258 ~57 ~634 minecraft:redstone_wire replace
setblock ~184 ~57 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~57 ~638 ~196 ~57 ~638 minecraft:redstone_wire replace
setblock ~198 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~200 ~57 ~638 ~213 ~57 ~638 minecraft:redstone_wire replace
setblock ~215 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~217 ~57 ~638 ~230 ~57 ~638 minecraft:redstone_wire replace
setblock ~232 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~57 ~638 ~247 ~57 ~638 minecraft:redstone_wire replace
setblock ~249 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~251 ~57 ~638 ~264 ~57 ~638 minecraft:redstone_wire replace
setblock ~266 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~57 ~638 ~281 ~57 ~638 minecraft:redstone_wire replace
setblock ~283 ~57 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~57 ~638 ~291 ~57 ~638 minecraft:redstone_wire replace
setblock ~133 ~57 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~57 ~642 ~133 ~57 ~642 minecraft:redstone_wire replace
setblock ~135 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~57 ~642 ~150 ~57 ~642 minecraft:redstone_wire replace
setblock ~152 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~57 ~642 ~167 ~57 ~642 minecraft:redstone_wire replace
setblock ~169 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~57 ~642 ~184 ~57 ~642 minecraft:redstone_wire replace
setblock ~186 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~188 ~57 ~642 ~201 ~57 ~642 minecraft:redstone_wire replace
setblock ~203 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~205 ~57 ~642 ~218 ~57 ~642 minecraft:redstone_wire replace
setblock ~220 ~57 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~57 ~642 ~228 ~57 ~642 minecraft:redstone_wire replace
setblock ~211 ~57 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~57 ~646 ~211 ~57 ~646 minecraft:redstone_wire replace
setblock ~212 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~57 ~646 ~226 ~57 ~646 minecraft:redstone_wire replace
setblock ~228 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~57 ~646 ~243 ~57 ~646 minecraft:redstone_wire replace
setblock ~245 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~57 ~646 ~260 ~57 ~646 minecraft:redstone_wire replace
setblock ~262 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~57 ~646 ~277 ~57 ~646 minecraft:redstone_wire replace
setblock ~279 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~281 ~57 ~646 ~294 ~57 ~646 minecraft:redstone_wire replace
setblock ~296 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~57 ~646 ~311 ~57 ~646 minecraft:redstone_wire replace
setblock ~313 ~57 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~57 ~646 ~321 ~57 ~646 minecraft:redstone_wire replace
setblock ~79 ~57 ~649 minecraft:redstone_wire replace
fill ~78 ~57 ~650 ~86 ~57 ~650 minecraft:redstone_wire replace
setblock ~88 ~57 ~650 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~90 ~57 ~650 ~96 ~57 ~650 minecraft:redstone_wire replace
setblock ~187 ~57 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~57 ~654 ~199 ~57 ~654 minecraft:redstone_wire replace
setblock ~201 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~57 ~654 ~216 ~57 ~654 minecraft:redstone_wire replace
setblock ~218 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~220 ~57 ~654 ~233 ~57 ~654 minecraft:redstone_wire replace
setblock ~235 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~57 ~654 ~250 ~57 ~654 minecraft:redstone_wire replace
setblock ~252 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~57 ~654 ~267 ~57 ~654 minecraft:redstone_wire replace
setblock ~269 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~57 ~654 ~284 ~57 ~654 minecraft:redstone_wire replace
setblock ~286 ~57 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~57 ~654 ~294 ~57 ~654 minecraft:redstone_wire replace
setblock ~208 ~57 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~207 ~57 ~658 ~208 ~57 ~658 minecraft:redstone_wire replace
setblock ~209 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~57 ~658 ~223 ~57 ~658 minecraft:redstone_wire replace
setblock ~225 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~227 ~57 ~658 ~240 ~57 ~658 minecraft:redstone_wire replace
setblock ~242 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~57 ~658 ~257 ~57 ~658 minecraft:redstone_wire replace
setblock ~259 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~57 ~658 ~274 ~57 ~658 minecraft:redstone_wire replace
setblock ~276 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~278 ~57 ~658 ~291 ~57 ~658 minecraft:redstone_wire replace
setblock ~293 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~57 ~658 ~308 ~57 ~658 minecraft:redstone_wire replace
setblock ~310 ~57 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~57 ~658 ~318 ~57 ~658 minecraft:redstone_wire replace
setblock ~169 ~58 ~72 minecraft:redstone_torch[lit=true] replace
setblock ~79 ~58 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~58 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~100 ~58 ~324 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~58 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~118 ~58 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~58 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~58 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~58 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~58 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~58 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~58 ~372 minecraft:redstone_torch[lit=true] replace
setblock ~199 ~58 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~58 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~58 ~396 minecraft:redstone_wire replace
setblock ~79 ~58 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~416 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~420 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~424 minecraft:redstone_torch[lit=true] replace
setblock ~112 ~58 ~428 minecraft:redstone_wire replace
setblock ~136 ~58 ~432 minecraft:redstone_wire replace
setblock ~157 ~58 ~436 minecraft:redstone_wire replace
setblock ~166 ~58 ~440 minecraft:redstone_wire replace
setblock ~79 ~58 ~444 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~448 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~452 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~456 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~460 minecraft:redstone_torch[lit=true] replace
setblock ~109 ~58 ~464 minecraft:redstone_wire replace
setblock ~130 ~58 ~468 minecraft:redstone_wire replace
setblock ~154 ~58 ~472 minecraft:redstone_wire replace
setblock ~181 ~58 ~476 minecraft:redstone_wire replace
setblock ~205 ~58 ~480 minecraft:redstone_wire replace
setblock ~79 ~58 ~484 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~488 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~492 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~496 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~500 minecraft:redstone_torch[lit=true] replace
setblock ~106 ~58 ~504 minecraft:redstone_wire replace
setblock ~127 ~58 ~508 minecraft:redstone_wire replace
setblock ~151 ~58 ~512 minecraft:redstone_wire replace
setblock ~178 ~58 ~516 minecraft:redstone_wire replace
setblock ~202 ~58 ~520 minecraft:redstone_wire replace
setblock ~79 ~58 ~524 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~528 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~532 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~536 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~540 minecraft:redstone_torch[lit=true] replace
setblock ~103 ~58 ~544 minecraft:redstone_wire replace
setblock ~124 ~58 ~548 minecraft:redstone_wire replace
setblock ~145 ~58 ~552 minecraft:redstone_wire replace
setblock ~175 ~58 ~556 minecraft:redstone_wire replace
setblock ~196 ~58 ~560 minecraft:redstone_wire replace
setblock ~79 ~58 ~564 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~58 ~568 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~572 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~576 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~580 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~58 ~584 minecraft:redstone_wire replace
setblock ~121 ~58 ~588 minecraft:redstone_wire replace
setblock ~142 ~58 ~592 minecraft:redstone_wire replace
setblock ~172 ~58 ~596 minecraft:redstone_wire replace
setblock ~193 ~58 ~600 minecraft:redstone_wire replace
setblock ~82 ~58 ~604 minecraft:redstone_torch[lit=true] replace
setblock ~85 ~58 ~608 minecraft:redstone_torch[lit=true] replace
setblock ~88 ~58 ~612 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~58 ~616 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~58 ~620 minecraft:redstone_wire replace
setblock ~115 ~58 ~624 minecraft:redstone_wire replace
setblock ~148 ~58 ~628 minecraft:redstone_wire replace
setblock ~160 ~58 ~632 minecraft:redstone_wire replace
setblock ~184 ~58 ~636 minecraft:redstone_wire replace
setblock ~133 ~58 ~640 minecraft:redstone_wire replace
setblock ~211 ~58 ~644 minecraft:redstone_wire replace
setblock ~79 ~58 ~648 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~58 ~652 minecraft:redstone_wire replace
setblock ~208 ~58 ~656 minecraft:redstone_wire replace
fill ~168 ~59 ~72 ~168 ~59 ~84 minecraft:redstone_wire replace
setblock ~168 ~59 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~88 ~168 ~59 ~100 minecraft:redstone_wire replace
setblock ~168 ~59 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~104 ~168 ~59 ~116 minecraft:redstone_wire replace
setblock ~168 ~59 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~120 ~168 ~59 ~132 minecraft:redstone_wire replace
setblock ~168 ~59 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~136 ~168 ~59 ~148 minecraft:redstone_wire replace
setblock ~168 ~59 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~152 ~168 ~59 ~164 minecraft:redstone_wire replace
setblock ~168 ~59 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~168 ~168 ~59 ~180 minecraft:redstone_wire replace
setblock ~168 ~59 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~184 ~168 ~59 ~196 minecraft:redstone_wire replace
setblock ~168 ~59 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~200 ~168 ~59 ~212 minecraft:redstone_wire replace
setblock ~168 ~59 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~216 ~168 ~59 ~228 minecraft:redstone_wire replace
setblock ~168 ~59 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~232 ~168 ~59 ~244 minecraft:redstone_wire replace
fill ~78 ~59 ~244 ~78 ~59 ~256 minecraft:redstone_wire replace
setblock ~168 ~59 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~248 ~168 ~59 ~260 minecraft:redstone_wire replace
setblock ~78 ~59 ~258 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~260 ~78 ~59 ~272 minecraft:redstone_wire replace
setblock ~168 ~59 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~264 ~81 ~59 ~276 minecraft:redstone_wire replace
fill ~168 ~59 ~264 ~168 ~59 ~276 minecraft:redstone_wire replace
setblock ~78 ~59 ~274 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~276 ~78 ~59 ~288 minecraft:redstone_wire replace
setblock ~81 ~59 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~278 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~280 ~81 ~59 ~292 minecraft:redstone_wire replace
fill ~84 ~59 ~280 ~84 ~59 ~292 minecraft:redstone_wire replace
fill ~168 ~59 ~280 ~168 ~59 ~292 minecraft:redstone_wire replace
setblock ~78 ~59 ~290 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~292 ~78 ~59 ~304 minecraft:redstone_wire replace
fill ~87 ~59 ~292 ~87 ~59 ~304 minecraft:redstone_wire replace
setblock ~81 ~59 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~294 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~296 ~81 ~59 ~308 minecraft:redstone_wire replace
fill ~84 ~59 ~296 ~84 ~59 ~308 minecraft:redstone_wire replace
fill ~168 ~59 ~296 ~168 ~59 ~308 minecraft:redstone_wire replace
setblock ~78 ~59 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~306 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~308 ~78 ~59 ~320 minecraft:redstone_wire replace
fill ~87 ~59 ~308 ~87 ~59 ~320 minecraft:redstone_wire replace
setblock ~81 ~59 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~310 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~312 ~81 ~59 ~324 minecraft:redstone_wire replace
fill ~84 ~59 ~312 ~84 ~59 ~324 minecraft:redstone_wire replace
fill ~168 ~59 ~312 ~168 ~59 ~324 minecraft:redstone_wire replace
fill ~90 ~59 ~316 ~90 ~59 ~328 minecraft:redstone_wire replace
fill ~99 ~59 ~320 ~99 ~59 ~326 minecraft:redstone_wire replace
setblock ~78 ~59 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~322 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~324 ~78 ~59 ~336 minecraft:redstone_wire replace
fill ~87 ~59 ~324 ~87 ~59 ~336 minecraft:redstone_wire replace
setblock ~81 ~59 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~326 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~328 ~81 ~59 ~340 minecraft:redstone_wire replace
fill ~84 ~59 ~328 ~84 ~59 ~340 minecraft:redstone_wire replace
setblock ~99 ~59 ~328 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~328 ~168 ~59 ~340 minecraft:redstone_wire replace
setblock ~90 ~59 ~330 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~332 ~90 ~59 ~344 minecraft:redstone_wire replace
fill ~117 ~59 ~336 ~117 ~59 ~342 minecraft:redstone_wire replace
setblock ~78 ~59 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~338 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~340 ~78 ~59 ~352 minecraft:redstone_wire replace
fill ~87 ~59 ~340 ~87 ~59 ~352 minecraft:redstone_wire replace
setblock ~81 ~59 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~342 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~344 ~81 ~59 ~356 minecraft:redstone_wire replace
fill ~84 ~59 ~344 ~84 ~59 ~356 minecraft:redstone_wire replace
setblock ~117 ~59 ~344 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~344 ~168 ~59 ~356 minecraft:redstone_wire replace
setblock ~90 ~59 ~346 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~348 ~90 ~59 ~360 minecraft:redstone_wire replace
fill ~162 ~59 ~352 ~162 ~59 ~358 minecraft:redstone_wire replace
setblock ~78 ~59 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~354 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~356 ~78 ~59 ~368 minecraft:redstone_wire replace
fill ~87 ~59 ~356 ~87 ~59 ~368 minecraft:redstone_wire replace
setblock ~81 ~59 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~358 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~360 ~81 ~59 ~372 minecraft:redstone_wire replace
fill ~84 ~59 ~360 ~84 ~59 ~372 minecraft:redstone_wire replace
setblock ~162 ~59 ~360 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~360 ~168 ~59 ~372 minecraft:redstone_wire replace
fill ~198 ~59 ~360 ~198 ~59 ~372 minecraft:redstone_wire replace
setblock ~90 ~59 ~362 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~364 ~90 ~59 ~376 minecraft:redstone_wire replace
fill ~138 ~59 ~368 ~138 ~59 ~374 minecraft:redstone_wire replace
setblock ~78 ~59 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~370 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~372 ~78 ~59 ~384 minecraft:redstone_wire replace
fill ~87 ~59 ~372 ~87 ~59 ~384 minecraft:redstone_wire replace
setblock ~81 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~198 ~59 ~374 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~376 ~81 ~59 ~388 minecraft:redstone_wire replace
fill ~84 ~59 ~376 ~84 ~59 ~388 minecraft:redstone_wire replace
setblock ~138 ~59 ~376 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~59 ~376 ~168 ~59 ~388 minecraft:redstone_wire replace
fill ~198 ~59 ~376 ~198 ~59 ~388 minecraft:redstone_wire replace
setblock ~90 ~59 ~378 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~380 ~90 ~59 ~392 minecraft:redstone_wire replace
setblock ~78 ~59 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~386 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~388 ~78 ~59 ~400 minecraft:redstone_wire replace
fill ~87 ~59 ~388 ~87 ~59 ~400 minecraft:redstone_wire replace
setblock ~198 ~59 ~389 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~168 ~59 ~390 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~59 ~390 ~198 ~59 ~392 minecraft:redstone_wire replace
fill ~81 ~59 ~392 ~81 ~59 ~404 minecraft:redstone_wire replace
fill ~84 ~59 ~392 ~84 ~59 ~404 minecraft:redstone_wire replace
fill ~168 ~59 ~392 ~168 ~59 ~396 minecraft:redstone_wire replace
setblock ~90 ~59 ~394 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~396 ~90 ~59 ~408 minecraft:redstone_wire replace
fill ~189 ~59 ~396 ~189 ~59 ~400 minecraft:redstone_wire replace
setblock ~78 ~59 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~402 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~404 ~78 ~59 ~416 minecraft:redstone_wire replace
fill ~87 ~59 ~404 ~87 ~59 ~416 minecraft:redstone_wire replace
setblock ~81 ~59 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~406 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~408 ~81 ~59 ~420 minecraft:redstone_wire replace
fill ~84 ~59 ~408 ~84 ~59 ~420 minecraft:redstone_wire replace
setblock ~90 ~59 ~410 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~412 ~90 ~59 ~424 minecraft:redstone_wire replace
setblock ~78 ~59 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~418 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~420 ~78 ~59 ~432 minecraft:redstone_wire replace
fill ~87 ~59 ~420 ~87 ~59 ~432 minecraft:redstone_wire replace
setblock ~81 ~59 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~422 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~424 ~81 ~59 ~436 minecraft:redstone_wire replace
fill ~84 ~59 ~424 ~84 ~59 ~436 minecraft:redstone_wire replace
setblock ~90 ~59 ~425 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~426 ~90 ~59 ~438 minecraft:redstone_wire replace
fill ~111 ~59 ~428 ~111 ~59 ~432 minecraft:redstone_wire replace
fill ~135 ~59 ~432 ~135 ~59 ~436 minecraft:redstone_wire replace
setblock ~78 ~59 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~434 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~436 ~78 ~59 ~448 minecraft:redstone_wire replace
fill ~87 ~59 ~436 ~87 ~59 ~448 minecraft:redstone_wire replace
fill ~156 ~59 ~436 ~156 ~59 ~440 minecraft:redstone_wire replace
setblock ~81 ~59 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~438 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~440 ~81 ~59 ~452 minecraft:redstone_wire replace
fill ~84 ~59 ~440 ~84 ~59 ~452 minecraft:redstone_wire replace
setblock ~90 ~59 ~440 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~59 ~440 ~165 ~59 ~444 minecraft:redstone_wire replace
fill ~90 ~59 ~442 ~90 ~59 ~454 minecraft:redstone_wire replace
setblock ~78 ~59 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~450 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~452 ~78 ~59 ~464 minecraft:redstone_wire replace
fill ~87 ~59 ~452 ~87 ~59 ~464 minecraft:redstone_wire replace
setblock ~84 ~59 ~453 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~454 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~454 ~84 ~59 ~466 minecraft:redstone_wire replace
fill ~81 ~59 ~456 ~81 ~59 ~468 minecraft:redstone_wire replace
setblock ~90 ~59 ~456 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~458 ~90 ~59 ~470 minecraft:redstone_wire replace
fill ~108 ~59 ~464 ~108 ~59 ~468 minecraft:redstone_wire replace
setblock ~78 ~59 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~466 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~468 ~78 ~59 ~480 minecraft:redstone_wire replace
setblock ~84 ~59 ~468 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~468 ~87 ~59 ~480 minecraft:redstone_wire replace
fill ~129 ~59 ~468 ~129 ~59 ~472 minecraft:redstone_wire replace
setblock ~81 ~59 ~470 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~470 ~84 ~59 ~482 minecraft:redstone_wire replace
fill ~81 ~59 ~472 ~81 ~59 ~484 minecraft:redstone_wire replace
setblock ~90 ~59 ~472 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~59 ~472 ~153 ~59 ~476 minecraft:redstone_wire replace
fill ~90 ~59 ~474 ~90 ~59 ~486 minecraft:redstone_wire replace
fill ~180 ~59 ~476 ~180 ~59 ~480 minecraft:redstone_wire replace
fill ~204 ~59 ~480 ~204 ~59 ~484 minecraft:redstone_wire replace
setblock ~78 ~59 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~482 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~484 ~78 ~59 ~496 minecraft:redstone_wire replace
setblock ~84 ~59 ~484 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~484 ~87 ~59 ~496 minecraft:redstone_wire replace
setblock ~81 ~59 ~486 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~486 ~84 ~59 ~498 minecraft:redstone_wire replace
fill ~81 ~59 ~488 ~81 ~59 ~500 minecraft:redstone_wire replace
setblock ~90 ~59 ~488 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~490 ~90 ~59 ~502 minecraft:redstone_wire replace
setblock ~87 ~59 ~497 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~59 ~498 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~498 ~87 ~59 ~510 minecraft:redstone_wire replace
fill ~78 ~59 ~500 ~78 ~59 ~512 minecraft:redstone_wire replace
setblock ~84 ~59 ~500 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~502 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~502 ~84 ~59 ~514 minecraft:redstone_wire replace
fill ~81 ~59 ~504 ~81 ~59 ~516 minecraft:redstone_wire replace
setblock ~90 ~59 ~504 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~59 ~504 ~105 ~59 ~508 minecraft:redstone_wire replace
fill ~90 ~59 ~506 ~90 ~59 ~518 minecraft:redstone_wire replace
fill ~126 ~59 ~508 ~126 ~59 ~512 minecraft:redstone_wire replace
setblock ~87 ~59 ~512 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~59 ~512 ~150 ~59 ~516 minecraft:redstone_wire replace
setblock ~78 ~59 ~514 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~514 ~87 ~59 ~526 minecraft:redstone_wire replace
fill ~78 ~59 ~516 ~78 ~59 ~528 minecraft:redstone_wire replace
setblock ~84 ~59 ~516 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~59 ~516 ~177 ~59 ~520 minecraft:redstone_wire replace
setblock ~81 ~59 ~518 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~518 ~84 ~59 ~530 minecraft:redstone_wire replace
fill ~81 ~59 ~520 ~81 ~59 ~532 minecraft:redstone_wire replace
setblock ~90 ~59 ~520 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~59 ~520 ~201 ~59 ~524 minecraft:redstone_wire replace
fill ~90 ~59 ~522 ~90 ~59 ~534 minecraft:redstone_wire replace
setblock ~87 ~59 ~528 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~59 ~530 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~530 ~87 ~59 ~542 minecraft:redstone_wire replace
setblock ~84 ~59 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~532 ~78 ~59 ~544 minecraft:redstone_wire replace
fill ~84 ~59 ~532 ~84 ~59 ~544 minecraft:redstone_wire replace
setblock ~81 ~59 ~534 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~536 ~81 ~59 ~548 minecraft:redstone_wire replace
setblock ~90 ~59 ~536 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~538 ~90 ~59 ~550 minecraft:redstone_wire replace
setblock ~87 ~59 ~544 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~59 ~544 ~102 ~59 ~548 minecraft:redstone_wire replace
setblock ~78 ~59 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~546 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~546 ~87 ~59 ~558 minecraft:redstone_wire replace
fill ~78 ~59 ~548 ~78 ~59 ~560 minecraft:redstone_wire replace
fill ~84 ~59 ~548 ~84 ~59 ~560 minecraft:redstone_wire replace
fill ~123 ~59 ~548 ~123 ~59 ~552 minecraft:redstone_wire replace
setblock ~81 ~59 ~550 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~552 ~81 ~59 ~564 minecraft:redstone_wire replace
setblock ~90 ~59 ~552 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~59 ~552 ~144 ~59 ~556 minecraft:redstone_wire replace
fill ~90 ~59 ~554 ~90 ~59 ~566 minecraft:redstone_wire replace
fill ~174 ~59 ~556 ~174 ~59 ~560 minecraft:redstone_wire replace
setblock ~87 ~59 ~560 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~59 ~560 ~195 ~59 ~564 minecraft:redstone_wire replace
setblock ~78 ~59 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~562 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~562 ~87 ~59 ~574 minecraft:redstone_wire replace
fill ~78 ~59 ~564 ~78 ~59 ~576 minecraft:redstone_wire replace
fill ~84 ~59 ~564 ~84 ~59 ~576 minecraft:redstone_wire replace
setblock ~81 ~59 ~566 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~568 ~81 ~59 ~580 minecraft:redstone_wire replace
setblock ~90 ~59 ~568 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~570 ~90 ~59 ~582 minecraft:redstone_wire replace
setblock ~87 ~59 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~576 ~87 ~59 ~588 minecraft:redstone_wire replace
setblock ~78 ~59 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~578 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~580 ~78 ~59 ~592 minecraft:redstone_wire replace
fill ~84 ~59 ~580 ~84 ~59 ~592 minecraft:redstone_wire replace
setblock ~81 ~59 ~582 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~584 ~81 ~59 ~596 minecraft:redstone_wire replace
setblock ~90 ~59 ~584 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~59 ~584 ~96 ~59 ~588 minecraft:redstone_wire replace
fill ~90 ~59 ~586 ~90 ~59 ~598 minecraft:redstone_wire replace
fill ~120 ~59 ~588 ~120 ~59 ~592 minecraft:redstone_wire replace
setblock ~87 ~59 ~590 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~592 ~87 ~59 ~604 minecraft:redstone_wire replace
fill ~141 ~59 ~592 ~141 ~59 ~596 minecraft:redstone_wire replace
setblock ~78 ~59 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~84 ~59 ~594 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~596 ~78 ~59 ~608 minecraft:redstone_wire replace
fill ~84 ~59 ~596 ~84 ~59 ~608 minecraft:redstone_wire replace
fill ~171 ~59 ~596 ~171 ~59 ~600 minecraft:redstone_wire replace
setblock ~81 ~59 ~598 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~59 ~600 ~81 ~59 ~606 minecraft:redstone_wire replace
setblock ~90 ~59 ~600 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~59 ~600 ~192 ~59 ~604 minecraft:redstone_wire replace
fill ~90 ~59 ~602 ~90 ~59 ~614 minecraft:redstone_wire replace
setblock ~87 ~59 ~606 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~81 ~59 ~608 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~59 ~608 ~87 ~59 ~614 minecraft:redstone_wire replace
setblock ~84 ~59 ~609 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~78 ~59 ~610 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~59 ~610 ~84 ~59 ~612 minecraft:redstone_wire replace
fill ~78 ~59 ~612 ~78 ~59 ~624 minecraft:redstone_wire replace
setblock ~90 ~59 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~87 ~59 ~616 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~59 ~616 ~90 ~59 ~620 minecraft:redstone_wire replace
fill ~93 ~59 ~620 ~93 ~59 ~624 minecraft:redstone_wire replace
fill ~114 ~59 ~624 ~114 ~59 ~628 minecraft:redstone_wire replace
setblock ~78 ~59 ~626 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~628 ~78 ~59 ~640 minecraft:redstone_wire replace
fill ~147 ~59 ~628 ~147 ~59 ~632 minecraft:redstone_wire replace
fill ~159 ~59 ~632 ~159 ~59 ~636 minecraft:redstone_wire replace
fill ~183 ~59 ~636 ~183 ~59 ~640 minecraft:redstone_wire replace
fill ~132 ~59 ~640 ~132 ~59 ~644 minecraft:redstone_wire replace
setblock ~78 ~59 ~642 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~59 ~644 ~78 ~59 ~650 minecraft:redstone_wire replace
fill ~210 ~59 ~644 ~210 ~59 ~648 minecraft:redstone_wire replace
setblock ~78 ~59 ~652 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~59 ~652 ~186 ~59 ~656 minecraft:redstone_wire replace
fill ~207 ~59 ~656 ~207 ~59 ~660 minecraft:redstone_wire replace
setblock ~99 ~60 ~329 minecraft:redstone_wire replace
setblock ~117 ~60 ~345 minecraft:redstone_wire replace
setblock ~162 ~60 ~361 minecraft:redstone_wire replace
setblock ~138 ~60 ~377 minecraft:redstone_wire replace
setblock ~198 ~60 ~393 minecraft:redstone_wire replace
setblock ~168 ~60 ~397 minecraft:redstone_wire replace
setblock ~189 ~60 ~401 minecraft:redstone_wire replace
setblock ~111 ~60 ~433 minecraft:redstone_wire replace
setblock ~135 ~60 ~437 minecraft:redstone_wire replace
setblock ~156 ~60 ~441 minecraft:redstone_wire replace
setblock ~165 ~60 ~445 minecraft:redstone_wire replace
setblock ~108 ~60 ~469 minecraft:redstone_wire replace
setblock ~129 ~60 ~473 minecraft:redstone_wire replace
setblock ~153 ~60 ~477 minecraft:redstone_wire replace
setblock ~180 ~60 ~481 minecraft:redstone_wire replace
setblock ~204 ~60 ~485 minecraft:redstone_wire replace
setblock ~105 ~60 ~509 minecraft:redstone_wire replace
setblock ~126 ~60 ~513 minecraft:redstone_wire replace
setblock ~150 ~60 ~517 minecraft:redstone_wire replace
setblock ~177 ~60 ~521 minecraft:redstone_wire replace
setblock ~201 ~60 ~525 minecraft:redstone_wire replace
setblock ~102 ~60 ~549 minecraft:redstone_wire replace
setblock ~123 ~60 ~553 minecraft:redstone_wire replace
setblock ~144 ~60 ~557 minecraft:redstone_wire replace
setblock ~174 ~60 ~561 minecraft:redstone_wire replace
setblock ~195 ~60 ~565 minecraft:redstone_wire replace
setblock ~96 ~60 ~589 minecraft:redstone_wire replace
setblock ~120 ~60 ~593 minecraft:redstone_wire replace
setblock ~141 ~60 ~597 minecraft:redstone_wire replace
setblock ~171 ~60 ~601 minecraft:redstone_wire replace
setblock ~192 ~60 ~605 minecraft:redstone_wire replace
setblock ~81 ~60 ~609 minecraft:redstone_wire replace
setblock ~84 ~60 ~613 minecraft:redstone_wire replace
setblock ~87 ~60 ~617 minecraft:redstone_wire replace
setblock ~90 ~60 ~621 minecraft:redstone_wire replace
setblock ~93 ~60 ~625 minecraft:redstone_wire replace
setblock ~114 ~60 ~629 minecraft:redstone_wire replace
setblock ~147 ~60 ~633 minecraft:redstone_wire replace
setblock ~159 ~60 ~637 minecraft:redstone_wire replace
setblock ~183 ~60 ~641 minecraft:redstone_wire replace
setblock ~132 ~60 ~645 minecraft:redstone_wire replace
setblock ~210 ~60 ~649 minecraft:redstone_wire replace
setblock ~78 ~60 ~653 minecraft:redstone_wire replace
setblock ~186 ~60 ~657 minecraft:redstone_wire replace
setblock ~207 ~60 ~661 minecraft:redstone_wire replace
fill ~99 ~61 ~330 ~104 ~61 ~330 minecraft:redstone_wire replace
setblock ~103 ~61 ~331 minecraft:redstone_wire replace
fill ~117 ~61 ~346 ~122 ~61 ~346 minecraft:redstone_wire replace
setblock ~121 ~61 ~347 minecraft:redstone_wire replace
fill ~162 ~61 ~362 ~164 ~61 ~362 minecraft:redstone_wire replace
setblock ~163 ~61 ~363 minecraft:redstone_wire replace
fill ~138 ~61 ~378 ~140 ~61 ~378 minecraft:redstone_wire replace
setblock ~139 ~61 ~379 minecraft:redstone_wire replace
fill ~186 ~61 ~394 ~187 ~61 ~394 minecraft:redstone_wire replace
setblock ~188 ~61 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~61 ~394 ~206 ~61 ~394 minecraft:redstone_wire replace
setblock ~207 ~61 ~394 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~208 ~61 ~394 ~212 ~61 ~394 minecraft:redstone_wire replace
setblock ~187 ~61 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~190 ~61 ~395 minecraft:redstone_wire replace
setblock ~208 ~61 ~395 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~211 ~61 ~395 minecraft:redstone_wire replace
fill ~81 ~61 ~398 ~90 ~61 ~398 minecraft:redstone_wire replace
setblock ~92 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~94 ~61 ~398 ~107 ~61 ~398 minecraft:redstone_wire replace
setblock ~109 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~61 ~398 ~124 ~61 ~398 minecraft:redstone_wire replace
setblock ~126 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~61 ~398 ~141 ~61 ~398 minecraft:redstone_wire replace
setblock ~143 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~61 ~398 ~158 ~61 ~398 minecraft:redstone_wire replace
setblock ~160 ~61 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~61 ~398 ~174 ~61 ~398 minecraft:redstone_wire replace
setblock ~176 ~61 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~178 ~61 ~398 ~191 ~61 ~398 minecraft:redstone_wire replace
setblock ~193 ~61 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~195 ~61 ~398 ~208 ~61 ~398 minecraft:redstone_wire replace
setblock ~209 ~61 ~398 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~210 ~61 ~398 ~212 ~61 ~398 minecraft:redstone_wire replace
setblock ~82 ~61 ~399 minecraft:redstone_wire replace
setblock ~208 ~61 ~399 minecraft:redstone_wire replace
setblock ~211 ~61 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~61 ~402 ~191 ~61 ~402 minecraft:redstone_wire replace
setblock ~187 ~61 ~403 minecraft:redstone_wire replace
setblock ~190 ~61 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~61 ~434 ~116 ~61 ~434 minecraft:redstone_wire replace
setblock ~115 ~61 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~61 ~438 ~137 ~61 ~438 minecraft:redstone_wire replace
setblock ~136 ~61 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~61 ~442 ~158 ~61 ~442 minecraft:redstone_wire replace
setblock ~157 ~61 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~61 ~446 ~167 ~61 ~446 minecraft:redstone_wire replace
setblock ~166 ~61 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~61 ~470 ~113 ~61 ~470 minecraft:redstone_wire replace
setblock ~112 ~61 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~61 ~474 ~134 ~61 ~474 minecraft:redstone_wire replace
setblock ~133 ~61 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~61 ~478 ~155 ~61 ~478 minecraft:redstone_wire replace
setblock ~154 ~61 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~177 ~61 ~482 ~180 ~61 ~482 minecraft:redstone_wire replace
setblock ~178 ~61 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~61 ~486 ~206 ~61 ~486 minecraft:redstone_wire replace
setblock ~205 ~61 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~61 ~510 ~110 ~61 ~510 minecraft:redstone_wire replace
setblock ~109 ~61 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~61 ~514 ~131 ~61 ~514 minecraft:redstone_wire replace
setblock ~130 ~61 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~150 ~61 ~518 ~152 ~61 ~518 minecraft:redstone_wire replace
setblock ~151 ~61 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~174 ~61 ~522 ~177 ~61 ~522 minecraft:redstone_wire replace
setblock ~175 ~61 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~61 ~526 ~203 ~61 ~526 minecraft:redstone_wire replace
setblock ~202 ~61 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~61 ~550 ~107 ~61 ~550 minecraft:redstone_wire replace
setblock ~106 ~61 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~61 ~554 ~128 ~61 ~554 minecraft:redstone_wire replace
setblock ~127 ~61 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~61 ~558 ~146 ~61 ~558 minecraft:redstone_wire replace
setblock ~145 ~61 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~171 ~61 ~562 ~174 ~61 ~562 minecraft:redstone_wire replace
setblock ~172 ~61 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~61 ~566 ~197 ~61 ~566 minecraft:redstone_wire replace
setblock ~196 ~61 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~61 ~590 ~101 ~61 ~590 minecraft:redstone_wire replace
setblock ~100 ~61 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~61 ~594 ~125 ~61 ~594 minecraft:redstone_wire replace
setblock ~124 ~61 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~141 ~61 ~598 ~143 ~61 ~598 minecraft:redstone_wire replace
setblock ~142 ~61 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~168 ~61 ~602 ~171 ~61 ~602 minecraft:redstone_wire replace
setblock ~169 ~61 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~61 ~606 ~194 ~61 ~606 minecraft:redstone_wire replace
setblock ~193 ~61 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~61 ~610 ~86 ~61 ~610 minecraft:redstone_wire replace
setblock ~85 ~61 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~61 ~614 ~89 ~61 ~614 minecraft:redstone_wire replace
setblock ~88 ~61 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~61 ~618 ~92 ~61 ~618 minecraft:redstone_wire replace
setblock ~91 ~61 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~90 ~61 ~622 ~95 ~61 ~622 minecraft:redstone_wire replace
setblock ~94 ~61 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~93 ~61 ~626 ~98 ~61 ~626 minecraft:redstone_wire replace
setblock ~97 ~61 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~61 ~630 ~119 ~61 ~630 minecraft:redstone_wire replace
setblock ~118 ~61 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~61 ~634 ~149 ~61 ~634 minecraft:redstone_wire replace
setblock ~148 ~61 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~61 ~638 ~161 ~61 ~638 minecraft:redstone_wire replace
setblock ~160 ~61 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~180 ~61 ~642 ~183 ~61 ~642 minecraft:redstone_wire replace
setblock ~181 ~61 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~61 ~646 ~88 ~61 ~646 minecraft:redstone_wire replace
setblock ~90 ~61 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~61 ~646 ~105 ~61 ~646 minecraft:redstone_wire replace
setblock ~107 ~61 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~61 ~646 ~122 ~61 ~646 minecraft:redstone_wire replace
setblock ~124 ~61 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~61 ~646 ~137 ~61 ~646 minecraft:redstone_wire replace
setblock ~138 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~61 ~646 ~151 ~61 ~646 minecraft:redstone_wire replace
setblock ~153 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~155 ~61 ~646 ~167 ~61 ~646 minecraft:redstone_wire replace
setblock ~169 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~61 ~646 ~183 ~61 ~646 minecraft:redstone_wire replace
setblock ~185 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~61 ~646 ~199 ~61 ~646 minecraft:redstone_wire replace
setblock ~200 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~82 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~61 ~650 ~215 ~61 ~650 minecraft:redstone_wire replace
setblock ~216 ~61 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~61 ~650 ~218 ~61 ~650 minecraft:redstone_wire replace
setblock ~217 ~61 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~61 ~654 ~80 ~61 ~654 minecraft:redstone_wire replace
setblock ~79 ~61 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~61 ~658 ~186 ~61 ~658 minecraft:redstone_wire replace
setblock ~184 ~61 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~61 ~662 ~212 ~61 ~662 minecraft:redstone_wire replace
setblock ~213 ~61 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~214 ~61 ~662 ~215 ~61 ~662 minecraft:redstone_wire replace
setblock ~214 ~61 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~62 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~62 ~348 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~62 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~62 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~62 ~396 minecraft:redstone_wire replace
setblock ~190 ~62 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~62 ~396 minecraft:redstone_wire replace
setblock ~211 ~62 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~62 ~400 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~62 ~400 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~62 ~400 minecraft:redstone_wire replace
setblock ~187 ~62 ~404 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~62 ~404 minecraft:redstone_wire replace
setblock ~115 ~62 ~436 minecraft:redstone_wire replace
setblock ~136 ~62 ~440 minecraft:redstone_wire replace
setblock ~157 ~62 ~444 minecraft:redstone_wire replace
setblock ~166 ~62 ~448 minecraft:redstone_wire replace
setblock ~112 ~62 ~472 minecraft:redstone_wire replace
setblock ~133 ~62 ~476 minecraft:redstone_wire replace
setblock ~154 ~62 ~480 minecraft:redstone_wire replace
setblock ~178 ~62 ~484 minecraft:redstone_wire replace
setblock ~205 ~62 ~488 minecraft:redstone_wire replace
setblock ~109 ~62 ~512 minecraft:redstone_wire replace
setblock ~130 ~62 ~516 minecraft:redstone_wire replace
setblock ~151 ~62 ~520 minecraft:redstone_wire replace
setblock ~175 ~62 ~524 minecraft:redstone_wire replace
setblock ~202 ~62 ~528 minecraft:redstone_wire replace
setblock ~106 ~62 ~552 minecraft:redstone_wire replace
setblock ~127 ~62 ~556 minecraft:redstone_wire replace
setblock ~145 ~62 ~560 minecraft:redstone_wire replace
setblock ~172 ~62 ~564 minecraft:redstone_wire replace
setblock ~196 ~62 ~568 minecraft:redstone_wire replace
setblock ~100 ~62 ~592 minecraft:redstone_wire replace
setblock ~124 ~62 ~596 minecraft:redstone_wire replace
setblock ~142 ~62 ~600 minecraft:redstone_wire replace
setblock ~169 ~62 ~604 minecraft:redstone_wire replace
setblock ~193 ~62 ~608 minecraft:redstone_wire replace
setblock ~85 ~62 ~612 minecraft:redstone_wire replace
setblock ~88 ~62 ~616 minecraft:redstone_wire replace
setblock ~91 ~62 ~620 minecraft:redstone_wire replace
setblock ~94 ~62 ~624 minecraft:redstone_wire replace
setblock ~97 ~62 ~628 minecraft:redstone_wire replace
setblock ~118 ~62 ~632 minecraft:redstone_wire replace
setblock ~148 ~62 ~636 minecraft:redstone_wire replace
setblock ~160 ~62 ~640 minecraft:redstone_wire replace
setblock ~181 ~62 ~644 minecraft:redstone_wire replace
setblock ~82 ~62 ~648 minecraft:redstone_wire replace
setblock ~103 ~62 ~648 minecraft:redstone_wire replace
setblock ~121 ~62 ~648 minecraft:redstone_wire replace
setblock ~139 ~62 ~648 minecraft:redstone_wire replace
setblock ~163 ~62 ~648 minecraft:redstone_wire replace
setblock ~199 ~62 ~648 minecraft:redstone_wire replace
setblock ~217 ~62 ~652 minecraft:redstone_wire replace
setblock ~79 ~62 ~656 minecraft:redstone_wire replace
setblock ~184 ~62 ~660 minecraft:redstone_wire replace
setblock ~214 ~62 ~664 minecraft:redstone_wire replace
fill ~102 ~63 ~328 ~102 ~63 ~330 minecraft:redstone_wire replace
setblock ~102 ~63 ~331 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~332 ~102 ~63 ~344 minecraft:redstone_wire replace
fill ~120 ~63 ~344 ~120 ~63 ~346 minecraft:redstone_wire replace
setblock ~102 ~63 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~347 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~348 ~102 ~63 ~360 minecraft:redstone_wire replace
fill ~120 ~63 ~348 ~120 ~63 ~360 minecraft:redstone_wire replace
fill ~162 ~63 ~360 ~162 ~63 ~362 minecraft:redstone_wire replace
setblock ~102 ~63 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~364 ~102 ~63 ~376 minecraft:redstone_wire replace
fill ~120 ~63 ~364 ~120 ~63 ~376 minecraft:redstone_wire replace
fill ~162 ~63 ~364 ~162 ~63 ~376 minecraft:redstone_wire replace
fill ~138 ~63 ~376 ~138 ~63 ~378 minecraft:redstone_wire replace
setblock ~102 ~63 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~379 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~380 ~102 ~63 ~392 minecraft:redstone_wire replace
fill ~120 ~63 ~380 ~120 ~63 ~392 minecraft:redstone_wire replace
fill ~138 ~63 ~380 ~138 ~63 ~392 minecraft:redstone_wire replace
fill ~162 ~63 ~380 ~162 ~63 ~392 minecraft:redstone_wire replace
fill ~210 ~63 ~380 ~210 ~63 ~384 minecraft:redstone_wire replace
setblock ~207 ~63 ~384 minecraft:redstone_wire replace
setblock ~207 ~63 ~386 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~63 ~386 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~63 ~388 minecraft:redstone_wire replace
fill ~207 ~63 ~388 ~207 ~63 ~400 minecraft:redstone_wire replace
fill ~210 ~63 ~388 ~210 ~63 ~400 minecraft:redstone_wire replace
setblock ~189 ~63 ~390 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~63 ~392 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~63 ~392 ~189 ~63 ~404 minecraft:redstone_wire replace
setblock ~102 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~63 ~394 ~186 ~63 ~404 minecraft:redstone_wire replace
setblock ~81 ~63 ~396 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~396 ~102 ~63 ~408 minecraft:redstone_wire replace
fill ~120 ~63 ~396 ~120 ~63 ~408 minecraft:redstone_wire replace
fill ~138 ~63 ~396 ~138 ~63 ~408 minecraft:redstone_wire replace
fill ~162 ~63 ~396 ~162 ~63 ~408 minecraft:redstone_wire replace
fill ~81 ~63 ~398 ~81 ~63 ~408 minecraft:redstone_wire replace
setblock ~81 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~412 ~81 ~63 ~424 minecraft:redstone_wire replace
fill ~102 ~63 ~412 ~102 ~63 ~424 minecraft:redstone_wire replace
fill ~120 ~63 ~412 ~120 ~63 ~424 minecraft:redstone_wire replace
fill ~138 ~63 ~412 ~138 ~63 ~424 minecraft:redstone_wire replace
fill ~162 ~63 ~412 ~162 ~63 ~424 minecraft:redstone_wire replace
setblock ~81 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~428 ~81 ~63 ~440 minecraft:redstone_wire replace
fill ~102 ~63 ~428 ~102 ~63 ~440 minecraft:redstone_wire replace
fill ~120 ~63 ~428 ~120 ~63 ~440 minecraft:redstone_wire replace
fill ~138 ~63 ~428 ~138 ~63 ~440 minecraft:redstone_wire replace
fill ~162 ~63 ~428 ~162 ~63 ~440 minecraft:redstone_wire replace
fill ~114 ~63 ~432 ~114 ~63 ~436 minecraft:redstone_wire replace
fill ~135 ~63 ~436 ~135 ~63 ~440 minecraft:redstone_wire replace
fill ~156 ~63 ~440 ~156 ~63 ~444 minecraft:redstone_wire replace
setblock ~81 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~444 ~81 ~63 ~456 minecraft:redstone_wire replace
fill ~102 ~63 ~444 ~102 ~63 ~456 minecraft:redstone_wire replace
fill ~120 ~63 ~444 ~120 ~63 ~456 minecraft:redstone_wire replace
fill ~138 ~63 ~444 ~138 ~63 ~456 minecraft:redstone_wire replace
fill ~162 ~63 ~444 ~162 ~63 ~456 minecraft:redstone_wire replace
fill ~165 ~63 ~444 ~165 ~63 ~448 minecraft:redstone_wire replace
setblock ~81 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~460 ~81 ~63 ~472 minecraft:redstone_wire replace
fill ~102 ~63 ~460 ~102 ~63 ~472 minecraft:redstone_wire replace
fill ~120 ~63 ~460 ~120 ~63 ~472 minecraft:redstone_wire replace
fill ~138 ~63 ~460 ~138 ~63 ~472 minecraft:redstone_wire replace
fill ~162 ~63 ~460 ~162 ~63 ~472 minecraft:redstone_wire replace
fill ~111 ~63 ~468 ~111 ~63 ~472 minecraft:redstone_wire replace
fill ~132 ~63 ~472 ~132 ~63 ~476 minecraft:redstone_wire replace
setblock ~81 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~476 ~81 ~63 ~488 minecraft:redstone_wire replace
fill ~102 ~63 ~476 ~102 ~63 ~488 minecraft:redstone_wire replace
fill ~120 ~63 ~476 ~120 ~63 ~488 minecraft:redstone_wire replace
fill ~138 ~63 ~476 ~138 ~63 ~488 minecraft:redstone_wire replace
fill ~153 ~63 ~476 ~153 ~63 ~480 minecraft:redstone_wire replace
fill ~162 ~63 ~476 ~162 ~63 ~488 minecraft:redstone_wire replace
fill ~177 ~63 ~480 ~177 ~63 ~484 minecraft:redstone_wire replace
fill ~204 ~63 ~484 ~204 ~63 ~488 minecraft:redstone_wire replace
setblock ~81 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~492 ~81 ~63 ~504 minecraft:redstone_wire replace
fill ~102 ~63 ~492 ~102 ~63 ~504 minecraft:redstone_wire replace
