setblock ~274 ~53 ~80 minecraft:light_gray_concrete replace
setblock ~94 ~53 ~252 minecraft:light_gray_concrete replace
setblock ~118 ~53 ~272 minecraft:light_gray_concrete replace
setblock ~139 ~53 ~288 minecraft:light_gray_concrete replace
setblock ~154 ~53 ~300 minecraft:light_gray_concrete replace
setblock ~169 ~53 ~324 minecraft:light_gray_concrete replace
setblock ~190 ~53 ~332 minecraft:light_gray_concrete replace
setblock ~193 ~53 ~332 minecraft:light_gray_concrete replace
setblock ~190 ~53 ~344 minecraft:light_gray_concrete replace
setblock ~193 ~53 ~344 minecraft:light_gray_concrete replace
setblock ~211 ~53 ~348 minecraft:light_gray_concrete replace
setblock ~214 ~53 ~348 minecraft:light_gray_concrete replace
setblock ~211 ~53 ~360 minecraft:light_gray_concrete replace
setblock ~214 ~53 ~360 minecraft:light_gray_concrete replace
setblock ~262 ~53 ~368 minecraft:light_gray_concrete replace
setblock ~265 ~53 ~368 minecraft:light_gray_concrete replace
setblock ~262 ~53 ~372 minecraft:light_gray_concrete replace
setblock ~265 ~53 ~372 minecraft:light_gray_concrete replace
setblock ~251 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~253 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~264 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~266 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~281 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~283 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~298 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~300 ~53 ~378 minecraft:light_gray_concrete replace
setblock ~235 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~238 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~271 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~307 ~53 ~380 minecraft:light_gray_concrete replace
setblock ~235 ~53 ~388 minecraft:light_gray_concrete replace
setblock ~238 ~53 ~388 minecraft:light_gray_concrete replace
setblock ~279 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~281 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~295 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~297 ~53 ~390 minecraft:light_gray_concrete replace
setblock ~271 ~53 ~392 minecraft:light_gray_concrete replace
setblock ~307 ~53 ~392 minecraft:light_gray_concrete replace
setblock ~310 ~53 ~396 minecraft:light_gray_concrete replace
setblock ~277 ~53 ~400 minecraft:light_gray_concrete replace
setblock ~298 ~53 ~404 minecraft:light_gray_concrete replace
setblock ~271 ~53 ~408 minecraft:light_gray_concrete replace
setblock ~91 ~53 ~416 minecraft:light_gray_concrete replace
setblock ~115 ~53 ~420 minecraft:light_gray_concrete replace
setblock ~136 ~53 ~424 minecraft:light_gray_concrete replace
setblock ~160 ~53 ~428 minecraft:light_gray_concrete replace
setblock ~181 ~53 ~432 minecraft:light_gray_concrete replace
setblock ~205 ~53 ~436 minecraft:light_gray_concrete replace
setblock ~232 ~53 ~440 minecraft:light_gray_concrete replace
setblock ~256 ~53 ~444 minecraft:light_gray_concrete replace
setblock ~268 ~53 ~448 minecraft:light_gray_concrete replace
setblock ~88 ~53 ~452 minecraft:light_gray_concrete replace
setblock ~112 ~53 ~456 minecraft:light_gray_concrete replace
setblock ~133 ~53 ~460 minecraft:light_gray_concrete replace
setblock ~157 ~53 ~464 minecraft:light_gray_concrete replace
setblock ~178 ~53 ~468 minecraft:light_gray_concrete replace
setblock ~202 ~53 ~472 minecraft:light_gray_concrete replace
setblock ~226 ~53 ~476 minecraft:light_gray_concrete replace
setblock ~253 ~53 ~480 minecraft:light_gray_concrete replace
setblock ~289 ~53 ~484 minecraft:light_gray_concrete replace
setblock ~316 ~53 ~488 minecraft:light_gray_concrete replace
setblock ~85 ~53 ~492 minecraft:light_gray_concrete replace
setblock ~109 ~53 ~496 minecraft:light_gray_concrete replace
setblock ~130 ~53 ~500 minecraft:light_gray_concrete replace
setblock ~151 ~53 ~504 minecraft:light_gray_concrete replace
setblock ~175 ~53 ~508 minecraft:light_gray_concrete replace
setblock ~199 ~53 ~512 minecraft:light_gray_concrete replace
setblock ~223 ~53 ~516 minecraft:light_gray_concrete replace
setblock ~250 ~53 ~520 minecraft:light_gray_concrete replace
setblock ~286 ~53 ~524 minecraft:light_gray_concrete replace
setblock ~313 ~53 ~528 minecraft:light_gray_concrete replace
setblock ~82 ~53 ~532 minecraft:light_gray_concrete replace
setblock ~106 ~53 ~536 minecraft:light_gray_concrete replace
setblock ~127 ~53 ~540 minecraft:light_gray_concrete replace
setblock ~148 ~53 ~544 minecraft:light_gray_concrete replace
setblock ~172 ~53 ~548 minecraft:light_gray_concrete replace
setblock ~196 ~53 ~552 minecraft:light_gray_concrete replace
setblock ~220 ~53 ~556 minecraft:light_gray_concrete replace
setblock ~244 ~53 ~560 minecraft:light_gray_concrete replace
setblock ~283 ~53 ~564 minecraft:light_gray_concrete replace
setblock ~304 ~53 ~568 minecraft:light_gray_concrete replace
setblock ~79 ~53 ~572 minecraft:light_gray_concrete replace
setblock ~103 ~53 ~576 minecraft:light_gray_concrete replace
setblock ~124 ~53 ~580 minecraft:light_gray_concrete replace
setblock ~145 ~53 ~584 minecraft:light_gray_concrete replace
setblock ~166 ~53 ~588 minecraft:light_gray_concrete replace
setblock ~187 ~53 ~592 minecraft:light_gray_concrete replace
setblock ~217 ~53 ~596 minecraft:light_gray_concrete replace
setblock ~241 ~53 ~600 minecraft:light_gray_concrete replace
setblock ~280 ~53 ~604 minecraft:light_gray_concrete replace
setblock ~301 ~53 ~608 minecraft:light_gray_concrete replace
setblock ~100 ~53 ~612 minecraft:light_gray_concrete replace
setblock ~121 ~53 ~616 minecraft:light_gray_concrete replace
setblock ~142 ~53 ~620 minecraft:light_gray_concrete replace
setblock ~163 ~53 ~624 minecraft:light_gray_concrete replace
setblock ~184 ~53 ~628 minecraft:light_gray_concrete replace
setblock ~208 ~53 ~632 minecraft:light_gray_concrete replace
setblock ~247 ~53 ~636 minecraft:light_gray_concrete replace
setblock ~259 ~53 ~640 minecraft:light_gray_concrete replace
setblock ~292 ~53 ~644 minecraft:light_gray_concrete replace
setblock ~107 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~109 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~124 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~126 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~141 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~143 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~157 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~159 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~174 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~176 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~191 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~193 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~208 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~210 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~225 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~227 ~53 ~646 minecraft:light_gray_concrete replace
setblock ~94 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~118 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~139 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~154 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~169 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~229 ~53 ~648 minecraft:light_gray_concrete replace
setblock ~322 ~53 ~652 minecraft:light_gray_concrete replace
setblock ~97 ~53 ~656 minecraft:light_gray_concrete replace
setblock ~295 ~53 ~660 minecraft:light_gray_concrete replace
setblock ~319 ~53 ~664 minecraft:light_gray_concrete replace
fill ~273 ~54 ~76 ~273 ~54 ~80 minecraft:light_gray_concrete replace
fill ~93 ~54 ~248 ~93 ~54 ~648 minecraft:light_gray_concrete replace
fill ~117 ~54 ~268 ~117 ~54 ~648 minecraft:light_gray_concrete replace
fill ~138 ~54 ~284 ~138 ~54 ~648 minecraft:light_gray_concrete replace
fill ~153 ~54 ~296 ~153 ~54 ~648 minecraft:light_gray_concrete replace
fill ~168 ~54 ~320 ~168 ~54 ~648 minecraft:light_gray_concrete replace
fill ~192 ~54 ~324 ~192 ~54 ~344 minecraft:light_gray_concrete replace
fill ~189 ~54 ~328 ~189 ~54 ~344 minecraft:light_gray_concrete replace
fill ~213 ~54 ~340 ~213 ~54 ~360 minecraft:light_gray_concrete replace
fill ~210 ~54 ~344 ~210 ~54 ~360 minecraft:light_gray_concrete replace
fill ~264 ~54 ~356 ~264 ~54 ~372 minecraft:light_gray_concrete replace
fill ~261 ~54 ~360 ~261 ~54 ~372 minecraft:light_gray_concrete replace
fill ~306 ~54 ~364 ~306 ~54 ~392 minecraft:light_gray_concrete replace
fill ~270 ~54 ~368 ~270 ~54 ~408 minecraft:light_gray_concrete replace
fill ~237 ~54 ~372 ~237 ~54 ~388 minecraft:light_gray_concrete replace
fill ~234 ~54 ~376 ~234 ~54 ~388 minecraft:light_gray_concrete replace
fill ~309 ~54 ~392 ~309 ~54 ~396 minecraft:light_gray_concrete replace
fill ~276 ~54 ~396 ~276 ~54 ~400 minecraft:light_gray_concrete replace
fill ~297 ~54 ~400 ~297 ~54 ~404 minecraft:light_gray_concrete replace
fill ~90 ~54 ~412 ~90 ~54 ~416 minecraft:light_gray_concrete replace
fill ~114 ~54 ~416 ~114 ~54 ~420 minecraft:light_gray_concrete replace
fill ~135 ~54 ~420 ~135 ~54 ~424 minecraft:light_gray_concrete replace
fill ~159 ~54 ~424 ~159 ~54 ~428 minecraft:light_gray_concrete replace
fill ~180 ~54 ~428 ~180 ~54 ~432 minecraft:light_gray_concrete replace
fill ~204 ~54 ~432 ~204 ~54 ~436 minecraft:light_gray_concrete replace
fill ~231 ~54 ~436 ~231 ~54 ~440 minecraft:light_gray_concrete replace
fill ~255 ~54 ~440 ~255 ~54 ~444 minecraft:light_gray_concrete replace
fill ~267 ~54 ~444 ~267 ~54 ~448 minecraft:light_gray_concrete replace
fill ~87 ~54 ~448 ~87 ~54 ~452 minecraft:light_gray_concrete replace
fill ~111 ~54 ~452 ~111 ~54 ~456 minecraft:light_gray_concrete replace
fill ~132 ~54 ~456 ~132 ~54 ~460 minecraft:light_gray_concrete replace
fill ~156 ~54 ~460 ~156 ~54 ~464 minecraft:light_gray_concrete replace
fill ~177 ~54 ~464 ~177 ~54 ~468 minecraft:light_gray_concrete replace
fill ~201 ~54 ~468 ~201 ~54 ~472 minecraft:light_gray_concrete replace
fill ~225 ~54 ~472 ~225 ~54 ~476 minecraft:light_gray_concrete replace
fill ~252 ~54 ~476 ~252 ~54 ~480 minecraft:light_gray_concrete replace
fill ~288 ~54 ~480 ~288 ~54 ~484 minecraft:light_gray_concrete replace
fill ~315 ~54 ~484 ~315 ~54 ~488 minecraft:light_gray_concrete replace
fill ~84 ~54 ~488 ~84 ~54 ~492 minecraft:light_gray_concrete replace
fill ~108 ~54 ~492 ~108 ~54 ~496 minecraft:light_gray_concrete replace
fill ~129 ~54 ~496 ~129 ~54 ~500 minecraft:light_gray_concrete replace
fill ~150 ~54 ~500 ~150 ~54 ~504 minecraft:light_gray_concrete replace
fill ~174 ~54 ~504 ~174 ~54 ~508 minecraft:light_gray_concrete replace
fill ~198 ~54 ~508 ~198 ~54 ~512 minecraft:light_gray_concrete replace
fill ~222 ~54 ~512 ~222 ~54 ~516 minecraft:light_gray_concrete replace
fill ~249 ~54 ~516 ~249 ~54 ~520 minecraft:light_gray_concrete replace
fill ~285 ~54 ~520 ~285 ~54 ~524 minecraft:light_gray_concrete replace
fill ~312 ~54 ~524 ~312 ~54 ~528 minecraft:light_gray_concrete replace
fill ~81 ~54 ~528 ~81 ~54 ~532 minecraft:light_gray_concrete replace
fill ~105 ~54 ~532 ~105 ~54 ~536 minecraft:light_gray_concrete replace
fill ~126 ~54 ~536 ~126 ~54 ~540 minecraft:light_gray_concrete replace
fill ~147 ~54 ~540 ~147 ~54 ~544 minecraft:light_gray_concrete replace
fill ~171 ~54 ~544 ~171 ~54 ~548 minecraft:light_gray_concrete replace
fill ~195 ~54 ~548 ~195 ~54 ~552 minecraft:light_gray_concrete replace
fill ~219 ~54 ~552 ~219 ~54 ~556 minecraft:light_gray_concrete replace
fill ~243 ~54 ~556 ~243 ~54 ~560 minecraft:light_gray_concrete replace
fill ~282 ~54 ~560 ~282 ~54 ~564 minecraft:light_gray_concrete replace
fill ~303 ~54 ~564 ~303 ~54 ~568 minecraft:light_gray_concrete replace
fill ~78 ~54 ~568 ~78 ~54 ~572 minecraft:light_gray_concrete replace
fill ~102 ~54 ~572 ~102 ~54 ~576 minecraft:light_gray_concrete replace
fill ~123 ~54 ~576 ~123 ~54 ~580 minecraft:light_gray_concrete replace
fill ~144 ~54 ~580 ~144 ~54 ~584 minecraft:light_gray_concrete replace
fill ~165 ~54 ~584 ~165 ~54 ~588 minecraft:light_gray_concrete replace
fill ~186 ~54 ~588 ~186 ~54 ~592 minecraft:light_gray_concrete replace
fill ~216 ~54 ~592 ~216 ~54 ~596 minecraft:light_gray_concrete replace
fill ~240 ~54 ~596 ~240 ~54 ~600 minecraft:light_gray_concrete replace
fill ~279 ~54 ~600 ~279 ~54 ~604 minecraft:light_gray_concrete replace
fill ~300 ~54 ~604 ~300 ~54 ~608 minecraft:light_gray_concrete replace
fill ~99 ~54 ~608 ~99 ~54 ~612 minecraft:light_gray_concrete replace
fill ~120 ~54 ~612 ~120 ~54 ~616 minecraft:light_gray_concrete replace
fill ~141 ~54 ~616 ~141 ~54 ~620 minecraft:light_gray_concrete replace
fill ~162 ~54 ~620 ~162 ~54 ~624 minecraft:light_gray_concrete replace
fill ~183 ~54 ~624 ~183 ~54 ~628 minecraft:light_gray_concrete replace
fill ~207 ~54 ~628 ~207 ~54 ~632 minecraft:light_gray_concrete replace
fill ~246 ~54 ~632 ~246 ~54 ~636 minecraft:light_gray_concrete replace
fill ~258 ~54 ~636 ~258 ~54 ~640 minecraft:light_gray_concrete replace
fill ~291 ~54 ~640 ~291 ~54 ~644 minecraft:light_gray_concrete replace
fill ~228 ~54 ~644 ~228 ~54 ~648 minecraft:light_gray_concrete replace
fill ~321 ~54 ~648 ~321 ~54 ~652 minecraft:light_gray_concrete replace
fill ~96 ~54 ~652 ~96 ~54 ~656 minecraft:light_gray_concrete replace
fill ~294 ~54 ~656 ~294 ~54 ~660 minecraft:light_gray_concrete replace
fill ~318 ~54 ~660 ~318 ~54 ~664 minecraft:light_gray_concrete replace
setblock ~273 ~55 ~75 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~247 minecraft:light_gray_concrete replace
setblock ~94 ~55 ~252 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~265 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~267 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~267 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~269 minecraft:light_gray_concrete replace
setblock ~118 ~55 ~272 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~281 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~281 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~283 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~283 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~283 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~285 minecraft:light_gray_concrete replace
setblock ~139 ~55 ~288 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~295 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~297 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~297 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~297 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~299 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~299 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~299 minecraft:light_gray_concrete replace
setblock ~154 ~55 ~300 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~313 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~315 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~319 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~321 minecraft:light_gray_concrete replace
setblock ~192 ~55 ~323 minecraft:light_gray_concrete replace
setblock ~169 ~55 ~324 minecraft:light_gray_concrete replace
setblock ~189 ~55 ~327 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~329 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~331 minecraft:light_gray_concrete replace
setblock ~193 ~55 ~332 minecraft:light_gray_concrete replace
setblock ~213 ~55 ~339 minecraft:light_gray_concrete replace
setblock ~210 ~55 ~343 minecraft:light_gray_concrete replace
setblock ~190 ~55 ~344 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~345 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~347 minecraft:light_gray_concrete replace
setblock ~214 ~55 ~348 minecraft:light_gray_concrete replace
setblock ~264 ~55 ~355 minecraft:light_gray_concrete replace
setblock ~264 ~55 ~357 minecraft:light_gray_concrete replace
setblock ~261 ~55 ~359 minecraft:light_gray_concrete replace
setblock ~264 ~55 ~359 minecraft:light_gray_concrete replace
setblock ~211 ~55 ~360 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~261 ~55 ~361 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~306 ~55 ~363 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~367 minecraft:light_gray_concrete replace
setblock ~265 ~55 ~368 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~369 minecraft:light_gray_concrete replace
setblock ~237 ~55 ~371 minecraft:light_gray_concrete replace
setblock ~262 ~55 ~372 minecraft:light_gray_concrete replace
setblock ~237 ~55 ~373 minecraft:light_gray_concrete replace
setblock ~234 ~55 ~375 minecraft:light_gray_concrete replace
setblock ~237 ~55 ~375 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~234 ~55 ~377 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~379 minecraft:light_gray_concrete replace
setblock ~238 ~55 ~380 minecraft:light_gray_concrete replace
setblock ~271 ~55 ~380 minecraft:light_gray_concrete replace
setblock ~307 ~55 ~380 minecraft:light_gray_concrete replace
setblock ~235 ~55 ~388 minecraft:light_gray_concrete replace
setblock ~309 ~55 ~391 minecraft:light_gray_concrete replace
setblock ~271 ~55 ~392 minecraft:light_gray_concrete replace
setblock ~307 ~55 ~392 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~393 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~270 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~276 ~55 ~395 minecraft:light_gray_concrete replace
setblock ~297 ~55 ~399 minecraft:light_gray_concrete replace
setblock ~271 ~55 ~408 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~409 minecraft:light_gray_concrete replace
setblock ~90 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~411 minecraft:light_gray_concrete replace
setblock ~114 ~55 ~415 minecraft:light_gray_concrete replace
setblock ~135 ~55 ~419 minecraft:light_gray_concrete replace
setblock ~159 ~55 ~423 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~425 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~180 ~55 ~427 minecraft:light_gray_concrete replace
setblock ~204 ~55 ~431 minecraft:light_gray_concrete replace
setblock ~231 ~55 ~435 minecraft:light_gray_concrete replace
setblock ~255 ~55 ~439 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~441 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~267 ~55 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~55 ~447 minecraft:light_gray_concrete replace
setblock ~111 ~55 ~451 minecraft:light_gray_concrete replace
setblock ~132 ~55 ~455 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~457 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~156 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~459 minecraft:light_gray_concrete replace
setblock ~177 ~55 ~463 minecraft:light_gray_concrete replace
setblock ~201 ~55 ~467 minecraft:light_gray_concrete replace
setblock ~225 ~55 ~471 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~473 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~252 ~55 ~475 minecraft:light_gray_concrete replace
setblock ~288 ~55 ~479 minecraft:light_gray_concrete replace
setblock ~315 ~55 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~55 ~487 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~489 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~108 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~491 minecraft:light_gray_concrete replace
setblock ~129 ~55 ~495 minecraft:light_gray_concrete replace
setblock ~150 ~55 ~499 minecraft:light_gray_concrete replace
setblock ~174 ~55 ~503 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~505 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~198 ~55 ~507 minecraft:light_gray_concrete replace
setblock ~222 ~55 ~511 minecraft:light_gray_concrete replace
setblock ~249 ~55 ~515 minecraft:light_gray_concrete replace
setblock ~285 ~55 ~519 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~521 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~312 ~55 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~55 ~527 minecraft:light_gray_concrete replace
setblock ~105 ~55 ~531 minecraft:light_gray_concrete replace
setblock ~126 ~55 ~535 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~537 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~147 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~539 minecraft:light_gray_concrete replace
setblock ~171 ~55 ~543 minecraft:light_gray_concrete replace
setblock ~195 ~55 ~547 minecraft:light_gray_concrete replace
setblock ~219 ~55 ~551 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~553 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~243 ~55 ~555 minecraft:light_gray_concrete replace
setblock ~282 ~55 ~559 minecraft:light_gray_concrete replace
setblock ~303 ~55 ~563 minecraft:light_gray_concrete replace
setblock ~78 ~55 ~567 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~569 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~102 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~571 minecraft:light_gray_concrete replace
setblock ~123 ~55 ~575 minecraft:light_gray_concrete replace
setblock ~144 ~55 ~579 minecraft:light_gray_concrete replace
setblock ~165 ~55 ~583 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~585 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~186 ~55 ~587 minecraft:light_gray_concrete replace
setblock ~216 ~55 ~591 minecraft:light_gray_concrete replace
setblock ~240 ~55 ~595 minecraft:light_gray_concrete replace
setblock ~279 ~55 ~599 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~601 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~300 ~55 ~603 minecraft:light_gray_concrete replace
setblock ~99 ~55 ~607 minecraft:light_gray_concrete replace
setblock ~120 ~55 ~611 minecraft:light_gray_concrete replace
setblock ~141 ~55 ~615 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~617 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~162 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~619 minecraft:light_gray_concrete replace
setblock ~183 ~55 ~623 minecraft:light_gray_concrete replace
setblock ~207 ~55 ~627 minecraft:light_gray_concrete replace
setblock ~246 ~55 ~631 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~633 minecraft:light_gray_concrete replace
setblock ~93 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~117 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~138 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~153 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~168 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~258 ~55 ~635 minecraft:light_gray_concrete replace
setblock ~291 ~55 ~639 minecraft:light_gray_concrete replace
setblock ~228 ~55 ~643 minecraft:light_gray_concrete replace
setblock ~321 ~55 ~647 minecraft:light_gray_concrete replace
setblock ~96 ~55 ~651 minecraft:light_gray_concrete replace
setblock ~294 ~55 ~655 minecraft:light_gray_concrete replace
setblock ~318 ~55 ~659 minecraft:light_gray_concrete replace
fill ~169 ~56 ~72 ~169 ~56 ~73 minecraft:light_gray_concrete replace
fill ~168 ~56 ~74 ~273 ~56 ~74 minecraft:light_gray_concrete replace
fill ~79 ~56 ~244 ~79 ~56 ~245 minecraft:light_gray_concrete replace
fill ~78 ~56 ~246 ~93 ~56 ~246 minecraft:light_gray_concrete replace
fill ~82 ~56 ~264 ~82 ~56 ~265 minecraft:light_gray_concrete replace
fill ~81 ~56 ~266 ~117 ~56 ~266 minecraft:light_gray_concrete replace
fill ~85 ~56 ~280 ~85 ~56 ~281 minecraft:light_gray_concrete replace
fill ~84 ~56 ~282 ~138 ~56 ~282 minecraft:light_gray_concrete replace
fill ~88 ~56 ~292 ~88 ~56 ~293 minecraft:light_gray_concrete replace
fill ~87 ~56 ~294 ~153 ~56 ~294 minecraft:light_gray_concrete replace
fill ~91 ~56 ~316 ~91 ~56 ~317 minecraft:light_gray_concrete replace
fill ~90 ~56 ~318 ~168 ~56 ~318 minecraft:light_gray_concrete replace
fill ~100 ~56 ~320 ~100 ~56 ~321 minecraft:light_gray_concrete replace
fill ~99 ~56 ~322 ~192 ~56 ~322 minecraft:light_gray_concrete replace
fill ~100 ~56 ~324 ~100 ~56 ~325 minecraft:light_gray_concrete replace
fill ~99 ~56 ~326 ~189 ~56 ~326 minecraft:light_gray_concrete replace
fill ~118 ~56 ~336 ~118 ~56 ~337 minecraft:light_gray_concrete replace
fill ~117 ~56 ~338 ~213 ~56 ~338 minecraft:light_gray_concrete replace
fill ~118 ~56 ~340 ~118 ~56 ~341 minecraft:light_gray_concrete replace
fill ~117 ~56 ~342 ~210 ~56 ~342 minecraft:light_gray_concrete replace
fill ~163 ~56 ~352 ~163 ~56 ~353 minecraft:light_gray_concrete replace
fill ~162 ~56 ~354 ~264 ~56 ~354 minecraft:light_gray_concrete replace
fill ~163 ~56 ~356 ~163 ~56 ~357 minecraft:light_gray_concrete replace
fill ~162 ~56 ~358 ~261 ~56 ~358 minecraft:light_gray_concrete replace
fill ~199 ~56 ~360 ~199 ~56 ~361 minecraft:light_gray_concrete replace
fill ~198 ~56 ~362 ~306 ~56 ~362 minecraft:light_gray_concrete replace
fill ~169 ~56 ~364 ~169 ~56 ~365 minecraft:light_gray_concrete replace
fill ~168 ~56 ~366 ~270 ~56 ~366 minecraft:light_gray_concrete replace
fill ~139 ~56 ~368 ~139 ~56 ~369 minecraft:light_gray_concrete replace
fill ~138 ~56 ~370 ~237 ~56 ~370 minecraft:light_gray_concrete replace
fill ~139 ~56 ~372 ~139 ~56 ~373 minecraft:light_gray_concrete replace
fill ~138 ~56 ~374 ~234 ~56 ~374 minecraft:light_gray_concrete replace
fill ~199 ~56 ~388 ~199 ~56 ~389 minecraft:light_gray_concrete replace
fill ~198 ~56 ~390 ~309 ~56 ~390 minecraft:light_gray_concrete replace
fill ~169 ~56 ~392 ~169 ~56 ~393 minecraft:light_gray_concrete replace
fill ~168 ~56 ~394 ~276 ~56 ~394 minecraft:light_gray_concrete replace
fill ~190 ~56 ~396 ~190 ~56 ~397 minecraft:light_gray_concrete replace
fill ~189 ~56 ~398 ~297 ~56 ~398 minecraft:light_gray_concrete replace
fill ~79 ~56 ~408 ~79 ~56 ~409 minecraft:light_gray_concrete replace
fill ~78 ~56 ~410 ~90 ~56 ~410 minecraft:light_gray_concrete replace
fill ~82 ~56 ~412 ~82 ~56 ~413 minecraft:light_gray_concrete replace
fill ~81 ~56 ~414 ~114 ~56 ~414 minecraft:light_gray_concrete replace
fill ~85 ~56 ~416 ~85 ~56 ~417 minecraft:light_gray_concrete replace
fill ~84 ~56 ~418 ~135 ~56 ~418 minecraft:light_gray_concrete replace
fill ~88 ~56 ~420 ~88 ~56 ~421 minecraft:light_gray_concrete replace
fill ~87 ~56 ~422 ~159 ~56 ~422 minecraft:light_gray_concrete replace
fill ~91 ~56 ~424 ~91 ~56 ~425 minecraft:light_gray_concrete replace
fill ~90 ~56 ~426 ~180 ~56 ~426 minecraft:light_gray_concrete replace
fill ~112 ~56 ~428 ~112 ~56 ~429 minecraft:light_gray_concrete replace
fill ~111 ~56 ~430 ~204 ~56 ~430 minecraft:light_gray_concrete replace
fill ~136 ~56 ~432 ~136 ~56 ~433 minecraft:light_gray_concrete replace
fill ~135 ~56 ~434 ~231 ~56 ~434 minecraft:light_gray_concrete replace
fill ~157 ~56 ~436 ~157 ~56 ~437 minecraft:light_gray_concrete replace
fill ~156 ~56 ~438 ~255 ~56 ~438 minecraft:light_gray_concrete replace
fill ~166 ~56 ~440 ~166 ~56 ~441 minecraft:light_gray_concrete replace
fill ~165 ~56 ~442 ~267 ~56 ~442 minecraft:light_gray_concrete replace
fill ~79 ~56 ~444 ~79 ~56 ~445 minecraft:light_gray_concrete replace
fill ~78 ~56 ~446 ~87 ~56 ~446 minecraft:light_gray_concrete replace
fill ~82 ~56 ~448 ~82 ~56 ~449 minecraft:light_gray_concrete replace
fill ~81 ~56 ~450 ~111 ~56 ~450 minecraft:light_gray_concrete replace
