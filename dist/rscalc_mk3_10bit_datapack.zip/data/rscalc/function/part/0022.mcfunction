setblock ~204 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~206 ~37 ~278 ~219 ~37 ~278 minecraft:redstone_wire replace
setblock ~221 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~223 ~37 ~278 ~236 ~37 ~278 minecraft:redstone_wire replace
setblock ~238 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~240 ~37 ~278 ~253 ~37 ~278 minecraft:redstone_wire replace
setblock ~254 ~37 ~278 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~97 ~37 ~279 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~127 ~37 ~279 minecraft:redstone_wire replace
setblock ~154 ~37 ~279 minecraft:redstone_wire replace
setblock ~184 ~37 ~279 minecraft:redstone_wire replace
setblock ~253 ~37 ~279 minecraft:redstone_wire replace
fill ~117 ~37 ~282 ~122 ~37 ~282 minecraft:redstone_wire replace
setblock ~121 ~37 ~283 minecraft:redstone_wire replace
fill ~141 ~37 ~286 ~152 ~37 ~286 minecraft:redstone_wire replace
setblock ~151 ~37 ~287 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~120 ~37 ~290 ~124 ~37 ~290 minecraft:redstone_wire replace
setblock ~126 ~37 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~37 ~290 ~141 ~37 ~290 minecraft:redstone_wire replace
setblock ~143 ~37 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~37 ~290 ~158 ~37 ~290 minecraft:redstone_wire replace
setblock ~160 ~37 ~290 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~37 ~290 ~180 ~37 ~290 minecraft:redstone_wire replace
setblock ~182 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~184 ~37 ~290 ~197 ~37 ~290 minecraft:redstone_wire replace
setblock ~199 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~201 ~37 ~290 ~214 ~37 ~290 minecraft:redstone_wire replace
setblock ~216 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~218 ~37 ~290 ~231 ~37 ~290 minecraft:redstone_wire replace
setblock ~233 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~235 ~37 ~290 ~248 ~37 ~290 minecraft:redstone_wire replace
setblock ~250 ~37 ~290 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~252 ~37 ~290 ~254 ~37 ~290 minecraft:redstone_wire replace
setblock ~121 ~37 ~291 minecraft:redstone_wire replace
setblock ~148 ~37 ~291 minecraft:redstone_wire replace
setblock ~154 ~37 ~291 minecraft:redstone_wire replace
setblock ~175 ~37 ~291 minecraft:redstone_wire replace
setblock ~184 ~37 ~291 minecraft:redstone_wire replace
setblock ~244 ~37 ~291 minecraft:redstone_wire replace
setblock ~253 ~37 ~291 minecraft:redstone_wire replace
fill ~177 ~37 ~294 ~180 ~37 ~294 minecraft:redstone_wire replace
setblock ~182 ~37 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~184 ~37 ~294 ~197 ~37 ~294 minecraft:redstone_wire replace
setblock ~199 ~37 ~294 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~37 ~294 ~225 ~37 ~294 minecraft:redstone_wire replace
setblock ~227 ~37 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~229 ~37 ~294 ~242 ~37 ~294 minecraft:redstone_wire replace
setblock ~244 ~37 ~294 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~246 ~37 ~294 ~248 ~37 ~294 minecraft:redstone_wire replace
setblock ~178 ~37 ~295 minecraft:redstone_wire replace
setblock ~247 ~37 ~295 minecraft:redstone_wire replace
fill ~144 ~37 ~298 ~153 ~37 ~298 minecraft:redstone_wire replace
setblock ~155 ~37 ~298 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~157 ~37 ~298 ~158 ~37 ~298 minecraft:redstone_wire replace
setblock ~157 ~37 ~299 minecraft:redstone_wire replace
fill ~168 ~37 ~302 ~173 ~37 ~302 minecraft:redstone_wire replace
setblock ~175 ~37 ~302 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~177 ~37 ~302 ~182 ~37 ~302 minecraft:redstone_wire replace
setblock ~181 ~37 ~303 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~156 ~37 ~306 ~168 ~37 ~306 minecraft:redstone_wire replace
setblock ~170 ~37 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~37 ~306 ~185 ~37 ~306 minecraft:redstone_wire replace
setblock ~187 ~37 ~306 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~37 ~306 ~213 ~37 ~306 minecraft:redstone_wire replace
setblock ~215 ~37 ~306 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~37 ~306 ~230 ~37 ~306 minecraft:redstone_wire replace
setblock ~232 ~37 ~306 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~234 ~37 ~306 ~247 ~37 ~306 minecraft:redstone_wire replace
setblock ~248 ~37 ~306 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~249 ~37 ~306 ~254 ~37 ~306 minecraft:redstone_wire replace
setblock ~157 ~37 ~307 minecraft:redstone_wire replace
setblock ~175 ~37 ~307 minecraft:redstone_wire replace
setblock ~178 ~37 ~307 minecraft:redstone_wire replace
setblock ~184 ~37 ~307 minecraft:redstone_wire replace
setblock ~244 ~37 ~307 minecraft:redstone_wire replace
setblock ~247 ~37 ~307 minecraft:redstone_wire replace
setblock ~253 ~37 ~307 minecraft:redstone_wire replace
fill ~249 ~37 ~310 ~255 ~37 ~310 minecraft:redstone_wire replace
setblock ~250 ~37 ~311 minecraft:redstone_wire replace
fill ~174 ~37 ~314 ~185 ~37 ~314 minecraft:redstone_wire replace
setblock ~186 ~37 ~314 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~37 ~314 ~188 ~37 ~314 minecraft:redstone_wire replace
setblock ~187 ~37 ~315 minecraft:redstone_wire replace
fill ~186 ~37 ~318 ~191 ~37 ~318 minecraft:redstone_wire replace
setblock ~193 ~37 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~37 ~318 ~208 ~37 ~318 minecraft:redstone_wire replace
setblock ~210 ~37 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~212 ~37 ~318 ~225 ~37 ~318 minecraft:redstone_wire replace
setblock ~227 ~37 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~229 ~37 ~318 ~251 ~37 ~318 minecraft:redstone_wire replace
setblock ~252 ~37 ~318 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~253 ~37 ~318 ~254 ~37 ~318 minecraft:redstone_wire replace
setblock ~187 ~37 ~319 minecraft:redstone_wire replace
setblock ~244 ~37 ~319 minecraft:redstone_wire replace
setblock ~247 ~37 ~319 minecraft:redstone_wire replace
setblock ~250 ~37 ~319 minecraft:redstone_wire replace
setblock ~253 ~37 ~319 minecraft:redstone_wire replace
fill ~255 ~37 ~322 ~258 ~37 ~322 minecraft:redstone_wire replace
setblock ~256 ~37 ~323 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~195 ~37 ~326 ~203 ~37 ~326 minecraft:redstone_wire replace
setblock ~202 ~37 ~327 minecraft:redstone_wire replace
fill ~222 ~37 ~330 ~225 ~37 ~330 minecraft:redstone_wire replace
setblock ~223 ~37 ~331 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~201 ~37 ~334 ~203 ~37 ~334 minecraft:redstone_wire replace
setblock ~205 ~37 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~37 ~334 ~220 ~37 ~334 minecraft:redstone_wire replace
setblock ~222 ~37 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~224 ~37 ~334 ~237 ~37 ~334 minecraft:redstone_wire replace
setblock ~239 ~37 ~334 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~241 ~37 ~334 ~251 ~37 ~334 minecraft:redstone_wire replace
setblock ~253 ~37 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~255 ~37 ~334 ~268 ~37 ~334 minecraft:redstone_wire replace
setblock ~270 ~37 ~334 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~272 ~37 ~334 ~281 ~37 ~334 minecraft:redstone_wire replace
setblock ~202 ~37 ~335 minecraft:redstone_wire replace
setblock ~280 ~37 ~335 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~258 ~37 ~338 ~270 ~37 ~338 minecraft:redstone_wire replace
setblock ~272 ~37 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~37 ~338 ~287 ~37 ~338 minecraft:redstone_wire replace
setblock ~289 ~37 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~37 ~338 ~314 ~37 ~338 minecraft:redstone_wire replace
setblock ~315 ~37 ~338 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~316 ~37 ~338 ~328 ~37 ~338 minecraft:redstone_wire replace
setblock ~329 ~37 ~338 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~330 ~37 ~338 ~332 ~37 ~338 minecraft:redstone_wire replace
setblock ~259 ~37 ~339 minecraft:redstone_wire replace
setblock ~316 ~37 ~339 minecraft:redstone_wire replace
setblock ~331 ~37 ~339 minecraft:redstone_wire replace
fill ~225 ~37 ~342 ~228 ~37 ~342 minecraft:redstone_wire replace
setblock ~226 ~37 ~343 minecraft:redstone_wire replace
fill ~261 ~37 ~346 ~263 ~37 ~346 minecraft:redstone_wire replace
setblock ~262 ~37 ~347 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~37 ~350 ~233 ~37 ~350 minecraft:redstone_wire replace
setblock ~235 ~37 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~37 ~350 ~250 ~37 ~350 minecraft:redstone_wire replace
setblock ~252 ~37 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~254 ~37 ~350 ~267 ~37 ~350 minecraft:redstone_wire replace
setblock ~269 ~37 ~350 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~37 ~350 ~293 ~37 ~350 minecraft:redstone_wire replace
setblock ~295 ~37 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~297 ~37 ~350 ~310 ~37 ~350 minecraft:redstone_wire replace
setblock ~312 ~37 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~314 ~37 ~350 ~327 ~37 ~350 minecraft:redstone_wire replace
setblock ~329 ~37 ~350 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~331 ~37 ~350 ~332 ~37 ~350 minecraft:redstone_wire replace
setblock ~226 ~37 ~351 minecraft:redstone_wire replace
setblock ~259 ~37 ~351 minecraft:redstone_wire replace
setblock ~298 ~37 ~351 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~316 ~37 ~351 minecraft:redstone_wire replace
setblock ~331 ~37 ~351 minecraft:redstone_wire replace
fill ~318 ~37 ~354 ~322 ~37 ~354 minecraft:redstone_wire replace
setblock ~324 ~37 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~326 ~37 ~354 ~335 ~37 ~354 minecraft:redstone_wire replace
setblock ~319 ~37 ~355 minecraft:redstone_wire replace
setblock ~334 ~37 ~355 minecraft:redstone_wire replace
fill ~264 ~37 ~358 ~266 ~37 ~358 minecraft:redstone_wire replace
setblock ~265 ~37 ~359 minecraft:redstone_wire replace
fill ~264 ~37 ~362 ~268 ~37 ~362 minecraft:redstone_wire replace
setblock ~270 ~37 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~272 ~37 ~362 ~285 ~37 ~362 minecraft:redstone_wire replace
setblock ~287 ~37 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~37 ~362 ~302 ~37 ~362 minecraft:redstone_wire replace
setblock ~304 ~37 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~37 ~362 ~324 ~37 ~362 minecraft:redstone_wire replace
setblock ~326 ~37 ~362 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~328 ~37 ~362 ~335 ~37 ~362 minecraft:redstone_wire replace
setblock ~265 ~37 ~363 minecraft:redstone_wire replace
setblock ~316 ~37 ~363 minecraft:redstone_wire replace
setblock ~319 ~37 ~363 minecraft:redstone_wire replace
setblock ~322 ~37 ~363 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~331 ~37 ~363 minecraft:redstone_wire replace
setblock ~334 ~37 ~363 minecraft:redstone_wire replace
fill ~324 ~37 ~366 ~326 ~37 ~366 minecraft:redstone_wire replace
setblock ~325 ~37 ~367 minecraft:redstone_wire replace
fill ~336 ~37 ~370 ~339 ~37 ~370 minecraft:redstone_wire replace
setblock ~337 ~37 ~371 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~312 ~37 ~374 ~330 ~37 ~374 minecraft:redstone_wire replace
setblock ~332 ~37 ~374 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~334 ~37 ~374 ~341 ~37 ~374 minecraft:redstone_wire replace
setblock ~313 ~37 ~375 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~316 ~37 ~375 minecraft:redstone_wire replace
setblock ~319 ~37 ~375 minecraft:redstone_wire replace
setblock ~325 ~37 ~375 minecraft:redstone_wire replace
setblock ~340 ~37 ~375 minecraft:redstone_wire replace
fill ~327 ~37 ~378 ~336 ~37 ~378 minecraft:redstone_wire replace
setblock ~328 ~37 ~379 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~339 ~37 ~382 ~342 ~37 ~382 minecraft:redstone_wire replace
setblock ~340 ~37 ~383 minecraft:redstone_wire replace
fill ~285 ~37 ~386 ~287 ~37 ~386 minecraft:redstone_wire replace
setblock ~286 ~37 ~387 minecraft:redstone_wire replace
fill ~285 ~37 ~390 ~295 ~37 ~390 minecraft:redstone_wire replace
setblock ~297 ~37 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~299 ~37 ~390 ~312 ~37 ~390 minecraft:redstone_wire replace
setblock ~314 ~37 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~316 ~37 ~390 ~338 ~37 ~390 minecraft:redstone_wire replace
setblock ~340 ~37 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~342 ~37 ~390 ~355 ~37 ~390 minecraft:redstone_wire replace
setblock ~357 ~37 ~390 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~359 ~37 ~390 ~365 ~37 ~390 minecraft:redstone_wire replace
setblock ~286 ~37 ~391 minecraft:redstone_wire replace
setblock ~364 ~37 ~391 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~348 ~37 ~394 ~350 ~37 ~394 minecraft:redstone_wire replace
setblock ~349 ~37 ~395 minecraft:redstone_wire replace
fill ~384 ~37 ~398 ~387 ~37 ~398 minecraft:redstone_wire replace
setblock ~385 ~37 ~399 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~351 ~37 ~402 ~354 ~37 ~402 minecraft:redstone_wire replace
setblock ~352 ~37 ~403 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~345 ~37 ~406 ~346 ~37 ~406 minecraft:redstone_wire replace
setblock ~347 ~37 ~406 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~37 ~406 ~372 ~37 ~406 minecraft:redstone_wire replace
setblock ~374 ~37 ~406 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~376 ~37 ~406 ~377 ~37 ~406 minecraft:redstone_wire replace
setblock ~346 ~37 ~407 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~349 ~37 ~407 minecraft:redstone_wire replace
setblock ~376 ~37 ~407 minecraft:redstone_wire replace
fill ~375 ~37 ~410 ~378 ~37 ~410 minecraft:redstone_wire replace
setblock ~376 ~37 ~411 minecraft:redstone_wire replace
fill ~90 ~37 ~414 ~92 ~37 ~414 minecraft:redstone_wire replace
setblock ~91 ~37 ~415 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~114 ~37 ~418 ~119 ~37 ~418 minecraft:redstone_wire replace
setblock ~118 ~37 ~419 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~138 ~37 ~422 ~146 ~37 ~422 minecraft:redstone_wire replace
setblock ~145 ~37 ~423 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~186 ~37 ~426 ~194 ~37 ~426 minecraft:redstone_wire replace
setblock ~193 ~37 ~427 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~213 ~37 ~430 ~216 ~37 ~430 minecraft:redstone_wire replace
setblock ~214 ~37 ~431 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~237 ~37 ~434 ~243 ~37 ~434 minecraft:redstone_wire replace
setblock ~238 ~37 ~435 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~279 ~37 ~438 ~284 ~37 ~438 minecraft:redstone_wire replace
setblock ~283 ~37 ~439 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~306 ~37 ~442 ~309 ~37 ~442 minecraft:redstone_wire replace
setblock ~307 ~37 ~443 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~342 ~37 ~446 ~345 ~37 ~446 minecraft:redstone_wire replace
setblock ~343 ~37 ~447 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~87 ~37 ~450 ~89 ~37 ~450 minecraft:redstone_wire replace
setblock ~88 ~37 ~451 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~111 ~37 ~454 ~116 ~37 ~454 minecraft:redstone_wire replace
setblock ~115 ~37 ~455 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~135 ~37 ~458 ~143 ~37 ~458 minecraft:redstone_wire replace
setblock ~142 ~37 ~459 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~37 ~462 ~191 ~37 ~462 minecraft:redstone_wire replace
setblock ~190 ~37 ~463 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~37 ~466 ~212 ~37 ~466 minecraft:redstone_wire replace
setblock ~211 ~37 ~467 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~234 ~37 ~470 ~237 ~37 ~470 minecraft:redstone_wire replace
setblock ~235 ~37 ~471 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~276 ~37 ~474 ~278 ~37 ~474 minecraft:redstone_wire replace
setblock ~277 ~37 ~475 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~37 ~478 ~306 ~37 ~478 minecraft:redstone_wire replace
setblock ~304 ~37 ~479 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~366 ~37 ~482 ~369 ~37 ~482 minecraft:redstone_wire replace
setblock ~367 ~37 ~483 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~390 ~37 ~486 ~393 ~37 ~486 minecraft:redstone_wire replace
setblock ~391 ~37 ~487 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~84 ~37 ~490 ~86 ~37 ~490 minecraft:redstone_wire replace
setblock ~85 ~37 ~491 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~108 ~37 ~494 ~113 ~37 ~494 minecraft:redstone_wire replace
setblock ~112 ~37 ~495 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~132 ~37 ~498 ~140 ~37 ~498 minecraft:redstone_wire replace
setblock ~139 ~37 ~499 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~37 ~502 ~173 ~37 ~502 minecraft:redstone_wire replace
setblock ~172 ~37 ~503 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~204 ~37 ~506 ~209 ~37 ~506 minecraft:redstone_wire replace
setblock ~208 ~37 ~507 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~231 ~37 ~510 ~234 ~37 ~510 minecraft:redstone_wire replace
setblock ~232 ~37 ~511 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~273 ~37 ~514 ~275 ~37 ~514 minecraft:redstone_wire replace
setblock ~274 ~37 ~515 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~297 ~37 ~518 ~302 ~37 ~518 minecraft:redstone_wire replace
setblock ~301 ~37 ~519 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~360 ~37 ~522 ~366 ~37 ~522 minecraft:redstone_wire replace
setblock ~361 ~37 ~523 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~387 ~37 ~526 ~390 ~37 ~526 minecraft:redstone_wire replace
setblock ~388 ~37 ~527 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~81 ~37 ~530 ~83 ~37 ~530 minecraft:redstone_wire replace
setblock ~82 ~37 ~531 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~105 ~37 ~534 ~110 ~37 ~534 minecraft:redstone_wire replace
setblock ~109 ~37 ~535 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~129 ~37 ~538 ~137 ~37 ~538 minecraft:redstone_wire replace
setblock ~136 ~37 ~539 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~159 ~37 ~542 ~167 ~37 ~542 minecraft:redstone_wire replace
setblock ~166 ~37 ~543 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~198 ~37 ~546 ~206 ~37 ~546 minecraft:redstone_wire replace
setblock ~205 ~37 ~547 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~228 ~37 ~550 ~231 ~37 ~550 minecraft:redstone_wire replace
setblock ~229 ~37 ~551 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~270 ~37 ~554 ~272 ~37 ~554 minecraft:redstone_wire replace
setblock ~271 ~37 ~555 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~291 ~37 ~558 ~293 ~37 ~558 minecraft:redstone_wire replace
setblock ~292 ~37 ~559 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~357 ~37 ~562 ~363 ~37 ~562 minecraft:redstone_wire replace
setblock ~358 ~37 ~563 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~381 ~37 ~566 ~384 ~37 ~566 minecraft:redstone_wire replace
setblock ~382 ~37 ~567 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~37 ~570 ~80 ~37 ~570 minecraft:redstone_wire replace
setblock ~79 ~37 ~571 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~102 ~37 ~574 ~107 ~37 ~574 minecraft:redstone_wire replace
setblock ~106 ~37 ~575 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~126 ~37 ~578 ~134 ~37 ~578 minecraft:redstone_wire replace
setblock ~133 ~37 ~579 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~153 ~37 ~582 ~164 ~37 ~582 minecraft:redstone_wire replace
setblock ~163 ~37 ~583 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~192 ~37 ~586 ~200 ~37 ~586 minecraft:redstone_wire replace
setblock ~199 ~37 ~587 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~219 ~37 ~590 ~222 ~37 ~590 minecraft:redstone_wire replace
setblock ~220 ~37 ~591 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~267 ~37 ~594 ~269 ~37 ~594 minecraft:redstone_wire replace
setblock ~268 ~37 ~595 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~37 ~598 ~290 ~37 ~598 minecraft:redstone_wire replace
setblock ~289 ~37 ~599 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~354 ~37 ~602 ~357 ~37 ~602 minecraft:redstone_wire replace
setblock ~355 ~37 ~603 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~378 ~37 ~606 ~381 ~37 ~606 minecraft:redstone_wire replace
setblock ~379 ~37 ~607 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~99 ~37 ~610 ~104 ~37 ~610 minecraft:redstone_wire replace
setblock ~103 ~37 ~611 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~37 ~614 ~131 ~37 ~614 minecraft:redstone_wire replace
setblock ~130 ~37 ~615 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~147 ~37 ~618 ~158 ~37 ~618 minecraft:redstone_wire replace
setblock ~159 ~37 ~618 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~160 ~37 ~618 ~161 ~37 ~618 minecraft:redstone_wire replace
setblock ~160 ~37 ~619 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~189 ~37 ~622 ~197 ~37 ~622 minecraft:redstone_wire replace
setblock ~196 ~37 ~623 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~216 ~37 ~626 ~219 ~37 ~626 minecraft:redstone_wire replace
setblock ~217 ~37 ~627 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~240 ~37 ~630 ~249 ~37 ~630 minecraft:redstone_wire replace
setblock ~241 ~37 ~631 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~294 ~37 ~634 ~296 ~37 ~634 minecraft:redstone_wire replace
setblock ~295 ~37 ~635 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~309 ~37 ~638 ~312 ~37 ~638 minecraft:redstone_wire replace
setblock ~310 ~37 ~639 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~369 ~37 ~642 ~372 ~37 ~642 minecraft:redstone_wire replace
setblock ~370 ~37 ~643 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~162 ~37 ~646 ~170 ~37 ~646 minecraft:redstone_wire replace
setblock ~169 ~37 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~396 ~37 ~650 ~399 ~37 ~650 minecraft:redstone_wire replace
setblock ~397 ~37 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~37 ~654 ~101 ~37 ~654 minecraft:redstone_wire replace
setblock ~100 ~37 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~372 ~37 ~658 ~375 ~37 ~658 minecraft:redstone_wire replace
setblock ~373 ~37 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~393 ~37 ~662 ~396 ~37 ~662 minecraft:redstone_wire replace
setblock ~394 ~37 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~148 ~38 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~38 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~38 ~32 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~38 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~38 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~38 ~48 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~38 ~56 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~38 ~64 minecraft:redstone_torch[lit=true] replace
setblock ~349 ~38 ~80 minecraft:redstone_torch[lit=true] replace
setblock ~94 ~38 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~38 ~268 minecraft:redstone_wire replace
setblock ~94 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~127 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~272 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~38 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~38 ~280 minecraft:redstone_wire replace
setblock ~127 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~38 ~284 minecraft:redstone_torch[lit=true] replace
setblock ~151 ~38 ~288 minecraft:redstone_wire replace
setblock ~121 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~154 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~38 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~157 ~38 ~300 minecraft:redstone_torch[lit=true] replace
setblock ~181 ~38 ~304 minecraft:redstone_wire replace
setblock ~157 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~175 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~178 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~38 ~312 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~38 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~244 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~247 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~250 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~253 ~38 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~256 ~38 ~324 minecraft:redstone_wire replace
setblock ~202 ~38 ~328 minecraft:redstone_torch[lit=true] replace
setblock ~223 ~38 ~332 minecraft:redstone_wire replace
setblock ~202 ~38 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~280 ~38 ~336 minecraft:redstone_wire replace
setblock ~259 ~38 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~38 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~38 ~340 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~38 ~344 minecraft:redstone_torch[lit=true] replace
setblock ~262 ~38 ~348 minecraft:redstone_wire replace
setblock ~226 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~259 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~298 ~38 ~352 minecraft:redstone_wire replace
setblock ~316 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~331 ~38 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~38 ~356 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~38 ~360 minecraft:redstone_torch[lit=true] replace
setblock ~265 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~322 ~38 ~364 minecraft:redstone_wire replace
setblock ~331 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~38 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~38 ~368 minecraft:redstone_torch[lit=true] replace
setblock ~337 ~38 ~372 minecraft:redstone_wire replace
setblock ~313 ~38 ~376 minecraft:redstone_wire replace
setblock ~316 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~319 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~325 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~340 ~38 ~376 minecraft:redstone_torch[lit=true] replace
setblock ~328 ~38 ~380 minecraft:redstone_wire replace
setblock ~340 ~38 ~384 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~38 ~388 minecraft:redstone_torch[lit=true] replace
setblock ~286 ~38 ~392 minecraft:redstone_torch[lit=true] replace
setblock ~364 ~38 ~392 minecraft:redstone_wire replace
setblock ~349 ~38 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~385 ~38 ~400 minecraft:redstone_wire replace
setblock ~352 ~38 ~404 minecraft:redstone_wire replace
setblock ~346 ~38 ~408 minecraft:redstone_wire replace
setblock ~349 ~38 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~38 ~408 minecraft:redstone_torch[lit=true] replace
setblock ~376 ~38 ~412 minecraft:redstone_torch[lit=true] replace
setblock ~91 ~38 ~416 minecraft:redstone_wire replace
setblock ~118 ~38 ~420 minecraft:redstone_wire replace
setblock ~145 ~38 ~424 minecraft:redstone_wire replace
setblock ~193 ~38 ~428 minecraft:redstone_wire replace
setblock ~214 ~38 ~432 minecraft:redstone_wire replace
setblock ~238 ~38 ~436 minecraft:redstone_wire replace
setblock ~283 ~38 ~440 minecraft:redstone_wire replace
setblock ~307 ~38 ~444 minecraft:redstone_wire replace
setblock ~343 ~38 ~448 minecraft:redstone_wire replace
setblock ~88 ~38 ~452 minecraft:redstone_wire replace
setblock ~115 ~38 ~456 minecraft:redstone_wire replace
setblock ~142 ~38 ~460 minecraft:redstone_wire replace
setblock ~190 ~38 ~464 minecraft:redstone_wire replace
setblock ~211 ~38 ~468 minecraft:redstone_wire replace
setblock ~235 ~38 ~472 minecraft:redstone_wire replace
setblock ~277 ~38 ~476 minecraft:redstone_wire replace
setblock ~304 ~38 ~480 minecraft:redstone_wire replace
setblock ~367 ~38 ~484 minecraft:redstone_wire replace
setblock ~391 ~38 ~488 minecraft:redstone_wire replace
setblock ~85 ~38 ~492 minecraft:redstone_wire replace
setblock ~112 ~38 ~496 minecraft:redstone_wire replace
setblock ~139 ~38 ~500 minecraft:redstone_wire replace
setblock ~172 ~38 ~504 minecraft:redstone_wire replace
setblock ~208 ~38 ~508 minecraft:redstone_wire replace
setblock ~232 ~38 ~512 minecraft:redstone_wire replace
setblock ~274 ~38 ~516 minecraft:redstone_wire replace
setblock ~301 ~38 ~520 minecraft:redstone_wire replace
setblock ~361 ~38 ~524 minecraft:redstone_wire replace
setblock ~388 ~38 ~528 minecraft:redstone_wire replace
setblock ~82 ~38 ~532 minecraft:redstone_wire replace
setblock ~109 ~38 ~536 minecraft:redstone_wire replace
setblock ~136 ~38 ~540 minecraft:redstone_wire replace
setblock ~166 ~38 ~544 minecraft:redstone_wire replace
setblock ~205 ~38 ~548 minecraft:redstone_wire replace
setblock ~229 ~38 ~552 minecraft:redstone_wire replace
setblock ~271 ~38 ~556 minecraft:redstone_wire replace
setblock ~292 ~38 ~560 minecraft:redstone_wire replace
setblock ~358 ~38 ~564 minecraft:redstone_wire replace
setblock ~382 ~38 ~568 minecraft:redstone_wire replace
setblock ~79 ~38 ~572 minecraft:redstone_wire replace
setblock ~106 ~38 ~576 minecraft:redstone_wire replace
setblock ~133 ~38 ~580 minecraft:redstone_wire replace
setblock ~163 ~38 ~584 minecraft:redstone_wire replace
setblock ~199 ~38 ~588 minecraft:redstone_wire replace
setblock ~220 ~38 ~592 minecraft:redstone_wire replace
setblock ~268 ~38 ~596 minecraft:redstone_wire replace
setblock ~289 ~38 ~600 minecraft:redstone_wire replace
setblock ~355 ~38 ~604 minecraft:redstone_wire replace
setblock ~379 ~38 ~608 minecraft:redstone_wire replace
setblock ~103 ~38 ~612 minecraft:redstone_wire replace
setblock ~130 ~38 ~616 minecraft:redstone_wire replace
setblock ~160 ~38 ~620 minecraft:redstone_wire replace
setblock ~196 ~38 ~624 minecraft:redstone_wire replace
setblock ~217 ~38 ~628 minecraft:redstone_wire replace
setblock ~241 ~38 ~632 minecraft:redstone_wire replace
setblock ~295 ~38 ~636 minecraft:redstone_wire replace
setblock ~310 ~38 ~640 minecraft:redstone_wire replace
setblock ~370 ~38 ~644 minecraft:redstone_wire replace
setblock ~169 ~38 ~648 minecraft:redstone_wire replace
setblock ~397 ~38 ~652 minecraft:redstone_wire replace
setblock ~100 ~38 ~656 minecraft:redstone_wire replace
setblock ~373 ~38 ~660 minecraft:redstone_wire replace
setblock ~394 ~38 ~664 minecraft:redstone_wire replace
setblock ~243 ~39 ~4 minecraft:redstone_wire replace
setblock ~243 ~39 ~6 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~8 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~8 ~243 ~39 ~20 minecraft:redstone_wire replace
fill ~174 ~39 ~10 ~174 ~39 ~20 minecraft:redstone_wire replace
setblock ~147 ~39 ~12 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~39 ~14 ~147 ~39 ~20 minecraft:redstone_wire replace
fill ~246 ~39 ~16 ~246 ~39 ~18 minecraft:redstone_wire replace
fill ~177 ~39 ~20 ~177 ~39 ~24 minecraft:redstone_wire replace
setblock ~246 ~39 ~20 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~22 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~22 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~22 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~22 ~246 ~39 ~34 minecraft:redstone_wire replace
fill ~147 ~39 ~24 ~147 ~39 ~36 minecraft:redstone_wire replace
fill ~174 ~39 ~24 ~174 ~39 ~36 minecraft:redstone_wire replace
fill ~243 ~39 ~24 ~243 ~39 ~36 minecraft:redstone_wire replace
setblock ~177 ~39 ~25 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~39 ~26 ~177 ~39 ~38 minecraft:redstone_wire replace
fill ~249 ~39 ~28 ~249 ~39 ~32 minecraft:redstone_wire replace
setblock ~249 ~39 ~34 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~246 ~39 ~36 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~36 ~249 ~39 ~48 minecraft:redstone_wire replace
setblock ~330 ~39 ~36 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~38 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~38 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~38 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~38 ~246 ~39 ~50 minecraft:redstone_wire replace
fill ~330 ~39 ~38 ~330 ~39 ~48 minecraft:redstone_wire replace
fill ~147 ~39 ~40 ~147 ~39 ~52 minecraft:redstone_wire replace
fill ~174 ~39 ~40 ~174 ~39 ~52 minecraft:redstone_wire replace
setblock ~177 ~39 ~40 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~40 ~243 ~39 ~52 minecraft:redstone_wire replace
fill ~315 ~39 ~40 ~315 ~39 ~42 minecraft:redstone_wire replace
fill ~177 ~39 ~42 ~177 ~39 ~54 minecraft:redstone_wire replace
fill ~258 ~39 ~44 ~258 ~39 ~50 minecraft:redstone_wire replace
setblock ~315 ~39 ~44 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~46 ~315 ~39 ~58 minecraft:redstone_wire replace
setblock ~333 ~39 ~48 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~330 ~39 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~249 ~39 ~50 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~50 ~330 ~39 ~62 minecraft:redstone_wire replace
fill ~333 ~39 ~50 ~333 ~39 ~60 minecraft:redstone_wire replace
setblock ~246 ~39 ~52 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~52 ~249 ~39 ~64 minecraft:redstone_wire replace
setblock ~258 ~39 ~52 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~39 ~52 ~318 ~39 ~58 minecraft:redstone_wire replace
setblock ~147 ~39 ~54 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~54 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~54 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~54 ~246 ~39 ~66 minecraft:redstone_wire replace
fill ~258 ~39 ~54 ~258 ~39 ~66 minecraft:redstone_wire replace
fill ~147 ~39 ~56 ~147 ~39 ~68 minecraft:redstone_wire replace
fill ~174 ~39 ~56 ~174 ~39 ~68 minecraft:redstone_wire replace
setblock ~177 ~39 ~56 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~56 ~243 ~39 ~68 minecraft:redstone_wire replace
fill ~177 ~39 ~58 ~177 ~39 ~70 minecraft:redstone_wire replace
setblock ~315 ~39 ~60 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~60 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~324 ~39 ~60 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~62 ~315 ~39 ~74 minecraft:redstone_wire replace
fill ~318 ~39 ~62 ~318 ~39 ~74 minecraft:redstone_wire replace
fill ~324 ~39 ~62 ~324 ~39 ~72 minecraft:redstone_wire replace
setblock ~333 ~39 ~62 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~330 ~39 ~64 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~64 ~333 ~39 ~76 minecraft:redstone_wire replace
setblock ~249 ~39 ~66 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~66 ~330 ~39 ~78 minecraft:redstone_wire replace
setblock ~246 ~39 ~68 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~68 ~249 ~39 ~80 minecraft:redstone_wire replace
setblock ~258 ~39 ~68 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~70 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~70 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~70 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~70 ~246 ~39 ~82 minecraft:redstone_wire replace
fill ~258 ~39 ~70 ~258 ~39 ~82 minecraft:redstone_wire replace
fill ~147 ~39 ~72 ~147 ~39 ~84 minecraft:redstone_wire replace
fill ~174 ~39 ~72 ~174 ~39 ~84 minecraft:redstone_wire replace
setblock ~177 ~39 ~72 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~72 ~243 ~39 ~84 minecraft:redstone_wire replace
fill ~177 ~39 ~74 ~177 ~39 ~86 minecraft:redstone_wire replace
setblock ~324 ~39 ~74 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~76 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~76 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~76 ~324 ~39 ~88 minecraft:redstone_wire replace
setblock ~348 ~39 ~76 minecraft:redstone_wire replace
setblock ~348 ~39 ~77 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~78 ~315 ~39 ~90 minecraft:redstone_wire replace
fill ~318 ~39 ~78 ~318 ~39 ~90 minecraft:redstone_wire replace
setblock ~333 ~39 ~78 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~78 ~348 ~39 ~90 minecraft:redstone_wire replace
setblock ~330 ~39 ~80 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~80 ~333 ~39 ~92 minecraft:redstone_wire replace
setblock ~249 ~39 ~82 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~82 ~330 ~39 ~94 minecraft:redstone_wire replace
setblock ~246 ~39 ~84 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~84 ~249 ~39 ~96 minecraft:redstone_wire replace
setblock ~258 ~39 ~84 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~86 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~86 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~86 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~86 ~246 ~39 ~98 minecraft:redstone_wire replace
fill ~258 ~39 ~86 ~258 ~39 ~98 minecraft:redstone_wire replace
fill ~147 ~39 ~88 ~147 ~39 ~100 minecraft:redstone_wire replace
fill ~174 ~39 ~88 ~174 ~39 ~100 minecraft:redstone_wire replace
setblock ~177 ~39 ~88 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~88 ~243 ~39 ~100 minecraft:redstone_wire replace
fill ~177 ~39 ~90 ~177 ~39 ~102 minecraft:redstone_wire replace
setblock ~324 ~39 ~90 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~92 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~92 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~92 ~324 ~39 ~104 minecraft:redstone_wire replace
setblock ~348 ~39 ~92 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~94 ~315 ~39 ~106 minecraft:redstone_wire replace
fill ~318 ~39 ~94 ~318 ~39 ~106 minecraft:redstone_wire replace
setblock ~333 ~39 ~94 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~94 ~348 ~39 ~106 minecraft:redstone_wire replace
setblock ~330 ~39 ~96 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~96 ~333 ~39 ~108 minecraft:redstone_wire replace
setblock ~249 ~39 ~98 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~98 ~330 ~39 ~110 minecraft:redstone_wire replace
setblock ~246 ~39 ~100 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~100 ~249 ~39 ~112 minecraft:redstone_wire replace
setblock ~258 ~39 ~100 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~102 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~102 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~102 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~102 ~246 ~39 ~114 minecraft:redstone_wire replace
fill ~258 ~39 ~102 ~258 ~39 ~114 minecraft:redstone_wire replace
fill ~147 ~39 ~104 ~147 ~39 ~116 minecraft:redstone_wire replace
fill ~174 ~39 ~104 ~174 ~39 ~116 minecraft:redstone_wire replace
setblock ~177 ~39 ~104 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~104 ~243 ~39 ~116 minecraft:redstone_wire replace
fill ~177 ~39 ~106 ~177 ~39 ~118 minecraft:redstone_wire replace
setblock ~324 ~39 ~106 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~108 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~108 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~108 ~324 ~39 ~120 minecraft:redstone_wire replace
setblock ~348 ~39 ~108 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~110 ~315 ~39 ~122 minecraft:redstone_wire replace
fill ~318 ~39 ~110 ~318 ~39 ~122 minecraft:redstone_wire replace
setblock ~333 ~39 ~110 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~110 ~348 ~39 ~122 minecraft:redstone_wire replace
setblock ~330 ~39 ~112 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~112 ~333 ~39 ~124 minecraft:redstone_wire replace
setblock ~249 ~39 ~114 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~114 ~330 ~39 ~126 minecraft:redstone_wire replace
setblock ~246 ~39 ~116 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~116 ~249 ~39 ~128 minecraft:redstone_wire replace
setblock ~258 ~39 ~116 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~118 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~118 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~118 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~118 ~246 ~39 ~130 minecraft:redstone_wire replace
fill ~258 ~39 ~118 ~258 ~39 ~130 minecraft:redstone_wire replace
fill ~147 ~39 ~120 ~147 ~39 ~132 minecraft:redstone_wire replace
fill ~174 ~39 ~120 ~174 ~39 ~132 minecraft:redstone_wire replace
setblock ~177 ~39 ~120 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~120 ~243 ~39 ~132 minecraft:redstone_wire replace
fill ~177 ~39 ~122 ~177 ~39 ~134 minecraft:redstone_wire replace
setblock ~324 ~39 ~122 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~124 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~124 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~124 ~324 ~39 ~136 minecraft:redstone_wire replace
setblock ~348 ~39 ~124 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~126 ~315 ~39 ~138 minecraft:redstone_wire replace
fill ~318 ~39 ~126 ~318 ~39 ~138 minecraft:redstone_wire replace
setblock ~333 ~39 ~126 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~126 ~348 ~39 ~138 minecraft:redstone_wire replace
setblock ~330 ~39 ~128 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~128 ~333 ~39 ~140 minecraft:redstone_wire replace
setblock ~249 ~39 ~130 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~130 ~330 ~39 ~142 minecraft:redstone_wire replace
setblock ~246 ~39 ~132 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~132 ~249 ~39 ~144 minecraft:redstone_wire replace
setblock ~258 ~39 ~132 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~134 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~134 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~134 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~134 ~246 ~39 ~146 minecraft:redstone_wire replace
fill ~258 ~39 ~134 ~258 ~39 ~146 minecraft:redstone_wire replace
fill ~147 ~39 ~136 ~147 ~39 ~148 minecraft:redstone_wire replace
fill ~174 ~39 ~136 ~174 ~39 ~148 minecraft:redstone_wire replace
setblock ~177 ~39 ~136 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~136 ~243 ~39 ~148 minecraft:redstone_wire replace
fill ~177 ~39 ~138 ~177 ~39 ~150 minecraft:redstone_wire replace
setblock ~324 ~39 ~138 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~140 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~140 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~140 ~324 ~39 ~152 minecraft:redstone_wire replace
setblock ~348 ~39 ~140 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~142 ~315 ~39 ~154 minecraft:redstone_wire replace
fill ~318 ~39 ~142 ~318 ~39 ~154 minecraft:redstone_wire replace
setblock ~333 ~39 ~142 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~142 ~348 ~39 ~154 minecraft:redstone_wire replace
setblock ~330 ~39 ~144 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~144 ~333 ~39 ~156 minecraft:redstone_wire replace
setblock ~249 ~39 ~146 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~146 ~330 ~39 ~158 minecraft:redstone_wire replace
setblock ~246 ~39 ~148 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~148 ~249 ~39 ~160 minecraft:redstone_wire replace
setblock ~258 ~39 ~148 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~150 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~150 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~150 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~150 ~246 ~39 ~162 minecraft:redstone_wire replace
fill ~258 ~39 ~150 ~258 ~39 ~162 minecraft:redstone_wire replace
fill ~147 ~39 ~152 ~147 ~39 ~164 minecraft:redstone_wire replace
fill ~174 ~39 ~152 ~174 ~39 ~164 minecraft:redstone_wire replace
setblock ~177 ~39 ~152 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~152 ~243 ~39 ~164 minecraft:redstone_wire replace
fill ~177 ~39 ~154 ~177 ~39 ~166 minecraft:redstone_wire replace
setblock ~324 ~39 ~154 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~156 ~324 ~39 ~168 minecraft:redstone_wire replace
setblock ~348 ~39 ~156 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~158 ~315 ~39 ~170 minecraft:redstone_wire replace
fill ~318 ~39 ~158 ~318 ~39 ~170 minecraft:redstone_wire replace
setblock ~333 ~39 ~158 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~158 ~348 ~39 ~170 minecraft:redstone_wire replace
setblock ~330 ~39 ~160 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~160 ~333 ~39 ~172 minecraft:redstone_wire replace
setblock ~249 ~39 ~162 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~162 ~330 ~39 ~174 minecraft:redstone_wire replace
setblock ~246 ~39 ~164 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~164 ~249 ~39 ~176 minecraft:redstone_wire replace
setblock ~258 ~39 ~164 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~166 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~166 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~166 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~166 ~246 ~39 ~178 minecraft:redstone_wire replace
fill ~258 ~39 ~166 ~258 ~39 ~178 minecraft:redstone_wire replace
fill ~147 ~39 ~168 ~147 ~39 ~180 minecraft:redstone_wire replace
fill ~174 ~39 ~168 ~174 ~39 ~180 minecraft:redstone_wire replace
setblock ~177 ~39 ~168 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~168 ~243 ~39 ~180 minecraft:redstone_wire replace
fill ~177 ~39 ~170 ~177 ~39 ~182 minecraft:redstone_wire replace
setblock ~324 ~39 ~170 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~172 ~324 ~39 ~184 minecraft:redstone_wire replace
setblock ~348 ~39 ~172 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~174 ~315 ~39 ~186 minecraft:redstone_wire replace
fill ~318 ~39 ~174 ~318 ~39 ~186 minecraft:redstone_wire replace
setblock ~333 ~39 ~174 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~174 ~348 ~39 ~186 minecraft:redstone_wire replace
setblock ~330 ~39 ~176 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~176 ~333 ~39 ~188 minecraft:redstone_wire replace
setblock ~249 ~39 ~178 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~178 ~330 ~39 ~190 minecraft:redstone_wire replace
setblock ~246 ~39 ~180 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~180 ~249 ~39 ~192 minecraft:redstone_wire replace
setblock ~258 ~39 ~180 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~182 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~182 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~182 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~182 ~246 ~39 ~194 minecraft:redstone_wire replace
fill ~258 ~39 ~182 ~258 ~39 ~194 minecraft:redstone_wire replace
fill ~147 ~39 ~184 ~147 ~39 ~196 minecraft:redstone_wire replace
fill ~174 ~39 ~184 ~174 ~39 ~196 minecraft:redstone_wire replace
setblock ~177 ~39 ~184 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~184 ~243 ~39 ~196 minecraft:redstone_wire replace
fill ~177 ~39 ~186 ~177 ~39 ~198 minecraft:redstone_wire replace
setblock ~324 ~39 ~186 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~188 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~188 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~188 ~324 ~39 ~200 minecraft:redstone_wire replace
setblock ~348 ~39 ~188 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~190 ~315 ~39 ~202 minecraft:redstone_wire replace
fill ~318 ~39 ~190 ~318 ~39 ~202 minecraft:redstone_wire replace
setblock ~333 ~39 ~190 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~190 ~348 ~39 ~202 minecraft:redstone_wire replace
setblock ~330 ~39 ~192 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~192 ~333 ~39 ~204 minecraft:redstone_wire replace
setblock ~249 ~39 ~194 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~194 ~330 ~39 ~206 minecraft:redstone_wire replace
setblock ~246 ~39 ~196 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~196 ~249 ~39 ~208 minecraft:redstone_wire replace
setblock ~258 ~39 ~196 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~198 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~198 ~246 ~39 ~210 minecraft:redstone_wire replace
fill ~258 ~39 ~198 ~258 ~39 ~210 minecraft:redstone_wire replace
fill ~147 ~39 ~200 ~147 ~39 ~212 minecraft:redstone_wire replace
fill ~174 ~39 ~200 ~174 ~39 ~212 minecraft:redstone_wire replace
setblock ~177 ~39 ~200 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~200 ~243 ~39 ~212 minecraft:redstone_wire replace
fill ~177 ~39 ~202 ~177 ~39 ~214 minecraft:redstone_wire replace
setblock ~324 ~39 ~202 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~204 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~204 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~204 ~324 ~39 ~216 minecraft:redstone_wire replace
setblock ~348 ~39 ~204 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~206 ~315 ~39 ~218 minecraft:redstone_wire replace
fill ~318 ~39 ~206 ~318 ~39 ~218 minecraft:redstone_wire replace
setblock ~333 ~39 ~206 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~206 ~348 ~39 ~218 minecraft:redstone_wire replace
setblock ~330 ~39 ~208 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~208 ~333 ~39 ~220 minecraft:redstone_wire replace
setblock ~249 ~39 ~210 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~210 ~330 ~39 ~222 minecraft:redstone_wire replace
setblock ~246 ~39 ~212 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~212 ~249 ~39 ~224 minecraft:redstone_wire replace
setblock ~258 ~39 ~212 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~214 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~214 ~246 ~39 ~226 minecraft:redstone_wire replace
fill ~258 ~39 ~214 ~258 ~39 ~226 minecraft:redstone_wire replace
fill ~147 ~39 ~216 ~147 ~39 ~228 minecraft:redstone_wire replace
fill ~174 ~39 ~216 ~174 ~39 ~228 minecraft:redstone_wire replace
setblock ~177 ~39 ~216 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~216 ~243 ~39 ~228 minecraft:redstone_wire replace
fill ~177 ~39 ~218 ~177 ~39 ~230 minecraft:redstone_wire replace
setblock ~324 ~39 ~218 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~220 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~220 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~220 ~324 ~39 ~232 minecraft:redstone_wire replace
setblock ~348 ~39 ~220 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~222 ~315 ~39 ~234 minecraft:redstone_wire replace
fill ~318 ~39 ~222 ~318 ~39 ~234 minecraft:redstone_wire replace
setblock ~333 ~39 ~222 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~222 ~348 ~39 ~234 minecraft:redstone_wire replace
setblock ~330 ~39 ~224 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~224 ~333 ~39 ~236 minecraft:redstone_wire replace
setblock ~249 ~39 ~226 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~226 ~330 ~39 ~238 minecraft:redstone_wire replace
setblock ~246 ~39 ~228 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~228 ~249 ~39 ~240 minecraft:redstone_wire replace
setblock ~258 ~39 ~228 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~230 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~230 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~230 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~230 ~246 ~39 ~242 minecraft:redstone_wire replace
fill ~258 ~39 ~230 ~258 ~39 ~242 minecraft:redstone_wire replace
fill ~147 ~39 ~232 ~147 ~39 ~244 minecraft:redstone_wire replace
fill ~174 ~39 ~232 ~174 ~39 ~244 minecraft:redstone_wire replace
setblock ~177 ~39 ~232 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~232 ~243 ~39 ~244 minecraft:redstone_wire replace
fill ~177 ~39 ~234 ~177 ~39 ~246 minecraft:redstone_wire replace
setblock ~324 ~39 ~234 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~236 ~324 ~39 ~248 minecraft:redstone_wire replace
setblock ~348 ~39 ~236 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~238 ~315 ~39 ~250 minecraft:redstone_wire replace
fill ~318 ~39 ~238 ~318 ~39 ~250 minecraft:redstone_wire replace
setblock ~333 ~39 ~238 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~238 ~348 ~39 ~250 minecraft:redstone_wire replace
setblock ~330 ~39 ~240 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~240 ~333 ~39 ~252 minecraft:redstone_wire replace
setblock ~249 ~39 ~242 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~242 ~330 ~39 ~254 minecraft:redstone_wire replace
setblock ~246 ~39 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~244 ~249 ~39 ~256 minecraft:redstone_wire replace
setblock ~258 ~39 ~244 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~246 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~246 ~246 ~39 ~258 minecraft:redstone_wire replace
fill ~258 ~39 ~246 ~258 ~39 ~258 minecraft:redstone_wire replace
setblock ~93 ~39 ~248 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~39 ~248 ~147 ~39 ~260 minecraft:redstone_wire replace
fill ~174 ~39 ~248 ~174 ~39 ~260 minecraft:redstone_wire replace
setblock ~177 ~39 ~248 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~248 ~243 ~39 ~260 minecraft:redstone_wire replace
fill ~93 ~39 ~250 ~93 ~39 ~256 minecraft:redstone_wire replace
fill ~177 ~39 ~250 ~177 ~39 ~262 minecraft:redstone_wire replace
setblock ~324 ~39 ~250 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~39 ~252 minecraft:redstone_wire replace
setblock ~315 ~39 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~252 ~324 ~39 ~264 minecraft:redstone_wire replace
setblock ~348 ~39 ~252 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~123 ~39 ~254 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~254 ~315 ~39 ~266 minecraft:redstone_wire replace
fill ~318 ~39 ~254 ~318 ~39 ~266 minecraft:redstone_wire replace
setblock ~333 ~39 ~254 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~254 ~348 ~39 ~266 minecraft:redstone_wire replace
fill ~123 ~39 ~256 ~123 ~39 ~268 minecraft:redstone_wire replace
fill ~252 ~39 ~256 ~252 ~39 ~262 minecraft:redstone_wire replace
setblock ~330 ~39 ~256 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~256 ~333 ~39 ~268 minecraft:redstone_wire replace
setblock ~93 ~39 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~249 ~39 ~258 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~258 ~330 ~39 ~270 minecraft:redstone_wire replace
fill ~93 ~39 ~260 ~93 ~39 ~272 minecraft:redstone_wire replace
fill ~183 ~39 ~260 ~183 ~39 ~262 minecraft:redstone_wire replace
setblock ~246 ~39 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~260 ~249 ~39 ~272 minecraft:redstone_wire replace
setblock ~258 ~39 ~260 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~262 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~262 ~246 ~39 ~274 minecraft:redstone_wire replace
fill ~258 ~39 ~262 ~258 ~39 ~274 minecraft:redstone_wire replace
fill ~147 ~39 ~264 ~147 ~39 ~276 minecraft:redstone_wire replace
setblock ~153 ~39 ~264 minecraft:redstone_wire replace
fill ~174 ~39 ~264 ~174 ~39 ~276 minecraft:redstone_wire replace
setblock ~177 ~39 ~264 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~39 ~264 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~264 ~243 ~39 ~276 minecraft:redstone_wire replace
setblock ~252 ~39 ~264 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~153 ~39 ~265 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~39 ~266 ~153 ~39 ~278 minecraft:redstone_wire replace
fill ~177 ~39 ~266 ~177 ~39 ~278 minecraft:redstone_wire replace
fill ~183 ~39 ~266 ~183 ~39 ~278 minecraft:redstone_wire replace
fill ~252 ~39 ~266 ~252 ~39 ~278 minecraft:redstone_wire replace
setblock ~324 ~39 ~266 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~268 ~324 ~39 ~280 minecraft:redstone_wire replace
setblock ~348 ~39 ~268 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~39 ~270 ~126 ~39 ~280 minecraft:redstone_wire replace
fill ~315 ~39 ~270 ~315 ~39 ~282 minecraft:redstone_wire replace
fill ~318 ~39 ~270 ~318 ~39 ~282 minecraft:redstone_wire replace
setblock ~333 ~39 ~270 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~270 ~348 ~39 ~282 minecraft:redstone_wire replace
setblock ~330 ~39 ~272 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~272 ~333 ~39 ~284 minecraft:redstone_wire replace
setblock ~249 ~39 ~274 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~274 ~330 ~39 ~286 minecraft:redstone_wire replace
fill ~96 ~39 ~276 ~96 ~39 ~280 minecraft:redstone_wire replace
setblock ~246 ~39 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~276 ~249 ~39 ~288 minecraft:redstone_wire replace
setblock ~258 ~39 ~276 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~147 ~39 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~278 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~39 ~278 ~246 ~39 ~290 minecraft:redstone_wire replace
fill ~258 ~39 ~278 ~258 ~39 ~290 minecraft:redstone_wire replace
setblock ~153 ~39 ~279 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~39 ~279 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~39 ~279 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~39 ~280 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~147 ~39 ~280 ~147 ~39 ~292 minecraft:redstone_wire replace
fill ~153 ~39 ~280 ~153 ~39 ~292 minecraft:redstone_wire replace
fill ~174 ~39 ~280 ~174 ~39 ~292 minecraft:redstone_wire replace
setblock ~177 ~39 ~280 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~183 ~39 ~280 ~183 ~39 ~292 minecraft:redstone_wire replace
fill ~243 ~39 ~280 ~243 ~39 ~292 minecraft:redstone_wire replace
fill ~252 ~39 ~280 ~252 ~39 ~292 minecraft:redstone_wire replace
fill ~120 ~39 ~282 ~120 ~39 ~292 minecraft:redstone_wire replace
fill ~177 ~39 ~282 ~177 ~39 ~294 minecraft:redstone_wire replace
setblock ~324 ~39 ~282 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~39 ~284 ~150 ~39 ~288 minecraft:redstone_wire replace
setblock ~315 ~39 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~284 ~324 ~39 ~296 minecraft:redstone_wire replace
setblock ~348 ~39 ~284 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~286 ~315 ~39 ~298 minecraft:redstone_wire replace
fill ~318 ~39 ~286 ~318 ~39 ~298 minecraft:redstone_wire replace
setblock ~333 ~39 ~286 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~286 ~348 ~39 ~298 minecraft:redstone_wire replace
setblock ~330 ~39 ~288 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~288 ~333 ~39 ~300 minecraft:redstone_wire replace
setblock ~249 ~39 ~290 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~290 ~330 ~39 ~302 minecraft:redstone_wire replace
setblock ~246 ~39 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~39 ~292 ~249 ~39 ~304 minecraft:redstone_wire replace
setblock ~258 ~39 ~292 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~243 ~39 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~39 ~293 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~174 ~39 ~294 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~183 ~39 ~294 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~294 ~243 ~39 ~306 minecraft:redstone_wire replace
fill ~246 ~39 ~294 ~246 ~39 ~306 minecraft:redstone_wire replace
fill ~252 ~39 ~294 ~252 ~39 ~306 minecraft:redstone_wire replace
fill ~258 ~39 ~294 ~258 ~39 ~306 minecraft:redstone_wire replace
setblock ~177 ~39 ~295 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~156 ~39 ~296 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~39 ~296 ~174 ~39 ~308 minecraft:redstone_wire replace
fill ~177 ~39 ~296 ~177 ~39 ~308 minecraft:redstone_wire replace
fill ~183 ~39 ~296 ~183 ~39 ~308 minecraft:redstone_wire replace
fill ~156 ~39 ~298 ~156 ~39 ~308 minecraft:redstone_wire replace
setblock ~324 ~39 ~298 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~39 ~300 ~180 ~39 ~304 minecraft:redstone_wire replace
setblock ~315 ~39 ~300 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~300 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~300 ~324 ~39 ~312 minecraft:redstone_wire replace
setblock ~348 ~39 ~300 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~302 ~315 ~39 ~314 minecraft:redstone_wire replace
fill ~318 ~39 ~302 ~318 ~39 ~314 minecraft:redstone_wire replace
setblock ~333 ~39 ~302 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~302 ~348 ~39 ~314 minecraft:redstone_wire replace
setblock ~330 ~39 ~304 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~304 ~333 ~39 ~316 minecraft:redstone_wire replace
setblock ~249 ~39 ~306 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~306 ~330 ~39 ~318 minecraft:redstone_wire replace
setblock ~243 ~39 ~307 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~246 ~39 ~307 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~252 ~39 ~307 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~39 ~308 ~243 ~39 ~320 minecraft:redstone_wire replace
fill ~246 ~39 ~308 ~246 ~39 ~320 minecraft:redstone_wire replace
fill ~249 ~39 ~308 ~249 ~39 ~320 minecraft:redstone_wire replace
fill ~252 ~39 ~308 ~252 ~39 ~320 minecraft:redstone_wire replace
setblock ~258 ~39 ~308 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~39 ~310 ~258 ~39 ~322 minecraft:redstone_wire replace
setblock ~186 ~39 ~312 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~39 ~314 ~186 ~39 ~320 minecraft:redstone_wire replace
setblock ~324 ~39 ~314 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~316 ~324 ~39 ~328 minecraft:redstone_wire replace
setblock ~348 ~39 ~316 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~318 ~315 ~39 ~330 minecraft:redstone_wire replace
fill ~318 ~39 ~318 ~318 ~39 ~330 minecraft:redstone_wire replace
setblock ~333 ~39 ~318 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~318 ~348 ~39 ~330 minecraft:redstone_wire replace
fill ~255 ~39 ~320 ~255 ~39 ~324 minecraft:redstone_wire replace
setblock ~330 ~39 ~320 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~320 ~333 ~39 ~332 minecraft:redstone_wire replace
fill ~330 ~39 ~322 ~330 ~39 ~334 minecraft:redstone_wire replace
setblock ~201 ~39 ~324 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~258 ~39 ~324 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~39 ~326 ~201 ~39 ~336 minecraft:redstone_wire replace
fill ~258 ~39 ~326 ~258 ~39 ~338 minecraft:redstone_wire replace
fill ~222 ~39 ~328 ~222 ~39 ~332 minecraft:redstone_wire replace
setblock ~324 ~39 ~330 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~39 ~332 ~279 ~39 ~336 minecraft:redstone_wire replace
setblock ~315 ~39 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~332 ~324 ~39 ~344 minecraft:redstone_wire replace
setblock ~348 ~39 ~332 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~334 ~315 ~39 ~346 minecraft:redstone_wire replace
fill ~318 ~39 ~334 ~318 ~39 ~346 minecraft:redstone_wire replace
setblock ~333 ~39 ~334 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~334 ~348 ~39 ~346 minecraft:redstone_wire replace
setblock ~330 ~39 ~336 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~39 ~336 ~333 ~39 ~348 minecraft:redstone_wire replace
fill ~330 ~39 ~338 ~330 ~39 ~350 minecraft:redstone_wire replace
setblock ~258 ~39 ~339 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~225 ~39 ~340 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~39 ~340 ~258 ~39 ~352 minecraft:redstone_wire replace
fill ~225 ~39 ~342 ~225 ~39 ~352 minecraft:redstone_wire replace
fill ~261 ~39 ~344 ~261 ~39 ~348 minecraft:redstone_wire replace
setblock ~324 ~39 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~39 ~348 ~297 ~39 ~352 minecraft:redstone_wire replace
setblock ~315 ~39 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~39 ~348 ~324 ~39 ~360 minecraft:redstone_wire replace
setblock ~348 ~39 ~348 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~350 ~315 ~39 ~362 minecraft:redstone_wire replace
fill ~318 ~39 ~350 ~318 ~39 ~362 minecraft:redstone_wire replace
setblock ~333 ~39 ~350 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~350 ~348 ~39 ~362 minecraft:redstone_wire replace
setblock ~330 ~39 ~351 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~39 ~352 ~330 ~39 ~364 minecraft:redstone_wire replace
fill ~333 ~39 ~352 ~333 ~39 ~364 minecraft:redstone_wire replace
setblock ~264 ~39 ~356 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~39 ~358 ~264 ~39 ~364 minecraft:redstone_wire replace
fill ~321 ~39 ~360 ~321 ~39 ~364 minecraft:redstone_wire replace
setblock ~324 ~39 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~315 ~39 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~318 ~39 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~39 ~364 ~315 ~39 ~376 minecraft:redstone_wire replace
fill ~318 ~39 ~364 ~318 ~39 ~376 minecraft:redstone_wire replace
fill ~324 ~39 ~364 ~324 ~39 ~376 minecraft:redstone_wire replace
setblock ~336 ~39 ~364 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~348 ~39 ~364 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~336 ~39 ~366 ~336 ~39 ~372 minecraft:redstone_wire replace
fill ~348 ~39 ~366 ~348 ~39 ~378 minecraft:redstone_wire replace
setblock ~339 ~39 ~368 minecraft:redstone_wire replace
setblock ~339 ~39 ~370 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~39 ~372 ~312 ~39 ~376 minecraft:redstone_wire replace
fill ~339 ~39 ~372 ~339 ~39 ~384 minecraft:redstone_wire replace
fill ~327 ~39 ~376 ~327 ~39 ~380 minecraft:redstone_wire replace
setblock ~348 ~39 ~380 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~382 ~348 ~39 ~394 minecraft:redstone_wire replace
setblock ~285 ~39 ~384 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~39 ~386 ~285 ~39 ~392 minecraft:redstone_wire replace
fill ~363 ~39 ~388 ~363 ~39 ~392 minecraft:redstone_wire replace
setblock ~384 ~39 ~392 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~384 ~39 ~394 ~384 ~39 ~400 minecraft:redstone_wire replace
setblock ~348 ~39 ~395 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~39 ~396 ~348 ~39 ~408 minecraft:redstone_wire replace
setblock ~351 ~39 ~396 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~351 ~39 ~398 ~351 ~39 ~404 minecraft:redstone_wire replace
setblock ~375 ~39 ~400 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~375 ~39 ~402 ~375 ~39 ~412 minecraft:redstone_wire replace
fill ~345 ~39 ~404 ~345 ~39 ~408 minecraft:redstone_wire replace
fill ~90 ~39 ~412 ~90 ~39 ~416 minecraft:redstone_wire replace
fill ~117 ~39 ~416 ~117 ~39 ~420 minecraft:redstone_wire replace
fill ~144 ~39 ~420 ~144 ~39 ~424 minecraft:redstone_wire replace
fill ~192 ~39 ~424 ~192 ~39 ~428 minecraft:redstone_wire replace
fill ~213 ~39 ~428 ~213 ~39 ~432 minecraft:redstone_wire replace
fill ~237 ~39 ~432 ~237 ~39 ~436 minecraft:redstone_wire replace
fill ~282 ~39 ~436 ~282 ~39 ~440 minecraft:redstone_wire replace
fill ~306 ~39 ~440 ~306 ~39 ~444 minecraft:redstone_wire replace
fill ~342 ~39 ~444 ~342 ~39 ~448 minecraft:redstone_wire replace
fill ~87 ~39 ~448 ~87 ~39 ~452 minecraft:redstone_wire replace
fill ~114 ~39 ~452 ~114 ~39 ~456 minecraft:redstone_wire replace
fill ~141 ~39 ~456 ~141 ~39 ~460 minecraft:redstone_wire replace
fill ~189 ~39 ~460 ~189 ~39 ~464 minecraft:redstone_wire replace
fill ~210 ~39 ~464 ~210 ~39 ~468 minecraft:redstone_wire replace
fill ~234 ~39 ~468 ~234 ~39 ~472 minecraft:redstone_wire replace
fill ~276 ~39 ~472 ~276 ~39 ~476 minecraft:redstone_wire replace
fill ~303 ~39 ~476 ~303 ~39 ~480 minecraft:redstone_wire replace
fill ~366 ~39 ~480 ~366 ~39 ~484 minecraft:redstone_wire replace
fill ~390 ~39 ~484 ~390 ~39 ~488 minecraft:redstone_wire replace
fill ~84 ~39 ~488 ~84 ~39 ~492 minecraft:redstone_wire replace
fill ~111 ~39 ~492 ~111 ~39 ~496 minecraft:redstone_wire replace
fill ~138 ~39 ~496 ~138 ~39 ~500 minecraft:redstone_wire replace
fill ~171 ~39 ~500 ~171 ~39 ~504 minecraft:redstone_wire replace
fill ~207 ~39 ~504 ~207 ~39 ~508 minecraft:redstone_wire replace
fill ~231 ~39 ~508 ~231 ~39 ~512 minecraft:redstone_wire replace
fill ~273 ~39 ~512 ~273 ~39 ~516 minecraft:redstone_wire replace
fill ~300 ~39 ~516 ~300 ~39 ~520 minecraft:redstone_wire replace
fill ~360 ~39 ~520 ~360 ~39 ~524 minecraft:redstone_wire replace
fill ~387 ~39 ~524 ~387 ~39 ~528 minecraft:redstone_wire replace
fill ~81 ~39 ~528 ~81 ~39 ~532 minecraft:redstone_wire replace
fill ~108 ~39 ~532 ~108 ~39 ~536 minecraft:redstone_wire replace
fill ~135 ~39 ~536 ~135 ~39 ~540 minecraft:redstone_wire replace
fill ~165 ~39 ~540 ~165 ~39 ~544 minecraft:redstone_wire replace
fill ~204 ~39 ~544 ~204 ~39 ~548 minecraft:redstone_wire replace
fill ~228 ~39 ~548 ~228 ~39 ~552 minecraft:redstone_wire replace
fill ~270 ~39 ~552 ~270 ~39 ~556 minecraft:redstone_wire replace
fill ~291 ~39 ~556 ~291 ~39 ~560 minecraft:redstone_wire replace
fill ~357 ~39 ~560 ~357 ~39 ~564 minecraft:redstone_wire replace
fill ~381 ~39 ~564 ~381 ~39 ~568 minecraft:redstone_wire replace
fill ~78 ~39 ~568 ~78 ~39 ~572 minecraft:redstone_wire replace
fill ~105 ~39 ~572 ~105 ~39 ~576 minecraft:redstone_wire replace
fill ~132 ~39 ~576 ~132 ~39 ~580 minecraft:redstone_wire replace
fill ~162 ~39 ~580 ~162 ~39 ~584 minecraft:redstone_wire replace
fill ~198 ~39 ~584 ~198 ~39 ~588 minecraft:redstone_wire replace
fill ~219 ~39 ~588 ~219 ~39 ~592 minecraft:redstone_wire replace
fill ~267 ~39 ~592 ~267 ~39 ~596 minecraft:redstone_wire replace
fill ~288 ~39 ~596 ~288 ~39 ~600 minecraft:redstone_wire replace
fill ~354 ~39 ~600 ~354 ~39 ~604 minecraft:redstone_wire replace
fill ~378 ~39 ~604 ~378 ~39 ~608 minecraft:redstone_wire replace
fill ~102 ~39 ~608 ~102 ~39 ~612 minecraft:redstone_wire replace
fill ~129 ~39 ~612 ~129 ~39 ~616 minecraft:redstone_wire replace
fill ~159 ~39 ~616 ~159 ~39 ~620 minecraft:redstone_wire replace
fill ~195 ~39 ~620 ~195 ~39 ~624 minecraft:redstone_wire replace
fill ~216 ~39 ~624 ~216 ~39 ~628 minecraft:redstone_wire replace
fill ~240 ~39 ~628 ~240 ~39 ~632 minecraft:redstone_wire replace
fill ~294 ~39 ~632 ~294 ~39 ~636 minecraft:redstone_wire replace
fill ~309 ~39 ~636 ~309 ~39 ~640 minecraft:redstone_wire replace
fill ~369 ~39 ~640 ~369 ~39 ~644 minecraft:redstone_wire replace
fill ~168 ~39 ~644 ~168 ~39 ~648 minecraft:redstone_wire replace
fill ~396 ~39 ~648 ~396 ~39 ~652 minecraft:redstone_wire replace
fill ~99 ~39 ~652 ~99 ~39 ~656 minecraft:redstone_wire replace
fill ~372 ~39 ~656 ~372 ~39 ~660 minecraft:redstone_wire replace
fill ~393 ~39 ~660 ~393 ~39 ~664 minecraft:redstone_wire replace
setblock ~243 ~40 ~3 minecraft:redstone_wire replace
setblock ~174 ~40 ~7 minecraft:redstone_wire replace
setblock ~147 ~40 ~11 minecraft:redstone_wire replace
setblock ~246 ~40 ~15 minecraft:redstone_wire replace
setblock ~177 ~40 ~19 minecraft:redstone_wire replace
setblock ~249 ~40 ~27 minecraft:redstone_wire replace
setblock ~330 ~40 ~35 minecraft:redstone_wire replace
setblock ~315 ~40 ~39 minecraft:redstone_wire replace
setblock ~258 ~40 ~43 minecraft:redstone_wire replace
setblock ~333 ~40 ~47 minecraft:redstone_wire replace
setblock ~318 ~40 ~51 minecraft:redstone_wire replace
setblock ~324 ~40 ~59 minecraft:redstone_wire replace
setblock ~348 ~40 ~75 minecraft:redstone_wire replace
setblock ~93 ~40 ~247 minecraft:redstone_wire replace
setblock ~123 ~40 ~251 minecraft:redstone_wire replace
setblock ~252 ~40 ~255 minecraft:redstone_wire replace
setblock ~183 ~40 ~259 minecraft:redstone_wire replace
setblock ~153 ~40 ~263 minecraft:redstone_wire replace
setblock ~126 ~40 ~267 minecraft:redstone_wire replace
setblock ~96 ~40 ~275 minecraft:redstone_wire replace
setblock ~120 ~40 ~279 minecraft:redstone_wire replace
setblock ~150 ~40 ~283 minecraft:redstone_wire replace
setblock ~156 ~40 ~295 minecraft:redstone_wire replace
setblock ~180 ~40 ~299 minecraft:redstone_wire replace
setblock ~186 ~40 ~311 minecraft:redstone_wire replace
setblock ~255 ~40 ~319 minecraft:redstone_wire replace
setblock ~201 ~40 ~323 minecraft:redstone_wire replace
setblock ~222 ~40 ~327 minecraft:redstone_wire replace
setblock ~279 ~40 ~331 minecraft:redstone_wire replace
setblock ~225 ~40 ~339 minecraft:redstone_wire replace
setblock ~261 ~40 ~343 minecraft:redstone_wire replace
setblock ~297 ~40 ~347 minecraft:redstone_wire replace
setblock ~264 ~40 ~355 minecraft:redstone_wire replace
setblock ~321 ~40 ~359 minecraft:redstone_wire replace
setblock ~336 ~40 ~363 minecraft:redstone_wire replace
setblock ~339 ~40 ~367 minecraft:redstone_wire replace
setblock ~312 ~40 ~371 minecraft:redstone_wire replace
setblock ~327 ~40 ~375 minecraft:redstone_wire replace
setblock ~285 ~40 ~383 minecraft:redstone_wire replace
setblock ~363 ~40 ~387 minecraft:redstone_wire replace
setblock ~384 ~40 ~391 minecraft:redstone_wire replace
setblock ~351 ~40 ~395 minecraft:redstone_wire replace
setblock ~375 ~40 ~399 minecraft:redstone_wire replace
setblock ~345 ~40 ~403 minecraft:redstone_wire replace
setblock ~90 ~40 ~411 minecraft:redstone_wire replace
setblock ~117 ~40 ~415 minecraft:redstone_wire replace
setblock ~144 ~40 ~419 minecraft:redstone_wire replace
setblock ~192 ~40 ~423 minecraft:redstone_wire replace
setblock ~213 ~40 ~427 minecraft:redstone_wire replace
setblock ~237 ~40 ~431 minecraft:redstone_wire replace
setblock ~282 ~40 ~435 minecraft:redstone_wire replace
setblock ~306 ~40 ~439 minecraft:redstone_wire replace
setblock ~342 ~40 ~443 minecraft:redstone_wire replace
setblock ~87 ~40 ~447 minecraft:redstone_wire replace
setblock ~114 ~40 ~451 minecraft:redstone_wire replace
setblock ~141 ~40 ~455 minecraft:redstone_wire replace
setblock ~189 ~40 ~459 minecraft:redstone_wire replace
setblock ~210 ~40 ~463 minecraft:redstone_wire replace
setblock ~234 ~40 ~467 minecraft:redstone_wire replace
setblock ~276 ~40 ~471 minecraft:redstone_wire replace
setblock ~303 ~40 ~475 minecraft:redstone_wire replace
setblock ~366 ~40 ~479 minecraft:redstone_wire replace
setblock ~390 ~40 ~483 minecraft:redstone_wire replace
setblock ~84 ~40 ~487 minecraft:redstone_wire replace
setblock ~111 ~40 ~491 minecraft:redstone_wire replace
setblock ~138 ~40 ~495 minecraft:redstone_wire replace
setblock ~171 ~40 ~499 minecraft:redstone_wire replace
setblock ~207 ~40 ~503 minecraft:redstone_wire replace
setblock ~231 ~40 ~507 minecraft:redstone_wire replace
setblock ~273 ~40 ~511 minecraft:redstone_wire replace
setblock ~300 ~40 ~515 minecraft:redstone_wire replace
setblock ~360 ~40 ~519 minecraft:redstone_wire replace
setblock ~387 ~40 ~523 minecraft:redstone_wire replace
setblock ~81 ~40 ~527 minecraft:redstone_wire replace
setblock ~108 ~40 ~531 minecraft:redstone_wire replace
setblock ~135 ~40 ~535 minecraft:redstone_wire replace
setblock ~165 ~40 ~539 minecraft:redstone_wire replace
setblock ~204 ~40 ~543 minecraft:redstone_wire replace
setblock ~228 ~40 ~547 minecraft:redstone_wire replace
setblock ~270 ~40 ~551 minecraft:redstone_wire replace
setblock ~291 ~40 ~555 minecraft:redstone_wire replace
setblock ~357 ~40 ~559 minecraft:redstone_wire replace
setblock ~381 ~40 ~563 minecraft:redstone_wire replace
setblock ~78 ~40 ~567 minecraft:redstone_wire replace
setblock ~105 ~40 ~571 minecraft:redstone_wire replace
setblock ~132 ~40 ~575 minecraft:redstone_wire replace
setblock ~162 ~40 ~579 minecraft:redstone_wire replace
setblock ~198 ~40 ~583 minecraft:redstone_wire replace
setblock ~219 ~40 ~587 minecraft:redstone_wire replace
setblock ~267 ~40 ~591 minecraft:redstone_wire replace
setblock ~288 ~40 ~595 minecraft:redstone_wire replace
setblock ~354 ~40 ~599 minecraft:redstone_wire replace
setblock ~378 ~40 ~603 minecraft:redstone_wire replace
setblock ~102 ~40 ~607 minecraft:redstone_wire replace
setblock ~129 ~40 ~611 minecraft:redstone_wire replace
setblock ~159 ~40 ~615 minecraft:redstone_wire replace
setblock ~195 ~40 ~619 minecraft:redstone_wire replace
setblock ~216 ~40 ~623 minecraft:redstone_wire replace
setblock ~240 ~40 ~627 minecraft:redstone_wire replace
setblock ~294 ~40 ~631 minecraft:redstone_wire replace
setblock ~309 ~40 ~635 minecraft:redstone_wire replace
setblock ~369 ~40 ~639 minecraft:redstone_wire replace
setblock ~168 ~40 ~643 minecraft:redstone_wire replace
setblock ~396 ~40 ~647 minecraft:redstone_wire replace
setblock ~99 ~40 ~651 minecraft:redstone_wire replace
setblock ~372 ~40 ~655 minecraft:redstone_wire replace
setblock ~393 ~40 ~659 minecraft:redstone_wire replace
setblock ~226 ~41 ~1 minecraft:redstone_wire replace
fill ~225 ~41 ~2 ~228 ~41 ~2 minecraft:redstone_wire replace
setblock ~230 ~41 ~2 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~41 ~2 ~243 ~41 ~2 minecraft:redstone_wire replace
setblock ~166 ~41 ~5 minecraft:redstone_wire replace
fill ~165 ~41 ~6 ~174 ~41 ~6 minecraft:redstone_wire replace
setblock ~145 ~41 ~9 minecraft:redstone_wire replace
fill ~144 ~41 ~10 ~147 ~41 ~10 minecraft:redstone_wire replace
setblock ~226 ~41 ~13 minecraft:redstone_wire replace
fill ~225 ~41 ~14 ~233 ~41 ~14 minecraft:redstone_wire replace
setblock ~235 ~41 ~14 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~237 ~41 ~14 ~246 ~41 ~14 minecraft:redstone_wire replace
setblock ~166 ~41 ~17 minecraft:redstone_wire replace
fill ~165 ~41 ~18 ~167 ~41 ~18 minecraft:redstone_wire replace
setblock ~169 ~41 ~18 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~41 ~18 ~177 ~41 ~18 minecraft:redstone_wire replace
setblock ~226 ~41 ~25 minecraft:redstone_wire replace
setblock ~225 ~41 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~226 ~41 ~26 ~239 ~41 ~26 minecraft:redstone_wire replace
setblock ~241 ~41 ~26 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~243 ~41 ~26 ~249 ~41 ~26 minecraft:redstone_wire replace
setblock ~301 ~41 ~33 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~300 ~41 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~301 ~41 ~34 ~314 ~41 ~34 minecraft:redstone_wire replace
setblock ~316 ~41 ~34 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~318 ~41 ~34 ~330 ~41 ~34 minecraft:redstone_wire replace
setblock ~286 ~41 ~37 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~285 ~41 ~38 ~287 ~41 ~38 minecraft:redstone_wire replace
setblock ~288 ~41 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~41 ~38 ~302 ~41 ~38 minecraft:redstone_wire replace
setblock ~304 ~41 ~38 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~41 ~38 ~315 ~41 ~38 minecraft:redstone_wire replace
setblock ~229 ~41 ~41 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~228 ~41 ~42 ~232 ~41 ~42 minecraft:redstone_wire replace
setblock ~234 ~41 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~236 ~41 ~42 ~249 ~41 ~42 minecraft:redstone_wire replace
setblock ~251 ~41 ~42 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~41 ~42 ~258 ~41 ~42 minecraft:redstone_wire replace
setblock ~304 ~41 ~45 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~303 ~41 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~41 ~46 ~317 ~41 ~46 minecraft:redstone_wire replace
setblock ~319 ~41 ~46 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~41 ~46 ~333 ~41 ~46 minecraft:redstone_wire replace
setblock ~289 ~41 ~49 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~288 ~41 ~50 ~292 ~41 ~50 minecraft:redstone_wire replace
setblock ~294 ~41 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~296 ~41 ~50 ~309 ~41 ~50 minecraft:redstone_wire replace
setblock ~311 ~41 ~50 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~41 ~50 ~318 ~41 ~50 minecraft:redstone_wire replace
setblock ~295 ~41 ~57 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~294 ~41 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~295 ~41 ~58 ~308 ~41 ~58 minecraft:redstone_wire replace
setblock ~310 ~41 ~58 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~312 ~41 ~58 ~324 ~41 ~58 minecraft:redstone_wire replace
setblock ~319 ~41 ~73 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~318 ~41 ~74 ~320 ~41 ~74 minecraft:redstone_wire replace
setblock ~321 ~41 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~41 ~74 ~334 ~41 ~74 minecraft:redstone_wire replace
setblock ~336 ~41 ~74 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~338 ~41 ~74 ~348 ~41 ~74 minecraft:redstone_wire replace
setblock ~94 ~41 ~245 minecraft:redstone_wire replace
fill ~93 ~41 ~246 ~95 ~41 ~246 minecraft:redstone_wire replace
setblock ~124 ~41 ~249 minecraft:redstone_wire replace
fill ~123 ~41 ~250 ~125 ~41 ~250 minecraft:redstone_wire replace
setblock ~226 ~41 ~253 minecraft:redstone_wire replace
fill ~225 ~41 ~254 ~226 ~41 ~254 minecraft:redstone_wire replace
setblock ~228 ~41 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~230 ~41 ~254 ~243 ~41 ~254 minecraft:redstone_wire replace
setblock ~245 ~41 ~254 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~41 ~254 ~252 ~41 ~254 minecraft:redstone_wire replace
setblock ~166 ~41 ~257 minecraft:redstone_wire replace
fill ~165 ~41 ~258 ~170 ~41 ~258 minecraft:redstone_wire replace
setblock ~172 ~41 ~258 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~41 ~258 ~183 ~41 ~258 minecraft:redstone_wire replace
setblock ~145 ~41 ~261 minecraft:redstone_wire replace
fill ~144 ~41 ~262 ~153 ~41 ~262 minecraft:redstone_wire replace
setblock ~124 ~41 ~265 minecraft:redstone_wire replace
fill ~123 ~41 ~266 ~126 ~41 ~266 minecraft:redstone_wire replace
setblock ~97 ~41 ~273 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~96 ~41 ~274 ~98 ~41 ~274 minecraft:redstone_wire replace
setblock ~121 ~41 ~277 minecraft:redstone_wire replace
fill ~120 ~41 ~278 ~122 ~41 ~278 minecraft:redstone_wire replace
setblock ~145 ~41 ~281 minecraft:redstone_wire replace
fill ~144 ~41 ~282 ~150 ~41 ~282 minecraft:redstone_wire replace
setblock ~148 ~41 ~293 minecraft:redstone_wire replace
fill ~147 ~41 ~294 ~156 ~41 ~294 minecraft:redstone_wire replace
setblock ~166 ~41 ~297 minecraft:redstone_wire replace
fill ~165 ~41 ~298 ~170 ~41 ~298 minecraft:redstone_wire replace
setblock ~172 ~41 ~298 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~41 ~298 ~180 ~41 ~298 minecraft:redstone_wire replace
setblock ~169 ~41 ~309 minecraft:redstone_wire replace
fill ~168 ~41 ~310 ~170 ~41 ~310 minecraft:redstone_wire replace
setblock ~172 ~41 ~310 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~41 ~310 ~186 ~41 ~310 minecraft:redstone_wire replace
setblock ~226 ~41 ~317 minecraft:redstone_wire replace
fill ~225 ~41 ~318 ~228 ~41 ~318 minecraft:redstone_wire replace
setblock ~230 ~41 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~232 ~41 ~318 ~245 ~41 ~318 minecraft:redstone_wire replace
setblock ~247 ~41 ~318 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~249 ~41 ~318 ~255 ~41 ~318 minecraft:redstone_wire replace
setblock ~184 ~41 ~321 minecraft:redstone_wire replace
fill ~183 ~41 ~322 ~185 ~41 ~322 minecraft:redstone_wire replace
setblock ~187 ~41 ~322 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~41 ~322 ~201 ~41 ~322 minecraft:redstone_wire replace
setblock ~205 ~41 ~325 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~204 ~41 ~326 ~212 ~41 ~326 minecraft:redstone_wire replace
setblock ~214 ~41 ~326 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~216 ~41 ~326 ~222 ~41 ~326 minecraft:redstone_wire replace
setblock ~250 ~41 ~329 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~249 ~41 ~330 ~252 ~41 ~330 minecraft:redstone_wire replace
setblock ~254 ~41 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~41 ~330 ~269 ~41 ~330 minecraft:redstone_wire replace
setblock ~271 ~41 ~330 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~41 ~330 ~279 ~41 ~330 minecraft:redstone_wire replace
setblock ~208 ~41 ~337 minecraft:redstone_wire replace
fill ~207 ~41 ~338 ~209 ~41 ~338 minecraft:redstone_wire replace
setblock ~211 ~41 ~338 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~41 ~338 ~225 ~41 ~338 minecraft:redstone_wire replace
setblock ~232 ~41 ~341 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~231 ~41 ~342 ~234 ~41 ~342 minecraft:redstone_wire replace
setblock ~236 ~41 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~238 ~41 ~342 ~251 ~41 ~342 minecraft:redstone_wire replace
setblock ~253 ~41 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~255 ~41 ~342 ~261 ~41 ~342 minecraft:redstone_wire replace
setblock ~268 ~41 ~345 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~267 ~41 ~346 ~270 ~41 ~346 minecraft:redstone_wire replace
setblock ~272 ~41 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~274 ~41 ~346 ~287 ~41 ~346 minecraft:redstone_wire replace
setblock ~289 ~41 ~346 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~291 ~41 ~346 ~297 ~41 ~346 minecraft:redstone_wire replace
setblock ~235 ~41 ~353 minecraft:redstone_wire replace
setblock ~234 ~41 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~235 ~41 ~354 ~248 ~41 ~354 minecraft:redstone_wire replace
setblock ~250 ~41 ~354 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~252 ~41 ~354 ~264 ~41 ~354 minecraft:redstone_wire replace
setblock ~292 ~41 ~357 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~291 ~41 ~358 ~294 ~41 ~358 minecraft:redstone_wire replace
setblock ~296 ~41 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~298 ~41 ~358 ~311 ~41 ~358 minecraft:redstone_wire replace
setblock ~313 ~41 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~315 ~41 ~358 ~321 ~41 ~358 minecraft:redstone_wire replace
setblock ~307 ~41 ~361 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~306 ~41 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~307 ~41 ~362 ~320 ~41 ~362 minecraft:redstone_wire replace
setblock ~322 ~41 ~362 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~324 ~41 ~362 ~336 ~41 ~362 minecraft:redstone_wire replace
setblock ~310 ~41 ~365 minecraft:redstone_wire replace
fill ~309 ~41 ~366 ~311 ~41 ~366 minecraft:redstone_wire replace
setblock ~312 ~41 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~313 ~41 ~366 ~325 ~41 ~366 minecraft:redstone_wire replace
setblock ~327 ~41 ~366 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~329 ~41 ~366 ~339 ~41 ~366 minecraft:redstone_wire replace
setblock ~283 ~41 ~369 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~282 ~41 ~370 ~285 ~41 ~370 minecraft:redstone_wire replace
setblock ~287 ~41 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~289 ~41 ~370 ~302 ~41 ~370 minecraft:redstone_wire replace
setblock ~304 ~41 ~370 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~306 ~41 ~370 ~312 ~41 ~370 minecraft:redstone_wire replace
setblock ~298 ~41 ~373 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~297 ~41 ~374 ~300 ~41 ~374 minecraft:redstone_wire replace
setblock ~302 ~41 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~304 ~41 ~374 ~317 ~41 ~374 minecraft:redstone_wire replace
setblock ~319 ~41 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~321 ~41 ~374 ~327 ~41 ~374 minecraft:redstone_wire replace
setblock ~256 ~41 ~381 minecraft:redstone_wire replace
setblock ~255 ~41 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~256 ~41 ~382 ~269 ~41 ~382 minecraft:redstone_wire replace
setblock ~271 ~41 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~273 ~41 ~382 ~285 ~41 ~382 minecraft:redstone_wire replace
setblock ~334 ~41 ~385 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~333 ~41 ~386 ~336 ~41 ~386 minecraft:redstone_wire replace
setblock ~338 ~41 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~340 ~41 ~386 ~353 ~41 ~386 minecraft:redstone_wire replace
setblock ~355 ~41 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~357 ~41 ~386 ~363 ~41 ~386 minecraft:redstone_wire replace
setblock ~355 ~41 ~389 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~354 ~41 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~355 ~41 ~390 ~368 ~41 ~390 minecraft:redstone_wire replace
setblock ~370 ~41 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~372 ~41 ~390 ~384 ~41 ~390 minecraft:redstone_wire replace
setblock ~322 ~41 ~393 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~321 ~41 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~41 ~394 ~335 ~41 ~394 minecraft:redstone_wire replace
setblock ~337 ~41 ~394 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~41 ~394 ~351 ~41 ~394 minecraft:redstone_wire replace
setblock ~346 ~41 ~397 minecraft:redstone_wire replace
setblock ~345 ~41 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~41 ~398 ~359 ~41 ~398 minecraft:redstone_wire replace
setblock ~361 ~41 ~398 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~41 ~398 ~375 ~41 ~398 minecraft:redstone_wire replace
setblock ~316 ~41 ~401 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~315 ~41 ~402 ~318 ~41 ~402 minecraft:redstone_wire replace
setblock ~320 ~41 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~322 ~41 ~402 ~335 ~41 ~402 minecraft:redstone_wire replace
setblock ~337 ~41 ~402 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~339 ~41 ~402 ~345 ~41 ~402 minecraft:redstone_wire replace
setblock ~91 ~41 ~409 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~90 ~41 ~410 ~92 ~41 ~410 minecraft:redstone_wire replace
setblock ~118 ~41 ~413 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~117 ~41 ~414 ~119 ~41 ~414 minecraft:redstone_wire replace
setblock ~142 ~41 ~417 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~141 ~41 ~418 ~144 ~41 ~418 minecraft:redstone_wire replace
setblock ~175 ~41 ~421 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~174 ~41 ~422 ~182 ~41 ~422 minecraft:redstone_wire replace
setblock ~184 ~41 ~422 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~41 ~422 ~192 ~41 ~422 minecraft:redstone_wire replace
setblock ~196 ~41 ~425 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~195 ~41 ~426 ~203 ~41 ~426 minecraft:redstone_wire replace
setblock ~205 ~41 ~426 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~207 ~41 ~426 ~213 ~41 ~426 minecraft:redstone_wire replace
setblock ~220 ~41 ~429 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~219 ~41 ~430 ~227 ~41 ~430 minecraft:redstone_wire replace
setblock ~229 ~41 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~231 ~41 ~430 ~237 ~41 ~430 minecraft:redstone_wire replace
setblock ~253 ~41 ~433 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~252 ~41 ~434 ~255 ~41 ~434 minecraft:redstone_wire replace
setblock ~257 ~41 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~259 ~41 ~434 ~272 ~41 ~434 minecraft:redstone_wire replace
setblock ~274 ~41 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~276 ~41 ~434 ~282 ~41 ~434 minecraft:redstone_wire replace
setblock ~277 ~41 ~437 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~276 ~41 ~438 ~279 ~41 ~438 minecraft:redstone_wire replace
setblock ~281 ~41 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~283 ~41 ~438 ~296 ~41 ~438 minecraft:redstone_wire replace
setblock ~298 ~41 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~300 ~41 ~438 ~306 ~41 ~438 minecraft:redstone_wire replace
setblock ~313 ~41 ~441 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~312 ~41 ~442 ~315 ~41 ~442 minecraft:redstone_wire replace
setblock ~317 ~41 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~319 ~41 ~442 ~332 ~41 ~442 minecraft:redstone_wire replace
setblock ~334 ~41 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~336 ~41 ~442 ~342 ~41 ~442 minecraft:redstone_wire replace
setblock ~88 ~41 ~445 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~87 ~41 ~446 ~89 ~41 ~446 minecraft:redstone_wire replace
setblock ~115 ~41 ~449 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~114 ~41 ~450 ~116 ~41 ~450 minecraft:redstone_wire replace
setblock ~139 ~41 ~453 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~138 ~41 ~454 ~141 ~41 ~454 minecraft:redstone_wire replace
setblock ~172 ~41 ~457 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~171 ~41 ~458 ~179 ~41 ~458 minecraft:redstone_wire replace
setblock ~181 ~41 ~458 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~183 ~41 ~458 ~189 ~41 ~458 minecraft:redstone_wire replace
setblock ~193 ~41 ~461 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~192 ~41 ~462 ~200 ~41 ~462 minecraft:redstone_wire replace
setblock ~202 ~41 ~462 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~204 ~41 ~462 ~210 ~41 ~462 minecraft:redstone_wire replace
setblock ~217 ~41 ~465 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~216 ~41 ~466 ~224 ~41 ~466 minecraft:redstone_wire replace
setblock ~226 ~41 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~228 ~41 ~466 ~234 ~41 ~466 minecraft:redstone_wire replace
setblock ~247 ~41 ~469 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~246 ~41 ~470 ~249 ~41 ~470 minecraft:redstone_wire replace
setblock ~251 ~41 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~253 ~41 ~470 ~266 ~41 ~470 minecraft:redstone_wire replace
setblock ~268 ~41 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~270 ~41 ~470 ~276 ~41 ~470 minecraft:redstone_wire replace
setblock ~274 ~41 ~473 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~273 ~41 ~474 ~276 ~41 ~474 minecraft:redstone_wire replace
setblock ~278 ~41 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~280 ~41 ~474 ~293 ~41 ~474 minecraft:redstone_wire replace
setblock ~295 ~41 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~297 ~41 ~474 ~303 ~41 ~474 minecraft:redstone_wire replace
setblock ~337 ~41 ~477 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~336 ~41 ~478 ~339 ~41 ~478 minecraft:redstone_wire replace
setblock ~341 ~41 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~343 ~41 ~478 ~356 ~41 ~478 minecraft:redstone_wire replace
setblock ~358 ~41 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~360 ~41 ~478 ~366 ~41 ~478 minecraft:redstone_wire replace
setblock ~361 ~41 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~360 ~41 ~482 ~363 ~41 ~482 minecraft:redstone_wire replace
setblock ~365 ~41 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~367 ~41 ~482 ~380 ~41 ~482 minecraft:redstone_wire replace
setblock ~382 ~41 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~384 ~41 ~482 ~390 ~41 ~482 minecraft:redstone_wire replace
setblock ~85 ~41 ~485 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~84 ~41 ~486 ~86 ~41 ~486 minecraft:redstone_wire replace
setblock ~112 ~41 ~489 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~111 ~41 ~490 ~113 ~41 ~490 minecraft:redstone_wire replace
setblock ~136 ~41 ~493 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~135 ~41 ~494 ~138 ~41 ~494 minecraft:redstone_wire replace
setblock ~163 ~41 ~497 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~162 ~41 ~498 ~163 ~41 ~498 minecraft:redstone_wire replace
setblock ~164 ~41 ~498 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~41 ~498 ~171 ~41 ~498 minecraft:redstone_wire replace
setblock ~190 ~41 ~501 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~41 ~502 ~197 ~41 ~502 minecraft:redstone_wire replace
setblock ~199 ~41 ~502 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~201 ~41 ~502 ~207 ~41 ~502 minecraft:redstone_wire replace
setblock ~214 ~41 ~505 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~213 ~41 ~506 ~221 ~41 ~506 minecraft:redstone_wire replace
setblock ~223 ~41 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~225 ~41 ~506 ~231 ~41 ~506 minecraft:redstone_wire replace
setblock ~244 ~41 ~509 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~243 ~41 ~510 ~246 ~41 ~510 minecraft:redstone_wire replace
setblock ~248 ~41 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~250 ~41 ~510 ~263 ~41 ~510 minecraft:redstone_wire replace
setblock ~265 ~41 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~267 ~41 ~510 ~273 ~41 ~510 minecraft:redstone_wire replace
setblock ~271 ~41 ~513 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~270 ~41 ~514 ~273 ~41 ~514 minecraft:redstone_wire replace
setblock ~275 ~41 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~277 ~41 ~514 ~290 ~41 ~514 minecraft:redstone_wire replace
setblock ~292 ~41 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~294 ~41 ~514 ~300 ~41 ~514 minecraft:redstone_wire replace
setblock ~331 ~41 ~517 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~330 ~41 ~518 ~333 ~41 ~518 minecraft:redstone_wire replace
setblock ~335 ~41 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~337 ~41 ~518 ~350 ~41 ~518 minecraft:redstone_wire replace
setblock ~352 ~41 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~354 ~41 ~518 ~360 ~41 ~518 minecraft:redstone_wire replace
setblock ~358 ~41 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~357 ~41 ~522 ~360 ~41 ~522 minecraft:redstone_wire replace
setblock ~362 ~41 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~364 ~41 ~522 ~377 ~41 ~522 minecraft:redstone_wire replace
setblock ~379 ~41 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~381 ~41 ~522 ~387 ~41 ~522 minecraft:redstone_wire replace
setblock ~82 ~41 ~525 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~41 ~526 ~83 ~41 ~526 minecraft:redstone_wire replace
setblock ~109 ~41 ~529 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~108 ~41 ~530 ~110 ~41 ~530 minecraft:redstone_wire replace
setblock ~133 ~41 ~533 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~132 ~41 ~534 ~135 ~41 ~534 minecraft:redstone_wire replace
setblock ~157 ~41 ~537 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~156 ~41 ~538 ~157 ~41 ~538 minecraft:redstone_wire replace
setblock ~158 ~41 ~538 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~41 ~538 ~165 ~41 ~538 minecraft:redstone_wire replace
setblock ~187 ~41 ~541 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~41 ~542 ~194 ~41 ~542 minecraft:redstone_wire replace
setblock ~196 ~41 ~542 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~41 ~542 ~204 ~41 ~542 minecraft:redstone_wire replace
setblock ~211 ~41 ~545 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~210 ~41 ~546 ~218 ~41 ~546 minecraft:redstone_wire replace
setblock ~220 ~41 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~222 ~41 ~546 ~228 ~41 ~546 minecraft:redstone_wire replace
setblock ~241 ~41 ~549 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~240 ~41 ~550 ~243 ~41 ~550 minecraft:redstone_wire replace
setblock ~245 ~41 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~247 ~41 ~550 ~260 ~41 ~550 minecraft:redstone_wire replace
setblock ~262 ~41 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~264 ~41 ~550 ~270 ~41 ~550 minecraft:redstone_wire replace
setblock ~262 ~41 ~553 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~261 ~41 ~554 ~264 ~41 ~554 minecraft:redstone_wire replace
setblock ~266 ~41 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~268 ~41 ~554 ~281 ~41 ~554 minecraft:redstone_wire replace
setblock ~283 ~41 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~285 ~41 ~554 ~291 ~41 ~554 minecraft:redstone_wire replace
setblock ~328 ~41 ~557 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~327 ~41 ~558 ~330 ~41 ~558 minecraft:redstone_wire replace
setblock ~332 ~41 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~334 ~41 ~558 ~347 ~41 ~558 minecraft:redstone_wire replace
setblock ~349 ~41 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~351 ~41 ~558 ~357 ~41 ~558 minecraft:redstone_wire replace
setblock ~352 ~41 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~351 ~41 ~562 ~354 ~41 ~562 minecraft:redstone_wire replace
setblock ~356 ~41 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~358 ~41 ~562 ~371 ~41 ~562 minecraft:redstone_wire replace
setblock ~373 ~41 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~375 ~41 ~562 ~381 ~41 ~562 minecraft:redstone_wire replace
setblock ~79 ~41 ~565 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~78 ~41 ~566 ~80 ~41 ~566 minecraft:redstone_wire replace
setblock ~106 ~41 ~569 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~105 ~41 ~570 ~107 ~41 ~570 minecraft:redstone_wire replace
setblock ~130 ~41 ~573 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~129 ~41 ~574 ~132 ~41 ~574 minecraft:redstone_wire replace
setblock ~154 ~41 ~577 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~153 ~41 ~578 ~154 ~41 ~578 minecraft:redstone_wire replace
setblock ~155 ~41 ~578 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~156 ~41 ~578 ~162 ~41 ~578 minecraft:redstone_wire replace
setblock ~181 ~41 ~581 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~180 ~41 ~582 ~188 ~41 ~582 minecraft:redstone_wire replace
setblock ~190 ~41 ~582 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~192 ~41 ~582 ~198 ~41 ~582 minecraft:redstone_wire replace
setblock ~202 ~41 ~585 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~201 ~41 ~586 ~209 ~41 ~586 minecraft:redstone_wire replace
setblock ~211 ~41 ~586 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~213 ~41 ~586 ~219 ~41 ~586 minecraft:redstone_wire replace
setblock ~238 ~41 ~589 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~237 ~41 ~590 ~240 ~41 ~590 minecraft:redstone_wire replace
setblock ~242 ~41 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~244 ~41 ~590 ~257 ~41 ~590 minecraft:redstone_wire replace
setblock ~259 ~41 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~261 ~41 ~590 ~267 ~41 ~590 minecraft:redstone_wire replace
setblock ~259 ~41 ~593 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~258 ~41 ~594 ~261 ~41 ~594 minecraft:redstone_wire replace
setblock ~263 ~41 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~265 ~41 ~594 ~278 ~41 ~594 minecraft:redstone_wire replace
setblock ~280 ~41 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~282 ~41 ~594 ~288 ~41 ~594 minecraft:redstone_wire replace
setblock ~325 ~41 ~597 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~324 ~41 ~598 ~327 ~41 ~598 minecraft:redstone_wire replace
setblock ~329 ~41 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~331 ~41 ~598 ~344 ~41 ~598 minecraft:redstone_wire replace
setblock ~346 ~41 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~348 ~41 ~598 ~354 ~41 ~598 minecraft:redstone_wire replace
setblock ~349 ~41 ~601 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~348 ~41 ~602 ~351 ~41 ~602 minecraft:redstone_wire replace
setblock ~353 ~41 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~355 ~41 ~602 ~368 ~41 ~602 minecraft:redstone_wire replace
setblock ~370 ~41 ~602 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~372 ~41 ~602 ~378 ~41 ~602 minecraft:redstone_wire replace
setblock ~103 ~41 ~605 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~41 ~606 ~104 ~41 ~606 minecraft:redstone_wire replace
setblock ~127 ~41 ~609 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~126 ~41 ~610 ~129 ~41 ~610 minecraft:redstone_wire replace
setblock ~151 ~41 ~613 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~150 ~41 ~614 ~151 ~41 ~614 minecraft:redstone_wire replace
setblock ~152 ~41 ~614 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~41 ~614 ~159 ~41 ~614 minecraft:redstone_wire replace
setblock ~178 ~41 ~617 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~177 ~41 ~618 ~185 ~41 ~618 minecraft:redstone_wire replace
setblock ~187 ~41 ~618 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~41 ~618 ~195 ~41 ~618 minecraft:redstone_wire replace
setblock ~199 ~41 ~621 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~198 ~41 ~622 ~206 ~41 ~622 minecraft:redstone_wire replace
setblock ~208 ~41 ~622 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~210 ~41 ~622 ~216 ~41 ~622 minecraft:redstone_wire replace
setblock ~223 ~41 ~625 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~222 ~41 ~626 ~230 ~41 ~626 minecraft:redstone_wire replace
setblock ~232 ~41 ~626 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~234 ~41 ~626 ~240 ~41 ~626 minecraft:redstone_wire replace
setblock ~265 ~41 ~629 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~264 ~41 ~630 ~267 ~41 ~630 minecraft:redstone_wire replace
setblock ~269 ~41 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~271 ~41 ~630 ~284 ~41 ~630 minecraft:redstone_wire replace
setblock ~286 ~41 ~630 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~288 ~41 ~630 ~294 ~41 ~630 minecraft:redstone_wire replace
setblock ~280 ~41 ~633 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~279 ~41 ~634 ~282 ~41 ~634 minecraft:redstone_wire replace
setblock ~284 ~41 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~286 ~41 ~634 ~299 ~41 ~634 minecraft:redstone_wire replace
setblock ~301 ~41 ~634 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~303 ~41 ~634 ~309 ~41 ~634 minecraft:redstone_wire replace
setblock ~340 ~41 ~637 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~339 ~41 ~638 ~342 ~41 ~638 minecraft:redstone_wire replace
setblock ~344 ~41 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~346 ~41 ~638 ~359 ~41 ~638 minecraft:redstone_wire replace
setblock ~361 ~41 ~638 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~363 ~41 ~638 ~369 ~41 ~638 minecraft:redstone_wire replace
setblock ~160 ~41 ~641 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~159 ~41 ~642 ~160 ~41 ~642 minecraft:redstone_wire replace
setblock ~161 ~41 ~642 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~41 ~642 ~168 ~41 ~642 minecraft:redstone_wire replace
setblock ~367 ~41 ~645 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~366 ~41 ~646 ~369 ~41 ~646 minecraft:redstone_wire replace
setblock ~371 ~41 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~373 ~41 ~646 ~386 ~41 ~646 minecraft:redstone_wire replace
setblock ~388 ~41 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~390 ~41 ~646 ~396 ~41 ~646 minecraft:redstone_wire replace
setblock ~100 ~41 ~649 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~99 ~41 ~650 ~101 ~41 ~650 minecraft:redstone_wire replace
setblock ~343 ~41 ~653 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~342 ~41 ~654 ~345 ~41 ~654 minecraft:redstone_wire replace
setblock ~347 ~41 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~349 ~41 ~654 ~362 ~41 ~654 minecraft:redstone_wire replace
setblock ~364 ~41 ~654 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~366 ~41 ~654 ~372 ~41 ~654 minecraft:redstone_wire replace
setblock ~364 ~41 ~657 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~363 ~41 ~658 ~366 ~41 ~658 minecraft:redstone_wire replace
setblock ~368 ~41 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~370 ~41 ~658 ~383 ~41 ~658 minecraft:redstone_wire replace
setblock ~385 ~41 ~658 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~387 ~41 ~658 ~393 ~41 ~658 minecraft:redstone_wire replace
setblock ~226 ~42 ~0 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~4 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~42 ~8 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~12 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~16 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~24 minecraft:redstone_torch[lit=true] replace
setblock ~301 ~42 ~32 minecraft:redstone_wire replace
setblock ~286 ~42 ~36 minecraft:redstone_wire replace
setblock ~229 ~42 ~40 minecraft:redstone_wire replace
setblock ~304 ~42 ~44 minecraft:redstone_wire replace
setblock ~289 ~42 ~48 minecraft:redstone_wire replace
setblock ~295 ~42 ~56 minecraft:redstone_wire replace
setblock ~319 ~42 ~72 minecraft:redstone_wire replace
setblock ~94 ~42 ~244 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~42 ~248 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~252 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~256 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~42 ~260 minecraft:redstone_torch[lit=true] replace
setblock ~124 ~42 ~264 minecraft:redstone_torch[lit=true] replace
setblock ~97 ~42 ~272 minecraft:redstone_wire replace
setblock ~121 ~42 ~276 minecraft:redstone_torch[lit=true] replace
setblock ~145 ~42 ~280 minecraft:redstone_torch[lit=true] replace
setblock ~148 ~42 ~292 minecraft:redstone_torch[lit=true] replace
setblock ~166 ~42 ~296 minecraft:redstone_torch[lit=true] replace
setblock ~169 ~42 ~308 minecraft:redstone_torch[lit=true] replace
setblock ~226 ~42 ~316 minecraft:redstone_torch[lit=true] replace
setblock ~184 ~42 ~320 minecraft:redstone_torch[lit=true] replace
setblock ~205 ~42 ~324 minecraft:redstone_wire replace
setblock ~250 ~42 ~328 minecraft:redstone_wire replace
setblock ~208 ~42 ~336 minecraft:redstone_torch[lit=true] replace
setblock ~232 ~42 ~340 minecraft:redstone_wire replace
setblock ~268 ~42 ~344 minecraft:redstone_wire replace
setblock ~235 ~42 ~352 minecraft:redstone_torch[lit=true] replace
setblock ~292 ~42 ~356 minecraft:redstone_wire replace
setblock ~307 ~42 ~360 minecraft:redstone_wire replace
setblock ~310 ~42 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~283 ~42 ~368 minecraft:redstone_wire replace
setblock ~298 ~42 ~372 minecraft:redstone_wire replace
setblock ~256 ~42 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~334 ~42 ~384 minecraft:redstone_wire replace
setblock ~355 ~42 ~388 minecraft:redstone_wire replace
setblock ~322 ~42 ~392 minecraft:redstone_wire replace
setblock ~346 ~42 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~316 ~42 ~400 minecraft:redstone_wire replace
setblock ~91 ~42 ~408 minecraft:redstone_wire replace
setblock ~118 ~42 ~412 minecraft:redstone_wire replace
setblock ~142 ~42 ~416 minecraft:redstone_wire replace
setblock ~175 ~42 ~420 minecraft:redstone_wire replace
setblock ~196 ~42 ~424 minecraft:redstone_wire replace
setblock ~220 ~42 ~428 minecraft:redstone_wire replace
setblock ~253 ~42 ~432 minecraft:redstone_wire replace
setblock ~277 ~42 ~436 minecraft:redstone_wire replace
setblock ~313 ~42 ~440 minecraft:redstone_wire replace
setblock ~88 ~42 ~444 minecraft:redstone_wire replace
setblock ~115 ~42 ~448 minecraft:redstone_wire replace
setblock ~139 ~42 ~452 minecraft:redstone_wire replace
setblock ~172 ~42 ~456 minecraft:redstone_wire replace
setblock ~193 ~42 ~460 minecraft:redstone_wire replace
setblock ~217 ~42 ~464 minecraft:redstone_wire replace
setblock ~247 ~42 ~468 minecraft:redstone_wire replace
setblock ~274 ~42 ~472 minecraft:redstone_wire replace
setblock ~337 ~42 ~476 minecraft:redstone_wire replace
setblock ~361 ~42 ~480 minecraft:redstone_wire replace
setblock ~85 ~42 ~484 minecraft:redstone_wire replace
setblock ~112 ~42 ~488 minecraft:redstone_wire replace
setblock ~136 ~42 ~492 minecraft:redstone_wire replace
setblock ~163 ~42 ~496 minecraft:redstone_wire replace
setblock ~190 ~42 ~500 minecraft:redstone_wire replace
setblock ~214 ~42 ~504 minecraft:redstone_wire replace
setblock ~244 ~42 ~508 minecraft:redstone_wire replace
setblock ~271 ~42 ~512 minecraft:redstone_wire replace
setblock ~331 ~42 ~516 minecraft:redstone_wire replace
setblock ~358 ~42 ~520 minecraft:redstone_wire replace
setblock ~82 ~42 ~524 minecraft:redstone_wire replace
setblock ~109 ~42 ~528 minecraft:redstone_wire replace
setblock ~133 ~42 ~532 minecraft:redstone_wire replace
setblock ~157 ~42 ~536 minecraft:redstone_wire replace
setblock ~187 ~42 ~540 minecraft:redstone_wire replace
setblock ~211 ~42 ~544 minecraft:redstone_wire replace
setblock ~241 ~42 ~548 minecraft:redstone_wire replace
setblock ~262 ~42 ~552 minecraft:redstone_wire replace
setblock ~328 ~42 ~556 minecraft:redstone_wire replace
setblock ~352 ~42 ~560 minecraft:redstone_wire replace
setblock ~79 ~42 ~564 minecraft:redstone_wire replace
setblock ~106 ~42 ~568 minecraft:redstone_wire replace
setblock ~130 ~42 ~572 minecraft:redstone_wire replace
setblock ~154 ~42 ~576 minecraft:redstone_wire replace
setblock ~181 ~42 ~580 minecraft:redstone_wire replace
setblock ~202 ~42 ~584 minecraft:redstone_wire replace
setblock ~238 ~42 ~588 minecraft:redstone_wire replace
setblock ~259 ~42 ~592 minecraft:redstone_wire replace
setblock ~325 ~42 ~596 minecraft:redstone_wire replace
setblock ~349 ~42 ~600 minecraft:redstone_wire replace
setblock ~103 ~42 ~604 minecraft:redstone_wire replace
setblock ~127 ~42 ~608 minecraft:redstone_wire replace
setblock ~151 ~42 ~612 minecraft:redstone_wire replace
setblock ~178 ~42 ~616 minecraft:redstone_wire replace
setblock ~199 ~42 ~620 minecraft:redstone_wire replace
setblock ~223 ~42 ~624 minecraft:redstone_wire replace
setblock ~265 ~42 ~628 minecraft:redstone_wire replace
setblock ~280 ~42 ~632 minecraft:redstone_wire replace
setblock ~340 ~42 ~636 minecraft:redstone_wire replace
setblock ~160 ~42 ~640 minecraft:redstone_wire replace
setblock ~367 ~42 ~644 minecraft:redstone_wire replace
setblock ~100 ~42 ~648 minecraft:redstone_wire replace
setblock ~343 ~42 ~652 minecraft:redstone_wire replace
setblock ~364 ~42 ~656 minecraft:redstone_wire replace
fill ~225 ~43 ~0 ~225 ~43 ~12 minecraft:redstone_wire replace
fill ~165 ~43 ~4 ~165 ~43 ~16 minecraft:redstone_wire replace
fill ~144 ~43 ~8 ~144 ~43 ~20 minecraft:redstone_wire replace
setblock ~225 ~43 ~13 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~14 ~225 ~43 ~26 minecraft:redstone_wire replace
setblock ~165 ~43 ~17 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~18 ~165 ~43 ~30 minecraft:redstone_wire replace
setblock ~144 ~43 ~22 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~24 ~144 ~43 ~36 minecraft:redstone_wire replace
setblock ~225 ~43 ~28 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~30 ~225 ~43 ~42 minecraft:redstone_wire replace
setblock ~165 ~43 ~32 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~300 ~43 ~32 ~300 ~43 ~36 minecraft:redstone_wire replace
fill ~165 ~43 ~34 ~165 ~43 ~46 minecraft:redstone_wire replace
fill ~285 ~43 ~36 ~285 ~43 ~40 minecraft:redstone_wire replace
setblock ~144 ~43 ~38 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~40 ~144 ~43 ~52 minecraft:redstone_wire replace
fill ~228 ~43 ~40 ~228 ~43 ~44 minecraft:redstone_wire replace
setblock ~225 ~43 ~44 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~303 ~43 ~44 ~303 ~43 ~48 minecraft:redstone_wire replace
fill ~225 ~43 ~46 ~225 ~43 ~58 minecraft:redstone_wire replace
setblock ~165 ~43 ~48 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~288 ~43 ~48 ~288 ~43 ~52 minecraft:redstone_wire replace
fill ~165 ~43 ~50 ~165 ~43 ~62 minecraft:redstone_wire replace
setblock ~144 ~43 ~54 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~56 ~144 ~43 ~68 minecraft:redstone_wire replace
fill ~294 ~43 ~56 ~294 ~43 ~60 minecraft:redstone_wire replace
setblock ~225 ~43 ~60 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~62 ~225 ~43 ~74 minecraft:redstone_wire replace
setblock ~165 ~43 ~64 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~66 ~165 ~43 ~78 minecraft:redstone_wire replace
setblock ~144 ~43 ~70 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~72 ~144 ~43 ~84 minecraft:redstone_wire replace
fill ~318 ~43 ~72 ~318 ~43 ~76 minecraft:redstone_wire replace
setblock ~225 ~43 ~76 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~78 ~225 ~43 ~90 minecraft:redstone_wire replace
setblock ~165 ~43 ~80 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~82 ~165 ~43 ~94 minecraft:redstone_wire replace
setblock ~144 ~43 ~86 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~88 ~144 ~43 ~100 minecraft:redstone_wire replace
setblock ~225 ~43 ~92 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~94 ~225 ~43 ~106 minecraft:redstone_wire replace
setblock ~165 ~43 ~96 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~98 ~165 ~43 ~110 minecraft:redstone_wire replace
setblock ~144 ~43 ~102 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~104 ~144 ~43 ~116 minecraft:redstone_wire replace
setblock ~225 ~43 ~108 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~110 ~225 ~43 ~122 minecraft:redstone_wire replace
setblock ~165 ~43 ~112 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~114 ~165 ~43 ~126 minecraft:redstone_wire replace
setblock ~144 ~43 ~118 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~120 ~144 ~43 ~132 minecraft:redstone_wire replace
setblock ~225 ~43 ~124 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~126 ~225 ~43 ~138 minecraft:redstone_wire replace
setblock ~165 ~43 ~128 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~130 ~165 ~43 ~142 minecraft:redstone_wire replace
setblock ~144 ~43 ~134 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~136 ~144 ~43 ~148 minecraft:redstone_wire replace
setblock ~225 ~43 ~140 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~142 ~225 ~43 ~154 minecraft:redstone_wire replace
setblock ~165 ~43 ~144 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~146 ~165 ~43 ~158 minecraft:redstone_wire replace
setblock ~144 ~43 ~150 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~152 ~144 ~43 ~164 minecraft:redstone_wire replace
setblock ~225 ~43 ~156 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~158 ~225 ~43 ~170 minecraft:redstone_wire replace
setblock ~165 ~43 ~160 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~162 ~165 ~43 ~174 minecraft:redstone_wire replace
setblock ~144 ~43 ~166 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~168 ~144 ~43 ~180 minecraft:redstone_wire replace
setblock ~225 ~43 ~172 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~174 ~225 ~43 ~186 minecraft:redstone_wire replace
setblock ~165 ~43 ~176 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~178 ~165 ~43 ~190 minecraft:redstone_wire replace
setblock ~144 ~43 ~182 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~184 ~144 ~43 ~196 minecraft:redstone_wire replace
setblock ~225 ~43 ~188 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~190 ~225 ~43 ~202 minecraft:redstone_wire replace
setblock ~165 ~43 ~192 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~194 ~165 ~43 ~206 minecraft:redstone_wire replace
setblock ~144 ~43 ~198 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~200 ~144 ~43 ~212 minecraft:redstone_wire replace
setblock ~225 ~43 ~204 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~206 ~225 ~43 ~218 minecraft:redstone_wire replace
setblock ~165 ~43 ~208 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~210 ~165 ~43 ~222 minecraft:redstone_wire replace
setblock ~144 ~43 ~214 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~216 ~144 ~43 ~228 minecraft:redstone_wire replace
setblock ~225 ~43 ~220 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~222 ~225 ~43 ~234 minecraft:redstone_wire replace
setblock ~165 ~43 ~224 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~226 ~165 ~43 ~238 minecraft:redstone_wire replace
setblock ~144 ~43 ~230 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~232 ~144 ~43 ~244 minecraft:redstone_wire replace
setblock ~225 ~43 ~236 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~238 ~225 ~43 ~250 minecraft:redstone_wire replace
setblock ~165 ~43 ~240 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~242 ~165 ~43 ~254 minecraft:redstone_wire replace
fill ~93 ~43 ~244 ~93 ~43 ~248 minecraft:redstone_wire replace
setblock ~144 ~43 ~246 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~123 ~43 ~248 ~123 ~43 ~260 minecraft:redstone_wire replace
fill ~144 ~43 ~248 ~144 ~43 ~260 minecraft:redstone_wire replace
setblock ~225 ~43 ~251 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~252 ~225 ~43 ~264 minecraft:redstone_wire replace
setblock ~165 ~43 ~255 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~256 ~165 ~43 ~268 minecraft:redstone_wire replace
setblock ~144 ~43 ~261 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~123 ~43 ~262 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~262 ~144 ~43 ~274 minecraft:redstone_wire replace
fill ~123 ~43 ~264 ~123 ~43 ~268 minecraft:redstone_wire replace
setblock ~225 ~43 ~266 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~268 ~225 ~43 ~280 minecraft:redstone_wire replace
setblock ~165 ~43 ~270 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~96 ~43 ~272 ~96 ~43 ~276 minecraft:redstone_wire replace
fill ~165 ~43 ~272 ~165 ~43 ~284 minecraft:redstone_wire replace
fill ~120 ~43 ~276 ~120 ~43 ~280 minecraft:redstone_wire replace
setblock ~144 ~43 ~276 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~144 ~43 ~278 ~144 ~43 ~284 minecraft:redstone_wire replace
setblock ~225 ~43 ~282 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~284 ~225 ~43 ~296 minecraft:redstone_wire replace
setblock ~165 ~43 ~286 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~165 ~43 ~288 ~165 ~43 ~298 minecraft:redstone_wire replace
fill ~147 ~43 ~292 ~147 ~43 ~296 minecraft:redstone_wire replace
setblock ~225 ~43 ~298 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~165 ~43 ~300 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~300 ~225 ~43 ~312 minecraft:redstone_wire replace
fill ~168 ~43 ~308 ~168 ~43 ~312 minecraft:redstone_wire replace
setblock ~225 ~43 ~314 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~225 ~43 ~316 ~225 ~43 ~320 minecraft:redstone_wire replace
fill ~183 ~43 ~320 ~183 ~43 ~324 minecraft:redstone_wire replace
fill ~204 ~43 ~324 ~204 ~43 ~328 minecraft:redstone_wire replace
fill ~249 ~43 ~328 ~249 ~43 ~332 minecraft:redstone_wire replace
fill ~207 ~43 ~336 ~207 ~43 ~340 minecraft:redstone_wire replace
fill ~231 ~43 ~340 ~231 ~43 ~344 minecraft:redstone_wire replace
fill ~267 ~43 ~344 ~267 ~43 ~348 minecraft:redstone_wire replace
fill ~234 ~43 ~352 ~234 ~43 ~356 minecraft:redstone_wire replace
fill ~291 ~43 ~356 ~291 ~43 ~360 minecraft:redstone_wire replace
fill ~306 ~43 ~360 ~306 ~43 ~364 minecraft:redstone_wire replace
fill ~309 ~43 ~364 ~309 ~43 ~368 minecraft:redstone_wire replace
fill ~282 ~43 ~368 ~282 ~43 ~372 minecraft:redstone_wire replace
fill ~297 ~43 ~372 ~297 ~43 ~376 minecraft:redstone_wire replace
fill ~255 ~43 ~380 ~255 ~43 ~384 minecraft:redstone_wire replace
fill ~333 ~43 ~384 ~333 ~43 ~388 minecraft:redstone_wire replace
fill ~354 ~43 ~388 ~354 ~43 ~392 minecraft:redstone_wire replace
fill ~321 ~43 ~392 ~321 ~43 ~396 minecraft:redstone_wire replace
fill ~345 ~43 ~396 ~345 ~43 ~400 minecraft:redstone_wire replace
fill ~315 ~43 ~400 ~315 ~43 ~404 minecraft:redstone_wire replace
fill ~90 ~43 ~408 ~90 ~43 ~412 minecraft:redstone_wire replace
fill ~117 ~43 ~412 ~117 ~43 ~416 minecraft:redstone_wire replace
fill ~141 ~43 ~416 ~141 ~43 ~420 minecraft:redstone_wire replace
fill ~174 ~43 ~420 ~174 ~43 ~424 minecraft:redstone_wire replace
fill ~195 ~43 ~424 ~195 ~43 ~428 minecraft:redstone_wire replace
fill ~219 ~43 ~428 ~219 ~43 ~432 minecraft:redstone_wire replace
fill ~252 ~43 ~432 ~252 ~43 ~436 minecraft:redstone_wire replace
fill ~276 ~43 ~436 ~276 ~43 ~440 minecraft:redstone_wire replace
fill ~312 ~43 ~440 ~312 ~43 ~444 minecraft:redstone_wire replace
fill ~87 ~43 ~444 ~87 ~43 ~448 minecraft:redstone_wire replace
fill ~114 ~43 ~448 ~114 ~43 ~452 minecraft:redstone_wire replace
fill ~138 ~43 ~452 ~138 ~43 ~456 minecraft:redstone_wire replace
fill ~171 ~43 ~456 ~171 ~43 ~460 minecraft:redstone_wire replace
fill ~192 ~43 ~460 ~192 ~43 ~464 minecraft:redstone_wire replace
fill ~216 ~43 ~464 ~216 ~43 ~468 minecraft:redstone_wire replace
fill ~246 ~43 ~468 ~246 ~43 ~472 minecraft:redstone_wire replace
fill ~273 ~43 ~472 ~273 ~43 ~476 minecraft:redstone_wire replace
fill ~336 ~43 ~476 ~336 ~43 ~480 minecraft:redstone_wire replace
fill ~360 ~43 ~480 ~360 ~43 ~484 minecraft:redstone_wire replace
fill ~84 ~43 ~484 ~84 ~43 ~488 minecraft:redstone_wire replace
fill ~111 ~43 ~488 ~111 ~43 ~492 minecraft:redstone_wire replace
fill ~135 ~43 ~492 ~135 ~43 ~496 minecraft:redstone_wire replace
fill ~162 ~43 ~496 ~162 ~43 ~500 minecraft:redstone_wire replace
fill ~189 ~43 ~500 ~189 ~43 ~504 minecraft:redstone_wire replace
