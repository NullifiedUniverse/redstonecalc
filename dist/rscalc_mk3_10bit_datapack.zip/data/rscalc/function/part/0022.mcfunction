fill ~276 ~46 ~440 ~276 ~46 ~444 minecraft:light_gray_concrete replace
fill ~312 ~46 ~444 ~312 ~46 ~448 minecraft:light_gray_concrete replace
fill ~87 ~46 ~448 ~87 ~46 ~452 minecraft:light_gray_concrete replace
fill ~114 ~46 ~452 ~114 ~46 ~456 minecraft:light_gray_concrete replace
fill ~138 ~46 ~456 ~138 ~46 ~460 minecraft:light_gray_concrete replace
fill ~171 ~46 ~460 ~171 ~46 ~464 minecraft:light_gray_concrete replace
fill ~195 ~46 ~464 ~195 ~46 ~468 minecraft:light_gray_concrete replace
fill ~222 ~46 ~468 ~222 ~46 ~472 minecraft:light_gray_concrete replace
fill ~252 ~46 ~472 ~252 ~46 ~476 minecraft:light_gray_concrete replace
fill ~273 ~46 ~476 ~273 ~46 ~480 minecraft:light_gray_concrete replace
fill ~336 ~46 ~480 ~336 ~46 ~484 minecraft:light_gray_concrete replace
fill ~360 ~46 ~484 ~360 ~46 ~488 minecraft:light_gray_concrete replace
fill ~84 ~46 ~488 ~84 ~46 ~492 minecraft:light_gray_concrete replace
fill ~111 ~46 ~492 ~111 ~46 ~496 minecraft:light_gray_concrete replace
fill ~135 ~46 ~496 ~135 ~46 ~500 minecraft:light_gray_concrete replace
fill ~162 ~46 ~500 ~162 ~46 ~504 minecraft:light_gray_concrete replace
fill ~192 ~46 ~504 ~192 ~46 ~508 minecraft:light_gray_concrete replace
fill ~219 ~46 ~508 ~219 ~46 ~512 minecraft:light_gray_concrete replace
fill ~249 ~46 ~512 ~249 ~46 ~516 minecraft:light_gray_concrete replace
fill ~270 ~46 ~516 ~270 ~46 ~520 minecraft:light_gray_concrete replace
fill ~330 ~46 ~520 ~330 ~46 ~524 minecraft:light_gray_concrete replace
fill ~357 ~46 ~524 ~357 ~46 ~528 minecraft:light_gray_concrete replace
fill ~81 ~46 ~528 ~81 ~46 ~532 minecraft:light_gray_concrete replace
fill ~108 ~46 ~532 ~108 ~46 ~536 minecraft:light_gray_concrete replace
fill ~132 ~46 ~536 ~132 ~46 ~540 minecraft:light_gray_concrete replace
fill ~156 ~46 ~540 ~156 ~46 ~544 minecraft:light_gray_concrete replace
fill ~189 ~46 ~544 ~189 ~46 ~548 minecraft:light_gray_concrete replace
fill ~216 ~46 ~548 ~216 ~46 ~552 minecraft:light_gray_concrete replace
fill ~246 ~46 ~552 ~246 ~46 ~556 minecraft:light_gray_concrete replace
fill ~264 ~46 ~556 ~264 ~46 ~560 minecraft:light_gray_concrete replace
fill ~327 ~46 ~560 ~327 ~46 ~564 minecraft:light_gray_concrete replace
fill ~351 ~46 ~564 ~351 ~46 ~568 minecraft:light_gray_concrete replace
fill ~78 ~46 ~568 ~78 ~46 ~572 minecraft:light_gray_concrete replace
fill ~105 ~46 ~572 ~105 ~46 ~576 minecraft:light_gray_concrete replace
fill ~129 ~46 ~576 ~129 ~46 ~580 minecraft:light_gray_concrete replace
fill ~153 ~46 ~580 ~153 ~46 ~584 minecraft:light_gray_concrete replace
fill ~180 ~46 ~584 ~180 ~46 ~588 minecraft:light_gray_concrete replace
fill ~204 ~46 ~588 ~204 ~46 ~592 minecraft:light_gray_concrete replace
fill ~243 ~46 ~592 ~243 ~46 ~596 minecraft:light_gray_concrete replace
fill ~261 ~46 ~596 ~261 ~46 ~600 minecraft:light_gray_concrete replace
fill ~324 ~46 ~600 ~324 ~46 ~604 minecraft:light_gray_concrete replace
fill ~348 ~46 ~604 ~348 ~46 ~608 minecraft:light_gray_concrete replace
fill ~102 ~46 ~608 ~102 ~46 ~612 minecraft:light_gray_concrete replace
fill ~126 ~46 ~612 ~126 ~46 ~616 minecraft:light_gray_concrete replace
fill ~150 ~46 ~616 ~150 ~46 ~620 minecraft:light_gray_concrete replace
fill ~177 ~46 ~620 ~177 ~46 ~624 minecraft:light_gray_concrete replace
fill ~201 ~46 ~624 ~201 ~46 ~628 minecraft:light_gray_concrete replace
fill ~228 ~46 ~628 ~228 ~46 ~632 minecraft:light_gray_concrete replace
fill ~267 ~46 ~632 ~267 ~46 ~636 minecraft:light_gray_concrete replace
fill ~279 ~46 ~636 ~279 ~46 ~640 minecraft:light_gray_concrete replace
fill ~339 ~46 ~640 ~339 ~46 ~644 minecraft:light_gray_concrete replace
fill ~159 ~46 ~644 ~159 ~46 ~648 minecraft:light_gray_concrete replace
fill ~366 ~46 ~648 ~366 ~46 ~652 minecraft:light_gray_concrete replace
fill ~99 ~46 ~652 ~99 ~46 ~656 minecraft:light_gray_concrete replace
fill ~342 ~46 ~656 ~342 ~46 ~660 minecraft:light_gray_concrete replace
fill ~363 ~46 ~660 ~363 ~46 ~664 minecraft:light_gray_concrete replace
setblock ~300 ~47 ~35 minecraft:light_gray_concrete replace
setblock ~285 ~47 ~39 minecraft:light_gray_concrete replace
setblock ~234 ~47 ~43 minecraft:light_gray_concrete replace
setblock ~303 ~47 ~47 minecraft:light_gray_concrete replace
setblock ~288 ~47 ~51 minecraft:light_gray_concrete replace
setblock ~291 ~47 ~59 minecraft:light_gray_concrete replace
setblock ~318 ~47 ~75 minecraft:light_gray_concrete replace
setblock ~96 ~47 ~243 minecraft:light_gray_concrete replace
setblock ~93 ~47 ~247 minecraft:light_gray_concrete replace
setblock ~94 ~47 ~252 minecraft:light_gray_concrete replace
setblock ~123 ~47 ~263 minecraft:light_gray_concrete replace
setblock ~93 ~47 ~265 minecraft:light_gray_concrete replace
setblock ~96 ~47 ~265 minecraft:light_gray_concrete replace
setblock ~93 ~47 ~267 minecraft:light_gray_concrete replace
setblock ~96 ~47 ~267 minecraft:light_gray_concrete replace
setblock ~120 ~47 ~267 minecraft:light_gray_concrete replace
setblock ~124 ~47 ~272 minecraft:light_gray_concrete replace
setblock ~147 ~47 ~279 minecraft:light_gray_concrete replace
setblock ~97 ~47 ~280 minecraft:light_gray_concrete replace
setblock ~144 ~47 ~283 minecraft:light_gray_concrete replace
setblock ~121 ~47 ~284 minecraft:light_gray_concrete replace
setblock ~148 ~47 ~288 minecraft:light_gray_concrete replace
setblock ~168 ~47 ~291 minecraft:light_gray_concrete replace
setblock ~168 ~47 ~293 minecraft:light_gray_concrete replace
setblock ~165 ~47 ~295 minecraft:light_gray_concrete replace
setblock ~297 ~47 ~299 minecraft:light_gray_concrete replace
setblock ~145 ~47 ~300 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~303 minecraft:light_gray_concrete replace
setblock ~169 ~47 ~304 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~305 minecraft:light_gray_concrete replace
setblock ~231 ~47 ~307 minecraft:light_gray_concrete replace
setblock ~297 ~47 ~307 minecraft:light_gray_concrete replace
setblock ~297 ~47 ~309 minecraft:light_gray_concrete replace
setblock ~207 ~47 ~311 minecraft:light_gray_concrete replace
setblock ~207 ~47 ~313 minecraft:light_gray_concrete replace
setblock ~186 ~47 ~315 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~315 minecraft:light_gray_concrete replace
setblock ~166 ~47 ~316 minecraft:light_gray_concrete replace
setblock ~186 ~47 ~317 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~317 minecraft:light_gray_concrete replace
setblock ~183 ~47 ~319 minecraft:light_gray_concrete replace
setblock ~183 ~47 ~321 minecraft:light_gray_concrete replace
setblock ~187 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~208 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~232 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~324 minecraft:light_gray_concrete replace
setblock ~210 ~47 ~327 minecraft:light_gray_concrete replace
setblock ~184 ~47 ~328 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~331 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~333 minecraft:light_gray_concrete replace
setblock ~208 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~232 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~336 minecraft:light_gray_concrete replace
setblock ~231 ~47 ~337 minecraft:light_gray_concrete replace
setblock ~213 ~47 ~339 minecraft:light_gray_concrete replace
setblock ~231 ~47 ~339 minecraft:light_gray_concrete replace
setblock ~237 ~47 ~343 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~347 minecraft:light_gray_concrete replace
setblock ~282 ~47 ~349 minecraft:light_gray_concrete replace
setblock ~232 ~47 ~352 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~352 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~352 minecraft:light_gray_concrete replace
setblock ~240 ~47 ~355 minecraft:light_gray_concrete replace
setblock ~306 ~47 ~363 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~364 minecraft:light_gray_concrete replace
setblock ~298 ~47 ~364 minecraft:light_gray_concrete replace
setblock ~309 ~47 ~367 minecraft:light_gray_concrete replace
setblock ~294 ~47 ~375 minecraft:light_gray_concrete replace
setblock ~283 ~47 ~376 minecraft:light_gray_concrete replace
setblock ~258 ~47 ~383 minecraft:light_gray_concrete replace
setblock ~333 ~47 ~387 minecraft:light_gray_concrete replace
setblock ~354 ~47 ~391 minecraft:light_gray_concrete replace
setblock ~321 ~47 ~395 minecraft:light_gray_concrete replace
setblock ~345 ~47 ~399 minecraft:light_gray_concrete replace
setblock ~315 ~47 ~403 minecraft:light_gray_concrete replace
setblock ~90 ~47 ~411 minecraft:light_gray_concrete replace
setblock ~117 ~47 ~415 minecraft:light_gray_concrete replace
setblock ~141 ~47 ~419 minecraft:light_gray_concrete replace
setblock ~174 ~47 ~423 minecraft:light_gray_concrete replace
setblock ~198 ~47 ~427 minecraft:light_gray_concrete replace
setblock ~225 ~47 ~431 minecraft:light_gray_concrete replace
setblock ~255 ~47 ~435 minecraft:light_gray_concrete replace
setblock ~276 ~47 ~439 minecraft:light_gray_concrete replace
setblock ~312 ~47 ~443 minecraft:light_gray_concrete replace
setblock ~87 ~47 ~447 minecraft:light_gray_concrete replace
setblock ~114 ~47 ~451 minecraft:light_gray_concrete replace
setblock ~138 ~47 ~455 minecraft:light_gray_concrete replace
setblock ~171 ~47 ~459 minecraft:light_gray_concrete replace
setblock ~195 ~47 ~463 minecraft:light_gray_concrete replace
setblock ~222 ~47 ~467 minecraft:light_gray_concrete replace
setblock ~252 ~47 ~471 minecraft:light_gray_concrete replace
setblock ~273 ~47 ~475 minecraft:light_gray_concrete replace
setblock ~336 ~47 ~479 minecraft:light_gray_concrete replace
setblock ~360 ~47 ~483 minecraft:light_gray_concrete replace
setblock ~84 ~47 ~487 minecraft:light_gray_concrete replace
setblock ~111 ~47 ~491 minecraft:light_gray_concrete replace
setblock ~135 ~47 ~495 minecraft:light_gray_concrete replace
setblock ~162 ~47 ~499 minecraft:light_gray_concrete replace
setblock ~192 ~47 ~503 minecraft:light_gray_concrete replace
setblock ~219 ~47 ~507 minecraft:light_gray_concrete replace
setblock ~249 ~47 ~511 minecraft:light_gray_concrete replace
setblock ~270 ~47 ~515 minecraft:light_gray_concrete replace
setblock ~330 ~47 ~519 minecraft:light_gray_concrete replace
setblock ~357 ~47 ~523 minecraft:light_gray_concrete replace
setblock ~81 ~47 ~527 minecraft:light_gray_concrete replace
setblock ~108 ~47 ~531 minecraft:light_gray_concrete replace
setblock ~132 ~47 ~535 minecraft:light_gray_concrete replace
setblock ~156 ~47 ~539 minecraft:light_gray_concrete replace
setblock ~189 ~47 ~543 minecraft:light_gray_concrete replace
setblock ~216 ~47 ~547 minecraft:light_gray_concrete replace
setblock ~246 ~47 ~551 minecraft:light_gray_concrete replace
setblock ~264 ~47 ~555 minecraft:light_gray_concrete replace
setblock ~327 ~47 ~559 minecraft:light_gray_concrete replace
setblock ~351 ~47 ~563 minecraft:light_gray_concrete replace
setblock ~78 ~47 ~567 minecraft:light_gray_concrete replace
setblock ~105 ~47 ~571 minecraft:light_gray_concrete replace
setblock ~129 ~47 ~575 minecraft:light_gray_concrete replace
setblock ~153 ~47 ~579 minecraft:light_gray_concrete replace
setblock ~180 ~47 ~583 minecraft:light_gray_concrete replace
setblock ~204 ~47 ~587 minecraft:light_gray_concrete replace
setblock ~243 ~47 ~591 minecraft:light_gray_concrete replace
setblock ~261 ~47 ~595 minecraft:light_gray_concrete replace
setblock ~324 ~47 ~599 minecraft:light_gray_concrete replace
setblock ~348 ~47 ~603 minecraft:light_gray_concrete replace
setblock ~102 ~47 ~607 minecraft:light_gray_concrete replace
setblock ~126 ~47 ~611 minecraft:light_gray_concrete replace
setblock ~150 ~47 ~615 minecraft:light_gray_concrete replace
setblock ~177 ~47 ~619 minecraft:light_gray_concrete replace
setblock ~201 ~47 ~623 minecraft:light_gray_concrete replace
setblock ~228 ~47 ~627 minecraft:light_gray_concrete replace
setblock ~267 ~47 ~631 minecraft:light_gray_concrete replace
setblock ~279 ~47 ~635 minecraft:light_gray_concrete replace
setblock ~339 ~47 ~639 minecraft:light_gray_concrete replace
setblock ~159 ~47 ~643 minecraft:light_gray_concrete replace
setblock ~366 ~47 ~647 minecraft:light_gray_concrete replace
setblock ~99 ~47 ~651 minecraft:light_gray_concrete replace
setblock ~342 ~47 ~655 minecraft:light_gray_concrete replace
setblock ~363 ~47 ~659 minecraft:light_gray_concrete replace
fill ~262 ~48 ~32 ~262 ~48 ~33 minecraft:light_gray_concrete replace
fill ~261 ~48 ~34 ~300 ~48 ~34 minecraft:light_gray_concrete replace
fill ~259 ~48 ~36 ~259 ~48 ~37 minecraft:light_gray_concrete replace
fill ~258 ~48 ~38 ~285 ~48 ~38 minecraft:light_gray_concrete replace
fill ~214 ~48 ~40 ~214 ~48 ~41 minecraft:light_gray_concrete replace
fill ~213 ~48 ~42 ~234 ~48 ~42 minecraft:light_gray_concrete replace
fill ~262 ~48 ~44 ~262 ~48 ~45 minecraft:light_gray_concrete replace
fill ~261 ~48 ~46 ~303 ~48 ~46 minecraft:light_gray_concrete replace
fill ~259 ~48 ~48 ~259 ~48 ~49 minecraft:light_gray_concrete replace
fill ~258 ~48 ~50 ~288 ~48 ~50 minecraft:light_gray_concrete replace
fill ~259 ~48 ~56 ~259 ~48 ~57 minecraft:light_gray_concrete replace
fill ~258 ~48 ~58 ~291 ~48 ~58 minecraft:light_gray_concrete replace
fill ~274 ~48 ~72 ~274 ~48 ~73 minecraft:light_gray_concrete replace
fill ~273 ~48 ~74 ~318 ~48 ~74 minecraft:light_gray_concrete replace
fill ~94 ~48 ~240 ~94 ~48 ~241 minecraft:light_gray_concrete replace
fill ~93 ~48 ~242 ~96 ~48 ~242 minecraft:light_gray_concrete replace
fill ~94 ~48 ~244 ~94 ~48 ~245 minecraft:light_gray_concrete replace
fill ~93 ~48 ~246 ~95 ~48 ~246 minecraft:light_gray_concrete replace
fill ~118 ~48 ~260 ~118 ~48 ~261 minecraft:light_gray_concrete replace
fill ~117 ~48 ~262 ~123 ~48 ~262 minecraft:light_gray_concrete replace
fill ~118 ~48 ~264 ~118 ~48 ~265 minecraft:light_gray_concrete replace
fill ~117 ~48 ~266 ~120 ~48 ~266 minecraft:light_gray_concrete replace
fill ~139 ~48 ~276 ~139 ~48 ~277 minecraft:light_gray_concrete replace
fill ~138 ~48 ~278 ~147 ~48 ~278 minecraft:light_gray_concrete replace
fill ~139 ~48 ~280 ~139 ~48 ~281 minecraft:light_gray_concrete replace
fill ~138 ~48 ~282 ~144 ~48 ~282 minecraft:light_gray_concrete replace
fill ~157 ~48 ~288 ~157 ~48 ~289 minecraft:light_gray_concrete replace
fill ~156 ~48 ~290 ~168 ~48 ~290 minecraft:light_gray_concrete replace
fill ~157 ~48 ~292 ~157 ~48 ~293 minecraft:light_gray_concrete replace
fill ~156 ~48 ~294 ~165 ~48 ~294 minecraft:light_gray_concrete replace
fill ~262 ~48 ~296 ~262 ~48 ~297 minecraft:light_gray_concrete replace
fill ~261 ~48 ~298 ~297 ~48 ~298 minecraft:light_gray_concrete replace
fill ~259 ~48 ~300 ~259 ~48 ~301 minecraft:light_gray_concrete replace
fill ~258 ~48 ~302 ~282 ~48 ~302 minecraft:light_gray_concrete replace
fill ~214 ~48 ~304 ~214 ~48 ~305 minecraft:light_gray_concrete replace
fill ~213 ~48 ~306 ~231 ~48 ~306 minecraft:light_gray_concrete replace
fill ~193 ~48 ~308 ~193 ~48 ~309 minecraft:light_gray_concrete replace
fill ~192 ~48 ~310 ~207 ~48 ~310 minecraft:light_gray_concrete replace
fill ~172 ~48 ~312 ~172 ~48 ~313 minecraft:light_gray_concrete replace
fill ~171 ~48 ~314 ~186 ~48 ~314 minecraft:light_gray_concrete replace
fill ~172 ~48 ~316 ~172 ~48 ~317 minecraft:light_gray_concrete replace
fill ~171 ~48 ~318 ~183 ~48 ~318 minecraft:light_gray_concrete replace
fill ~193 ~48 ~324 ~193 ~48 ~325 minecraft:light_gray_concrete replace
fill ~192 ~48 ~326 ~210 ~48 ~326 minecraft:light_gray_concrete replace
fill ~196 ~48 ~336 ~196 ~48 ~337 minecraft:light_gray_concrete replace
fill ~195 ~48 ~338 ~213 ~48 ~338 minecraft:light_gray_concrete replace
fill ~214 ~48 ~340 ~214 ~48 ~341 minecraft:light_gray_concrete replace
fill ~213 ~48 ~342 ~237 ~48 ~342 minecraft:light_gray_concrete replace
fill ~217 ~48 ~352 ~217 ~48 ~353 minecraft:light_gray_concrete replace
fill ~216 ~48 ~354 ~240 ~48 ~354 minecraft:light_gray_concrete replace
fill ~262 ~48 ~360 ~262 ~48 ~361 minecraft:light_gray_concrete replace
fill ~261 ~48 ~362 ~306 ~48 ~362 minecraft:light_gray_concrete replace
fill ~265 ~48 ~364 ~265 ~48 ~365 minecraft:light_gray_concrete replace
fill ~264 ~48 ~366 ~309 ~48 ~366 minecraft:light_gray_concrete replace
fill ~259 ~48 ~372 ~259 ~48 ~373 minecraft:light_gray_concrete replace
fill ~258 ~48 ~374 ~294 ~48 ~374 minecraft:light_gray_concrete replace
fill ~235 ~48 ~380 ~235 ~48 ~381 minecraft:light_gray_concrete replace
fill ~234 ~48 ~382 ~258 ~48 ~382 minecraft:light_gray_concrete replace
fill ~289 ~48 ~384 ~289 ~48 ~385 minecraft:light_gray_concrete replace
fill ~288 ~48 ~386 ~333 ~48 ~386 minecraft:light_gray_concrete replace
fill ~310 ~48 ~388 ~310 ~48 ~389 minecraft:light_gray_concrete replace
fill ~309 ~48 ~390 ~354 ~48 ~390 minecraft:light_gray_concrete replace
fill ~277 ~48 ~392 ~277 ~48 ~393 minecraft:light_gray_concrete replace
fill ~276 ~48 ~394 ~321 ~48 ~394 minecraft:light_gray_concrete replace
fill ~301 ~48 ~396 ~301 ~48 ~397 minecraft:light_gray_concrete replace
fill ~300 ~48 ~398 ~345 ~48 ~398 minecraft:light_gray_concrete replace
fill ~271 ~48 ~400 ~271 ~48 ~401 minecraft:light_gray_concrete replace
fill ~270 ~48 ~402 ~315 ~48 ~402 minecraft:light_gray_concrete replace
fill ~91 ~48 ~408 ~91 ~48 ~409 minecraft:light_gray_concrete replace
fill ~90 ~48 ~410 ~92 ~48 ~410 minecraft:light_gray_concrete replace
fill ~115 ~48 ~412 ~115 ~48 ~413 minecraft:light_gray_concrete replace
fill ~114 ~48 ~414 ~117 ~48 ~414 minecraft:light_gray_concrete replace
fill ~136 ~48 ~416 ~136 ~48 ~417 minecraft:light_gray_concrete replace
fill ~135 ~48 ~418 ~141 ~48 ~418 minecraft:light_gray_concrete replace
fill ~163 ~48 ~420 ~163 ~48 ~421 minecraft:light_gray_concrete replace
fill ~162 ~48 ~422 ~174 ~48 ~422 minecraft:light_gray_concrete replace
fill ~184 ~48 ~424 ~184 ~48 ~425 minecraft:light_gray_concrete replace
fill ~183 ~48 ~426 ~198 ~48 ~426 minecraft:light_gray_concrete replace
fill ~208 ~48 ~428 ~208 ~48 ~429 minecraft:light_gray_concrete replace
fill ~207 ~48 ~430 ~225 ~48 ~430 minecraft:light_gray_concrete replace
fill ~232 ~48 ~432 ~232 ~48 ~433 minecraft:light_gray_concrete replace
fill ~231 ~48 ~434 ~255 ~48 ~434 minecraft:light_gray_concrete replace
fill ~253 ~48 ~436 ~253 ~48 ~437 minecraft:light_gray_concrete replace
fill ~252 ~48 ~438 ~276 ~48 ~438 minecraft:light_gray_concrete replace
fill ~268 ~48 ~440 ~268 ~48 ~441 minecraft:light_gray_concrete replace
fill ~267 ~48 ~442 ~312 ~48 ~442 minecraft:light_gray_concrete replace
fill ~88 ~48 ~444 ~88 ~48 ~445 minecraft:light_gray_concrete replace
fill ~87 ~48 ~446 ~89 ~48 ~446 minecraft:light_gray_concrete replace
fill ~112 ~48 ~448 ~112 ~48 ~449 minecraft:light_gray_concrete replace
fill ~111 ~48 ~450 ~114 ~48 ~450 minecraft:light_gray_concrete replace
fill ~133 ~48 ~452 ~133 ~48 ~453 minecraft:light_gray_concrete replace
fill ~132 ~48 ~454 ~138 ~48 ~454 minecraft:light_gray_concrete replace
fill ~160 ~48 ~456 ~160 ~48 ~457 minecraft:light_gray_concrete replace
fill ~159 ~48 ~458 ~171 ~48 ~458 minecraft:light_gray_concrete replace
fill ~181 ~48 ~460 ~181 ~48 ~461 minecraft:light_gray_concrete replace
fill ~180 ~48 ~462 ~195 ~48 ~462 minecraft:light_gray_concrete replace
fill ~205 ~48 ~464 ~205 ~48 ~465 minecraft:light_gray_concrete replace
fill ~204 ~48 ~466 ~222 ~48 ~466 minecraft:light_gray_concrete replace
fill ~229 ~48 ~468 ~229 ~48 ~469 minecraft:light_gray_concrete replace
fill ~228 ~48 ~470 ~252 ~48 ~470 minecraft:light_gray_concrete replace
fill ~250 ~48 ~472 ~250 ~48 ~473 minecraft:light_gray_concrete replace
fill ~249 ~48 ~474 ~273 ~48 ~474 minecraft:light_gray_concrete replace
fill ~292 ~48 ~476 ~292 ~48 ~477 minecraft:light_gray_concrete replace
fill ~291 ~48 ~478 ~336 ~48 ~478 minecraft:light_gray_concrete replace
fill ~316 ~48 ~480 ~316 ~48 ~481 minecraft:light_gray_concrete replace
fill ~315 ~48 ~482 ~360 ~48 ~482 minecraft:light_gray_concrete replace
fill ~85 ~48 ~484 ~85 ~48 ~485 minecraft:light_gray_concrete replace
fill ~84 ~48 ~486 ~86 ~48 ~486 minecraft:light_gray_concrete replace
fill ~109 ~48 ~488 ~109 ~48 ~489 minecraft:light_gray_concrete replace
fill ~108 ~48 ~490 ~111 ~48 ~490 minecraft:light_gray_concrete replace
fill ~130 ~48 ~492 ~130 ~48 ~493 minecraft:light_gray_concrete replace
fill ~129 ~48 ~494 ~135 ~48 ~494 minecraft:light_gray_concrete replace
fill ~154 ~48 ~496 ~154 ~48 ~497 minecraft:light_gray_concrete replace
fill ~153 ~48 ~498 ~162 ~48 ~498 minecraft:light_gray_concrete replace
fill ~178 ~48 ~500 ~178 ~48 ~501 minecraft:light_gray_concrete replace
fill ~177 ~48 ~502 ~192 ~48 ~502 minecraft:light_gray_concrete replace
fill ~202 ~48 ~504 ~202 ~48 ~505 minecraft:light_gray_concrete replace
fill ~201 ~48 ~506 ~219 ~48 ~506 minecraft:light_gray_concrete replace
fill ~226 ~48 ~508 ~226 ~48 ~509 minecraft:light_gray_concrete replace
fill ~225 ~48 ~510 ~249 ~48 ~510 minecraft:light_gray_concrete replace
fill ~247 ~48 ~512 ~247 ~48 ~513 minecraft:light_gray_concrete replace
fill ~246 ~48 ~514 ~270 ~48 ~514 minecraft:light_gray_concrete replace
fill ~286 ~48 ~516 ~286 ~48 ~517 minecraft:light_gray_concrete replace
fill ~285 ~48 ~518 ~330 ~48 ~518 minecraft:light_gray_concrete replace
fill ~313 ~48 ~520 ~313 ~48 ~521 minecraft:light_gray_concrete replace
fill ~312 ~48 ~522 ~357 ~48 ~522 minecraft:light_gray_concrete replace
fill ~82 ~48 ~524 ~82 ~48 ~525 minecraft:light_gray_concrete replace
fill ~81 ~48 ~526 ~83 ~48 ~526 minecraft:light_gray_concrete replace
fill ~106 ~48 ~528 ~106 ~48 ~529 minecraft:light_gray_concrete replace
fill ~105 ~48 ~530 ~108 ~48 ~530 minecraft:light_gray_concrete replace
fill ~127 ~48 ~532 ~127 ~48 ~533 minecraft:light_gray_concrete replace
fill ~126 ~48 ~534 ~132 ~48 ~534 minecraft:light_gray_concrete replace
fill ~148 ~48 ~536 ~148 ~48 ~537 minecraft:light_gray_concrete replace
fill ~147 ~48 ~538 ~156 ~48 ~538 minecraft:light_gray_concrete replace
fill ~175 ~48 ~540 ~175 ~48 ~541 minecraft:light_gray_concrete replace
fill ~174 ~48 ~542 ~189 ~48 ~542 minecraft:light_gray_concrete replace
fill ~199 ~48 ~544 ~199 ~48 ~545 minecraft:light_gray_concrete replace
fill ~198 ~48 ~546 ~216 ~48 ~546 minecraft:light_gray_concrete replace
fill ~223 ~48 ~548 ~223 ~48 ~549 minecraft:light_gray_concrete replace
fill ~222 ~48 ~550 ~246 ~48 ~550 minecraft:light_gray_concrete replace
fill ~241 ~48 ~552 ~241 ~48 ~553 minecraft:light_gray_concrete replace
fill ~240 ~48 ~554 ~264 ~48 ~554 minecraft:light_gray_concrete replace
fill ~283 ~48 ~556 ~283 ~48 ~557 minecraft:light_gray_concrete replace
fill ~282 ~48 ~558 ~327 ~48 ~558 minecraft:light_gray_concrete replace
fill ~307 ~48 ~560 ~307 ~48 ~561 minecraft:light_gray_concrete replace
fill ~306 ~48 ~562 ~351 ~48 ~562 minecraft:light_gray_concrete replace
fill ~79 ~48 ~564 ~79 ~48 ~565 minecraft:light_gray_concrete replace
fill ~78 ~48 ~566 ~80 ~48 ~566 minecraft:light_gray_concrete replace
fill ~103 ~48 ~568 ~103 ~48 ~569 minecraft:light_gray_concrete replace
fill ~102 ~48 ~570 ~105 ~48 ~570 minecraft:light_gray_concrete replace
fill ~124 ~48 ~572 ~124 ~48 ~573 minecraft:light_gray_concrete replace
fill ~123 ~48 ~574 ~129 ~48 ~574 minecraft:light_gray_concrete replace
fill ~145 ~48 ~576 ~145 ~48 ~577 minecraft:light_gray_concrete replace
fill ~144 ~48 ~578 ~153 ~48 ~578 minecraft:light_gray_concrete replace
fill ~169 ~48 ~580 ~169 ~48 ~581 minecraft:light_gray_concrete replace
fill ~168 ~48 ~582 ~180 ~48 ~582 minecraft:light_gray_concrete replace
fill ~190 ~48 ~584 ~190 ~48 ~585 minecraft:light_gray_concrete replace
fill ~189 ~48 ~586 ~204 ~48 ~586 minecraft:light_gray_concrete replace
fill ~220 ~48 ~588 ~220 ~48 ~589 minecraft:light_gray_concrete replace
fill ~219 ~48 ~590 ~243 ~48 ~590 minecraft:light_gray_concrete replace
fill ~238 ~48 ~592 ~238 ~48 ~593 minecraft:light_gray_concrete replace
fill ~237 ~48 ~594 ~261 ~48 ~594 minecraft:light_gray_concrete replace
fill ~280 ~48 ~596 ~280 ~48 ~597 minecraft:light_gray_concrete replace
fill ~279 ~48 ~598 ~324 ~48 ~598 minecraft:light_gray_concrete replace
fill ~304 ~48 ~600 ~304 ~48 ~601 minecraft:light_gray_concrete replace
fill ~303 ~48 ~602 ~348 ~48 ~602 minecraft:light_gray_concrete replace
fill ~100 ~48 ~604 ~100 ~48 ~605 minecraft:light_gray_concrete replace
fill ~99 ~48 ~606 ~102 ~48 ~606 minecraft:light_gray_concrete replace
fill ~121 ~48 ~608 ~121 ~48 ~609 minecraft:light_gray_concrete replace
fill ~120 ~48 ~610 ~126 ~48 ~610 minecraft:light_gray_concrete replace
fill ~142 ~48 ~612 ~142 ~48 ~613 minecraft:light_gray_concrete replace
fill ~141 ~48 ~614 ~150 ~48 ~614 minecraft:light_gray_concrete replace
fill ~166 ~48 ~616 ~166 ~48 ~617 minecraft:light_gray_concrete replace
fill ~165 ~48 ~618 ~177 ~48 ~618 minecraft:light_gray_concrete replace
fill ~187 ~48 ~620 ~187 ~48 ~621 minecraft:light_gray_concrete replace
fill ~186 ~48 ~622 ~201 ~48 ~622 minecraft:light_gray_concrete replace
fill ~211 ~48 ~624 ~211 ~48 ~625 minecraft:light_gray_concrete replace
fill ~210 ~48 ~626 ~228 ~48 ~626 minecraft:light_gray_concrete replace
fill ~244 ~48 ~628 ~244 ~48 ~629 minecraft:light_gray_concrete replace
fill ~243 ~48 ~630 ~267 ~48 ~630 minecraft:light_gray_concrete replace
fill ~256 ~48 ~632 ~256 ~48 ~633 minecraft:light_gray_concrete replace
fill ~255 ~48 ~634 ~279 ~48 ~634 minecraft:light_gray_concrete replace
fill ~295 ~48 ~636 ~295 ~48 ~637 minecraft:light_gray_concrete replace
fill ~294 ~48 ~638 ~339 ~48 ~638 minecraft:light_gray_concrete replace
fill ~151 ~48 ~640 ~151 ~48 ~641 minecraft:light_gray_concrete replace
fill ~150 ~48 ~642 ~159 ~48 ~642 minecraft:light_gray_concrete replace
fill ~322 ~48 ~644 ~322 ~48 ~645 minecraft:light_gray_concrete replace
fill ~321 ~48 ~646 ~366 ~48 ~646 minecraft:light_gray_concrete replace
fill ~97 ~48 ~648 ~97 ~48 ~649 minecraft:light_gray_concrete replace
fill ~96 ~48 ~650 ~99 ~48 ~650 minecraft:light_gray_concrete replace
fill ~298 ~48 ~652 ~298 ~48 ~653 minecraft:light_gray_concrete replace
fill ~297 ~48 ~654 ~342 ~48 ~654 minecraft:light_gray_concrete replace
fill ~319 ~48 ~656 ~319 ~48 ~657 minecraft:light_gray_concrete replace
fill ~318 ~48 ~658 ~363 ~48 ~658 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~32 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~276 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~291 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~293 ~49 ~34 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~36 minecraft:light_gray_concrete replace
setblock ~276 ~49 ~38 minecraft:light_gray_concrete replace
setblock ~278 ~49 ~38 minecraft:light_gray_concrete replace
setblock ~214 ~49 ~40 minecraft:light_gray_concrete replace
setblock ~225 ~49 ~42 minecraft:light_gray_concrete replace
setblock ~227 ~49 ~42 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~44 minecraft:light_gray_concrete replace
setblock ~263 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~279 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~281 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~297 ~49 ~46 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~48 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~264 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~279 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~281 ~49 ~50 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~56 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~267 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~282 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~284 ~49 ~58 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~72 minecraft:light_gray_concrete replace
setblock ~275 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~277 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~292 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~294 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~309 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~311 ~49 ~74 minecraft:light_gray_concrete replace
setblock ~94 ~49 ~240 minecraft:light_gray_concrete replace
setblock ~94 ~49 ~244 minecraft:light_gray_concrete replace
setblock ~118 ~49 ~260 minecraft:light_gray_concrete replace
setblock ~118 ~49 ~264 minecraft:light_gray_concrete replace
setblock ~139 ~49 ~276 minecraft:light_gray_concrete replace
setblock ~139 ~49 ~280 minecraft:light_gray_concrete replace
setblock ~157 ~49 ~288 minecraft:light_gray_concrete replace
setblock ~157 ~49 ~292 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~296 minecraft:light_gray_concrete replace
setblock ~272 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~291 ~49 ~298 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~300 minecraft:light_gray_concrete replace
setblock ~267 ~49 ~302 minecraft:light_gray_concrete replace
setblock ~269 ~49 ~302 minecraft:light_gray_concrete replace
setblock ~214 ~49 ~304 minecraft:light_gray_concrete replace
setblock ~217 ~49 ~306 minecraft:light_gray_concrete replace
setblock ~219 ~49 ~306 minecraft:light_gray_concrete replace
setblock ~193 ~49 ~308 minecraft:light_gray_concrete replace
setblock ~172 ~49 ~312 minecraft:light_gray_concrete replace
setblock ~172 ~49 ~316 minecraft:light_gray_concrete replace
setblock ~193 ~49 ~324 minecraft:light_gray_concrete replace
setblock ~201 ~49 ~326 minecraft:light_gray_concrete replace
setblock ~203 ~49 ~326 minecraft:light_gray_concrete replace
setblock ~196 ~49 ~336 minecraft:light_gray_concrete replace
setblock ~204 ~49 ~338 minecraft:light_gray_concrete replace
setblock ~206 ~49 ~338 minecraft:light_gray_concrete replace
setblock ~214 ~49 ~340 minecraft:light_gray_concrete replace
setblock ~228 ~49 ~342 minecraft:light_gray_concrete replace
setblock ~230 ~49 ~342 minecraft:light_gray_concrete replace
setblock ~217 ~49 ~352 minecraft:light_gray_concrete replace
setblock ~231 ~49 ~354 minecraft:light_gray_concrete replace
setblock ~233 ~49 ~354 minecraft:light_gray_concrete replace
setblock ~262 ~49 ~360 minecraft:light_gray_concrete replace
setblock ~263 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~280 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~282 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~297 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~299 ~49 ~362 minecraft:light_gray_concrete replace
setblock ~265 ~49 ~364 minecraft:light_gray_concrete replace
setblock ~266 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~268 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~283 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~285 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~300 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~302 ~49 ~366 minecraft:light_gray_concrete replace
setblock ~259 ~49 ~372 minecraft:light_gray_concrete replace
setblock ~268 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~270 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~285 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~287 ~49 ~374 minecraft:light_gray_concrete replace
setblock ~235 ~49 ~380 minecraft:light_gray_concrete replace
setblock ~249 ~49 ~382 minecraft:light_gray_concrete replace
setblock ~251 ~49 ~382 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~384 minecraft:light_gray_concrete replace
setblock ~290 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~292 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~307 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~309 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~324 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~326 ~49 ~386 minecraft:light_gray_concrete replace
setblock ~310 ~49 ~388 minecraft:light_gray_concrete replace
setblock ~311 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~313 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~328 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~330 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~345 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~347 ~49 ~390 minecraft:light_gray_concrete replace
setblock ~277 ~49 ~392 minecraft:light_gray_concrete replace
setblock ~278 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~280 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~297 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~312 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~314 ~49 ~394 minecraft:light_gray_concrete replace
setblock ~301 ~49 ~396 minecraft:light_gray_concrete replace
setblock ~302 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~304 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~319 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~321 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~336 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~338 ~49 ~398 minecraft:light_gray_concrete replace
setblock ~271 ~49 ~400 minecraft:light_gray_concrete replace
setblock ~272 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~274 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~291 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~306 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~308 ~49 ~402 minecraft:light_gray_concrete replace
setblock ~91 ~49 ~408 minecraft:light_gray_concrete replace
setblock ~115 ~49 ~412 minecraft:light_gray_concrete replace
setblock ~136 ~49 ~416 minecraft:light_gray_concrete replace
setblock ~163 ~49 ~420 minecraft:light_gray_concrete replace
setblock ~165 ~49 ~422 minecraft:light_gray_concrete replace
setblock ~167 ~49 ~422 minecraft:light_gray_concrete replace
setblock ~184 ~49 ~424 minecraft:light_gray_concrete replace
setblock ~189 ~49 ~426 minecraft:light_gray_concrete replace
setblock ~191 ~49 ~426 minecraft:light_gray_concrete replace
setblock ~208 ~49 ~428 minecraft:light_gray_concrete replace
setblock ~216 ~49 ~430 minecraft:light_gray_concrete replace
setblock ~218 ~49 ~430 minecraft:light_gray_concrete replace
setblock ~232 ~49 ~432 minecraft:light_gray_concrete replace
setblock ~246 ~49 ~434 minecraft:light_gray_concrete replace
setblock ~248 ~49 ~434 minecraft:light_gray_concrete replace
setblock ~253 ~49 ~436 minecraft:light_gray_concrete replace
setblock ~267 ~49 ~438 minecraft:light_gray_concrete replace
setblock ~269 ~49 ~438 minecraft:light_gray_concrete replace
setblock ~268 ~49 ~440 minecraft:light_gray_concrete replace
setblock ~269 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~271 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~286 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~288 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~303 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~305 ~49 ~442 minecraft:light_gray_concrete replace
setblock ~88 ~49 ~444 minecraft:light_gray_concrete replace
setblock ~112 ~49 ~448 minecraft:light_gray_concrete replace
setblock ~133 ~49 ~452 minecraft:light_gray_concrete replace
setblock ~160 ~49 ~456 minecraft:light_gray_concrete replace
setblock ~162 ~49 ~458 minecraft:light_gray_concrete replace
setblock ~164 ~49 ~458 minecraft:light_gray_concrete replace
setblock ~181 ~49 ~460 minecraft:light_gray_concrete replace
setblock ~186 ~49 ~462 minecraft:light_gray_concrete replace
setblock ~188 ~49 ~462 minecraft:light_gray_concrete replace
setblock ~205 ~49 ~464 minecraft:light_gray_concrete replace
setblock ~213 ~49 ~466 minecraft:light_gray_concrete replace
setblock ~215 ~49 ~466 minecraft:light_gray_concrete replace
setblock ~229 ~49 ~468 minecraft:light_gray_concrete replace
setblock ~243 ~49 ~470 minecraft:light_gray_concrete replace
setblock ~245 ~49 ~470 minecraft:light_gray_concrete replace
setblock ~250 ~49 ~472 minecraft:light_gray_concrete replace
setblock ~264 ~49 ~474 minecraft:light_gray_concrete replace
setblock ~266 ~49 ~474 minecraft:light_gray_concrete replace
setblock ~292 ~49 ~476 minecraft:light_gray_concrete replace
setblock ~293 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~295 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~310 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~312 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~327 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~329 ~49 ~478 minecraft:light_gray_concrete replace
setblock ~316 ~49 ~480 minecraft:light_gray_concrete replace
setblock ~317 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~319 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~334 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~336 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~351 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~353 ~49 ~482 minecraft:light_gray_concrete replace
setblock ~85 ~49 ~484 minecraft:light_gray_concrete replace
setblock ~109 ~49 ~488 minecraft:light_gray_concrete replace
setblock ~130 ~49 ~492 minecraft:light_gray_concrete replace
setblock ~154 ~49 ~496 minecraft:light_gray_concrete replace
setblock ~178 ~49 ~500 minecraft:light_gray_concrete replace
setblock ~183 ~49 ~502 minecraft:light_gray_concrete replace
setblock ~185 ~49 ~502 minecraft:light_gray_concrete replace
setblock ~202 ~49 ~504 minecraft:light_gray_concrete replace
setblock ~210 ~49 ~506 minecraft:light_gray_concrete replace
setblock ~212 ~49 ~506 minecraft:light_gray_concrete replace
setblock ~226 ~49 ~508 minecraft:light_gray_concrete replace
setblock ~240 ~49 ~510 minecraft:light_gray_concrete replace
setblock ~242 ~49 ~510 minecraft:light_gray_concrete replace
setblock ~247 ~49 ~512 minecraft:light_gray_concrete replace
setblock ~261 ~49 ~514 minecraft:light_gray_concrete replace
setblock ~263 ~49 ~514 minecraft:light_gray_concrete replace
setblock ~286 ~49 ~516 minecraft:light_gray_concrete replace
setblock ~287 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~289 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~304 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~306 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~321 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~323 ~49 ~518 minecraft:light_gray_concrete replace
setblock ~313 ~49 ~520 minecraft:light_gray_concrete replace
setblock ~314 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~316 ~49 ~522 minecraft:light_gray_concrete replace
setblock ~331 ~49 ~522 minecraft:light_gray_concrete replace
