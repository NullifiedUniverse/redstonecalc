setblock ~90 ~61 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~92 ~61 ~646 ~105 ~61 ~646 minecraft:redstone_wire replace
setblock ~107 ~61 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~61 ~646 ~122 ~61 ~646 minecraft:redstone_wire replace
setblock ~124 ~61 ~646 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~61 ~646 ~137 ~61 ~646 minecraft:redstone_wire replace
setblock ~138 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~139 ~61 ~646 ~151 ~61 ~646 minecraft:redstone_wire replace
setblock ~153 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~155 ~61 ~646 ~167 ~61 ~646 minecraft:redstone_wire replace
setblock ~169 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~171 ~61 ~646 ~183 ~61 ~646 minecraft:redstone_wire replace
setblock ~185 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~187 ~61 ~646 ~199 ~61 ~646 minecraft:redstone_wire replace
setblock ~200 ~61 ~646 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
setblock ~82 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~121 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~139 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~163 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~199 ~61 ~647 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~210 ~61 ~650 ~215 ~61 ~650 minecraft:redstone_wire replace
setblock ~216 ~61 ~650 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~217 ~61 ~650 ~218 ~61 ~650 minecraft:redstone_wire replace
setblock ~217 ~61 ~651 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~78 ~61 ~654 ~80 ~61 ~654 minecraft:redstone_wire replace
setblock ~79 ~61 ~655 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~183 ~61 ~658 ~186 ~61 ~658 minecraft:redstone_wire replace
setblock ~184 ~61 ~659 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
fill ~207 ~61 ~662 ~212 ~61 ~662 minecraft:redstone_wire replace
setblock ~213 ~61 ~662 minecraft:repeater[delay=4,facing=west,locked=false,powered=false] replace
fill ~214 ~61 ~662 ~215 ~61 ~662 minecraft:redstone_wire replace
setblock ~214 ~61 ~663 minecraft:repeater[delay=4,facing=north,locked=false,powered=false] replace
setblock ~103 ~62 ~332 minecraft:redstone_torch[lit=true] replace
setblock ~121 ~62 ~348 minecraft:redstone_torch[lit=true] replace
setblock ~163 ~62 ~364 minecraft:redstone_torch[lit=true] replace
setblock ~139 ~62 ~380 minecraft:redstone_torch[lit=true] replace
setblock ~187 ~62 ~396 minecraft:redstone_wire replace
setblock ~190 ~62 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~62 ~396 minecraft:redstone_wire replace
setblock ~211 ~62 ~396 minecraft:redstone_torch[lit=true] replace
setblock ~82 ~62 ~400 minecraft:redstone_torch[lit=true] replace
setblock ~208 ~62 ~400 minecraft:redstone_torch[lit=true] replace
setblock ~211 ~62 ~400 minecraft:redstone_wire replace
setblock ~187 ~62 ~404 minecraft:redstone_torch[lit=true] replace
setblock ~190 ~62 ~404 minecraft:redstone_wire replace
setblock ~115 ~62 ~436 minecraft:redstone_wire replace
setblock ~136 ~62 ~440 minecraft:redstone_wire replace
setblock ~157 ~62 ~444 minecraft:redstone_wire replace
setblock ~166 ~62 ~448 minecraft:redstone_wire replace
setblock ~112 ~62 ~472 minecraft:redstone_wire replace
setblock ~133 ~62 ~476 minecraft:redstone_wire replace
setblock ~154 ~62 ~480 minecraft:redstone_wire replace
setblock ~178 ~62 ~484 minecraft:redstone_wire replace
setblock ~205 ~62 ~488 minecraft:redstone_wire replace
setblock ~109 ~62 ~512 minecraft:redstone_wire replace
setblock ~130 ~62 ~516 minecraft:redstone_wire replace
setblock ~151 ~62 ~520 minecraft:redstone_wire replace
setblock ~175 ~62 ~524 minecraft:redstone_wire replace
setblock ~202 ~62 ~528 minecraft:redstone_wire replace
setblock ~106 ~62 ~552 minecraft:redstone_wire replace
setblock ~127 ~62 ~556 minecraft:redstone_wire replace
setblock ~145 ~62 ~560 minecraft:redstone_wire replace
setblock ~172 ~62 ~564 minecraft:redstone_wire replace
setblock ~196 ~62 ~568 minecraft:redstone_wire replace
setblock ~100 ~62 ~592 minecraft:redstone_wire replace
setblock ~124 ~62 ~596 minecraft:redstone_wire replace
setblock ~142 ~62 ~600 minecraft:redstone_wire replace
setblock ~169 ~62 ~604 minecraft:redstone_wire replace
setblock ~193 ~62 ~608 minecraft:redstone_wire replace
setblock ~85 ~62 ~612 minecraft:redstone_wire replace
setblock ~88 ~62 ~616 minecraft:redstone_wire replace
setblock ~91 ~62 ~620 minecraft:redstone_wire replace
setblock ~94 ~62 ~624 minecraft:redstone_wire replace
setblock ~97 ~62 ~628 minecraft:redstone_wire replace
setblock ~118 ~62 ~632 minecraft:redstone_wire replace
setblock ~148 ~62 ~636 minecraft:redstone_wire replace
setblock ~160 ~62 ~640 minecraft:redstone_wire replace
setblock ~181 ~62 ~644 minecraft:redstone_wire replace
setblock ~82 ~62 ~648 minecraft:redstone_wire replace
setblock ~103 ~62 ~648 minecraft:redstone_wire replace
setblock ~121 ~62 ~648 minecraft:redstone_wire replace
setblock ~139 ~62 ~648 minecraft:redstone_wire replace
setblock ~163 ~62 ~648 minecraft:redstone_wire replace
setblock ~199 ~62 ~648 minecraft:redstone_wire replace
setblock ~217 ~62 ~652 minecraft:redstone_wire replace
setblock ~79 ~62 ~656 minecraft:redstone_wire replace
setblock ~184 ~62 ~660 minecraft:redstone_wire replace
setblock ~214 ~62 ~664 minecraft:redstone_wire replace
fill ~102 ~63 ~328 ~102 ~63 ~330 minecraft:redstone_wire replace
setblock ~102 ~63 ~331 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~332 ~102 ~63 ~344 minecraft:redstone_wire replace
fill ~120 ~63 ~344 ~120 ~63 ~346 minecraft:redstone_wire replace
setblock ~102 ~63 ~346 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~347 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~348 ~102 ~63 ~360 minecraft:redstone_wire replace
fill ~120 ~63 ~348 ~120 ~63 ~360 minecraft:redstone_wire replace
fill ~162 ~63 ~360 ~162 ~63 ~362 minecraft:redstone_wire replace
setblock ~102 ~63 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~362 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~363 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~364 ~102 ~63 ~376 minecraft:redstone_wire replace
fill ~120 ~63 ~364 ~120 ~63 ~376 minecraft:redstone_wire replace
fill ~162 ~63 ~364 ~162 ~63 ~376 minecraft:redstone_wire replace
fill ~138 ~63 ~376 ~138 ~63 ~378 minecraft:redstone_wire replace
setblock ~102 ~63 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~378 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~379 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~380 ~102 ~63 ~392 minecraft:redstone_wire replace
fill ~120 ~63 ~380 ~120 ~63 ~392 minecraft:redstone_wire replace
fill ~138 ~63 ~380 ~138 ~63 ~392 minecraft:redstone_wire replace
fill ~162 ~63 ~380 ~162 ~63 ~392 minecraft:redstone_wire replace
fill ~210 ~63 ~380 ~210 ~63 ~384 minecraft:redstone_wire replace
setblock ~207 ~63 ~384 minecraft:redstone_wire replace
setblock ~207 ~63 ~386 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~210 ~63 ~386 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~189 ~63 ~388 minecraft:redstone_wire replace
fill ~207 ~63 ~388 ~207 ~63 ~400 minecraft:redstone_wire replace
fill ~210 ~63 ~388 ~210 ~63 ~400 minecraft:redstone_wire replace
setblock ~189 ~63 ~390 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~186 ~63 ~392 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~189 ~63 ~392 ~189 ~63 ~404 minecraft:redstone_wire replace
setblock ~102 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~394 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~186 ~63 ~394 ~186 ~63 ~404 minecraft:redstone_wire replace
setblock ~81 ~63 ~396 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~102 ~63 ~396 ~102 ~63 ~408 minecraft:redstone_wire replace
fill ~120 ~63 ~396 ~120 ~63 ~408 minecraft:redstone_wire replace
fill ~138 ~63 ~396 ~138 ~63 ~408 minecraft:redstone_wire replace
fill ~162 ~63 ~396 ~162 ~63 ~408 minecraft:redstone_wire replace
fill ~81 ~63 ~398 ~81 ~63 ~408 minecraft:redstone_wire replace
setblock ~81 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~410 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~412 ~81 ~63 ~424 minecraft:redstone_wire replace
fill ~102 ~63 ~412 ~102 ~63 ~424 minecraft:redstone_wire replace
fill ~120 ~63 ~412 ~120 ~63 ~424 minecraft:redstone_wire replace
fill ~138 ~63 ~412 ~138 ~63 ~424 minecraft:redstone_wire replace
fill ~162 ~63 ~412 ~162 ~63 ~424 minecraft:redstone_wire replace
setblock ~81 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~426 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~428 ~81 ~63 ~440 minecraft:redstone_wire replace
fill ~102 ~63 ~428 ~102 ~63 ~440 minecraft:redstone_wire replace
fill ~120 ~63 ~428 ~120 ~63 ~440 minecraft:redstone_wire replace
fill ~138 ~63 ~428 ~138 ~63 ~440 minecraft:redstone_wire replace
fill ~162 ~63 ~428 ~162 ~63 ~440 minecraft:redstone_wire replace
fill ~114 ~63 ~432 ~114 ~63 ~436 minecraft:redstone_wire replace
fill ~135 ~63 ~436 ~135 ~63 ~440 minecraft:redstone_wire replace
fill ~156 ~63 ~440 ~156 ~63 ~444 minecraft:redstone_wire replace
setblock ~81 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~442 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~444 ~81 ~63 ~456 minecraft:redstone_wire replace
fill ~102 ~63 ~444 ~102 ~63 ~456 minecraft:redstone_wire replace
fill ~120 ~63 ~444 ~120 ~63 ~456 minecraft:redstone_wire replace
fill ~138 ~63 ~444 ~138 ~63 ~456 minecraft:redstone_wire replace
fill ~162 ~63 ~444 ~162 ~63 ~456 minecraft:redstone_wire replace
fill ~165 ~63 ~444 ~165 ~63 ~448 minecraft:redstone_wire replace
setblock ~81 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~458 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~460 ~81 ~63 ~472 minecraft:redstone_wire replace
fill ~102 ~63 ~460 ~102 ~63 ~472 minecraft:redstone_wire replace
fill ~120 ~63 ~460 ~120 ~63 ~472 minecraft:redstone_wire replace
fill ~138 ~63 ~460 ~138 ~63 ~472 minecraft:redstone_wire replace
fill ~162 ~63 ~460 ~162 ~63 ~472 minecraft:redstone_wire replace
fill ~111 ~63 ~468 ~111 ~63 ~472 minecraft:redstone_wire replace
fill ~132 ~63 ~472 ~132 ~63 ~476 minecraft:redstone_wire replace
setblock ~81 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~474 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~476 ~81 ~63 ~488 minecraft:redstone_wire replace
fill ~102 ~63 ~476 ~102 ~63 ~488 minecraft:redstone_wire replace
fill ~120 ~63 ~476 ~120 ~63 ~488 minecraft:redstone_wire replace
fill ~138 ~63 ~476 ~138 ~63 ~488 minecraft:redstone_wire replace
fill ~153 ~63 ~476 ~153 ~63 ~480 minecraft:redstone_wire replace
fill ~162 ~63 ~476 ~162 ~63 ~488 minecraft:redstone_wire replace
fill ~177 ~63 ~480 ~177 ~63 ~484 minecraft:redstone_wire replace
fill ~204 ~63 ~484 ~204 ~63 ~488 minecraft:redstone_wire replace
setblock ~81 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~490 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~492 ~81 ~63 ~504 minecraft:redstone_wire replace
fill ~102 ~63 ~492 ~102 ~63 ~504 minecraft:redstone_wire replace
fill ~120 ~63 ~492 ~120 ~63 ~504 minecraft:redstone_wire replace
fill ~138 ~63 ~492 ~138 ~63 ~504 minecraft:redstone_wire replace
fill ~162 ~63 ~492 ~162 ~63 ~504 minecraft:redstone_wire replace
setblock ~81 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~506 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~508 ~81 ~63 ~520 minecraft:redstone_wire replace
fill ~102 ~63 ~508 ~102 ~63 ~520 minecraft:redstone_wire replace
fill ~108 ~63 ~508 ~108 ~63 ~512 minecraft:redstone_wire replace
fill ~120 ~63 ~508 ~120 ~63 ~520 minecraft:redstone_wire replace
fill ~138 ~63 ~508 ~138 ~63 ~520 minecraft:redstone_wire replace
fill ~162 ~63 ~508 ~162 ~63 ~520 minecraft:redstone_wire replace
fill ~129 ~63 ~512 ~129 ~63 ~516 minecraft:redstone_wire replace
fill ~150 ~63 ~516 ~150 ~63 ~520 minecraft:redstone_wire replace
fill ~174 ~63 ~520 ~174 ~63 ~524 minecraft:redstone_wire replace
setblock ~81 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~522 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~524 ~81 ~63 ~536 minecraft:redstone_wire replace
fill ~102 ~63 ~524 ~102 ~63 ~536 minecraft:redstone_wire replace
fill ~120 ~63 ~524 ~120 ~63 ~536 minecraft:redstone_wire replace
fill ~138 ~63 ~524 ~138 ~63 ~536 minecraft:redstone_wire replace
fill ~162 ~63 ~524 ~162 ~63 ~536 minecraft:redstone_wire replace
fill ~201 ~63 ~524 ~201 ~63 ~528 minecraft:redstone_wire replace
setblock ~81 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~538 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~540 ~81 ~63 ~552 minecraft:redstone_wire replace
fill ~102 ~63 ~540 ~102 ~63 ~552 minecraft:redstone_wire replace
fill ~120 ~63 ~540 ~120 ~63 ~552 minecraft:redstone_wire replace
fill ~138 ~63 ~540 ~138 ~63 ~552 minecraft:redstone_wire replace
fill ~162 ~63 ~540 ~162 ~63 ~552 minecraft:redstone_wire replace
fill ~105 ~63 ~548 ~105 ~63 ~552 minecraft:redstone_wire replace
fill ~126 ~63 ~552 ~126 ~63 ~556 minecraft:redstone_wire replace
setblock ~81 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~554 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~556 ~81 ~63 ~568 minecraft:redstone_wire replace
fill ~102 ~63 ~556 ~102 ~63 ~568 minecraft:redstone_wire replace
fill ~120 ~63 ~556 ~120 ~63 ~568 minecraft:redstone_wire replace
fill ~138 ~63 ~556 ~138 ~63 ~568 minecraft:redstone_wire replace
fill ~144 ~63 ~556 ~144 ~63 ~560 minecraft:redstone_wire replace
fill ~162 ~63 ~556 ~162 ~63 ~568 minecraft:redstone_wire replace
fill ~171 ~63 ~560 ~171 ~63 ~564 minecraft:redstone_wire replace
fill ~195 ~63 ~564 ~195 ~63 ~568 minecraft:redstone_wire replace
setblock ~81 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~570 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~572 ~81 ~63 ~584 minecraft:redstone_wire replace
fill ~102 ~63 ~572 ~102 ~63 ~584 minecraft:redstone_wire replace
fill ~120 ~63 ~572 ~120 ~63 ~584 minecraft:redstone_wire replace
fill ~138 ~63 ~572 ~138 ~63 ~584 minecraft:redstone_wire replace
fill ~162 ~63 ~572 ~162 ~63 ~584 minecraft:redstone_wire replace
setblock ~81 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~586 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~588 ~81 ~63 ~600 minecraft:redstone_wire replace
fill ~99 ~63 ~588 ~99 ~63 ~592 minecraft:redstone_wire replace
fill ~102 ~63 ~588 ~102 ~63 ~600 minecraft:redstone_wire replace
fill ~120 ~63 ~588 ~120 ~63 ~600 minecraft:redstone_wire replace
fill ~138 ~63 ~588 ~138 ~63 ~600 minecraft:redstone_wire replace
fill ~162 ~63 ~588 ~162 ~63 ~600 minecraft:redstone_wire replace
fill ~123 ~63 ~592 ~123 ~63 ~596 minecraft:redstone_wire replace
fill ~141 ~63 ~596 ~141 ~63 ~600 minecraft:redstone_wire replace
fill ~168 ~63 ~600 ~168 ~63 ~604 minecraft:redstone_wire replace
setblock ~81 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~602 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~604 ~81 ~63 ~616 minecraft:redstone_wire replace
fill ~102 ~63 ~604 ~102 ~63 ~616 minecraft:redstone_wire replace
fill ~120 ~63 ~604 ~120 ~63 ~616 minecraft:redstone_wire replace
fill ~138 ~63 ~604 ~138 ~63 ~616 minecraft:redstone_wire replace
fill ~162 ~63 ~604 ~162 ~63 ~616 minecraft:redstone_wire replace
fill ~192 ~63 ~604 ~192 ~63 ~608 minecraft:redstone_wire replace
fill ~84 ~63 ~608 ~84 ~63 ~612 minecraft:redstone_wire replace
fill ~87 ~63 ~612 ~87 ~63 ~616 minecraft:redstone_wire replace
fill ~90 ~63 ~616 ~90 ~63 ~620 minecraft:redstone_wire replace
setblock ~81 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~618 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~620 ~81 ~63 ~632 minecraft:redstone_wire replace
fill ~93 ~63 ~620 ~93 ~63 ~624 minecraft:redstone_wire replace
fill ~102 ~63 ~620 ~102 ~63 ~632 minecraft:redstone_wire replace
fill ~120 ~63 ~620 ~120 ~63 ~632 minecraft:redstone_wire replace
fill ~138 ~63 ~620 ~138 ~63 ~632 minecraft:redstone_wire replace
fill ~162 ~63 ~620 ~162 ~63 ~632 minecraft:redstone_wire replace
fill ~96 ~63 ~624 ~96 ~63 ~628 minecraft:redstone_wire replace
fill ~117 ~63 ~628 ~117 ~63 ~632 minecraft:redstone_wire replace
fill ~147 ~63 ~632 ~147 ~63 ~636 minecraft:redstone_wire replace
setblock ~81 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~102 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~138 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~162 ~63 ~634 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
fill ~81 ~63 ~636 ~81 ~63 ~648 minecraft:redstone_wire replace
fill ~102 ~63 ~636 ~102 ~63 ~648 minecraft:redstone_wire replace
fill ~120 ~63 ~636 ~120 ~63 ~648 minecraft:redstone_wire replace
fill ~138 ~63 ~636 ~138 ~63 ~648 minecraft:redstone_wire replace
fill ~159 ~63 ~636 ~159 ~63 ~640 minecraft:redstone_wire replace
fill ~162 ~63 ~636 ~162 ~63 ~648 minecraft:redstone_wire replace
fill ~180 ~63 ~640 ~180 ~63 ~644 minecraft:redstone_wire replace
fill ~198 ~63 ~644 ~198 ~63 ~648 minecraft:redstone_wire replace
fill ~216 ~63 ~648 ~216 ~63 ~652 minecraft:redstone_wire replace
fill ~78 ~63 ~652 ~78 ~63 ~656 minecraft:redstone_wire replace
fill ~183 ~63 ~656 ~183 ~63 ~660 minecraft:redstone_wire replace
fill ~213 ~63 ~660 ~213 ~63 ~664 minecraft:redstone_wire replace
setblock ~102 ~64 ~327 minecraft:redstone_wire replace
setblock ~120 ~64 ~343 minecraft:redstone_wire replace
setblock ~162 ~64 ~359 minecraft:redstone_wire replace
setblock ~138 ~64 ~375 minecraft:redstone_wire replace
setblock ~210 ~64 ~379 minecraft:redstone_wire replace
setblock ~207 ~64 ~383 minecraft:redstone_wire replace
setblock ~189 ~64 ~387 minecraft:redstone_wire replace
setblock ~186 ~64 ~391 minecraft:redstone_wire replace
setblock ~81 ~64 ~395 minecraft:redstone_wire replace
setblock ~114 ~64 ~431 minecraft:redstone_wire replace
setblock ~135 ~64 ~435 minecraft:redstone_wire replace
setblock ~156 ~64 ~439 minecraft:redstone_wire replace
setblock ~165 ~64 ~443 minecraft:redstone_wire replace
setblock ~111 ~64 ~467 minecraft:redstone_wire replace
setblock ~132 ~64 ~471 minecraft:redstone_wire replace
setblock ~153 ~64 ~475 minecraft:redstone_wire replace
setblock ~177 ~64 ~479 minecraft:redstone_wire replace
setblock ~204 ~64 ~483 minecraft:redstone_wire replace
setblock ~108 ~64 ~507 minecraft:redstone_wire replace
setblock ~129 ~64 ~511 minecraft:redstone_wire replace
setblock ~150 ~64 ~515 minecraft:redstone_wire replace
setblock ~174 ~64 ~519 minecraft:redstone_wire replace
setblock ~201 ~64 ~523 minecraft:redstone_wire replace
setblock ~105 ~64 ~547 minecraft:redstone_wire replace
setblock ~126 ~64 ~551 minecraft:redstone_wire replace
setblock ~144 ~64 ~555 minecraft:redstone_wire replace
setblock ~171 ~64 ~559 minecraft:redstone_wire replace
setblock ~195 ~64 ~563 minecraft:redstone_wire replace
setblock ~99 ~64 ~587 minecraft:redstone_wire replace
setblock ~123 ~64 ~591 minecraft:redstone_wire replace
setblock ~141 ~64 ~595 minecraft:redstone_wire replace
setblock ~168 ~64 ~599 minecraft:redstone_wire replace
setblock ~192 ~64 ~603 minecraft:redstone_wire replace
setblock ~84 ~64 ~607 minecraft:redstone_wire replace
setblock ~87 ~64 ~611 minecraft:redstone_wire replace
setblock ~90 ~64 ~615 minecraft:redstone_wire replace
setblock ~93 ~64 ~619 minecraft:redstone_wire replace
setblock ~96 ~64 ~623 minecraft:redstone_wire replace
setblock ~117 ~64 ~627 minecraft:redstone_wire replace
setblock ~147 ~64 ~631 minecraft:redstone_wire replace
setblock ~159 ~64 ~635 minecraft:redstone_wire replace
setblock ~180 ~64 ~639 minecraft:redstone_wire replace
setblock ~198 ~64 ~643 minecraft:redstone_wire replace
setblock ~216 ~64 ~647 minecraft:redstone_wire replace
setblock ~78 ~64 ~651 minecraft:redstone_wire replace
setblock ~183 ~64 ~655 minecraft:redstone_wire replace
setblock ~213 ~64 ~659 minecraft:redstone_wire replace
setblock ~97 ~65 ~325 minecraft:redstone_wire replace
fill ~96 ~65 ~326 ~102 ~65 ~326 minecraft:redstone_wire replace
setblock ~100 ~65 ~341 minecraft:redstone_wire replace
fill ~99 ~65 ~342 ~107 ~65 ~342 minecraft:redstone_wire replace
setblock ~109 ~65 ~342 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~65 ~342 ~120 ~65 ~342 minecraft:redstone_wire replace
setblock ~106 ~65 ~357 minecraft:redstone_wire replace
fill ~105 ~65 ~358 ~115 ~65 ~358 minecraft:redstone_wire replace
setblock ~117 ~65 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~119 ~65 ~358 ~132 ~65 ~358 minecraft:redstone_wire replace
setblock ~134 ~65 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~136 ~65 ~358 ~149 ~65 ~358 minecraft:redstone_wire replace
setblock ~151 ~65 ~358 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~153 ~65 ~358 ~162 ~65 ~358 minecraft:redstone_wire replace
setblock ~103 ~65 ~373 minecraft:redstone_wire replace
fill ~102 ~65 ~374 ~108 ~65 ~374 minecraft:redstone_wire replace
setblock ~110 ~65 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~65 ~374 ~125 ~65 ~374 minecraft:redstone_wire replace
setblock ~127 ~65 ~374 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~65 ~374 ~138 ~65 ~374 minecraft:redstone_wire replace
setblock ~133 ~65 ~377 minecraft:redstone_wire replace
fill ~132 ~65 ~378 ~133 ~65 ~378 minecraft:redstone_wire replace
setblock ~134 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~65 ~378 ~148 ~65 ~378 minecraft:redstone_wire replace
setblock ~150 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~152 ~65 ~378 ~165 ~65 ~378 minecraft:redstone_wire replace
setblock ~167 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~169 ~65 ~378 ~182 ~65 ~378 minecraft:redstone_wire replace
setblock ~184 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~186 ~65 ~378 ~199 ~65 ~378 minecraft:redstone_wire replace
setblock ~201 ~65 ~378 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~203 ~65 ~378 ~210 ~65 ~378 minecraft:redstone_wire replace
setblock ~133 ~65 ~381 minecraft:redstone_wire replace
fill ~132 ~65 ~382 ~141 ~65 ~382 minecraft:redstone_wire replace
setblock ~143 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~65 ~382 ~158 ~65 ~382 minecraft:redstone_wire replace
setblock ~160 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~162 ~65 ~382 ~175 ~65 ~382 minecraft:redstone_wire replace
setblock ~177 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~179 ~65 ~382 ~192 ~65 ~382 minecraft:redstone_wire replace
setblock ~194 ~65 ~382 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~196 ~65 ~382 ~207 ~65 ~382 minecraft:redstone_wire replace
setblock ~115 ~65 ~385 minecraft:redstone_wire replace
fill ~114 ~65 ~386 ~123 ~65 ~386 minecraft:redstone_wire replace
setblock ~125 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~65 ~386 ~140 ~65 ~386 minecraft:redstone_wire replace
setblock ~142 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~65 ~386 ~157 ~65 ~386 minecraft:redstone_wire replace
setblock ~159 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~65 ~386 ~174 ~65 ~386 minecraft:redstone_wire replace
setblock ~176 ~65 ~386 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~65 ~386 ~189 ~65 ~386 minecraft:redstone_wire replace
setblock ~115 ~65 ~389 minecraft:redstone_wire replace
fill ~114 ~65 ~390 ~119 ~65 ~390 minecraft:redstone_wire replace
setblock ~121 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~390 ~136 ~65 ~390 minecraft:redstone_wire replace
setblock ~138 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~140 ~65 ~390 ~153 ~65 ~390 minecraft:redstone_wire replace
setblock ~155 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~157 ~65 ~390 ~170 ~65 ~390 minecraft:redstone_wire replace
setblock ~172 ~65 ~390 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~174 ~65 ~390 ~186 ~65 ~390 minecraft:redstone_wire replace
setblock ~82 ~65 ~393 minecraft:redstone_wire replace
fill ~81 ~65 ~394 ~83 ~65 ~394 minecraft:redstone_wire replace
setblock ~97 ~65 ~429 minecraft:redstone_wire replace
fill ~96 ~65 ~430 ~104 ~65 ~430 minecraft:redstone_wire replace
setblock ~106 ~65 ~430 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~65 ~430 ~114 ~65 ~430 minecraft:redstone_wire replace
setblock ~100 ~65 ~433 minecraft:redstone_wire replace
fill ~99 ~65 ~434 ~108 ~65 ~434 minecraft:redstone_wire replace
setblock ~110 ~65 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~112 ~65 ~434 ~125 ~65 ~434 minecraft:redstone_wire replace
setblock ~127 ~65 ~434 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~129 ~65 ~434 ~135 ~65 ~434 minecraft:redstone_wire replace
setblock ~103 ~65 ~437 minecraft:redstone_wire replace
fill ~102 ~65 ~438 ~112 ~65 ~438 minecraft:redstone_wire replace
setblock ~114 ~65 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~116 ~65 ~438 ~129 ~65 ~438 minecraft:redstone_wire replace
setblock ~131 ~65 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~133 ~65 ~438 ~146 ~65 ~438 minecraft:redstone_wire replace
setblock ~148 ~65 ~438 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~150 ~65 ~438 ~156 ~65 ~438 minecraft:redstone_wire replace
setblock ~106 ~65 ~441 minecraft:redstone_wire replace
fill ~105 ~65 ~442 ~106 ~65 ~442 minecraft:redstone_wire replace
setblock ~107 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~108 ~65 ~442 ~121 ~65 ~442 minecraft:redstone_wire replace
setblock ~123 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~125 ~65 ~442 ~138 ~65 ~442 minecraft:redstone_wire replace
setblock ~140 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~142 ~65 ~442 ~155 ~65 ~442 minecraft:redstone_wire replace
setblock ~157 ~65 ~442 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~159 ~65 ~442 ~165 ~65 ~442 minecraft:redstone_wire replace
setblock ~97 ~65 ~465 minecraft:redstone_wire replace
fill ~96 ~65 ~466 ~101 ~65 ~466 minecraft:redstone_wire replace
setblock ~103 ~65 ~466 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~105 ~65 ~466 ~111 ~65 ~466 minecraft:redstone_wire replace
setblock ~100 ~65 ~469 minecraft:redstone_wire replace
fill ~99 ~65 ~470 ~105 ~65 ~470 minecraft:redstone_wire replace
setblock ~107 ~65 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~109 ~65 ~470 ~122 ~65 ~470 minecraft:redstone_wire replace
setblock ~124 ~65 ~470 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~126 ~65 ~470 ~132 ~65 ~470 minecraft:redstone_wire replace
setblock ~103 ~65 ~473 minecraft:redstone_wire replace
fill ~102 ~65 ~474 ~109 ~65 ~474 minecraft:redstone_wire replace
setblock ~111 ~65 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~113 ~65 ~474 ~126 ~65 ~474 minecraft:redstone_wire replace
setblock ~128 ~65 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~65 ~474 ~143 ~65 ~474 minecraft:redstone_wire replace
setblock ~145 ~65 ~474 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~65 ~474 ~153 ~65 ~474 minecraft:redstone_wire replace
setblock ~106 ~65 ~477 minecraft:redstone_wire replace
fill ~105 ~65 ~478 ~116 ~65 ~478 minecraft:redstone_wire replace
setblock ~118 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~65 ~478 ~133 ~65 ~478 minecraft:redstone_wire replace
setblock ~135 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~137 ~65 ~478 ~150 ~65 ~478 minecraft:redstone_wire replace
setblock ~152 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~154 ~65 ~478 ~167 ~65 ~478 minecraft:redstone_wire replace
setblock ~169 ~65 ~478 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~171 ~65 ~478 ~177 ~65 ~478 minecraft:redstone_wire replace
setblock ~130 ~65 ~481 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~129 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~130 ~65 ~482 ~143 ~65 ~482 minecraft:redstone_wire replace
setblock ~145 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~147 ~65 ~482 ~160 ~65 ~482 minecraft:redstone_wire replace
setblock ~162 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~164 ~65 ~482 ~177 ~65 ~482 minecraft:redstone_wire replace
setblock ~179 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~181 ~65 ~482 ~194 ~65 ~482 minecraft:redstone_wire replace
setblock ~196 ~65 ~482 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~198 ~65 ~482 ~204 ~65 ~482 minecraft:redstone_wire replace
setblock ~97 ~65 ~505 minecraft:redstone_wire replace
fill ~96 ~65 ~506 ~98 ~65 ~506 minecraft:redstone_wire replace
setblock ~100 ~65 ~506 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~102 ~65 ~506 ~108 ~65 ~506 minecraft:redstone_wire replace
setblock ~100 ~65 ~509 minecraft:redstone_wire replace
fill ~99 ~65 ~510 ~102 ~65 ~510 minecraft:redstone_wire replace
setblock ~104 ~65 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~106 ~65 ~510 ~119 ~65 ~510 minecraft:redstone_wire replace
setblock ~121 ~65 ~510 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~510 ~129 ~65 ~510 minecraft:redstone_wire replace
setblock ~103 ~65 ~513 minecraft:redstone_wire replace
fill ~102 ~65 ~514 ~106 ~65 ~514 minecraft:redstone_wire replace
setblock ~108 ~65 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~110 ~65 ~514 ~123 ~65 ~514 minecraft:redstone_wire replace
setblock ~125 ~65 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~65 ~514 ~140 ~65 ~514 minecraft:redstone_wire replace
setblock ~142 ~65 ~514 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~65 ~514 ~150 ~65 ~514 minecraft:redstone_wire replace
setblock ~106 ~65 ~517 minecraft:redstone_wire replace
fill ~105 ~65 ~518 ~113 ~65 ~518 minecraft:redstone_wire replace
setblock ~115 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~65 ~518 ~130 ~65 ~518 minecraft:redstone_wire replace
setblock ~132 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~134 ~65 ~518 ~147 ~65 ~518 minecraft:redstone_wire replace
setblock ~149 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~151 ~65 ~518 ~164 ~65 ~518 minecraft:redstone_wire replace
setblock ~166 ~65 ~518 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~168 ~65 ~518 ~174 ~65 ~518 minecraft:redstone_wire replace
setblock ~127 ~65 ~521 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~126 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~127 ~65 ~522 ~140 ~65 ~522 minecraft:redstone_wire replace
setblock ~142 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~144 ~65 ~522 ~157 ~65 ~522 minecraft:redstone_wire replace
setblock ~159 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~161 ~65 ~522 ~174 ~65 ~522 minecraft:redstone_wire replace
setblock ~176 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~178 ~65 ~522 ~191 ~65 ~522 minecraft:redstone_wire replace
setblock ~193 ~65 ~522 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~195 ~65 ~522 ~201 ~65 ~522 minecraft:redstone_wire replace
setblock ~97 ~65 ~545 minecraft:redstone_wire replace
fill ~96 ~65 ~546 ~97 ~65 ~546 minecraft:redstone_wire replace
setblock ~98 ~65 ~546 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~99 ~65 ~546 ~105 ~65 ~546 minecraft:redstone_wire replace
setblock ~100 ~65 ~549 minecraft:redstone_wire replace
fill ~99 ~65 ~550 ~101 ~65 ~550 minecraft:redstone_wire replace
setblock ~102 ~65 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~103 ~65 ~550 ~116 ~65 ~550 minecraft:redstone_wire replace
setblock ~118 ~65 ~550 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~120 ~65 ~550 ~126 ~65 ~550 minecraft:redstone_wire replace
setblock ~103 ~65 ~553 minecraft:redstone_wire replace
fill ~102 ~65 ~554 ~103 ~65 ~554 minecraft:redstone_wire replace
setblock ~105 ~65 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~107 ~65 ~554 ~119 ~65 ~554 minecraft:redstone_wire replace
setblock ~121 ~65 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~123 ~65 ~554 ~135 ~65 ~554 minecraft:redstone_wire replace
setblock ~137 ~65 ~554 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~139 ~65 ~554 ~144 ~65 ~554 minecraft:redstone_wire replace
setblock ~106 ~65 ~557 minecraft:redstone_wire replace
fill ~105 ~65 ~558 ~110 ~65 ~558 minecraft:redstone_wire replace
setblock ~112 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~114 ~65 ~558 ~127 ~65 ~558 minecraft:redstone_wire replace
setblock ~129 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~131 ~65 ~558 ~144 ~65 ~558 minecraft:redstone_wire replace
setblock ~146 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~148 ~65 ~558 ~161 ~65 ~558 minecraft:redstone_wire replace
setblock ~163 ~65 ~558 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~165 ~65 ~558 ~171 ~65 ~558 minecraft:redstone_wire replace
setblock ~121 ~65 ~561 minecraft:repeater[delay=4,facing=south,locked=false,powered=false] replace
setblock ~120 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~121 ~65 ~562 ~134 ~65 ~562 minecraft:redstone_wire replace
setblock ~136 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~138 ~65 ~562 ~151 ~65 ~562 minecraft:redstone_wire replace
setblock ~153 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~155 ~65 ~562 ~168 ~65 ~562 minecraft:redstone_wire replace
setblock ~170 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~172 ~65 ~562 ~185 ~65 ~562 minecraft:redstone_wire replace
setblock ~187 ~65 ~562 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~189 ~65 ~562 ~195 ~65 ~562 minecraft:redstone_wire replace
setblock ~97 ~65 ~585 minecraft:redstone_wire replace
fill ~96 ~65 ~586 ~99 ~65 ~586 minecraft:redstone_wire replace
setblock ~100 ~65 ~589 minecraft:redstone_wire replace
setblock ~99 ~65 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~100 ~65 ~590 ~113 ~65 ~590 minecraft:redstone_wire replace
setblock ~115 ~65 ~590 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~117 ~65 ~590 ~123 ~65 ~590 minecraft:redstone_wire replace
setblock ~103 ~65 ~593 minecraft:redstone_wire replace
fill ~102 ~65 ~594 ~114 ~65 ~594 minecraft:redstone_wire replace
setblock ~116 ~65 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~118 ~65 ~594 ~131 ~65 ~594 minecraft:redstone_wire replace
setblock ~133 ~65 ~594 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~135 ~65 ~594 ~141 ~65 ~594 minecraft:redstone_wire replace
setblock ~106 ~65 ~597 minecraft:redstone_wire replace
fill ~105 ~65 ~598 ~107 ~65 ~598 minecraft:redstone_wire replace
setblock ~109 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~111 ~65 ~598 ~124 ~65 ~598 minecraft:redstone_wire replace
setblock ~126 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~128 ~65 ~598 ~141 ~65 ~598 minecraft:redstone_wire replace
setblock ~143 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
fill ~145 ~65 ~598 ~158 ~65 ~598 minecraft:redstone_wire replace
setblock ~160 ~65 ~598 minecraft:repeater[delay=4,facing=east,locked=false,powered=false] replace
