$execute positioned $(x) $(y) $(z) run function rscalc:sys/unload_tiles
