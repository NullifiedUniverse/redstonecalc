scoreboard players set #run rscalc_v 0
bossbar remove rscalc:progress
execute as @e[type=marker,tag=rscalc_anchor,limit=1] at @s run function rscalc:sys/signs
function rscalc:load
execute as @a at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2
tellraw @a {"text":"rscalc_mk3_10bit placed: 456,558 blocks, 555 x 195 x 973. /function rscalc:help for what to do next.","color":"green"}
title @a actionbar {"text":"rscalc_mk3_10bit: placed","color":"green"}
