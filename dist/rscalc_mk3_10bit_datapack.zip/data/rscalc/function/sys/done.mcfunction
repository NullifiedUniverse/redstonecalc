scoreboard players set #run rscalc_v 0
tellraw @a {"text":"rscalc_mk3_10bit placed: 71,768 blocks, 555 x 195 x 973. /function rscalc:help for what to do next.","color":"green"}
title @a actionbar {"text":"rscalc_mk3_10bit: placed","color":"green"}
