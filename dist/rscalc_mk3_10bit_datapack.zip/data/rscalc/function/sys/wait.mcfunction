scoreboard players set #loaded rscalc_v 0
execute as @e[type=marker,tag=rscalc_anchor,limit=1] at @s run function rscalc:sys/probe
scoreboard players add #wait rscalc_v 1
execute if score #loaded rscalc_v matches 2135.. run function rscalc:sys/go
execute if score #loaded rscalc_v matches ..2134 run function rscalc:sys/waiting
