$tellraw @a {"text":"rscalc_mk3_10bit: built at $(x) $(y) $(z), 555 x 195 x 973, 71,768 blocks in 2135 force-loaded chunks.","color":"green"}
