$execute positioned $(x) $(y) $(z) run tp @s ~558 ~193 ~8
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.4 1.4
tellraw @s {"text":"rscalc_mk3_10bit: display","color":"gray"}
