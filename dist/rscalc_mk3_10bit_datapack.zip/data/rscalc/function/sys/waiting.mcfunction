execute store result storage rscalc:ui loaded int 1 run scoreboard players get #loaded rscalc_v
function rscalc:sys/wait_bar with storage rscalc:ui
execute if score #wait rscalc_v matches ..12000 run schedule function rscalc:sys/wait 1t replace
execute if score #wait rscalc_v matches 12001.. run function rscalc:sys/wait_gave_up
