$tellraw @a {"text":"rscalc_mk3_10bit: clearing — layer $(layer) of 195.","color":"yellow"}
