$title @a actionbar {"text":"rscalc_mk3_10bit: placing part $(part) of 120","color":"gray"}
$bossbar set rscalc:progress value $(part)
$execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 0.22 $(pitch)
