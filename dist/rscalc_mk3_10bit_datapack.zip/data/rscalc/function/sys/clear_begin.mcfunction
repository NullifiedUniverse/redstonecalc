kill @e[type=marker,tag=rscalc_anchor_clear]
summon marker ~ ~ ~ {Tags:["rscalc_anchor_clear"]}
tellraw @a {"text":"rscalc_mk3_10bit: clearing 195 layers (9.8s)...","color":"gray"}
function rscalc:sys/clear_tick
