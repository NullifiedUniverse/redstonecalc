# 35 x 61 = 2135 chunks, 12 commands (256 chunks each is the cap).
forceload add ~0 ~0 ~255 ~255
forceload add ~0 ~256 ~255 ~511
forceload add ~0 ~512 ~255 ~767
forceload add ~0 ~768 ~255 ~972
forceload add ~256 ~0 ~511 ~255
forceload add ~256 ~256 ~511 ~511
forceload add ~256 ~512 ~511 ~767
forceload add ~256 ~768 ~511 ~972
forceload add ~512 ~0 ~554 ~255
forceload add ~512 ~256 ~554 ~511
forceload add ~512 ~512 ~554 ~767
forceload add ~512 ~768 ~554 ~972
tellraw @a {"text":"rscalc_mk3_10bit: 2135 chunks force-loaded. They take a moment to arrive — nothing is placed until they have.","color":"green"}
