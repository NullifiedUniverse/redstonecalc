scoreboard objectives add rscalc_v dummy
execute if score #keep rscalc_v matches 1 if data storage rscalc:origin x run function rscalc:sys/load_at with storage rscalc:origin
