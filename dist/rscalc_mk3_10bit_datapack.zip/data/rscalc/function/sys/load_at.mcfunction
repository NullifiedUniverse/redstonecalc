$execute positioned $(x) $(y) $(z) run function rscalc:sys/load_tiles
