$execute positioned $(x) $(y) $(z) run tp @s ~0 ~0 ~0
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.4 1.4
tellraw @s {"text":"rscalc_mk3_10bit: origin","color":"gray"}
