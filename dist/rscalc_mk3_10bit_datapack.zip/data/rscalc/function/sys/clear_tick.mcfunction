execute as @e[type=marker,tag=rscalc_anchor_clear,limit=1] at @s run function rscalc:sys/clear_slice
execute as @e[type=marker,tag=rscalc_anchor_clear,limit=1] at @s run tp @s ~ ~1 ~
scoreboard players add #clear rscalc_v 1
execute store result storage rscalc:ui layer int 1 run scoreboard players get #clear rscalc_v
function rscalc:sys/clear_bar with storage rscalc:ui
execute if score #clear rscalc_v matches ..194 run schedule function rscalc:sys/clear_tick 1t replace
execute if score #clear rscalc_v matches 195.. run function rscalc:sys/clear_done
