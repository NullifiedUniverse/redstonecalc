$tellraw @a {"text":"rscalc_mk3_10bit: working — part $(part) of 36.","color":"yellow"}
