forceload remove ~0 ~0 ~255 ~255
forceload remove ~0 ~256 ~255 ~511
forceload remove ~0 ~512 ~255 ~767
forceload remove ~0 ~768 ~255 ~972
forceload remove ~256 ~0 ~511 ~255
forceload remove ~256 ~256 ~511 ~511
forceload remove ~256 ~512 ~511 ~767
forceload remove ~256 ~768 ~511 ~972
forceload remove ~512 ~0 ~554 ~255
forceload remove ~512 ~256 ~554 ~511
forceload remove ~512 ~512 ~554 ~767
forceload remove ~512 ~768 ~554 ~972
tellraw @a {"text":"rscalc_mk3_10bit: chunks released. The machine stops ticking away from you.","color":"gray"}
