scoreboard players set #run rscalc_v 0
bossbar remove rscalc:progress
tellraw @a {"text":"rscalc_mk3_10bit: gave up waiting for chunks after 10 minutes. Nothing has been placed. The server may be struggling; try again, or reduce the view distance and retry.","color":"red"}
