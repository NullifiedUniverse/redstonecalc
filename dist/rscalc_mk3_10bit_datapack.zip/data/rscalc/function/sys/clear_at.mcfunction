$execute positioned $(x) $(y) $(z) run function rscalc:sys/clear_begin
