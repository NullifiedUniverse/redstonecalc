tellraw @a {"text":"rscalc_mk3_10bit: 2135 chunks loaded. Placing.","color":"green"}
function rscalc:tick
