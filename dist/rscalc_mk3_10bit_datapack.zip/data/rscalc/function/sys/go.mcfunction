tellraw @a {"text":"rscalc_mk3_10bit: 2135 chunks loaded. Placing.","color":"green"}
bossbar set rscalc:progress color green
bossbar set rscalc:progress name "rscalc_mk3_10bit: placing blocks"
bossbar set rscalc:progress max 120
bossbar set rscalc:progress value 0
function rscalc:tick
