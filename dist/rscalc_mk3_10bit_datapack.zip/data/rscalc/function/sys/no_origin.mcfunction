tellraw @a {"text":"rscalc_mk3_10bit: nothing built yet — no origin on record. Stand at the -X -Y -Z corner and run /function rscalc:build.","color":"red"}
