$execute positioned $(x) $(y) $(z) run tp @s ~59 ~1 ~107
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.4 1.4
tellraw @s {"text":"rscalc_mk3_10bit: controls","color":"gray"}
