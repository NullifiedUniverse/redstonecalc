$schedule function rscalc:tick $(pace)t replace
