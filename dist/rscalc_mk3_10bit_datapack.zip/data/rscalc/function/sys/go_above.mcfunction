$execute positioned $(x) $(y) $(z) run tp @s ~277 ~207 ~486
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.4 1.4
tellraw @s {"text":"rscalc_mk3_10bit: above","color":"gray"}
