$tellraw @a {"text":"rscalc_mk3_10bit: $(loaded) of 2135 chunks are loaded and ticking right now.","color":"aqua"}
