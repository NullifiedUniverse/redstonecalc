kill @e[type=marker,tag=rscalc_anchor_clear]
kill @e[type=marker,tag=rscalc_anchor]
function rscalc:unload
data remove storage rscalc:origin x
data remove storage rscalc:origin y
data remove storage rscalc:origin z
scoreboard players set #run rscalc_v 0
tellraw @a {"text":"rscalc_mk3_10bit removed: 195 layers, chunks released.","color":"gray"}
title @a actionbar {"text":"rscalc_mk3_10bit: removed","color":"gray"}
