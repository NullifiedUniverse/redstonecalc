execute unless data storage rscalc:origin x run function rscalc:sys/no_origin
execute unless data storage rscalc:origin x run return fail
function rscalc:sys/go_origin with storage rscalc:origin
