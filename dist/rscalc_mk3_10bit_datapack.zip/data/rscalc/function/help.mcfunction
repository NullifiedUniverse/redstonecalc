tellraw @s {"text":"rscalc — the machine, and getting around it","color":"white"}
tellraw @s {"text":"  /function rscalc:build  — place it, from the -X -Y -Z corner","color":"gray"}
tellraw @s {"text":"  /function rscalc:clear  — take it away again, from anywhere","color":"gray"}
tellraw @s {"text":"  /function rscalc:status  — where it is and what it is doing","color":"gray"}
tellraw @s {"text":"  /function rscalc:load  — force-load its chunks so it ticks","color":"gray"}
tellraw @s {"text":"  /function rscalc:unload  — release them again","color":"gray"}
tellraw @s {"text":"  /function rscalc:abort  — stop a build or clear part way","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/above  — look down on the whole machine from the air","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/controls  — the labelled lever wall — set A, B and the operation here","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/display  — the seven-segment readout, at the far end","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/origin  — the -X -Y -Z corner the build was placed from","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/gear  — hook, dash charm and recall compass — start here","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/mark  — remember where you are standing","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/hover  — stop taking fall damage while you look around","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/unstick  — if the hook ever leaves you riding something","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/off  — put the gadgets away","color":"gray"}
tellraw @s {"text":"  To watch it go up slowly: /scoreboard players set #pace rscalc_v 4 before /function rscalc:build — that is ticks per batch, so 4 makes the 120 batches take 24 seconds instead of 6.","color":"dark_gray"}
tellraw @s {"text":"  Each of the 28 controls has a sign beside it saying which bit or operation it is. /function rscalc:go/controls puts you in front of them.","color":"dark_gray"}
tellraw @s {"text":"  Cast the rod to grapple — it pulls while the bobber is out and lets go when you reel in. The charm dashes 5 blocks where you look. Both leave you with slow falling.","color":"gray"}
