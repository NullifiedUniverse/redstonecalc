tellraw @s {"text":"rscalc — the machine, and getting around it","color":"white"}
tellraw @s {"text":"  /function rscalc:build  — place it, from the -X -Y -Z corner","color":"gray"}
tellraw @s {"text":"  /function rscalc:clear  — take it away again, from anywhere","color":"gray"}
tellraw @s {"text":"  /function rscalc:status  — where it is and what it is doing","color":"gray"}
tellraw @s {"text":"  /function rscalc:load  — force-load its chunks so it ticks","color":"gray"}
tellraw @s {"text":"  /function rscalc:unload  — release them again","color":"gray"}
tellraw @s {"text":"  /function rscalc:abort  — stop a build or clear part way","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/above  — teleport to the above","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/controls  — teleport to the controls","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/display  — teleport to the display","color":"gray"}
tellraw @s {"text":"  /function rscalc:go/origin  — teleport to the origin","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/gear  — hook, dash charm and recall compass — start here","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/mark  — remember where you are standing","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/hover  — stop taking fall damage while you look around","color":"gray"}
tellraw @s {"text":"  /function rscalc:move/off  — put the gadgets away","color":"gray"}
tellraw @s {"text":"  Cast the rod to grapple — it pulls while the bobber is out and lets go when you reel in. The charm dashes 5 blocks where you look. Both leave you with slow falling.","color":"gray"}
