scoreboard objectives add rscalc_v dummy
execute unless data storage rscalc:origin x run function rscalc:sys/no_origin
execute if data storage rscalc:origin x run function rscalc:sys/status_show with storage rscalc:origin
execute if score #run rscalc_v matches 1 if data storage rscalc:ui part run function rscalc:sys/status_build with storage rscalc:ui
execute if score #run rscalc_v matches 1 if data storage rscalc:ui layer run function rscalc:sys/status_clear with storage rscalc:ui
execute if data storage rscalc:origin x unless entity @e[type=marker,tag=rscalc_anchor] run function rscalc:sys/status_lost
