# Removes the machine wherever it was built. Run it from anywhere.
scoreboard objectives add rscalc_v dummy
execute if score #run rscalc_v matches 1 run function rscalc:sys/busy
execute if score #run rscalc_v matches 1 run return fail
execute unless data storage rscalc:origin x run function rscalc:sys/no_origin
execute unless data storage rscalc:origin x run return fail
scoreboard players set #run rscalc_v 1
scoreboard players set #clear rscalc_v 0
scoreboard players set #wait rscalc_v 0
data remove storage rscalc:ui part
function rscalc:load
function rscalc:sys/clear_wait
