tellraw @s {"text":"no mark yet — /function rscalc:move/mark where you want to come back to.","color":"red"}
