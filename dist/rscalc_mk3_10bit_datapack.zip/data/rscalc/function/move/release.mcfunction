scoreboard players set @s rscalc_speed 0
