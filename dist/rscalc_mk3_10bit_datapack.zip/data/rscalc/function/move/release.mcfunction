scoreboard players set @s rscalc_speed 0
execute on vehicle if entity @s[tag=rscalc_ride] run kill @s
tag @s remove rscalc_hooked
