scoreboard players set @s rscalc_speed 0
ride @s dismount
kill @e[type=armor_stand,tag=rscalc_ride,distance=..6]
