scoreboard players set #has rscalc_vec 0
execute on passengers run scoreboard players set #has rscalc_vec 1
execute if score #has rscalc_vec matches 0 run kill @s
