$execute on vehicle at @s facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet run tp @s ^ ^ ^$(d)
