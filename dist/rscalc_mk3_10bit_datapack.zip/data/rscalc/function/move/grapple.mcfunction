execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] run function rscalc:move/release
execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] run return fail
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.5] run function rscalc:move/arrive
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.5] run return fail
execute at @s facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^1 unless block ~ ~ ~ #rscalc:passable run function rscalc:move/arrive
execute at @s facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^1 unless block ~ ~ ~ #rscalc:passable run return fail
scoreboard players set @s rscalc_fall 60
execute unless entity @e[type=armor_stand,tag=rscalc_ride,distance=..3] run function rscalc:move/mount
scoreboard players add @s rscalc_speed 12
execute if score @s rscalc_speed matches 90.. run scoreboard players set @s rscalc_speed 90
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..8] if score @s rscalc_speed matches 41.. run scoreboard players set @s rscalc_speed 40
execute at @s facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^1 run summon marker ~ ~ ~ {Tags:["rscalc_aim"]}
function rscalc:move/thrust
kill @e[type=marker,tag=rscalc_aim]
function rscalc:move/rope
