execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] run function rscalc:move/release
execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] run return fail
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.5] run function rscalc:move/arrive
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.5] run return fail
scoreboard players set @s rscalc_fall 60
scoreboard players add @s rscalc_speed 12
execute if score @s rscalc_speed matches 90.. run scoreboard players set @s rscalc_speed 90
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..8] if score @s rscalc_speed matches 41.. run scoreboard players set @s rscalc_speed 40
execute store result storage rscalc:move d double 0.01 run scoreboard players get @s rscalc_speed
function rscalc:move/step with storage rscalc:move
function rscalc:move/rope
