execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] if entity @s[tag=rscalc_hooked] run function rscalc:move/release
execute unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] run return fail
execute unless entity @s[tag=rscalc_hooked] unless entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96,nbt={OnGround:1b}] run return fail
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.5] run function rscalc:move/arrive
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..2.5] run return fail
scoreboard players set #free rscalc_vec 1
execute at @s facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^1 unless block ~ ~ ~ #rscalc:passable run scoreboard players set #free rscalc_vec 0
execute at @s facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^1 unless block ~ ~1 ~ #rscalc:passable run scoreboard players set #free rscalc_vec 0
execute if score #free rscalc_vec matches 0 run function rscalc:move/arrive
execute if score #free rscalc_vec matches 0 run return fail
scoreboard players set @s rscalc_fall 60
execute unless entity @s[tag=rscalc_hooked] run function rscalc:move/mount
scoreboard players set #riding rscalc_vec 0
execute on vehicle if entity @s[tag=rscalc_ride] run scoreboard players set #riding rscalc_vec 1
execute if score #riding rscalc_vec matches 0 run function rscalc:move/release
execute if score #riding rscalc_vec matches 0 run return fail
scoreboard players add @s rscalc_speed 12
execute if score @s rscalc_speed matches 90.. run scoreboard players set @s rscalc_speed 90
execute if entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..8] if score @s rscalc_speed matches 41.. run scoreboard players set @s rscalc_speed 40
execute store result storage rscalc:move d double 0.01 run scoreboard players get @s rscalc_speed
function rscalc:move/pull with storage rscalc:move
function rscalc:move/rope
