execute store result storage rscalc:wp x double 0.01 run data get entity @s Pos[0] 100
execute store result storage rscalc:wp y double 0.01 run data get entity @s Pos[1] 100
execute store result storage rscalc:wp z double 0.01 run data get entity @s Pos[2] 100
particle minecraft:happy_villager ~ ~1 ~ 0.3 0.5 0.3 0 12 normal @s
tellraw @s {"text":"mark set — right-click the compass to come back.","color":"light_purple"}
