execute anchored eyes facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] eyes positioned ^ ^ ^1 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force @a
execute anchored eyes facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] eyes positioned ^ ^ ^2 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force @a
execute anchored eyes facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] eyes positioned ^ ^ ^3 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force @a
execute anchored eyes facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] eyes positioned ^ ^ ^4 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force @a
execute anchored eyes facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] eyes positioned ^ ^ ^5 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force @a
execute anchored eyes facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] eyes positioned ^ ^ ^6 run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force @a
