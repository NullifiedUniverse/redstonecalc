$execute facing entity @e[type=fishing_bobber,limit=1,sort=nearest,distance=..96] feet positioned ^ ^ ^$(d) if block ~ ~ ~ #rscalc:passable run tp @s ~ ~ ~
