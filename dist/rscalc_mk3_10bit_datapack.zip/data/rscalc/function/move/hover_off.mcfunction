tag @s remove rscalc_hover
tellraw @s {"text":"hover off.","color":"gray"}
