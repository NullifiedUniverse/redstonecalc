tag @s remove rscalc_on
tag @s remove rscalc_hover
tellraw @s {"text":"hook and dash off.","color":"gray"}
