$execute as @s on vehicle run data merge entity @s {Motion:[$(mx)d,$(my)d,$(mz)d]}
