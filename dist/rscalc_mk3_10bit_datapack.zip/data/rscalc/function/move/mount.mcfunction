summon minecraft:armor_stand ~ ~0.6 ~ {Invisible:1b,NoGravity:1b,Marker:1b,Silent:1b,Invulnerable:1b,Tags:["rscalc_ride","rscalc_ride_new"]}
tag @s add rscalc_hooked
ride @s mount @e[type=armor_stand,tag=rscalc_ride_new,limit=1]
tag @e[type=armor_stand,tag=rscalc_ride_new] remove rscalc_ride_new
playsound minecraft:entity.arrow.hit player @s ~ ~ ~ 0.4 1.9
