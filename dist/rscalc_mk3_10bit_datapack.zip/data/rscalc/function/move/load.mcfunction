scoreboard objectives add rscalc_dash minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add rscalc_recall minecraft.used:minecraft.compass
scoreboard objectives add rscalc_fall dummy
scoreboard objectives add rscalc_speed dummy
