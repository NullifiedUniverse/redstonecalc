tag @s add rscalc_hover
tellraw @s {"text":"hover on — you will not take fall damage. /function rscalc:move/hover_off to stop.","color":"aqua"}
