scoreboard players set #c100 rscalc_vec 100
scoreboard players operation #spd rscalc_vec = @s rscalc_speed
execute store result score #dx rscalc_vec run data get entity @e[type=marker,tag=rscalc_aim,limit=1] Pos[0] 1000
execute store result score #px rscalc_vec run data get entity @s Pos[0] 1000
scoreboard players operation #dx rscalc_vec -= #px rscalc_vec
scoreboard players operation #dx rscalc_vec *= #spd rscalc_vec
scoreboard players operation #dx rscalc_vec /= #c100 rscalc_vec
execute store result storage rscalc:move mx double 0.001 run scoreboard players get #dx rscalc_vec
execute store result score #dy rscalc_vec run data get entity @e[type=marker,tag=rscalc_aim,limit=1] Pos[1] 1000
execute store result score #py rscalc_vec run data get entity @s Pos[1] 1000
scoreboard players operation #dy rscalc_vec -= #py rscalc_vec
scoreboard players operation #dy rscalc_vec *= #spd rscalc_vec
scoreboard players operation #dy rscalc_vec /= #c100 rscalc_vec
execute store result storage rscalc:move my double 0.001 run scoreboard players get #dy rscalc_vec
execute store result score #dz rscalc_vec run data get entity @e[type=marker,tag=rscalc_aim,limit=1] Pos[2] 1000
execute store result score #pz rscalc_vec run data get entity @s Pos[2] 1000
scoreboard players operation #dz rscalc_vec -= #pz rscalc_vec
scoreboard players operation #dz rscalc_vec *= #spd rscalc_vec
scoreboard players operation #dz rscalc_vec /= #c100 rscalc_vec
execute store result storage rscalc:move mz double 0.001 run scoreboard players get #dz rscalc_vec
function rscalc:move/motion with storage rscalc:move
