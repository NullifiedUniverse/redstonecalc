$tp @s $(x) $(y) $(z)
particle minecraft:reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.2 30 normal @a
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.6 1.2
