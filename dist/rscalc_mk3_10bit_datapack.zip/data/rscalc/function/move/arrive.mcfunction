scoreboard players set @s rscalc_speed 0
scoreboard players set @s rscalc_fall 60
ride @s dismount
kill @e[type=armor_stand,tag=rscalc_ride,distance=..6]
particle minecraft:cloud ~ ~ ~ 0.2 0.2 0.2 0.01 8 normal @a
playsound minecraft:entity.arrow.hit player @s ~ ~ ~ 0.5 1.8
