scoreboard players set @s rscalc_speed 0
scoreboard players set @s rscalc_fall 60
particle minecraft:cloud ~ ~ ~ 0.2 0.2 0.2 0.01 8 normal @a
playsound minecraft:entity.arrow.hit player @s ~ ~ ~ 0.5 1.8
