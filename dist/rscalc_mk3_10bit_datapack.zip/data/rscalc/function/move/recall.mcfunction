scoreboard players set @s rscalc_recall 0
execute unless data storage rscalc:wp x run function rscalc:move/no_mark
execute unless data storage rscalc:wp x run return fail
scoreboard players set @s rscalc_fall 60
particle minecraft:portal ~ ~1 ~ 0.4 0.6 0.4 0.4 40 normal @a
function rscalc:move/recall_at with storage rscalc:wp
