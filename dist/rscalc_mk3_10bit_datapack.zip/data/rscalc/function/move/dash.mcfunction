scoreboard players set @s rscalc_dash 0
scoreboard players set @s rscalc_fall 60
particle minecraft:cloud ~ ~0.2 ~ 0.25 0.1 0.25 0.02 14 normal @a
playsound minecraft:entity.arrow.shoot player @s ~ ~ ~ 0.7 1.7
execute positioned ^ ^ ^1 if block ~ ~ ~ #rscalc:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^2 if block ~ ~ ~ #rscalc:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^3 if block ~ ~ ~ #rscalc:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^4 if block ~ ~ ~ #rscalc:passable run tp @s ~ ~ ~
execute positioned ^ ^ ^5 if block ~ ~ ~ #rscalc:passable run tp @s ~ ~ ~
particle minecraft:end_rod ~ ~1 ~ 0.1 0.1 0.1 0.01 6 normal @a
