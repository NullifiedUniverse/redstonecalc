tag @s add rscalc_on
scoreboard players set @s rscalc_dash 0
scoreboard players set @s rscalc_recall 0
scoreboard players set @s rscalc_speed 0
tellraw @s {"text":"hook and dash on. Cast the rod to grapple, right-click the charm to dash, the compass to recall.","color":"aqua"}
