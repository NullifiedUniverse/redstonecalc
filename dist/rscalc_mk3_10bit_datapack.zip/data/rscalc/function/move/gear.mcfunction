give @s minecraft:fishing_rod
give @s minecraft:carrot_on_a_stick
give @s minecraft:compass
function rscalc:move/mark
function rscalc:move/on
