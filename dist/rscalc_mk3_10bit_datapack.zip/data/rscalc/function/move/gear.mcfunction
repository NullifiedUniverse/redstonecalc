give @s minecraft:fishing_rod[custom_name={text:"Grappling Hook",color:"aqua",italic:false},custom_data={rscalc:1b}]
give @s minecraft:carrot_on_a_stick[custom_name={text:"Dash Charm",color:"gold",italic:false},custom_data={rscalc:1b}]
give @s minecraft:compass[custom_name={text:"Recall Compass",color:"light_purple",italic:false},custom_data={rscalc:1b}]
function rscalc:move/mark
function rscalc:move/on
