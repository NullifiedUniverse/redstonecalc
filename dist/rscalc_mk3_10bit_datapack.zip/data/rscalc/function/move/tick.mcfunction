execute as @a[tag=rscalc_on] at @s run function rscalc:move/grapple
execute as @a[tag=rscalc_on,scores={rscalc_dash=1..}] at @s run function rscalc:move/dash
execute as @a[tag=rscalc_on,scores={rscalc_recall=1..}] at @s run function rscalc:move/recall
execute as @a[scores={rscalc_fall=1..}] run effect give @s minecraft:slow_falling 1 0 true
scoreboard players remove @a[scores={rscalc_fall=1..}] rscalc_fall 1
execute as @a[tag=rscalc_hover] run effect give @s minecraft:slow_falling 2 0 true
execute as @e[type=armor_stand,tag=rscalc_ride] at @s unless entity @a[distance=..2] run kill @s
