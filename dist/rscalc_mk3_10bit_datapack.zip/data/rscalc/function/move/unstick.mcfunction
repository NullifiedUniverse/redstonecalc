ride @s dismount
kill @e[type=armor_stand,tag=rscalc_ride,distance=..32]
scoreboard players set @s rscalc_speed 0
tellraw @s {"text":"dismounted and cleaned up.","color":"yellow"}
