execute unless data storage rscalc:origin x run function rscalc:sys/no_origin
execute unless data storage rscalc:origin x run return fail
scoreboard objectives add rscalc_v dummy
scoreboard players set #keep rscalc_v 1
function rscalc:sys/load_at with storage rscalc:origin
