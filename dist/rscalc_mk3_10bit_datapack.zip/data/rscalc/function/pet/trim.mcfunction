function rscalc:pet/oldest
kill @e[type=marker,tag=rscalc_target]
