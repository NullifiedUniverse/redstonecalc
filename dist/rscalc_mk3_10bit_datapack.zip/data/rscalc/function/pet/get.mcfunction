function rscalc:pet/dismiss
scoreboard players add #next rscalc_pet 1
scoreboard players operation @s rscalc_pet = #next rscalc_pet
data modify storage rscalc:pet uuid set from entity @s UUID
summon minecraft:armor_stand ~ ~ ~ {Small:1b,Invisible:1b,Invulnerable:1b,NoBasePlate:1b,PersistenceRequired:1b,Silent:1b,DisabledSlots:4144959,Tags:["rscalc_pet","rscalc_pet_new"]}
function rscalc:pet/head with storage rscalc:pet
execute as @e[type=armor_stand,tag=rscalc_pet_new] run scoreboard players operation @s rscalc_pet = #next rscalc_pet
tag @e[type=armor_stand,tag=rscalc_pet_new] remove rscalc_pet_new
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.6 1.6
tellraw @s {"text":"your head is following you. It walks the way you walked, and bites what comes near. /function rscalc:pet/dismiss to put it away.","color":"green"}
