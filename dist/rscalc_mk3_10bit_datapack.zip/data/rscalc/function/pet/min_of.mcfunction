execute if score @s rscalc_seq < #min rscalc_seq run scoreboard players operation #min rscalc_seq = @s rscalc_seq
