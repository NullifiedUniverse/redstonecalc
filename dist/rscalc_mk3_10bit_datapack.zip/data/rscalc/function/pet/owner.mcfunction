function rscalc:pet/select
execute unless entity @e[type=armor_stand,tag=rscalc_mine] run function rscalc:pet/lost
execute unless entity @e[type=armor_stand,tag=rscalc_mine] run return fail
execute unless entity @e[type=marker,tag=rscalc_mine,distance=..1.5] run function rscalc:pet/crumb
execute as @e[type=armor_stand,tag=rscalc_mine,limit=1] at @s run function rscalc:pet/drive
