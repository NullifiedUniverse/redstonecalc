scoreboard players operation @s rscalc_pet = #owner rscalc_pet
scoreboard players operation @s rscalc_seq = #seq rscalc_seq
tag @s add rscalc_mine
