scoreboard players reset @s rscalc_pet
kill @e[type=marker,tag=rscalc_mine]
