execute unless entity @a[tag=rscalc_boss,distance=..48] run function rscalc:pet/catch_up
execute if entity @e[type=marker,tag=rscalc_mine] run function rscalc:pet/oldest
execute if entity @e[type=marker,tag=rscalc_target] run function rscalc:pet/walk
function rscalc:pet/fight
