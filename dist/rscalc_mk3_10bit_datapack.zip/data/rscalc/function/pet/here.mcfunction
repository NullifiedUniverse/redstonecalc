function rscalc:pet/select
execute if entity @e[type=armor_stand,tag=rscalc_mine] run tp @e[type=armor_stand,tag=rscalc_mine] @s
kill @e[type=marker,tag=rscalc_mine]
execute unless entity @e[type=armor_stand,tag=rscalc_mine] run function rscalc:pet/none
