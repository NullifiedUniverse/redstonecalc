scoreboard objectives add rscalc_pet dummy
scoreboard objectives add rscalc_seq dummy
scoreboard objectives add rscalc_bite dummy
