execute if score @s rscalc_bite matches 1.. run scoreboard players remove @s rscalc_bite 1
execute if score @s rscalc_bite matches ..0 if entity @e[type=#rscalc:prey,distance=..3.5] run function rscalc:pet/bite
