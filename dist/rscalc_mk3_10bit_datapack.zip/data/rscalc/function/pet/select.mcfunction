scoreboard players set #owner rscalc_pet 0
execute if score @s rscalc_pet matches 1.. run scoreboard players operation #owner rscalc_pet = @s rscalc_pet
tag @a remove rscalc_boss
tag @s add rscalc_boss
tag @e[type=armor_stand,tag=rscalc_pet] remove rscalc_mine
tag @e[type=marker,tag=rscalc_crumb] remove rscalc_mine
execute as @e[type=armor_stand,tag=rscalc_pet] if score @s rscalc_pet = #owner rscalc_pet run tag @s add rscalc_mine
execute as @e[type=marker,tag=rscalc_crumb] if score @s rscalc_pet = #owner rscalc_pet run tag @s add rscalc_mine
