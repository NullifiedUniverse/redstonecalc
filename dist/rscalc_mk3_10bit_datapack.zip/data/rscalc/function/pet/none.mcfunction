tellraw @s {"text":"you have no pet — /function rscalc:pet/get.","color":"red"}
