execute facing entity @e[type=marker,tag=rscalc_target,limit=1] feet positioned ^ ^ ^0.22 if block ~ ~ ~ #rscalc:passable run tp @s ^ ^ ^0.22
execute facing entity @e[type=marker,tag=rscalc_target,limit=1] feet positioned ^ ^ ^0.22 unless block ~ ~ ~ #rscalc:passable if block ~ ~1 ~ #rscalc:passable run tp @s ^ ^0.55 ^0.22
