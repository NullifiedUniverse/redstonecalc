kill @e[type=marker,tag=rscalc_mine]
tp @s @a[tag=rscalc_boss,limit=1]
particle minecraft:poof ~ ~0.2 ~ 0.2 0.2 0.2 0.01 6 normal @a
