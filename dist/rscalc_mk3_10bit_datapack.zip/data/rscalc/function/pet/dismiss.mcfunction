function rscalc:pet/select
kill @e[type=armor_stand,tag=rscalc_mine]
kill @e[type=marker,tag=rscalc_mine]
scoreboard players reset @s rscalc_pet
