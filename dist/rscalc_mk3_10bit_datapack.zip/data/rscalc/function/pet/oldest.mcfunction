tag @e[type=marker,tag=rscalc_target] remove rscalc_target
scoreboard players set #min rscalc_seq 2147483647
execute as @e[type=marker,tag=rscalc_mine] run function rscalc:pet/min_of
execute as @e[type=marker,tag=rscalc_mine] if score @s rscalc_seq = #min rscalc_seq run tag @s add rscalc_target
