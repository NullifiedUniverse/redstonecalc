damage @e[type=#rscalc:prey,distance=..3.5,limit=1,sort=nearest] 4 minecraft:mob_attack by @s from @p
execute facing entity @e[type=#rscalc:prey,distance=..3.5,limit=1,sort=nearest] feet positioned ^ ^0.3 ^0.6 run particle minecraft:crit ~ ~ ~ 0.1 0.1 0.1 0.05 6 normal @a
playsound minecraft:entity.wolf.growl neutral @a ~ ~ ~ 0.5 1.6
scoreboard players set @s rscalc_bite 20
