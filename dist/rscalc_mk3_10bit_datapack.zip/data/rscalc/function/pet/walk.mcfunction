execute if entity @e[type=marker,tag=rscalc_target,distance=..0.9] run kill @e[type=marker,tag=rscalc_target]
execute if entity @e[type=marker,tag=rscalc_target] run function rscalc:pet/step
