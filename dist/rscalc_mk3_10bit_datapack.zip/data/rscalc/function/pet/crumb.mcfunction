scoreboard players add #seq rscalc_seq 1
summon minecraft:marker ~ ~ ~ {Tags:["rscalc_crumb","rscalc_crumb_new"]}
execute as @e[type=marker,tag=rscalc_crumb_new] run function rscalc:pet/crumb_id
tag @e[type=marker,tag=rscalc_crumb_new] remove rscalc_crumb_new
execute store result score #crumbs rscalc_seq if entity @e[type=marker,tag=rscalc_mine]
execute if score #crumbs rscalc_seq matches 65.. run function rscalc:pet/trim
