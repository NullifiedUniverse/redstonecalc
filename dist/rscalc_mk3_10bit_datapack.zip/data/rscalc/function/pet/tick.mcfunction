execute as @a[scores={rscalc_pet=1..}] at @s run function rscalc:pet/owner
