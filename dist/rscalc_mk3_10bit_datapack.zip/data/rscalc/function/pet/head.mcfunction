$item replace entity @e[type=armor_stand,tag=rscalc_pet_new,limit=1] armor.head with minecraft:player_head[minecraft:profile={id:$(uuid)}]
