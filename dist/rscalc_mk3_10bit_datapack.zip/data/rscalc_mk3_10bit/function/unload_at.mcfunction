$execute positioned $(x) $(y) $(z) run function rscalc_mk3_10bit:unload_tiles
