$execute positioned $(x) $(y) $(z) run tp @s ~558 ~193 ~8
tellraw @s {"text":"rscalc_mk3_10bit: display","color":"gray"}
