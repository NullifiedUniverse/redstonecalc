scoreboard players set #run rscalc_mk3_10bit_step 0
tellraw @a {"text":"rscalc_mk3_10bit placed: 71,768 blocks, 555 x 195 x 973. The control wall is at the -X end. /function rscalc_mk3_10bit:help for what to do next.","color":"green"}
title @a actionbar {"text":"rscalc_mk3_10bit: placed","color":"green"}
