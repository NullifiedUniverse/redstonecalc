scoreboard objectives add rscalc_mk3_10bit_step dummy
execute unless data storage rscalc_mk3_10bit:origin x run function rscalc_mk3_10bit:no_origin
execute if data storage rscalc_mk3_10bit:origin x run function rscalc_mk3_10bit:status_show with storage rscalc_mk3_10bit:origin
execute if score #run rscalc_mk3_10bit_step matches 1 if data storage rscalc_mk3_10bit:ui part run function rscalc_mk3_10bit:status_running with storage rscalc_mk3_10bit:ui
execute if score #run rscalc_mk3_10bit_step matches 1 if data storage rscalc_mk3_10bit:ui layer run function rscalc_mk3_10bit:status_clearing with storage rscalc_mk3_10bit:ui
execute if data storage rscalc_mk3_10bit:origin x unless entity @e[type=marker,tag=rscalc_mk3_10bit_anchor] run function rscalc_mk3_10bit:status_lost
