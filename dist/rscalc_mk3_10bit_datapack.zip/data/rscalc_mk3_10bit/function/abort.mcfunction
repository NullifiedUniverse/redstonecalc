schedule clear rscalc_mk3_10bit:tick
schedule clear rscalc_mk3_10bit:clear_tick
scoreboard players set #run rscalc_mk3_10bit_step 0
kill @e[type=marker,tag=rscalc_mk3_10bit_anchor_clear]
tellraw @a {"text":"rscalc_mk3_10bit: stopped. The machine is half-placed; run build again or clear it.","color":"yellow"}
