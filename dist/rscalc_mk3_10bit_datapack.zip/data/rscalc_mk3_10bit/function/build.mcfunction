# 71,768 commands in 36 parts, one part per tick.
# Stand at the machine's -X -Y -Z corner and run this.
scoreboard objectives add rscalc_mk3_10bit_step dummy
execute if score #run rscalc_mk3_10bit_step matches 1 run function rscalc_mk3_10bit:busy
execute if score #run rscalc_mk3_10bit_step matches 1 run return fail
scoreboard players set #run rscalc_mk3_10bit_step 1
scoreboard players set #build rscalc_mk3_10bit_step 0
data remove storage rscalc_mk3_10bit:ui layer
kill @e[type=marker,tag=rscalc_mk3_10bit_anchor]
execute at @s align xyz run summon marker ~ ~ ~ {Tags:["rscalc_mk3_10bit_anchor"]}
execute store result storage rscalc_mk3_10bit:origin x int 1 run data get entity @e[type=marker,tag=rscalc_mk3_10bit_anchor,limit=1] Pos[0]
execute store result storage rscalc_mk3_10bit:origin y int 1 run data get entity @e[type=marker,tag=rscalc_mk3_10bit_anchor,limit=1] Pos[1]
execute store result storage rscalc_mk3_10bit:origin z int 1 run data get entity @e[type=marker,tag=rscalc_mk3_10bit_anchor,limit=1] Pos[2]
tellraw @a {"text":"rscalc_mk3_10bit: 71,768 commands over 36 ticks (1.8s). You are standing inside the footprint — use spectator, or /function rscalc_mk3_10bit:go_above.","color":"gray"}
function rscalc_mk3_10bit:load
function rscalc_mk3_10bit:tick
