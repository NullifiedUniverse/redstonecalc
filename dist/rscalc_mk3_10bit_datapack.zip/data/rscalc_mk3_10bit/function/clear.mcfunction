# Removes the machine wherever it was built. Run it from anywhere.
scoreboard objectives add rscalc_mk3_10bit_step dummy
execute if score #run rscalc_mk3_10bit_step matches 1 run function rscalc_mk3_10bit:busy
execute if score #run rscalc_mk3_10bit_step matches 1 run return fail
execute unless data storage rscalc_mk3_10bit:origin x run function rscalc_mk3_10bit:no_origin
execute unless data storage rscalc_mk3_10bit:origin x run return fail
scoreboard players set #run rscalc_mk3_10bit_step 1
scoreboard players set #clear rscalc_mk3_10bit_step 0
function rscalc_mk3_10bit:load
function rscalc_mk3_10bit:clear_at with storage rscalc_mk3_10bit:origin
