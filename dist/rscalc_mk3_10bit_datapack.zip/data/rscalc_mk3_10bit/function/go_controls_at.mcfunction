$execute positioned $(x) $(y) $(z) run tp @s ~59 ~1 ~107
tellraw @s {"text":"rscalc_mk3_10bit: controls","color":"gray"}
