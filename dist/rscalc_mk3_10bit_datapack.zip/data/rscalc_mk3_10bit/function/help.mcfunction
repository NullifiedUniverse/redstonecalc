tellraw @a {"text":"rscalc_mk3_10bit — 555 x 195 x 973, 71,768 blocks","color":"white"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:build  — place it, from the -X -Y -Z corner","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:clear  — take it away again, from anywhere","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:status  — where it is and what it is doing","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:load  — force-load its chunks so it ticks","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:unload  — release them again","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:abort  — stop a build or clear part way","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:go_above  — teleport to the above","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:go_controls  — teleport to the controls","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:go_display  — teleport to the display","color":"gray"}
tellraw @a {"text":"  /function rscalc_mk3_10bit:go_origin  — teleport to the origin","color":"gray"}
