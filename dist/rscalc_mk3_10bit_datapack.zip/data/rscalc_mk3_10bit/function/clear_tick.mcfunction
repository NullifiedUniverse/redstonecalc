execute as @e[type=marker,tag=rscalc_mk3_10bit_anchor_clear,limit=1] at @s run function rscalc_mk3_10bit:clear_slice
execute as @e[type=marker,tag=rscalc_mk3_10bit_anchor_clear,limit=1] at @s run tp @s ~ ~1 ~
scoreboard players add #clear rscalc_mk3_10bit_step 1
execute store result storage rscalc_mk3_10bit:ui layer int 1 run scoreboard players get #clear rscalc_mk3_10bit_step
function rscalc_mk3_10bit:clear_progress with storage rscalc_mk3_10bit:ui
execute if score #clear rscalc_mk3_10bit_step matches ..194 run schedule function rscalc_mk3_10bit:clear_tick 1t replace
execute if score #clear rscalc_mk3_10bit_step matches 195.. run function rscalc_mk3_10bit:clear_done
