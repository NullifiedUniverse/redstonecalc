data remove storage rscalc_mk3_10bit:ui part
kill @e[type=marker,tag=rscalc_mk3_10bit_anchor_clear]
summon marker ~ ~ ~ {Tags:["rscalc_mk3_10bit_anchor_clear"]}
tellraw @a {"text":"rscalc_mk3_10bit: clearing 195 layers (9.8s)...","color":"gray"}
function rscalc_mk3_10bit:clear_tick
