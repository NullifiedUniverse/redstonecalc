$execute positioned $(x) $(y) $(z) run tp @s ~277 ~207 ~486
tellraw @s {"text":"rscalc_mk3_10bit: above","color":"gray"}
