$execute positioned $(x) $(y) $(z) run tp @s ~0 ~0 ~0
tellraw @s {"text":"rscalc_mk3_10bit: origin","color":"gray"}
