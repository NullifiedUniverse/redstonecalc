kill @e[type=marker,tag=rscalc_mk3_10bit_anchor_clear]
kill @e[type=marker,tag=rscalc_mk3_10bit_anchor]
function rscalc_mk3_10bit:unload
data remove storage rscalc_mk3_10bit:origin x
data remove storage rscalc_mk3_10bit:origin y
data remove storage rscalc_mk3_10bit:origin z
scoreboard players set #run rscalc_mk3_10bit_step 0
tellraw @a {"text":"rscalc_mk3_10bit removed: 195 layers, chunks released.","color":"gray"}
title @a actionbar {"text":"rscalc_mk3_10bit: removed","color":"gray"}
