tellraw @a {"text":"rscalc_mk3_10bit: a build or clear is already running. Wait for it, or /function rscalc_mk3_10bit:abort.","color":"red"}
