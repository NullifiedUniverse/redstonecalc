execute unless data storage rscalc_mk3_10bit:origin x run function rscalc_mk3_10bit:no_origin
execute unless data storage rscalc_mk3_10bit:origin x run return fail
function rscalc_mk3_10bit:go_origin_at with storage rscalc_mk3_10bit:origin
