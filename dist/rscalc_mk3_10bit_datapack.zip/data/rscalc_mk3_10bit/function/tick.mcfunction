execute as @e[type=marker,tag=rscalc_mk3_10bit_anchor,limit=1] at @s run function rscalc_mk3_10bit:dispatch
scoreboard players add #build rscalc_mk3_10bit_step 1
execute store result storage rscalc_mk3_10bit:ui part int 1 run scoreboard players get #build rscalc_mk3_10bit_step
function rscalc_mk3_10bit:progress with storage rscalc_mk3_10bit:ui
execute if score #build rscalc_mk3_10bit_step matches ..35 run schedule function rscalc_mk3_10bit:tick 1t replace
execute if score #build rscalc_mk3_10bit_step matches 36.. run function rscalc_mk3_10bit:done
