rscalc_mk3_10bit — a 456,558-block redstone calculator
============================================================

555 x 195 x 973, targets Minecraft 26.2.
(What the launcher calls 1.26.2 the pack format table calls 26.2. This pack
declares both the new min_format/max_format pair and a legacy pack_format, so
it also loads on 1.21.)

  1. This zip goes in <your world>/datapacks/   — cheats on; superflat is easiest
  2. /reload
  3. Stand where you want the -X -Y -Z corner, facing +X:

       /function rscalc:build

It force-loads 2135 chunks and then **waits for them to actually
arrive** before placing anything. That wait is the difference between a machine
and a floor covered in dropped redstone: /forceload marks chunks, it does not
load them, and a /fill into a chunk that has not arrived yet fails silently.
Expect "loading chunks N of 2135" on the action bar for a while —
on a cold world that can be minutes.

Then 71,768 commands over 36 ticks. Solid blocks go down first
across the whole build, then the redstone, so nothing is ever placed into thin
air and dropped as an item.

You are standing inside the footprint when it starts. Use spectator, or
/function rscalc:go/above.

Everything else
---------------
  /function rscalc:status      where it is and what it is doing
  /function rscalc:clear       remove it — from anywhere, not just the corner
  /function rscalc:load        force-load its chunks again
  /function rscalc:unload      release them (the machine stops ticking)
  /function rscalc:abort       stop a build or clear part way
  /function rscalc:help        this list, in game
  /function rscalc:move/gear   grappling hook, dash charm, recall compass

The control wall is at the -X end; the lamps are 973 blocks away at the other.
Flip the operand levers, press an operation key, read the digits. The answer
takes a couple of thousand game ticks to arrive — it is a very deep machine.
