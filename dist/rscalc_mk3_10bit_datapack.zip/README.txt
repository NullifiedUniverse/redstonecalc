rscalc_mk3_10bit — a 456,558-block redstone calculator
============================================================

555 x 195 x 973, targets Minecraft 26.2.
(What the launcher calls 1.26.2 the pack format table calls 26.2. This pack
declares both the new min_format/max_format pair and a legacy pack_format, so
it also loads on 1.21.)

  1. This zip goes in <your world>/datapacks/   — cheats on; superflat is easiest
  2. /reload
  3. Stand where you want the -X -Y -Z corner, facing +X:

       /function rscalc:build

It force-loads 2135 chunks and then **waits for them to actually
arrive** before placing anything. That wait is the difference between a machine
and a floor covered in dropped redstone: /forceload marks chunks, it does not
load them, and a /fill into a chunk that has not arrived yet fails silently.
Expect "loading chunks N of 2135" on the action bar for a while —
on a cold world that can be minutes.

Then 71,768 commands over 120 batches, one a tick — about
6 seconds, with a boss bar and a knock that rises in
pitch as it goes. Solid blocks go down first across the whole build, then the
redstone, so nothing is ever placed into thin air and dropped as an item.

To watch it go up slowly, set the batch pace first — this is ticks per batch,
so 4 stretches it to 24 seconds:

    /scoreboard players set #pace rscalc_v 4

You are standing inside the footprint when it starts. Use spectator, or
/function rscalc:go/above.

Everything else
---------------
  /function rscalc:status      where it is and what it is doing
  /function rscalc:clear       remove it — from anywhere, not just the corner
  /function rscalc:load        force-load its chunks again
  /function rscalc:unload      release them (the machine stops ticking)
  /function rscalc:abort       stop a build or clear part way
  /function rscalc:help        this list, in game
  /function rscalc:go/controls the lever wall — every lever has a sign on it
  /function rscalc:move/gear   grappling hook, dash charm, recall compass

The chunks stay force-loaded across restarts: /forceload is saved with the
world, and this pack re-asserts it on every world start as well, until you run
rscalc:unload. That is what lets the machine keep computing while you walk away.

The control wall is at the -X end; the lamps are 973 blocks away at the other.
Every lever has a wall sign beside it saying which operand bit it is and what
it is worth, and each operation key is named. Flip the operand levers, press an
operation key, read the digits. The answer takes a couple of thousand game
ticks to arrive — it is a very deep machine.

The gadgets
-----------
/function rscalc:move/gear hands you a rod, a carrot on a stick and a compass.
Cast the rod at something up to 96 blocks away and it pulls you there — it is a
real pull, not a teleport: you ride an invisible mount whose velocity is set
each tick, so the movement interpolates and you keep your momentum when it lets
go. Reel in to release. The carrot dashes you 5 blocks where you look, the
compass returns you to your mark (rscalc:move/mark). Anything that lets go leaves
you with slow falling. If you are ever left riding something, rscalc:move/unstick.
